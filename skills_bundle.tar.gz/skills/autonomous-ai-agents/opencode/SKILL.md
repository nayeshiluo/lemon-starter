---
name: opencode
description: "Delegate coding to OpenCode CLI (features, PR review)."
version: 1.2.0
author: Hermes Agent
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [Coding-Agent, OpenCode, Autonomous, Refactoring, Code-Review]
    related_skills: [claude-code, codex, hermes-agent]
---

# OpenCode CLI

Use [OpenCode](https://opencode.ai) as an autonomous coding worker orchestrated by Hermes terminal/process tools. OpenCode is a provider-agnostic, open-source AI coding agent with a TUI and CLI.

## When to Use

- User explicitly asks to use OpenCode
- You want an external coding agent to implement/refactor/review code
- You need long-running coding sessions with progress checks
- You want parallel task execution in isolated workdirs/worktrees

## Prerequisites

- OpenCode installed: `npm i -g opencode-ai@latest` or `brew install anomalyco/tap/opencode`
- Auth configured: `opencode auth login` or set provider env vars (OPENROUTER_API_KEY, etc.)
- Verify: `opencode auth list` should show at least one provider
- Git repository for code tasks (recommended)
- `pty=true` for interactive TUI sessions

## Install on this host (verified 2026-11-07)

`npm i -g opencode-ai` fails with `EACCES /usr/local/lib/node_modules` — must use the user prefix:

```
npm --prefix /home/ubuntu/.npm-global i -g opencode-ai@latest
ln -sf /home/ubuntu/.npm-global/bin/opencode /home/ubuntu/bin/opencode
```

npm blocks the package's `postinstall` by default; the CLI still works, but if a platform binary is missing re-run with `--allow-scripts=opencode-ai`.

## Wiring an OpenAI-compatible relay (no hardcoded keys)

Config lives at `~/.config/opencode/opencode.json`. Reference keys by env name so no secret is written to disk:

```json
{
  "$schema": "https://opencode.ai/config.json",
  "provider": {
    "command": {
      "npm": "@ai-sdk/openai-compatible",
      "name": "Command",
      "options": {
        "baseURL": "https://api.commandcode.ai/provider/v1",
        "apiKey": "{env:COMMAND_API_KEY}"
      },
      "models": { "gpt-5.6-sol": { "name": "gpt-5.6-sol" } }
    }
  },
  "model": "command/gpt-5.6-sol"
}
```

Rules learned the hard way:
- `models` keys must be the **exact ids returned by `<base_url>/models`** — display names with spaces (e.g. `Deepseek v4.1 Flash` on ikun) get rejected or 500.
- Anthropic-shaped models on a relay require `@ai-sdk/anthropic` + `/messages` endpoint; with `@ai-sdk/openai-compatible` the `/v1/chat/completions` path errors out ("must be called via /provider/v1/messages"). Prefer OpenAI-shape models (`gpt-*`, `deepseek-*`) on relays.
- `opencode auth list` showing 0 credentials is fine when providers come from env vars; ZHIPU_API_KEY being present makes OpenCode default to `glm-*`, which fails with "Insufficient balance" — always pin `model` in the config or pass `-m`.

## Making the v2 server durable (systemd)

`opencode2 pair` exits after printing the link but leaves `opencode serve --service` running as an orphan in whatever cgroup launched it (in Hermes that is `hermes-web-ui.service`, so a panel restart kills the mobile connection and its RAM is billed to the panel). Promote it to its own unit:

```ini
[Service]
Type=simple
User=ubuntu
WorkingDirectory=/home/ubuntu/oc-play
Environment=HOME=/home/ubuntu
Environment=PATH=/home/ubuntu/.opencode/bin:/usr/local/bin:/usr/bin:/bin
ExecStart=/home/ubuntu/.opencode/bin/opencode2 serve --service --hostname 127.0.0.1 --port 49374
Restart=always
RestartSec=5
KillMode=mixed
MemoryMax=2G
MemoryHigh=1500M
```

- Stop the orphan with SIGTERM first, then `systemctl enable --now`.
- `~/.config/opencode/service.json` holds `remote.route` (stable opentunnel subdomain) + `password`, so the tunnel reconnects on every restart and the URL does not change — only the one-time pairing link is regenerated.
- Verify for real: `systemctl restart`, then confirm MainPID changed, `ss` still listens, and BOTH `curl 127.0.0.1:<port>` and the `<YOUR_PRIVATE_DOMAIN>` URL return 200.
- Footprint measured on this host (2026-11-08): RSS ~200–330 MiB (peak 509 MiB), ~0.2% of one core idle, 247 MB binary + ~12–24 MB data.

## v2 CLI + mobile app pairing (verified 2026-11-08)

The mobile app (and `pair`) only exists on the v2 line; 1.19.x has no `pair` subcommand.

```
curl -fsSL https://opencode.ai/v2/install | bash   # -> ~/.opencode/bin/opencode2, coexists with npm 1.19.x
opencode2 pair --remote --yes                      # prints a one-time URL + QR, valid 5 min
```

- `--remote` publishes the server through `<YOUR_PRIVATE_DOMAIN>` (E2E encrypted, gated by the server password). Without `--yes` it needs an interactive TTY.
- After pairing the `pair` process exits but `opencode serve --service` keeps running on a random 127.0.0.1 port; that service is not systemd-managed, so it dies on reboot.
- v2 reads the same `~/.config/opencode/opencode.json`, so relay providers configured for 1.19.x appear in `opencode2 models` with no extra work.
- The `opencode/*-free` quota is shared across both versions: a mobile session hitting free models logs `AI.Error.QuotaExceeded: Free usage limit reached` in `~/.local/share/opencode/log/opencode.log`. Point the app at a relay model instead.
- Diagnostic: `opencode2 run -m <provider>/<model> 'Reply with exactly: X'` works headless and is the fastest way to prove a model is usable from the server side.

## Free tier (verified 2026-11-07)

`opencode/<id>` free models (`glm-5.3-flash-free`, `deepseek-v4.1-flash-free`, `big-pickle`, `iceman-free`, `flint-40b-free`, `nemotron-*-free`, `mimo-v2.6-flash-free`, `inkling-2-small-free`, `crouton-alpha-free`, `beam-free`, `jev-1.13-free`) need no API key — but the quota is per anonymous install/device, not per IP:

- `opencode run -m opencode/glm-5.3-flash-free ...` prints nothing and exits 0; only `--print-logs` reveals `AI_APICallError: Free usage limit reached ... subscribe to OpenCode Go`.
- Rerouting through another exit IP (socks5 → http CONNECT bridge) gives the identical error, so IP rotation does not reset the quota.
- Several free models are geo-blocked (Crouton Alpha, Beam exclude China incl. HK/Macau; Inkling excludes EU etc.) and Nemotron free endpoints return `Unexpected server error`.
- Always add `--print-logs` when a model returns empty output — silent empty stdout is the normal symptom of quota/geo errors.

## Binary Resolution (Important)

Shell environments may resolve different OpenCode binaries. If behavior differs between your terminal and Hermes, check:

```
terminal(command="which -a opencode")
terminal(command="opencode --version")
```

If needed, pin an explicit binary path:

```
terminal(command="$HOME/.opencode/bin/opencode run '...'", workdir="~/project", pty=true)
```

## One-Shot Tasks

Use `opencode run` for bounded, non-interactive tasks:

```
terminal(command="opencode run 'Add retry logic to API calls and update tests'", workdir="~/project")
```

Attach context files with `-f`:

```
terminal(command="opencode run 'Review this config for security issues' -f config.yaml -f .env.example", workdir="~/project")
```

Show model thinking with `--thinking`:

```
terminal(command="opencode run 'Debug why tests fail in CI' --thinking", workdir="~/project")
```

Force a specific model:

```
terminal(command="opencode run 'Refactor auth module' --model openrouter/anthropic/claude-sonnet-4", workdir="~/project")
```

## Interactive Sessions (Background)

For iterative work requiring multiple exchanges, start the TUI in background:

```
terminal(command="opencode", workdir="~/project", background=true, pty=true)
# Returns session_id

# Send a prompt
process(action="submit", session_id="<id>", data="Implement OAuth refresh flow and add tests")

# Monitor progress
process(action="poll", session_id="<id>")
process(action="log", session_id="<id>")

# Send follow-up input
process(action="submit", session_id="<id>", data="Now add error handling for token expiry")

# Exit cleanly — Ctrl+C
process(action="write", session_id="<id>", data="\x03")
# Or just kill the process
process(action="kill", session_id="<id>")
```

**Important:** Do NOT use `/exit` — it is not a valid OpenCode command and will open an agent selector dialog instead. Use Ctrl+C (`\x03`) or `process(action="kill")` to exit.

### TUI Keybindings

| Key | Action |
|-----|--------|
| `Enter` | Submit message (press twice if needed) |
| `Tab` | Switch between agents (build/plan) |
| `Ctrl+P` | Open command palette |
| `Ctrl+X L` | Switch session |
| `Ctrl+X M` | Switch model |
| `Ctrl+X N` | New session |
| `Ctrl+X E` | Open editor |
| `Ctrl+C` | Exit OpenCode |

### Resuming Sessions

After exiting, OpenCode prints a session ID. Resume with:

```
terminal(command="opencode -c", workdir="~/project", background=true, pty=true)  # Continue last session
terminal(command="opencode -s ses_abc123", workdir="~/project", background=true, pty=true)  # Specific session
```

## Common Flags

| Flag | Use |
|------|-----|
| `run 'prompt'` | One-shot execution and exit |
| `--continue` / `-c` | Continue the last OpenCode session |
| `--session <id>` / `-s` | Continue a specific session |
| `--agent <name>` | Choose OpenCode agent (build or plan) |
| `--model provider/model` | Force specific model |
| `--format json` | Machine-readable output/events |
| `--file <path>` / `-f` | Attach file(s) to the message |
| `--thinking` | Show model thinking blocks |
| `--variant <level>` | Reasoning effort (high, max, minimal) |
| `--title <name>` | Name the session |
| `--attach <url>` | Connect to a running opencode server |

## Procedure

1. Verify tool readiness:
   - `terminal(command="opencode --version")`
   - `terminal(command="opencode auth list")`
2. For bounded tasks, use `opencode run '...'` (no pty needed).
3. For iterative tasks, start `opencode` with `background=true, pty=true`.
4. Monitor long tasks with `process(action="poll"|"log")`.
5. If OpenCode asks for input, respond via `process(action="submit", ...)`.
6. Exit with `process(action="write", data="\x03")` or `process(action="kill")`.
7. Summarize file changes, test results, and next steps back to user.

## PR Review Workflow

OpenCode has a built-in PR command:

```
terminal(command="opencode pr 42", workdir="~/project", pty=true)
```

Or review in a temporary clone for isolation:

```
terminal(command="REVIEW=$(mktemp -d) && git clone https://github.com/user/repo.git $REVIEW && cd $REVIEW && opencode run 'Review this PR vs main. Report bugs, security risks, test gaps, and style issues.' -f $(git diff origin/main --name-only | head -20 | tr '\n' ' ')", pty=true)
```

## Parallel Work Pattern

Use separate workdirs/worktrees to avoid collisions:

```
terminal(command="opencode run 'Fix issue #101 and commit'", workdir="/tmp/issue-101", background=true, pty=true)
terminal(command="opencode run 'Add parser regression tests and commit'", workdir="/tmp/issue-102", background=true, pty=true)
process(action="list")
```

## Session & Cost Management

List past sessions:

```
terminal(command="opencode session list")
```

Check token usage and costs:

```
terminal(command="opencode stats")
terminal(command="opencode stats --days 7 --models anthropic/claude-sonnet-4")
```

## Pitfalls

- Interactive `opencode` (TUI) sessions require `pty=true`. The `opencode run` command does NOT need pty.
- `/exit` is NOT a valid command — it opens an agent selector. Use Ctrl+C to exit the TUI.
- PATH mismatch can select the wrong OpenCode binary/model config.
- If OpenCode appears stuck, inspect logs before killing:
  - `process(action="log", session_id="<id>")`
- Avoid sharing one working directory across parallel OpenCode sessions.
- Enter may need to be pressed twice to submit in the TUI (once to finalize text, once to send).

## Verification

Smoke test:

```
terminal(command="opencode run 'Respond with exactly: OPENCODE_SMOKE_OK'")
```

Success criteria:
- Output includes `OPENCODE_SMOKE_OK`
- Command exits without provider/model errors
- For code tasks: expected files changed and tests pass

## Rules

1. Prefer `opencode run` for one-shot automation — it's simpler and doesn't need pty.
2. Use interactive background mode only when iteration is needed.
3. Always scope OpenCode sessions to a single repo/workdir.
4. For long tasks, provide progress updates from `process` logs.
5. Report concrete outcomes (files changed, tests, remaining risks).
6. Exit interactive sessions with Ctrl+C or kill, never `/exit`.
