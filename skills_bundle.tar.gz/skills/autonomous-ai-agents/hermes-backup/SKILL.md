---
name: hermes-backup
description: "Backup Hermes: local snapshot + encrypted Telegram offsite."
version: 1.0.0
author: 柠檬
license: MIT
platforms: [linux]
metadata:
  hermes:
    tags: [backup, hermes, telegram, cron, sqlite, openssl]
---

# Hermes 备份与恢复

## 当前权威入口

- 正式脚本：`~/.hermes/scripts/backup_hermes.sh`；cron job `319e7f36295e` 调用此脚本。`~/bin/backup_hermes.sh` 只作兼容转发，不保存第二份实现。
- 先只读检查 cron、正式脚本、最近备份、恢复材料和上传清单；不得用历史描述替代实时状态。
- 2026-10-16 核对的计划为每日 `0 3 * * *`，下一次时间按 UTC 记录；03:00 UTC 为北京时间 11:00。改时间前核对任务时区和用户要求。
- 正式脚本会读取数据库、创建本地备份并向既有目标上传；只有请求授权备份/重试上传时才运行，不为“检查一下”发送 Telegram 文件。

## 内容与一致性

- 当前数据库清单：`state.db`、`kanban.db`、`response_store.db`、`verification_evidence.db`。
- 用 Hermes venv 的匹配 SQLite 环境与 backup API 包含已提交 WAL；不要在线裸拷主库。
- 健康门禁失败时保留现场报告，不关闭门禁、不把异常库写成健康备份。
- 私有数据包含配置、凭证、人设、memories/skills/cron/scripts/hooks 和正式脚本列出的恢复目录；恢复辅助包包含用户 bin 与用户级服务定义。
- 源码、二进制和缓存不在数据包中；完整恢复另核对 git 源码与生产补丁，不能仅因 data.tar.gz 存在就声称可完整恢复。
- **整机迁移不是恢复日备份**：逐项检查真实包成员与当前源。`data` 的 `*.db` 排除会漏掉不在顶层四库名单里的辅助库；统一包的在线快照作用域也可能只覆盖直接子目录的 `*.db`/`*.session`，嵌套 `.sqlite`、队列库及其 WAL 不能仅凭已入 tar 判一致。Web UI、CLI/SSH/OAuth/设备身份、共享模块链接目标、系统级 unit/drop-in/服务账户及其他项目须单列覆盖；未覆盖不等于可丢弃。
- **备份新鲜度按内容核对**：记忆、配置、业务库在备份后可继续变化，晨间快照通过哈希不等于等同当前状态。切换前需另做最终一致快照/增量，并验证单写者交接；不得同时启用两个相同 Bot/session/OAuth 凭据的消费者。
- **下节为历史事故参数，不是当前配额**：512MiB、暂存倍数、异地份数等必须从当前 `offsite_backup.py` 和执行参数重新读取。`source_validation` 只证明加密前源产物校验；只有真实取回、解密和隔离恢复才证明该次恢复路径。不能因日志 SUCCESS 就写已恢复验证。
- 凭证、数据库、会话只留在受限私有备份，不得提交 Git 或放入公开技能包。

## 当前加密与异地验收

- 本地目录：`~/backups/hermes-<时间戳>/`；目录 700、敏感文件 600。保留策略以正式脚本和 backup_safety.py 为准。
- 当前异地文件为 CMS DER `.cms`，用 `~/.config/hermes-backup/recovery-cert.pem` 公钥证书加密；不能用旧 .enc + .backup_key 方法解密。
- 解密需要匹配的恢复私钥，公钥证书不能解密。私钥由所有者独立保管，不打印、不写入技能、不上传服务器或 Git。
- 上传以全部加密分片和最终清单完成为准，数量/哈希/大小须符合清单。单个分片或局部 ok 不等于完整异地备份。
- backup_upload_failed 等错误须分别报告本地与异地状态；只读核查日志、分片、目标限额/权限，再根据授权重试，失败不得标 SUCCESS。
- 实际解密、完整清单检查和隔离恢复都通过才算恢复验证；没有私钥或分片不全时明确标记未验证。

## 洛杉矶离站链路（offsite_backup.py）的四个坑（2026-10-20 实测修复）

- **两个离站链路要分开看**：`~/.hermes/scripts/backup_hermes.sh`（每日 03:00，CMS 分片发 Telegram）与 `hermes-jobs/releases/offsite-20261004/offsite_backup.py`（每日 03:30 由 `phase5-backup-schedule.sh` 调用，`.hermesenc` 发洛杉矶）是**独立两条**。前者成功不代表后者成功；只查 `backups/hermes-*/UPLOAD_MANIFEST.json` 会误判为“备份正常”。
- **512MiB 硬天花板**：`offsite_backup.py:204` 判定 `total > 512MiB` 直接失败。`total` **不是** unified 快照大小，而是 `package()` 里 9 个文件的合计：`unified/{state.db,configs.tar.gz}` + `hermes-*/{state.db,kanban.db,response_store.db,data.tar.gz,model_proxy.tar.gz,verification_evidence.db,recovery_support.tar.gz}`。核算时必须按这 9 项求和，只 `du` unified 会严重低估。
- **空间需求 = total × 4 + 1GiB**：同一行第二个条件。total 541.6M 时需 3.12GiB，磁盘只剩 1.7G 必然失败。清理磁盘前先按此公式核算，别清完才发现还是不够。
- **失败现场故意保留，会自我放大**：`execute()` 的 `finally` 只在 `success=True` 时 `rmtree`，失败则打印 `FAILED: preserved private workspace` 并保留 `tmp/offsite-XXXXXXXX`（约 1.2G：snapshot.tar + 加密包各一份）。下一次备份因空间不足再次失败，再留一份 → **磁盘被自己的失败现场挤爆**。清理前必须确认源数据仍在 `backups/unified/<stamp>` 且失败日志已存档（`jobs/unified-backup-daily/job.log`），然后才能删。
- **scp 超时曾固定 180s**：跨境实测约 **0.93 MB/s**，509M 需 547s，180s 只能传 167M 就 `TimeoutExpired`，远端留下 `.part` 半截文件。已改为模块级 `scp_timeout(size)`：`min(1800, max(900, size/(0.8MB/s)+180))`，**上传与 verify 取回两处都调用它**。改时注意作用域——最初把 `transfer_timeout` 定义在 `publish()` 内、却在 `execute()` 的 verify 分支引用，会 `NameError`，必须提为模块级函数。
- **备份内容冗余是包体膨胀主因**：`model_proxy.tar.gz` 曾达 91M，内含 **4 份 CPA 二进制**（`cli-proxy-api` ×3 + 安装包 ×1，约 222M 未压缩）。`backup_hermes.sh:129` 已加 `--exclude='*/cli-proxy-api'`、`--exclude='cli-proxy-api'`、`--exclude='*/CLIProxyAPI_*_linux_amd64.tar.gz'`，压到 **3.4M**，total 541.6M→454.7M，直接落回 512MiB 以内且空间需求降到 2.78GiB。**必须保留 `.cli-proxy-api/*.json`（OAuth 凭证）和 `cliproxyapi/config.yaml`**——二进制可重新下载，凭证丢了要重新授权。
- **改打包规则后要重生成已存在的包**：脚本改动只影响下一次运行；当天已生成的 `model_proxy.tar.gz` 仍是旧体积，`offsite_backup.py` 读的是磁盘文件，不重打包就照样超限。重生成后需同步 `UPLOAD_MANIFEST.json` 里对应条目的 `bytes`/`sha256`，否则清单与实际不符。
- **诊断顺序**：`tail jobs/unified-backup-daily/job.log` 看 `FAILED rc=` 与 traceback → 按 9 项算 total 并对照 512MiB → 按 `total*4+1G` 对照 `df` → `du -sh tmp/offsite-*` 找失败现场 → 查 `ls -lht vps-la:/opt/hermes-offsite-backups/aws/` 看是否有 `.part`。
- **私有镜像会过期**：`hermes-ops-private/projects/hermes-backup/backup_hermes.sh` 可能落后正式脚本很多（实测落后 155 行、缺锁与健康门禁）。改正式脚本后要 `cp` 同步镜像并核对 md5，别只改一处。
- **备份“卡死”先看内存守卫，不是 traceback**：`job-runner.sh:61` 执行前调 `memory-guard.sh wait`，默认 `MIN_RESUME_MB=550`、`MAX_WAIT_SEC=3600`。白天 available 只有 350–520MiB 时会一直刷 `MEM_GUARD_WAIT`，干等满 1 小时才 `exit 75`，日志里没有任何报错，极易误判成脚本挂死。手动验证用 `MIN_START_MB=330 MIN_RESUME_MB=330 job-runner.sh <job> <script>` 覆盖即可；实测 454MiB 就能跑通（tar/gzip 流式，峰值内存很低）。
- **当天失败必须当天重试，异地包事后补不了**：`package()` 需要 `hermes-*` 目录下 5 个文件，而 `hermes-*` 由 Hermes 自身轮转只留最新。某天的 unified 快照若当天没传成，次日 `hermes-<那天>` 已被清掉 → 该天异地包**永久缺失**，只能保住本地明文，无法补传。排查时先 `ls -1d backups/hermes-*` 确认源还在不在，再谈重传。
- **prune 会删掉唯一留存**：`backup_safety.py prune()` 用 `re.fullmatch(r'[0-9]{8}_[0-9]{6}')` 匹配目录名，删「非当前 + mtime>24h」。若某天异地包缺失，本地快照就是唯一副本，必须在下次备份前改名加后缀（如 `.keep-nooffsite`）让正则失配，否则下次备份成功后它会被当过期明文静默删掉。
- **完整链路成功基线（2026-10-20 实测）**：14:46:23→14:50:11 共 **3 分 48 秒**，密文 480MiB，跨境实测约 **2.1MB/s**（远高于历史 0.93MB/s），900s 下限余量充足；`retention` 会顺带删远端最旧包（本次删 10-16，保留 4 个）。验收判据看 `jobs/<job>/status` 的 `SUCCESS rc=0` + 远端包字节数与本地 `ciphertext_bytes` 完全一致 + `head -c 8` 为 `HERMES01`。

## 恢复边界

1. 确认日期、完整清单、源码/补丁和恢复私钥；先在私有临时目录解密检查，不覆盖生产。
2. 核对结构、外键、消息历史、两套 FTS 实际索引及官方延迟回填；仅 count 相等不足以通过。
3. 获准替换时停止全部持库进程，保存旧主库/WAL/SHM，再按审核后的离线方案恢复，保留回滚路径。
4. 启动后真实验证会话、模型路由与消息持久化；未测试不得宣称恢复完成。
5. 不改字面量、换路径或用包装/调度器绕过安全拒绝，采用已有授权的独立运维入口。

## 修改与回滚

修改正式脚本前先备份并跑隔离测试；兼容入口始终转发正式脚本。同步私有源码镜像并记录验证边界。回滚只恢复本次确认变更的文件，不覆盖其他并发修复。
