---
name: hermes-backup
description: "Backup Hermes: local snapshot + encrypted Telegram offsite."
version: 1.0.0
author: 柠檬
license: MIT
platforms: [linux]
metadata:
  hermes:
    tags: [backup, hermes, telegram, cron, sqlite, openssl]
---

# Hermes 备份与恢复

## 当前权威入口

- 正式脚本：`~/.hermes/scripts/backup_hermes.sh`；cron job `319e7f36295e` 调用此脚本。`~/bin/backup_hermes.sh` 只作兼容转发，不保存第二份实现。
- 先只读检查 cron、正式脚本、最近备份、恢复材料和上传清单；不得用历史描述替代实时状态。
- 2026-10-16 核对的计划为每日 `0 3 * * *`，下一次时间按 UTC 记录；03:00 UTC 为北京时间 11:00。改时间前核对任务时区和用户要求。
- 正式脚本会读取数据库、创建本地备份并向既有目标上传；只有请求授权备份/重试上传时才运行，不为“检查一下”发送 Telegram 文件。

## 内容与一致性

- 当前数据库清单：`state.db`、`kanban.db`、`response_store.db`、`verification_evidence.db`。
- 用 Hermes venv 的匹配 SQLite 环境与 backup API 包含已提交 WAL；不要在线裸拷主库。
- 健康门禁失败时保留现场报告，不关闭门禁、不把异常库写成健康备份。
- 私有数据包含配置、凭证、人设、memories/skills/cron/scripts/hooks 和正式脚本列出的恢复目录；恢复辅助包包含用户 bin 与用户级服务定义。
- 源码、二进制和缓存不在数据包中；完整恢复另核对 git 源码与生产补丁，不能仅因 data.tar.gz 存在就声称可完整恢复。
- 凭证、数据库、会话只留在受限私有备份，不得提交 Git 或放入公开技能包。

## 当前加密与异地验收

- 本地目录：`~/backups/hermes-<时间戳>/`；目录 700、敏感文件 600。保留策略以正式脚本和 backup_safety.py 为准。
- 当前异地文件为 CMS DER `.cms`，用 `~/.config/hermes-backup/recovery-cert.pem` 公钥证书加密；不能用旧 .enc + .backup_key 方法解密。
- 解密需要匹配的恢复私钥，公钥证书不能解密。私钥由所有者独立保管，不打印、不写入技能、不上传服务器或 Git。
- 上传以全部加密分片和最终清单完成为准，数量/哈希/大小须符合清单。单个分片或局部 ok 不等于完整异地备份。
- backup_upload_failed 等错误须分别报告本地与异地状态；只读核查日志、分片、目标限额/权限，再根据授权重试，失败不得标 SUCCESS。
- 实际解密、完整清单检查和隔离恢复都通过才算恢复验证；没有私钥或分片不全时明确标记未验证。

## 恢复边界

1. 确认日期、完整清单、源码/补丁和恢复私钥；先在私有临时目录解密检查，不覆盖生产。
2. 核对结构、外键、消息历史、两套 FTS 实际索引及官方延迟回填；仅 count 相等不足以通过。
3. 获准替换时停止全部持库进程，保存旧主库/WAL/SHM，再按审核后的离线方案恢复，保留回滚路径。
4. 启动后真实验证会话、模型路由与消息持久化；未测试不得宣称恢复完成。
5. 不改字面量、换路径或用包装/调度器绕过安全拒绝，采用已有授权的独立运维入口。

## 修改与回滚

修改正式脚本前先备份并跑隔离测试；兼容入口始终转发正式脚本。同步私有源码镜像并记录验证边界。回滚只恢复本次确认变更的文件，不覆盖其他并发修复。
