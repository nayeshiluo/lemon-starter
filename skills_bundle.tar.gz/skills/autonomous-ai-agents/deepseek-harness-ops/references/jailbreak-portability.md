# 把破甲搬到别的 agent 框架（可移植性判定）

用户问「这个破甲能放到 <另一个 bot 框架> 里面吗」时的判断框架。
本文件以 AstrBot（大肥鱼）为实测样例，方法适用于任何宿主迁移。

## 一、先拆成两层：宿主补丁 vs 提示词

破甲类插件通常做两件事，**可移植性完全不同**：

| 层 | 内容 | 能否移植 |
|---|---|---|
| 宿主补丁层 | 改宿主源码：审批门自动放行、沙箱策略、identity strip、shim 注入 | **不能**。强绑定宿主语言与包结构 |
| 提示词层 | 那段人格/越狱 system prompt | **能**。任何能写 system 的框架都能装 |

`dsh-purge` 的 66 个补丁全是 Node.js 侧改 `@deepseek-ai/*/lib/index.js`、`cordis.patch.yml`、
`/usr/local/bin/dsh` shim。AstrBot 是 Python 框架，两套宿主毫无交集，一个补丁都用不上。
**回答时必须先讲清这一点，否则用户会以为「装上插件就完事」。**

## 二、提示词层的三个拦路虎（按顺序查，任一个没解决就白搭）

### 1. 框架有没有地方放 system prompt

AstrBot：人格存在 SQLite，不在配置文件里。

```python
# /opt/astrbot/data/data_v4.db
#   personas: created_at, updated_at, id, persona_id, system_prompt,
#             begin_dialogs, tools, skills, custom_error_message, folder_id, sort_order
# 当前生效的是哪个：cmd_config.json → agent_runner.config.persona.persona_id
```

源码路径（uv 安装）：`<astrbot_pkg>/core/astr_main_agent.py`

```python
req.system_prompt += f"\n# Persona Instructions\n\n{prompt}\n"   # ~line 605
```

→ AstrBot 确实把 persona 作为 OpenAI `system` 角色发出去。机制上通。

### 2. provider 到底执不执行 system（**真正的拦路虎**）

大肥鱼 4 个 provider 全挂一个 source：

```
provider_sources: tengbaipiao → capy.<PRIVATE_IDENTIFIER>:2087
  kimi-k3-1 / cn-deepseek-v4.1-flash / cn-glm-5.3 / cn-kimi-k3.1-pro
agent_runner.config.model: provider_id=kimi-k3-1, fallback=[cn-deepseek-v4-1-flash]
```

腾白嫖实测 **D 探针 0/4，完全不执行 system**。提示词写得多狠都无效。
**这一步不过，后面全都不用谈** —— 先跑 `scripts/dshprobe.py` 的 D 探针。

### 3. 框架自己有没有往 system 里塞反向指令

AstrBot `agent_runner.config.persona`：

```json
{"persona_id": "ratman4080", "safety_mode": true, "safety_mode_strategy": "system_prompt"}
```

```python
def _apply_llm_safety_mode(config, req):
    if config.safety_mode_strategy == "system_prompt":
        req.system_prompt = f"{LLM_SAFETY_MODE_SYSTEM_PROMPT}\n\n{req.system_prompt}"
```

安全指令**拼在人格前面**，跟破甲提示词直接对冲。另外 `content_safety.internal_keywords.enable`
也默认开着。这两层不关，提示词再强也会被压回去。

## 三、读 AstrBot 配置的坑

- `data/cmd_config.json` **带 UTF-8 BOM**，`json.load()` 直接抛
  `Unexpected UTF-8 BOM`。必须 `io.open(p, encoding="utf-8-sig")`。
- 结构容易猜错：`provider` 是 **list** 不是 dict（每项只有
  `id/enable/type/model/provider_source_id`，**没有 base_url**）；真正的端点与 key 在
  `provider_sources` 里。`personas` 不在 cmd_config.json，在 `data_v4.db`。
- 机器上未必有 `sqlite3` CLI（exit 127），用 python `sqlite3` 模块读。

## 四、风险分级：实验机 ≠ 生产 bot

同样的破甲提示词，落在不同宿主上风险量级完全不同，必须分开说：

| 宿主 | 暴露面 | 风险 |
|---|---|---|
| 一次性实验沙箱 | 链接泄漏 → 别人白嫖一个不受限助手 | 中 |
| 生产 IM bot（AstrBot 等） | 群/白名单里任何人 → 拿到一台能执行命令的机器 | **高** |

AstrBot 的工具集含 `ExecuteShellTool` / `PythonTool` / `FileWriteTool` / `FileEditTool` /
`GrepTool`，且 `_apply_sandbox_tools` 会把它们全挂上。破甲 + 这些工具 = 任何人都能让它跑命令。

**所以：不擅自改生产 bot。** 给出分步方案让用户决策，第一步只动 provider + safety_mode，
保留原人格不动，看效果；提示词那步单独再定。

## 五、回答这类问题的结构

1. **结论先行**：插件不能装 / 提示词能搬 / 但现在搬了也无效
2. **逐层拆**：宿主补丁层（不可移植）→ 提示词层（可移植）→ provider（当前阻塞）
3. **给证据**：D 探针数字、源码行号、配置文件实际值，别只说「大概不行」
4. **给方案**：要改哪几处，按风险从小到大排序
5. **把风险讲成对比**，不是一句「有风险」——用户才知道量级差在哪
6. **不擅自动生产**，问一句再执行
