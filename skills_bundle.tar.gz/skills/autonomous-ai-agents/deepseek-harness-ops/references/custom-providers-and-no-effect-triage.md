# 「插件装了但没效果」的分层诊断（dsh + 破甲类插件）

2026-10-29 在 InstaBox 沙箱（dsh 0.2.1-rc.2 + dsh-purge 1.1.82）实测。
接自定义模型 provider（`llm-pi-ai` 路由、key 走 EnvironmentFile）的配置写法见
`custom-model-providers.md`，本文件只管**诊断**。

用户说「破甲无效 / 用不了 / 是不是我用法有问题」时，**先分清是 harness 层没生效，还是模型自己拒绝**。
别一上来改提示词，也别把「模型拒绝」写成「插件没装上」。

## 阶梯（按顺序查，每步都要硬证据）

1. **补丁层**
   ```bash
   sudo -n env DSH_HOME=$DSH_HOME node <plugin>/bin/<cli>.js --status | grep -c '✓'   # 实测 66
   sudo -n env DSH_HOME=$DSH_HOME node <plugin>/bin/<cli>.js --status | grep -E 'APPROVAL|SANDBOX'
   ```
   关键项 `#5 APPROVAL_NEVER_SENTENCE`、`#6 SANDBOX_DENY_FILE_WRITE`、`#7 SANDBOX_MODE_DEFAULT`、
   `#8 APPROVAL_POLICY_DEFAULT`、`#9 APPROVAL_AUTO_GRANT` 应为 applied。

2. **注入是否进了系统提示词** —— 读会话记录，看 `system/message` 的长度与注入标记（见下节）。

3. **运行时策略是否真放开** —— 会话里的 runtime-context 快照会明写：
   `Current DSH file policy: danger-full-access`、
   `Approval requests are auto-granted in this session (approval bypass, approval policy: never)`。
   这两句在，说明补丁在运行时确实生效。

4. **上游有没有报错** —— 看 `assistant/attempt` 的 finish reason 与 `llm/retry` 的 failure。
   实测撞到中转站 `503 {"code":"no_healthy_account","gateway_hint":"no healthy account available in pool"}`，
   重试 3 次全挂。**这类是瞬时故障**：隔几分钟用同一个 curl 复测全部 200 就证明了。
   别把它写成「这个 provider 不可用」——下次会被自己的记录误导。

5. **模型是否自己拒答** —— 读 `assistant/message` 的 reasoning 段。实测原文：
   > This is a request for pornographic content. I should decline. My guidelines prohibit...
   > **there's no safety policy layer in the environment that would force this — I just decline.**

   → harness 层全放开了（审批、沙箱、提示词注入都在），拒绝来自模型自身对齐。
   这时结论是「插件工作正常，是模型层不配合」，不是「破甲无效」。

## 读会话记录（关键技巧）

位置：`$DSH_HOME/sessions/<cwd-slug>/session-<uuid>/session.v4.jsonl.zstd`

**这个文件是多帧 zstd 追加**。`zlib.zstdDecompressSync()` 只解第一帧——那条 200 字节左右的
session header，`records` 只有 1 条，会让人误判「用户根本没发消息 / 会话是空的」。
必须按 magic `0x28 B5 2F FD` 切帧逐帧解。

直接跑 `scripts/read-dsh-session.js`：

```bash
scp scripts/read-dsh-session.js <host>:/tmp/
ssh -n <host> 'node /tmp/read-dsh-session.js --home /data/workspace/.dsh'
```

输出：记录类型统计、system prompt 字符数、注入标记是否命中、provider/model、
失败的 attempt 及其 error、模型 reasoning/text 摘要。

真实样本（供对照）：31 帧 / 31 条记录；`system/message` 28073 字符且含 `UNRESTRICTED`；
`request/header` 指向 `tengbaipiao / cn:deepseek-v4.1-flash`；`assistant/attempt` ×3 全 503；
最后的 `assistant/message` reasoning 明写「我应该拒绝」。

其它：
- `ssh` 一律加 `-n`，否则远端读日志/等 stdin 会把整条命令挂到超时。
- 会话目录名是 cwd 的 slug（如 `--data-home-Desktop-120--`），换工作区就换目录。
- 机器上通常没有 `zstd` CLI、Python 也没有 `zstandard` 模块；用 node（22.15+ 自带
  `zlib.zstdDecompressSync`）最省事，脚本就是这条路。

## 结论怎么写给用户

分开讲两件事，别混成「装失败了」：

- **harness 层**：补丁计数、系统提示词长度/注入标记、runtime-context 原文——都有据可查。
- **模型层**：默认提示词面向某个特定模型人格，换模型就得换提示词；不同模型对齐强度差别很大，
  同一句话换个模型就能看出差别。提示词入口是 `$DSH_HOME/prompt-inject.md`，改完**必须重新 apply** 才生效。

另：注入文件开头常带 `<|im_start|>system:<project_instructions>` 这类 chat-template 标记，
塞进 system 段对非原生模型是噪音、会削弱效果——可以客观指出，但**不要替用户写越狱提示词内容**。
