# dsh web 反代到公网后的认证：为什么「自动登录」会把人坑死

场景：`dsh web` 绑 `127.0.0.1:8099`，Caddy 反代到 `https://dsh.example.com`。
用户手机（iOS Safari）反馈「网站打不开」，实际现象是白屏，并弹出 `_.txt` 下载。

本文记的是三次尝试的完整结果，**前两次都是错的、都上线过、都被用户打回**。别重复。

---

## 一、dsh 的认证模型（读源码得到，不是猜的）

`node_modules/@deepseek-ai/dsh-client-connection/lib/index.js`：

```js
const COOKIE_PREFIX = "dsh-auth-";
const COOKIE_PAYLOAD_VERSION = 1;
const SECRET_BYTES = 32;

function requestAudience(headers, secure) {
    const host = header(headers, "host");
    const url = new URL(`${secure ? "https:" : "http:"}//${host}`);
    return secure ? url.origin : url.host;   // ← 明文监听器只给 host，不带 scheme
}

function cookieName(authority) {
    return COOKIE_PREFIX + encodeBase64Url(createHash("sha256").update(authority).digest());
}

function sessionCookie(name, value, expiresAt, maxAgeSeconds, secure) {
    const attributes = `${name}=${value}; Max-Age=...; Path=/; Expires=...; HttpOnly; SameSite=Strict`;
    return secure ? `${attributes}; Secure` : attributes;
}
```

认证流程：

1. `GET /?token=<launchToken>` → 校验通过 → **303** + `set-cookie: dsh-auth-<43字符>=v1.<body>.<sig>`
2. 浏览器存 cookie → `GET /` 带 cookie → `isAuthenticated()` 为真 → 200 index.html
3. 裸域名无 cookie → **401**，body 是 `text/plain` 的 `dsh web authentication required; ...`

`authenticate()` 的硬校验（写 cookie 时最容易踩）：

```js
if (payload.expiresAt - payload.issuedAt > this.maxAgeMilliseconds) return void 0;
```

`maxAgeMilliseconds` 默认 **30 天**。自己签 cookie 时给 10 年 → **401**，且没有任何提示。

---

## 二、错误尝试 1：Caddy 302 自动登录（上线后被用户打回）

```caddyfile
@needlogin {
    not header_regexp Cookie dsh-auth-
    not query token=*
}
redir @needlogin /?token=<当前token> 302
```

意图：裸域名自动跳到带 token 的地址，用户只记短地址。

**结果：iPhone Safari 报 `ERR_TOO_MANY_REDIRECTS`。**

原因：Safari 在 3xx 响应里设置的 cookie 不可靠 —— 拿到 303 的 `set-cookie` 后
跟跳回 `/`，cookie 没存上 → 再命中 `@needlogin` → 再 302 → 死循环。

`curl -sL` 复测是 `redirects=1 final=200`，**看起来完全正常**。
curl 不模拟 Safari 的 cookie 存储策略，所以命令行测通过不能证明手机能开。
这是本类问题最贵的教训：**验收必须用 Safari UA + 真实跳转链，不能只信 curl。**

---

## 三、错误尝试 2：改成服务端 rewrite（上线后仍然打回）

```caddyfile
@needlogin {
    not header Cookie *dsh-auth-*
    path /
}
rewrite @needlogin /?token=<当前token>
```

意图：内部改写 URI，不产生浏览器级跳转，绕开 303 循环。

curl 复测：首次 `redirects=1 final=200`，第二次 `redirects=0 final=200`，全绿。

**结果：用户手机白屏 + 弹 `_.txt` 下载。**

原因没变 —— 根子不在跳转次数，在 **Safari 就是不肯把 303 里的 `set-cookie` 落盘**。
没有 cookie 就永远走 401/303 分支；Safari 反复重试后把最后一个 `text/plain` 响应当文件下载，
文件名显示成 `_.txt`（iOS 的兜底命名）。所以：

- 白屏 = 拿不到 index.html
- `_.txt` 下载 = 兜底的 401 纯文本响应被当成附件
- `ERR_TOO_MANY_REDIRECTS` 和「白屏 + 下载」是**同一个根因的两种表现**

**判断信号**：用户发来截图里有「下载触发者：<你的域名>」+ 一个 `.txt` 文件，
就直接跳到本文第四节，别再调跳转规则。

---

## 四、正确解法：Caddy 直接注入会话 cookie

思路：不让浏览器参与认证。Caddy 对每个转发请求硬塞一个自己签好的有效 cookie，
dsh 认为已登录、直接回 200；顺手再用 `header_down` 给浏览器种一份（浏览器存不存都无所谓）。

### 1) 从 DSH_HOME 取 secret

```bash
grep -A3 "browser-session" $DSH_HOME/.credentials.yaml
#   client-connection/browser-session:
#     kind: grant
#     secret: <43 字符 base64url，解码后 32 字节>
```

### 2) 签一个 cookie

用 `scripts/gen-dsh-session-cookie.mjs`（同目录）：

```bash
DSH_HOME=/home/ubuntu/.dsh-lab \
DSH_AUTHORITY=dsh.example.com \
node scripts/gen-dsh-session-cookie.mjs
# NAME=dsh-auth-<43字符>
# VALUE=v1.<body>.<sig>
# COOKIE=dsh-auth-<43字符>=v1.<body>.<sig>
```

要点：

- `authority` 用**域名 host**（`dsh.example.com`），因为 dsh 自己监听的是明文 HTTP，
  `requestAudience()` 走 `url.host` 分支，不含 `https://`
- 有效期 **≤ 30 天**，脚本默认 29
- 生成的 cookie 名应与 dsh 自己 set 的那条**逐字符一致**，不一致就是 authority 算错了

先单测 cookie 有效再改 Caddy：

```bash
C=$(DSH_HOME=... DSH_AUTHORITY=... node scripts/gen-dsh-session-cookie.mjs | grep '^COOKIE=' | cut -d= -f2-)
curl -s -D - -o /tmp/p.html -H "Cookie: $C" "https://dsh.example.com/" | head -1   # 期望 200
grep -oE "<title>[^<]*</title>" /tmp/p.html                                        # DeepSeek Harness
```

### 3) 写进 Caddy

**`header_up` / `header_down` 必须写在 `reverse_proxy {}` 块里**，写在站点块层级会报
`unrecognized directive: header_up` 且 `caddy validate` 失败：

```caddyfile
dsh.example.com {
    header Strict-Transport-Security "max-age=<YOUR_USER_IDENTIFIER>"

    reverse_proxy 127.0.0.1:8099 {
        header_up Cookie "dsh-auth-<43字符>=v1.<body>.<sig>"
        header_down +Set-Cookie "dsh-auth-<43字符>=v1.<body>.<sig>; Max-Age=2419200; Path=/; HttpOnly; SameSite=Lax"
    }
}
```

- `header_up Cookie` 会**覆盖**浏览器带来的所有 cookie（这里没有别的 cookie，可接受）
- `header_down` 里用 `SameSite=Lax` 而不是 `Strict`，给浏览器存的那份更宽容
- 原来那些 `@needlogin` / `redir` / `rewrite` 规则**全部删掉**，不再需要

### 4) 验收矩阵（缺一条都不算通）

```bash
sudo -n caddy validate --config /etc/caddy/Caddyfile     # PASS
sudo -n systemctl restart caddy && systemctl is-active caddy

curl -sL --max-redirs 3 -o /dev/null -w 'bare %{http_code} r=%{num_redirects}\n' \
  "https://dsh.example.com/"                              # 200 r=0  ← 关键：0 跳转
curl -sL --max-redirs 3 -o /dev/null -w 'safari %{http_code} r=%{num_redirects}\n' \
  -A "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1" \
  "https://dsh.example.com/"                              # 200 r=0
curl -s -o /dev/null -w '%{http_code} %{size_download}\n' \
  "https://dsh.example.com/assets/index-*.js"             # 200，体积是 MB 级
for h in <同域其他子域...>; do
  curl -s -o /dev/null -w "$h %{http_code}\n" "https://$h/"   # 回归，别搞坏别的站点
done
```

`redirects=0` 是这次修复的核心指标 —— 一次请求直接 200，没有任何跳转。

### 5) 29 天会过期 → 定时续

cookie 有 29 天寿命，到期又变 401。加一条周任务重新签 + reload：

```bash
0 3 * * 0 /path/refresh_dsh_cookie.sh
```

脚本内容 = 重新跑 `gen-dsh-session-cookie.mjs` → 重写 Caddyfile 里那两行 →
`caddy validate` 通过才 `systemctl restart caddy`（`admin off` 只能 restart，约 3s）。

---

## 五、代价与安全边界（必须主动告诉用户）

这套做法等于**把认证关掉了**：

- 任何知道域名的人都能直接进，不需要密码
- 所有人共用同一个会话身份（Caddy 注入的是同一个 cookie）
- `header_up Cookie` 覆盖浏览器 cookie，用户自己的登录态被忽略

对「自己一个人用的实验机」可接受；对外或多人使用必须再加一层
Caddy `basic_auth` 或 IP 限制。**交付时要把这句说出来，不要等用户问。**

---

## 六、回滚

```bash
sudo -n cp /etc/caddy/Caddyfile.bak-<改动前> /etc/caddy/Caddyfile
sudo -n systemctl restart caddy
```

Caddyfile 每次改动前都 `cp` 一份带时间戳的备份 —— `admin off` 时没有 `caddy reload` 的
原子回退，只能靠文件备份。

---

## 七、一句话总结

> dsh 的 web 认证是「303 种 cookie」模型，Safari 在 303 里丢 cookie。
> 修跳转规则是死路（试了 302 和 rewrite，都被打回）。
> 正解是反代层签一个 cookie 用 `header_up` 注入，浏览器完全不参与。
> 验收看 `redirects=0`，不看 `final=200`。
