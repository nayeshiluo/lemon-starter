# InstaBox 沙箱 provisioning（多账号 + 端口发布实测）

2026-10-29 实测。用户给了**第二个 InstaBox 账号**的 API key，要给它名下的机器接保活并发布 dsh 实验环境。
（主账号相关基础事实仍以 `instabox-node-ops` 为准，本文件只记多账号与端口两块的增量。）

## 一、多账号：保活守护要按账号拆实例

Activity lease 接口是**按 API key 的 org 隔离**的：`GET /v1/machines` 只返回该 key 名下机器。
所以两个账号不能共用一个守护进程，否则第二个账号的机器永远拿不到租约。

做法：把 key 路径、日志、leaseID 全部环境变量化，同一个脚本跑两个 systemd 实例。

```ini
# /etc/systemd/system/instabox-lease-lab.service
[Service]
Environment=KEYFILE=/etc/instabox-lab/api.key
Environment=LOG=/var/log/instabox-lease-lab.log
Environment=LEASE=lemon-lab-keepalive
Environment=TTL=1800
Environment=INTERVAL=600
ExecStart=/usr/local/bin/instabox-lease-multi.sh
Restart=always
```

安装要点：

- key 单独落 `/etc/instabox-lab/api.key`，`600 root:root`，目录 `750`，**不写进脚本正文**
- 上传后立刻 `rm -f /tmp/ibk-lab.key`
- 两个实例的 `LEASE` 名必须不同（同名不同 key 虽然不会互相覆盖，但日志/排障会混）
- 原有账号的 `instabox-lease.service` 不动

验收（实测输出）：

```
2026-10-29 12:57:25+0000 start pid=... ttl=1800s interval=600s lease=lemon-lab-keepalive
2026-10-29 12:57:25+0000 OK m_agqx7prvqwd5m7kxusega2slay state=running maxrun=480m expires=2026-10-29T13:27:25Z
```

多账号版脚本见本技能 `scripts/instabox_lease_multi.sh`。

## 二、新建机器（可选字段很好用）

```bash
curl -sS -X POST https://api.instabox.sh/v1/machines \
 -H "X-API-Key: $KEY" -H "Content-Type: application/json" \
 -H "Idempotency-Key: lab-$(date +%s)" \
 -d '{"name":"dsh-purge-lab","deleteAfterSeconds":86400}'
```

- 返回 `{id: "op_...", machineId: "m_...", state: "queued"}`，是**异步 operation**，几秒后 `GET /v1/machines/{id}` 变 `running`
- 不传 `templateId` 时默认 `agent-browser`（自带 node 22 / chromium / Xvfb / xdotool）
- 默认规格：4 vCPU / 8192 MiB / 系统盘 16G / 持久盘 20G
- **`deleteAfterSeconds`（60–86400）很适合实验机**：到期自动删除，不怕忘记清理。`archiveSeconds` 是到点停止（更温和）
- 免费档仍是 `maxRunMinutes=480`（8h 硬断 + ~10min 冷却），`autoSuspendAfterSeconds=1800`

## 三、SSH：面板 token 不可用时自己签

`GET /v1/machines/{id}/connection-info` 的 `username` 是**机器 ID**，不是登录名。登录名来自 SSH token。

实测：面板里已存在的 token（名为「2号」）直接 `Permission denied (publickey)`，而机器 `state=running`、`runtime.ready=true`、`ssh-tokens` 列表非空。**这是凭据问题，不是机器没起来。**

```bash
curl -sS -X POST -H "X-API-Key: $KEY" -H "Content-Type: application/json" \
  -H "Idempotency-Key: tok-$(date +%s)" -d '{"name":"hermes-lab"}' \
  https://api.instabox.sh/v1/machines/<machineId>/ssh-tokens
```

返回里直接给 `token`、`command`、`expiresAt`（约 7 天）。新签的立即可用。

> 提醒用户：面板里那个连不上的旧 token 建议删掉重建，否则下次还会踩。

## 四、端口发布：public / private 与双 token 拼接

```bash
curl -sS -X POST -H "X-API-Key: $KEY" -H "Content-Type: application/json" \
 -H "Idempotency-Key: pub-$(date +%s)" \
 -d '{"port":8080,"protocol":"http","access":"private","name":"dsh"}' \
 https://api.instabox.sh/v1/machines/<machineId>/ports
```

响应：

```json
{"id":"pv-...","url":"https://8080-<machineId>.instabox.tech",
 "access":"private","token":"ibp_...",
 "tokenUrl":"https://8080-<machineId>.instabox.tech/?_token=ibp_..."}
```

- `access=private` 时无 `_token` 请求返回 **401**，带 `_token` 返回 **303** 并设 cookie，之后 cookie 生效
- 上游应用自带 token 门（dsh web 的 `?token=`）→ 拼成一个 URL：
  `https://8080-<id>.instabox.tech/?_token=ibp_xxx&token=<上游token>`
  实测 `curl -L` 一次走通：303 → 重定向 → **200 / 37889 字节 / `<title>DeepSeek Harness</title>`**
- 旧账号的机器用的是 `access=public`（`expiresAt: null`，URL 永久、无认证），所以用户习惯了"直接点链接"
- 改 access 或轮换 token 会换 `id`，**URL 不变**
- 保留端口：桌面 5901、Orca 6768；`protocol:"tcp"` 付费档且不能 private

## 五、判断"要不要开隧道"的正确姿势

先查既有机器怎么用的：

```bash
curl -sS -H "X-API-Key: $KEY" https://api.instabox.sh/v1/machines/<id>/ports
```

看到 `access:"public"` + `expiresAt:null` 就说明这个环境一直是**直连浏览器**的。
此时再给新机器"只绑 127.0.0.1 + 你自己 SSH 转发"，等于凭空多两步，用户会直接质疑。
默认给 private 端口 + 可直接点的链接；隧道只在平台不给端口映射时才用。
