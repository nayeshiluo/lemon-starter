# 把 dsh 当聊天后端：headless 前端桥接（2026-10 实测）

场景：用户已有跑通的 dsh（含破甲类插件），要求「用 Telegram / 别的 IM 和它对话，能切模型」。
不是在宿主里再写一套聊天，而是**把 dsh headless 当成一次性问答进程**来调用。

## 一、headless profile 的补丁层是独立的 ⚠️

`profiles/web/cordis.patch.yml` 里加的 provider 路由，**headless 完全不认**：

```
dsh: NO_ADAPTER: no adapter registered for provider "honghong2"
```

`--dump-config` 对比即可确认：web 有 `honghong2`，headless 没有。两种修法：

- 把路由写进 `profiles/headless/cordis.patch.yml` 的 `llm-pi-ai.config.providers`（持久，适合固定集合）
- 或每次运行用 `--patch <overlay.yml>` 覆盖（适合按请求切模型，见下节）

### 抄路由别只抄 baseURL —— `UNKNOWN_MODEL`

路由补上、models 列表没补，报的是另一条错：

```
dsh: UNKNOWN_MODEL: pi-ai provider "newfou" has no configured model "gpt-5.6-luna"
```

`NO_ADAPTER` = 路由 key 不在；`UNKNOWN_MODEL` = 路由在但 `models[].id` 里没这个模型。
**从 web 抄到 headless 时，`baseURL` / `apiKeyEnv` / `models` 三样要一起搬。**

同样地，**换掉一个站点的模型集合后，每个 profile 都要各自更新一遍**（本会话只改了 web，
headless 立刻撞 `UNKNOWN_MODEL`）。改完用 `--dump-config | grep -A10 '<route>:'` 逐 profile 核。

## 二、headless 不读 web 服务的 EnvironmentFile ⚠️

web 的凭据来自 systemd unit 的 `EnvironmentFile=.../lab-providers.env`；headless 是前台进程，**不会**加载它：

```
dsh: MISSING_CREDENTIAL: llm-pi-ai: no credential for provider route "newfou";
its profile resolves NEWFOUAPI_API_KEY, which is not set
```

桥接脚本里必须先 `set -a; . <envfile>; set +a`，或直接 export 本次要用的 key。

另外默认模型可能被中转站 ACL 拒（`token_acl_error: 当前 API Key 无权访问模型 'xxx'`）——
这不是链接坏了，是 key 与模型不匹配，换模型或换 key。

## 三、按请求切模型：`--patch` overlay

`agent-default-model` 是配置项，没有 `--model` 参数。要每次换模型，就生成一个 overlay：

```yaml
- id: llm-pi-ai
  name: "@deepseek-ai/dsh-llm-pi-ai"
  config:
    providers:
      sel:                      # 路由 key 自定，小写连字符最稳
        displayName: 哄哄2
        api: openai-completions
        baseURL: http://host:3001/v1
        apiKeyEnv: POJAI_SEL_KEY  # 名字自定，由调用方 export
        headers:                  # ⚠️ 套 Cloudflare 的站缺这行会整站 403
          User-Agent: Mozilla/5.0
        models:
          - id: gpt-6.1-sol
            name: gpt-6.1-sol
- id: agent-default-model
  name: "@deepseek-ai/dsh-agent-default-model"
  config:
    provider: sel
    model: gpt-6.1-sol
```

### ⚠️ overlay 必须透传站点的 `extra_headers`

2026-11-06 实测：把默认站换成 Command Code 后 Bot 全哑，而 Hermes 里同 key 同模型好用。
原因是 overlay 只写了 `baseURL` / `apiKeyEnv` / `models`，**没带 UA**，Cloudflare 对 dsh 的
Node 默认 UA 直接回 `403 error code: 1010`。生成 overlay 的代码要从 provider 配置读
`extra_headers` 原样写进 `headers:`，不要硬编码端点或漏掉这一项。

同理，`models` 是**整体替换**该 route 的目录：塞全量模型能做出好看的二级菜单，但菜单里会
出现没实测过的模型，对用户要说明「菜单数量 > 已验证可用数量」。

`--patch` 的 config 覆盖是按 entry id 定位的；overlay 里只写 `sel` 一条路由即可，
不必重复基础层那堆 provider（但**别指望它合并**——要用别的路由就在 overlay 里列全）。

## 四、`--json` 事件流（解析答案与会话）

```bash
dsh --profile headless --json -        # task 从 stdin 读，避免引号地狱
```

逐行 JSON：

| type | 关键字段 | 用途 |
|---|---|---|
| `session` | `sessionId`, `cwd` | 首轮拿到会话 id，后续续聊 |
| `text` | `text` | 增量正文（可能多次） |
| `status` | `phase`, `turn`, `usage` | turn_start/step_end/turn_end |
| `final` | `text` | 完整答案，**以它为准** |
| `error` | `message` | 失败原因 |

续聊：`--session-id session-...`。**未知 id 直接报错**，所以第一轮必须不带 id，从 `session` 事件里取。
用户点「新对话」= 丢掉 id 重新开一轮。

## 五、跨机桥接（Bot 在常驻机、dsh 在沙箱机）

```python
script = "\n".join([
  "set -e",
  "export DSH_HOME=/data/workspace/.dsh",
  "export POJAI_SEL_KEY=" + shlex.quote(key),   # key 只进脚本，不进 argv、不落盘
  "cat > <overlay> <<'EOF'", body, "EOF",
  "cd /data/workspace",
  "printf '%s' " + shlex.quote(b64(task)) + " | base64 -d | dsh --profile headless --patch <overlay> --json -",
]) + "\n"
proc = await asyncio.create_subprocess_exec("ssh", host, "bash -s",
        stdin=PIPE, stdout=PIPE, stderr=PIPE)
out, err = await asyncio.wait_for(proc.communicate(script.encode()), 300)
```

要点：
- **`ssh -n` 会吞 stdin**，喂脚本时绝对不能加 `-n`（`-n` 只用于纯读日志）。
- 任务正文 base64 后嵌入，避开多层引号与中文标点。
- 取消（用户点「停止」）时 `proc.kill()`；超时也 kill，别留僵尸 ssh。
- 每条消息起一个 node 进程，首字延迟明显高于直连 API——这是 headless 模式的固有代价。
- overlay 文件名用「站点名 + overlay 内容」的 sha256 前 16 位，同配置复用同一文件，天然幂等。
- `dsh --help` 是**启动器**帮助（`--profile/--patch/--dump-config`），app 自己的参数在
  `dsh --profile <name> --help`；两者混看会以为没有 `--json`。
- stdout 为空时，真错误在 **stderr 最后一行**（`dsh: MISSING_CREDENTIAL …` / `dsh: AUTH: 403 …`），
  把它截进日志再抛错，别只报「未返回回答」。

## 五之二、验收阶梯（缺一层都不算成）

1. 机器上裸跑：`dsh --profile headless --patch <overlay> "只回复四个字：链路可用"`
2. `--json` 能取到 `final.text` 与 `sessionId`
3. 第二轮带 `--session-id` 追问上一轮内容，确认记忆真的在
4. **从 Bot 进程内**（不是交互 shell）再跑一次——环境变量、工作目录、ssh 免密都可能不同
5. 最后才 `systemctl restart` 并看 `is-active` + journal 首行 `Bot started`

## 六、两个必须对用户讲明的风险

1. **headless 带工具**：agent 默认具备执行/写文件能力。把 IM 入口接到 headless，等于给聊天开了一个沙箱 shell。
   至少限制为 owner 私聊白名单，并明确告知。
   **别只看配置断言「无工具」** —— 读会话存档的 `request/header.tools[]` 才算验收：
   `node scripts/dsh-session-frames.js <session.v4.jsonl.zstd> --tools`，为空才是真无工具。
2. **别把生产前端挂在会休眠的沙箱机上**（InstaBox 等）：机器睡着时所有消息失败。
   要么迁到常驻机，要么接受「随时可能不通」。

## 七、Telegram 按钮颜色：官方支持 `style`

`InlineKeyboardButton` 与 `ReplyKeyboardButton` 都有 `style` 字段：
`danger`(红) / `success`(绿) / `primary`(蓝)，省略则用客户端默认样式。
（2026-10 核对 core.telegram.org/bots/api 正文；不要凭记忆说「按钮不能染色」。）

## 八、部署验收纪律（本次踩到的真实事故）

派子代理去部署，子代理在 199s 时**静默中断、零产物**，主会话却继续对用户说「正在部署」，
用户直接质问「你到底装了什么」。教训：

- 派活后必须看 `cache/delegation/live/<id>/task-*.log`，**看到 `status=interrupted` 就当场改口**。
- 汇报前先查硬证据：`systemctl is-active`、目标目录里有没有代码文件、进程在不在。
- 需求本身也要先对齐：用户说「接破甲」= 要 dsh 前端，不是另写一个直连模型的聊天 Bot。
  先确认交付物，再动手；做错方向比做慢更贵。

## 九、「试了，好像没破甲」怎么归因（三层，别混成一句）

链路跑通后用户反馈「没效果」，先分层取证再回话。本会话同一 Bot 连试三次的真实样本：

| 现象 | 归因层 | 结论 |
|---|---|---|
| `403 token_acl_error: 无权访问模型 'xxx'` ×2 | 链路层 | key 对那几个模型没授权，换模型即可 |
| `session_blocked_by_cyber_policy: 该会话已被网络安全策略屏蔽` | **上游层** | 模型站自己的内容策略拦的，跟本地配置无关 |
| 会话存档 `system/message` 10678 字符、开头 `You are <人格名>` | harness 层 | 注入正常，补丁在生效 |

取证命令（都在 dsh 机上）：

```bash
# harness 层：人格到底进没进 system
node scripts/read-dsh-session.js --home $DSH_HOME
head -c 300 $DSH_HOME/prompt-inject.md      # 取人格开场词，比对 system 首段

# 链路/上游层：Bot 侧日志里 dsh 的 stderr 末行
journalctl -u <bot-service> --since '-40min' | grep -i 'dsh returned no answer'
```

**给用户的正确说法**：harness 层正常 → 拦截发生在上游站方策略。不要说成「插件没装上」
「Bot 接错了」，也不要因为连通性测试通过就暗示内容策略能过 —— 两者是两道门。

⚠️ `read-dsh-session.js` 的注入判定是**关键词**匹配（`UNRESTRICTED|dsh-purge|MODE:`）。
dsh-purge 走 `prompt-inject.md` 注入人格时，system 里可能只有人格开场、没有这些字样，
**关键词不命中 ≠ 没注入**。判「NO」时先把人格开头几个词加进正则再复核。

