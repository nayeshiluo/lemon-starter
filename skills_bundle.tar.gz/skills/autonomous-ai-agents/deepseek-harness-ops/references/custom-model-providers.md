# dsh 接入第三方 OpenAI 兼容模型（llm-pi-ai 路由）

场景：dsh 装好后网页能打开，但一说话就 `MISSING_CREDENTIAL` / 模型选择器空。
原因不是链接坏了——`DSH_HOME/.credentials.yaml` 里只有 `client-connection/browser-session`
（网页登录态），没有任何 LLM 凭据。dsh 在凭据缺失时模型目录返回空，界面上就没有可选模型。

两条路：
- **A（最省事，推荐给用户）**：网页 设置 → Models → DeepSeek 卡片填 API key；中转站走
  「添加模型提供商 → 自定义模型 API」（Provider ID / 端点 / 协议：OpenAI Chat Completions、
  OpenAI Responses、Anthropic Messages / 至少一个模型 ID）。key 只写不读回，不经过聊天。
- **B（代用户配好，本文件重点）**：写进 profile 的 `cordis.patch.yml`。

## 一、路由声明写在哪

profile 的 patch 层是顶层 YAML 数组，**id 定位覆盖**（不是 `insert`）：

```yaml
- id: llm-pi-ai                 # entry id，不是包名
  config:
    providers:
      <route-key>:
        displayName: 周三
        api: openai-completions   # 目录外的路由必须显式给协议
        baseURL: https://host/v1
        apiKeyEnv: ZHOUSAN_API_KEY
        headers:
          User-Agent: Mozilla/5.0 (...) Chrome/<YOUR_SERVER_IP> Safari/537.36
        models:
          - id: Deepseek v4.1 Flash   # id 可以是带空格/冒号的原始请求 id
            name: Deepseek v4.1 Flash
```

- entry id 先用 `dsh --profile web --dump-config | grep -n 'pi-ai'` 查（实测 `llm-pi-ai`）。
  注意 `--dump-config` **必须带 `--profile`**，否则 `error: --profile <name> is required`。
- `api` / `baseURL` / 非空 `models` 是自定义路由的硬性三件套，缺一个保存处就拒绝。
- `models` 整体替换路由目录；`modelOverrides` 只改个别模型。带空格的中转站模型名原样写进 `id`。
- 有的中转站（如套 CF 的 NewAPI）**必须带浏览器 User-Agent**，缺了直接拒。这类头写在
  路由 `headers` 里，同时 curl 测试也要带，否则测试结果不能代表 dsh 里的结果。

## 二、key 怎么给（不要写进 patch 文件）

`apiKeyEnv` 是按请求解析的凭据引用，配置文件里只有变量名。落地用 systemd：

```bash
install -m 600 /tmp/lab-providers.env /data/workspace/.dsh/lab-providers.env
# unit 里加一行（放在 Environment=DSH_HOME=... 后面）
EnvironmentFile=/data/workspace/.dsh/lab-providers.env
systemctl --user daemon-reload && systemctl --user restart dsh-web
```

env 文件格式 `ZHOUSAN_API_KEY=xxx`，属主 600。本地生成后立刻删掉中转副本。
provider 的 route key 用小写连字符（`zhousan`），大写/下划线的手工路由无法走 pi-ai 登录流程。

## 三、验收（三层，缺一层都不算成）

```bash
# 1) 配置真的注入了
DSH_HOME=... dsh --profile web --dump-config | grep -A6 'id: llm-pi-ai'

# 2) 端点 + key 真的能用（从机器上测，不是本地）
set -a; . $DSH_HOME/lab-providers.env; set +a
curl -sS -o /dev/null -w '%{http_code}\n' -H "Authorization: Bearer $KEY" $BASE/models
curl -sS -H "Authorization: Bearer $KEY" -H 'Content-Type: application/json' \
  -d '{"model":"<id>","messages":[{"role":"user","content":"hi"}],"max_tokens":20}' \
  $BASE/chat/completions

# 3) 服务活着 + 新 token
systemctl --user is-active dsh-web && dsh-url
```

`max_tokens` 给小了会看到 `content` 为空、`reasoning_content` 被 `finish_reason: length` 截断——
这是正常现象，不是接口不通，别误判。

## 四、dsh-purge 的 net-scope 会不会拦住模型请求

不会。`lib/net-scope.js` 的 `installRegionGate()` 只挂两个钩子：`agent/pre-step` 与
`tools/pre-execute`，只在识别为攻击/红队/作弊任务时拦公网目标。LLM 出站请求不走工具钩子，
配公网 baseURL 照常可用。别因为「插件宣称只允许内网」就认为中转站接不进去——去看钩子挂在哪。

## 五、回滚

`cp cordis.patch.yml cordis.patch.yml.providers.bak` 先备份；删除那个 `- id: llm-pi-ai` 块
+ 去掉 unit 里的 `EnvironmentFile` + 删 env 文件，重启即恢复原状。
patch 块要幂等：重跑脚本前先用正则把旧块剥掉，否则会叠加两份 providers 配置。
