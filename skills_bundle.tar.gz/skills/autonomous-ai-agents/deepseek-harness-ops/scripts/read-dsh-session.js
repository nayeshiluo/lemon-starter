#!/usr/bin/env node
/*
 * 读 dsh 会话记录，用来判断「提示词注入有没有生效 / 模型为什么拒答」。
 *
 * 背景：$DSH_HOME/sessions/<cwd-slug>/session-<id>/session.v4.jsonl.zstd 是
 * **多帧 zstd 追加**文件。zlib.zstdDecompressSync 只解第一帧（通常就是那条
 * 200 字节的 session header），会让人误以为会话是空的。必须按 magic
 * 0x28 B5 2F FD 切帧逐帧解。
 *
 * ⚠️ 注释里千万不要写 `session-*` 这种通配路径：`*` 紧跟 `/` 会构成 `*/`
 * 提前闭合本块注释，node 直接报 `SyntaxError: Unexpected identifier`，
 * 报错行号落在注释内部，极难看出原因。2026-10 实测踩过。
 *
 * 用法：node read-dsh-session.js [--home /data/workspace/.dsh] [--all]
 *   默认取最新一个 session；--all 列出所有 session 的摘要。
 */
const fs = require("fs");
const path = require("path");
const zlib = require("zlib");

const MAGIC = [0x28, 0xb5, 0x2f, 0xfd];

function args() {
  const a = process.argv.slice(2);
  const o = { home: process.env.DSH_HOME || "", all: false };
  for (let i = 0; i < a.length; i++) {
    if (a[i] === "--home") o.home = a[++i];
    else if (a[i] === "--all") o.all = true;
  }
  return o;
}

function decode(file) {
  const buf = fs.readFileSync(file);
  const cuts = [];
  for (let i = 0; i + 4 <= buf.length; i++) {
    if (buf[i] === MAGIC[0] && buf[i + 1] === MAGIC[1] && buf[i + 2] === MAGIC[2] && buf[i + 3] === MAGIC[3]) cuts.push(i);
  }
  let text = "";
  for (let k = 0; k < cuts.length; k++) {
    const s = cuts[k];
    const e = k + 1 < cuts.length ? cuts[k + 1] : buf.length;
    try {
      text += zlib.zstdDecompressSync(buf.subarray(s, e)).toString("utf8");
    } catch (_) {
      /* 截断的尾帧属正常，跳过 */
    }
  }
  return text
    .split("\n")
    .filter((l) => l.trim())
    .map((l) => {
      try {
        return JSON.parse(l);
      } catch (_) {
        return null;
      }
    })
    .filter(Boolean);
}

function sessions(home) {
  const root = path.join(home, "sessions");
  const out = [];
  if (!fs.existsSync(root)) return out;
  for (const proj of fs.readdirSync(root)) {
    const dir = path.join(root, proj);
    if (!fs.statSync(dir).isDirectory()) continue;
    for (const s of fs.readdirSync(dir)) {
      const f = path.join(dir, s, "session.v4.jsonl.zstd");
      if (fs.existsSync(f)) out.push({ file: f, mtime: fs.statSync(f).mtimeMs, id: s });
    }
  }
  return out.sort((a, b) => b.mtime - a.mtime);
}

function summarize(recs) {
  const types = {};
  for (const r of recs) types[r.type || "?"] = (types[r.type || "?"] || 0) + 1;

  let sysLen = 0;
  let inject = false;
  for (const r of recs) {
    if (r.type === "system/message") {
      const s = JSON.stringify(r.data);
      sysLen = s.length;
      // 破甲类插件的注入标记；换插件时按需改这几个关键词。
      // 注意：dsh-purge 走 prompt-inject.md 注入人格时，system 里可能**没有**
      // UNRESTRICTED/dsh-purge 字样，只有人格开场（如 "You are 富江"）。
      // 关键词不命中 ≠ 没注入 —— 先用 `head -c 300 $DSH_HOME/prompt-inject.md`
      // 取人格开头几个词，加进这个正则再判。
      inject = /UNRESTRICTED|dsh-purge|MODE:/.test(s);
    }
  }

  let provider = null;
  for (const r of recs) if (r.type === "request/header") provider = r.data?.header?.config;

  const attempts = [];
  for (const r of recs) {
    if (r.type !== "assistant/attempt") continue;
    const stream = r.data?.stream || [];
    const fin = stream.find((c) => c.chunk?.type === "finish");
    attempts.push(fin?.chunk?.reason || null);
  }

  const assistant = [];
  for (const r of recs) {
    if (r.type !== "assistant/message") continue;
    const parts = r.data?.message?.content || [];
    assistant.push({
      reasoning: (parts.find((p) => p.type === "reasoning") || {}).text || "",
      text: (parts.find((p) => p.type === "text") || {}).text || "",
    });
  }

  return { types, sysLen, inject, provider, attempts, assistant };
}

const opt = args();
if (!opt.home) {
  console.error("need --home <DSH_HOME> or $DSH_HOME");
  process.exit(2);
}
const list = sessions(opt.home);
if (!list.length) {
  console.error("no session found under", path.join(opt.home, "sessions"));
  process.exit(1);
}

const pick = opt.all ? list : [list[0]];
for (const s of pick) {
  const recs = decode(s.file);
  const sum = summarize(recs);
  console.log("== " + s.id + "  (" + new Date(s.mtime).toISOString() + ")");
  console.log("   records:", recs.length, JSON.stringify(sum.types));
  console.log("   system prompt chars:", sum.sysLen, "| 注入标记:", sum.inject ? "YES" : "NO");
  console.log("   provider:", JSON.stringify(sum.provider));
  sum.attempts.forEach((a, i) => {
    if (a && a.kind === "error") console.log("   attempt#" + (i + 1) + " ERROR:", a.failure?.message?.slice(0, 200));
  });
  sum.assistant.forEach((m, i) => {
    if (m.reasoning) console.log("   #" + (i + 1) + " reasoning:", m.reasoning.slice(0, 400).replace(/\n/g, " "));
    if (m.text) console.log("   #" + (i + 1) + " text:", m.text.slice(0, 300).replace(/\n/g, " "));
  });
}
