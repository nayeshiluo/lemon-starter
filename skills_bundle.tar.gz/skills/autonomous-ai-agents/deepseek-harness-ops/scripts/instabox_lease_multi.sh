#!/bin/bash
# InstaBox Activity Lease 保活守护（多账号版）
#
# 与单账号版的区别：KEYFILE / LOG / LEASE / TTL / INTERVAL 全部由环境变量注入，
# 同一个脚本可以给每个账号跑一个独立的 systemd 实例。
# （GET /v1/machines 只返回当前 key 所属 org 的机器，所以不同账号必须分开跑。）
#
# 安装参考：
#   /etc/instabox-lab/api.key        600 root:root，目录 750
#   /usr/local/bin/instabox-lease-multi.sh   755
#   systemd 单元用 Environment= 传下面这几个变量
set -uo pipefail

API="https://api.instabox.sh"
KEYFILE="${KEYFILE:-/etc/instabox/api.key}"
LOG="${LOG:-/var/log/instabox-lease.log}"
LEASE="${LEASE:-lemon-keepalive}"
TTL="${TTL:-1800}"          # 30 分钟，上限 3600
INTERVAL="${INTERVAL:-600}" # 10 分钟续一次，必须 < TTL

[ -r "$KEYFILE" ] || { echo "$(date '+%F %T%z') FATAL 读不到 $KEYFILE" >> "$LOG"; exit 1; }
KEY=$(tr -d '\r\n' < "$KEYFILE")

log() { echo "$(date '+%F %T%z') $*" >> "$LOG"; }

log "start pid=$$ ttl=${TTL}s interval=${INTERVAL}s lease=${LEASE} keyfile=${KEYFILE}"

while true; do
    body=$(curl -fsS --max-time 20 -H "X-API-Key: $KEY" "$API/v1/machines" 2>&1)
    if [ $? -ne 0 ]; then
        log "LIST_FAIL $body"
        sleep 120
        continue
    fi

    # 用 jq 解析，别用 grep 正则抓 ID（格式一变就静默失效）
    ids=$(printf '%s' "$body" | jq -r '.machines[] | "\(.id)|\(.state)|\(.maxRunMinutes)|\(.runStartedAt // "-")"' 2>/dev/null)

    if [ -z "$ids" ]; then
        log "PARSE_FAIL $(printf '%s' "$body" | head -c 200)"
        sleep 120
        continue
    fi

    while IFS='|' read -r id state maxrun started; do
        [ -z "$id" ] && continue
        resp=$(curl -sS --max-time 20 -w '\n%{http_code}' -X PUT \
            "$API/v1/machines/$id/activity-leases/$LEASE" \
            -H "X-API-Key: $KEY" \
            -H "Content-Type: application/json" \
            -d "{\"ttlSeconds\":$TTL}" 2>&1)
        code=$(printf '%s' "$resp" | tail -1)
        payload=$(printf '%s' "$resp" | head -n -1 | tr -d '\n')
        if [ "$code" = "200" ]; then
            exp=$(printf '%s' "$payload" | jq -r '.expiresAt // "?"' 2>/dev/null)
            log "OK $id state=$state maxrun=${maxrun}m expires=$exp"
        else
            log "FAIL $id state=$state maxrun=${maxrun}m http=$code $payload"
        fi
    done <<< "$ids"

    # 日志防膨胀
    if [ "$(wc -l < "$LOG")" -gt 3000 ]; then
        tail -1000 "$LOG" > "$LOG.tmp" && mv "$LOG.tmp" "$LOG"
    fi

    sleep "$INTERVAL"
done
