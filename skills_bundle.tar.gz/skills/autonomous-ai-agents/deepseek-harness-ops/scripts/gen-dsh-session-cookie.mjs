#!/usr/bin/env node
/**
 * 生成 dsh 浏览器会话 cookie，用于反代层直接注入（绕开浏览器/303 丢 cookie）。
 *
 * 用法：
 *   DSH_HOME=/home/ubuntu/.dsh-lab \
 *   DSH_AUTHORITY=dsh.example.com \
 *   node gen-dsh-session-cookie.mjs
 *
 * 可选：
 *   DSH_COOKIE_DAYS  有效期天数，默认 29。**服务端硬上限 30 天，超了直接 401。**
 *
 * 输出三行：NAME= / VALUE= / COOKIE=
 *
 * 原理（dsh-client-connection/lib/index.js）：
 *   cookie 名 = "dsh-auth-" + base64url(sha256(authority))
 *   authority = 监听器为明文 HTTP 时是 url.host（域名[:端口]，无 scheme）
 *               监听器为 TLS 时是 url.origin（https://域名）
 *   cookie 值 = v1.<base64url(json payload)>.<base64url(HMAC-SHA256(secret, body))>
 *   payload  = {version:1, authority, issuedAt, expiresAt}
 *   secret   = $DSH_HOME/.credentials.yaml 里 client-connection/browser-session 的 secret（base64url, 32 字节）
 *
 * 反代场景下 dsh 自己监听 127.0.0.1:http，所以 authority 必须用域名 host 形式。
 */
import { readFileSync } from "node:fs";
import { createHash, createHmac } from "node:crypto";
import { join } from "node:path";

const DSH_HOME = process.env.DSH_HOME;
const AUTHORITY = process.env.DSH_AUTHORITY;
const DAYS = Number(process.env.DSH_COOKIE_DAYS || 29);

if (!DSH_HOME || !AUTHORITY) {
  console.error("需要 DSH_HOME 与 DSH_AUTHORITY 环境变量");
  process.exit(2);
}
if (DAYS > 30) {
  console.error(`DSH_COOKIE_DAYS=${DAYS} 超过服务端 30 天上限，会被判无效返回 401`);
  process.exit(2);
}

// .credentials.yaml 结构简单，用正则取，不引 yaml 依赖
const credPath = join(DSH_HOME, ".credentials.yaml");
let raw;
try {
  raw = readFileSync(credPath, "utf8");
} catch (e) {
  console.error(`读不到 ${credPath}: ${e.message}`);
  process.exit(1);
}
const secretLine = raw.match(/browser-session:[\s\S]*?secret:\s*([A-Za-z0-9_\-=+/]+)/);
if (!secretLine) {
  console.error("credentials 里没找到 client-connection/browser-session 的 secret（dsh web 至少启动过一次才会生成）");
  process.exit(1);
}
const secretB64 = secretLine[1];

const b64u = (buf) => Buffer.from(buf).toString("base64url");
const secret = Buffer.from(secretB64, "base64url");
if (secret.byteLength !== 32) {
  console.error(`secret 解码后 ${secret.byteLength} 字节，期望 32`);
  process.exit(1);
}

const VERSION = 1;
const name = "dsh-auth-" + b64u(createHash("sha256").update(AUTHORITY).digest());

const now = Date.now();
const expiresAt = now + DAYS * 24 * 3600 * 1000;
const payload = { version: VERSION, authority: AUTHORITY, issuedAt: now, expiresAt };

const body = b64u(Buffer.from(JSON.stringify(payload), "utf8"));
const sig = b64u(createHmac("sha256", secret).update(body).digest());
const value = `v${VERSION}.${body}.${sig}`;

console.log("NAME=" + name);
console.log("VALUE=" + value);
console.log("COOKIE=" + name + "=" + value);
