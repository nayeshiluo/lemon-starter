#!/usr/bin/env python3
"""假 OpenAI 兼容端点：记录 dsh 发来的请求体，返回固定回复。

用途：证明「提示词/人格到底有没有进 system prompt」，不需要任何真 API key。
这是 §九 抓包终审的最小实现，比行为探针可靠 —— 模型不听话 ≠ 提示词没进去。

用法
----
1) 起服务（建议后台跑）：
       python3 fake_openai_capture.py 9999
   抓到的请求体写到 /tmp/dsh_capture.json（每次覆盖），stdout 打印一行
   `CAPTURE roles=[...] system_chars=N`。

2) 在目标 profile 的 cordis.patch.yml 末尾追加（注意是顶层数组，直接追加即可）：

       - id: llm-pi-ai
         config:
           providers:
             fake:
               displayName: Fake
               api: openai-completions
               baseURL: http://127.0.0.1:9999/v1
               apiKeyEnv: FAKE_API_KEY
               models:
                 - id: fake-model
                   name: fake-model
       - id: agent-default-model
         config:
           provider: fake
           model: fake-model

   追加前先 cp cordis.patch.yml cordis.patch.yml.bak。

3) 发一句：

       export DSH_HOME=<你的 home> FAKE_API_KEY=sk-fake-test
       dsh --profile headless "你是谁"

   dsh 会报 `TRANSPORT: Stream ended without finish_reason` —— **这是预期的**，
   因为本服务返回非流式 JSON 而 dsh 期待 SSE。抓包文件此时已经落盘，忽略该错。

4) 检查：

       python3 -c "import json;d=json.load(open('/tmp/dsh_capture.json'));\
print([(m['role'],len(str(m['content']))) for m in d['messages']]);\
print(d['messages'][0]['content'][:800])"

   期望：messages[0].role == 'system'，字符数与人格文本规模相符
   （富江破甲双段注入实测 11291 字），首句出现人格开场。

坑
--
- 若 patch 里还有别的插件写了 `personaSuffix: ... {{cwd}}`，headless 会先崩在
  `unknown prompt variable "{{cwd}}"`，请求根本发不出去。先把它改成 `""`。
- 抓包只能证明「进没进 system」。上游模型听不听话是另一件事，用 §九 的 D 探针。
- 单进程单文件，别并发跑多个 dsh 实例，否则 /tmp/dsh_capture.json 互相覆盖。
"""

import json
import sys
from http.server import BaseHTTPRequestHandler, HTTPServer

CAPTURE_PATH = "/tmp/dsh_capture.json"


class Handler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        pass

    def do_GET(self):
        body = json.dumps(
            {"object": "list", "data": [{"id": "fake-model", "object": "model"}]}
        ).encode()
        self._send(body)

    def do_POST(self):
        n = int(self.headers.get("Content-Length", 0) or 0)
        raw = self.rfile.read(n)
        try:
            req = json.loads(raw)
        except Exception:
            req = {"_raw": raw[:4000].decode("utf-8", "ignore")}

        try:
            with open(CAPTURE_PATH, "w", encoding="utf-8") as f:
                json.dump(req, f, ensure_ascii=False, indent=2)
        except Exception as e:  # 抓包失败不该让请求挂掉
            print("capture write failed:", e, flush=True)

        msgs = req.get("messages", []) if isinstance(req, dict) else []
        roles = [m.get("role") for m in msgs if isinstance(m, dict)]
        syslen = sum(
            len(str(m.get("content", "")))
            for m in msgs
            if isinstance(m, dict) and m.get("role") == "system"
        )
        # tools 数量单独打：验证「工具注册有没有生效」时不用翻抓包文件
        ntools = len(req.get("tools") or []) if isinstance(req, dict) else 0
        print("CAPTURE roles=%s system_chars=%d tools=%d" % (roles, syslen, ntools), flush=True)

        resp = {
            "id": "chatcmpl-fake",
            "object": "chat.completion",
            "model": (req.get("model") if isinstance(req, dict) else None) or "fake",
            "choices": [
                {
                    "index": 0,
                    "message": {"role": "assistant", "content": "OK"},
                    "finish_reason": "stop",
                }
            ],
            "usage": {"prompt_tokens": 1, "completion_tokens": 1, "total_tokens": 2},
        }
        self._send(json.dumps(resp).encode())

    def _send(self, body: bytes):
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)


if __name__ == "__main__":
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 9999
    print("fake provider on http://127.0.0.1:%d/v1 -> %s" % (port, CAPTURE_PATH), flush=True)
    HTTPServer(("127.0.0.1", port), Handler).serve_forever()
