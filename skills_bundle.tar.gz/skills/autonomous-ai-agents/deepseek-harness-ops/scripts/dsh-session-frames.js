#!/usr/bin/env node
// 读 dsh 会话记录：session.v4.jsonl.zstd 是多帧 zstd，必须按 magic 切帧逐帧解。
// 只解第一帧会得到一个 ~200 字节的 session header，误判成「会话是空的」。
//
// 用法：
//   node dsh-session-frames.js <session.v4.jsonl.zstd 路径>
//   node dsh-session-frames.js <path> --dump-system     # 额外打印 system prompt 片段
//   node dsh-session-frames.js <path> --tools           # 打印会话挂载的工具名
//
// 远端通常没有 zstd CLI，也没有 python zstandard；node 22+ 自带 zlib.zstdDecompressSync，用这个最省事。

const fs = require('fs');
const zlib = require('zlib');

const file = process.argv[2];
const dumpSystem = process.argv.includes('--dump-system');
const showTools = process.argv.includes('--tools');
if (!file) {
  console.error('usage: node dsh-session-frames.js <session.v4.jsonl.zstd> [--dump-system] [--tools]');
  process.exit(2);
}

const buf = fs.readFileSync(file);
const MAGIC = Buffer.from([0x28, 0xb5, 0x2f, 0xfd]);

const offsets = [];
let i = 0;
while ((i = buf.indexOf(MAGIC, i)) !== -1) {
  offsets.push(i);
  i += 4;
}

const records = [];
let badFrames = 0;
for (let k = 0; k < offsets.length; k++) {
  const end = k + 1 < offsets.length ? offsets[k + 1] : buf.length;
  let text;
  try {
    text = zlib.zstdDecompressSync(buf.subarray(offsets[k], end)).toString('utf8');
  } catch (e) {
    badFrames++;
    continue;
  }
  for (const line of text.split('\n')) {
    if (!line.trim()) continue;
    try {
      records.push(JSON.parse(line));
    } catch (e) {
      /* 半帧或非 JSON 行，跳过 */
    }
  }
}

const types = {};
for (const r of records) types[r.type || '?'] = (types[r.type || '?'] || 0) + 1;

console.log('frames:', offsets.length, 'bad:', badFrames, 'records:', records.length);
console.log('types:', JSON.stringify(types));

for (const r of records) {
  const d = r.data || r;

  if (r.type === 'system/message') {
    const s = typeof d.content === 'string' ? d.content : JSON.stringify(d);
    console.log('system/message chars:', s.length);
    for (const marker of ['UNRESTRICTED', 'project_instructions', 'im_start']) {
      if (s.includes(marker)) console.log('  marker hit:', marker);
    }
    if (dumpSystem) console.log('  head:', s.slice(0, 400).replace(/\s+/g, ' '));
  }

  if (r.type === 'request/header') {
    const cfg = (d.header && d.header.config) || {};
    console.log('request provider/model:', cfg.provider, '/', cfg.model);
    const tools = (d.header && d.header.tools) || [];
    if (showTools) console.log('  tools:', tools.map((t) => t.name).join(', ') || '(none)');
    else console.log('  tool count:', tools.length);
  }

  if (r.type === 'request/context') {
    console.log('contextWindow:', d.contextWindow);
  }

  if (r.type === 'assistant/attempt' && (r.error || d.error)) {
    console.log('attempt error:', JSON.stringify(r.error || d.error).slice(0, 300));
  }

  if (r.type === 'session' && (r.sessionId || d.sessionId)) {
    console.log('sessionId:', r.sessionId || d.sessionId);
  }
}
