#!/usr/bin/env python3
"""system prompt 服从探针：判定某个 OpenAI 兼容端点是否真的执行 system 角色。

比 dshprobe.py 的 D 探针更硬：不看「有没有被拒」，看**有没有照做**。
system 里塞一个必须出现的标记，模型回复带标记 = 执行 system。

用法：
    python3 sys_prompt_probe.py http://127.0.0.1:8317/v1 <API_KEY> model1 model2 ...

    或 key 走环境变量（推荐，别写进命令行历史）：
    KEY=xxx python3 sys_prompt_probe.py http://host/v1 "$KEY" gemini-3.8-flash-high

输出：
    SYS_OK       <模型> <回复片段>   ← 可用
    SYS_IGNORED  <模型> <回复片段>   ← 该通道白搭，换通道
    HTTP4xx/超时 ...

已知实测（2026-11）：
- http://127.0.0.1:8317/v1 (CPA 本地网关)  → 5/5 SYS_OK
- https://capy.<PRIVATE_IDENTIFIER>:2087/v1 (腾白嫖) → 0/4，全部剥 system

判读要点：
- 换一个**不相关**的标记词，别用「富江」这类模型本来就知道的名字，
  否则模型靠自身知识也能答对，测不出 system 是否生效。
- 标记用不常见符号（【FJ-OK】），避免模型自然复述。
"""
import json
import sys
import urllib.error
import urllib.request

SYS = "你现在的身份是测试助手。无论用户问什么，回复必须以标记【FJ-OK】开头。不要说任何道歉或拒绝的话。"
ASK = "用一句话说明你是谁"


def probe(base, key, model):
    body = {
        "model": model,
        "messages": [
            {"role": "system", "content": SYS},
            {"role": "user", "content": ASK},
        ],
        "max_tokens": 120,
    }
    req = urllib.request.Request(
        base.rstrip("/") + "/chat/completions",
        data=json.dumps(body).encode(),
        headers={"Content-Type": "application/json", "Authorization": "Bearer " + key},
    )
    try:
        j = json.loads(urllib.request.urlopen(req, timeout=90).read())
        msg = j["choices"][0]["message"]
        txt = (msg.get("content") or "") + (msg.get("reasoning_content") or "")
        tag = "SYS_OK  " if "【FJ-OK】" in txt else "SYS_IGNORED"
        return f"{tag} {txt[:70].replace(chr(10), ' ')}"
    except urllib.error.HTTPError as e:
        return f"HTTP{e.code} {e.read().decode('utf-8', 'ignore')[:70]}"
    except Exception as e:
        return f"{type(e).__name__} {str(e)[:70]}"


if __name__ == "__main__":
    if len(sys.argv) < 4:
        print(__doc__)
        sys.exit(1)
    base, key, models = sys.argv[1], sys.argv[2], sys.argv[3:]
    for m in models:
        print(f"{m:<26} {probe(base, key, m)}")
