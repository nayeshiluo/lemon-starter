---
name: hermes-ai-chain-alert-triage
description: "排查 Lemon Ops「AI 链路告警」与模型回退：定位告警源、读检测逻辑、复现探针、分层归因。"
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux]
metadata:
  hermes:
    tags: [hermes, ops, alert-triage, model-fallback, monitoring, cpa]
    related_skills: [hermes-custom-providers, cliproxyapi, telegram-ops-bot]
---

# Hermes AI 链路告警排查

## When to Use

运维 Bot 私聊推送 `🚨【Lemon Ops · AI链路告警】` / `✅【Lemon Ops · AI链路恢复】`，或用户说「查一下日志分析下原因」「又告警了」「排查一下这条告警」。典型告警文案：

- `Gemini 主模型真实推理异常：CPA 推理连接失败或超时`
- `Hermes 过去30分钟累计发生 N 次模型回退`
- `CPA 过去30分钟内累计推理 HTTP 失败 N 次`
- 广告杀手 AI 审核线程心跳 / AI 失败次数相关
- `🛡 Ad Killer 仍未恢复（持续告警）` / `[P1] 连不上 vps-la：SSH 退出码 255`（lemon-ops-bot 自己的存活看门狗）

**不要**一上手就改模型或重启 CPA —— 告警脚本自己就声明「不会自动改模型或重启」，排查也必须先只读取证，改配置等用户点头。

## 第 0 步：先证伪探针本身（成本最低，命中率很高）

`lemon-ops-bot` 里的存活看门狗（`probe_ad_killer()`，main.py 2659-2864）是**自己发 SSH 出去取数**的，它和被测服务之间隔着一段可能腐化的链路：SSH 端口、ssh 别名、远端采集脚本、凭据文件。所以看到 `连不上 <主机>：SSH 退出码 255` 这类 P1，**先在同一个账号下手动跑一遍它跑的那条命令**，再谈服务死活：

```bash
ssh -o BatchMode=yes -o ConnectTimeout=8 <ADK_HOST> "sh /opt/ad-killer/ops_probe.sh"   # 能通 → 是监控/探针的问题，不是服务的问题
```

本次实测就是这条路：告警持续 P1「连不上」，而同一秒手工 `ssh vps-la` 秒回健康快照。根因是 `ADK_HOST="root@<PRIVATE_IDENTIFIER>"` 没有 `-p 2222`，vps-la 的 SSH 早改成 2222（22 被国内封）——监控每 10 分钟稳定误报一次。

排查顺序：**探针能通？→ 读远端快照 → 再看服务本身**。顺序反过来会把「端口漂移」误判成「主机宕机」，进而去重启健康的服务。


## 告警系统结构（先认路，别瞎 grep）

| 用途 | 路径 |
|------|------|
| 检测脚本（唯一告警源） | `/home/ubuntu/hermes-jobs/ai-model-healthcheck.py` |
| 当前状态（各信号 OK/ALERT/ACTIVE） | `/home/ubuntu/hermes-jobs/status/ai-model-health.state.json` |
| 历史检测流水 | `/home/ubuntu/hermes-jobs/status/ai-model-health.log` |
| 看门狗（15 分钟） | `/home/ubuntu/hermes-jobs/status/ai-monitor-watchdog.log` |
| 告警投递桥 | `/home/ubuntu/hermes-jobs/status/happy-capy-alert-bridge.log` |
| Hermes 主日志（回退真相） | `/home/ubuntu/.hermes/logs/agent.log`（+ `.1` 轮转） |
| Hermes 错误日志 | `/home/ubuntu/.hermes/logs/errors.log` |
| CPA 配置（含 api-keys） | `/home/ubuntu/cliproxyapi/config.yaml` |

⚠️ 别去 `lemon-ops-bot/ops-bot.log` 找「AI链路」关键词 —— 那里只有 Telegram 轮询日志（含多实例 Conflict），搜不到会白跑一轮。告警文案硬编码在 healthcheck 脚本里。

## 检测语义（读错就会误判）

- `EVENT_WINDOW_SECONDS = 30*60`：所有计数都是**滑动 30 分钟窗口**
- `MODEL_INTERVAL = 3600` / `RETRY_INTERVAL = 600`：真实推理探针成功 1 小时一次，失败后 10 分钟重试
- `advance(state, key, bad, msg, fail_after, recover_after)`：状态机 `OK → ALERT`（连续 bad 达 fail_after）→ `ACTIVE`（持续异常）→ `RECOVERED` → `OK`
- `model_probe` 用一次性挑战令牌（`CHECK-<8hex>`），要求模型**逐字符原样返回**，`timeout=17`
- `hermes_fallback` 统计 `agent.log` 里 `Fallback activated:` 行数；`cpa_inference` / `cpa_auth_probe` / `model_probe` 是**三条独立信号**，不要混为一谈

## 排查顺序（照这个走，不要跳）

1. **认告警源**：`grep -rn '<告警关键词>' /home/ubuntu/hermes-jobs/ --include="*.py"`，确认是哪条信号、阈值多少。
2. **读检测函数**：把对应 `def` 段读出来（`sed -n 'A,Bp'`），搞清它到底测什么、超时多少、窗口多大、判据是什么。
3. **读状态与流水**：`ai-model-health.state.json` 看各信号 `bad/good` 与 `last_probe`；`ai-model-health.log` 拉当天 `probe PASS/FAIL` 时间线，按 20 分钟间隔聚类成 burst。
4. **手动复现探针**：用脚本同款逻辑（同一 key、同一 model、同一 challenge、同一 timeout）直接打 CPA，**区分**「连接超时 / HTTP 错误码 / 200 但令牌不匹配」三种失败。
5. **归因到 agent.log**：回退类告警必须回 `agent.log` 找 `Fallback activated:` 那一行的**上游错误原文**，不要停在告警文案。
6. **实测 provider 可用性**：涉及模型逐个打真实 `chat/completions`，区分「永久不可用」与「瞬态」。
7. **汇报**：结论先行 + 北京时间时间线 + 已核实/推断分开 + 是否仍在发生 + 修复建议（等授权再动手）。

## 归因分类（这套告警最常见的四类根因）

1. **上游间歇超时（CPA 慢，不是坏了）**：`probe FAIL` 呈 burst、10~40 分钟后自愈，CPA 进程/端口/到 Google 的 TCP 全正常。免费 tier 波动 QoS + thinking 模型 + 17s 探针超时偏紧 = 高频误报。见 `references/cpa-inference-timeout-triage.md`。
2. **模型名在该账号上根本不可用（永久，重试无用）**：`HTTP 503` + `code:11158` + `personal_free_user` + `model [X] is not allowed for user type`。见 `references/account-tier-model-denied.md`。
3. **会话被切到坏模型**：`/model` 或 bridge 把会话切到不可用模型 → 每次调用 503 → 重试 2 次（attempt 1/3、2/3）→ 回退到兜底 → 凑满 2 次触发告警。
4. **辅助链路连带**：`vision_analyze` / 标题生成等 auxiliary client **继承会话模型**，坏模型会让视觉工具直接报错，表象像「图片坏了」，实际是模型选错。
5. **旁路请求漏剥 provider 字段（协议兼容层，不是模型坏）**：`HTTP 400 服务器不支持参数 messages.name` 这类报错，指纹是**日常对话全好、只在撞工具调用上限收尾 / 标题生成时炸**。根因是旁路请求绕过 transport 自己拼 messages，漏掉 transport 里的 host 白名单字段剥除。判定用「字段×角色」探针矩阵，不要猜、不要换模型。完整根因链、补丁与守卫见 `references/summary-path-provider-schema-rejection.md`。
6. **出口 IP 被判地区不支持（只有 Gemini 家族挂，同渠道 Claude/GPT 全好）**：`HTTP 400` + `User location is not supported for the API use.` + `FAILED_PRECONDITION`，恒定 ~1s 秒拒。判据是**控制变量换出口**：同账号同配置同二进制，直连 400、走代理 200 即定案。不要因为「Gemini 和 Claude 共用同一批 antigravity 账号」就推断它们会一起挂 —— Google 在同一端点内对模型家族套不同准入。修法是给网关加 `HTTPS_PROXY` + 精确 `NO_PROXY`，并把该节点的 `ai_timeout_overrides` 放宽。见 `references/gemini-region-block-egress-ip.md`。
7. **探针 / 依赖链路自身漂移（告警是假的，但底下常压着真故障）**：告警说「连不上」，实际是看门狗走了旧端口/旧 IP/旧别名；告警说「AI 失败」，实际是它指向的本地代理端口已经没有监听。这一类的特征是**告警文案与手工复现结果矛盾**。完整实录（SSH 22→2222 漂移、systemd `Requires=` 不传播 start 导致 worker 停 22 小时、AI 端点从死掉的 CPA 核心改指本机 wb2api 并端到端验收）见 `references/watchdog-probe-drift.md`。

## Pitfalls

- **`连不上 <主机>：SSH 退出码 255` ≠ 主机宕机**：先看探针里 `ADK_HOST` 是不是裸 IP、调用里有没有 `-p`。主机 SSH 改过端口后，所有硬编码 IP 的调用点会一起变成 255，而 `ssh <别名>` 一直好好的。用别名（`~/.ssh/config`）当唯一来源，别在代码里写死端口；改完顺手 `grep -rn 'root@<ip>' *.py` 把同类调用点扫干净（本次扫出 `vps_video_module.py` 三处）。
- **`Requires=` 只传播 stop，不传播 start**：worker 上写 `Requires=主服务` + `After=`，只是「主服务停我也停」。远程 `systemctl restart 主服务` 后 worker 会**一直死着**（本次死了 22 小时，靠 P2 `cleanup != active` 才露出）。要让它跟着起，得在**主服务**侧加 drop-in `[Unit] Wants=<worker>.service`；只给 worker 加 `PartOf=` 不够（worker 已 inactive 时不会被动启动）。判据：看 journal 里 worker 的停止时刻是否与主服务 restart 同一秒、有没有崩溃/错误文本。
- **「AI 失败」先分清是端点死还是模型拒**：`reason=model_transport_failed` 且 `curl <base_url>/v1/models` 返回 exit 7/连接被拒 = 端点没了（本次是 CPA 核心 18318 消失，而面板代理 `cpa-manager-plus:18317` 自己也在往 18318 拨，所以打 18317 只会得到 502 转发错误，别把它当成健康）。`reason=model_http_503` + `personal_free_user` 才是模型/账号问题。
- **换 AI 端点必须走「服务自己的客户端」验收**：`curl /v1/models` 返回 200 只证明端口活着。要用服务自己的 `AIClient` + 真实 prompt 跑一条评审，才同时验掉端点、key、模型名、prompt 契约与 JSON 解析。ad-killer 的 `parse_review()` 要求 `label ∈ {spam, normal, uncertain}`，且 `max_tokens=700` —— 推理模型会把额度全烧在 `reasoning_content` 上、`content` 返回空串，所以优先选非推理模型或路由器别名。
- **密钥不一定在 config.json 里**：ad-killer 的 AI key 走 `LoadCredential=ai-key:/etc/ad-killer/ai-key`，运行中读的是 `/run/credentials/<unit>/ai-key` 快照。只改 config.json 不改 key 文件（或改完不 restart）等于没改；验收要读运行中的凭据副本。
- **`ai_errors_30m` 归零不等于修好**：那是滑动 30 分钟窗口，修完立刻读到的 0 可能只是旧错误滑出窗口。正证只有「`bot.log` 里新增的 `ai_review`（成功）行」或客户端实测；群安静时如实写「等第一条真实消息确认」，别报成功。
- **`ops_probe.sh` 在 cleanup 非 active 时会多吐一行 `unknown`**：`CLEANUP=$(systemctl is-active ... || echo unknown)` 把 stdout 与兜底 echo 都留下了。key=value 解析能容忍，按行号取值会错位。

- **回退计数 ≠ 根因个数**：`Fallback activated:` 只记**最终落到兜底**的那一跳。中途的 `Model switched in-place: A -> B`（`/model` 切换）**不计入**。2 次回退可能只是 1 个坏模型被用了 2 轮。
- **`ACTIVE` 会自己掉下来**：滑动窗口把旧事件排出后，下几轮检查自动 `RECOVERED → OK`。窗口内事件数已低于阈值时就别「修」，先确认是不是自愈中。汇报要写「预计 X 分钟自动转 OK」。
- **`probe_model()` 的 17s 超时对 thinking 模型偏紧**：`gemini-3.8-flash-high` 实测 `reasoning_tokens≈91`，上游抖动时轻易超 17s。探针 FAIL ≠ 链路不可用，要看 burst 形态与真实调用延迟。
- **超长 latency 是事故链起点**：`agent.log` 里出现 `latency=389.0s` 这类调用，会先拖垮会话、再诱发人工/自动切模型，进而引出第 2/3 类根因。看到先记下来。
- **CPA 401 `Missing API key` 是正常的**：不带 `Authorization` 直接 curl 必然 401，别当故障。测 CPA 必须从 `config.yaml` 的 `api-keys[0]` 取那条 bcrypt 字符串当 Bearer 值。
- **`journalctl --user -u cliproxyapi` 常常 `-- No entries --`**：CPA 不是 systemd user unit 管理（进程直接跑），没有 journal。别据此判断「服务挂了」，改用 `ss -tlnp | grep 8317` + `/proc/<pid>/fd` + `ss -tnp | grep <pid>` 看真实连接。
- **不要 `cat` 大文件**：`ai-model-health.log` 26 万字符、`models_dev_cache.json` 单行 580 万字符，直接 cat/grep 会把上下文打爆。一律 `tail`/`grep` 限定时间与关键词；输出被截断时按提示定向补读，不要重跑同一命令。
- **只读优先**：告警排查阶段不改 config、不重启 CPA、不动 fallback 链。修复建议单独提出。
- **别把运维 Bot 的多实例 Conflict 当链路故障**：`ops-bot.log` 里的 `terminated by other getUpdates request` 只会导致**同一条告警重复推送**（用户说「发了多次」多半是这个），与模型链路无关，单独作为一条发现汇报。
- **摘要 / 标题生成类报错记的是 WARNING 不是 ERROR**：`Failed to get summary response` 用 `grep ERROR` 搜不到，会误判「没有报错」。按这条文案搜 `~/.hermes/logs/agent.log`。
- **「会话被强制结束」的文案会误导归因**：`I reached the maximum iterations (50) but couldn't summarize. Error: ...` 看着像会话被杀，实际是**收尾那次请求被上游拒了**，会话内容没丢、丢的是总结。先读 `Error:` 后面的上游原文，别停在第一句。
- **主链路通 ≠ 全链路通**：Hermes 里迭代上限摘要、标题生成、vision、compression 都是**绕过 transport 自己拼 messages** 的旁路，transport 里的 provider 特定字段剥除对它们无效。遇到「聊得好好的、只在长任务收尾炸」，先去旁路构造 messages 的地方找，不要怀疑模型或 key。
- **守卫报 `ok` ≠ 守全了**：v1 的 `patch-guard.json` 只有一对 `target`/`markers`，只能守一个补丁。**2026-10-24 已扩成 v2 多目标**（本机 16 目标 + 1 门控 + 5 import 全绿，去重键含失败集合、新增 import 探针与 `gate_unused`），但判据仍是「配置里列出来的」——**以后每次新加本地补丁，必须同步往 `targets` 里加一项**，否则又回到盲区。审计时用 `git status --porcelain`（未提交改动）+ `git log --oneline upstream/main..HEAD`（本地独有提交）把**所有**改在 Hermes 安装目录里的东西列出来逐项对照。本机实测 6 处本地改动只有 1 处有守卫时，漏掉的 4 个 `agent/local_*.py` 被 `agent_init`/`tool_executor`/`conversation_loop` 真实 import —— 丢了是**功能静默消失**，不是报错。
- **autostash 只保护未提交的改动**：`hermes update` 的 stash/restore 覆盖不到「已提交在无上游分支上」的本地补丁，这两类是不同风险，别混为一谈。
- **marker 验的是「文本存在」，不是「行为正确」**：补丁里若含 `hostname == "某中转域名"` 这类硬编码，换 provider 后补丁静默失效而标记一个不少、守卫照样报 `ok`。审计时把补丁里的硬编码常量与当前 `~/.hermes/config.yaml` 的 `base_url` 对一遍；标记也要取补丁独有片段（`from urllib.parse import urlsplit` 这种通用语句会假通过）。
- **`hermes update --check` 是只读的**（只 fetch + 比较，不落地），审计可以放心跑；会弹一次「restarts gateway」审批，解释清楚即可。另外 `git diff origin/main..HEAD` 出现上万文件差异时先查 `git merge-base`——镜像可能被重写过历史、与本地无共同祖先，不是「本地改了 19000 个文件」。

## 汇报模板

```
## 告警来源
<脚本路径 + 检测函数 + 阈值/窗口>

## 实况（北京时间）
| 时间 | 路径/信号 | 原因 |

## 根因
<一句话结论> + 实测证据表

## 当前状态
<是否仍在发生 / 预计何时自动恢复>

## 建议
<最小改动> + 「需要我现在改吗」
```

## 支持文件

- `references/gemini-region-block-egress-ip.md` — **「Gemini 全挂但 Claude/GPT 正常」先看这篇**：400 `User location is not supported` 的判定（控制变量换出口）、同端点不同模型家族不同准入的证据、网关加 `HTTPS_PROXY`+`NO_PROXY` 的 drop-in、节点预算放宽、连打压测触发 `ai_limits` 限流的误判
- `references/account-tier-model-denied.md` — 账号类型不支持模型的判定与实测（`code:11158` / `personal_free_user`）
- `references/watchdog-probe-drift.md` — **`🛡 Ad Killer 仍未恢复` / P1「连不上」先看这篇**：看门狗判定口径、SSH 22→2222 漂移导致的恒定 255 误报、`Requires=` 不传播 start 让 worker 停 22 小时、AI 端点从死掉的 CPA 核心改指本机 wb2api 的完整改法与端到端验收、换模型的两个硬约束（`label` 枚举 / `max_tokens=700` 烧在 reasoning 上）
- `references/cpa-inference-timeout-triage.md` — CPA 推理超时告警实录：burst 时间线、探针复现脚本、17s 超时误报分析
- `references/summary-path-provider-schema-rejection.md` — **「日常正常、只在长任务收尾 400」时先看这篇**：`messages.name` 根因链（旁路绕过 transport）、字段×角色探针矩阵、只剥 tool 角色的最小补丁、补丁前后对照验收、改 Hermes 安装目录的升级覆盖防线与守卫 cron
- `references/local-patch-guard-audit.md` — **用户说「审计一下补丁守卫」时看这篇**：守卫四条路径的桩测试（`PATCH_GUARD_NOTIFY` 防误发）、「一次更新会丢什么」的只读命令组（`git status` / `git log upstream/main..HEAD` / `hermes update --check`）、marker 只验文本不验行为的两个失效路径、v2 多目标/门控/import 探针的完整实现与去重键陷阱、改 systemd 单元用 `install` 不用 heredoc
- `scripts/provider_field_probe.py` — 可复用「字段×角色」探针矩阵（任意 provider / 任意字段），`--verify` 模式做补丁前后对照；key 走 `key_env` 不进命令行，host 与 key 全脱敏
- `scripts/verify_bypass_patch_behavior.py` — **行为级验收**：用 mock agent 调用真实旁路函数（如 `handle_max_iterations`），抓它实际发出的 `kwargs["messages"]`，断言目标 provider 剥了字段、对照 provider 没被误伤。`py_compile` 和「打真实网关返回 200」都替代不了这一层——只有它能证明补丁代码路径真的被执行
- `scripts/verify_patch_guard.py` — 补丁守卫的**行为回归**，改完 `patch_guard.py` 或 `patch-guard.json` 必跑：9 条路径（全绿静默 / 单目标坏 / 同集合去重 / **又坏一个必须再告警** / 恢复通知 / import 失败点名 / 文件消失 / `gate_unused` / 旧单目标配置兼容）+ `--upstream` 只读预演「上游覆盖后是否每个目标都会告警」。配置副本、state、通知桩全在临时目录，**不碰真实 state 也不打真实 notify**；全通过才删现场，失败保留供排查
- `scripts/patch_guard.py` — 补丁守卫 **v2 多目标**（`--config <json>`，兼容旧的 `--target/--marker`）：一次巡检覆盖 `targets`（每项 = 一个被改过的上游文件 + 必须全命中的 `markers` + `impact` + 可选 `patch` 重放）、`gates`（门控域名是否还在 `config.yaml` 里，抓「换中转后补丁静默失效」）、`imports`（真 import 一遍本地模块，抓「标记还在但代码坏了」）。正常静默、12h 去重（键含失败集合，不会因为整体仍 broken 而漏报新坏项）、恢复发通知、告警附受影响功能与重放命令。
  **部署范式（单一来源，推荐）**：脚本本体留在本技能目录，部署侧只放一份 JSON 配置（`target` / `patch` / `repo` / `state` / `markers`），systemd service 直接指向技能脚本 + `--config`。这样技能改进自动生效，不会出现「技能模板」与「线上副本」两份代码分叉：
  ```ini
  [Service]
  Type=oneshot
  User=ubuntu
  ExecStart=<venv>/python3 <skills>/hermes-ai-chain-alert-triage/scripts/patch_guard.py --config /home/ubuntu/hermes-jobs/patch-guard.json
  Nice=10
  IOSchedulingClass=idle
  ```
  配套 `.timer` 用 `OnCalendar=*-*-* 01:10:00 UTC` + `Persistent=true` + `RandomizedDelaySec=180`。
  ⚠️ 告警里的「重放命令」依赖 git 仓库根：`repo` 字段不给时会从 target 向上找 `.git`，找不到才退回 `parent×3` 的旧猜测——临时路径下会算出 `git -C /`，务必显式配 `repo`。
