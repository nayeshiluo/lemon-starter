---
name: hermes-ai-chain-alert-triage
description: "排查 Lemon Ops「AI 链路告警」与模型回退：定位告警源、读检测逻辑、复现探针、分层归因。"
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux]
metadata:
  hermes:
    tags: [hermes, ops, alert-triage, model-fallback, monitoring, cpa]
    related_skills: [hermes-custom-providers, cliproxyapi, telegram-ops-bot]
---

# Hermes AI 链路告警排查

## When to Use

运维 Bot 私聊推送 `🚨【Lemon Ops · AI链路告警】` / `✅【Lemon Ops · AI链路恢复】`，或用户说「查一下日志分析下原因」「又告警了」「排查一下这条告警」。典型告警文案：

- `Gemini 主模型真实推理异常：CPA 推理连接失败或超时`
- `Hermes 过去30分钟累计发生 N 次模型回退`
- `CPA 过去30分钟内累计推理 HTTP 失败 N 次`
- 广告杀手 AI 审核线程心跳 / AI 失败次数相关

**不要**一上手就改模型或重启 CPA —— 告警脚本自己就声明「不会自动改模型或重启」，排查也必须先只读取证，改配置等用户点头。

## 告警系统结构（先认路，别瞎 grep）

| 用途 | 路径 |
|------|------|
| 检测脚本（唯一告警源） | `/home/ubuntu/hermes-jobs/ai-model-healthcheck.py` |
| 当前状态（各信号 OK/ALERT/ACTIVE） | `/home/ubuntu/hermes-jobs/status/ai-model-health.state.json` |
| 历史检测流水 | `/home/ubuntu/hermes-jobs/status/ai-model-health.log` |
| 看门狗（15 分钟） | `/home/ubuntu/hermes-jobs/status/ai-monitor-watchdog.log` |
| 告警投递桥 | `/home/ubuntu/hermes-jobs/status/happy-capy-alert-bridge.log` |
| Hermes 主日志（回退真相） | `/home/ubuntu/.hermes/logs/agent.log`（+ `.1` 轮转） |
| Hermes 错误日志 | `/home/ubuntu/.hermes/logs/errors.log` |
| CPA 配置（含 api-keys） | `/home/ubuntu/cliproxyapi/config.yaml` |

⚠️ 别去 `lemon-ops-bot/ops-bot.log` 找「AI链路」关键词 —— 那里只有 Telegram 轮询日志（含多实例 Conflict），搜不到会白跑一轮。告警文案硬编码在 healthcheck 脚本里。

## 检测语义（读错就会误判）

- `EVENT_WINDOW_SECONDS = 30*60`：所有计数都是**滑动 30 分钟窗口**
- `MODEL_INTERVAL = 3600` / `RETRY_INTERVAL = 600`：真实推理探针成功 1 小时一次，失败后 10 分钟重试
- `advance(state, key, bad, msg, fail_after, recover_after)`：状态机 `OK → ALERT`（连续 bad 达 fail_after）→ `ACTIVE`（持续异常）→ `RECOVERED` → `OK`
- `model_probe` 用一次性挑战令牌（`CHECK-<8hex>`），要求模型**逐字符原样返回**，`timeout=17`
- `hermes_fallback` 统计 `agent.log` 里 `Fallback activated:` 行数；`cpa_inference` / `cpa_auth_probe` / `model_probe` 是**三条独立信号**，不要混为一谈

## 排查顺序（照这个走，不要跳）

1. **认告警源**：`grep -rn '<告警关键词>' /home/ubuntu/hermes-jobs/ --include="*.py"`，确认是哪条信号、阈值多少。
2. **读检测函数**：把对应 `def` 段读出来（`sed -n 'A,Bp'`），搞清它到底测什么、超时多少、窗口多大、判据是什么。
3. **读状态与流水**：`ai-model-health.state.json` 看各信号 `bad/good` 与 `last_probe`；`ai-model-health.log` 拉当天 `probe PASS/FAIL` 时间线，按 20 分钟间隔聚类成 burst。
4. **手动复现探针**：用脚本同款逻辑（同一 key、同一 model、同一 challenge、同一 timeout）直接打 CPA，**区分**「连接超时 / HTTP 错误码 / 200 但令牌不匹配」三种失败。
5. **归因到 agent.log**：回退类告警必须回 `agent.log` 找 `Fallback activated:` 那一行的**上游错误原文**，不要停在告警文案。
6. **实测 provider 可用性**：涉及模型逐个打真实 `chat/completions`，区分「永久不可用」与「瞬态」。
7. **汇报**：结论先行 + 北京时间时间线 + 已核实/推断分开 + 是否仍在发生 + 修复建议（等授权再动手）。

## 归因分类（这套告警最常见的四类根因）

1. **上游间歇超时（CPA 慢，不是坏了）**：`probe FAIL` 呈 burst、10~40 分钟后自愈，CPA 进程/端口/到 Google 的 TCP 全正常。免费 tier 波动 QoS + thinking 模型 + 17s 探针超时偏紧 = 高频误报。见 `references/cpa-inference-timeout-triage.md`。
2. **模型名在该账号上根本不可用（永久，重试无用）**：`HTTP 503` + `code:11158` + `personal_free_user` + `model [X] is not allowed for user type`。见 `references/account-tier-model-denied.md`。
3. **会话被切到坏模型**：`/model` 或 bridge 把会话切到不可用模型 → 每次调用 503 → 重试 2 次（attempt 1/3、2/3）→ 回退到兜底 → 凑满 2 次触发告警。
4. **辅助链路连带**：`vision_analyze` / 标题生成等 auxiliary client **继承会话模型**，坏模型会让视觉工具直接报错，表象像「图片坏了」，实际是模型选错。
5. **旁路请求漏剥 provider 字段（协议兼容层，不是模型坏）**：`HTTP 400 服务器不支持参数 messages.name` 这类报错，指纹是**日常对话全好、只在撞工具调用上限收尾 / 标题生成时炸**。根因是旁路请求绕过 transport 自己拼 messages，漏掉 transport 里的 host 白名单字段剥除。判定用「字段×角色」探针矩阵，不要猜、不要换模型。完整根因链、补丁与守卫见 `references/summary-path-provider-schema-rejection.md`。

## Pitfalls

- **回退计数 ≠ 根因个数**：`Fallback activated:` 只记**最终落到兜底**的那一跳。中途的 `Model switched in-place: A -> B`（`/model` 切换）**不计入**。2 次回退可能只是 1 个坏模型被用了 2 轮。
- **`ACTIVE` 会自己掉下来**：滑动窗口把旧事件排出后，下几轮检查自动 `RECOVERED → OK`。窗口内事件数已低于阈值时就别「修」，先确认是不是自愈中。汇报要写「预计 X 分钟自动转 OK」。
- **`probe_model()` 的 17s 超时对 thinking 模型偏紧**：`gemini-3.8-flash-high` 实测 `reasoning_tokens≈91`，上游抖动时轻易超 17s。探针 FAIL ≠ 链路不可用，要看 burst 形态与真实调用延迟。
- **超长 latency 是事故链起点**：`agent.log` 里出现 `latency=389.0s` 这类调用，会先拖垮会话、再诱发人工/自动切模型，进而引出第 2/3 类根因。看到先记下来。
- **CPA 401 `Missing API key` 是正常的**：不带 `Authorization` 直接 curl 必然 401，别当故障。测 CPA 必须从 `config.yaml` 的 `api-keys[0]` 取那条 bcrypt 字符串当 Bearer 值。
- **`journalctl --user -u cliproxyapi` 常常 `-- No entries --`**：CPA 不是 systemd user unit 管理（进程直接跑），没有 journal。别据此判断「服务挂了」，改用 `ss -tlnp | grep 8317` + `/proc/<pid>/fd` + `ss -tnp | grep <pid>` 看真实连接。
- **不要 `cat` 大文件**：`ai-model-health.log` 26 万字符、`models_dev_cache.json` 单行 580 万字符，直接 cat/grep 会把上下文打爆。一律 `tail`/`grep` 限定时间与关键词；输出被截断时按提示定向补读，不要重跑同一命令。
- **只读优先**：告警排查阶段不改 config、不重启 CPA、不动 fallback 链。修复建议单独提出。
- **别把运维 Bot 的多实例 Conflict 当链路故障**：`ops-bot.log` 里的 `terminated by other getUpdates request` 只会导致**同一条告警重复推送**（用户说「发了多次」多半是这个），与模型链路无关，单独作为一条发现汇报。
- **摘要 / 标题生成类报错记的是 WARNING 不是 ERROR**：`Failed to get summary response` 用 `grep ERROR` 搜不到，会误判「没有报错」。按这条文案搜 `~/.hermes/logs/agent.log`。
- **「会话被强制结束」的文案会误导归因**：`I reached the maximum iterations (50) but couldn't summarize. Error: ...` 看着像会话被杀，实际是**收尾那次请求被上游拒了**，会话内容没丢、丢的是总结。先读 `Error:` 后面的上游原文，别停在第一句。
- **主链路通 ≠ 全链路通**：Hermes 里迭代上限摘要、标题生成、vision、compression 都是**绕过 transport 自己拼 messages** 的旁路，transport 里的 provider 特定字段剥除对它们无效。遇到「聊得好好的、只在长任务收尾炸」，先去旁路构造 messages 的地方找，不要怀疑模型或 key。

## 汇报模板

```
## 告警来源
<脚本路径 + 检测函数 + 阈值/窗口>

## 实况（北京时间）
| 时间 | 路径/信号 | 原因 |

## 根因
<一句话结论> + 实测证据表

## 当前状态
<是否仍在发生 / 预计何时自动恢复>

## 建议
<最小改动> + 「需要我现在改吗」
```

## 支持文件

- `references/account-tier-model-denied.md` — 账号类型不支持模型的判定与实测（`code:11158` / `personal_free_user`；腾白嫖 `global:*` 全灭、`cn:*` 全通）
- `references/cpa-inference-timeout-triage.md` — CPA 推理超时告警实录：burst 时间线、探针复现脚本、17s 超时误报分析
- `references/summary-path-provider-schema-rejection.md` — **「日常正常、只在长任务收尾 400」时先看这篇**：`messages.name` 根因链（旁路绕过 transport）、字段×角色探针矩阵、只剥 tool 角色的最小补丁、补丁前后对照验收、改 Hermes 安装目录的升级覆盖防线与守卫 cron
- `scripts/provider_field_probe.py` — 可复用「字段×角色」探针矩阵（任意 provider / 任意字段），`--verify` 模式做补丁前后对照；key 走 `key_env` 不进命令行，host 与 key 全脱敏
- `scripts/patch_guard.py` — 补丁守卫：每日检查改在 Hermes 安装目录里的补丁标记是否被升级覆盖，正常静默、12h 去重、恢复发通知、告警附重放命令
