#!/usr/bin/env python3
"""provider 字段×角色 探针矩阵 —— 定案「网关不认某个消息字段」的问题。

用途：Hermes 报 `HTTP 400 服务器不支持参数 messages.<字段>` 时，别猜是哪个字段、
哪个角色不认。用本脚本对同一 key/模型只改消息形状跑四组用例，一次定案。

用法：
    python3 provider_field_probe.py <provider名>            # 跑矩阵
    python3 provider_field_probe.py <provider名> --verify    # 补丁前后对照（复刻剥除逻辑）

字段默认 name；换字段用 --field thinking（同时会改到 tool 消息上）。

安全：key 从 ~/.hermes/.env 按 key_env 读，不进命令行；输出里 host 与 key 全部脱敏。
"""
import argparse
import os
import re
import sys

import requests
import yaml

CFG = os.path.expanduser("~/.hermes/config.yaml")
ENV = os.path.expanduser("~/.hermes/.env")


def load_provider(name):
    d = yaml.safe_load(open(CFG, encoding="utf-8"))
    for c in d.get("custom_providers") or []:
        if c.get("name") == name:
            return c
    raise SystemExit(f"provider 未找到: {name}（可用: "
                     + ", ".join(c.get("name", "?") for c in d.get("custom_providers") or []) + "）")


def load_key(key_env):
    if not key_env:
        return None
    v = os.environ.get(key_env)
    if v:
        return v
    try:
        for line in open(ENV, encoding="utf-8"):
            line = line.strip()
            if line.startswith(key_env + "="):
                return line.split("=", 1)[1].strip().strip('"').strip("'")
    except OSError:
        pass
    return None


def scrub(txt, host):
    txt = re.sub(r"(sk-|key-)[A-Za-z0-9_\-]{6,}", "<REDACTED>", str(txt))
    if host:
        txt = txt.replace(host, "<gw>")
    return txt[:400]


def cases(field="name"):
    """四组用例：只改消息形状，不动内容。"""
    base = {"role": "user", "content": "回复OK"}
    tool_turn = [
        {"role": "user", "content": "调用工具"},
        {"role": "assistant", "content": None, "tool_calls": [
            {"id": "call_1", "type": "function",
             "function": {"name": "get_time", "arguments": "{}"}}]},
        {"role": "tool", "tool_call_id": "call_1", field: "get_time", "content": "12:00"},
        {"role": "user", "content": "回复OK"},
    ]
    return {
        f"A 基线（无 {field}）": [dict(base)],
        f"B tool 消息带 {field}": tool_turn,
        f"C user 消息带 {field}": [{"role": "user", field: "lemon", "content": "回复OK"}],
        f"D assistant 消息带 {field}": [
            dict(base),
            {"role": "assistant", field: "lemon", "content": "OK"},
            {"role": "user", "content": "再说一次"},
        ],
    }


def send(base_url, key, model, msgs, host, max_tokens=16, timeout=120):
    headers = {"Content-Type": "application/json"}
    if key:
        headers["Authorization"] = f"Bearer {key}"
    body = {"model": model, "messages": msgs, "max_tokens": max_tokens}
    try:
        r = requests.post(base_url.rstrip("/") + "/chat/completions",
                          headers=headers, json=body, timeout=timeout)
        return r.status_code, scrub(r.text, host)
    except Exception as exc:
        return None, f"{type(exc).__name__}: {scrub(exc, host)}"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("provider")
    ap.add_argument("--field", default="name")
    ap.add_argument("--model", default=None)
    ap.add_argument("--verify", action="store_true",
                    help="额外验证「只剥 tool 角色」的修法是否成立")
    args = ap.parse_args()

    cfg = load_provider(args.provider)
    base_url = str(cfg.get("base_url") or "")
    host = re.sub(r"^https?://", "", base_url).split("/")[0].split(":")[0]
    model = args.model or cfg.get("model")
    key = load_key(cfg.get("key_env"))

    print(f"provider={args.provider} host=<gw> model={model} "
          f"key={'loaded' if key else 'MISSING'} field={args.field}\n")

    results = {}
    for label, msgs in cases(args.field).items():
        code, text = send(base_url, key, model, msgs, host)
        results[label] = code
        print(f"[{'PASS' if code == 200 else 'FAIL'}] {label} -> HTTP {code}")
        if code != 200:
            print(f"       {text}")

    if not args.verify:
        bad = [k for k, v in results.items() if v != 200]
        print("\n不兼容用例:", "、".join(bad) if bad else "无")
        if bad and all("tool" in k for k in bad):
            print("→ 结论：网关只拒绝 tool 角色上的该字段，修法应只剥 role==tool，"
                  "不要一刀切全剥。")
        return 0

    # ---- 补丁前后对照：复刻「只剥 tool 的 name」逻辑 ----
    print("\n--- 补丁前后对照 ---")
    raw = cases(args.field)[f"B tool 消息带 {args.field}"]
    before, _ = send(base_url, key, model, raw, host)
    patched = []
    for m in raw:
        m = dict(m)
        if m.get("role") == "tool":
            m.pop(args.field, None)
        patched.append(m)
    after, _ = send(base_url, key, model, patched, host)

    print(f"剥除前（应非 200，复现原 bug） -> HTTP {before}")
    print(f"剥除后（应 200）               -> HTTP {after}")

    # 未命中 host 的 provider 不应被剥
    other_kept = any(m.get(args.field) for m in patched if m.get("role") == "user")
    print(f"user 的 {args.field} 未被误剥: {other_kept}")

    ok = before != 200 and after == 200 and other_kept
    print("\n对照验收:", "通过" if ok else "未通过（需人工复核）")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
