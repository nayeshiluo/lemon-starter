#!/usr/bin/env python3
"""补丁守卫：检测改在 Hermes 安装目录里的本地补丁是否被 `hermes update` 覆盖。

背景：Hermes 升级会覆盖 `~/.hermes/hermes-agent/` 下的文件。任何改在那里的补丁
都必须配一个守卫，否则下次升级静默失效、故障复发而无人知情。

判据（三层，任一不过就算坏）：
  1. 目标文件存在
  2. 补丁在文件里留下的「源码标记」必须同时存在（markers）
  3. 本地模块必须能 import（imports，可选）—— 标记还在但语法/依赖坏了也能抓到

用法：
    python3 patch_guard.py --config /path/to/guard.json

    # 兼容旧单目标写法
    python3 patch_guard.py --target <file> --marker "label:needle"

配置（推荐多目标）：
    {
      "state": ".../patch-guard.state.json",
      "repo":  "/home/ubuntu/.hermes/hermes-agent",
      "imports": ["agent.local_group_policy", "..."],
      "targets": [
        {"name": "总结路径剥 name", "path": ".../chat_completion_helpers.py",
         "markers": {"门控": "strip_tool_result_name = ("},
         "impact": "长任务收尾 400",
         "patch": ".../x.patch"}
      ]
    }

行为：正常静默（退出 0，不通知）；有目标坏 → 告警并附重放命令；
      整体恢复正常 → 发一条恢复通知；同一组失败项 12h 内不重复告警
      （失败项集合变化则立刻告警，不会因为「整体状态还是坏」而漏报新坏的目标）。
"""
import argparse
import json
import os
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

DEFAULT_NOTIFY = "/home/ubuntu/lemon-ops-bot/notify.py"
DEFAULT_STATE = "/home/ubuntu/hermes-jobs/status/patch-guard.state.json"
# notify.py 是 Python 脚本，必须用解释器跑（用 shell 直接执行会静默失败）
PYTHON = "/home/ubuntu/.hermes/hermes-agent/venv/bin/python3"
DEDUP_HOURS = 12

# 在子进程里逐个 import，把失败定位到具体模块
IMPORT_PROBE = r"""
import importlib, json, sys
out = {}
for name in sys.argv[1:]:
    try:
        importlib.import_module(name)
        out[name] = "ok"
    except BaseException as exc:            # noqa: BLE001 - 故意全抓
        out[name] = f"{type(exc).__name__}: {exc}"
print(json.dumps(out, ensure_ascii=False))
"""


def notify(text):
    path = os.environ.get("PATCH_GUARD_NOTIFY", DEFAULT_NOTIFY)
    if not os.path.exists(path):
        print(f"WARN: 通知器不存在，仅打印：{path}", file=sys.stderr)
        return
    try:
        subprocess.run([PYTHON, path, text], timeout=30, check=False,
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except Exception as exc:
        print(f"WARN: 通知发送失败: {exc}", file=sys.stderr)


def load_state(path):
    try:
        return json.loads(Path(path).read_text(encoding="utf-8"))
    except Exception:
        return {}


def save_state(path, state):
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_suffix(".tmp")
    tmp.write_text(json.dumps(state, ensure_ascii=False, indent=2), encoding="utf-8")
    os.chmod(tmp, 0o600)
    os.replace(tmp, p)


def find_repo(start: Path) -> str:
    """从 target 向上找 .git；找不到就退回上三级（旧行为）。"""
    p = start.parent
    while p != p.parent:
        if (p / ".git").exists():
            return str(p)
        p = p.parent
    return str(start.parent.parent.parent)


def check_target(t: dict) -> dict:
    """检查单个目标，返回 {name,status,detail,impact,patch,path}。"""
    path = Path(t.get("path") or "")
    markers = t.get("markers") or {}
    name = t.get("name") or path.name
    res = {"name": name, "path": str(path), "impact": t.get("impact", ""),
           "patch": t.get("patch", ""), "status": "ok", "detail": ""}
    if not markers:
        res["status"] = "config_error"
        res["detail"] = "未配置 markers"
        return res
    if not path.exists():
        res["status"] = "missing_file"
        res["detail"] = f"文件不存在：{path}"
        return res
    try:
        src = path.read_text(encoding="utf-8", errors="replace")
    except Exception as exc:
        res["status"] = "unreadable"
        res["detail"] = f"读取失败：{type(exc).__name__}: {exc}"
        return res
    missing = [k for k, v in markers.items() if v not in src]
    if missing:
        res["status"] = "patch_lost"
        res["detail"] = "缺失标记：" + "、".join(missing)
    return res


def check_gates(gates) -> list:
    """检查补丁的门控域名是否还出现在配置文件里。

    补丁用域名做门控（只对某个自定义网关剥 name 字段）。一旦换中转站/换域名，
    补丁就静默失效——但源码标记全都还在，纯 marker 检查永远报 ok。
    这里换个角度：门控域名在 config 里已经找不到了 → 补丁大概率已无用或需要改域名，
    提醒人工复核，而不是假装一切正常。
    """
    out = []
    for g in gates or []:
        domain = (g.get("domain") or "").strip()
        cfg_path = Path(g.get("config") or "")
        if not domain:
            continue
        name = g.get("name") or f"门控域名 {domain}"
        res = {"name": name, "path": str(cfg_path), "patch": "",
               "impact": g.get("impact", ""), "status": "ok", "detail": ""}
        if not cfg_path.exists():
            res["status"] = "config_missing"
            res["detail"] = f"配置文件不存在：{cfg_path}"
        else:
            try:
                text = cfg_path.read_text(encoding="utf-8", errors="replace")
            except Exception as exc:
                res["status"] = "unreadable"
                res["detail"] = f"配置读取失败：{type(exc).__name__}: {exc}"
                out.append(res)
                continue
            if domain not in text:
                res["status"] = "gate_unused"
                res["detail"] = f"门控域名已不在配置中：{domain}（换过中转？补丁可能失效或可退役）"
        out.append(res)
    return out


def check_imports(modules, repo: str) -> dict:
    """逐个 import 本地模块；返回 {module: "ok"|"错误"}。"""
    if not modules:
        return {}
    py = PYTHON if os.path.exists(PYTHON) else sys.executable
    try:
        proc = subprocess.run(
            [py, "-c", IMPORT_PROBE, *modules],
            cwd=repo or None, capture_output=True, text=True,
            encoding="utf-8", errors="replace", timeout=90,
        )
        if proc.stdout.strip():
            return json.loads(proc.stdout.strip().splitlines()[-1])
        return {m: f"探针无输出（rc={proc.returncode}）：{proc.stderr.strip()[:120]}"
                for m in modules}
    except Exception as exc:
        return {m: f"探针异常：{type(exc).__name__}: {exc}" for m in modules}


def check_behaviors(checks, repo: str) -> list:
    """Run configured local behavioral probes without a shell."""
    results = []
    for check in checks or []:
        result = {"name": check["name"], "path": "", "patch": "",
                  "impact": check.get("impact", ""), "status": "ok", "detail": ""}
        try:
            command = check.get("command")
            if not isinstance(command, list) or not command or not all(isinstance(x, str) for x in command):
                raise ValueError("behavior command must be a non-empty argv list")
            proc = subprocess.run(command, cwd=repo or None, capture_output=True,
                                  text=True, timeout=check.get("timeout", 30))
            if proc.returncode:
                result.update(status="behavior_failed", detail=f"local probe exited {proc.returncode}")
        except Exception as exc:
            result.update(status="behavior_failed", detail=type(exc).__name__)
        results.append(result)
    return results


def build_targets(args, cfg) -> list:
    targets = cfg.get("targets")
    if targets:
        return targets
    # 兼容旧的单目标配置 / 纯命令行
    t = {"name": Path(cfg.get("target") or args.target or "").name,
         "path": cfg.get("target") or args.target,
         "markers": cfg.get("markers") or {},
         "patch": cfg.get("patch") or args.patch or "",
         "impact": cfg.get("impact", "")}
    for item in args.marker:
        label, _, needle = item.partition(":")
        if label and needle:
            t["markers"][label] = needle
    return [t]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", help="JSON 配置：targets/imports/state/repo")
    ap.add_argument("--target")
    ap.add_argument("--patch", default="")
    ap.add_argument("--marker", action="append", default=[],
                    help="形如 label:needle，可多次给")
    ap.add_argument("--state", default=os.environ.get("PATCH_GUARD_STATE", DEFAULT_STATE))
    ap.add_argument("--repo", default="",
                    help="git 仓库根（import 探针与重放命令用）")
    ap.add_argument("--check", action="store_true",
                    help="read-only: no notifications/state writes; exit 1 if broken")
    ap.add_argument("--no-notify", action="store_true",
                    help="update real check state without sending notifications")
    args = ap.parse_args()

    cfg = {}
    if args.config:
        cfg = json.loads(Path(args.config).read_text(encoding="utf-8"))
    state_path = cfg.get("state") or args.state
    repo = cfg.get("repo") or args.repo
    imports = cfg.get("imports") or []

    targets = build_targets(args, cfg)
    if not targets or not any(t.get("markers") for t in targets):
        raise SystemExit("需要至少一个带 markers 的目标（--config 的 targets 或 --target/--marker）")

    results = [check_target(t) for t in targets]

    gates = cfg.get("gates") or []
    gate_results = check_gates(gates)
    results = results + gate_results

    if not repo:
        first = Path(results[0]["path"] or ".")
        repo = find_repo(first)

    import_results = check_imports(imports, repo)
    bad_imports = {m: e for m, e in import_results.items() if e != "ok"}
    behaviors = cfg.get("behaviors") or []
    results += check_behaviors(behaviors, repo)

    failing = [r for r in results if r["status"] != "ok"]
    overall = "ok" if (not failing and not bad_imports) else "broken"

    def _counts() -> str:
        parts = [f"{len(targets)} 目标"]
        if gates:
            parts.append(f"{len(gates)} 门控")
        if imports:
            parts.append(f"{len(imports)} import")
        if behaviors:
            parts.append(f"{len(behaviors)} behavior")
        return " + ".join(parts)

    if args.check:
        for result in failing:
            print(f"FAIL {result['name']}: {result['status']} {result['detail']}")
        for name in bad_imports:
            print(f"FAIL import: {name}")
        print(f"检查完成：{overall}（{_counts()}，异常 {len(failing) + len(bad_imports)}）")
        return 0 if overall == "ok" else 1

    send_notice = (lambda text: None) if args.no_notify else notify

    # 去重键必须包含「哪些目标坏了」，否则第二个目标坏掉时整体状态仍是 broken，
    # 会被 12h 去重逻辑当成重复告警而静默。
    fail_key = sorted([f"{r['name']}:{r['status']}" for r in failing] +
                      [f"import:{m}" for m in bad_imports])

    state = load_state(state_path)
    prev_status = state.get("status")
    prev_key = state.get("fail_key") or []
    now = datetime.now(timezone.utc)
    changed = prev_status != overall or prev_key != fail_key
    due = True
    if state.get("last_alert_at"):
        try:
            due = (now - datetime.fromisoformat(state["last_alert_at"])).total_seconds() \
                >= DEDUP_HOURS * 3600
        except Exception:
            due = True

    if overall == "ok":
        if prev_status and prev_status != "ok":
            body = ("✅【补丁已恢复】\n━━━━━━━━━━━━━━━━━━━━\n"
                    f"全部 {len(targets)} 个本地补丁目标标记齐全"
                    + (f"，{len(gates)} 个门控域名仍在配置中" if gates else "")
                    + (f"，{len(imports)} 个本地模块 import 正常" if imports else "")
                    + "。")
            print(body)
            send_notice(body)
    elif changed or due:
        lines = [f"🔴 受影响项：{len(failing) + len(bad_imports)} / {len(results) + len(imports)}"]
        for r in failing:
            lines.append(f"• `{r['name']}` — {r['status']}：{r['detail']}")
            if r["impact"]:
                lines.append(f"  影响：{r['impact']}")
            if r["patch"] and Path(r["patch"]).exists():
                lines.append(f"  重放：`git -C {repo} apply {Path(r['patch']).name}`")
            elif r["patch"]:
                lines.append("  ⚠️ 补丁文件缺失，需重新生成")
        for m, err in bad_imports.items():
            lines.append(f"• `{m}` — import 失败：{err[:160]}")
        lines.append("• 修复后下次巡检会自动发恢复通知")
        body = "🛡️【补丁守卫告警：本地补丁被覆盖】\n━━━━━━━━━━━━━━━━━━━━\n" + "\n".join(lines)
        print(body)
        send_notice(body)
    else:
        print(f"仍有 {len(failing) + len(bad_imports)} 项异常，{DEDUP_HOURS}h 内已告警过且失败集合未变，跳过")

    state["status"] = overall
    state["fail_key"] = fail_key
    state["checked_at"] = now.isoformat()
    state["targets"] = {r["name"]: r["status"] for r in results}
    if bad_imports:
        state["imports"] = bad_imports
    else:
        state.pop("imports", None)
    if overall != "ok" and (changed or due):
        state["last_alert_at"] = now.isoformat()
    save_state(state_path, state)

    summary = f"检查完成：{overall}（{_counts()}"
    summary += f"，异常 {len(failing) + len(bad_imports)}）"
    print(summary)
    return 0


if __name__ == "__main__":
    sys.exit(main())
