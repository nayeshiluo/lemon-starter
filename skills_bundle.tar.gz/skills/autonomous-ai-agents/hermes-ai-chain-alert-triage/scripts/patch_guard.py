#!/usr/bin/env python3
"""补丁守卫：检测改在 Hermes 安装目录里的补丁是否被 `hermes update` 覆盖。

背景：Hermes 升级会覆盖 `~/.hermes/hermes-agent/` 下的文件。任何改在那里的补丁
都必须配一个守卫，否则下次升级静默失效、故障复发而无人知情。

判据：补丁在目标文件里留下的若干「源码标记」必须同时存在。

用法：
    # 1) 在技能/项目里放一份配置（JSON）
    #    {"target": ".../agent/chat_completion_helpers.py",
    #     "patch":  ".../summary-strip-tool-name.patch",
    #     "markers": {"urlsplit 已导入": "from urllib.parse import urlsplit",
    #                 "tool 角色判断": "strip_tool_result_name and msg.get(\"role\") == \"tool\""}}
    python3 patch_guard.py --config /path/to/guard.json

    # 2) 或直接命令行给标记
    python3 patch_guard.py --target <file> --patch <patchfile> \
        --marker "urlsplit:from urllib.parse import urlsplit"

行为：正常静默（退出 0，不通知）；标记缺失 → 告警并附重放命令；
      恢复正常 → 发一条恢复通知；同状态 12h 内不重复告警。
"""
import argparse
import json
import os
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

DEFAULT_NOTIFY = "/home/ubuntu/lemon-ops-bot/notify.py"
DEFAULT_STATE = "/home/ubuntu/hermes-jobs/status/patch-guard.state.json"
# notify.py 是 Python 脚本，必须用解释器跑（用 shell 直接执行会静默失败）
PYTHON = "/home/ubuntu/.hermes/hermes-agent/venv/bin/python3"
DEDUP_HOURS = 12


def notify(text):
    path = os.environ.get("PATCH_GUARD_NOTIFY", DEFAULT_NOTIFY)
    if not os.path.exists(path):
        print(f"WARN: 通知器不存在，仅打印：{path}", file=sys.stderr)
        return
    try:
        subprocess.run([PYTHON, path, text], timeout=30, check=False,
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except Exception as exc:
        print(f"WARN: 通知发送失败: {exc}", file=sys.stderr)


def load_state(path):
    try:
        return json.loads(Path(path).read_text(encoding="utf-8"))
    except Exception:
        return {}


def save_state(path, state):
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_suffix(".tmp")
    tmp.write_text(json.dumps(state, ensure_ascii=False, indent=2), encoding="utf-8")
    os.chmod(tmp, 0o600)
    os.replace(tmp, p)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", help="JSON 配置：target/patch/markers/state")
    ap.add_argument("--target")
    ap.add_argument("--patch", default="")
    ap.add_argument("--marker", action="append", default=[],
                    help="形如 label:needle，可多次给")
    ap.add_argument("--state", default=os.environ.get("PATCH_GUARD_STATE", DEFAULT_STATE))
    args = ap.parse_args()

    target, patch, markers, state_path = args.target, args.patch, {}, args.state
    if args.config:
        cfg = json.loads(Path(args.config).read_text(encoding="utf-8"))
        target = cfg.get("target", target)
        patch = cfg.get("patch", patch)
        markers = cfg.get("markers") or {}
        state_path = cfg.get("state", state_path)
    for item in args.marker:
        label, _, needle = item.partition(":")
        if label and needle:
            markers[label] = needle

    if not target or not markers:
        raise SystemExit("需要 --target 与至少一个 --marker（或用 --config）")

    tp = Path(target)
    if not tp.exists():
        status, detail, missing = "missing_file", f"目标文件不存在：{tp}", list(markers)
    else:
        src = tp.read_text(encoding="utf-8", errors="replace")
        missing = [k for k, v in markers.items() if v not in src]
        status = "ok" if not missing else "patch_lost"
        detail = "" if not missing else "缺失标记：" + "、".join(missing)

    state = load_state(state_path)
    prev = state.get("status")
    now = datetime.now(timezone.utc)
    changed = prev != status
    due = True
    if state.get("last_alert_at"):
        try:
            due = (now - datetime.fromisoformat(state["last_alert_at"])).total_seconds() >= DEDUP_HOURS * 3600
        except Exception:
            due = True

    if status == "ok":
        if prev and prev != "ok":
            body = ("✅【补丁已恢复】\n━━━━━━━━━━━━━━━━━━━━\n"
                    f"`{tp.name}` 的补丁标记齐全，旁路请求恢复正常。")
            print(body)
            notify(body)
    elif changed or due:
        lines = [f"🔴 状态：`{status}`", f"• {detail}"]
        if patch and Path(patch).exists():
            lines.append(f"• 补丁文件在位：`{Path(patch).name}`")
            lines.append(f"• 重放：`git -C {tp.parent.parent.parent} apply {patch}`")
        else:
            lines.append("• ⚠️ 补丁文件缺失，需重新生成")
        lines.append("• 影响：长任务收尾 / 旁路请求会再次因字段不兼容 400")
        body = "🛡️【补丁守卫告警：补丁被覆盖】\n━━━━━━━━━━━━━━━━━━━━\n" + "\n".join(lines)
        print(body)
        notify(body)
    else:
        print(f"补丁仍缺失（{status}），{DEDUP_HOURS}h 内已告警过，跳过")

    state["status"] = status
    state["checked_at"] = now.isoformat()
    if status != "ok" and (changed or due):
        state["last_alert_at"] = now.isoformat()
    save_state(state_path, state)
    print(f"检查完成：{status}" + (f"（{detail}）" if detail else ""))
    return 0


if __name__ == "__main__":
    sys.exit(main())
