#!/usr/bin/env python3
"""行为级验收：证明「旁路拼 messages 的补丁」真的改掉了发出去的 payload。

为什么需要这一层：
  - `py_compile` 只证明语法对；
  - 打真实网关只证明「上游现在返回 200」，无法区分是补丁生效还是上游自己好了；
  - 只有**用 mock agent 调用真实函数、抓它实际发出的 kwargs**，才能证明补丁代码路径被执行到。

用法：改下面 CONFIG 区三处（目标函数 / 要断言的 provider host / 期望行为），然后
  python3 verify_bypass_patch_behavior.py
退出码 0 = 全部通过。

本模板 2026-10-24 实测通过：验证 `handle_max_iterations` 是否按 provider 剥离
tool 消息上的 `name`（周三网关 400 `messages.name` 那一类）。
"""
import sys
from unittest.mock import MagicMock

sys.path.insert(0, "/home/ubuntu/.hermes/hermes-agent")

# ============================ CONFIG ============================
from agent.chat_completion_helpers import handle_max_iterations  # noqa: E402

# 命中补丁门控的 provider（会被剥字段的）
TARGET_BASE_URL = "https://<YOUR_PRIVATE_DOMAIN>/v1"
# 不该被影响的 provider（用来证明没误伤）
CONTROL_BASE_URLS = [
    "http://127.0.0.1:8317/v1",
    "https://capy.<PRIVATE_IDENTIFIER>:2087/v1",
]

# 一段含 tool 消息 + user 带 name 的最小历史
HISTORY = [
    {"role": "user", "content": "调用工具"},
    {"role": "assistant", "content": None, "tool_calls": [
        {"id": "call_1", "type": "function",
         "function": {"name": "get_time", "arguments": "{}"}}]},
    {"role": "tool", "tool_call_id": "call_1", "name": "get_time", "content": "12:00"},
    {"role": "user", "name": "lemon", "content": "继续"},
]

# 期望：目标 provider 上 tool 的 name 被剥；user 的 name 一律保留
EXPECT_TARGET_TOOL_NAME = False
EXPECT_CONTROL_TOOL_NAME = True
EXPECT_USER_NAME = True
# ================================================================


def make_agent(base_url):
    """构造一个刚好够 handle_max_iterations 跑完的 mock agent，并捕获发出的请求。"""
    a = MagicMock()
    a.base_url = base_url
    a._base_url_lower = base_url.lower()
    a.model = "test-model"
    a.provider = "custom"
    a.max_tokens = 64
    a.max_iterations = 50
    a.api_mode = "chat_completions"
    a.reasoning_config = None
    a.reasoning_effort = None
    a.ephemeral_system_prompt = ""
    a.prefill_messages = []
    a._cached_system_prompt = "sys"
    a._should_sanitize_tool_calls.return_value = False
    a._copy_reasoning_content_for_api.side_effect = lambda src, dst: None
    a._sanitize_api_messages.side_effect = lambda m: m
    a._drop_thinking_only_and_merge_users.side_effect = lambda m: m
    a._supports_reasoning_extra_body.return_value = False
    a._max_tokens_param.return_value = {"max_tokens": 64}
    a._is_openrouter_url.return_value = False
    a._is_anthropic_oauth = False
    a._anthropic_base_url = None
    a._anthropic_preserve_dots.return_value = False
    a.openrouter_min_coding_score = None
    a.profile_extra_body = None
    a.provider_preferences = None
    a._lm_reasoning_effort = None
    a._resolve_lmstudio_summary_reasoning_effort.return_value = None

    captured = {}

    def fake_create(**kwargs):
        captured.update(kwargs)
        resp = MagicMock()
        resp.choices = [MagicMock()]
        resp.choices[0].message.content = "summary ok"
        resp.choices[0].finish_reason = "stop"
        resp.usage = MagicMock(prompt_tokens=1, completion_tokens=1, total_tokens=2)
        return resp

    client = MagicMock()
    client.chat.completions.create.side_effect = fake_create
    a._ensure_primary_openai_client.return_value = client

    transport = MagicMock()
    transport.normalize_response.side_effect = lambda r, **kw: MagicMock(content="summary ok")
    a._get_transport.return_value = transport
    return a, captured


def check(label, base_url, expect_tool_name):
    agent, captured = make_agent(base_url)
    try:
        handle_max_iterations(agent, [dict(m) for m in HISTORY], api_call_count=50)
    except Exception as exc:
        print(f"[FAIL] {label} -> 调用抛异常: {type(exc).__name__}: {exc}")
        return False

    msgs = captured.get("messages")
    if msgs is None:
        print(f"[FAIL] {label} -> 未捕获到请求（函数没走到 create）")
        return False

    tool_has = any("name" in m for m in msgs if m.get("role") == "tool")
    user_has = any("name" in m for m in msgs if m.get("role") == "user")
    ok = (tool_has == expect_tool_name) and (user_has == EXPECT_USER_NAME)

    print(f"[{'OK' if ok else 'FAIL'}] {label}")
    print(f"       tool 消息带 name={tool_has}（期望 {expect_tool_name}）"
          f" / user 消息保留 name={user_has}（期望 {EXPECT_USER_NAME}）")
    return ok


def main():
    results = [check("目标 provider（应剥离）", TARGET_BASE_URL, EXPECT_TARGET_TOOL_NAME)]
    for url in CONTROL_BASE_URLS:
        results.append(check(f"对照 provider {url}（应保留）", url, EXPECT_CONTROL_TOOL_NAME))
    print("\n行为级验收:", "全部通过" if all(results) else "存在失败")
    return 0 if all(results) else 1


if __name__ == "__main__":
    sys.exit(main())
