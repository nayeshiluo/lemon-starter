#!/usr/bin/env python3
"""Offline production-patch checks; no live models, messages or runtime writes."""
import argparse
import ast
import asyncio
import collections
import json
import os
import sys
import subprocess
import tempfile
import threading
import time
import uuid
from datetime import datetime
from pathlib import Path
from types import SimpleNamespace
from typing import Any
from unittest.mock import Mock, patch


def privacy():
    from agent.local_telegram_access_alerts import AccessAlerts
    with tempfile.TemporaryDirectory() as tmp:
        path = Path(tmp) / 'alerts.json'
        alerts = AccessAlerts(SimpleNamespace(), path)
        alerts.pending['dm:123'] = dict(id='a'*16, created_at=time.time(),
            next_attempt=time.time(), attempts=1, text='用户 ID：123\n内容：PRIVATE_PROBE_TEXT\n处理：已拒绝')
        assert alerts._save()
        assert 'PRIVATE_PROBE_TEXT' not in path.read_text()
        assert 'PRIVATE_PROBE_TEXT' in alerts.pending['dm:123']['text']
        restored = AccessAlerts(SimpleNamespace(), path)
        assert '摘要未保存' in restored.pending['dm:123']['text']


def expiry():
    from cron import jobs, scheduler
    at = datetime.fromisoformat('2030-12-01T00:00:00+08:00')
    with tempfile.TemporaryDirectory() as tmp, jobs.use_cron_store(tmp), patch.object(jobs, '_hermes_now', return_value=at):
        entry = dict(id='expiry-probe', enabled=True, state='scheduled',
            schedule={'kind':'cron','expr':'0 17 * * *'},
            expires_at=at.isoformat(), next_run_at=at.isoformat(),
            repeat={'times':33,'completed':1}, last_status='error', last_error='history')
        jobs.save_jobs([entry])
        assert jobs.get_due_jobs() == []
        saved = jobs.get_job(entry['id'])
        assert saved['state'] == 'paused' and saved['last_error'] == 'history'
        called = Mock(side_effect=AssertionError('expired job executed'))
        with patch.object(scheduler, 'run_job', called), patch.object(scheduler, 'create_execution', return_value={'id':'probe'}), patch.object(scheduler, 'finish_execution'):
            assert scheduler.run_one_job(dict(entry, expires_at=None))
        called.assert_not_called()
        assert jobs.get_job(entry['id'])['repeat']['completed'] == 1


def auxiliary_http():
    import httpx
    import yaml
    from agent import auxiliary_client as ac
    with tempfile.TemporaryDirectory() as tmp, patch.dict(os.environ, {'HERMES_HOME':tmp}):
        config = {'custom_providers':[{'name':n,'base_url':f'https://{n}.invalid/v1','api_key':'offline-probe'} for n in ['primary','backup']],
            'auxiliary':{'transient_retries':1,'vision':{'fallback_chain':[{'provider':'custom:backup','model':'backup-probe'}]}}}
        (Path(tmp)/'config.yaml').write_text(yaml.safe_dump(config))
        calls = collections.Counter()
        def respond(request):
            assert request.url.host in ['primary.invalid','backup.invalid']
            calls[request.url.host] += 1
            if request.url.host == 'primary.invalid':
                return httpx.Response(504,json={'error':{'message':'offline simulated failure'}})
            return httpx.Response(200,json={'id':'probe','object':'chat.completion','created':1,'model':'backup-probe',
                'choices':[{'index':0,'finish_reason':'stop','message':{'role':'assistant','content':'OK'}}]})
        def clients(base_url, *, async_mode=False):
            cls = httpx.AsyncClient if async_mode else httpx.Client
            return {'http_client':cls(transport=httpx.MockTransport(respond))}
        with patch.object(ac, '_openai_http_client_kwargs', clients), patch.object(ac,'_TRANSIENT_RETRY_BACKOFF_BASE',0):
            for async_mode in [False,True]:
                ac._client_cache.clear(); ac._aux_unhealthy_until.clear(); calls.clear()
                kw = dict(task='vision',provider='custom:primary',model='primary-probe',messages=[{'role':'user','content':'offline check'}])
                result = asyncio.run(ac.async_call_llm(**kw)) if async_mode else ac.call_llm(**kw)
                assert result.choices[0].message.content == 'OK'
                assert calls == {'primary.invalid':2,'backup.invalid':1}


def webui_approval(path):
    # Execute the installed callback method with a fake pool, without importing
    # its worker bootstrap or creating a real bridge/session/approval.
    tree = ast.parse(Path(path).read_text())
    cls = next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='AgentPool')
    method = next(n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name=='_gateway_approval_notify')
    namespace = {'Any':Any,'uuid':uuid,'_approval_pattern_keys':lambda data:[]}
    exec(compile(ast.fix_missing_locations(ast.Module(body=[method],type_ignores=[])),str(path),'exec'),namespace)
    for data,expected in [({'_request_id':'underscored'},'underscored'),({'request_id':'legacy'},'legacy'),({'request_id':'first','_request_id':'second'},'first')]:
        events=[]
        pool=SimpleNamespace(_lock=threading.Lock(),_sessions={'session':SimpleNamespace(current_run_id='run')},
            _gateway_approval_requests={},_gateway_approval_pattern_keys={},_append_event=lambda *a:events.append(a))
        namespace['_gateway_approval_notify'](pool,'session')(data)
        assert list(pool._gateway_approval_requests.values())==[('session','run',expected)]
        assert events[0][1]['event']=='approval.requested'


def whole_patch(repo, patch_path):
    # Check applicability only. Never apply/revert code or discard local edits.
    assert Path(patch_path).is_file()
    result = subprocess.run(['git','-C',str(repo),'apply','--reverse','--check',str(patch_path)],
                            capture_output=True,timeout=20)
    assert result.returncode == 0, 'installed source requires patch review'


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('case',choices=['privacy','expiry','auxiliary_http','webui_approval','whole_patch'])
    parser.add_argument('--repo',default='/home/ubuntu/.hermes/hermes-agent')
    parser.add_argument('--bridge',default='/usr/local/lib/node_modules/hermes-web-ui/dist/server/agent-bridge/python/bridge_pool.py')
    parser.add_argument('--patch',default='/home/ubuntu/.hermes/patches/production-20261028-v2/production.patch')
    args=parser.parse_args();sys.path.insert(0,args.repo)
    try:
        if args.case=='webui_approval':webui_approval(args.bridge)
        elif args.case=='whole_patch':whole_patch(args.repo,args.patch)
        else:globals()[args.case]()
    except Exception as exc:
        print('FAIL',args.case,type(exc).__name__)
        return 1
    print('PASS',args.case)
    return 0


if __name__=='__main__':
    raise SystemExit(main())
