#!/usr/bin/env python3
"""patch_guard 多目标守卫的行为回归：9 条路径 + 上游覆盖只读预演。

用法：
    python3 verify_patch_guard.py                  # 只跑行为用例（默认配置）
    python3 verify_patch_guard.py --upstream       # 追加「上游覆盖后是否会告警」预演
    python3 verify_patch_guard.py --config X --script Y --repo Z

安全承诺：配置副本 / state / 通知桩全部落在临时目录，
**绝不触碰真实 state，也绝不打真实 notify**（否则一次验收就给管理员发 9 条假告警）。

判读：全 ✅ 才算验收通过。任何 ❌ 会打印该用例的完整输出，方便定位。
"""
import argparse
import copy
import json
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
DEFAULT_SCRIPT = HERE / "patch_guard.py"
DEFAULT_CONFIG = Path("/home/ubuntu/hermes-jobs/patch-guard.json")

# notify() 用 subprocess.run(..., stdout=DEVNULL) 调子进程，
# 桩往 stdout 打印会被吞掉 → 测试误判「没发通知」。必须写文件。
STUB = (
    "import sys, pathlib\n"
    "pathlib.Path({log!r}).open('a', encoding='utf-8')"
    ".write(sys.argv[1] + '\\n===SPLIT===\\n')\n"
)


def pick(targets, needle, fallback):
    """按路径/名字里的关键词挑目标，避免依赖 targets 数组的下标顺序。"""
    for i, t in enumerate(targets):
        if needle in (t.get("path") or "") or needle in (t.get("name") or ""):
            return i
    return fallback if fallback < len(targets) else None


def upstream_preflight(cfg, repo, targets):
    """只读预演：把每个目标换成 upstream/main 版本，断言守卫仍会告警。

    这是整套验收里最有说服力的一步——不碰工作区，直接证明「真跑一次
    hermes update，这 N 个目标全都会被报出来」。
    """
    print("\n=== 上游覆盖只读预演 ===")
    repo = (repo or "").rstrip("/")
    if not repo:
        print("⏭ 未配置 repo，跳过")
        return True
    probe = subprocess.run(["git", "-C", repo, "rev-parse", "--verify", "upstream/main"],
                           capture_output=True, text=True)
    if probe.returncode != 0:
        print("⏭ 本地没有 upstream/main 引用（先 git fetch upstream），跳过"
              " —— 注意不要因此当成通过")
        return True
    all_ok, fired = True, 0
    for t in targets:
        path = (t.get("path") or "").replace("\\", "/")
        name = t.get("name") or path
        if not path.startswith(repo + "/"):
            print(f"⏭ {name}: 不在 repo 内，跳过")
            continue
        rel = path[len(repo) + 1:]
        show = subprocess.run(["git", "-C", repo, "show", f"upstream/main:{rel}"],
                              capture_output=True, text=True)
        if show.returncode != 0:
            print(f"✅ {name}: 上游无此文件 → 更新即消失（会告警）")
            fired += 1
            continue
        markers = t.get("markers") or {}
        missing = [k for k, v in markers.items() if v not in show.stdout]
        if missing:
            print(f"✅ {name}: 上游缺 {len(missing)}/{len(markers)} 个标记（会告警）")
            fired += 1
        else:
            print(f"❌ {name}: 上游已含全部标记 → 守卫不会告警（漏守，或已被上游合并）")
            all_ok = False
    print(f"→ {fired}/{len(targets)} 个目标在上游覆盖后会告警")
    return all_ok


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default=str(DEFAULT_CONFIG))
    ap.add_argument("--script", default=str(DEFAULT_SCRIPT))
    ap.add_argument("--upstream", action="store_true", help="追加 upstream/main 覆盖预演")
    ap.add_argument("--repo", default="")
    args = ap.parse_args()

    base = json.loads(Path(args.config).read_text(encoding="utf-8"))
    targets = base.get("targets")
    if not targets:
        print("✗ 配置里没有 targets —— 这是单目标 v1 配置，多目标用例无从展开")
        return 2

    repo = args.repo or base.get("repo") or ""
    tmp = Path(tempfile.mkdtemp(prefix="pgverify-"))
    state = str(tmp / "state.json")
    log = str(tmp / "notify.log")
    notify = tmp / "notify.py"
    notify.write_text(STUB.format(log=log), encoding="utf-8")

    def run(cfg, label, expect_notify, must_contain=()):
        cfg_path = tmp / "cfg.json"
        cfg_path.write_text(json.dumps(cfg, ensure_ascii=False), encoding="utf-8")
        before = os.path.getsize(log) if os.path.exists(log) else 0
        proc = subprocess.run([sys.executable, args.script, "--config", str(cfg_path)],
                              capture_output=True, text=True,
                              env={**os.environ, "PATCH_GUARD_NOTIFY": str(notify)})
        after = os.path.getsize(log) if os.path.exists(log) else 0
        fired = after > before
        out = proc.stdout + proc.stderr
        missing = [k for k in must_contain if k not in out]
        ok = (fired == expect_notify) and proc.returncode == 0 and not missing
        print(("✅ " if ok else "❌ ") + label
              + f"  [通知={fired} 期望={expect_notify}"
              + (f" 缺={missing}" if missing else "") + "]")
        if not ok:
            for line in out.strip().splitlines():
                print("     " + line)
        return ok

    i_group = pick(targets, "local_group_policy", 0)
    i_adapter = pick(targets, "adapter.py", 1)
    i_cred = pick(targets, "session_credentials", 2)
    results = []

    # A 全绿 → 静默
    cfg = copy.deepcopy(base); cfg["state"] = state
    results.append(run(cfg, "A 首次全绿：静默", False, ["检查完成：ok"]))

    # B 单目标坏 → 告警且点名
    cfg = copy.deepcopy(base); cfg["state"] = state
    if i_group is not None:
        cfg["targets"][i_group].setdefault("markers", {})["故意坏标记"] = "NEEDLE_A_42"
        results.append(run(cfg, "B 单个目标标记缺失：告警且点名", True,
                           [cfg["targets"][i_group].get("name") or ""]))

        # C 同一失败集合再跑 → 去重静默
        results.append(run(cfg, "C 同一失败集合重复：12h 内静默", False, ["跳过"]))

        # D 再坏一个 → 整体仍 broken 也必须再告警（v1 去重键的经典漏报）
        if i_adapter is not None:
            cfg2 = copy.deepcopy(cfg)
            cfg2["targets"][i_adapter].setdefault("markers", {})["故意坏标记"] = "NEEDLE_B_99"
            results.append(run(cfg2, "D 又坏一个：失败集合变了必须再告警", True,
                               ["受影响项：2"]))

    # E 全部恢复 → 恢复通知
    results.append(run(base | {"state": state}, "E 全部恢复：发恢复通知", True,
                       ["补丁已恢复"]))

    # F import 探针失败 → 点名模块
    cfg3 = copy.deepcopy(base); cfg3["state"] = state
    cfg3["imports"] = list(base.get("imports") or []) + ["agent.gone_xyz"]
    results.append(run(cfg3, "F 本地模块 import 失败：点名模块", True,
                       ["agent.gone_xyz", "import 失败"]))

    # G 目标文件消失
    if i_cred is not None:
        cfg4 = copy.deepcopy(base); cfg4["state"] = state
        cfg4["targets"][i_cred]["path"] = str(tmp / "nope.py")
        results.append(run(cfg4, "G 目标文件不存在：missing_file", True, ["missing_file"]))

    # H 门控域名已不在配置里 → gate_unused
    if base.get("gates"):
        cfg5 = copy.deepcopy(base); cfg5["state"] = state
        cfg5["gates"][0]["domain"] = "api.retired-gateway.invalid"
        results.append(run(cfg5, "H 门控域名失效：gate_unused", True, ["gate_unused"]))
    else:
        print("⏭ H 未配置 gates，跳过")

    # I 旧单目标配置向后兼容
    legacy = {"target": targets[0]["path"],
              "markers": dict(list((targets[0].get("markers") or {}).items())[:1]),
              "state": str(tmp / "state_old.json")}
    if legacy["markers"]:
        results.append(run(legacy, "I 旧单目标配置向后兼容", False, ["ok（1 目标"]))

    if args.upstream:
        results.append(upstream_preflight(base, repo, targets))

    passed = sum(results)
    total = len(results)
    print(f"\n{'全部通过' if passed == total else '有失败'}：{passed}/{total}")
    if passed == total:
        shutil.rmtree(tmp, ignore_errors=True)
    else:
        print(f"现场保留（含通知桩与配置副本）：{tmp}")
    return 0 if passed == total else 1


if __name__ == "__main__":
    sys.exit(main())
