# 旁路请求漏剥 provider 字段 → 长任务收尾必然 400

**指纹**：日常对话完全正常，**只有撞到工具调用上限 / 长任务收尾 / 标题生成时**报
`HTTP 400 服务器不支持参数 messages.name`（或同类 schema 字段），总结丢失。

2026-10-24 实录。主模型 `gemini-3.8-flash-high`，provider `custom:反重力`（`127.0.0.1:8317`）；
出问题的会话实际走的是 `周三`（`<YOUR_PRIVATE_DOMAIN>`）。

## 症状长这样

```
You've reached the maximum number of tool-calling iterations allowed.
Please provide a final response summarizing what you've found...
```

然后那条「收尾总结」本身炸掉，用户看到的是：

```
I reached the maximum iterations (50) but couldn't summarize.
Error: Error code: 400 - {'error': {'message': '服务器不支持参数 messages.name，
请删除该参数或改用受支持的字段。（错误码：invalid_request；请求编号：req_xxx）',
'type': 'invalid_request_error', 'param': 'messages.name', 'code': 'invalid_request'}}
```

⚠️ **别被这段文案带偏**：它长得像「会话被强制结束」，实际是**收尾请求被上游拒了**。
会话内容没丢，丢的是那次总结。

## 根因链

1. 网关 `周三` 拒绝 **role=tool 消息上的 `name` 键**（user/assistant 带 name 是 200，实测见下）。
2. **主循环**走 `agent/transports/chat_completions.py`，那里有硬编码 host 白名单：
   ```python
   strip_tool_result_name = (
       urlsplit(str(kwargs.get("base_url") or "")).hostname == "<YOUR_PRIVATE_DOMAIN>"
   )
   ...
   if strip_tool_result_name and msg.get("role") == "tool" and "name" in msg:
       mutable_msg().pop("name", None)
   ```
   所以日常多轮工具调用一直没事。
3. **迭代上限摘要路径**（`agent/chat_completion_helpers.py::handle_max_iterations`）**绕过 transport**，
   自己 `msg.copy()` 逐个手工拼 `api_messages`，剥除清单只有
   `tool_name` / `codex_reasoning_items` / `codex_message_items` / `timestamp` / `api_content` / `_` 前缀键，
   **没有 `name`** → tool 消息的 `name` 一路带上线 → 400 → 整个收尾失败。

日志里同一报错累计 11 次（`grep -c "messages.name" ~/.hermes/logs/agent.log`），
形态固定为 `agent.chat_completion_helpers: Failed to get summary response: Error code: 400`。

**这一类 bug 的通用形态**：Hermes 里凡是「不走 transport、自己拼 messages 直调
`chat.completions.create()`」的旁路（迭代上限摘要、标题生成、vision、compression），
都会漏掉 transport 里那些 provider 特定的字段剥除。遇到「主链路好、辅助链路炸」，
先去找旁路构造 messages 的地方，不要去怀疑模型或 key。

## 第一步：先确认是哪个 provider（别猜）

```python
import sqlite3
con = sqlite3.connect('/home/ubuntu/.hermes/state.db'); con.row_factory = sqlite3.Row
for r in con.execute(
    "SELECT model, billing_provider, billing_base_url, task, api_call_count, last_seen "
    "FROM session_model_usage WHERE session_id=? ORDER BY last_seen DESC", ('<sid>',)):
    print(dict(r))
```

`billing_base_url` 才是真线路（`billing_provider` 常常只写 `custom`）。
再拿 host 到 `config.yaml` 的 `custom_providers` 对号入座。
**provider 显示名会漂移**（同一 host 叫过 `ikun撸时涵` 又叫 `周三`），判定一律以 host 为准。

## 第二步：字段×角色探针矩阵（唯一能定案的方法）

不要凭报错文案猜是哪个字段、哪个角色。跑 `scripts/provider_field_probe.py`，四组用例：

| 用例 | 期望（本例实测） |
|---|---|
| A 基线（无 name） | 200 |
| B tool 消息带 name | **400 `messages.name`** |
| C user 消息带 name | 200 |
| D assistant 消息带 name | 200 |

关键结论：**只有 tool 角色不认**。所以修法必须**只剥 tool 的 name**，
一刀切剥所有 name 会掩盖问题、也可能破坏别家网关的语义。

同样的矩阵也能用来定案 `thinking` / `reasoning_effort` / `extra_body` / `timestamp`
等其它「网关不认某字段」的问题——**换字段名，不动结构**。

## 第三步：补丁（最小改动，只剥 tool 的 name）

`agent/chat_completion_helpers.py`，在 `handle_max_iterations` 里手工拼 `api_messages`
的那个循环上加门控，**与 transport 用完全相同的 host 判据**：

```python
from urllib.parse import urlsplit          # 文件顶部，先确认没重复导入

# 循环外算一次
strip_tool_result_name = (
    urlsplit(str(agent.base_url or "")).hostname
    == "<YOUR_PRIVATE_DOMAIN>"
)

# 循环内，紧跟现有 schema_foreign 剥除之后
# Mirror ChatCompletionsTransport.strip_tool_result_name because the
# summary path bypasses the transport.
if strip_tool_result_name and msg.get("role") == "tool":
    api_msg.pop("name", None)
```

要点：
- 门控条件**照抄 transport**，不要自己发明（否则两处行为不一致，下次更难查）。
- 放在**首轮与重试共用的那个循环**里，一次覆盖两条路径。
- 只剥 `role == "tool"`，不碰 user/assistant。
- 其它 provider 行为零变化。

## 第四步：验收（必须打到真实网关，不能只 py_compile）

```bash
python3 -m py_compile agent/chat_completion_helpers.py
git diff --check && git status --porcelain     # 期望只有这一个文件
```

然后跑**对照组 + 补丁组**（`scripts/provider_field_probe.py --verify`）：
- 不剥 name → 必须 **400**（复现原 bug，证明问题真实存在）
- 剥 name → 必须 **200**
- 非目标 provider（如反重力）的 tool name **仍然保留** → 证明没误伤
- 目标网关下 user 的 name **仍然保留** → 证明没误剥

只验「补丁后 200」不验「补丁前 400」的话，无法排除是上游自己好了。

### 第三层：行为级验收（证明补丁代码路径真的被执行）

上面两层有个共同盲区：**它们测的是「网关现在收不收这个字段」，不是「我们的代码还发不发这个字段」**。
上游某天自己放宽了校验，对照组也会 200，看着像"补丁生效"，其实补丁早被升级覆盖了。

所以要有一层直接抓 payload：用 mock agent 调**真实的** `handle_max_iterations`，断言它实际发出的
`kwargs["messages"]`。见 `scripts/verify_bypass_patch_behavior.py`（改三处 CONFIG 即可复用）：

| 断言 | 期望 |
|---|---|
| 目标 provider 的 tool 消息不带 `name` | `False` |
| 对照 provider 的 tool 消息仍带 `name` | `True`（证明没误伤） |
| 所有 provider 的 user 消息仍带 `name` | `True`（证明没误剥） |

关键实现点：`MagicMock` 自动满足 agent 那一堆属性，只需把
`_ensure_primary_openai_client.return_value.chat.completions.create` 换成捕获 kwargs 的假函数，
`_get_transport().normalize_response` 返回带 `.content` 的对象即可。

**这一层必须在上游还没修好、或你不确定补丁是否被覆盖时跑**——它是唯一能区分
「补丁在起作用」和「上游自己变宽容了」的手段。

## 第五步：改的是 Hermes 安装目录 → 必须防升级覆盖

这是改在 `~/.hermes/hermes-agent/` 里的，**`hermes update` 会覆盖掉**。三条配套：

1. **留补丁文件**：`git diff -- agent/chat_completion_helpers.py > <backup>/xxx.patch`，
   并 `git apply --reverse --check <patch>` 验证反向可应用（回滚路径有效）。
2. **留原文件**：`cp -av` 带时间戳的 `.bak`。
3. **挂守卫**：每日检查源码里那几条标记还在不在，丢了就告警 + 给出重放命令。
   见 `scripts/patch_guard.py`（正常静默、12h 去重、恢复发通知）。

**落地形态（2026-10-24 实测）**：守卫用 **systemd timer** 而非 crontab（`Persistent=true` 宕机补跑、
`RandomizedDelaySec` 避整点、`Nice=10` + `IOSchedulingClass=idle` 不抢业务）。脚本本体留在技能目录、
部署侧只放 `patch-guard.json`（`target`/`patch`/`repo`/`state`/`markers`），service 指向技能脚本 +
`--config` —— 单一来源，技能改进自动生效，不会出现「技能模板 vs 线上副本」两份代码分叉。
`repo` 必须显式配，否则重放命令会靠 `parent×3` 猜仓库根。

## 第六步：重启生效 + 行为级终验（缺一不算修完）

补丁落盘后运行中的进程仍是旧代码。重启前先说清影响（短暂中断 Telegram / 当前 CLI 会话可能断），
拿到许可再动：

```bash
systemctl show hermes-gateway.service -p MainPID -p ExecMainStartTimestamp  # 记旧 PID
sudo -n systemctl restart hermes-gateway.service
sleep 12
systemctl show hermes-gateway.service -p MainPID -p ActiveState -p SubState -p NRestarts
```

⚠️ **日志里那句 `Failed with result 'exit-code'` 是重启前旧进程的退出记录，不是新进程崩溃**。
判新进程健康看三样：`SubState=running` 稳定不掉、`NRestarts=0`、`ss -tnp | grep <新PID>` 有到上游的 ESTAB
（Telegram 平台是 `<YOUR_SERVER_IP>:443`）。别拿旧日志当新故障汇报。

生效链路可自证：源文件 mtime → `__pycache__/*.pyc` mtime（且二进制含补丁标记字符串）→ 进程启动时间，
三者时间递增即证明加载的是含补丁代码：

```bash
TZ=UTC stat -c '%y %n' agent/chat_completion_helpers.py agent/__pycache__/chat_completion_helpers*.pyc
TZ=UTC ps -o lstart= -p <新PID>
python3 -c "import glob;[print(f, b'strip_tool_result_name' in open(f,'rb').read()) for f in glob.glob('agent/__pycache__/chat_completion_helpers*.pyc')]"
```

最后跑行为级验收（`scripts/verify_bypass_patch_behavior.py`）三 provider 对照，全绿才算收工。

## Pitfalls

- **不要为了「让收尾能跑」去切模型或改 fallback 链**。问题在字段协议层，换模型只是掩盖，
  下次换回同一个网关照样炸。
- **不要在 gateway 未重启时宣布「已修复」**。补丁落盘 ≠ 生效，运行中的进程还是旧代码。
  汇报口径必须是「补丁已就位并验证，**等重启生效**」，并问用户何时重启（会短暂中断 Telegram）。
- **摘要路径的报错会被记成 WARNING 而非 ERROR**，`grep ERROR` 找不到，要按
  `Failed to get summary response` 搜。
- **别把 `messages.name` 与 `tool_calls[].function.name` 混为一谈**：后者是正常必需字段，
  永远不能剥；报错里的 `param: messages.name` 指的是消息级 `name`。
