# 监控探针自身漂移：`🛡 Ad Killer 仍未恢复` 持续告警实录（2026-10-28）

告警原文：

```
🛡 Ad Killer 仍未恢复（持续告警）
主机：vps-la   时间：2026-10-28 08:04:13 CST
• [P1] 连不上 vps-la：SSH 退出码 255
排查：ssh vps-la 'systemctl status ad-killer'
恢复：ssh vps-la 'systemctl restart ad-killer'
```

**结论：服务没挂，是监控探针连错端口。** 一条告警背后同时藏着 3 个独立问题，只有 1 个是告警说的那个。

## 1. 告警源与判定口径

`/home/ubuntu/lemon-ops-bot/main.py` 第 2659-2864 行：

| 常量 | 值 |
|---|---|
| `ADK_WATCH_STATE_PATH` | `/home/ubuntu/lemon-ops-bot/.ad_killer_watch_state.json` |
| `ADK_WATCH_INTERVAL` | 600s（启动后 90s 首检） |
| `ADK_REMIND_INTERVAL` | 6h 复提醒 |
| `ADK_SSH_KEY` | `/home/ubuntu/.ssh/lemon_racknerd_admin` |
| `ADK_HOST` | 原 `root@<PRIVATE_IDENTIFIER>` → 已改 `vps-la` |

`probe_ad_killer()` 用 `ssh -i <key> -o IdentitiesOnly=yes -o BatchMode=yes -o StrictHostKeyChecking=yes -o ConnectTimeout=8 <ADK_HOST> "sh /opt/ad-killer/ops_probe.sh"`，30s 超时，任何非 0 退出码都降级成 `reachable: False`。

P1：`service != active` 或 `heartbeat != alive`。P2：`cleanup != active`、`ai_errors_30m > 0`、磁盘 ≥90%、DB 快照 >48h、AWS 异地副本 >48h。

## 2. 根因 A（告警真正原因）：SSH 端口漂移

vps-la 的 SSH 已从 22 改到 **2222**（22 被国内封），但 `ADK_HOST` 仍是裸 IP 且调用里没有 `-p`：

```
ssh: connect to host <PRIVATE_IDENTIFIER> port 22: Connection refused   → exit 255
```

监控于是每 10 分钟稳定产出一次 P1「连不上」，而实际 `ssh vps-la 'sh /opt/ad-killer/ops_probe.sh'` 秒回正常。

修法（单一来源，别在代码里再写死端口）：

```python
ADK_HOST = "vps-la"   # ~/.ssh/config: HostName <PRIVATE_IDENTIFIER> / Port 2222
```

改完 `python3 -m py_compile main.py && sudo systemctl restart lemon-ops`，等 90s 首检，看 `.ad_killer_watch_state.json` 是否 `status: ok`，journal 是否出现 `ad-killer watch: sent ok alert`。

**同类 bug 一并扫**：`grep -rn 'root@{VPS_HOST}\|root@198\.' /home/ubuntu/lemon-ops-bot/*.py`。本次扫出 `vps_video_module.py` 三处（`get_vps_disk_stat` / `du -sB1` / `rm -rf`）同样裸 IP 无端口，全部补 `"-p", "2222"`。`emos_service.py`、`query_contact_alerts.py` 已用别名，是对的参照。

## 3. 根因 B（真实故障）：`Requires=` 不传播 start

`ad-killer-cleanup-worker.service` 已停 **22 小时**：

```
Active: inactive (dead) since 2026-10-27 01:35:02 UTC
Main PID: 2080931 (code=killed, signal=TERM)
```

journal 对照发现是**远程 `systemctl restart ad-killer`** 引起的（同一秒 sshd 接受了来自 `<YOUR_SERVER_IP>` 的 root key，随后主服务起、worker 没起）。

机制：worker 上写的是 `Requires=ad-killer.service` + `After=`，只声明了「主服务停我也停」，**没有声明「主服务起我也起」**。`WantedBy=multi-user.target` 只在开机时生效。

修法（主服务侧加 drop-in，最小改动）：

```ini
# /etc/systemd/system/ad-killer.service.d/10-cleanup-worker.conf
[Unit]
Wants=ad-killer-cleanup-worker.service
```

`systemctl daemon-reload && systemctl restart ad-killer` 后两者都 `active` —— 实测 restart 主服务会把 worker 一起拉起来。
（只给 worker 加 `PartOf=ad-killer.service` 不够：主服务 restart 时 worker 若已 inactive，PartOf 不会把它启动。）

## 4. 根因 C（真实故障）：AI 审核后端端口空了

现象：`/var/log/ad-killer/bot.log` 里 5 条 `WARNING ai_review_failed reason=model_transport_failed`（06:57 / 07:13 / 07:17 / 07:33 / 08:13 CST）。

链路取证：

```
curl 127.0.0.1:18318/v1/models  → exit 7 连接被拒（无任何监听）
curl 127.0.0.1:18317/v1/models  → {"code":"request_failed","error":"dial tcp 127.0.0.1:18318: connect: connection refused"}
```

`18317` 是 `cpa-manager-plus`（面板/代理），**它自己就是往 18318 拨的**——18318 是早已消失的 CPA 核心。所以「ad-killer 由本地 cpa-manager-plus 供 AI」这个历史结论只在核心还活着时成立。

修法：指向本机自建的 wb2api（`127.0.0.1:7863`，OpenAI 兼容）。

```python
# /etc/ad-killer/config.json 的 ai 段
{"base_url": "http://127.0.0.1:7863/v1", "model": "global:default-model", "enabled": true}
```

密钥位置：`ai.py` 的 key **不在 config.json 里**，而是 `$CREDENTIALS_DIRECTORY/ai-key`（`LoadCredential=ai-key:/etc/ad-killer/ai-key`），所以要同时覆盖 `/etc/ad-killer/ai-key`，再 `systemctl restart ad-killer` 让凭据快照重建。验收：读 `/run/credentials/ad-killer.service/config.json` 与 `ai-key` 长度，确认运行中的是新闻值。

## 5. 换模型前的两个硬约束（`/opt/ad-killer/ai.py`）

- `parse_review()` 要求 `label ∈ {spam, normal, uncertain}`，且 `reason` / `observed_text` 必须存在；` ```json ` 围栏会自动剥掉，JSON 前后带围栏不是问题。
- `max_tokens=700`、`temperature=0`、`timeout=20`。**推理模型会把 700 token 全烧在 `reasoning_content` 上、`content` 返回空串** → `invalid_response`。优先选 `supports_reasoning=false` 的模型或路由器别名。
- `AIClient.__init__` 只允许 `https://` 或 `http://127.0.0.1`（`endpoint_requires_https`），所以本机端口直连是合规路径。

**实测矩阵（vps-la wb2api，2026-10-28）**：

| model | 结果 |
|---|---|
| `global:gemini-3.5-flash` / `3.8-flash` | 503 `no_healthy_account` → 上游 `code:11158` `personal_free_user` 不支持 |
| `global:o4-mini` / `global:auto-chat` | 400 `model_unavailable`（该后端无此模型） |
| `cn:deepseek-v4.1-flash` / `cn:glm-5.3-flash` | 200，但 `content` 空、全在 reasoning（max_tokens 小时必炸） |
| **`global:default-model`** | **200，1.6-1.9s，JSON 正常** ✅ |

## 6. 验收必须走「服务自己的客户端」

不要只用 `curl` 打 `/v1/models` 就算修好。用 ad-killer 自己的 `AIClient` + 真实 `PROMPT` 跑一条文本评审：

```python
import sys, time; sys.path.insert(0, "/opt/ad-killer")
from ai import AIClient, ReviewError
c = AIClient({"base_url": "http://127.0.0.1:7863/v1", "model": "global:default-model"}, key)
for txt in ["加V看片 t.me/xxx 每日更新", "今晚八点老地方开黑，带好装备"]:
    t0 = time.time()
    try: print(time.time()-t0, c.review({"text": txt}, api_stub))   # 文本消息不会触发图片下载
    except ReviewError as e: print("ERROR", e)
```

预期 `spam` / `normal`，1-2s。这一层能同时验掉端点、key、模型、prompt 契约与解析。

## 7. 两个「看着已经好了」的假象

- **`ai_errors_30m` 是滑动 30 分钟窗口**：修完立刻读到 `0` 可能只是旧错误滑出窗口，不构成修复证据。要拿 `bot.log` 里**新增的 `ai_review`（成功）行**或上面那条 AIClient 实测当正证。群安静时可能几小时没有真实评审，如实写「等第一条广告消息确认」。
- **`ops_probe.sh` 在 cleanup 非 active 时会多吐一行 `unknown`**：`CLEANUP=$(systemctl is-active ... || echo unknown)` 把 `is-active` 的 stdout 和兜底 echo 都留下了。key=value 解析能容忍，但按行号取值会错位。

## 8. 一次性验收清单

```bash
ssh vps-la 'sh /opt/ad-killer/ops_probe.sh'          # SNAP/CLEANUP/DISK/BKAGE/BKCOUNT
ssh vps-la 'systemctl is-active ad-killer ad-killer-cleanup-worker'
ssh vps-la 'systemctl restart ad-killer && sleep 5 && systemctl is-active ad-killer-cleanup-worker'  # 验 Wants 生效
cat /home/ubuntu/lemon-ops-bot/.ad_killer_watch_state.json   # 期望 {"status":"ok",...}
ls -lt /home/ubuntu/backups/ad-killer-offsite/ | head -3      # 异地副本 <48h
```
