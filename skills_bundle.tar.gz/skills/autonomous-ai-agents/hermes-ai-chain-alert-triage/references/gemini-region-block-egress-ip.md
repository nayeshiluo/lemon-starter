# Gemini 全家族 400「User location is not supported」= 出口 IP 地区限制

2026-11-03 实测。**这是「某个模型突然全挂、但同渠道别的模型全好」时的首选排查方向。**

## 症状

- 所有 `gemini-*` 模型一律 `HTTP 400`：
  ```json
  {"error":{"code":400,"message":"User location is not supported for the API use.","status":"FAILED_PRECONDITION"}}
  ```
- **同一个网关、同一批账号下，`claude-*` / `gpt-*` 全部 200 正常**
- 报错耗时恒定 ~1s（不是超时，是立刻拒绝）
- 群里表现：AI 问答显示的模型从 Gemini 变成后面的兜底节点

## 最容易走错的两个方向

1. **以为是渠道/账号整体失效** —— 因为 Gemini 和 Claude 在 antigravity 里**确实共用同一批 Google 账号、同一个端点**。看 `~/.cli-proxy-api/antigravity-*.json` 的 `antigravity_capability_hints`：
   ```json
   {"endpoint":"https://daily-cloudcode-pa.googleapis.com",
    "model_ids":["claude-sonnet-4-6","gemini-3-flash","gemini-3.8-flash-high", ...]}
   ```
   同一份 model_ids 里既有 Claude 也有 Gemini。所以「同渠道应该一起挂」的直觉是合理的，但它不成立：**Google 在同一个端点内部对不同模型家族套不同准入策略** —— Gemini 走自家服务（带 IP 地区校验），Claude 走转售 Anthropic 通道（不套该策略）。

2. **以为是模型名写错** —— 直接 `POST {endpoint}/v1internal:generateContent` 手动拼请求时，Gemini 会返回 `404 Requested entity was not found`，看着像模型不存在。实际是请求包装格式不对（CLIProxyAPI 有自己的构造方式）。**别用手工请求的 404 去否定模型存在**，要看网关 `/v1/chat/completions` 的 400。

## 判定方法：控制变量，只换出口 IP

同一批账号、同一份配置、同一个二进制，只改出口：

```bash
# 1) 确认可用代理出口（本机 1081 = vps-la socks5，来自 lemon-qb-tunnel-la）
curl -s --socks5-hostname 127.0.0.1:1081 https://api.ipify.org

# 2) 起独立实例（改端口，不动生产 8317），走代理出口
cp /home/ubuntu/cliproxyapi/config.yaml /tmp/cpa-test/config.yaml
sed -i 's/^port: 8317/port: 8399/' /tmp/cpa-test/config.yaml
HTTPS_PROXY=socks5h://127.0.0.1:1081 HTTP_PROXY=socks5h://127.0.0.1:1081 \
  /home/ubuntu/cliproxyapi/cli-proxy-api -config /tmp/cpa-test/config.yaml &

# 3) 同一批模型分别打直连实例和生产实例，对比
#    gemini 走代理 200、直连 400 → 定案：出口 IP 地区限制
```

实测对照（2026-11-03）：

| 出口 | gemini-3.8-flash-high | gemini-3-flash | claude-sonnet-4-6 |
|---|---|---|---|
| 直连（naye <YOUR_SERVER_IP>） | 400 location | 400 location | 200 |
| 走代理（vps-la <PRIVATE_IDENTIFIER>） | **200** | **200** | 200 |

同一天 11:29 还能正常返回（13.5s），13:33 起开始 400 —— **Google 侧策略变化，不是本地改动**。

## 修复：网关按需走代理

CLIProxyAPI 的 `proxy-url` 按 provider 配置只覆盖 api-key 类型（`gemini[].proxy-url` / `claude[].proxy-url` / `vertex[]` / `codex[]`），**antigravity 走 OAuth 账号池，不吃这套**。用环境变量最省事（Go 标准库自动识别，已实测生效）：

```ini
# /etc/systemd/system/cliproxyapi.service.d/proxy.conf
[Unit]
After=lemon-qb-tunnel-la.service

[Service]
Environment="HTTPS_PROXY=socks5h://127.0.0.1:1081"
Environment="HTTP_PROXY=socks5h://127.0.0.1:1081"
Environment="NO_PROXY=127.0.0.1,localhost,::1,capy.<PRIVATE_IDENTIFIER>,.<PRIVATE_IDENTIFIER>"
```

`NO_PROXY` 必须包含：本机回环（bot 访问网关 `127.0.0.1:8317`、管理接口）+ 自建中转（腾白嫖 `capy.<PRIVATE_IDENTIFIER>`，直连更快且不占代理带宽）。

改完 `daemon-reload` + `restart`，用三个家族各打一遍确认。

## 坑

- **代理是单点，但降级链保底**：代理挂在 `lemon-qb-tunnel-la`（vps-la 的 ssh `-D 1081`）上。隧道断 → Gemini/Claude/GPT 一起挂，但 `tengbaipiao` 在 `NO_PROXY` 里直连，GLM 仍可用。**别把自建中转也塞进代理**，那会把保底一起弄死。
- **节点预算要放宽**：`antigravity_gemini` 默认 `small=16.0`，而走代理后真实生成要 3~15s，长尾轻易撞线 → 连续 2 次超时 → 熔断 45s → 后面几次直接 0 秒失败。在 `data/ai_timeout_overrides.json` 加 `{"antigravity_gemini":{"small":25.0,"large":35.0}}`（热加载，不用重启）。
- **别用连打做压测**：`services/ai_limits.admit()` 会拦高频请求，返回「请求过长或请求过于频繁，请缩短输入或稍后重试」，`ask_ai` 返回空串、0 秒、无 `实际使用节点` 日志。这**不是故障**，是限流保护。看到 0 秒空返回先查是不是自己打太快。
- **冷启动会降级一次**：网关重启后首个 Gemini 请求要建 socks5 + TLS 连接池，容易超过预算。第一次降级到 GLM 属正常，第二次起稳定。
- **上游 `daily-cloudcode-pa.googleapis.com` 是 Google 域名**，不是私有中转，排障可以看；但汇报给群聊时只说「Google 侧地区限制」，别贴内部端点。

## 验收口径

不能只报「返回 200」。要三层：

1. 网关层：三个家族各 3 轮 `chat/completions` 全 200
2. 服务层：真实 `ask_ai()` 看 `LLM 实际使用节点: 反重力·Gemini3.8` 且 `fallback_index=0`
3. 延迟：命中时 2.5~4.5s 属正常；单次 14s 是长尾，不是坏

## 出口方案选型与两个结构性问题（2026-11-03 补充）

按「解决问题层级」选，而不是「找哪个 IP 能用」：

| 方案 | 出口 IP | 过 Gemini | 说明 |
|---|---|---|---|
| 本机直连 | `<YOUR_SERVER_IP>` | ❌ 400 | 被 Google 判不支持地区 |
| vps-la SOCKS5 | `<PRIVATE_IDENTIFIER>` | ✅ 200 | 独享 VPS IP，洛杉矶，稳定 |
| diaomao SOCKS5 | `<YOUR_SERVER_IP>` | ✅ 200 | 同为洛杉矶，实测 3/3 通过 |
| Cloudflare WARP | 共享 datacenter IP | ⚠️ 不稳 | Google 对这批 IP 定位常判错，`warp=on`+`loc=US` 仍可能 400，只能反复重连刷 IP |
| Vertex AI | 无关 | ✅ | **按项目 region 判定，完全不看出口 IP** |

「换出口」只治标：同一批 VPS IP 段哪天被标记还得再换。**唯一根治是 Vertex AI**——请求发到
`{region}-aiplatform.googleapis.com`，Google 按 region 而非 IP 判定。
官方定价（`cloud.google.com/vertex-ai/generative-ai/pricing`，2026-11-03 抓取）：Gemini 3.8 Flash
输入 $0.75 / 输出 $3.75 每百万 token（优惠价至 2026-12-31），2027-01-01 起 $1.5 / $7.5。

### 坑一：出口要独立，不要借别人的隧道

最初直接复用 `lemon-qb-tunnel-la.service` 的 `-D 127.0.0.1:1081`。那条隧道本职是 qBittorrent 下载，
**qB 侧任何重启/调整都会连带 AI 断流**。正确做法是给 AI 单独一条
`lemon-ai-tunnel-la.service`（`-D 127.0.0.1:1083`）：出口 IP 不变、零成本，故障域彻底分开。
drop-in 的 `After=` 也要改成指向新隧道服务。验收时用 `ss -ltnp | grep -E ":1081 |:1083 "` 确认是**两个不同 ssh pid**。

### 坑二：单节点吃光总预算，fallback 形同虚设

`_llm_request_budget()` 给的是**整条链**的 deadline。首节点 `antigravity_gemini`（budget 25s）
偶发长尾跑到 25.8s 超时后，后续节点只剩 ~3.6s，必然连续 timeout，用户看到的是空回答。
日志特征：`node_elapsed_s=25.835` 紧跟 `zhousan ... node_budget_s=3.657 outcome=timed_out`。
这不是节点坏了，是预算分配问题——要么抬高总预算，要么限制单节点占总额比例。
**网关刚重启后的首个请求**最容易触发（建 socks5 + TLS 连接池），复跑即恢复，别当故障处理。
