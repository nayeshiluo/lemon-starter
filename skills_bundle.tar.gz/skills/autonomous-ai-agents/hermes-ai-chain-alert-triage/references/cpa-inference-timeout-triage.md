# CPA 推理超时告警实录（"CPA 推理连接失败或超时"）

2026-10-20 实录。告警文案：`Gemini 主模型真实推理异常：CPA 推理连接失败或超时`。

## 结论（可直接复用）

**CPA 没坏，是上游 Gemini 间歇性超时 + 探针 17s 阈值偏紧。** 免费 tier 的波动 QoS 属已知特性，
Hermes 有 fallback 链兜底，不影响实际使用。

## 检测逻辑

`ai-model-healthcheck.py::probe_model()`：

```python
challenge = "CHECK-" + secrets.token_hex(4)
payload = {"model": model,
           "messages": [{"role": "user", "content":
             "Return only this exact ASCII verification token with no other characters: " + challenge}],
           "max_tokens": 80, "temperature": 0, "stream": False}
...
with urllib.request.urlopen(req, timeout=17) as resp:   # ← 17 秒
...
except (urllib.error.URLError, TimeoutError, OSError):
    return False, "CPA 推理连接失败或超时"
```

三种失败分支要分清：

| 分支 | 含义 |
|------|------|
| `HTTPError` → `CPA 推理接口 HTTP <code>` | 上游返回了错误码，是业务层问题 |
| `URLError/TimeoutError/OSError` → `CPA 推理连接失败或超时` | 纯超时，本次全部落这里 |
| `ValueError/KeyError/TypeError` → `CPA 推理内容无法解析` | 200 但格式不对 |
| 走到 `HTTP200但校验文本不匹配` | 模型没按要求原样回令牌（thinking 模型常见） |

## 当日 burst 时间线（UTC，北京时间 = +8）

```
Burst 1: 02:56:43 ~ 03:37:05  (5 次连续 FAIL)  ≈40min
Burst 2: 05:49:02 ~ 05:59:13  (2 次)
Burst 3: 07:09:55 ~ 07:50:03  (5 次)           ≈40min
Burst 4: 09:01:25 ~ 09:21:43  (3 次)           ≈20min
Burst 5: 10:32:31 ~ 10:42:37  (2 次)
```

合计 69 次探测、17 次 FAIL（24.6%），**每次 burst 都在 10~40 分钟内自愈** —— 典型上游抖动，
不是持续故障。

## 关键判据：CPA 进程层全部正常

```bash
ss -tlnp | grep 8317          # LISTEN 127.0.0.1:8317 cli-proxy-api
ss -tnp  | grep <pid>         # ESTAB 到 <YOUR_SERVER_IP>:443（Google）保持
ls /proc/<pid>/fd | wc -l     # fd 数量正常
```

同时 `ai-model-health.log` 里 `cpa_service` / `cpa_inference` / `cpa_auth_probe` / `cpa_catalog`
全部 `OK`。→ 排除 CPA 本身，锁定上游。

## 探针复现脚本

```python
import yaml, json, urllib.request, secrets, time
cpa = yaml.safe_load(open('/home/ubuntu/cliproxyapi/config.yaml'))
key = cpa['api-keys'][0]          # 直接就是 Bearer 值（bcrypt 字符串）
challenge = 'CHECK-' + secrets.token_hex(4)
payload = json.dumps({
    'model': 'gemini-3.8-flash-high',
    'messages': [{'role': 'user', 'content':
        'Return only this exact ASCII verification token with no other characters: ' + challenge}],
    'max_tokens': 80, 'temperature': 0, 'stream': False}).encode()
req = urllib.request.Request('http://127.0.0.1:8317/v1/chat/completions', data=payload,
    headers={'Authorization': 'Bearer ' + key, 'Content-Type': 'application/json'}, method='POST')
t = time.time()
try:
    with urllib.request.urlopen(req, timeout=45) as r:      # 放宽到 45s 做对照
        result = json.loads(r.read(400000))
    content = result['choices'][0]['message']['content']
    print(f'{time.time()-t:.2f}s  match={content.strip()==challenge}')
    print('reasoning_tokens =', result.get('usage', {})
          .get('completion_tokens_details', {}).get('reasoning_tokens'))
except Exception as e:
    print(f'{time.time()-t:.2f}s  {type(e).__name__}: {e}')
```

本次结果：`HTTP 200 | 2.57s | match=True | reasoning_tokens=91`
→ 同一请求放宽超时后立刻成功，证明是**阈值问题**不是链路断裂。

## 为什么 17s 对 `gemini-3.8-flash-high` 偏紧

该模型是 thinking 变体，实测 `reasoning_tokens≈91`，上游负载高时首包轻易超 17s。
建议（需用户授权后改）：把 `probe_model()` 的 `timeout=17` 放宽到 25~30s，
或对 thinking 模型单列更长阈值。改前备份脚本。

## 汇报要点

- 先给「当前手动测试通过」的实测结果，再给历史 burst 时间线
- 明确「不是 CPA 本身的问题」并列出进程/端口/连接三项证据
- 说明「免费 tier 间歇超时属正常，fallback 兜底，不影响使用」
- 附带发现：`ops-bot.log` 的 Telegram 多实例 Conflict 会导致告警重复推送，与链路无关
