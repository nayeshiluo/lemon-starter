---
name: skill-library-curation
description: "审计技能库重复、归属错位与边界，给出合并/迁移方案。"
version: 1.1.0
author: 柠檬
license: MIT
platforms: [linux, macos]
metadata:
  hermes:
    tags: [skills, curation, dedupe, audit, library]
    related_skills: [hermes-agent-skill-authoring, backup-chain-audit, agent-memory-curation]
---

# 技能库审计与合并

对已有技能库做「梳理/去重/合并」，产出经证据核实的方案。**不做**新建技能（那是 `hermes-agent-skill-authoring` 的领域），也不做「按描述猜谁重复」的快速清单。

## When to Use

- 用户说「梳理一下目前的技能」「技能是不是重复了」「帮我合并一下」
- 技能数量膨胀到索引变吵、同名主题开始各写一份
- 某个技能明显写错了推荐，需要确认是不是与另一个技能冲突
- 不适用：只想知道有哪些技能 → 直接 `skills_list` 汇报即可

## 铁律：描述不算证据

`skills_list` 的 description 只够发现「可疑」，**不足以判定重复**。凭描述下结论至少会犯两类错：

- 把「两套不同系统的同域功能」判成重复（本例 `telegram-group-assistant` vs `telegram-group-bot-suite` 是两个不同 Bot，合并会糊掉部署边界）
- 把「已明确划清边界的协作技能」判成重复（本例 `pdf` 明写 OCR out of scope 并指向 `ocr-and-documents`）

用户说「仔细核实」时，指的正是这一层：读正文、读支持文件、读用量。方案里每个判定都要能指到具体行。

## 第一步 盘点：磁盘数 ≠ 索引数，差额有三种来源

```bash
find ~/.hermes/skills -name SKILL.md | wc -l
```

与 `skills_list` 的 `count` 对不上时，按顺序核这三类，**别直接报「技能丢失」**：

| 来源 | 核法 |
|---|---|
| `config.yaml` 的 `skills.disabled` | 读该列表，逐个比对 |
| 平台不适用 | frontmatter `platforms:`（如 apple 系列在 Linux 不索引） |
| 环境/工具集门控 | frontmatter `environments:`、`requires_toolsets:`（如 `sdlc-review` 需 kanban） |

用 Python 做集合差（磁盘 − 索引 − disabled）最省事，能一次吐出「未索引但非 disabled」的名单。**注意 `skills_list` 输出会被截断**，拿全名单要靠磁盘侧遍历。

## 第二步 用量取证：谁还活着

`~/.hermes/skills/.usage.json` 是判定重复对里「保留哪个」的客观依据，字段：`use_count`、`view_count`、`last_used_at`、`state`（active/stale/archived）、`pinned`。

```python
import json
d = json.load(open('/home/ubuntu/.hermes/skills/.usage.json'))
for k in ['a','b']:
    v = d.get(k, {})
    print(k, v.get('use_count'), v.get('last_used_at'), v.get('state'))
```

读法：

- 两份都 active 且**同日各被加载多次** → 真实双倍上下文成本，优先级最高
- 一份 0 次、另一份有记录 → 0 次那份是纯重量，但**不能据此判「废弃」**，只作为「合并时保留哪个名字」的依据
- `state: stale` 只表示久未使用，不等于内容过时；stale 但内容厚的仍可能是有价值的参考手册

## 第三步 判定四分法（核心）

对每个可疑对，读两份 SKILL.md 的 `##` 标题大纲 + `find <skill_dir> -type f` 支持文件清单，然后落进下面四档之一：

### A. 真重复 → 合并
判据（需同时成立）：
- 章节大纲大面积重合，关键表格/流程近乎逐字相同
- **支持文件零重叠**（各有独占的 scripts/references）→ 合并是纯增量、无损
- 两边 `related_skills` 也互相指向同一批

### B. 异系统同域 → 不合并，交叉去重
判据：
- 双方都有「现行边界 / 部署边界」段落，且互相点名对方为准
- 落在不同代码库/不同部署实例（官方网关 Bot vs 自建双 Bot）
- 功能域重合（贴纸/summary/降级链/群开关/音乐各写一份）

处理方式：先定权威归属（谁持有该功能域的现行实现），另一侧只留一句指针。**不要合并 SKILL.md**——合并会把两套部署边界糊成一套，这是最危险的一类改动。

### C. 假重复 → 保持
判据：
- 结构同构但参数/命令是真硬知识（如 `codex`/`claude-code`/`opencode`：套路同、CLI 差异大）
- 一方已显式声明边界并指向另一方（`pdf` → `ocr-and-documents`）
- 合并后单文件会超过 ~300 行，每次调用全量加载反而更贵

**体积是判定项，不是结果。** 合并的目标是降低加载成本，若合并产出一个 47KB 怪物就失去了意义。

### D. 归属错位 → 迁移（不是合并，也不是交叉去重）

第四种情况，2026-10-25 实测新增。**内容不重复，是放错了技能。**

判据：某个技能的 `references/*.md` 里，**文件自身第一行标题点名了另一个项目**。本例 `telegram-group-assistant` 下 5 个 reference，标题分别写着「(群霸项目)」「(@Music163bot 同款)」——群霸是 `telegram-group-bot-suite` 的地盘。

**关键动作：读每个 reference 的第一行标题。** 描述层面看，assistant 和 bot-suite 都是「Telegram 群聊 Bot」，`skills_list` 完全看不出错位；只有打开文件看标题才能一眼定位。这是本节最可复用的判据。

处理方式：`cp` 到正确技能的 `references/`，**逐文件比对字节数确认零丢失**，然后在原技能留带技能名的指针，最后全局扫失效引用。

- 不要走「合并」：两套部署边界仍然要分开
- 不要走「交叉去重」：去重是在两个技能里各留一份摘要，而这里是内容压根不该在这里
- 迁移后原技能的 references 数量应显著下降（本例 14 → 7），新技能上升（6 → 11）

**混合内容的处理**：一个 reference 里既有 A 领域规范又有 B 领域实战时（本例 `bot-api-rich-and-group-bot.md` = 折叠卡片规范 + 群霸实战），**不要迁**——先拆内容再定归属，或标注归属后留给下一轮。为迁而拆的风险高于收益。

## 第四步 爆炸半径：改名/退役前先数引用

```bash
cd ~/.hermes && grep -rn -E '<name-a>|<name-b>' skills cron config.yaml \
  | grep -v -E 'skills/(<本对目录前缀>)'
```

引用通常藏在：其他技能的 `related_skills`、正文散文里的「见 X 技能」、`references/*.md`、cron 任务的 prompt。

- 零外部引用 → 合并/改名安全，只需改自身 `related_skills`
- 有外部引用 → 每个引用点都要同步改；引用数直接决定工时与风险，**先改引用再动正文**

## 第五步 合并执行

> **写前必须复核文件大小/mtime（数据丢失风险，本次实测踩过）**
>
> 本机常驻多个 Hermes worker，另一个会话可能在你「读过」和「写入」之间改同一个 SKILL.md。实测：`media-library-cleanup-ops/SKILL.md` 在探索期间被并发修改（5,815 → 8,837 字节，新增「验收必须回读源」「批量改名回滚机制」「汇报纪律」三节），`read_file` 读到的是旧内容，`write_file` 直接覆盖**静默丢掉新章节**，只回一条 `_warning` 不阻断。
>
> 写前固定动作：`stat -c '%s %y' <file>` 与自己读到的字节数比对；不一致就先重读，或 `cp` 一份当前版本再基于它改。**合并这类批量写操作，开工前先确认没有其他会话正在动同一目录。**

1. **备份**：`tar czf ~/.hermes/backups/skills-premerge-$(date +%F).tar.gz -C ~/.hermes skills` — `skill_manage` 的 delete 没有 undo
2. **选伞名**：用量高 + description 触发词写得好的那个；不要为「更准确的名字」牺牲既有引用
3. **主体取厚的那份**，把另一份的独占章节按主题插入，不要按原文顺序拼接
4. **支持文件全收**：真重复对的文件不重叠，直接 `write_file` 到伞技能下
5. **合并矛盾数字**：两份实测数字不一致时（不同批次/不同专区），标注为两次独立观测，**不要混成一个数**
6. **验收**：`skills_list` 回读确认只剩伞名；`skill_view` 读回正文确认关键表格没丢；确认支持文件路径可解析

## 第六步 记忆满了怎么办：分层，不是删减

记忆是硬上限（`MEMORY.md` 2200 字符、`USER.md` 1375 字符），技能是软上限。同一条事实写在哪，决定它值不值得占配额。**记忆满了不是「加不进去了」，是提示「这条该下放了」。**

**判定三问**（任一为「后者」就下放）：

1. 这是**判断原则**还是**配置细节**？原则进记忆，细节进技能。
2. 三个月后它**会不会变**？会变的（端口、路径、服务名、包名、尺寸参数、成员 ID）进技能；不变的（偏好、禁令、判断方式）进记忆。
3. **不查任何东西，现在就需要它吗**？需要 → 记忆；能先查一下 → 技能。

**下放后的记忆写法**：只留「索引 + 那个猜不到的坑」，形如 `XX 全档见 YY 技能；注意 <反直觉的点>`。不要留技能里已有的大段摘抄。

**顺序铁律：先写进技能，再删记忆。** 反了会丢信息。删前必须 grep 关键值，确认技能里真有这条，不能凭印象。

**典型可下放**：端口、路径、服务名、贴纸/图片尺寸参数、群成员 ID 映射、域名列表、脚本参数。
**必须留记忆**：反直觉的坑（如「水印前缀是正片，勿删」）、跨任务判断原则、用户偏好、身份与权限边界、当前阻塞状态（带日期锚点）。

**顺手核对过期值**：下放时若发现记忆与代码/技能冲突，以**代码**为准。实测过一例：记忆写 Emoji 包「1px 描边 + 2px 圆角」，代码与技能都是 `radius=14 / width=3`，记忆是旧值——这种留着比删掉更危险。

## 常见坑

1. **只读 description 就下结论** —— 会误判「异系统同域」为重复。必须先读正文大纲。
2. **把 `use_count=0` 当废弃证据** —— 只用于选保留哪个名字，不作退役理由。
3. **合并异系统技能** —— 部署边界段落一旦合并就自相矛盾，未来 agent 会按错的那套操作生产。
4. **忽略支持文件清单** —— 支持文件零重叠是真重复的强信号；有重叠则说明两份已经在各自维护同一份资料，合并前要先对齐版本。
5. **发现两技能推荐冲突却不报** —— 冲突（A 推 3-5GB 方案，B 实测同机 OOM）是**真 bug**，价值高于去重本身，必须单独列出并给修法。
6. **改了正文没改引用** —— 被退役名字的 6 处外部引用会全部悬空。
7. **报告只给「建议合并」** —— 必须给优先级、工时、风险、以及明确的「不做」清单。
8. **验收时把字符数当字节数** —— Python 的 `len(text)` 是**字符数**，`stat -c %s` 是**字节数**。中文按 UTF-8 占 3 字节，一个 53,099 字节 / 549 行的文件 `len()` 只有 29,462。用 `len()` 去比对 `stat` 会误判成「文件被截断了」并触发一轮无谓排查。**校验用 `stat`，或用 `os.path.getsize()`。**
9. **`skill_manage` 删除时漏 `absorbed_into`** —— 删被合并的技能必须写 `action='delete', absorbed_into='<伞名>'`，它告诉 curator 这是「合并」而非「废弃」，下游 cron/引用改写靠它判断。真退役才传空串。传了伞名就别再手动删目录。
10. **技能里的无后缀脚本会让公开快照发布失败** —— `~/.hermes/skills` 有一条公开发布管线（`/home/ubuntu/bin/public-skills-export/`，cron 每日 `prepare` → 待 Owner 复审 → 推 GitHub）。它按 `TEXT_EXTENSIONS ∪ TEXT_NAMES` 白名单校验每个文件，不在白名单就抛 `unsupported_candidate_file`，整个 cron 静默失败（只在 `status` 文件里留一行）。实测 `deepseek-harness-ops/scripts/dshask`、`dshchat` 两个**无后缀 bash 脚本**踩中——它们不带后缀是为了装进 `~/.local/bin/dshask` 能直接调用。
    - **自查要复用管线自己的遍历逻辑**，别自己 `rglob`（管线的 `SKIP_DIR`/`SKIP_NAME` 会跳过 `.curator_backups`、`__pycache__`、`.usage.json` 等，直接 rglob 会报一堆假阳性）：
      ```python
      import sys, pathlib
      sys.path.insert(0, '/home/ubuntu/bin/public-skills-export')
      import candidate_pipeline as cp
      from public_skills_guard import TEXT_EXTENSIONS, TEXT_NAMES
      for n in cp.source_bytes(cp.SOURCE):
          p = pathlib.PurePosixPath(n)
          if p.suffix not in TEXT_EXTENSIONS | {'.pdf'} and p.name not in TEXT_NAMES:
              print('BAD:', n)
      ```
    - **修法二选一**：脚本改名带 `.sh`（SKILL.md 里注明安装时去掉后缀）；或加进 `public_skills_guard.py` 的 `TEXT_NAMES`（已有 `'ib'` 先例）。加白名单前先 grep 该脚本有无 `token|password|secret|api_key|sk-`，`secret_check` 虽会兜底扫凭据，但白名单本身是在放宽文件类型闸门。
    - **改 `public_skills_guard.py` 会作废已有候选**：该文件被 `code_hash()` 纳入候选身份指纹，改完旧 `pending.json` 的 id 全部失效，必须重新跑 `prepare` 生成新候选。改前先 `cp -a` 备份。
    - 发布管线代码本身也在 `/home/ubuntu/hermes-ops-private/projects/lemon-starter-publish/` 有仓库副本，改线上后要 `bash sync-from-live.sh` 同步，否则下次安全巡检会报「副本未同步」。

## 汇报格式

用户要的是决策，不是清单：

1. **结论先行**：几组真重复、几组不能合、有没有 bug
2. **客观数据表**：盘点差额来源 + 关键技能的 use_count/last_used
3. **逐组判定**：真重复给合并方案与命名决策；异系统给「不合并 + 交叉去重」理由；归属错位给「迁移到哪、迁了哪几个文件、字节数是否一致」
4. **冲突项单列**：技能之间互相矛盾的建议，给修法
5. **执行表**：优先级 / 动作 / 风险 / 工时 + 「不做」清单
6. **收尾一问**：哪几项现在执行，哪项单独排

## 支持文件

- `references/library-audit-2026-10-25.md` — 2026-10-25 全库审计实测：盘点数字、四组判定结论、P0–P3 执行结果（含 Telegram 归属迁移的 5 文件清单与字节校验）、外部引用清单、以及本次踩到的并发覆盖坑。**读它是为了复用判据与数字口径，不是为了重跑审计**；技能增删后数字会变，但判定方法不变。
