# 2026-10-25 全库审计实测

采样日期：2026-10-25（Asia/Shanghai）。数字为该时刻快照，技能增删后需重跑。

## 一、盘点：134 磁盘 / 108 索引 / 差 26

| 来源 | 数量 | 明细 |
|---|---|---|
| 磁盘 SKILL.md | 134 | `find ~/.hermes/skills -name SKILL.md` |
| `skills_list` count | 108 | 索引输出（注意会被截断，全名单靠磁盘侧遍历） |
| `config.yaml` `skills.disabled` | 21 | arxiv / blogwatcher / competitor-news-monitor / ctf-crypto-puzzles / email-inbox-triage / evaluating-llms-harness / himalaya / llama-cpp / manim-video / meeting-action-items / openhue / p5js / pretext / product-price-monitor / research-paper-writing / serving-llms-vllm / songwriting-and-ai-music / teams-meeting-pipeline / touchdesigner-mcp / weekly-review-planning / weights-and-biases |
| 平台不适用 | 4 | apple-notes / apple-reminders / findmy / imessage（macOS 专属，Linux 不索引） |
| 工具集门控 | 1 | sdlc-review（`environments: [kanban]` + `requires_toolsets: [kanban]`） |

结论：索引侧无异常，差额全部有解释。`pinned` 为空，`archived` 为空，`use_count=0` 共 64 个。

## 二、用量快照（`.usage.json`）

| 技能 | use | last_used | state |
|---|---|---|---|
| media-library-cleanup-audit | 3 | 2026-10-25 | active |
| media-library-cleanup-ops | 3 | 2026-10-25 | active |
| qbittorrent-remote-ops | 1 | 2026-10-24 | active |
| qbittorrent-multi-node | 0 | — | active |
| telegram-group-assistant | 141 | 2026-10-15 | active |
| telegram-group-bot-suite | 114 | 2026-10-24 | active |
| codex | 16 | 2026-10-24 | active |
| claude-code | 1 | 2026-09-04 | stale |
| opencode | 1 | 2026-09-04 | stale |
| pdf | 2 | 2026-08-13 | stale |
| nano-pdf | 0 | — | stale |
| ocr-and-documents | 6 | 2026-08-14 | stale |
| scanned-pdf-to-word | 4 | 2026-09-02 | stale |

清理器两份**同日各 3 次**，是真实双倍加载成本。

## 三、四组判定结论

### A. 真重复 → 合并

**1. `media-library-cleanup-audit` + `media-library-cleanup-ops`**

- 重复：空转检测（三层表 vs 五步核对，同一件事）、四类分拣表（几乎逐字）、灰度流程、域名前缀坑
- 支持文件零重叠：audit 有 `scripts/verify_rename_journal.py` + `references/cleanup-rule-regex.md`；ops 有 `scripts/audit_promo_scope.py` + `references/guangya-pipeline.md`
- 数字矛盾：audit 记 18,362 文件中 2,020 个被旧规则误标、真广告 0；ops 记 2,996 个误判。**两次不同批次/专区的实测，合并时须分别标注**
- 外部引用：无
- 决策：保留 `media-library-cleanup-ops` 作伞名（description 触发词更好），并入 audit 正文；4 个支持文件全收
- 独占需保留：audit 的三层空转表、祖先目录三层判定代码（`has_titled_ancestor`）、10 条坑、灰度 6 步含「读回云盘验收」、汇报口径；ops 的第四步安全闸门（`dry_run`/`IncompleteVideoSweep`/单批 ≤50/禁清空回收站）、第五步调度锁、`guangya-pipeline.md`

**2. `qbittorrent-remote-ops` + `qbittorrent-multi-node`**

- 重复：`Host` 头伪装两处各写一遍、rrsync 受限通道两处各写一遍（最易漂移）
- 各自独占：remote-ops 有 PBKDF2 密码设置、systemd 隧道常驻、下发验证配方、多节点命名；multi-node 有 4.x/5.x 端点差异（`paused`→`stopped`、`resume`→`start` 的 404 坑）、三段流量模型、双会话设计、吞吐基线（2026-10，InstaBox→RackNerd）、排障三角、验证顺序
- 外部引用：无
- 决策：保留 `qbittorrent-remote-ops`（有使用记录），description 扩到覆盖多节点编排

### B. 异系统同域 → 不合并，交叉去重

**`telegram-group-assistant`（141 次） + `telegram-group-bot-suite`（114 次）**

- assistant = Hermes 官方网关 Bot 进群 + observe 模式 + 权威可折叠总结规范（`<details><summary>`）
- bot-suite = 自建群霸双 Bot（@<PRIVATE_IDENTIFIER>_bot / @<PRIVATE_IDENTIFIER>_bot），有「本部署现行边界」段
- assistant 明写「当前媒体路线以 telegram-group-bot-suite 技能为准」；bot-suite 明写「以运行中源码和配置为准」→ 合并会糊掉两套部署边界
- 功能域重复五处：贴纸规范、summary 格式、LLM 降级链、群开关、音乐
- 外部引用 6 处，动之前必须同步：
  - `summary`：`related_skills` + 正文「完整规范见 telegram-group-assistant」
  - `telegram-ops-bot`：`related_skills` + 正文指向 bot-suite 的 `references/owner-contact-alerts.md`
  - `telegram-quote-sticker`：`related_skills`
  - `music-relay-triage`：`related_skills`
  - `forwarded-material-triage`：`related_skills` + 正文
  - `cliproxyapi/references/quota-exhaustion-diagnosis.md`：正文指向 assistant
- 决策：定权威归属后交叉去重，另一侧留一句指针。建议贴纸/summary/降级链归 bot-suite，网关配置/人名归属校验归 assistant

### C. 假重复 → 保持

- `codex`(16) / `claude-code`(1, stale, 745 行) / `opencode`(1, stale)：结构同构但 CLI 参数是硬知识，合并会产出 47KB 单文件，每次全量加载更贵
- `pdf` / `nano-pdf` / `ocr-and-documents` / `scanned-pdf-to-word`：`pdf` 正文已明写「OCR is explicitly out of scope here — use the `ocr-and-documents` skill」，边界清晰

## 四、真 bug（不是重复）

`ocr-and-documents` 把 `marker-pdf` 列为扫描件首选（3–5GB，PyTorch + 模型），但 `scanned-pdf-to-word` 实测记录：**marker-pdf 在 2GB 内存机器上被 OOM 杀掉**，本机 1.9G。

修法：给 `ocr-and-documents` 加环境限制提示，扫描件场景指向 `scanned-pdf-to-word` 的视觉模型路线（200 DPI 渲染 + OpenAI 兼容视觉接口 + 每页落盘 `md/page_NNN.md`）。

## 五、执行计划与状态

| 优先级 | 动作 | 风险 | 工时 | 状态（2026-10-25） |
|---|---|---|---|---|
| P0 | 合并清理器两份 | 低（无外部引用、文件不重叠） | 15 min | ✅ 已执行 |
| P1 | 合并 qBittorrent 两份 | 低 | 20 min | ✅ 已执行 |
| P2 | 修 `ocr-and-documents` 的 marker 建议 | 极低 | 5 min | ✅ 已执行 |
| P3 | Telegram 两份交叉去重 | 中（6 处外部引用 + 部署边界） | 60 min | ✅ 已执行（改为「归属迁移」而非合并） |
| 不做 | codex 三兄弟、PDF 四件套 | — | — | — |

执行前备份：`tar czf ~/.hermes/backups/skills-premerge-20261025.tar.gz -C ~/.hermes skills`（37KB，含 5 个目录）

### 执行结果

- `media-library-cleanup-audit` → 并入 `media-library-cleanup-ops`（v2.0.0，16.0KB / 194 行，4 个支持文件全收）。两处误判数字已分别标注为不同批次
- `qbittorrent-multi-node` → 并入 `qbittorrent-remote-ops`（v2.0.0，16.4KB，支持文件 5 个）
- `ocr-and-documents` → 在 Step 1 前插入本机 1.9G 内存约束块，明确 marker-pdf 会被 OOM、扫描件指向 `scanned-pdf-to-word`
- 磁盘技能数 134 → 133（删 2 加 1：新增本技能）

### P3 执行结果：归属迁移（比合并更正确）

核查发现 assistant 的 5 个 reference **标题里就写着「群霸项目」「@Music163bot 同款」**——它们是群霸专属实现，误挂在 Hermes 网关 Bot 技能下。所以 P3 不是「合并两份」，而是**把错位内容迁回正确技能**：

| 迁移文件 | 字节 | 去向 |
|---|---|---|
| `group-sticker-and-quote-spec.md` | 12,193 | → `telegram-group-bot-suite/references/` |
| `group-moderation-and-sticker-pack.md` | 16,659 | → 同上 |
| `per-group-feature-toggles-and-tag-enrichment.md` | 8,636 | → 同上 |
| `music-bot-service-spec.md` | 7,022 | → 同上 |
| `llm-fallback-chain-and-failure-surfacing.md` | 4,515 | → 同上 |

- 迁移前后字节数逐一比对，零丢失
- `telegram-group-assistant/references` 14 → 7 个；`telegram-group-bot-suite/references` 6 → 11 个
- bot-suite 新增「配套参考索引」段（含全部 references/scripts/templates 说明 + 与 assistant 的边界声明）
- assistant 的「配套文件」段改为 4 条带技能名的指针；§9.5 段首加「权威归属」声明（保留历史排查过程与通用反模式，但明确现行实现看 bot-suite）
- 外部引用同步：`cliproxyapi/references/quota-exhaustion-diagnosis.md` 的兜底链指针改为指向 bot-suite
- 全局扫描：无指向已删文件的失效引用

**保留在 assistant 的**：`summary-format-collapsible.md`（总结双通道渲染权威）、`qh-nested-reply-bot-api-limitation.md`、`multi-platform-video-parsing.md`、`anti-collision-and-time-parsing.md`、`state-db-recovery.md`、`bot-api-rich-and-group-bot.md`、`group-bot-deep-integrations.md`。

后两个是混合内容（折叠卡片规范 + 群霸实战），暂不迁；若后续再清理，先拆内容再定归属。

### 判据修正（重要经验）

**不要按技能名/描述判归属，要读 reference 的第一行标题。** 本次 5 个错位文件全靠标题里的「(群霸项目)」「(@Music163bot 同款)」一眼定位。描述层面看，assistant 和 bot-suite 都是「Telegram 群聊 Bot」，完全看不出内容错位。

「合并」也不是唯一解：**归属迁移**（内容搬到正确技能 + 原处留指针）风险更低、语义更准，且不动两套部署边界。

### 执行中发现的坑（下次必看）

**写技能前必须重新核对文件大小/mtime**。本次 `media-library-cleanup-ops/SKILL.md` 在探索与写入之间被并发修改（5,815 → 8,837 字节，新增「验收必须回读源」「批量改名回滚机制」「汇报纪律」三节）。`read_file` 读到的是旧内容，`write_file` 直接覆盖会**静默丢失新章节**，只给一条 `_warning`。正确做法：写前 `stat -c '%s %y'` 比对，或先 `cp` 一份当前版本再改。

同一批技能文件可能被多个 Hermes worker 并发改（本机常驻多 worker，见 `telegram-group-bot-suite` 的 `concurrent-config-drift.md`）。技能合并这类批量写操作，开工前先确认没有其他会话正在改同一目录。
