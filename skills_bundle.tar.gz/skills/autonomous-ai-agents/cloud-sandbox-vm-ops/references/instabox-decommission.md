# InstaBox 沙箱退役（Decommission）实操档案

> 2026-11-24 实测退役两台免费沙箱（`agent-browser-xoel` / `agent-browser-zqwq`）的全过程。
> 适用于「这台免费沙箱不要了 / 告警太吵 / 平台锁了」这类退役诉求。

## 0. 退役前必须先分清「哪种不可用」

平台至少有 **4 种「连不上」**，处置完全不同，**不要一律当成 8 小时暂停**：

| 现象 | API 表现 | 处置 |
|---|---|---|
| 正常空闲暂停 | `state=suspended`，`cooldownUntil` 为 null 或刚过期 | 唤醒即可，无需退役 |
| max-run 冷却 | `state=stopped`，`cooldownUntil` = 约 10 分钟后 | 等冷却自动恢复，无需退役 |
| **合规锁定 `abuse_proxy`** | `state=stopped`，`cooldownUntil` **几小时后**，`reason: "abuse_proxy"` | 平台按免费档条款冻结，**保活救不回来** |
| 已被删除 | `GET /v1/machines/{id}/files` → `404 machine not found` | 已退役，只需清理外部依赖 |

### 合规锁定的原文长这样（实测）

```
HTTP 409 {"error":{"code":"machine_cooldown","message":"machine is locked until
2026-11-24T17:26:55Z: an automatic abuse check (free-plan proxy) paused it: it kept
running a proxy server (sing-box, port 18080) after we asked you to stop it
(free plan, Terms 2(e)) ...","reason":"abuse_proxy","retryAfterSeconds":64947}}
```

判读要点：

- `reason` 字段区分性质：`abuse_proxy` 是**条款违规**，不是资源不足；
- `retryAfterSeconds` 动辄几万秒（十几小时），**不是 10 分钟冷却**；
- 免费档条款禁止在沙箱里跑代理服务。**在免费沙箱上跑 sing-box / dante / xray 等代理 = 迟早被平台锁**，不要指望保活；
- 机器被锁期间 `exec` / `files` / `snapshots` 全 409/404，**磁盘内容取不回来了** → 所以退役前要先备份。

## 1. 资产盘点（决定这台机器能不能删）

退役前必须查清三件事，否则会误删生产依赖：

```bash
# a) 有没有别的机器/服务在依赖它（SSH 别名、隧道、systemd、订阅、监控面板）
grep -rlE "<machineId去m_前缀>|instabox\.tech" /etc /opt /root /home 2>/dev/null
ps -eo pid,args | grep -E 'ssh .*(instabox|ssh\.instabox)' | grep -v grep
systemctl list-unit-files | grep -iE 'instabox|ib-'

# b) 机器上有没有独有的配置资产（SSH 连不上时用 API exec 读）
# c) Monitor 面板里对应的 node 行 + traffic 行（traffic 必须一起删，否则 hub 报 unusable）
```

**多台机器逐台打标签**：每条命令先 `echo "=== $(hostname) ==="`，采集完立刻记下「机器名 + 规格」，汇报前对一遍。跨机串数据是已发生过的事故。

## 2. 备份机器内的配置资产

沙箱唯一有价值的通常是 `/data/workspace` 下的配置目录（如 DSH 的 `.dsh/`）。

### ⚠️ API 有大小截断，必须分块拉（这是最容易踩的坑）

| 通道 | 实测截断上限 | 现象 |
|---|---|---|
| `POST /v1/machines/{id}/exec` 的 stdout | **1 MiB**（1048576 字符） | 静默截断，`tar`/base64 之后校验和必然对不上 |
| `GET /v1/machines/{id}/files` 的 `content` | **256 KiB**（262144 字符） | 同上，且**不报错**，返回 200 |

两种截断都**不会报错**，只会给你一份不完整的文件 → 校验和对不上才发现，浪费好几轮。

**解法：在机器上分块，逐块拉。** 可直接用 `scripts/ib-export-chunked.py`：

```bash
# 机器上先切块
split -b 200000 -d -a 3 payload.b64 part-     # → part-000, part-001, ...
# 再对每个 part 调 GET /v1/machines/{id}/files?path=/data/workspace/part-NNN
# 遇到 404 = 拉完了（不是错误，是终止条件）
```

实测 23 块 / 4.55 MB base64 完整还原，sha256 与源端一致（577 个文件）。

**校验和必须在两端比对**（机器上 `sha256sum` + 本地 `sha256sum`），对不上就是被截断了，别存进备份目录。

### 备份落点

存到自有机器的归档目录，不要留在 Hermes workspace 根目录：

```
/home/ubuntu/hermes-jobs/retired/instabox/<name>-archive-<YYYYMMDD>.tgz
```

⚠️ 归档里通常**含 provider 配置 / API key**，按凭据资产对待：`600` 权限、不进 Git、不在聊天里贴内容。

## 3. 退役执行顺序（严格按序）

1. **删公开端口**：`DELETE /v1/machines/{id}/ports/{port}` → 返回**空 body**（不是 JSON），200 即成功
2. **吊销 SSH token**：`DELETE /v1/machines/{id}/ssh-tokens` → `{"revoked":1}`（一次性吊销全部）
3. **停机**：`POST /v1/machines/{id}/stop` → 返回 `op_...` 对象，`state: "queued"`（异步）
4. **删除机器**：`DELETE /v1/machines/{id}` → `op_...`，`type: "delete"`
5. **等待并复核**：`GET /v1/machines` → `{"machines":[],"nextCursor":null}`

所有写操作都要 `Idempotency-Key`（新 uuid），DELETE 也要。

### 坑：machine id 绝不能硬编码进脚本

把 `m_xxx` 写死在脚本里再发出去 → 占位符/模板替换会把 id 弄错，报 `machine not found` 或打到别的机器上。

**正确做法：脚本运行时从 `GET /v1/machines` 动态取 id 再循环**：

```python
d = json.loads(call(key, "/v1/machines"))
for m in d.get("machines", []):
    mid = m["id"]          # ← 从 API 拿，不硬编码
    ...
```

`GET /v1/machines` 返回结构是 `{"machines":[...]}`，**不是裸数组**；早期代码按裸数组写会抛 `KeyError: 'id'`。

### 坑：`/v1/machines/{id}/snapshots` 这个路由不存在

`GET /v1/machines/{id}/snapshots` 返回 `404 route not found`（不是 `machine not found`）。快照是独立资源：`DELETE /v1/snapshots/{id}`、`POST /v1/machines/{id}/snapshots`（建快照）。**用 "route not found" vs "machine not found" 区分「路由写错」和「机器没了」**，别误判成机器不存在。

### 坑：删完机器后，端口/SSH token 的 DELETE 全 404

机器删除是异步的。删完立刻调 `DELETE .../ports/8080` 会 `404 machine not found`——这是**正常的**，说明删除已完成，不需要重试。

## 4. 清理外部依赖（退役的一半工作量在这里）

平台删了机器，本地还有一堆东西指向它，**不清干净就会一直误报**。

### 4a. 常开 VPS 上的保活守护

```bash
ssh vps-la 'sudo systemctl disable --now instabox-lease.service instabox-lease-lab.service instabox-keepalive.timer'
sudo rm -f /etc/systemd/system/instabox-{lease,lease-lab,keepalive}.{service,timer} \
          /usr/local/bin/instabox-{lease,lease-multi,keepalive}.sh
sudo rm -rf /etc/instabox /etc/instabox-lab      # ← 含 API key，必须删
sudo systemctl daemon-reload
```

验证：`systemctl list-unit-files | grep -i instabox` 应为空；`ls /etc/instabox*` 应 No such file。

> `systemctl disable` 对 `Type=oneshot` 的 service 会打印一段"不该用 systemctl enable/disable"的警告——**那是正常噪音，不是失败**，看 `is-active` 是否 inactive 即可。

### 4b. Monitor 面板的节点行

node 行和 traffic 行**都要删**，只删 node 会留下孤儿 traffic。

⚠️ **不要用 `ssh vps-la 'python3 -c "...%s..."'` 传含 `%` 的 SQL**：shell / Python / SQLite 三层引号会打架，报 `near "%": syntax error`。正确做法是**写 .py 文件 scp 过去再执行**：

```python
# /tmp/mon_clean.py
import sqlite3
c = sqlite3.connect("/opt/monitor/data/monitor.db")
c.execute("DELETE FROM node WHERE name LIKE ?", ("%InstaBox%",))
c.execute("DELETE FROM traffic WHERE node_id NOT IN (SELECT id FROM node)")
c.commit()
print(c.execute("SELECT id,name FROM node").fetchall())
```

```bash
scp -q /tmp/mon_clean.py vps-la:/tmp/ && ssh vps-la 'sudo python3 /tmp/mon_clean.py; rm -f /tmp/mon_clean.py'
```

### 4c. 本机监控脚本

从采样列表里摘掉，**并删掉「平台暂停不算故障」的降级特例**——机器都没了，这个特例会让别的机器真故障时也只报 WARN：

```python
# hermes-jobs/resource_monitor.py
for host in ('naye', 'vps-la', 'vps-hk', 'aliyun', 'yecao'):   # 去掉 instabox-xoel
    ...
add(host, 'connection', 'CRIT', v['error'])   # 去掉 'WARN' if host == 'instabox-xoel' else
```

```python
# hermes-jobs/daily-health-briefing.py
HOSTS = ('naye', 'vps-la', 'vps-hk', 'diaomao', 'aliyun', 'yecao')
attention = issues    # 去掉对 instabox-xoel / dshlab 的过滤
```

**改完必须实跑验收**：`python3 resource_monitor.py` → 期望 `issues: {}` 且采样列表里没有目标机器。别只改不跑。

### 4d. 单元测试里的引用

`hermes-jobs/test_alert_policy.py` 里有 `self.assertEqual(set(m.sample()), {'naye','vps-la','instabox-xoel'})` —— 机器删了不改测试，测试会假失败。

### 4e. cron 提示词 / SSH 别名 / 密钥

- cron job 的 prompt 里可能硬编码了机器别名（`hermes cron edit` 要过审批，超时即中止，别反复重发）；
- `~/.ssh/config` 里的 `Host <alias>` 块（属受保护凭据文件，`patch`/`write_file` 会被拒，走 shell 追加 + 回读验证）；
- 本地遗留的 API key 文件（`~/.config/instabox-api.key`、`~/.ib/api_key*`）；
- `provider_models_cache.json` 里可能缓存着旧面板 URL（`custom:https://8080-xxx.instabox.tech/v1`）→ 机器删了之后这个 provider 永久不可用，**从 config 里清掉**（`config.yaml` 的 `custom_providers` 是 list，逐条核对 `base_url`）。

## 5. 验收清单

| 项 | 期望 | 命令 |
|---|---|---|
| 平台侧机器已删 | `{"machines":[]}` | `GET /v1/machines`（两个账号各查一次） |
| 公开端口已删 | 无 ports 记录 | `GET /v1/machines/{id}/ports` |
| SSH token 已吊销 | `{"revoked":1}` | DELETE 返回值 |
| 保活守护已停 | inactive + disabled | `systemctl is-active/is-enabled` |
| unit/脚本/key 已删 | 无残留 | `ls /etc/instabox* /usr/local/bin/instabox*` |
| Monitor 节点已删 | node 表无该节点、traffic 无孤儿 | sqlite 查询 |
| 监控脚本已改 | 采样列表无该机器 | `python3 resource_monitor.py` |
| 告警不再出现 | 下一轮巡检 issues=0 | `journalctl -u lemon-ops-health.service` |
| 资产已备份 | 双端 sha256 一致 | `sha256sum` |

## 6. 汇报纪律

- **不要把「平台已删」说成「全部清理完毕」**——外部依赖清理是独立的一大块，逐项核完再下结论；
- 工具轮次用尽时，**如实列出未完成的尾巴**（cron 提示词、SSH 别名、密钥、测试断言），不要含糊带过；
- 被锁机器取不到资产时，**说明取证范围受限**（「无法对锁内文件做全量取证」），不要写成「已确认无依赖」。

## 7. 顺带教训

- 免费沙箱跑代理服务（sing-box/dante/xray）**违反免费档条款**，平台会按 `abuse_proxy` 冻结，锁十几小时。代理节点一律放有公网 IP 的自有机器（见 `socks5-proxy-setup`）。
- 免费机 `maxRunMinutes` **每台不同**（实测 120 和 480 同账号并存），schema 里的 "default to 480" 是默认值不是保证值。算剩余时间只能读该机自己的 `maxRunMinutes` + `runStartedAt`。
