# 在沙箱里跑回环 Web 服务（绝不发布端口）

场景：沙箱里要跑一个带浏览器 UI 的服务（DeepSeek Harness `dsh web`、面板类工具、Notebook 等），
但**不能**把它暴露到平台公网端口——一旦挂上去，任何知道 URL 的人都能访问，而这类工具往往自带命令执行。

实测对象：InstaBox 免费档 `agent-browser` 模板 + `@deepseek-ai/dsh` 0.2.1-rc.2（2026-10-29）。

## 一、绑定回环

```bash
DSH_HOME=/data/workspace/.dsh \
  dsh web --host 127.0.0.1 --port 8080 --no-open
```

- `--host` **只接受具体本地地址字面量**，通配地址（`0.0.0.0`）会被拒——这正是想要的默认安全姿态。
- 服务起来后访问根路径返回 `401` 是**正常的**，它要 URL 里的 `?token=`。
- 独立 `DSH_HOME`（放持久盘，如 `/data/workspace/.dsh`）是必须的：不碰默认目录，删目录即干净回滚。
- 装 CLI 到全局要 root：`sudo npm i -g <pkg>@<version>`（沙箱普通用户无写权限于 `/usr/local`）。

## 二、常驻：systemd --user（沙箱无 root 系统服务的标准解法）

前提 `loginctl show-user <u> -p Linger` = `yes`（InstaBox 模板已开）。

```ini
# ~/.config/systemd/user/dsh-web.service
[Unit]
Description=dsh web (loopback only)
After=network.target
[Service]
Type=simple
Environment=DSH_HOME=/data/workspace/.dsh
WorkingDirectory=/data/workspace
ExecStart=/usr/local/bin/dsh web --host 127.0.0.1 --port 8080 --no-open
Restart=always
RestartSec=20
[Install]
WantedBy=default.target
```

```bash
export XDG_RUNTIME_DIR="/run/user/$(id -u)"
systemctl --user daemon-reload && systemctl --user enable --now dsh-web.service
```

好处：8 小时强制暂停恢复后服务自动拉起（`Restart=always` + Linger 常驻）。

## 三、本地访问：SSH 端口转发（唯一安全的入口）

```bash
ssh -p 2222 -N -L 8080:127.0.0.1:8080 <ssh-user>@ssh.<platform>.sh
```

访问 token 每次重启会变，从日志里取当前值：

```bash
ssh <host> 'journalctl --user -u dsh-web -n 30 --no-pager | grep -o "token=[A-Za-z0-9_-]*" | tail -1'
```

浏览器打开 `http://127.0.0.1:8080/?token=<值>`（带 token 会 303 跳转并种 cookie，属正常）。

**验收**：无 token 401、带 token 303/200；`ss -ltn` 只看到 `127.0.0.1:8080`；
平台端口列表为空（`GET /v1/machines/{id}/ports` → `{"enabled":true,"ports":[]}`）。

## 四、坑：`pkill -f` 会杀掉执行它的那条 ssh 命令

```bash
# ✗ 自杀写法：bash -c 的 cmdline 里含 "dsh web --host 127.0.0.1"，pkill -f 先把自己杀了
ssh host 'pkill -f "dsh web --host 127.0.0.1" ; systemctl --user restart dsh-web'
# 现象：输出全空、ssh 立刻返回、后续步骤一个没执行，看起来像"连不上"或"命令没生效"
```

```bash
# ✓ 锚定进程名，避开自身
ssh host 'P=$(pgrep -f "^node /usr/local/bin/dsh web" | head -1); [ -n "$P" ] && kill "$P"'
```

判据：ssh 命令返回空输出 + 退出异常，但目标进程其实还在（或刚被杀）→ 先想"我是不是把自己杀了"，
不要当成网络问题重试同一串命令。更省事的替代：直接 `systemctl --user restart`，不需要 pkill。

## 五、边界

- 沙箱里跑这类"能执行命令的 UI"，审批/确认门等于唯一闸门；**不要装会改写宿主审批链的插件**（实测
  `dsh-purge` 之类会把 approval 请求改成自动放行），更不能配合公网端口一起用。
- 需要给用户看界面时，优先"他自己 SSH 转发"，而不是你去开隧道/反代——后者等于把回环服务搬到公网。
