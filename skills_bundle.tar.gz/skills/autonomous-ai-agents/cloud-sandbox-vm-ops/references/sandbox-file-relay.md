# 沙箱文件回传通道：rrsync 安装、验收与 sshfs 只读挂载

> 配合 SKILL.md 正文「受限回传通道：受限用户 + rrsync 单向只写」一节使用。正文已含 VPS 侧
> authorized_keys / sshd_config 配置与沙箱侧推送命令，本篇补齐：一键安装脚本、验收命令、
> sshfs 只读挂载。

## 1. VPS 侧一键安装（root 执行）

```bash
# 1) 建受限用户与只写目录
useradd -r -m -d /home/qbupload -s /bin/bash qbupload
install -d -m 750 -o qbupload -g qbupload /srv/qbupload

# 2) 挂公钥（密钥由沙箱生成，公钥贴到下面文件）
install -d -m 700 /etc/ssh/keys
cat > /etc/ssh/keys/qbupload << 'EOF'
command="/usr/bin/rrsync -wo /srv/qbupload",restrict ssh-ed25519 AAAA... sandbox-relay@lemon
EOF
chmod 644 /etc/ssh/keys/qbupload

# 3) Match 块锁死能力
cat > /etc/ssh/sshd_config.d/99-qbupload.conf << 'EOF'
Match User qbupload
    AuthorizedKeysFile /etc/ssh/keys/qbupload
    AllowTcpForwarding no
    AllowAgentForwarding no
    PermitTunnel no
    X11Forwarding no
    PermitTTY no
    PasswordAuthentication no
EOF

# 4) 语法检查 + 重载（单元名是 ssh，不是 sshd）
sshd -t && systemctl reload ssh
```

坑：`StrictModes` 不能写进 Match 块（`sshd -t` 当场报 `Directive 'StrictModes' is not allowed within a Match block`）。不写即可，默认值已足够。

## 2. 验收命令（隔离自证是通道合格的判据，别省）

```bash
# 沙箱侧：正常推送应成功
rsync -a --partial --inplace \
  -e "ssh -i ~/.ssh/id_relay -o BatchMode=yes -o StrictHostKeyChecking=accept-new" \
  /data/downloads/<file> qbupload@<vps>:<name>

# 沙箱侧：路径穿越必须被拒（预期输出 rrsync error: do not use .. in arg）
rsync -a -e "ssh -i ~/.ssh/id_relay" \
  ../../etc/evil.bin qbupload@<vps>:evil.bin
# 验收：VPS 上 /etc/evil.bin 与 /srv/qbupload/evil.bin 都不出现

# VPS 侧：确认锁死生效（预期被拒，拿不到 shell）
ssh -i ~/.ssh/id_relay qbupload@<vps> 'id'   # 应被 command= 强制转成 rrsync 报错，而非返回 uid
```

## 3. sshfs 只读挂载（VPS 侧查看中继目录，不做写操作）

```bash
# 前提：VPS 已装 sshfs + fuse
apt-get install -y sshfs

# 用 root 自己的密钥挂载（不是 qbupload 用户；只读镜像中继目录）
mkdir -p /mnt/qbupload-ro
sshfs -o ro,allow_other,IdentityFile=/root/.ssh/id_ed25519 \
  root@localhost:/srv/qbupload /mnt/qbupload-ro

# 用完卸载
fusermount -u /mnt/qbupload-ro
```

要点：
- 挂载对象是中继目录的**只读镜像**，验收只看、不写、不删。清中继副本走 VPS 本地 worker，
  不走 sshfs。
- `allow_other` 只在确有其他本地用户需要读时才加；单用户巡检可省略。
- sshfs 是 FUSE 文件系统，断连会残留挂载点，卸载失败时先 `umount -l` 再查占用进程。