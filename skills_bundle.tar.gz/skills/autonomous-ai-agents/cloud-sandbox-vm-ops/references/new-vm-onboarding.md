# 新 VM 接入评估与初始化（2026-11-16 yecao/aliyun 实战）

用户丢来已有服务的 VM 问"能做什么"时的标准动线，与最大的翻车点。

## 标准动线
1. `~/.ssh/config` 先找别名（本机惯例：`Host <alias>` + `IdentityFile ~/.ssh/lemon_<alias>_admin`），别问用户要地址。
2. 实测画像一条命令打全：`hostname; curl -4s ip.sb; nproc; free -h; df -h /; systemd-detect-virt; cat /etc/os-release | grep PRETTY`。
3. 网络定性三测：国内 ping（<YOUR_SERVER_IP>）、出境测（google/github http_code + time）、下载测速（speed.cloudflare.com/__down?bytes=<YOUR_USER_IDENTIFIER>）。
4. **`ss -tlnp` + `systemctl list-units --state=running` 盘点既有服务** —— 这步必须在任何写操作之前。

## 铁律：动防火墙前先放行所有既有监听端口
真实事故：在两台跑着 IX 专线（端口 20001：yecao=ssserver，aliyun=realm 转发）的机器上按方案 `ufw allow 22/80/443/8443 && ufw enable`，直接打断用户正在用的专线。用户问"你怎么把我专线弄断了"。

正确顺序：
```bash
ss -tlnp | awk 'NR>1{split($4,a,":"); print a[length(a)]}' | sort -un   # 既有端口清单
# 逐个 ufw allow <port>/tcp（UDP 服务如 SS 还要 /udp）之后才能 enable
```
既有多协议端口（shadowsocks 等）要 tcp+udp 都放。

## 云商控制台防火墙是独立一层
野草云实测：ufw 全关 + gost 监听 8443/443/8080/9443/18443，外部全 blocked——控制台层面只放行了 22/20001，机器内部改不了。症状识别：`ufw status` 规则正确、iptables 无 DROP，但外部端口不通且本机 telnet 也不通 → 是云商层，让用户去面板开，别在机器里反复折腾。

## 出境差的国内机：autossh -D 隧道（已验证方案）
get.docker.com 直连可能超时；gost 端口被云商挡时，走已通的 22 端口做 SSH 动态转发最稳：

```ini
# /etc/systemd/system/ssh-egress.service（国内机上）
[Service]
Environment=AUTOSSH_GATETIME=0
ExecStart=/usr/bin/autossh -M 0 -N -o ServerAliveInterval=30 -o ExitOnForwardFailure=yes \
  -o StrictHostKeyChecking=accept-new -D 127.0.0.1:1080 root@<境外IP> -i /root/.ssh/<key>
Restart=always
```
互信：国内机生成 key，公钥追加到境外机 `/root/.ssh/authorized_keys`。
验证：`curl --socks5-hostname 127.0.0.1:1080 https://www.google.com` → 200。
注意 `--socks5-hostname`（本地 DNS 也走代理），裸 `--socks5` 在 DNS 污染环境下仍会失败。

## 国内 apt 源坑（阿里云 Debian 11）
- 内网 mirror `mirrors.cloud.aliyuncs.com` 缺 `bullseye-backports` Release → `apt-get update` 直接报错且 get.docker.com 装不上。换 `mirrors.aliyun.com` 后 backports 仍缺，直接 `sed -i '/backports/d'` 删掉该行。
- 卡死的 `apt-get update`（>5min）要按 PID kill，lock 才释放；kill 后重跑。
- 改 sources.list 前先 `cp` 备份。

## 本机两台机器档案（2026-11-16 实测）
- yecao=<YOUR_SERVER_IP> 香港 2C/1G/10G Debian 13，国内延迟 2.4ms，出境自由；控制台只开 22/20001。定位：境外出口。
- aliyun=<YOUR_SERVER_IP> 北京 2C/2G/40G Debian 11，国内 5-7ms，Google 不通。定位：国内工作机，出境走 yecao 隧道（ssh-egress.service, 127.0.0.1:1080）。
- 两台 20001 都是 IX 专线，任何防火墙操作必须先放行。
