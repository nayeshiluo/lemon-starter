# InstaBox REST API 实测档案（2026-10-23 从 `/v1/openapi.json` 核对）

## 拿到 schema 的正确姿势

未公开文档的 API，先摸 OpenAPI 位置，比猜接口快十倍：

```bash
# 这些 404：/openapi.json  /docs  /v1/docs  /swagger.json
curl -sS -H "X-API-Key: $KEY" https://api.instabox.sh/v1/openapi.json -o /tmp/ib_openapi.json
# → 200，224KB，94 条 path
```

然后按关键字筛，别整份打印：

```python
import json
d = json.load(open('/tmp/ib_openapi.json'))
for p, v in d['paths'].items():
    if any(k in p for k in ('lease', 'suspend', 'resume', 'lifecycle')):
        print(p, list(v.keys()))
print(json.dumps(d['components']['schemas'].get('MaxRunMinutes', {}), ensure_ascii=False, indent=2))
```

## 鉴权

- Header `X-API-Key: ibk_...`（也支持 `bearerAuth` / `sessionCookie`）
- key 来源：面板 Profile → API keys
- scope：`machines:write` / `machines:exec`
- **key 不要写进脚本正文或聊天记录**；落地为 `600` 独立文件（如 `/etc/instabox/api.key`），脚本读文件

## 关键接口

### GET /v1/machines
返回 `{"machines":[...], "nextCursor":null}`。每台机器关键字段：

| 字段 | 含义 |
|---|---|
| `state` / `desiredState` | `running` / `paused` / `suspended` … |
| `autoSuspendAfterSeconds` | 闲置多少秒后暂停；免费机固定 `1800` |
| `maxRunMinutes` | 连续运行上限；免费机默认 `480`（8h），`-1` = 无限 |
| `runStartedAt` | 本次连续运行起点，确认 sleep 后才重置 |
| `autoSuspendedAt` | 被自动暂停的时间 |
| `cooldownUntil` | 冷却截止；max-run 暂停后非 null |
| `runtime.ready` / `runtime.processesPreserved` | 就绪 / 暂停保留进程 |
| `free` | 是否免费档 |

### PUT /v1/machines/{id}/activity-leases/{leaseID} ← 保活正解
官方描述原文：
> Creates or renews a task lease, **waking an idle-suspended machine first**. Renew before expiry while working and delete when finished. Expiry starts a full idle period; an explicit lifecycle operation invalidates leases. At most 128 active task leases per machine.

- 请求体字段是 **`ttlSeconds`**（30–3600，默认 300）——**不是** `durationSeconds`
- `leaseID` 自己起名，`^[A-Za-z0-9_-]{1,64}$`；**同名重复 PUT = 续期**
- 无需 `Idempotency-Key`
- 响应：`{"id","machineId","expiresAt"}`（实测 `ttlSeconds:1800` → `expiresAt` 正好 +30min）
- 计费/暂停判定的语义是「lease 未到期 = 有任务在跑」，所以它管得住 30 分钟闲置，但**管不住 `maxRunMinutes`**

### DELETE /v1/machines/{id}/activity-leases/{leaseID}
幂等；**记录完成活动但不唤醒机器**。任务做完要主动释放，否则要等 ttl 到期才开始算闲置。

### PATCH /v1/machines/{id}
- **必须带 `Idempotency-Key` 头**（1–200 可打印字符），否则 `400 Idempotency-Key header is required`
- 可改字段：`name`、`metadata`、`autoSuspendAfterSeconds`、`maxRunMinutes`、`rootDiskGiB`、`persistentDiskGiB`、`vault`
- 传 `null` 改 `autoSuspendAfterSeconds` 会报 `400 nothing to change: give name, rootDiskGiB, ...`（说明 null 不被接受为“关闭”）
- 实测 `{"autoSuspendAfterSeconds":7200}` 返回 **200 但值仍是 1800** —— 免费档改不动，别把 200 当成功
- `maxRunMinutes` 同理：`Free machines default to 480 and only an admin session can change them`

### POST /v1/machines/{id}/suspend | /resume
`suspend` 暂停并保留进程；`resume` 原地恢复。两者都要 `Idempotency-Key`。

## 暂停/冷却语义（决定监控告警怎么写）

- 两条件**谁先到谁触发**：闲置 `autoSuspendAfterSeconds`、连续运行 `maxRunMinutes`
- max-run 触发后进入服务端冷却（默认 10 分钟），**所有唤醒路径**返回
  `409 machine_cooldown` + `Retry-After`
- 冷却结束仍为 `0` 时唤醒返回 `409 max_run_disabled`
- 结论：免费机是「跑满 8h → 停 ~10min → 自动可恢复」的循环，保活消不掉这个断点
- 监控里 SSH/agent 失联要先判 `cooldownUntil`/`state`，别直接报红色故障

## 常见第三方保活脚本的错误（评审清单）

拿到别人写的 lease 脚本，按这五条过一遍：

1. **字段名**：`ttlSeconds` vs `durationSeconds` —— 发错字段服务端按默认 300s 处理，能跑但语义错
2. **ttl 上限**：`maximum: 3600`，写 7200 会被截断/拒绝
3. **续期间隔 < ttl**：ttl=1800 配 sleep 600 可以；ttl=300 配 sleep 600 会中间断开
4. **进程存活**：`nohup ... &` 放 `/tmp` 重启即失效 → 必须 systemd 常驻 `Restart=always`
5. **ID 提取**：`grep -oE 'm_[a-z0-9]{26}'` 依赖固定长度，格式一变静默失效 → 用 `jq -r '.machines[].id'`
