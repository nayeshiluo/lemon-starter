# InstaBox REST API 实测档案（2026-10-23 从 `/v1/openapi.json` 核对）

## 拿到 schema 的正确姿势

未公开文档的 API，先摸 OpenAPI 位置，比猜接口快十倍：

```bash
# 这些 404：/openapi.json  /docs  /v1/docs  /swagger.json
curl -sS -H "X-API-Key: $KEY" https://api.instabox.sh/v1/openapi.json -o /tmp/ib_openapi.json
# → 200，224KB，94 条 path
```

然后按关键字筛，别整份打印：

```python
import json
d = json.load(open('/tmp/ib_openapi.json'))
for p, v in d['paths'].items():
    if any(k in p for k in ('lease', 'suspend', 'resume', 'lifecycle')):
        print(p, list(v.keys()))
print(json.dumps(d['components']['schemas'].get('MaxRunMinutes', {}), ensure_ascii=False, indent=2))
```

## 鉴权

- Header `X-API-Key: ibk_...`（也支持 `bearerAuth` / `sessionCookie`）
- key 来源：面板 Profile → API keys
- scope：`machines:write` / `machines:exec`
- **key 不要写进脚本正文或聊天记录**；落地为 `600` 独立文件（如 `/etc/instabox/api.key`），脚本读文件

## 关键接口

### GET /v1/machines
返回 `{"machines":[...], "nextCursor":null}`。每台机器关键字段：

| 字段 | 含义 |
|---|---|
| `state` / `desiredState` | `running` / `paused` / `suspended` … |
| `autoSuspendAfterSeconds` | 闲置多少秒后暂停；免费机固定 `1800` |
| `maxRunMinutes` | 连续运行上限；**每台不同**（实测同账号下 480 与 120 并存），`-1` = 无限 |
| `runStartedAt` | 本次连续运行起点，确认 sleep 后才重置 |
| `autoSuspendedAt` | 被自动暂停的时间 |
| `cooldownUntil` | 冷却截止；max-run 暂停后非 null |
| `runtime.ready` / `runtime.processesPreserved` | 就绪 / 暂停保留进程 |
| `free` | 是否免费档 |

### PUT /v1/machines/{id}/activity-leases/{leaseID} ← 保活正解
官方描述原文：
> Creates or renews a task lease, **waking an idle-suspended machine first**. Renew before expiry while working and delete when finished. Expiry starts a full idle period; an explicit lifecycle operation invalidates leases. At most 128 active task leases per machine.

- 请求体字段是 **`ttlSeconds`**（30–3600，默认 300）——**不是** `durationSeconds`
- `leaseID` 自己起名，`^[A-Za-z0-9_-]{1,64}$`；**同名重复 PUT = 续期**
- 无需 `Idempotency-Key`
- 响应：`{"id","machineId","expiresAt"}`（实测 `ttlSeconds:1800` → `expiresAt` 正好 +30min）
- 计费/暂停判定的语义是「lease 未到期 = 有任务在跑」，所以它管得住 30 分钟闲置，但**管不住 `maxRunMinutes`**

### DELETE /v1/machines/{id}/activity-leases/{leaseID}
幂等；**记录完成活动但不唤醒机器**。任务做完要主动释放，否则要等 ttl 到期才开始算闲置。

### PATCH /v1/machines/{id}
- **必须带 `Idempotency-Key` 头**（1–200 可打印字符），否则 `400 Idempotency-Key header is required`
- 可改字段：`name`、`metadata`、`autoSuspendAfterSeconds`、`maxRunMinutes`、`rootDiskGiB`、`persistentDiskGiB`、`vault`
- 传 `null` 改 `autoSuspendAfterSeconds` 会报 `400 nothing to change: give name, rootDiskGiB, ...`（说明 null 不被接受为“关闭”）
- 实测 `{"autoSuspendAfterSeconds":7200}` 返回 **200 但值仍是 1800** —— 免费档改不动，别把 200 当成功
- `maxRunMinutes` 同理：`Free machines default to 480 and only an admin session can change them`

### POST /v1/machines/{id}/suspend | /resume
`suspend` 暂停并保留进程；`resume` 原地恢复。两者都要 `Idempotency-Key`。

### POST /v1/machines/{id}/ssh-tokens ← SSH 登不进时的可靠路径（2026-10-29 实测）

面板截图/复制出来的 token **不一定能登**（实测 `Permission denied (publickey)`，而机器 `state=running` + `runtime.ready=true`）。别去动机器，直接重签：

```bash
curl -sS -X POST -H "X-API-Key: $KEY" -H "Content-Type: application/json" \
  -H "Idempotency-Key: tok-$(date +%s)" \
  -d '{"name":"hermes-lab"}' \
  https://api.instabox.sh/v1/machines/$MID/ssh-tokens
```

返回体带 `token`、完整 `command`、`expiresAt`（默认 +7 天）、`hostKeyFingerprint`。签发后立刻可连。

配套坑：

- `GET /v1/machines/{id}/connection-info` 里的 `username` 是 **machineId**，不是 SSH 登录名，拿它当用户名同样登不进。
- 老 token 列表用 `GET /v1/machines/{id}/ssh-tokens` 查（只回 `id`/`name`/`createdAt`，不回 token 值，值只在创建时给一次）。
- 面板截图里的 token 可能是 OCR 误读（`l/1`、`0/o`），别拿肉眼抄的值当唯一真相。

### POST /v1/machines ← 建机（先确认是不是你该做的事）

- 全部字段可选；`templateId` / `snapshotId` 二选一，都不给就默认 `agent-browser`
- **必须带 `Idempotency-Key`**；返回的是 `op_...` 操作对象，含 `machineId`，创建是异步的（`state: queued`）
- `deleteAfterSeconds`（60–86400）：到点无论状态一律删除，**自己建的实验机必须带**，实测 86400 生效（`deleteAt` 可在 GET 里核对）
- `archiveSeconds`（60–86400）：到点停止但保留
- `desiredState`：`running`（默认）/ `stopped`

> ⚠️ 工作流纪律：用户说"我再弄一台这种机子，你来操作"指的是**他自己去面板开**，不是授权你调这个接口。擅自建机被纠正过一次。建了就要说清楚，并给一个明确的处理选项（继续用 / 删掉）。

### 多账号：一个 key 只能看一个 org

`GET /v1/machines` 只返回当前 key 所属 org 的机器。新开一个 InstaBox 账号 = **再加一个保活实例**（不同 `KEYFILE` / `LOG` / `LEASE`），不是改现有脚本，也绝不能覆盖已有账号的 unit。落地方式见 `scripts/sandbox-lease-keepalive-multi.sh`。

## 暂停/冷却语义（决定监控告警怎么写）

- 两条件**谁先到谁触发**：闲置 `autoSuspendAfterSeconds`、连续运行 `maxRunMinutes`
- max-run 触发后进入服务端冷却（默认 10 分钟），**所有唤醒路径**返回
  `409 machine_cooldown` + `Retry-After`
- 冷却结束仍为 `0` 时唤醒返回 `409 max_run_disabled`
- 结论：免费机是「跑满上限 → 停 ~10min → 自动可恢复」的循环，保活消不掉这个断点
- 监控里 SSH/agent 失联要先判 `cooldownUntil`/`state`，别直接报红色故障

### ⚠️ 第三种状态：合规锁定 `abuse_proxy`（2026-11-24 实测）

`409 machine_cooldown` 不一定是 10 分钟的 max-run 冷却。看 `reason` 和 `retryAfterSeconds`：

| 判据 | 普通 max-run 冷却 | **合规锁定 `abuse_proxy`** |
|---|---|---|
| `reason` | 无 | `abuse_proxy` |
| `retryAfterSeconds` | ~600 | 几万（十几小时） |
| message | 普通冷却措辞 | 复述违规行为（如 "kept running a proxy server (sing-box, port 18080) after we asked you to stop it, free plan, Terms 2(e)"） |
| 保活能救回吗 | 能 | **不能** |

免费档条款禁止在沙箱里跑代理服务。**在免费沙箱跑 sing-box / dante / xray = 迟早被平台按条款冻结**，不要指望 lease/SSH 保活顶住。被锁期间 `exec` / `files` / `snapshots` 全部 409/404，**磁盘内容取不回来** → 退役前必须先备份。

### ⚠️ API 响应大小有静默截断（2026-11-24 实测）

| 通道 | 截断上限 | 现象 |
|---|---|---|
| `POST /v1/machines/{id}/exec` 的 stdout | **1 MiB**（1048576） | 静默截断，**不报错** |
| `GET /v1/machines/{id}/files` 的 `content` | **256 KiB**（262144） | 静默截断，**不报错** |

拉大文件必须**在机器上分块再逐块拉**（`split -b 200000`，404 作为终止条件），并在两端比对 sha256。工具：`scripts/ib-export-chunked.py`。

## 退役（删除机器）相关端点（2026-11-24 实测）

| 方法 | 路径 | 说明 |
|---|---|---|
| DELETE | `/v1/machines/{id}` | 删机器 + 系统文件 + 存储。返回 `op_...`（`type: "delete"`, `state: "queued"`），**异步** |
| DELETE | `/v1/machines/{id}/ports/{port}` | 删公开端口。返回**空 body**（非 JSON），200 即成功 |
| DELETE | `/v1/machines/{id}/ssh-tokens` | 一次性吊销全部 SSH token，返回 `{"revoked":1}` |
| POST | `/v1/machines/{id}/stop` | 停机，返回 `op_...`（`state: "queued"`） |

坑：

- **`machine id 不要硬编码进脚本**——从 `GET /v1/machines` 动态取。返回结构是 `{"machines":[...]}`，不是裸数组；按裸数组写会 `KeyError: 'id'`。
- **`GET /v1/machines/{id}/snapshots` 这个路由不存在** → `404 route not found`（区别于 `404 machine not found`）。快照是独立资源：`POST /v1/machines/{id}/snapshots` 建、`DELETE /v1/snapshots/{id}` 删。用 "route not found" vs "machine not found" 区分「路由写错」和「机器没了」。
- 机器删除是**异步**的，删完再调 ports/SSH-token 的 DELETE 会 `404 machine not found`——这是**正常终态**，别重试。

完整退役流程（资产盘点、备份、外部依赖清理、验收）见 `references/instabox-decommission.md`。

## 常见第三方保活脚本的错误（评审清单）

拿到别人写的 lease 脚本，按这五条过一遍：

1. **字段名**：`ttlSeconds` vs `durationSeconds` —— 发错字段服务端按默认 300s 处理，能跑但语义错
2. **ttl 上限**：`maximum: 3600`，写 7200 会被截断/拒绝
3. **续期间隔 < ttl**：ttl=1800 配 sleep 600 可以；ttl=300 配 sleep 600 会中间断开
4. **进程存活**：`nohup ... &` 放 `/tmp` 重启即失效 → 必须 systemd 常驻 `Restart=always`
5. **ID 提取**：`grep -oE 'm_[a-z0-9]{26}'` 依赖固定长度，格式一变静默失效 → 用 `jq -r '.machines[].id'`
