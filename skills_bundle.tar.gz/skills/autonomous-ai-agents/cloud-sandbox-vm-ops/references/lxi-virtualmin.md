# lxi.be Virtualmin 托管沙箱（naye.lxi.be）

接入日期 2026-11-19。用户丢来的是"域名+面板+SSH/SFTP+邮箱"套餐式凭据卡，形态如下：

```
Domain     naye.lxi.be
Panel      https://panel.lxi.be/        (用户名 naye + 初始密码)
SSH/SFTP   panel.lxi.be · port 2222     (用户名 naye + 初始密码，非 token)
FTPS       panel.lxi.be · port 2121 TLS
Webmail    https://webmail.lxi.be/
IMAP       mail.lxi.be:993 SSL          SMTP mail.lxi.be:587 STARTTLS
邮箱登录名 = 完整邮箱地址 user@example.com
```

## 实测要点

- SSH 2222 一次密码登录即通（Ubuntu 宿主，内核 6.8，KVM）。
- 密钥安装照常：追加 `~/.ssh/authorized_keys`，配本机别名 `Host lxi`（HostName panel.lxi.be, Port 2222, User naye）。初始密码建议用户尽快在面板改掉。
- `/workspace` 即整个可见世界：`public_html`（网站根）、`Maildir`（邮箱）、`etc/php8.3 / etc/php8.4`、`cgi-bin`、`logs`、`virtualmin-backup`。
- `sudo` 报 `libsudo_util.so.0` 缺库 —— 这不是机器坏了，是 chroot jail 里根本不带 sudo。**无 root**。
- 8 核 / 7.7G 内存 / 193G 盘是共享宿主的配额视图，不是独占机。

## chroot jail 判据（与真 VPS 的区分）

一条命令打全，任中两条基本就是 jail：

1. **网络 loopback-only**：`ip addr` 只有 `lo`；curl/DNS 配置正常但 `connect: Network is unreachable`，`/dev/tcp/1.1.1.1/443` 同样 unreachable。
2. **sudo 缺库或不存在**、无 `/etc/os-release`、无 systemd 可见性。
3. **home 目录就是业务目录**（public_html/Maildir/php 等），不是常规 `/home/<user>`。

## 后果与结论口径

- **探针接不进去**：Komari/Monitor agent 都是主动外连，出站为零 + 无 root ⇒ 无法接入。这是平台封死不是配置问题，向用户如实说"除非服务商开白名单"。
- **用途判定**：这类账户只能做"建站（宿主 Apache/PHP-FPM 代跑）+ 收发邮件"。SSH 是文件管理入口，不能当代理节点/下载机/部署机。
- 用户"想买台能跑东西的服务器"却买了这种套餐时，直接点破：买错了，或确认他就是要建站收信。

接入信息（密钥指纹等）已进本机 `~/.ssh/config` 的 `Host lxi`，节点接入状态以 Komari 在册为准（本机预计永远不在册）。
