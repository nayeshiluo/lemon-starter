# InstaBox 沙箱实测档案

## 是什么
InstaBox（instabox.sh）是云端 Linux 沙箱平台，面板里有 **Terminal / Computer / Ports / Files / Settings** 标签页。
- `Terminal` = 一个 shell；`Computer` = 真实桌面（XFCE + Chromium），可在浏览器里观看。
- 机器名形如 `instabox-agent-browser-xoel`，即“代理浏览器”模板。
- 免费方案：永不计费，但**闲置 30 分钟或累计运行 8 小时自动暂停**，暂停后 SSH 不可达，需在面板重新启动。

## 连接
面板机器详情页 `SSH` 栏给出四要素（`Create token` 可重新生成，旧 token 立即失效）：

| 字段 | 实测值/形态 |
|---|---|
| HostName | `ssh.instabox.sh` |
| Port | `2222` |
| User | `ibssh_...`（**token 本身即用户名，无密码、无 SSH key**） |
| Mosh | `mosh --ssh="ssh -p 2222" <token>@mosh.instabox.sh` |

```bash
ssh -p 2222 <token>@ssh.instabox.sh
```

CLI 形态（本机装了 instabox CLI 时）：
- `instabox ssh <machine_id>` — 进 shell
- `instabox exec <machine_id> -- <cmd>` — 跑单条命令
- `instabox files <machine_id> [PATH]` — 浏览文件
- `instabox ssh-config <machine_id>` — 生成 VS Code/Cursor 用的 ssh config
- `instabox-port publish 3000` / `list` / `unpublish <port>` — 临时公网 URL（沙箱运行期间有效）
- `instabox-computer-use` MCP 驱动同一个桌面

## 实测环境（Debian 13 trixie 镜像）
- 内核 `6.18.x-instabox`，4 vCPU / 约 7.8 GiB 内存（`free -m` total 7964MB，available 约 7112MB）
- 根盘 `/dev/root` 16G（实测用量 3.9G / 27%），**不是 8.7G** —— 别把别台小机的 `df` 结果串到这台
- `machine-id` 可用于判断实例是否被平台重建过（重建会变，重启不会变）
- 用户 `user`，在 `sudo` 组且 **`sudo -n` 免密**，也在 `docker` 组
- 工作目录约定 `/data/workspace`；`$HOME` 在 `/data/home`
- 预装：`git gh curl jq node npm python3 uv go cargo docker docker compose claude codex chromium`
- 自述文件：`~/MACHINE.md`（机器 ID/尺寸/工具/桌面启动方式）、`~/AGENTS.md`、`~/README.md`
- 桌面：XFCE，`DISPLAY=:1`，Xvnc 监听 `127.0.0.1:5901`（`-SecurityTypes None -AlwaysShared -nolisten tcp`），由面板 Computer 标签页拉起
- 默认分辨率异常小（实测 `367x515`），先 `xrandr -s 1280x800` 再操作
- 没有 `x11vnc / websockify / ffmpeg / wmctrl / tmux`；有 `xdotool`、`scrot`、`xrandr`
- Playwright/Puppeteer 从新 shell 启动的浏览器会显示在 `:1` 上（headed）；`INSTABOX_HEADLESS=1` 保持无头

## 已验证的操控序列
```bash
export DISPLAY=:1
xrandr -s 1280x800
nohup chromium --no-sandbox --user-data-dir=/tmp/cprof1 --no-first-run about:blank >/tmp/ch.log 2>&1 &
sleep 8
w=$(xdotool search --onlyvisible --class Chromium | head -1)   # 实测返回窗口 id
xdotool windowactivate --sync $w
xdotool key --window $w ctrl+l
xdotool type --window $w --delay 40 "https://example.com"
xdotool key --window $w Return
xdotool getwindowname $w    # → "Example Domain - Chromium"
scrot -o /tmp/shot.png
```
本地取图：`scp -P 2222 <token>@ssh.instabox.sh:/tmp/shot.png /tmp/instabox-screen.png`

## 注意
- token 等同免密登录凭证，**不要写进技能/仓库/群聊**；泄露就让用户在面板 `Create token` 重新生成。
- 沙箱“无公网地址”，要对外提供服务只能用 `instabox-port`，且只在运行期间有效。
- 加入监控探针时 agent 走外连即可（沙箱出站正常，实测 `curl https://github.com` 200）。
