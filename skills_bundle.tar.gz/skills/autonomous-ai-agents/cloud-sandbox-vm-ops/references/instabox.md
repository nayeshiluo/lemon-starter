# InstaBox 沙箱实测档案

## 是什么
InstaBox（instabox.sh）是云端 Linux 沙箱平台，面板里有 **Terminal / Computer / Ports / Files / Settings** 标签页。
- `Terminal` = 一个 shell；`Computer` = 真实桌面（XFCE + Chromium），可在浏览器里观看。
- 机器名形如 `instabox-agent-browser-xoel`，即“代理浏览器”模板。
- 免费方案：永不计费，有**两道暂停机制**（均来自 2026-10-23 API 实测验证）：
  - **闲置 30 分钟**（`autoSuspendAfterSeconds: 1800`）：文件/内存/进程全保留，恢复 <1 秒
  - **连续运行 8 小时**（`maxRunMinutes: 480`）：强制暂停 + 冷却期约 10 分钟，冷却期唤醒返回 `409 machine_cooldown`；冷却结束后可恢复，计时重置
- 算“活动”的操作（重置闲置计时）：执行命令、读写文件、SSH、访问公开端口 URL。agent 自身的上报流量**不算**。
- `instabox auto-suspend <机器> 0` 可关闲置暂停，但属 manual lifecycle，免费档固定；API key 无法改 `maxRunMinutes`（只有管理员 session 可改）。

## 连接
面板机器详情页 `SSH` 栏给出四要素（`Create token` 可重新生成，旧 token 立即失效）：

| 字段 | 实测值/形态 |
|---|---|
| HostName | `ssh.instabox.sh` |
| Port | `2222` |
| User | `ibssh_...`（**token 本身即用户名，无密码、无 SSH key**） |
| Mosh | `mosh --ssh="ssh -p 2222" <token>@mosh.instabox.sh` |

```bash
ssh -p 2222 <token>@ssh.instabox.sh
```

CLI 形态（本机装了 instabox CLI 时）：
- `instabox ssh <machine_id>` — 进 shell
- `instabox exec <machine_id> -- <cmd>` — 跑单条命令
- `instabox files <machine_id> [PATH]` — 浏览文件
- `instabox ssh-config <machine_id>` — 生成 VS Code/Cursor 用的 ssh config
- `instabox-port publish 3000` / `list` / `unpublish <port>` — 临时公网 URL（沙箱运行期间有效）
- `instabox-computer-use` MCP 驱动同一个桌面

## 实测环境（Debian 13 trixie 镜像）
- 内核 `6.18.x-instabox`，4 vCPU / 约 7.8 GiB 内存（`free -m` total 7964MB，available 约 7112MB）
- 根盘 `/dev/root` 16G（实测用量 3.9G / 27%），**不是 8.7G** —— 别把别台小机的 `df` 结果串到这台
- `machine-id` 可用于判断实例是否被平台重建过（重建会变，重启不会变）
- 用户 `user`，在 `sudo` 组且 **`sudo -n` 免密**，也在 `docker` 组
- 工作目录约定 `/data/workspace`；`$HOME` 在 `/data/home`
- 预装：`git gh curl jq node npm python3 uv go cargo docker docker compose claude codex chromium`
- 自述文件：`~/MACHINE.md`（机器 ID/尺寸/工具/桌面启动方式）、`~/AGENTS.md`、`~/README.md`
- 桌面：XFCE，`DISPLAY=:1`，Xvnc 监听 `127.0.0.1:5901`（`-SecurityTypes None -AlwaysShared -nolisten tcp`），由面板 Computer 标签页拉起
- 默认分辨率异常小（实测 `367x515`），先 `xrandr -s 1280x800` 再操作
- 没有 `x11vnc / websockify / ffmpeg / wmctrl / tmux`；有 `xdotool`、`scrot`、`xrandr`
- Playwright/Puppeteer 从新 shell 启动的浏览器会显示在 `:1` 上（headed）；`INSTABOX_HEADLESS=1` 保持无头

## 已验证的操控序列
```bash
export DISPLAY=:1
xrandr -s 1280x800
nohup chromium --no-sandbox --user-data-dir=/tmp/cprof1 --no-first-run about:blank >/tmp/ch.log 2>&1 &
sleep 8
w=$(xdotool search --onlyvisible --class Chromium | head -1)   # 实测返回窗口 id
xdotool windowactivate --sync $w
xdotool key --window $w ctrl+l
xdotool type --window $w --delay 40 "https://example.com"
xdotool key --window $w Return
xdotool getwindowname $w    # → "Example Domain - Chromium"
scrot -o /tmp/shot.png
```
本地取图：`scp -P 2222 <token>@ssh.instabox.sh:/tmp/shot.png /tmp/instabox-screen.png`

## 保活（2026-10-23 已落地）

免费档无法改设置，只能定时制造活动。落地形态：

| 项 | 值 |
|---|---|
| 执行机 | `vps-la`（<PRIVATE_IDENTIFIER>，RackNerd），不占 AWS 出网额度 |
| 脚本 | `/usr/local/bin/instabox-keepalive.sh`（同 `scripts/sandbox-keepalive.sh`） |
| unit | `instabox-keepalive.service`（oneshot）+ `instabox-keepalive.timer`（`OnBootSec=3min`, `OnUnitActiveSec=15min`, `Persistent=true`） |
| 日志 | `/var/log/instabox-keepalive.log`，成功记 `ok ... OK <utc> up=<秒>s`，失败记 `FAIL rc=` |

实测验收输出：`status=0/SUCCESS`、日志 `2026-10-23 05:35:38+0000 ok ... OK 2026-10-23T05:35:38Z up=15253s`、`list-timers` 的 NEXT/LAST 相差 15 分钟。
oneshot 服务跑完显示 `inactive (dead)` 属正常，别当失败。

## 注意
- token 等同免密登录凭证，**不要写进技能/仓库/群聊**；泄露就让用户在面板 `Create token` 重新生成。保活配置放 `/etc/sandbox-keepalive.conf` 时权限 600。
- 沙箱“无公网地址”，要对外提供服务只能用 `instabox-port`，且只在运行期间有效。
- 加入监控面板时 agent 走外连即可（沙箱出站正常，实测 `curl https://github.com` 200、到 `la.<PRIVATE_IDENTIFIER>:2096` 面板 200）。
- `sudo -n` 免密是真的可用（`sudo touch` 实测通过）；若某条写命令被 `BLOCKED: ... without user response` 拦住，那是 Hermes 的写库/危险操作审批弹窗在等人点允许，不是沙箱没权限。
