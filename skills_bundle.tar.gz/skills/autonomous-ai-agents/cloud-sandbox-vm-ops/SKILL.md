---
name: cloud-sandbox-vm-ops
description: "云沙箱/远程VM运维：SSH接入、无头桌面操控、截图回传与探针纳管。"
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux]
metadata:
  hermes:
    tags: [sandbox, ssh, remote-desktop, xvnc, xdotool, instabox, vm, probe]
    related_skills: [computer-use, nezha-ops, aws-ec2-ops]
---

# 云沙箱 / 远程 VM 运维与无头桌面操控

## When to Use
- 用户丢来一台云端沙箱/远程 VM（InstaBox、Codespaces 类、临时评测机）的连接信息或 PDF 截图，问“能不能连/能不能操控”；
- 需要在没有本地 cua-driver 的情况下，远程驱动一台 Linux 桌面（点浏览器、敲键盘、截图）；
- 要把一台外部沙箱机器纳管进监控探针（见 `nezha-ops`）。

> 若卡在 **SSH 登录本身被拒**（`Permission denied (publickey)`、`No available authentication methods`、老 RSA key 被 OpenSSH 9.x 拒、fail2ban 封禁），转 `ssh-login-troubleshooting`——那套双侧日志对照与 `sshd_config.d/` 最小变更流程在本技能之外单独维护。

## 铁律：先验证，再汇报
用户问“能连吗/能操控吗”时，**不接受只读配置就下结论**。必须做到：

1. 真实 SSH 登录成功（拿到 `id`、`uname -a`、`nproc`、`free -m`）；
2. 真实操控生效（启动一个 GUI 程序 + `xdotool` 输入 + 窗口标题/截图变化作为证据）；
3. 把截图回传到本地并用 Markdown 本地绝对路径展示给用户。

只跑到第 1 步就报“可以操控”属于未验证成功，禁止。

## 接入套路

### 1. 读凭据形态，别假设有密码/密钥
沙箱平台常见“token 即用户名、无密码无密钥”：
```bash
ssh -p 2222 <token>@ssh.<platform>.sh
```
首次连接会问 host key，`StrictHostKeyChecking accept-new` 即可（这类平台不开指纹校验）。
别名写法（含防 NAT 断连）：
```
Host <alias>
    HostName ssh.example.sh
    Port 2222
    User <token>
    StrictHostKeyChecking accept-new
    ServerAliveInterval 30
```
弱网再加 mosh：`mosh --ssh="ssh -p 2222" <token>@mosh.<platform>.sh`。
VS Code / Cursor 用 Remote-SSH 直接选该 Host。

### 2. 先读机器自述文件
沙箱镜像通常在 `$HOME` 放了 `MACHINE.md` / `AGENTS.md` / `README.md`，写明机器 ID、工作目录、已装工具、桌面启动方式。**先读它们，省掉一轮盲猜**。典型约定：干活目录 `/data/workspace`，桌面 `DISPLAY=:1`。

### 3. 桌面能力盘点（一条命令打全）
```bash
for c in Xvfb Xvnc xdotool scrot xrandr wmctrl ffmpeg chromium node docker tmux; do
  printf "%s: " $c; command -v $c || echo -; done
ss -ltnp | head -20          # 看 Xvnc 监听端口
ps aux | grep -Ei "xvfb|vnc|chrome" | grep -v grep
```
若 Xvnc 只监听 `127.0.0.1:5901`，说明平台前端在做隧道，**不要自己去开 x11vnc 或改端口**，直接用 `DISPLAY=:1` + xdotool 操作。

## 无头桌面操控标准动作（xdotool + scrot）

```bash
export DISPLAY=:1
xrandr -s 1280x800            # 默认常是 367x515 这种怪尺寸，先调到可用分辨率
nohup chromium --no-sandbox --user-data-dir=/tmp/cprof1 --no-first-run about:blank >/tmp/ch.log 2>&1 &
sleep 8
w=$(xdotool search --onlyvisible --class Chromium | head -1)
xdotool windowactivate --sync $w
xdotool key --window $w ctrl+l
xdotool type --window $w --delay 40 "https://example.com"
xdotool key --window $w Return
sleep 6
echo "标题: $(xdotool getwindowname $w)"     # ← 这就是“输入真的生效”的铁证
scrot -o /tmp/shot.png
```
回传：`scp -P <port> user@host:/tmp/shot.png /tmp/<name>.png`，再用 Markdown 本地路径贴给用户。

**验收口径**：窗口标题从 `about:blank - Chromium` 变成 `Example Domain - Chromium`，说明键入+导航都真实执行；只有进程在跑不算。

## 常见坑

1. **`xdotool search --name ""` 会刷出一堆空行**，用 `--onlyvisible --class <Class>` 收窄。
2. **`xrandr -s` 改分辨率后旧窗口位置失效**，改完再启动 GUI 程序。
3. **别用 `pkill -f` 批量清自己起的进程**：一旦被安全确认拦下会整条命令作废（连带后续步骤），改成按 PID 或 `--user-data-dir` 精确匹配，并且把清理动作单独成一条命令。
4. **清理/改 `~/.ssh/config` 这类写操作要与诊断命令分开执行**，一条命令里混了 pkill + 写配置，被拦时全部不生效，排查时会误判“配置已写”。
   - 补充（2026-10-23 实测）：`~/.ssh/config` 属受保护凭据文件，`patch`/`write_file` 会被直接拒绝（`Write denied: ... protected system/credential file`）。要用 shell 追加：先 `cp` 备份，再 `printf '...' >> ~/.ssh/config`，最后 `grep -A4` 回读验证。
   - 若命令持续返回 `BLOCKED: Command timed out without user response`，说明卡在人工审批而不是命令报错。**只有在用户明确说“全权放权/直接执行”之后**，才可临时 `hermes config set approvals.mode off` 干活，**做完立刻 `hermes config set approvals.mode manual` 还原**（改前先备份 `config.yaml`）。`approvals.deny` 里针对受保护服务（如 desktop-commander）的硬拦不受此影响，不要试图绕过。
5. **一次盘点多台机器时，必须逐台打标签，禁止跨机串数据**。真实事故：同一次会话里先查了 A 机（Ubuntu 24.04 / 1 核 / 913MB / 8.7G 盘 51%）再查 B 沙箱，汇报时把 A 的数字写成了 B 的规格，导致后续告警阈值按 913MB 设（实际 B 是 7964MB），险些误报。做法：每条 SSH 命令内部先 `echo "=== $(hostname) ==="`，采集完立刻把「主机名 + 规格」写成一行记下来再进入下一台；汇报前拿主机名和规格对一遍。
6. **免费沙箱会自动暂停，规则以平台文档为准，别抄二手转述**。InstaBox 官方文档（`instabox.sh/docs` 正文，2026-10-23 核实）只说：免费机**闲置 30 分钟**暂停；文档里**没有**“运行 8 小时上限”这条（面板上的 `Max runtime` 字段含义未核实，别当结论写）。
   - 暂停=挂起：文件、内存、进程全保留，恢复 <1 秒；
   - 算“活动”的操作：**执行命令、读写文件、SSH、访问公开端口 URL**（agent 自身的上报流量不算）；
   - 想关掉自动暂停要 `instabox auto-suspend <机器> 0`，属 manual lifecycle（管理员设置），方案对比表里只有 Pro/Team 是“自选或从不”，免费档固定 30 分钟。
   - **8 小时 (`maxRunMinutes: 480`) 是真实存在的限制**（2026-10-23 从 API 响应体 `GET /v1/machines` 实测确认，免费机默认 480 分钟连续运行上限）。该字段 `only an admin session can change`，API key 无法修改。8 小时到了平台强制暂停并进入冷却期（默认 10 分钟），期间任何唤醒路径都返回 `409 machine_cooldown with Retry-After`；等冷却结束恢复运行，计时重置。Activity-lease 和 SSH 保活都无法突破此上限，只能保住"30 分钟闲置"这道坎。面板 Monitor 的 InstaBox 节点在 8 小时+10 分钟冷却期间会短暂离线（正常现象，不是 agent 故障）。
   汇报能力时如实说明这两点（30 分钟闲置 + 8 小时连续运行），别承诺“长期在线”；给监控/告警脚本写判定时，SSH 失败要判成“疑似平台暂停/冷却”（⚪ 提示）而不是 🔴 故障。需要真保活见下节。
7. **视觉模型可能读不到截图**（上游 504 等）：此时不要卡住，截图仍然有效，直接把本地路径给用户看图，并说明自动读图暂不可用。
8. 沙箱通常已预装 `gh`/`git`/`claude`/`codex`，动手前先 `gh auth status`、`git config --get user.email` 看是否已登录，别急着要 token。

## 保活（免费档自动暂停的对策）

免费档关不掉自动暂停，只能**定时制造活动**。已验证可用的做法（2026-10-23 落地并实测）：

- 保活脚本**放在第三方常在线机器**上（如 `vps-la <PRIVATE_IDENTIFIER>`），不要放业务主机，避免占用 AWS 出网额度；
- 间隔 **15 分钟**（官方 30 分钟闲置才暂停，两次触碰间最多空 15 分钟，留一倍余量）；
- 用 systemd timer 而不是 crontab：`Persistent=true` 让机器重启后不丢节奏，`OnBootSec=3min` 避免开机抢网络。

脚本：`scripts/sandbox-keepalive.sh`（读 `/etc/sandbox-keepalive.conf`，含 host/port/token，权限 600）。unit 两份：

```ini
# /etc/systemd/system/sandbox-keepalive.service
[Unit]
Description=Sandbox keep-alive (SSH touch every 15 min)
After=network-online.target
Wants=network-online.target
[Service]
Type=oneshot
ExecStart=/usr/local/bin/sandbox-keepalive.sh
TimeoutStartSec=120
```

```ini
# /etc/systemd/system/sandbox-keepalive.timer
[Unit]
Description=Run sandbox keep-alive every 15 minutes
[Timer]
OnBootSec=3min
OnUnitActiveSec=15min
AccuracySec=30s
Persistent=true
Unit=sandbox-keepalive.service
[Install]
WantedBy=timers.target
```

部署与验收（缺一步都算没做完）：
```bash
sudo systemctl daemon-reload && sudo systemctl enable --now sandbox-keepalive.timer
sudo systemctl start sandbox-keepalive.service          # 立刻跑一次
sudo systemctl status sandbox-keepalive.service --no-pager | head -8   # 期望 status=0/SUCCESS
sudo tail -3 /var/log/sandbox-keepalive.log             # 期望 "... ok ... OK <ts> up=<秒>s"
sudo systemctl list-timers sandbox-keepalive.timer --no-pager | head -3  # NEXT/LAST 相差 15min
```
注意 `systemctl status` 里 oneshot 服务显示 `inactive (dead)` 是正常的（跑完即退），要看 `ExecStart ... status=0/SUCCESS` 和日志，不要误判失败。
`up=` 值能反推沙箱已经连续跑了多久；若日志开始出现 `FAIL rc=255`，先看面板是不是已被暂停/重建，别盲目提高触碰频率。

### 更优解：Activity Lease（平台官方保活语义，优先用它）

SSH 触碰是"装作有人用"，**Activity Lease 是平台显式提供的"任务进行中"声明**，语义正确、能主动唤醒已暂停的机器、不依赖 SSH 是否通。InstaBox 已核实可用（接口与字段见 `references/instabox-api.md`）：

- `PUT /v1/machines/{id}/activity-leases/{leaseID}`，请求体 `{"ttlSeconds":1800}`（**字段是 ttlSeconds，不是 durationSeconds**）
- 同一 `leaseID` 重复 PUT = 续期；`ttlSeconds` 上限 3600
- 续期间隔必须显著小于 ttl（ttl 1800 + 间隔 600 合适）
- 任务结束用 `DELETE` 同一 lease 主动释放
- 它**不能突破 `maxRunMinutes`**（免费机 480 分钟硬上限），只能消除 30 分钟闲置暂停

脚本 `scripts/sandbox-lease-keepalive.sh`，常驻服务（注意与上面 oneshot+timer 的写法不同）：

```ini
[Service]
Type=simple
ExecStart=/usr/local/bin/sandbox-lease-keepalive.sh
Restart=always
RestartSec=30
```

API key 落成 `/etc/instabox/api.key`（`600 root:root`），脚本读文件，**绝不把 key 写进脚本正文或聊天回复**。

两套可并存：timer 管 SSH 通道，lease 管 API 通道，互为兜底。日志里 `FAIL ... http=409 machine_cooldown` 是 8 小时上限触发的冷却，属预期，不要当故障去调频率。

### 评审别人给的保活脚本（常见坑，按条过）
1. 字段名 `ttlSeconds` vs `durationSeconds` —— 写错能跑但按默认 300s 生效；
2. ttl 写超 3600 会被截/拒；
3. `sleep` 间隔 ≥ ttl 会中间断档；
4. `nohup ... &` 放 `/tmp`：重启即失效，必须 systemd `Restart=always`；
5. `grep -oE 'm_[a-z0-9]{26}'` 抓 ID 依赖固定长度，格式一变静默失效 → `jq -r '.machines[].id'`。
评审结论要区分「原理对/字段错/部署方式错」，别笼统说"能用"或"不能用"。

## 远程 sudo 部署与授权弹窗（实测高频摩擦点）

往远端装系统服务要 `sudo`，而 `sudo install/tee` 这类写入会触发**人工审批弹窗**，超时（约 5 分钟）即整条命令作废。踩过两次后固化成流程：

1. **先把所有不需要 sudo 的活干完**：脚本、unit 文件、key 文件全部 `scp` 到远端 `/tmp`（写自己目录不触发审批），并 `ls -l` 确认真的落地了（scp 可能因整条 `&&` 链被拦而根本没执行）。
2. **再发一条尽量短的 sudo 命令**，一次把安装做完；不要在弹窗命令里混诊断、混 `sleep` 等待，被拦一次全部白费。
3. **永远同时给一条可自行粘贴的等价单行命令**作为兜底。用户经常在弹窗期间离开（"窗口再给我一次，我老是错过"），给他自己跑的版本比反复重发弹窗更省事。
4. **key 不要出现在聊天里**：把 key 写成远端 `/tmp` 下的 600 文件，命令里 `install -m 600 /tmp/xxx.key /etc/.../api.key` 引用它，收尾 `rm -f /tmp/xxx.key`。
5. 被 `BLOCKED: Command timed out without user response` 拦下后**不要原样重发**（规则明确禁止），改用「A. 你说发我就发弹窗 / B. 你自己粘贴这条」二选一，等用户回话。

## 纳管进探针
沙箱无公网 IP，走 agent **主动外连** Dashboard（出站），不需要端口映射。
- **当前在用的面板是自建 Monitor**（`https://la.<PRIVATE_IDENTIFIER>:2096`），加节点/补 traffic 行/无 root 部署 agent 全流程见 `monitor-hub-ops`；
- 哪吒（`nezha-ops`）已于 2026-10-23 全量退役，只作历史参考。

无 root 的沙箱用 **systemd --user** 装 Agent：
```bash
loginctl show-user <u> | grep Linger          # 必须 Linger=yes
systemctl --user is-system-running            # 必须 running
# 写 ~/.config/systemd/user/<agent>.service（ExecStart=%h/... , WantedBy=default.target）
systemctl --user enable --now <agent>
```
验收三件套：`systemctl --user is-active` = active、`is-enabled` = enabled、`ss -tn | grep <面板IP>` 有 ESTAB。**再加一步库侧验收**（`last_seen` 在 60 秒内、`metric` 有行），只看 `connected` 日志会漏掉“连上但数据被丢弃”的情况。

本机 SSH 别名约定（已落地）：`Host instabox-xoel` → `ssh.instabox.sh:2222`，User 为面板 token。

## 把沙箱接成下载节点 + 受限回传通道

沙箱不只跑采集，当第二台 BT/PT 下载机很划算。但前提是**假设平台管理员能读你沙箱里的一切**。

### 实测速度：瓶颈在回传，不在下载

| 环节 | 实测（InstaBox 免费档，2026-10-24） |
|---|---|
| 沙箱下行 | 峰值 **33.6 MB/s**，756MB **40 秒到 97.2%**，800+ peers |
| 沙箱 → 自有 VPS 回传 | **3.4 MB/s**（20MB / 5.9s，两端 md5 一致） |

结论：**下载随便跑，1GB 回传约 5 分钟才是真实成本**。别因为"沙箱带宽小"就只敢下小文件——要算的是回传时间，不是下载时间。

### 铁律：平台 token 永不落沙箱

沙箱只做**下载**。任何影视站/网盘/发种的 token 都不能进第三方沙箱。正确链路：

```
沙箱下载 → rrsync 回传自有 VPS 中继目录 → 由 VPS 本地 worker 完成上传
```

上传结束（**含"已存在"幂等跳过**）后必须清中继副本，否则反复下载会撑爆中转盘。

### 受限回传通道：受限用户 + `rrsync` 单向只写

不要给沙箱一个能读整机的 SSH 账号。用 `rrsync` 把整个 SSH 会话锁成「只能往一个目录写」：

```bash
# 自有 VPS 侧
useradd -r -m -d /home/qbupload -s /bin/bash qbupload
install -d -m 750 -o qbupload -g qbupload /srv/qbupload
# /etc/ssh/keys/qbupload  (root:root 644)
command="/usr/bin/rrsync -wo /srv/qbupload",restrict ssh-ed25519 AAAA... sandbox-relay@lemon
# /etc/ssh/sshd_config.d/99-qbupload.conf
Match User qbupload
    AuthorizedKeysFile /etc/ssh/keys/qbupload
    AllowTcpForwarding no
    AllowAgentForwarding no
    PermitTunnel no
    X11Forwarding no
    PermitTTY no
    PasswordAuthentication no
sshd -t && systemctl reload ssh        # ⚠️ 单元名是 ssh，不是 sshd
```

沙箱侧推送（密钥在沙箱生成，私钥不出沙箱）：

```bash
rsync -a --partial --inplace \
  -e "ssh -i ~/.ssh/id_relay -o BatchMode=yes -o StrictHostKeyChecking=accept-new" \
  /data/downloads/<file> qbupload@<vps>:<name>
```

**隔离自证是通道合格的判据，别省**：推 `../../etc/evil.bin` 应被服务端拒
`rrsync error: do not use .. in arg`，且 `/etc/evil.bin` 不出现。

完整安装脚本、验收命令与只读挂载（sshfs）配置见 `references/sandbox-file-relay.md`。

### 六个坑（都实测踩过）

1. **沙箱默认没装 rsync** → `sudo apt-get install -y -qq rsync`（实测 3.5.0）。不装直接 `rsync: command not found`。
2. **`StrictModes` 不能写进 sshd 的 `Match` 块** → `Directive 'StrictModes' is not allowed within a Match block`，`sshd -t` 当场失败。
3. **Debian/Ubuntu 的 systemd 单元名是 `ssh`**，`systemctl reload sshd` 报 `Unit sshd.service not found`。
4. **`AuthorizedKeysFile` 放 `Match` 块里时，密钥文件要 `root:root 644`** 且放 `/etc/ssh/keys/`；留在用户 home 会撞 StrictModes。
5. **sshfs 的 `-o allow_other` 需要 `/etc/fuse.conf` 里的 `user_allow_other`**，没有就干脆去掉该选项（单用户足够）。包成 `systemd --user` + `Restart=always`，`ExecStartPre/Stop` 先 `fusermount3 -uz` 再挂。
6. **远端路径校验要 `os.path.normpath` + 拒绝 `..`**：只 `startswith(root)` 不够，`/data/downloads/../etc/x` 能过前缀检查。写 `os.path.normpath(p) != p` 才挡得住。

### 8 小时暂停会打断下载与回传

`maxRunMinutes=480` 到点强制暂停，正在跑的下载和回传都会断。发大文件前先按 `runStartedAt + 480min` 算好窗口，别卡在临界点。回传中的文件用 `--partial --inplace` 才能在恢复后断点续传。

## 平台档案
- `references/instabox.md` — InstaBox 沙箱的实测参数（连接串、桌面、工具清单、暂停策略、保活落地细节）。
- `references/instabox-api.md` — InstaBox REST API 实测档案：`/v1/openapi.json` 拿 schema 的方法、鉴权、machines / activity-leases / PATCH / suspend-resume 字段、冷却语义、第三方脚本评审清单。
- `scripts/sandbox-keepalive.sh` — 保活脚本（SSH 定时触碰 + 日志），配 systemd timer 使用，见「保活」节。
- `scripts/sandbox-lease-keepalive.sh` — Activity Lease 保活守护（API 通道，常驻 `Restart=always`），见「保活 / 更优解」。
