#!/bin/bash
# 云沙箱保活：定时 SSH 触碰一次，重置平台的“闲置自动暂停”计时。
# 实测于 InstaBox 免费档（闲置 30 分钟自动暂停），部署在第三方常在线机器上（如 vps-la），
# 不占用业务主机的出网流量。配合 instabox-keepalive.timer 每 15 分钟触发。
#
# 用法：
#   sudo install -m 755 sandbox-keepalive.sh /usr/local/bin/sandbox-keepalive.sh
#   sudo install -m 644 sandbox-keepalive.conf /etc/sandbox-keepalive.conf   # 见下方变量
#   sudo systemctl start sandbox-keepalive.service                          # 手动跑一次验证
#
# 配置文件 /etc/sandbox-keepalive.conf（权限 600，含登录 token）：
#   SBX_HOST=ssh.instabox.sh
#   SBX_PORT=2222
#   SBX_USER=ibssh_xxxxxxxx        # 平台 token，本身即用户名
set -uo pipefail

CONF=${CONF:-/etc/sandbox-keepalive.conf}
LOG=${LOG:-/var/log/sandbox-keepalive.log}
# shellcheck disable=SC1090
[ -r "$CONF" ] && . "$CONF"

: "${SBX_HOST:?SBX_HOST missing}"
: "${SBX_PORT:=22}"
: "${SBX_USER:?SBX_USER missing}"

TS=$(date '+%Y-%m-%d %H:%M:%S%z')

out=$(timeout 60 ssh -p "$SBX_PORT" -o BatchMode=yes -o StrictHostKeyChecking=accept-new \
        -o ConnectTimeout=20 -o ServerAliveInterval=10 "$SBX_USER@$SBX_HOST" \
        'echo "OK $(date -u +%FT%TZ) up=$(cut -d. -f1 /proc/uptime)s"' 2>&1)
rc=$?

if [ $rc -eq 0 ]; then
  echo "$TS ok $out" >> "$LOG"
else
  # rc!=0 常见于沙箱已被暂停/删除；先看面板状态再决定是否重试，不要盲目加频率
  echo "$TS FAIL rc=$rc $out" >> "$LOG"
fi
exit $rc
