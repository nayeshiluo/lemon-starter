#!/usr/bin/env python3
"""从 InstaBox 沙箱分块导出大文件，绕开 API 的大小截断。

背景（2026-11-24 实测）：
  POST /v1/machines/{id}/exec  的 stdout      截断在 1 MiB (1048576)
  GET  /v1/machines/{id}/files 的 content    截断在 256 KiB (262144)
两种截断都**不报错**，只会静默给你不完整的数据，校验和必然对不上。

本脚本做三件事：
  1. 在机器上把目标文件 base64 后 split 成 <=200000 字节的小块
  2. 逐块 GET /v1/machines/{id}/files?path=... 拉回来，404 作为终止条件
  3. 拼回原始文件，写出 sha256 供两端比对

用法（在有 API key 的机器上跑，key 走文件）:
    python3 ib-export-chunked.py <keyfile> <machine_id> <remote_path> <local_out>

例:
    python3 ib-export-chunked.py /etc/instabox-lab/api.key \\
        m_xxx /data/workspace/.dsh-config.tar.gz /tmp/out.tar.gz

注意：machine_id 从 GET /v1/machines 动态取时更安全，硬编码的 id 可能已过期。
"""

import base64
import hashlib
import json
import sys
import urllib.error
import urllib.parse
import urllib.request
import uuid

API = "https://api.instabox.sh"
CHUNK = 200_000          # 小于 files API 的 256KiB 上限，留足余量


def call(key, path, method="GET", body=None):
    headers = {"X-API-Key": key, "Content-Type": "application/json"}
    if method != "GET":
        headers["Idempotency-Key"] = str(uuid.uuid4())
    req = urllib.request.Request(
        API + path,
        data=json.dumps(body).encode() if body else None,
        headers=headers,
        method=method,
    )
    try:
        return urllib.request.urlopen(req, timeout=180).read().decode()
    except urllib.error.HTTPError as e:
        return "HTTP %s %s" % (e.code, e.read().decode()[:200])


def main():
    if len(sys.argv) != 5:
        print(__doc__)
        return 2
    keyfile, mid, remote, out = sys.argv[1:5]
    key = open(keyfile).read().strip()

    # 1) 机器上打包 + base64 + 切块
    workdir = "/data/workspace/_ib_export_tmp"
    cmd = (
        "mkdir -p {wd} && cd {wd} && "
        "tar czf payload.tgz -C $(dirname {rem}) $(basename {rem}) && "
        "base64 -w0 payload.tgz > payload.b64 && "
        "rm -f part-* && split -b {chunk} -d -a 3 payload.b64 part- && "
        "sha256sum payload.tgz && wc -c payload.b64 && ls part-* | wc -l"
    ).format(wd=workdir, rem=remote, chunk=CHUNK)
    raw = call(key, "/v1/machines/%s/exec" % mid, "POST", {"cmd": cmd})
    try:
        stdout = json.loads(raw).get("stdout", "")
    except Exception:
        stdout = raw
    print("--- remote side ---")
    print(stdout)
    if "payload.b64" not in stdout:
        print("remote packaging failed; aborting")
        return 1

    # 2) 逐块拉取，404 = 拉完
    chunks = []
    i = 0
    while i < 500:
        path = "%s/part-%03d" % (workdir, i)
        raw = call(key, "/v1/machines/%s/files?path=%s"
                   % (mid, urllib.parse.quote(path)))
        try:
            d = json.loads(raw)
        except Exception:
            print("chunk %d: non-json response, stopping: %s" % (i, raw[:120]))
            break
        content = d.get("content")
        if not content:
            print("chunk %d: empty/404 -> done" % i)
            break
        chunks.append(content)
        i += 1
    print("fetched chunks:", len(chunks))

    # 3) 拼回 + 校验
    blob = base64.b64decode("".join(chunks))
    digest = hashlib.sha256(blob).hexdigest()
    with open(out, "wb") as f:
        f.write(blob)
    print("written:", out, len(blob), "bytes")
    print("sha256(local) :", digest)
    print("sha256(remote): 见上面 remote side 输出，两行必须一致")
    return 0


if __name__ == "__main__":
    sys.exit(main())
