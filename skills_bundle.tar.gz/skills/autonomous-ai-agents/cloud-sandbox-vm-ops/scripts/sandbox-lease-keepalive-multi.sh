#!/bin/bash
# InstaBox Activity Lease 保活守护（多账号版）
#
# 与 sandbox-lease-keepalive.sh 的差别：所有可变项走环境变量，
# 因此同一台 VPS 上可以用同一个脚本文件跑多个 systemd 实例，
# 每个实例对应一个 InstaBox 账号（不同 API key / 不同 leaseID / 不同日志）。
#
# 为什么需要多实例：GET /v1/machines 只返回当前 key 所属 org 的机器，
# 一个 key 看不到另一个账号的机器。多账号 = 多实例，不是改脚本。
#
# 部署（每账号一份）：
#   install -m 600 /tmp/<key> /etc/instabox-<tag>/api.key
#   systemd unit 里用 Environment= 指定 KEYFILE/LOG/LEASE
#
# 字段名是 ttlSeconds（30-3600）；同一 leaseID 重复 PUT = 续期。
# 续期间隔必须显著小于 ttl（ttl=1800 + interval=600 合适）。
set -uo pipefail

API="https://api.instabox.sh"
KEYFILE="${KEYFILE:-/etc/instabox/api.key}"
LOG="${LOG:-/var/log/instabox-lease.log}"
LEASE="${LEASE:-lemon-keepalive}"
TTL="${TTL:-1800}"
INTERVAL="${INTERVAL:-600}"

[ -r "$KEYFILE" ] || { echo "$(date '+%F %T%z') FATAL 读不到 $KEYFILE" >> "$LOG"; exit 1; }
KEY=$(tr -d '\r\n' < "$KEYFILE")

log() { echo "$(date '+%F %T%z') $*" >> "$LOG"; }

log "start pid=$$ ttl=${TTL}s interval=${INTERVAL}s lease=${LEASE} keyfile=${KEYFILE}"

while true; do
    body=$(curl -fsS --max-time 20 -H "X-API-Key: $KEY" "$API/v1/machines" 2>&1)
    if [ $? -ne 0 ]; then
        log "LIST_FAIL $body"
        sleep 120
        continue
    fi

    # 用 jq 解析，别用 grep 正则抓 ID（格式一变就静默失效）
    ids=$(printf '%s' "$body" | jq -r '.machines[] | "\(.id)|\(.state)|\(.maxRunMinutes)|\(.runStartedAt // "-")"' 2>/dev/null)

    if [ -z "$ids" ]; then
        log "PARSE_FAIL $(printf '%s' "$body" | head -c 200)"
        sleep 120
        continue
    fi

    while IFS='|' read -r id state maxrun started; do
        [ -z "$id" ] && continue
        resp=$(curl -sS --max-time 20 -w '\n%{http_code}' -X PUT \
            "$API/v1/machines/$id/activity-leases/$LEASE" \
            -H "X-API-Key: $KEY" \
            -H "Content-Type: application/json" \
            -d "{\"ttlSeconds\":$TTL}" 2>&1)
        code=$(printf '%s' "$resp" | tail -1)
        payload=$(printf '%s' "$resp" | head -n -1 | tr -d '\n')
        if [ "$code" = "200" ]; then
            exp=$(printf '%s' "$payload" | jq -r '.expiresAt // "?"' 2>/dev/null)
            log "OK $id state=$state maxrun=${maxrun}m expires=$exp"
        else
            # http=409 machine_cooldown 是 8h 上限触发的冷却，属预期，别调频率
            log "FAIL $id state=$state maxrun=${maxrun}m http=$code $payload"
        fi
    done <<< "$ids"

    if [ "$(wc -l < "$LOG")" -gt 3000 ]; then
        tail -1000 "$LOG" > "$LOG.tmp" && mv "$LOG.tmp" "$LOG"
    fi

    sleep "$INTERVAL"
done
