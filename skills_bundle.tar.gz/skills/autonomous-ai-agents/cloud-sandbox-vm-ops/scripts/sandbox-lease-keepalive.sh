#!/bin/bash
# 云沙箱 Activity Lease 保活守护（InstaBox 实测可用，2026-10-23）
#
# 官方接口: PUT /v1/machines/{id}/activity-leases/{leaseID}
#   - 请求体字段是 ttlSeconds（30-3600，默认 300），不是 durationSeconds
#   - 同 leaseID 重复 PUT = 续期；到期后机器才重新开始算闲置
#   - 会主动唤醒已被闲置暂停的机器；但管不住 maxRunMinutes（免费机 480 分钟）
#
# 用法: sudo install -m 755 sandbox-lease-keepalive.sh /usr/local/bin/
#       /etc/instabox/api.key 放 API key（600 root:root）
#       配 systemd service（Type=simple, Restart=always）常驻
set -uo pipefail

API="${SANDBOX_API:-https://api.instabox.sh}"
KEYFILE="${SANDBOX_KEYFILE:-/etc/instabox/api.key}"
LOG="${SANDBOX_LOG:-/var/log/instabox-lease.log}"
LEASE="${SANDBOX_LEASE_ID:-hermes-keepalive}"
TTL="${SANDBOX_LEASE_TTL:-1800}"     # 30 分钟，API 上限 3600
INTERVAL="${SANDBOX_LEASE_INTERVAL:-600}"  # 必须显著小于 TTL

log() { echo "$(date '+%F %T%z') $*" >> "$LOG"; }

[ -r "$KEYFILE" ] || { log "FATAL 读不到 $KEYFILE"; exit 1; }
KEY=$(tr -d '\r\n' < "$KEYFILE")

log "start pid=$$ ttl=${TTL}s interval=${INTERVAL}s"

while true; do
    body=$(curl -fsS --max-time 20 -H "X-API-Key: $KEY" "$API/v1/machines" 2>&1)
    if [ $? -ne 0 ]; then
        log "LIST_FAIL $body"
        sleep 120
        continue
    fi

    # jq 正规解析，别用 grep 正则抓 ID（长度一变就静默失效）
    rows=$(printf '%s' "$body" | jq -r '.machines[] | "\(.id)|\(.state)|\(.maxRunMinutes)|\(.runStartedAt // "-")"' 2>/dev/null)
    if [ -z "$rows" ]; then
        log "PARSE_FAIL $(printf '%s' "$body" | head -c 200)"
        sleep 120
        continue
    fi

    while IFS='|' read -r id state maxrun started; do
        [ -z "$id" ] && continue
        resp=$(curl -sS --max-time 20 -w '\n%{http_code}' -X PUT \
            "$API/v1/machines/$id/activity-leases/$LEASE" \
            -H "X-API-Key: $KEY" \
            -H "Content-Type: application/json" \
            -d "{\"ttlSeconds\":$TTL}" 2>&1)
        code=$(printf '%s' "$resp" | tail -1)
        payload=$(printf '%s' "$resp" | head -n -1 | tr -d '\n')
        if [ "$code" = "200" ]; then
            exp=$(printf '%s' "$payload" | jq -r '.expiresAt // "?"' 2>/dev/null)
            log "OK $id state=$state maxrun=${maxrun}m expires=$exp"
        else
            # 409 machine_cooldown = 撞上 maxRunMinutes 冷却，属预期，不是故障
            log "FAIL $id state=$state maxrun=${maxrun}m http=$code $payload"
        fi
    done <<< "$rows"

    # 日志防膨胀
    if [ "$(wc -l < "$LOG")" -gt 3000 ]; then
        tail -1000 "$LOG" > "$LOG.tmp" && mv "$LOG.tmp" "$LOG"
    fi

    sleep "$INTERVAL"
done
