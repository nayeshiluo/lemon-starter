# 冗余镜像目录的退役核查（2026-10-24 实战）

配套 SKILL.md §三「删除前六项证据核查」。§三那六项是给**备份/快照目录**用的
（引用、worktree、lsof、reflog、工作区、双份留存）。当待删对象是**某个仓库里的镜像目录**
（如 `hermes-ops-private/projects/<project>/`）时，六项里有一半不适用，需要另一套证据。

## 触发形态

用户说「这个看着没用了 / 是不是早废了 / 你细查一下」。典型特征：

- 目录在私有仓库里，内容像是某个公开仓库的副本；
- 最后提交停在几周前，文件 mtime 却很新（`git checkout`/rebase 刷新的，**不是**被写过）；
- 仓库里还有个「看起来是权威副本」的 `tools/*.py`、`manifest.json`。

**注意 mtime 陷阱**：`find -printf '%TY-%Tm-%Td'` 显示今天，但 `git log -1 -- <dir>`
停在 10-08、`git status` 干净 → 内容就是 10-08 的，mtime 只是 git 操作刷的。
判新旧**只认 `git log`**，不认 mtime。

## 八项证据（全部通过才建议删）

| # | 检查 | 命令要点 | 通过标准 |
|---|---|---|---|
| 1 | cron 任务引用 | 解析 `~/.hermes/cron/jobs.json`，对整个 job JSON 做子串匹配 | 命中项的实际 `script` 不指向该目录 |
| 2 | 脚本引用 | `grep -rn "<repo>/projects/<dir>" ~/bin ~/.hermes/scripts ~/hermes-jobs` | 无命中 |
| 3 | systemd 引用 | `grep -rn <dir> /etc/systemd ~/.config/systemd/user` | 无命中 |
| 4 | 全局文本引用 | 全 `~/` 扫 `.py/.sh/.json/.service/.md`（排除 `backups/`） | 只剩自己写的技能文档 |
| 5 | 仓库 CI | 仓库根 `.github/workflows/` 是否存在；子目录里的 workflow 只属于公开套件 | 私库无 CI，`tests/` 不会跑 |
| 6 | 仓库政策文档 | `grep -n <dir> README.md SYNC_POLICY.md` | 无「必须保留」约定 |
| 7 | **文件集合差集** | 见下 | 镜像独有内容只有自述文件 |
| 8 | 可恢复性 | `git log -- <dir>` 提交数 + `git ls-remote --heads origin \| grep backup` | 提交全在历史里，且有 backup 分支 |

### 第 7 项是核心，且必须用完整差集

```python
def files(root):
    out = set()
    for p in root.rglob('*'):
        if p.is_symlink() or not p.is_file(): continue
        rel = p.relative_to(root)
        if any(x in {'.git','__pycache__'} for x in rel.parts): continue
        out.add(rel.as_posix())
    return out

m, pb = files(mirror), files(public_head)
print("镜像独有:", sorted(m - pb))
print("上游独有:", sorted(pb - m))
```

**绝不能拿 `find ... | head -20` 或 `ls | head` 的输出当差集。** 本次实测踩到：
`find projects/lemon-starter -type f | head -20` 只列到 `tools/public_skills_guard.py`
就截断了，据此断言「公开仓库 tools/ 只有 guard 一个文件」——实际公开仓库 `tools/` 有 4 个、
`tests/` 有 5 个。差集结论必须来自集合运算，不是肉眼看列表。

同理，比较单个文件用 `cmp -s` 或 `diff | grep -c '^[<>]'`，不要靠「看起来差不多」。

### 第 8 项：可恢复性看两处

```bash
git log --format='%h %ci %s' -- projects/<dir>/        # 历史提交还在，就能 checkout 回来
git branch -a | grep -i backup                          # 本地
git ls-remote --heads origin | grep -i <keyword>        # 远端（本次有 backup/<project>-<date>）
```

## 交付形态：报结论 + 等授权，不要顺手删

用户说「细查一下」= 要证据，**不是**删除授权。正确收尾：

1. 表格列出 8 项结果，明确写「无活引用 / 无 CI / 无保留约定 / 差集只剩 X」；
2. 给出体积（`du -sh`）与可恢复路径（提交 sha + backup 分支名）；
3. 明确一句「要删我需要你点头」；
4. 若同时发现别的洞，一并报（见下）。

## 同类发现：镜像没用了，但**真身可能根本不在 git 里**

本次顺带查出更严重的问题：被镜像的**源目录**（发布链路真身 `bin/public-skills-export/`）
`git rev-parse --show-toplevel` → **不在任何仓库内**。也就是说「镜像」是旧副本，
「真身」只有一份工作区文件 + 加密离线备份。

判据与话术：

```bash
cd <真身目录> && git rev-parse --show-toplevel 2>/dev/null || echo "不在任何 git 仓库内"
# 再确认离线备份有没有覆盖它：看 backup_hermes.sh 的 SUPPORT_ITEMS
grep -n "SUPPORT_ITEMS" -A6 ~/.hermes/scripts/backup_hermes.sh
```

本环境 `SUPPORT_ITEMS` 含 `bin`，所以 `recovery_support.tar.gz` 覆盖了它 → **不是零备份**，
但「必须持恢复私钥才能拿到」和「GitHub 上能直接看」是两回事，报告时要分清这两档
（对应 SKILL.md §六 的三档结论）。

**结论：退役旧镜像之前，先确认它镜像的那个源自己有没有被备份。** 否则删掉镜像
反而让唯一「进了 git 的那份」消失。
