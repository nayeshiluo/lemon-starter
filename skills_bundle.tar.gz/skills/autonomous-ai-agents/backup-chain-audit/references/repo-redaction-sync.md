# 把线上运维脚本脱敏同步进私有仓库（2026-10-24 落地实测）

配套 SKILL.md「覆盖度核查」与 Pitfalls。场景：线上脚本能跑，但要镜像进 `hermes-ops-private`
这类受 `SYNC_POLICY` 约束的仓库，而脚本里含有仓库禁止存储的标识（Telegram chat id 等）。

## 先发现，别假设脚本干净

同步前对线上脚本做一次标识扫描，不要假定它只含逻辑：

```bash
grep -nE 'CHAT_ID|OWNER|ADMIN|TOKEN|KEY' ~/.hermes/scripts/backup_hermes.sh
```

本次实测第 10 行就藏着 owner 的 Telegram chat id 作为默认值：

```bash
OFFSITE_CHAT_ID="${OFFSITE_CHAT_ID:-<YOUR_TELEGRAM_ID>}"
```

仓库 `README` 明写 `no ... Telegram IDs`，所以直接 `cp` 会违规。

## 为什么选"脱敏复制"而不是改线上

三条路都试过权衡，只有第三条成立：

1. 改线上脚本去掉默认值 → 改变生产行为，得单独验证；
2. 把值挪进 `~/.hermes/.env` → 改 `.env` 是敏感文件写入，要额外授权，本次就被卡住过；
3. **仓库副本脱敏 + 线上原样不动** → 零生产风险，推荐。

配一个 `sync-from-live.sh` 做"读取线上 → 脱敏 → 写入仓库"，以后同步都走它，不要手工 `cp`，
否则下一次同步又把明文带回来。

## sed 脱敏的静默陷阱（本次真实踩到）

第一版用 sed：

```bash
sed -E 's/(OFFSITE_CHAT_ID:-)([0-9]{5,15})(})/\1__OFFSITE_CHAT_ID__\2/'
```

写成 `\2`（数字）而不是 `\3`（右花括号），结果把 `}` 吃掉了：

```
输出：OFFSITE_CHAT_ID="${OFFSITE_CHAT_ID:-__OFFSITE_CHAT_ID__"
                                                     ^^^ 缺 }
```

**这种损坏 sed 自己不会报错，`grep` 也看着"像是替换成功了"。** 只有 `bash -n` 能抓到。

用 Python 重写更稳：

```python
import re, sys
src = open(sys.argv[1], encoding='utf-8').read()
src = re.sub(r'(OFFSITE_CHAT_ID(?:="\$\{OFFSITE_CHAT_ID:-|\$\{OFFSITE_CHAT_ID:-|="))(\d{5,15})',
             r'\1__OFFSITE_CHAT_ID__', src)
sys.stdout.write(src)
```

## 脱敏后必须跑的断言（缺一不可）

1. 无残留数字 chat id：`grep -qE 'OFFSITE_CHAT_ID[^_]*[0-9]{6,}'` 必须为空；
2. 无凭据形态：`bot[0-9]{8,}:[A-Za-z0-9_-]{30,}`、`ghp_[A-Za-z0-9]{20,}`；
3. `bash -n <脱敏脚本>` 通过（**抓 sed 吃字符**）；
4. `python3 -m py_compile` 通过（若同步 .py）；
5. **幂等**：`sync-from-live.sh --check` 二次运行应为 `OK`，不是 `DIFF`；
6. **差异收敛**：脱敏版与线上版 `diff` 应当**只有被脱敏那一行**。多出任何差异都说明脱敏逻辑动了别的字节。

## 扫暂存内容找泄露：要区分增删行

`git diff --cached` 里 grep 到疑似密钥时，先看行首符号：

- `-OFFSITE_CHAT_ID="...<YOUR_TELEGRAM_ID>}"` → **删除行 = 脱敏成功**，正是想要的结果；
- `+OFFSITE_CHAT_ID="...<YOUR_TELEGRAM_ID>}"` → 新增行 = 真泄露，必须停下。

本次唯一命中就是删除行。只看"有没有命中"会误判成失败。

注意：把大正则直接写在 `git diff --cached | grep -inE '...'` 一行里，容易触发
`BLOCKED (hardline): command parser limit`。改成两步：

```bash
git diff --cached > /tmp/staged.diff     # 先落盘
```

然后用 `search_files(path='/tmp/staged.diff', pattern='...')` 查，不要重试内联长正则。

## 历史里已有的标识：只报不改

脱敏只解决**增量**。已经进过 git 历史的照样能查出来：

```bash
git log --all --oneline -S "<敏感值>" -- .
```

本次实测命中 6 个历史提交（`1e0494e` init 到 `7651a15`）。处置原则：

- **如实报告**"现在起脱敏了，但历史里仍有 N 个提交能查到"；
- 不擅自 `filter-repo` / `filter-branch` + force push —— 会破坏所有现有克隆；
- 把选择权交给用户，写清代价（force push 影响面）再等指令。

## 同步前先看清工作区里有什么

私有镜像仓库常混着别的项目的未提交改动。提交时必须**逐文件显式 `git add`** 自己改的那几个，
不要 `git add -A`：本次 `git status` 里有 15+ 个 `lemon-2f` / `lemon-ops-bot` 的历史改动，
都不是本次产物，一并提交会把无关变更混进同一个 commit。

推送前还要先 `git fetch` 再比对：本次本地落后远端 10 个提交，直接 push 被
`non-fast-forward` 拒绝；`git rebase origin/main`（带 `rebase.autoStash=true` 处理脏工作区）
后重推才成功，rebase 后要复核脱敏仍然生效。

## 延伸：多个字面值、且需要防漂移时

本文件处理的是「一个 chat id 藏在 bash 默认值里」这种单点脱敏。若待镜像的文件**整份都是敏感值清单**
（典型是脱敏脚本自己的替换表），或值的种类多到无法逐条 `sed`，改用**按模式脱敏 + 自动重生成**：
生成器只含模式、不含真值，因此生成器本身可以正常进仓库。五条模式、占位符必须保持 `re.compile()`
合法、以及把 `--check` 挂进已有只读巡检防「线上改了仓库没跟上」，见
`publish-pipeline-mirroring.md` §3.1–§3.3。

另外，脱敏扫描报出的命中要**逐条定性**：保留地址（`127.0.0.1` / `8.8.8.8` / `169.254.169.254` / 私有网段）、
`example.com` 占位邮箱、测试 fixture 的假密钥、正则定义本身都不算泄露。只报「有命中」等于噪音，
会让用户白紧张、也让真正要看的那条被埋掉。
