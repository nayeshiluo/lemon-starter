# 大型加密归档：解密故障定位与认证恢复门槛

## 适用范围与证据级别

用于备份/迁移包“小包能解，大包 CMS 解密在 ASN.1/BUF_MEM 失败”的调查。这里保存可复用的源码证据和已验证的合成流方法，不保存生产主机、私有路径、归档摘要、密钥或数据。它不是对任何当前目标机的状态证明，也不是通用 CMS 生产恢复器。

先明确授权矩阵：可读哪些本地/远端对象、可写哪些审计产物、能否创建合成文件、是否允许读取目标既有密钥。只读调查不自动授权远端连接、源端重打包、凭据重传、安装依赖或恢复生产；只有报告可写时，测试逻辑可嵌入报告并读入内存执行，合成数据走匿名管道，不额外落盘 key/cert/归档。不要为满足“复现”而突破授权范围。

报告分列：主任务提供的事实、独立核查的版本源码、当前本地库版本、真实合成结果、未执行的目标侧门槛。前述任一层不能冒充另一层。

## 1. 先确定失败阶段，不凭错误名称下结论

收集精确 CLI、返回码、完整错误栈及文件行号、包大小与双方整包 SHA-256、之前成功包的量级、发行版/实际二进制版本。无需打印密钥正文或业务凭据。

按阶段追踪：输入编码/ASN.1 对象读入 → CMS 字段解析 → RSA 内容密钥解封 → GCM tag 认证 → tar/压缩完整性 → 数据库/业务恢复。若错误发生在第一层，不能据此宣称密钥错误、GCM 失败或数据库损坏。

对于 `malloc failure`，查看精确版本源码的报错分支：固定扩容上限、整数边界、溢出保护、真实 allocator 失败可能共用类似错误文案。无 kernel OOM 仅是旁证，既不证明没有内存压力，也不把长度保护变成物理内存不足。

## 2. 已核查的 OpenSSL 3.0.22 证据链

以下只针对官方 `openssl-3.0.22` 标签；其他版本、发行版补丁和实际二进制必须重新核对。来源为 OpenSSL 官方仓库：

- `apps/cms.c:317–318`：ASN.1 输入调用 `d2i_CMS_bio`。
- `crypto/cms/cms_io.c:35–43`：转入 `ASN1_item_d2i_bio_ex`。
- `crypto/asn1/a_d2i_fp.c:60–75`：先 `asn1_d2i_read_bio` 将对象读入 `BUF_MEM`，后调用 `ASN1_item_d2i_ex`。内部分块 `BIO_read` 并不表示丢弃此前密文；累计缓冲仍随对象增长。
- 同文件 `275–276`：`BUF_MEM_grow_clean(b, len + chunk)` 失败转为 ASN.1 malloc failure；`309–310` 另有 `off > INT_MAX` 拒绝路径。
- `crypto/buffer/buffer.c:19`：`LIMIT_BEFORE_EXPANSION = 0x5ffffffc`，即 1,610,612,732 bytes；`127–129` 在需要扩容且请求超限时主动报告 malloc failure。实际 realloc 位于 `135`，真正分配失败在 `136–137`。因此该版本 `buffer.c:128` 与 `a_d2i_fp.c:276` 的组合能将故障定位到固定保护，而非仅猜测 RAM。
- 该扩容公式 `(len+3)/3*4` 的最高容量为 2,147,483,644 bytes，后续还有 INT_MAX。不要说“所有 >1.5GiB 的对象均在同一字节失败”：既有容量足够时会先复用，实际触发点依扩容步幅而异。超过这些容量/整数边界的整对象解码，不靠加 RAM/swap 根治。

源码链接：

- https://raw.githubusercontent.com/openssl/openssl/openssl-3.0.22/apps/cms.c
- https://raw.githubusercontent.com/openssl/openssl/openssl-3.0.22/crypto/cms/cms_io.c
- https://raw.githubusercontent.com/openssl/openssl/openssl-3.0.22/crypto/asn1/a_d2i_fp.c
- https://raw.githubusercontent.com/openssl/openssl/openssl-3.0.22/crypto/buffer/buffer.c

同版本 `openssl-cms` 文档明确 `-stream/-indef` 为 **encoding operations**。不能将发送端流式编码误当接收端流式解码；改 stdin/FIFO、输出 `/dev/null`、换一个仍调用 `d2i_CMS_bio` 的绑定也不消除整对象读入。`openssl enc` 文档明确不支持 GCM/CCM；不要发明 `enc -d -aes-256-gcm` 补救命令。

- https://raw.githubusercontent.com/openssl/openssl/openssl-3.0.22/doc/man1/openssl-cms.pod.in （279–286）
- https://raw.githubusercontent.com/openssl/openssl/openssl-3.0.22/doc/man1/openssl-enc.pod.in （291–299）

## 3. 最小替代路径：目标侧严格有界流式恢复

先优先核查成熟工具是否真实支持所需格式、规模和最终认证；若没有已证实的 CLI 路径，才考虑限缩格式的离线解析器。只传非秘密脚本，在目标使用其已有传输私钥，不把生产包/私钥/明文回传，不要求源端重发凭据。直接切分已有 CMS 密文不等于生成多个可独立解密的 CMS 对象。

### 必须解析、拒绝猜测的字段

- ContentInfo/AuthEnvelopedData 类型与版本、收件人类型/个数、keyEncryptionAlgorithm OID/参数。
- 实际收件人若为 RSA `rsaEncryption`，可用 `private_key.decrypt(encrypted_key, padding.PKCS1v15())`；核查 AES-256 的 CEK 恰为32 bytes。OpenSSL 默认 RSA 填充是线索，不是跳过实际 OID 校验的理由。其他算法/OAEP参数必须另行实现与测试，未知就拒绝。
- contentType、AES-GCM算法OID、nonce、GCMParameters 的 ICV长度和尾部mac。RFC 5084 的 ICV长度省略时默认 **12 bytes，不是16**；允许值12–16。nonce长度等可主动收窄为本次已测试的配置，超限即停，不擅自兼容。
- `-stream -outform DER` 不保证实际是严格DER。须处理BER definite/indefinite容器、EOC，以及 encryptedContent context-tag 0 的 primitive/constructed OCTET STRING；不得固定偏移或把外壳/EOC当密文。
- `authAttrs` 若存在必须作为正确DER SET OF编码的AAD参与认证；不支持就拒绝，不能跳过后照用空AAD。`unauthAttrs`、originatorInfo、额外收件人、未知字段也需明确支持或拒绝；不静默吞掉。

### 资源与密码学要求

- 所有读/写和 `decryptor.update` 有固定chunk上限（合成实验验证过1MiB上限），元数据/密钥/嵌套深度/总大小也设主动上限。不能先 `read()` 整包，也不能用一次性 `AESGCM.decrypt` 再称流式。
- 使用 `Cipher(algorithms.AES(cek), modes.GCM(nonce, min_tag_length=icvlen)).decryptor()`，按需传AAD、逐chunk `update`，最后 **`finalize_with_tag(tag)` 必须成功**；检查tag长度与参数一致、结构关闭、EOF无尾随垃圾。
- RSA PKCS1v15仅用于已有离线封装兼容；不向外暴露padding错误差异或解密API。cryptography文档提醒 OpenSSL <=3.2 的该解密实现非恒定时间。不要将临时恢复器变成远程oracle。

### 认证前不发布明文

原语输出在finalization前均不可信。实际文件入口必须在可信祖先路径下的私有0700隔离目录，以 `O_EXCL|O_NOFOLLOW` 创建0600随机 `.part`，不输出明文到stdout，不与tar构成流水线。

只有结构/EOF、GCM tag、预期完整密文SHA和大小、源文件稳定性全部通过后，才flush/fsync并同目录原子no-clobber发布；例如硬链接到不存在的final后删除part，而非覆盖既有结果。必须测试文件系统是否支持所选发布方法。认证失败清理自己创建的part；只有O_EXCL成功后才能登记清理所有权，避免误删撞名文件。崩溃残留part永远不算成功；unlink不保证SSD/快照层安全擦除。发布后fsync失败可能留下已认证final，非零退出不能自动等同“绝无文件”。

## 4. 无生产材料的真实大流验证方法

已验证的实验方法：用新生成的合成RSA key/cert（内存），证书通过匿名pipe及 `/proc/self/fd/N` 提供给Linux OpenSSL；producer将确定性非生产字节写入 `openssl cms -encrypt -binary -aes-256-gcm -stream -outform DER` 的stdin；stdout直接给BER解析器；解密结果只进入SHA/计数sink。写pipe处理short write，producer并发防死锁；无须保存几GB样本文件。

验证必须实际流过超过2^31 bytes，不能只伪造长ASN.1头/sparse文件；比较producer和解密sink的完整明文SHA及字节数。记录CLI版本、Python cryptography版本与其实际后端版本，三者可能不同；RSS说明是否只计Python进程，不冒充系统整体内存。

已观察到的成功边界：一个真实OpenSSL流封装处理2,148,532,241明文字节、2,150,630,844 CMS字节，完整SHA相等；真实BER分段读取最大4096 bytes，另以大primitive OCTET STRING确认1MiB chunk上限。该观察证明本地流式核心工作，不证明任意目标版本、生产包字段或文件发布包装已经验收。

反向大流测试：只保留有限长度尾缓存，在匹配**合成fixture**的mac处翻转tag，再给同一解析器；必须全流处理后 `InvalidTag`，无成功metadata。固定尾偏移仅限已断言结构的测试fixture，生产解析必须读取TLV。小流还要测试错误密钥、密文翻转、截断、尾随垃圾、未知算法、authAttrs。测试ICV省略默认12/显式16、definite primitive/nested constructed、短读与容器越界。

## 5. 生产放行门槛与未验证项

按顺序核：

1. 在最终选定的目标解释器/依赖下重跑合成正/反向、大于2GiB及资源上限测试；依赖缺失不自动授权系统升级或安装。
2. 独立跑隔离文件包装测试：valid rc0且final为0600；坏tag/坏SHA/异常长度非0、无final、无未清理part；已有final不覆盖；权限/链接异常被拒绝。**历史调查仅验证了内存/管道核心，未执行文件发布包装测试，不能引用为生产已验证。**
3. 有授权时用目标本地已成功的小包作OpenSSL/候选恢复器明文SHA差分；只比较本地摘要，不传出数据。
4. 主包必须通过实际字段白名单、全流GCM认证、整包SHA/大小、EOF/稳定性，才允许得到隔离final；成功后再审核tar成员、路径穿越、链接、设备节点和展开预算。
5. 新staging目录恢复，不直接覆盖生产。业务库只能使用已确认的一致快照；在线tar的rc=1、热库/WAL不是一致恢复集。每库backup API一致也不等于跨库同一时点一致。
6. 报告分别标记“源码定位”“合成核心通过”“文件发布包装通过”“生产包认证通过”“业务恢复通过”；任一未执行就原样注明，不用猜测或演示结果补齐。

## 规范与实现来源

- RFC 5083：AuthEnvelopedData结构、authAttrs/AAD；属性缺省时AAD输入为零bits。https://www.rfc-editor.org/rfc/rfc5083.txt
- RFC 5084：GCMParameters nonce与默认ICV长度。https://www.rfc-editor.org/rfc/rfc5084.txt
- OpenSSL 3.0.22 `crypto/cms/cms_asn1.c`：NDEF结构与encryptedContent模板。https://raw.githubusercontent.com/openssl/openssl/openssl-3.0.22/crypto/cms/cms_asn1.c
- OpenSSL 3.0.22 `crypto/cms/cms_env.c:1179–1229`：AAD编码和mac/tag传递。https://raw.githubusercontent.com/openssl/openssl/openssl-3.0.22/crypto/cms/cms_env.c
- OpenSSL 3.0.22 `crypto/cms/cms_rsa.c:127–140`：默认RSA填充与算法编码。https://raw.githubusercontent.com/openssl/openssl/openssl-3.0.22/crypto/cms/cms_rsa.c
- cryptography 50.0.0对称加密文档：GCM完整性要等finalization；`finalize_with_tag`。https://raw.githubusercontent.com/pyca/cryptography/50.0.0/docs/hazmat/primitives/symmetric-encryption.rst
- cryptography 50.0.0 RSA文档：PKCS1v15后端时序警告。https://raw.githubusercontent.com/pyca/cryptography/50.0.0/docs/hazmat/primitives/asymmetric/rsa.rst
