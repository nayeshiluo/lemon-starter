# 公开技能快照发布链路：审计与三个已实证的静默 bug（2026-10-24）

配套 SKILL.md 第六节「覆盖度核查」与 GitHub 备份通道。`lemon-starter` 是用户认知里的
「两种 GitHub 备份」之一（另一个是 `hermes-ops-private`），但它**不是 push 式镜像**，
而是一条「脱敏候选 → 人工确认 → 发布」的快照链路。

## 链路结构（先认清再动手）

- 每日 cron `9b12946da1d3` → `bin/push_lemon_starter.sh` → `candidate_pipeline.py prepare --notify`
- `prepare()`：从 `~/.hermes/skills` 收集 → `legacy_sanitizer` → `public_skills_guard` 扫描
  → 生成 candidate（`~/.hermes/public-skills-candidates/<id>/`）→ **有变化才**发 TG「待确认」
- 用户 `/starter_publish <id>` → `publish()` → **在 `tempfile.TemporaryDirectory` 里
  `git clone --depth 1`**，改文件、commit、`push origin HEAD:main`、`ls-remote` 复核
- 无变化时 `prepare` 返回 `NO_CHANGE`，静默退出

**关键**：`/home/ubuntu/lemon-starter-repo` 这个本地克隆**不在发布链路上**。publish 用的是
临时目录的浅克隆。所以本地克隆陈旧/分叉**不影响发布**，可直接 reset 收敛。

## 三个已实证的 bug（全是「静默错」）

### 1. README 计数被硬编码替换，永久冻结

```python
# 错：README 一旦从 112 变成 113，这行就再也匹配不到，数字永久停住
text = text.replace('112 个技能', str(m['skills'])+' 个技能')
# 对：匹配任意数字
text = re.sub(r'\d+ 个技能', str(m['skills'])+' 个技能', text)
```

实证：README 声称 113，`output_hashes` 权威口径 122。旧逻辑跑一遍数字纹丝不动；
新逻辑 `['122']`，且幂等。

**审计方法**：取发布产物 `manifest['output_hashes']` 里 `endswith('/SKILL.md')` 的计数，
与 README 声称值对比。不等就是这类 bug——注意 `m['skills']` 的官方口径正是
`sum(n.endswith('/SKILL.md') for n in output)`，不要自己按目录数。

### 2. 扩展名白名单与源树漂移 → 定时任务静默失败

`public_skills_guard.py` 的 `TEXT_EXTENSIONS` / `TEXT_NAMES` 决定 `build()` 接受哪些文件。
技能里新加一个 `.timer`、或一个无扩展名脚本（如 `ib`），`prepare` 直接
`FAILED: unsupported_candidate_file`，cron 随后报「公开候选检查失败」。

**判断是不是新引入的**：比对失败文件 mtime 与 cron 上次 `SUCCESS` 时间。本次
`instabox_keepalive.timer` 06:11 创建、cron 05:31 成功 → 当晚必失败，无需等它真跑。

**定位到具体文件**：`GuardError` 只给类型名不给文件名。直接模拟 `build()` 的检查循环：

```python
files = cp.source_bytes(cp.SOURCE)          # key 带 'skills/' 前缀
bad = [n for n in files
       if pathlib.Path(n).suffix not in TEXT_EXTENSIONS|{'.pdf'}
       and pathlib.Path(n).name not in TEXT_NAMES]
```

注意 `source_bytes` 写入的是 `files['skills/'+rel]`，所以 key 有 `skills/` 前缀，
拼回绝对路径时别重复加。

**修法**：扩白名单（`.timer` 进 `TEXT_EXTENSIONS`，无扩展名脚本名进 `TEXT_NAMES`）。
扩之前先用 `PATTERNS` 扫一遍内容，确认不含敏感信息（本次 `ib` 从 `~/.ib/panel_token`
读 token，不硬编码，干净）。

### 3. 发布器不发布它自己用的校验器

`publish()` 的 `allowed` 原本只含 4 个文件（`skills_bundle.tar.gz` / manifest /
`SHA256SUMS` / `README.md`），**从不更新 `tools/public_skills_guard.py`**。
结果仓库里的 guard 是旧规则，校验新包时报 `FAILED: unsupported_archive_file`——
**用户手里的校验器和包自相矛盾**。

实证：同一候选包，新 guard `PASS`（732 文件），仓库旧 guard
`FAILED: unsupported_archive_file`。

**修法**：publish 时把实际校验用的 guard 一起写进仓库并纳入提交集合：

```python
(repo/'tools/public_skills_guard.py').write_bytes((HERE/'public_skills_guard.py').read_bytes())
allowed = {..., 'tools/public_skills_guard.py'}
```

## 通用教训（比这三个 bug 更值钱）

**「发布器」和「校验器」必须同版本发布。** 任何 `X publishes artifact + X ships a
validator for that artifact` 的设计，都要检查 validator 本身在不在发布集合里。
漏掉就会出现「包能发出去，但没人能验通过」的死局，且只有用户手跑才暴露。

**同一数字在多处声明时，查它是不是靠硬编码替换维护的。** `replace('112 ...')` 这类写法
在第一次变更后就永久失效，完全静默，而且看起来「一直在正常工作」。

## 分叉克隆能不能 reset：判据

不要看 commit 计数（`55 45` 只会误导）。看三件事：

1. **发布器是否用这个克隆**：读 `publish()`，若在 `tempfile` 里 clone → 本地克隆无关
2. **最终 tree 差多少**：`git diff --name-status HEAD origin/main`。只有少量 `M`、无 `A`/`D`
   = 内容同源，只是历史被重建（同一批日期、不同 sha）
3. **未提交改动是不是过期产物**：若 `git diff HEAD origin/main -- <file>` 与
   `git diff -- <file>` 的 blob hash 相同 → 本地未提交内容 == 远端内容，可直接丢弃

三条都过 → 备份再动手：

```bash
git bundle create <bk>/all-refs.before.bundle --all   # 用 git bundle verify 确认 complete
git diff > <bk>/uncommitted.patch
git reset --hard origin/main
sha256sum -c SHA256SUMS                                # 内容级验收
python3 tools/public_skills_guard.py <bundle> <manifest>   # guard PASS
```

## 别把「故意退役」当故障

`bin/push_lemon_github.sh` 是 256 字节的转发壳，直接
`echo "DISABLED: legacy lemon-backup Git sync was retired after the 2026-09-24 credential audit."`
并 `exit 64`。对应 cron job `enabled=false` 且 `last_status=error`（退役前的历史记录）。

看到「job 报错 + 被禁用」先读 script 本身：**打印 DISABLED/retired 并 exit 64 的是有意退役，
不是坏了**。报成故障会让用户以为备份断了。同理，`git push` 失败也可能是设计（退役脚本），
要先分清「链路故障」和「链路已主动下线」。

## 交付时要说清的

- 改了 `candidate_pipeline.py` 或 `public_skills_guard.py` 会改变 `code_hash()`，
  进而改变 candidate id。**改之前先查 `~/.hermes/public-skills-candidates/pending.json`
  是否存在**：存在且 code 变了会让待确认候选 `export_code_changed` 失效。
- `approval.json` 不含 code hash（只有 source/bundle/repo hashes），所以改代码不影响 baseline。
- 发布是**人工确认**动作，不要代为执行 `/starter_publish`；改完只跑
  `prepare`（不带 `--notify`）验证链路通，把 candidate id 交给用户。
