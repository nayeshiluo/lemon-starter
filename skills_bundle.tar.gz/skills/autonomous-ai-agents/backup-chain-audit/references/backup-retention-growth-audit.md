# 保留策略与体积增长审计 —— 实测基线与命令集

采样：UTC 2026-10-24 03:17–03:20（北京 11:17–11:20），系统时区 `Etc/UTC`。
这是一次快照，只能支撑该时刻的判断；再问必须重新采样。

## 一、两条备份链路的频率与真实执行状态

| 链路 | 触发处 | 计划 | 北京 | 内容 |
|---|---|---|---|---|
| Hermes 自身备份 | `~/.hermes/cron/jobs.json`（job `319e7f36295e`，`script: backup_hermes.sh`） | `0 3 * * *` | 11:00 | `.hermes` 数据（含 `plugins`）、4 个 db、model_proxy、recovery_support |
| unified 备份 | `crontab -l` → `hermes-jobs/phase5-backup-schedule.sh` → `job-runner.sh unified-backup-daily` | `30 3 * * *` | 11:30 | 项目源码 + configs |

**Hermes 的 cron 不在 crontab 里**，只看 `crontab -l` 会误判成"没有每日 Hermes 备份"。

查执行记录（只读）：

```bash
python3 - <<'EOF'
import json
d=json.load(open('.hermes/cron/jobs.json'))
jobs = d if isinstance(d,list) else d.get('jobs',d)
for j in (jobs if isinstance(jobs,list) else jobs.values()):
    if 'backup' in json.dumps(j,ensure_ascii=False).lower():
        print(j.get('id'), j.get('schedule'), 'enabled=', j.get('enabled'), j.get('script'))
EOF

python3 - <<'EOF'
import sqlite3
c=sqlite3.connect('.hermes/cron/executions.db')
for r in c.execute("SELECT status,started_at,finished_at,error FROM executions WHERE job_id='319e7f36295e' ORDER BY rowid DESC LIMIT 7"):
    print(r)
EOF
```

实测近 4 天全 `completed`，单次耗时 34–50s；成功摘要落在
`.hermes/cron/output/319e7f36295e/<date>.md`，含 `健康门禁通过: messages=…, sessions=…` 与各 db `ok`。

## 二、本地磁盘：稳定在 2 份，不线性增长

`bin/backup_safety.py`：

```python
def prune(root, current, pattern, now=None):
    # 删「匹配 pattern + 非当前 + mtime>86400」
```

- pattern：`hermes-[0-9]{8}_[0-9]{6}`（Hermes 链路）/ `[0-9]{8}_[0-9]{6}`（unified 链路）
- 效果：**常驻今日 + 昨日 2 份**，滚动覆盖，不会累积

实测：

```
backups/hermes-20261023_030052   209M
backups/hermes-20261024_030023   225M
合计 434M
```

## 三、本地加密包零残留（别误判）

`backup_hermes.sh` 上传后：

```
trap cleanup_upload EXIT   # 删 $ENC_FILE 与 $ENC_FILE.part-NNN
```

所以 `ls backups/*.cms` 为空是**正常现象**，不代表异地备份没做。
"异地有没有"只能看 `UPLOAD_MANIFEST.json` + 目标端（TG 私聊 / 洛杉矶主机）。

## 四、异地：只增不删，是唯一无限增长维度

- `bin/backup_upload.py` 只调用 `api('sendDocument', ...)`，**全脚本没有 `deleteMessage`**。
- 每天整包 `tar czf -` 后 `split -b 45M`，Bot API 单文件 50MB 上限决定了 45MiB 分片。
- 实测当天整包 `tar czf - . | wc -c` = **101.24 MiB** → 3 个分片/天。
- 推算：月 ≈3 GB，年 ≈36 GB。占 Telegram 云存储，不占本机磁盘。
- 后果不是"撑爆"，而是恢复时要按 `UPLOAD_MANIFEST.json` 在大量历史分片里找对应日期，且历史分片没有任何自动淘汰。

## 五、`~/backups` 里的孤儿目录（prune 管不到）

实测 `du -sh /home/ubuntu/backups` = **2.2G**，其中自动备份仅 434M，其余约 **1.77G** 是历史手工快照：

```
antigravity-holding-20260910 / antigravity-reauth-* / antigravity-watchdog-hardening-*
ai-footer-20260924-021312 / ai-footer-style-20260924-051156
aws-cold-git-20261008T1730Z
codex-remote-prep-20261021T111704Z
commands.callback64.20260918-075809.py / commands.grants-unify.*
backup_hermes.sh.pre-cms-20260924 / backup_hermes.sh.pre-cron-output-fix-20260922
```

这些名字都不匹配 `hermes-YYYYMMDD_HHMMSS`，**永远不会被 prune 删**。
磁盘 24G 用 18G、剩 5.5G（77%）时，先查这块；删除前按 SKILL.md 第三节六项证据核查，逐项摆证据再取授权。

## 六、增长源头

```
hermes-20261023_030052/state.db   184.63 MiB
hermes-20261024_030023/state.db   200.25 MiB   → 日增 15.6 MiB
```

同目录构成（今日）：

```
state.db                201M   ← 压缩率差，撑起整包 101MiB
data.tar.gz              20M
model_proxy.tar.gz      3.4M
recovery_support.tar.gz 314K
kanban.db               116K
verification_evidence.db 68K
response_store.db        20K
```

要降每日上传量，方向是 `state.db`：查 `~/.hermes/scripts/db_maintenance.py`（crontab `0 4,16 * * *`）是否做 VACUUM、老 session 能否归档；不要在没查前断言"数据库没优化"。

## 七、可选治理方向（需用户授权，勿擅自执行）

1. TG 分片加保留：保留最近 7 天 + 每月 1 号一份，其余 `deleteMessage` —— 收益最直接。
2. 清 `~/backups` 那 1.77G 孤儿快照 —— 必须逐个列清单 + 引用核查。
3. 压 `state.db` 增量 —— 先只读看 `db_maintenance.py` 实际做了什么。
