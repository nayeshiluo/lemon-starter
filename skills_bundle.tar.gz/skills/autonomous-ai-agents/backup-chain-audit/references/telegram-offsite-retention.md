# Telegram 异地备份保留策略：台账 + 精确删除（2026-10-24 落地实测）

配套 SKILL.md 第七节第 5 条。那里诊断出"异地只增不删是常态缺口"，本文是它的**修复方案**。

## 为什么旧链路清不了历史

旧 `~/bin/backup_upload.py` 上传完只写本地 `UPLOAD_MANIFEST.json`（bytes/sha256），
**不记录 Telegram 返回的 `message_id`**。而 Bot API 没有 `getChatHistory`，
bot 无法枚举自己发过的消息 → 已上传的历史分片**无法回溯删除**，只能人工在客户端删。

**结论：任何"以后能自动清理"的设计，前提是上传那一刻就把 message_id 落盘。**
没有台账的存量是硬伤，不要承诺能脚本清掉。

## Bot API 实测结论（别再踩）

| 事项 | 结论 |
|---|---|
| 删除方法 | `deleteMessages`（复数） |
| 参数 | `message_ids=[123,456]` —— **JSON 数组字符串**，不是 `message_id=` |
| 写错的后果 | curl 400；带 `--fail` 时响应体被吞，只看到 `curl: (22) ... 400`，极易误判为权限不足 |
| 单条方法 | `deleteMessage` 才用单数 `message_id`，两者不可混用 |
| 48h 限制 | **不适用**。该限制针对群组里删他人消息；bot 删自己发的消息无时间窗口（实测成功） |
| 批量 | 每次 ≤100 条，按 chat_id 分组 |

调试技巧：调 API 先**去掉 `--fail`** 再跑一次，才能看到 Telegram 返回的 `description`。
本次就是靠这一步从"400 无信息"定位到参数名错误的。

## 台账设计

- 位置 `~/.hermes/state/backup_ledger.jsonl`，0600，追加写。
  放 `state/` 是因为它在 `backup_hermes.sh` 的 `DATA_ITEMS` 白名单里，
  会随 `data.tar.gz` 进备份 —— 恢复后台账不丢，不会退化成"又清不了"。
- 每条字段：`stamp`（从 `hermes-20261024_030023` 去掉 `hermes-` 前缀）、`chat_id`、
  `uploaded_at`（UTC ISO）、`message_ids`（本批全部分片 + 清单相册的 id）、
  `parts`、`encrypted_bytes`、`sha256`、`deleted_at`。
- 写入时机：**全部** `sendDocument` / `sendMediaGroup` 成功之后一次性追加。
  `sendMediaGroup` 返回数组，要遍历取每个元素的 `message_id`。

## 保留规则（`~/bin/backup_retention.py`）

满足任一即保留，其余删：

1. 最近 `KEEP_DAYS`（默认 7）天内上传的批次；
2. **每月 1 号**锚点批次（`stamp` 第 7-8 位 == `01`）永久保留；
3. 最新一批永远保留。

设计要点：

- **只删台账里自己记录过的 id**，绝不按时间/序号/猜测删除，不碰任何未记录的会话。
- 删除成功后才写 `deleted_at` → 天然幂等，重跑得 `delete=0`。
- `uploaded_at` 解析失败的行归入**保留**，不猜年龄。
- **失败不抛**：只写日志，绝不让保留策略把备份本身标成 FAILED。

## 接线方式

`~/.hermes/scripts/backup_hermes.sh` 尾部、prune 之后：

```bash
python3 "$SCRIPT_DIR/backup_retention.py" --env-file "$H/.env" \
  >>/dev/null 2>>"$H/logs/backup_retention.err" || true
```

`$SCRIPT_DIR` = `$HOME/bin`（脚本真身在 `.hermes/scripts/`，但 helper 都放 `bin/`，
`bin/backup_hermes.sh` 只是 105 字节的转发壳）。
`|| true` + stderr 重定向是刻意的：备份脚本契约是"成功静默、失败报错"，
保留策略若走 stdout 会被 cron 误判成备份失败。

## 验收（真跑，不要纸面推演）

1. **逻辑单测**：造 21 天假台账 → `plan()` 应保留 7 天窗口 + 月锚点 + 最新批，
   删除其余；显式断言锚点与最新批都在 `keep` 里。
2. **端到端**：真发 3 条测试消息 → 台账 stamp 设为 20 天前 → 非 dry-run 跑
   → 日志出现 `deleteMessages ... ok=True` → 台账 `deleted_at` 有值
   → 再跑一次 `delete=0`（幂等）。
3. 测试消息必须自己清掉，不留痕在用户私聊里。

## 交付时必须说清的两条限制

- 台账上线**之前**的历史分片无法自动清理（无 id 记录 + 无 getChatHistory），
  只能人工删，或不管它（只占 Telegram 云端，不占本机）。
- 想立刻压低每日上传量只能压 `state.db` —— **不允许**，见 SKILL.md 第七节 state.db 条目。
