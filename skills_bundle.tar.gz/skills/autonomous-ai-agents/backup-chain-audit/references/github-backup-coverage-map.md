# GitHub 备份覆盖度速查（2026-10-24 实测）

核查场景："某个功能/代码在不在 GitHub 那两个备份里？" 先读这张表，避免逐仓库重新摸一遍。

## 通道与真实范围

| 通道 | 仓库 | 内容 | 是否含 Hermes 本体插件 |
|---|---|---|---|
| 私有镜像 | `nayeshiluo/hermes-ops-private` | `projects/`（约 559 个文件，含 lemon-* 各项目源码）、`manifests/`（inventory/repository-map/hermes-backup.txt）、`recovery/`、`scripts/check-dual-sync.sh`、`projects/hermes-local-patches/` | ❌ |
| 公开分发 | `nayeshiluo/lemon-starter` | `install.sh`、`skills_bundle.tar.gz`（约 646 条目，纯 skills）、`SHA256SUMS`、`tests/`、`tools/` | ❌ |
| 上游镜像 | `~/.hermes/hermes-agent`（远端 `cnb.cool/...` + `NousResearch/hermes-agent`） | Hermes 本体源码，含 `plugins/` | ✅ 但**不是**用户的 GitHub 备份 |
| 加密异地 | `~/.hermes/scripts/backup_hermes.sh` → `data.tar.gz`（openssl cms 加密上传） | 打包清单：`patches plans state sessions workspace platforms public-skills-approved profiles plugins configs pairing proxy inventory` | ✅ 插件改动在这里有备份 |

`hermes-local-patches` 目前只覆盖 3 个文件：`gateway/run.py`、`gateway/runtime_footer.py`、`tools/approval.py`（另附 `hermes-local.patch`、`scripts/antigravity-watchdog.py`、`skills/`、`tools/`）。任何 `plugins/` 下的改动默认**不在** GitHub 备份里。

## 案例：TG 私聊快捷键盘

- 真实位置：`.hermes/hermes-agent/plugins/platforms/telegram/adapter.py` → `_handle_command()` 内 `/start`、`/menu` 分支；条件为私聊 + `from_user.id == OWNER_ID == chat.id`；`ReplyKeyboardMarkup([[status, model],[new, stop]], resize_keyboard=True, is_persistent=True, input_field_placeholder='选择 Hermes 快捷命令')`；颜色用 `KeyboardButton(label, api_kwargs={'style': ...})`（PTB 22.6 无 `style` 关键字参数）。
- 提交：`458a2cf2 chore: establish audited Hermes local baseline`（2026-10-22），工作区干净。
- 两个 GitHub 仓库（含 `origin/main` 最新提交与全历史）均无此代码。
- 易混同款：`hermes-ops-private/projects/lemon-ops-bot/main.py` 的 `get_private_quick_keyboard()`，3 行 6 键（`/menu /status /service /logs /model /check`），占位符"选择运维快捷命令" —— 运维 Bot，非 Hermes 本体。

## 常用只读命令

```bash
# 1. 本机所有 git 仓库及其远端
for d in /home/ubuntu/*/; do [ -d "$d/.git" ] && { echo "== $d"; git -C "$d" remote -v | head -2; }; done

# 2. 本地 vs 远端（必须先 fetch）
git -C <repo> fetch origin
git -C <repo> rev-list --left-right --count origin/main...HEAD

# 3. 在远端最新树上 grep（不 fetch 会漏）
git -C <repo> grep -l "<特征串>" origin/main
git -C <repo> ls-tree -r --name-only origin/main | grep -i "<关键词>"

# 4. 全历史 grep
for c in $(git -C <repo> rev-list --all | head -30); do git -C <repo> grep -l "<特征串>" $c 2>/dev/null; done | sort -u

# 5. 打包类备份
tar tzf skills_bundle.tar.gz | wc -l
mkdir -p /tmp/x && tar xzf skills_bundle.tar.gz -C /tmp/x && grep -rl "<特征串>" /tmp/x
```

## 汇报口径

- 事实：某仓库某分支某 commit 有无该文件/字符串，附提交号与提交时间。
- 推断：需要说明前提（例如"离线加密包打包清单含 plugins，因此该改动应在其中，但未解密验证"）。
- 不要因为 `lemon-starter` 里有同名主题的 skill 文档（如 `hermes-gateway-ops/references/telegram-command-menu-localization.md` 讲的是 `setMyCommands` 命令菜单）就判定功能已备份 —— 文档 ≠ 实现代码。
