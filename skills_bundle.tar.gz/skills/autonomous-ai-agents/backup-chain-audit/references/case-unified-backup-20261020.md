# 案例：unified 备份链断裂（2026-10-20）

本机 AWS 实例的真实拓扑与实测数字，供同类排查参照。

## 链路结构

```
crontab: 30 3 * * *  flock -n /tmp/lemon-unified-backup.lock \
          /home/ubuntu/hermes-jobs/phase5-backup-schedule.sh
   └─ job-runner.sh unified-backup-daily phase5-backup-build.sh
        ├─ 1/6 建统一备份目录      /home/ubuntu/backups/unified/<YYYYMMDD_HHMMSS>/
        ├─ 2/6 SQLite 一致性快照   state.db（约 119MB）
        ├─ 3/6 核心项目配置归档     configs.tar.gz（约 214MB）
        ├─ 4/6 SHA256SUMS 校验
        ├─ 5/6 非破坏性恢复演练     只定点解压 notify.py / phase5-backup-build.sh / .ssh/config
        ├─ 6/6 加密异地传输         releases/offsite-20261004/offsite_backup.py
        └─ prune                    backup_safety.py prune → 只留 1 天
```

异地目标：`vps-la` = RackNerd `<PRIVATE_IDENTIFIER>`（`~/.ssh/lemon_racknerd_admin`），
落盘 `/opt/hermes-offsite-backups/aws/<stamp>.hermesenc`，远端保留最多 7 份 / 2GiB。

## 关键预算常量（offsite_backup.py）

- `total > 512MiB` 或 `free < total*4 + 1GiB` → `ValueError('Backup exceeds local staging space budget')`
  - 实测 total ≈ 333MB → 需要约 **2.3GB** 可用空间才能打包；
- 远端要求上传后仍剩 5GiB；
- `scp_timeout(size) = min(1800, max(900, size/(0.8MiB/s) + 180))`
  —— 注释明确记载"固定 180s 曾导致 509M 包只传 167M 即超时"，**旧版就是 180s**。

## 本次故障时间线（UTC）

| 时间 | 事件 |
|---|---|
| 10-18 03:30 | 成功，prune 生效 |
| 10-19 03:34:59 | FAILED，`scp ... timed out after 179.99s`（旧 180s 超时） |
| 10-20 03:31:04 | FAILED，`ValueError: Backup exceeds local staging space budget` |
| 10-20 13:29:58 | 远端出现 `20261020_033003.hermesenc`（477MB，来源未查明） |

结果：`unified/` 堆了 3 天（319M + 303M + 289M = 909M），磁盘 `/` 88%（24G 中剩 3.0G）。

## 证据核查实例

待删：`hermes-jobs/tmp/public-guard-merge-20261007T084215Z/`（79M，HEAD `e6f586b`）
与 `...084310Z/`（79M，HEAD `ae7acb5`）。

六项结果：

1. 引用检索：`search_files` 搜 `public-guard-merge|public-history-preparation` 全 `/home/ubuntu`，
   只命中目录自身内部文件；
2. `git worktree list` 在 `/home/ubuntu/lemon-starter-repo` 只有主仓库；
3. `lsof +D` 两目录均无输出；
4. `git reflog` 只有 `clone` 与 `checkout`，无本地提交；
5. `git status --short` 干净；
6. 双份留存：`ae7acb5` 在正式仓库 main 历史（`8551da1` 的父）；
   `e6f586b` 在 `backups/public-history-preparation-20261009T045129Z/lemon-starter.before.bundle`，
   `git bundle list-heads` 显示覆盖重写前 4 分支 + 2 个 PR head。

结论：可删。但**运行时 `rm -rf` 被拦截**，需用户当次明确授权后才执行 —— 不要换命令绕过。

## 教训

- 先看 `jobs/<job>/status`，不要从 `du` 开始；
- prune 在链路末端 + `set -e` = 一旦上传失败就永久堆积；
- 远端正式名（无 `.part`）说明 sha256 校验通过，可作完整性证据；
- 远端 mtime 与本机活动对不上时，如实标"来源未查明"。
