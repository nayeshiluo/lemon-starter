# 发布链路纳管与公开包隐私排除（2026-10-24 实战）

两类相邻但不同的问题，都在「把内部工具镜像进私有仓库」和「把内部文档排除出公开包」时出现。

## 一、排除一个文档出公开包：两份排除清单必须同时改

`lemon-starter` 发布链路有**两处独立的排除集合**，只改一处 `prepare` 直接失败：

| 位置 | 作用 | 只改另一处的后果 |
|---|---|---|
| `candidate_pipeline.py` 的 `SKIP_NAME` | 打包时跳过该文件 | 文件仍进包 |
| `public_skills_guard.py` → `verify_source()` 里的同名硬编码集合 | 校验「源目录每个文件都必须在 manifest 里」 | `FAILED: unapproved_source_file:skills/...` |

**根因**：`verify_source()` 遍历源目录，要求每个文件都出现在 `expected_hashes`（= 本次生成包的 `output_hashes`）。pipeline 排除了文件 → `output_hashes` 不含它 → guard 判定源目录有「未批准文件」。

这跟已记录的 bug 3（发布器不发布它自己的校验器）是同一类：**同一条规则写在两个地方**。动任何排除逻辑前先定位全部副本：

```bash
grep -rn "webui-managed-skills.json" ~/bin/public-skills-export/*.py
```

（该文件名是两份清单共有的稳定标记，用它一次性找出所有需要同步的位置。）

### 排除后的完整验收（八项，缺一不可）

1. `bundle sha256` 与 manifest 自洽
2. 包内 `tar -tzf | grep <文件名>` 为空
3. 包内文件数 == `output_hashes` 数
4. `skills` 字段 == 包内 `SKILL.md` 数
5. 与上一版 manifest 做**集合差**：删除的**只有**目标文件
6. `base_commit` == 当前线上 HEAD
7. guard 权威校验 `public_skills_guard.py <bundle> <candidate.json>` 退出码 0
8. 发布后**全新浅克隆**再验一遍（README 计数、`sha256sum -c`、仓库自带 guard）

第 5 项尤其重要：`prepare` 报的 `removed: 1` 只是计数，实际删了什么必须用 `set(old) - set(new)` 算出来再确认。

## 二、被排除文档的引用要一起改，否则公开包里引用断裂

排除文档后，`SKILL.md` 里若仍写「先读 `references/<该文档>`」，外部用户会去找一个不存在的文件。改法：

- 保留指路，标注「仅本地保留、已排除在公开包之外」
- **去掉文档里的具体内部细节描述** —— 那些描述本身就是泄露面（本例原文列了「三个已实证的静默 bug」的具体名称）

## 三、整个文件都是敏感值清单时：`.REDACTED` 后缀法

有些文件的**全部内容**就是一张敏感值清单 —— 典型是脱敏脚本的替换表：

```python
REPLACEMENTS = [
    (re.compile(r'52\.221\.30\.161'), '<YOUR_SERVER_IP>'),
    (re.compile(r'<YOUR_NODE_PASSWORD>'), '<YOUR_NODE_PASSWORD>'),
    ...
]
```

**真正的障碍不是「脱敏」本身，而是脱敏脚本把字面值写在了自己身上**：手工替换表既泄露原值，又随线上文件变化而失配。正确解法是按模式脱敏（见 §3.1）——生成器只含模式、不含任何真值，因此生成器本身可以正常进仓库，`.REDACTED` 每次由它自动重生成。

正确做法：

1. 生成脱敏副本，字面值换 `<REDACTED_*>`，**保留规则结构**（审计者仍能看出「哪些类型的值会被脱敏」）
2. 文件名加 `.REDACTED` 后缀 —— 不会被 Python `import`，也不会被 guard 的 `TEXT_EXTENSIONS` 当源码扫描
3. 文件头写明：不可执行、勿覆盖真身、真身路径、真身备份位置
4. 生成脚本自检：替换后原字面值**一个都不剩**才 PASS

真身留在线上。注意它可能参与发布器的 `code_hash()`（本例中 4 个文件之一），改它会改变 `code_sha256`，下次候选需重新复审 —— **这一条要写进 README**，否则未来有人改完不知道候选为什么变了。

### 3.1 按模式脱敏：生成器自身可进仓库，且能自动查漂移

五条模式足够覆盖常见的硬编码值清单。**顺序敏感：IP 必须先于长数字**，否则 IP 段会被拆成多个 ID。

| # | 模式 | 替换为 |
|---|---|---|
| 1 | IPv4，含正则里的转义写法（`52\.221\.30\.161`） | `<REDACTED_IP>` |
| 2 | 邮箱 `user@example.com` | `<REDACTED_EMAIL>` |
| 3 | URL 里的真实域名（lookbehind `https://`，保留 scheme 与路径） | `<REDACTED_HOST>` |
| 4 | 9~15 位纯数字（Telegram ID、长 ID） | `<REDACTED_ID>` |
| 5 | 引号内 16+ 位纯字母数字 `(?<=r')[A-Za-z0-9]{16,}(?=')` | `<REDACTED_SECRET>` |

**占位符必须选成「正则仍然合法」的形式**：`re.compile(r'<REDACTED_IP>')` 编译通过，脱敏版因此保持完整可审计结构，只是匹配不到真值。占位符若带引号冲突或特殊字符，脱敏版会变成语法垃圾，`py_compile` 直接失败。

第 5 条只在「引号内、整串都是字母数字」时触发，所以 `GOCSPX-[A-Za-z0-9_-]{20,}`、`eipalloc-[0-9a-z]+`、`Bearer\s+sk-[A-Za-z0-9_-]{20,}` 这类**通用正则原样保留**——它们本来就不含真值，保留才有审计价值。

配套一个双模式 `sync-from-live.sh`：

```bash
./sync-from-live.sh --check   # 逐文件 OK/DIFF，有漂移 exit 1
./sync-from-live.sh           # 复制原样文件 + 重新生成 .REDACTED
```

写入后自动跑四项断言，任一失败 exit 非 0：脱敏版无 IP/邮箱/长数字残留 → 整目录无凭据形态 → `py_compile` 全过 → 脱敏版 `ast.parse`（跳过注释行，因为头部警示语不是合法 Python）。

`--check` 的用途不是给人看，是给**巡检**看（见 §3.3）。

### 3.2 脱敏扫描的命中必须逐条定性，不能见红就判失败

扫自己的仓库时报命中是**常态**，先分类再下结论。本次 8 类模式扫 9 个文件，6 处命中全部良性：

| 命中内容 | 定性 |
|---|---|
| `SAFE_IPS = {'0.0.0.0','127.0.0.1','8.8.8.8','1.1.1.1','169.254.169.254','10.0.0.x','192.168.x.x'}` | 白名单里的**公开保留地址**，不是本机 IP |
| `maintainer@example.com`、`test@example.com` | `example.com` 占位符 |
| `VeryPrivateValue_123456789` | 测试 fixture 故意造的假密钥 |
| 邮箱脱敏正则、UUID 正则本身 | 规则定义，不是值 |

判据只有一条：**命中项里有没有「本机真实 IP / 真实邮箱 / 真实 chat id / 真 token」**。保留地址、`example.*` 占位、测试 fixture、正则定义都不算。把「有命中」直接报成「有泄露」会让用户白紧张，也会让真正需要处理的那条被噪音埋掉。

### 3.3 别把「记得同步」写成人工待办，挂进已有巡检

镜像进仓库后最容易腐烂的一步是同步：线上改了、仓库副本还是旧的，而没有任何东西会喊。**写「以后记得跑一下同步」等于没做**——用户对此明确反问过「你可以直接操作吗」。

做法：`--check` 挂进已有的每日只读巡检（本例是 `5c7c83ec8ce4`，03:45 UTC），作为新增检查项，措辞按巡检契约写：

```
bash <repo>/projects/<name>/sync-from-live.sh --check
预期退出码 0、每个文件都是 OK。若 DIFF 或退出码非 0 → 报「线上已改但仓库副本未同步：<文件名>」
若脚本本身不存在 → 报「同步脚本缺失」，不要尝试重建
```

三条要点：① 挂进已有巡检而不是新建 job（复用「只读、正常静默」契约，用户只有一个地方要盯）；② `--check` 只比对、只写一个 `mktemp` 临时文件，符合只读约束；③ 必须加「脚本不存在就只报不重建」——否则巡检会去改文件，破坏只读契约。

## 四、发布器真身不在任何 git 仓库：先查再补

镜像/审计私有仓库时，先确认「真身在哪」：

```bash
cd <tool dir> && git rev-parse --show-toplevel   # fatal: not a git repository → 备份盲区
```

本例 `/home/ubuntu/bin/public-skills-export/` 的 7 个脚本不在任何仓库，唯一备份是每日加密离线备份的 `recovery_support.tar.gz`（`backup_hermes.sh` 的 `SUPPORT_ITEMS` 含 `bin`）。**有备份 ≠ 有 GitHub 备份**：恢复要私钥，无法在网页上查看或 diff。

补法：镜像进 `hermes-ops-private/projects/<name>-publish/`，README 写清「这是镜像不是运行位置」+ 文件对应表 + 同步命令 + 未纳管项（`vendor/` 依赖、`__pycache__`）。

## 五、文件集合对比别用 `find | head`

本次两次误判都源于输出截断：`find | head -20` 让我断言「公开仓库 `tools/` 只有 1 个文件」，实际有 4 个；`grep ... | head -8` 让我断言「agent 不读 `extra_headers`」，实际读。

**判断两个目录/两段代码的差集必须用完整集合运算**（Python `set(rglob('*'))` 相减、或 `grep -c`），不要用 `find | head` 目测，也不要在 `grep` 后叠加同行关键词过滤再定案。

## 六、往本技能加 reference 会随下次发布公开

`backup-chain-audit` 整个技能目录都在公开包内。往 `references/` 加文件 = 下次 `prepare` 自动进公开包，guard 只拦凭据类模式，不拦「内部运维细节」。

写之前先判断：这份内容适合公开吗？不适合就同时加进两份排除清单（见 §一）。
