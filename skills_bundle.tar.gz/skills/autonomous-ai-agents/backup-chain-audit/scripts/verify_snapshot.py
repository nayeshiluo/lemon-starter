#!/usr/bin/env python3
"""在删除旧快照之前，证明"要留下的那份"真的可恢复。

只读。不修改任何被检查的文件。

用法:
    python3 verify_snapshot.py <快照目录>
    python3 verify_snapshot.py <快照目录> --baseline <更旧的快照目录>   # 额外比对行数不低于旧份
    python3 verify_snapshot.py <快照目录> --min-messages 1000

检查项（任一失败即 exit 1）:
    1. SHA256SUMS 存在且 `sha256sum -c` 全 OK（若目录内有该文件）
    2. 每个 *.db 的 PRAGMA integrity_check == ok
    3. *.db 关键表行数非零；给了 --baseline 时不得低于 baseline
    4. 每个 *.tar.gz 能被完整遍历（含 gzip trailer/CRC），成员数 > 0
    5. 目录内没有残留的 .part-* / .cms 分片（存在即说明上传未完成）

设计取舍:
  - 只做只读校验，不尝试解密（解密需要私钥，不该出现在自动化里）。
  - 明文快照可校验到表级；加密包只能校验结构与成员，此时第 2/3 项自动跳过。
  - 行数比对是防"新快照看起来更全其实被截断"的关键，单看大小会漏。
"""
import argparse
import re
import sqlite3
import subprocess
import sys
import tarfile
from pathlib import Path

# 这些表存在就检查；不存在就跳过（不同 Hermes 版本表名有差异）
KEY_TABLES = ("messages", "sessions")


def fail(msg):
    print(f"FAIL  {msg}")
    return False


def ok(msg):
    print(f"ok    {msg}")
    return True


def check_sha256sums(root: Path) -> bool:
    manifest = root / "SHA256SUMS"
    if not manifest.is_file():
        print("skip  SHA256SUMS 不存在，跳过")
        return True
    r = subprocess.run(
        ["sha256sum", "-c", manifest.name],
        cwd=str(root), capture_output=True, text=True,
    )
    bad = [ln for ln in r.stdout.splitlines() if ln.strip().endswith(("FAILED", "OK")) is False]
    if r.returncode != 0:
        return fail(f"sha256sum -c 失败: {r.stdout.strip()[:400]}")
    n = len([ln for ln in r.stdout.splitlines() if ln.strip().endswith("OK")])
    return ok(f"SHA256SUMS 全部通过（{n} 个文件）")


def db_stats(path: Path):
    """返回 (integrity, {table: rows}) ；只读打开。"""
    con = sqlite3.connect(f"file:{path}?mode=ro", uri=True)
    try:
        integrity = con.execute("PRAGMA integrity_check").fetchone()[0]
        counts = {}
        have = {r[0] for r in con.execute(
            "SELECT name FROM sqlite_master WHERE type='table'")}
        for t in KEY_TABLES:
            if t in have:
                counts[t] = con.execute(f"SELECT count(*) FROM {t}").fetchone()[0]
        return integrity, counts
    finally:
        con.close()


def check_db(path: Path, baseline: Path | None, min_messages: int) -> bool:
    try:
        integrity, counts = db_stats(path)
    except Exception as exc:
        return fail(f"{path.name} 无法读取: {type(exc).__name__}: {exc}")
    if integrity != "ok":
        return fail(f"{path.name} integrity_check = {integrity}")
    if not ok(f"{path.name} integrity_check = ok  {counts}"):
        return False
    for t, n in counts.items():
        floor = 0
        if t == "messages":
            floor = max(floor, min_messages)
        if baseline is not None:
            bpath = baseline / path.name
            if bpath.is_file():
                try:
                    _, bcounts = db_stats(bpath)
                    floor = max(floor, bcounts.get(t, 0))
                except Exception:
                    pass
        if n < floor:
            return fail(f"{path.name} 表 {t} 行数 {n} < 下限 {floor}")
    return True


def check_tar(path: Path) -> bool:
    try:
        with tarfile.open(path, "r:gz") as tf:
            n = 0
            for m in tf:
                if m.isfile() and m.size > 0:
                    n += 1
            # 读完到 trailer，让 gzip CRC/长度校验真正跑一遍
            for _ in iter(lambda: tf.fileobj.read(1024 * 1024), b""):
                pass
    except Exception as exc:
        return fail(f"{path.name} 遍历失败: {type(exc).__name__}: {exc}")
    if n == 0:
        return fail(f"{path.name} 无有效成员")
    return ok(f"{path.name} 可完整遍历，{n} 个非空成员")


def check_no_fragments(root: Path) -> bool:
    junk = [p.name for p in root.iterdir()
            if re.search(r"\.part-\d+$|\.cms$", p.name)]
    if junk:
        return fail(f"残留未完成分片: {junk}")
    return ok("无 .part-* / .cms 残留")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("snapshot", type=Path)
    ap.add_argument("--baseline", type=Path, default=None,
                    help="更旧的快照目录，用于行数不低于旧份的比对")
    ap.add_argument("--min-messages", type=int, default=1)
    a = ap.parse_args()

    root = a.snapshot.resolve()
    if not root.is_dir():
        print(f"FAIL  {root} 不是目录")
        return 1
    if a.baseline is not None and not a.baseline.is_dir():
        print(f"FAIL  baseline {a.baseline} 不是目录")
        return 1

    print(f"检查快照: {root}")
    results = [
        check_no_fragments(root),
        check_sha256sums(root),
    ]
    for db in sorted(root.glob("*.db")):
        results.append(check_db(db, a.baseline.resolve() if a.baseline else None,
                                a.min_messages))
    for tarball in sorted(root.glob("*.tar.gz")):
        results.append(check_tar(tarball))

    if not any(root.glob("*.db")) and not any(root.glob("*.tar.gz")):
        results.append(fail("目录内既无 *.db 也无 *.tar.gz，无法证明可恢复"))

    if all(results):
        print("\nPASS  该快照可恢复，允许删除更旧的同类快照")
        return 0
    print("\n结论: 不可删除旧快照 —— 先修好上面 FAIL 的项")
    return 1


if __name__ == "__main__":
    sys.exit(main())
