---
name: backup-chain-audit
description: "备份链路诊断与治理：prune 死循环、删除前证据核查、恢复路径验证、覆盖度核查（某功能在不在备份里）、保留策略与异地台账。"
version: 1.2.0
author: Hermes Agent
license: MIT
platforms: [linux]
metadata:
  hermes:
    tags: [backup, disk-cleanup, prune, offsite, evidence, ops]
    related_skills: [hermes-backup, aws-ec2-ops]
---

# 备份链路审计与安全清理

## When to Use

- 磁盘告警或空间不足，需要清理备份/快照目录；
- 定时备份 job 报 `FAILED`，或备份目录份数明显超过保留策略；
- 需要删除任何"看起来没用了"的目录、沙箱、历史快照。
- **覆盖度核查**：用户问"某个功能/补丁/代码在不在备份里"（例如"你在 GitHub 那两种备份里有这个东西吗"）。这类问题必须先定位代码真实位置，再逐个备份通道核验，不能凭"应该有"回答。速查地图见 `references/github-backup-coverage-map.md`。
- **公开技能快照发布链路（`lemon-starter`）**：这条不是 push 镜像，而是「脱敏候选 → 人工确认 → 发布」。用户问"另一种备份"或要修这条链路时，先读 `references/public-skills-publish-pipeline.md`：含链路结构、三个已实证的静默 bug（README 计数硬编码冻结、扩展名白名单漂移致定时任务必失败、发布器不发布它自己的校验器）、分叉克隆能否 reset 的三条判据。
- **保留与体积核查**：用户问"每天都备份吗 / 备份都存着吗 / 会不会越来越臃肿"。这是**两个维度**的问题（本机磁盘 vs 异地云端），必须分开答，别用一句"有保留策略"糊过去。实测数据与命令集见 `references/backup-retention-growth-audit.md`。
- **保留策略落地**：用户说"给我一个完美方案，然后进行"——诊断完要真改脚本、真跑验证，不能停在建议。异地台账与精确删除的实现见 `references/telegram-offsite-retention.md`。
- **把线上运维脚本镜像进受约束的私有仓库**（`hermes-ops-private` 这类有 `SYNC_POLICY` 的）：脚本里常藏着仓库禁止存储的 Telegram chat id / token，直接 `cp` 就违规。必须先扫标识 → 脱敏复制 → 跑四项断言（含 `bash -n` 抓 sed 吃字符），并如实报告"历史提交里仍有"而不擅自 force push。完整配方见 `references/repo-redaction-sync.md`。

## 铁律：先证伪，再授权

用户明确要求过：**"你得先确认那个没用了，你才能删掉。"**

- 禁止凭目录名、时间戳、"看起来像一次性沙箱"下判断；
- 必须先完成下面的证据核查，**把证据摆给用户看**，取得明确同意后才动手；
- 运行时对 `rm` 类操作有独立拦截：即使证据齐全，也要等用户当次明确授权，不要换个命令绕过拦截。

## 一、先查备份 job，别直接删

**磁盘满 ≠ 该清磁盘。** 多数"备份堆积"是备份链断裂的结果，不是原因。

```bash
crontab -l | grep -iE "backup|unified"
cat /home/ubuntu/hermes-jobs/jobs/<job-name>/status      # FAILED?
tail -c 3000 /home/ubuntu/hermes-jobs/jobs/<job-name>/job.log
grep -E "^\[.*(FAILED|START)" /home/ubuntu/hermes-jobs/jobs/<job-name>/job.log | tail -14
```

`status` 文件里的 `exit=1` 与日志尾部 traceback 是判据；`FINAL_NOTIFY_CONFIRMED` 只代表通知发了，不代表成功。

## 二、prune 死循环：最常见的真根因

典型备份脚本结构：

```
建包 → 校验 → 恢复演练 → 加密异地传输 → prune（只留 N 天）
```

配合 `set -euo pipefail`：**异地传输失败 → prune 不执行 → 旧快照堆积 → 磁盘更满 → 打包暂存预算不足 → 下一次传输更失败**。这是正反馈死循环，会一直恶化到有人介入。

判据三件套：

1. 备份目录份数 > 保留策略（例：策略只留 1 天，实际堆了 3 天）；
2. job `status = FAILED`；
3. 日志含 `Backup exceeds local staging space budget`、`scp ... timed out`、`No space left`。

**处置顺序**：先手工清掉最旧的几份打破循环（保留最新一份，且确认最新一份在异地存在），再让下一轮定时任务自愈；不要只清磁盘不看 job 状态。

## 三、删除前六项证据核查

对每个待删目录逐项验证，全部通过才算"确认没用了"：

| # | 检查 | 命令要点 | 通过标准 |
|---|---|---|---|
| 1 | 外部引用 | 在 `/home/ubuntu`、`/etc/systemd`、`/etc/cron*`、`crontab -l` 检索目录名 | 只在目录自身内部命中 |
| 2 | git worktree 注册 | `git worktree list`（在对应正式仓库） | 无指向待删目录的条目 |
| 3 | 进程占用 | `lsof +D <dir>` | 无输出 |
| 4 | 本地独有 commit | `git reflog --date=short` | 只有 `clone` / `checkout`，无本地创作提交 |
| 5 | 工作区干净 | `git status --short` | 无未提交改动 |
| 6 | 内容有双份留存 | 见下 | 至少一处独立副本 |

**第 6 项最容易被跳过，也最关键。** 验证方式：

```bash
# 该 commit 是否在正式仓库
cd /home/ubuntu/<正式仓库> && git cat-file -t <sha>
# 该 commit 是否在备份 bundle 里
git bundle list-heads <xxx.before.bundle
```

`git bundle list-heads` 能直接证明 bundle 覆盖了哪些分支与 sha —— 这比"目录名像备份"强得多。

**但 thin bundle 会给假安全感**：实测某个 `unpushed-5-commits.bundle`，`list-heads` 正常返回
`6708c60... HEAD`，看起来"内容都在"；实际 `git fetch <bundle> HEAD` 报
`error: Repository lacks these prerequisite commits: be057df...` —— 它是**增量包**，
必须已有前置提交才能展开。若本机所有仓库都 `git cat-file -t` 不到那个前置提交，
就**无法证明它已被推送、也无法证明它未覆盖任何东西** → 证据不足，**保留，不删**。
只凭 `list-heads` 有输出就判定"bundle 可用/可弃"是错的。

## 四、写清理记录（可回滚）

删除前写 `CLEANUP-<date>.md`，至少包含：

- 待删目录、大小、HEAD sha、工作区状态；
- 六项核查结果（表格）；
- **明确列出保留项与理由**（安全网不能删）；
- 恢复命令（从 bundle 克隆的具体一行）。

## 五、远端/异地核实

```bash
ssh <host> 'stat -c "size=%s mtime=%y ctime=%z" <file>'
ssh <host> 'ls -1 <dir>/*.part 2>/dev/null'      # 残留分片
ssh <host> 'head -c 16 <file> | xxd'             # magic header
```

- **正式名 vs `.part`**：上传脚本通常"校验通过才 rename"，所以没有 `.part` 残留 + 有正式名 = 该包完整。这条能替代昂贵解密验证。
- **mtime 可能与本机活动对不上**：先查本机 `jobs/` 变动、`journalctl` 该时段、`ps`，若都无记录就如实标"来源未查明"，**不要编造来源**。可能原因：远端时钟偏移、多机共用目录、未知触发路径。
- 查远端磁盘：`df -h /`，确认不是远端打满导致上传失败。

## 六、覆盖度核查：某个功能/代码在不在备份里

用户问"这个功能在那几个备份里有吗"时，**先定位、再核验、后给结论**，顺序不能反：

1. **定位真实位置**：先用特征字符串在本地源码里 grep 出唯一归属文件（例：`grep -rn "输入框占位符/函数名"`），确认它属于哪个仓库、哪个 commit、工作区是否干净（`git status --porcelain`、`git log -1 -- <file>`）。很多人会以为功能属于 A 项目，实际在 B 仓库的插件里。
2. **确认"备份"指哪些仓库**：列 `/home/ubuntu` 下所有含 `.git` 的目录 + `git remote -v`，再对照 `hermes-ops-private/manifests/repository-map.json` 区分"私有镜像 / 公开分发 / 上游镜像"。**本机某个仓库有 cnb.cool 或 upstream 远端 ≠ 用户口中的 GitHub 备份。**
3. **先 fetch 再比较**：本地 origin ref 常常过期，`git rev-list --left-right --count origin/main...HEAD` 不 fetch 会得出错误结论。本次实测两个仓库分别落后 10 个和分叉 45/55 个提交 —— 结论必须建立在 `git fetch origin` 之后的 `origin/main` 上。
4. **按通道逐一 grep**：`git grep -l "<特征串>" origin/main`、历史全量 `for c in $(git rev-list --all); do git grep -l ... $c; done`；打包类备份要解开再 grep：`tar tzf bundle.tar.gz | grep -i <关键词>`、解包后 `grep -rl`。
5. **给出"有/没有 + 在哪有"**：结论要落到三档：GitHub 备份有 / 只在加密异地备份有 / 哪里都没有只在工作区。加密链路的覆盖范围看 `~/.hermes/scripts/backup_hermes.sh` 的打包清单（`plugins` 目录在内，所以插件改动在离线加密包里有备份，但不在 GitHub）。
6. **警惕"同款不同物"**：同类键盘/菜单可能在另一个 bot 里有几乎一样的实现（占位符文案相近、键位不同）。必须贴出键位与触发条件对比，明确说明"这是运维 Bot 的，不是 Hermes 本体的"，否则用户会误以为已覆盖。

修复建议按最小改动排序：优先把 diff 补进 `hermes-local-patches/hermes-local.patch`，其次才考虑新增源码快照（仓库会变大）。

## 七、保留策略与体积增长审计（"会不会越来越臃肿"）

必须把问题拆成 **本机磁盘 / 异地云端 / 不受策略管的孤儿目录** 三层分别回答，只答一层就会误导。

1. **确认频率**：Hermes 自身备份在 `~/.hermes/cron/jobs.json`（不是 crontab），按 `backup` 过滤出 job（例 `319e7f36295e`，`0 3 * * *`）；unified 链路在 `crontab -l`（`30 3 * * *` → `phase5-backup-schedule.sh`）。**系统时区是 `Etc/UTC`，cron 表达式按 UTC 记，报北京时间要 +8**，并且采样时间必须和指标一起从 `date` / `timedatectl` 读取。
2. **证明"每天真的跑成了"**：`executions.db` 按 `job_id` 过滤取最近 N 条 `status`，再看 `.hermes/cron/output/<job_id>/<日期>.md` 里的健康门禁行。只有 `completed` + 门禁数值才算跑成。
3. **本地保留量按 pattern 算，不按目录名猜**：`backup_safety.py prune()` 删「非当前 + mtime>24h」，所以**常驻 2 份**（今日 + 昨日）。用 `ls -d backups/hermes-[0-9]*` 数份数、`du -sh backups/hermes-*` 看体积，对不上就是链断了。
4. **本地加密包是零残留**：`backup_hermes.sh` 用 `trap cleanup_upload EXIT` 删 `.cms` 与 `.part-*`，所以 `ls backups/*.cms` 为空是**正常**，不能当成"异地备份没做"的证据。异地有没有做得看上传清单与目标端。
5. **异地只增不删是常态缺口**：`backup_upload.py` 只调 `sendDocument`，没有 `deleteMessage`。每天整包 tar.gz 永久留在 TG 私聊里，按 45MiB 切片。实测一天 ≈101MiB / 3 片 → 月 ≈3GB、年 ≈36GB。不占本机磁盘，但恢复时要按清单翻大量历史分片。**这是唯一真正无限增长的维度**，要主动报给用户，不要只答"本地只留 2 份所以不会臃肿"。
6. **孤儿目录单独算**：prune 的 pattern 只匹配 `hermes-YYYYMMDD_HHMMSS`，`~/backups` 下的历史手工快照（`antigravity-*`、`ai-footer-*`、`commands.callback64.*`、`codex-remote-prep-*`）**永远不删**。实测 2.2G 的 `backups` 里自动备份只占 434M，其余约 1.77G 全是这类。磁盘告警时先查这块，别只盯着定时备份。
7. **增长源头要落到文件**：`du -sh backups/hermes-<今日>/*` 找最大项（通常是 `state.db`），再用两天的 `state.db` 大小差算日增。加密后体积用 `cd <备份目录> && tar czf - . | wc -c` 实测，不要拿明文目录大小当上传量。
8. **找到 `state.db` 是增长源头后，不许提 VACUUM**：`~/.hermes/scripts/db_maintenance.py` 里写着明确审计结论——`state.db 完全跳过：由 Hermes gateway 24/7 独占维护`，2026-09-07 根因审计认定**外部脚本任何形式的干预都是 state.db 反复损坏的源头**（FTS merge 必失败、跨版本并发 checkpoint）。所以日增 15 MiB、每天上传 100 MiB 只能认，不能"优化"。给用户方案时必须把这条作为**已放弃项**讲清理由，而不是悄悄略过。

**修复方案（不只诊断）**：异地无限增长的解法是「上传时记 message_id 台账 + 按月/按天窗口精确删除」，实现细节、Bot API 参数坑、验收方法见 `references/telegram-offsite-retention.md`。注意台账上线**之前**的历史分片无法自动清理，这是 Bot API 能力边界，不要承诺能补。

## Pitfalls

- **`terminal` 里出现 `rm -rf` 字样会被 hardline 拦截**，即使只是写在 `grep -nE "rm -rf|..."` 里。改用 `search_files` 查内容、`read_file` 读文件，别用 shell 的 grep/sed。
- **真删文件时被拦截 ≠ 被拒绝，也 ≠ 可以换写法重试**。返回体是 `BLOCKED: ... user has NOT consented`，明确要求**不要重试、不要换命令达成同一结果**。此时正确动作是：停止删除、把已核实的删除清单和保留理由摆给用户、**明确说"请点一下授权弹窗"**，然后等。用户看不到弹窗时会误以为助手拒绝执行。同一轮里"先写清单 → 再删"的写法有效，但删除命令本身仍要等当次授权。
- **超长 heredoc / 巨型单行命令会被拦截**。把逻辑写成 `.py`/`.sh` 文件，再 `bash <file>` 或 `python <file>` 执行。
- 磁盘紧张时 `du -sh /home/ubuntu/*` 可能超时 → 先 `du -sh` 指定子目录，逐层缩小。
- **不要删加密异地备份的本地副本**（如 `verified-local-encrypted/`），它可能是传输失败时唯一安全网。
- 中间产物（`.git` / `.cleaned.git` / `.bundle`）与"最终快照"要分开评估；历史重写前的 `.before.bundle` 属于不可再生安全网，永远保留。
- **备份脚本里"恢复演练"通过不代表备份可用** —— 演练只解压几个指定文件（`notify.py`、`.ssh/config` 等），不代表全量可恢复。
- **定时 prune 会和你手工清理抢同一批目录，清单必须当场复核**。本次实测：分析阶段写下"保留 `unified/20261023_033004`（已校验）"，
  等真正执行删除时 03:30 的定时 job 已经跑过，把它 prune 掉并换成了 `20261024_033004`。若照几分钟前的清单盲删，
  就会删掉唯一还存在的旧份。**规则：`rm` 之前重新 `ls` 一遍待删项与保留项，确认都还在、大小没变；清单只是给人看的记录，不是执行依据。**
- **删旧快照前，先证明"要留下的那份"真的可恢复**，而不是只证明它存在。直接跑
  `python3 scripts/verify_snapshot.py <要留下的快照> --baseline <更旧的快照>`：
  它会连做 `sha256sum -c` 全 OK → `PRAGMA integrity_check` = `ok` → 关键表行数（`messages`/`sessions`）
  非零且不低于旧份 → `tar.gz` 完整遍历（含 gzip CRC）→ 无 `.part-*` 残留。五项通过才允许删旧份。
  **行数比对不能省**：只比大小会漏掉"新快照看起来更全其实被截断"。
- **不 fetch 就下"有没有"的结论必错**：本地 `origin/main` ref 可能落后几十个提交，`git rev-list --left-right --count` 也会给出误导性的"落后 N"。
- **同名主题的 skill 文档不等于实现代码**：`lemon-starter` 里的 `telegram-command-menu-localization.md` 讲 `setMyCommands`，与被问的 ReplyKeyboard 快捷键盘无关。核查结论要落到具体文件与字符串。
- 报告时区分**已验证事实**与**推断**：文件完整（magic/大小/无 .part）是事实；"这次备份安全"是推断，需要说明前提。
