---
name: backup-chain-audit
description: "备份链路断裂诊断与安全清理：prune 死循环、删除前证据核查、恢复路径验证。"
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux]
metadata:
  hermes:
    tags: [backup, disk-cleanup, prune, offsite, evidence, ops]
    related_skills: [hermes-backup, aws-ec2-ops]
---

# 备份链路审计与安全清理

## When to Use

- 磁盘告警或空间不足，需要清理备份/快照目录；
- 定时备份 job 报 `FAILED`，或备份目录份数明显超过保留策略；
- 需要删除任何"看起来没用了"的目录、沙箱、历史快照。

## 铁律：先证伪，再授权

用户明确要求过：**"你得先确认那个没用了，你才能删掉。"**

- 禁止凭目录名、时间戳、"看起来像一次性沙箱"下判断；
- 必须先完成下面的证据核查，**把证据摆给用户看**，取得明确同意后才动手；
- 运行时对 `rm` 类操作有独立拦截：即使证据齐全，也要等用户当次明确授权，不要换个命令绕过拦截。

## 一、先查备份 job，别直接删

**磁盘满 ≠ 该清磁盘。** 多数"备份堆积"是备份链断裂的结果，不是原因。

```bash
crontab -l | grep -iE "backup|unified"
cat /home/ubuntu/hermes-jobs/jobs/<job-name>/status      # FAILED?
tail -c 3000 /home/ubuntu/hermes-jobs/jobs/<job-name>/job.log
grep -E "^\[.*(FAILED|START)" /home/ubuntu/hermes-jobs/jobs/<job-name>/job.log | tail -14
```

`status` 文件里的 `exit=1` 与日志尾部 traceback 是判据；`FINAL_NOTIFY_CONFIRMED` 只代表通知发了，不代表成功。

## 二、prune 死循环：最常见的真根因

典型备份脚本结构：

```
建包 → 校验 → 恢复演练 → 加密异地传输 → prune（只留 N 天）
```

配合 `set -euo pipefail`：**异地传输失败 → prune 不执行 → 旧快照堆积 → 磁盘更满 → 打包暂存预算不足 → 下一次传输更失败**。这是正反馈死循环，会一直恶化到有人介入。

判据三件套：

1. 备份目录份数 > 保留策略（例：策略只留 1 天，实际堆了 3 天）；
2. job `status = FAILED`；
3. 日志含 `Backup exceeds local staging space budget`、`scp ... timed out`、`No space left`。

**处置顺序**：先手工清掉最旧的几份打破循环（保留最新一份，且确认最新一份在异地存在），再让下一轮定时任务自愈；不要只清磁盘不看 job 状态。

## 三、删除前六项证据核查

对每个待删目录逐项验证，全部通过才算"确认没用了"：

| # | 检查 | 命令要点 | 通过标准 |
|---|---|---|---|
| 1 | 外部引用 | 在 `/home/ubuntu`、`/etc/systemd`、`/etc/cron*`、`crontab -l` 检索目录名 | 只在目录自身内部命中 |
| 2 | git worktree 注册 | `git worktree list`（在对应正式仓库） | 无指向待删目录的条目 |
| 3 | 进程占用 | `lsof +D <dir>` | 无输出 |
| 4 | 本地独有 commit | `git reflog --date=short` | 只有 `clone` / `checkout`，无本地创作提交 |
| 5 | 工作区干净 | `git status --short` | 无未提交改动 |
| 6 | 内容有双份留存 | 见下 | 至少一处独立副本 |

**第 6 项最容易被跳过，也最关键。** 验证方式：

```bash
# 该 commit 是否在正式仓库
cd /home/ubuntu/<正式仓库> && git cat-file -t <sha>
# 该 commit 是否在备份 bundle 里
git bundle list-heads <xxx.before.bundle
```

`git bundle list-heads` 能直接证明 bundle 覆盖了哪些分支与 sha —— 这比"目录名像备份"强得多。

## 四、写清理记录（可回滚）

删除前写 `CLEANUP-<date>.md`，至少包含：

- 待删目录、大小、HEAD sha、工作区状态；
- 六项核查结果（表格）；
- **明确列出保留项与理由**（安全网不能删）；
- 恢复命令（从 bundle 克隆的具体一行）。

## 五、远端/异地核实

```bash
ssh <host> 'stat -c "size=%s mtime=%y ctime=%z" <file>'
ssh <host> 'ls -1 <dir>/*.part 2>/dev/null'      # 残留分片
ssh <host> 'head -c 16 <file> | xxd'             # magic header
```

- **正式名 vs `.part`**：上传脚本通常"校验通过才 rename"，所以没有 `.part` 残留 + 有正式名 = 该包完整。这条能替代昂贵解密验证。
- **mtime 可能与本机活动对不上**：先查本机 `jobs/` 变动、`journalctl` 该时段、`ps`，若都无记录就如实标"来源未查明"，**不要编造来源**。可能原因：远端时钟偏移、多机共用目录、未知触发路径。
- 查远端磁盘：`df -h /`，确认不是远端打满导致上传失败。

## Pitfalls

- **`terminal` 里出现 `rm -rf` 字样会被 hardline 拦截**，即使只是写在 `grep -nE "rm -rf|..."` 里。改用 `search_files` 查内容、`read_file` 读文件，别用 shell 的 grep/sed。
- **超长 heredoc / 巨型单行命令会被拦截**。把逻辑写成 `.py`/`.sh` 文件，再 `bash <file>` 或 `python <file>` 执行。
- 磁盘紧张时 `du -sh /home/ubuntu/*` 可能超时 → 先 `du -sh` 指定子目录，逐层缩小。
- **不要删加密异地备份的本地副本**（如 `verified-local-encrypted/`），它可能是传输失败时唯一安全网。
- 中间产物（`.git` / `.cleaned.git` / `.bundle`）与"最终快照"要分开评估；历史重写前的 `.before.bundle` 属于不可再生安全网，永远保留。
- 备份脚本里"恢复演练"通过不代表备份可用 —— 演练只解压几个指定文件（`notify.py`、`.ssh/config` 等），不代表全量可恢复。
- 报告时区分**已验证事实**与**推断**：文件完整（magic/大小/无 .part）是事实；"这次备份安全"是推断，需要说明前提。
