# CLIProxyAPI 远程无头服务器 OAuth 登录（Antigravity/Gemini 实测）

## 场景
服务跑在无头云服务器（无浏览器、无显示器），用户在自己电脑/手机浏览器完成 Google 授权。
OAuth redirect_uri 指向 `http://localhost:51121/oauth-callback`（服务器本机），用户浏览器跳转必然失败——这正是我们要利用的。

## 完整流程（实测通过，v7.2.132）
1. 后台启动登录：
   ```bash
   cd ~/cliproxyapi && ./cli-proxy-api -config config.yaml -antigravity-login -no-browser
   ```
   输出：
   - SSH 隧道建议（可忽略，走粘贴模式更省事）
   - `Visit the following URL to continue authentication:` + Google OAuth URL（带 state）
   - `Waiting for antigravity authentication callback...`
   - `Paste the antigravity callback URL (or press Enter to keep waiting):` ← 关键提示

2. 把授权 URL 发给用户，要求：
   - 用**有订阅的账号**登录
   - 点 Google 同意页的 **Continue / 允许** 按钮（可能在页面底部，需下滑）
   - 浏览器跳到 localhost:51121 显示"无法访问" → **复制地址栏完整 URL 发回**

3. 服务器侧喂回回调（**不要用 process submit——Hermes 后台进程 stdin 不可用**）：
   ```bash
   curl -s "http://localhost:51121/oauth-callback?state=<state>&iss=https://accounts.google.com&code=<code>&scope=...&authuser=0&prompt=consent" -m 15
   # 返回 <h1>Login successful</h1><p>You can close this window.</p>
   ```
   URL 含 & 符号必须整体加引号。

4. 登录进程输出：
   ```
   antigravity: obtained project ID axio...zp2g
   Authentication saved to /home/ubuntu/.cli-proxy-api/antigravity-<email>.json
   Authenticated as <email>
   ```

## 用户侧常见错误
| 用户发来的东西 | 含义 | 应对 |
|---|---|---|
| `accounts.google.com/signin/oauth/firstparty/nativeapp?...` | 还停在授权中间页，没点 Continue | 引导找蓝色 Continue/允许 按钮，点完才会跳转 |
| `http://localhost:51121/oauth-callback?code=...` | ✅ 正确的回调 URL | 直接 curl 喂回 |
| 什么都没发 | 链接 5 分钟过期 | 重跑登录命令拿新链接（新 state） |

## 注意
- 授权链接有效期约 5 分钟（CLIProxyAPI 端超时也约 5 分钟，日志 `authentication timed out`）——超时就重跑，不要等
- state 参数每次登录不同，喂回时必须用当前链接里的 state
- 一个账号只需登录一次，凭证落盘 auth-dir，之后服务重启自动加载、15 分钟自动刷新
- 其他提供商登录 flag 同套路：`-claude-login`、`-codex-login`（另有 `-codex-device-login` 设备码流程，远程更省事）、`-xai-login`、`-kimi-login`
