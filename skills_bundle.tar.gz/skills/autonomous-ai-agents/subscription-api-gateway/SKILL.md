---
name: subscription-api-gateway
description: 把 AI 订阅账号（Gemini/Codex/Claude/Grok）包装成 OpenAI 兼容 API 时使用。
---

# 订阅转 API 网关（CLIProxyAPI）

## 触发条件
用户想把**订阅账号**（Gemini Pro、ChatGPT Plus、Claude Pro、Super Grok、Kimi 订阅）当 **API** 用：
- "cli proxy api" / "把订阅变 API" / "OAuth 登录" / "Claude Code 用 Gemini 订阅" 等
- 低成本/白嫖路线：订阅费顶 API 费，多账号轮询不触率限

## 是什么
CLIProxyAPI（router-for-me/CLIProxyAPI，MIT）把官方 CLI 工具的 OAuth 登录态（Antigravity/Gemini、Claude Code、OpenAI Codex、Grok Build、Kimi）包装成 OpenAI / Gemini / Claude / Codex 兼容 API。任何 OpenAI 兼容客户端（Hermes custom provider、Claude Code、Codex、OpenCode、curl）都能接。
同类工具：sub2api、9Router、vibeproxy（仅参考，以下流程针对 CLIProxyAPI 已验证）。

## 部署（无 Docker 首选二进制，~64MB Go 单文件）
```bash
# 查最新版：GitHub releases 页面或 api.github.com/repos/router-for-me/CLIProxyAPI/releases/latest
mkdir -p ~/cliproxyapi && cd ~/cliproxyapi
curl -sL -o cpa.tar.gz <linux_amd64.tar.gz 下载链接>
tar xzf cpa.tar.gz   # 解压出 cli-proxy-api 二进制 + config.example.yaml
./cli-proxy-api --help   # 验证
```
Docker 替代：`docker run -d --name cliproxyapi -p 8317:8317 eceasy/cli-proxy-api:latest`
注意：小内存机（<2G）不建议 Docker，直接二进制。

## 最小配置 config.yaml
```yaml
host: ""
port: 8317
auth-dir: "~/.cli-proxy-api"
api-keys:
  - "<openssl rand -hex 16 生成>"
debug: false
```
- auth-dir 存 OAuth 凭证（antigravity-<email>.json 等），服务启动自动加载
- api-keys 是客户端调用必需的 Bearer key；不设 = API 裸奔
- remote-management.secret-key 留空 = 管理 API 全关；要 WebUI 面板再配（allow-remote + 强 key）

## 远程无头服务器 OAuth 登录（核心难点）
关键流程见 `references/remote-oauth-login.md`。一句话版：
1. `./cli-proxy-api -config config.yaml -antigravity-login -no-browser`（后台跑）
2. 打印 Google 授权 URL + "Paste the antigravity callback URL (or press Enter to keep waiting):"
3. 用户本地浏览器打开授权 → 点 Continue/允许 → 浏览器跳 `localhost:51121/oauth-callback?...` 失败
4. **用户把地址栏完整 URL 发回 → 服务器上 `curl "http://localhost:51121/oauth-callback?state=...&code=..."`**，监听进程捕获 code，输出 "Login successful" + "Authentication saved to ~/.cli-proxy-api/antigravity-<email>.json"
5. 授权链接 5 分钟超时，超时重跑登录命令拿新链接

其他登录 flag：`-claude-login`、`-codex-login` / `-codex-device-login`、`-xai-login`、`-kimi-login`、`-vertex-import <key.json>`

## systemd 常驻
模板：`templates/cliproxyapi.service`（User=ubuntu 按实际改，Restart=always）
```bash
sudo cp cliproxyapi.service /etc/systemd/system/
sudo systemctl daemon-reload && sudo systemctl enable --now cliproxyapi
```

## 验证
```bash
curl -s localhost:8317/v1/models -H "Authorization: Bearer <KEY>"                      # 模型列表
curl -s localhost:8317/v1/chat/completions -H "Authorization: Bearer <KEY>" \
  -H "Content-Type: application/json" -d '{"model":"gemini-3-flash","messages":[{"role":"user","content":"hi"}],"max_tokens":50}'  # 真实对话
```
Antigravity 账号常见模型：gemini-3-flash / -agent、gemini-3.5-flash-low、gemini-3.6/3.7-flash-high；部分账号经 antigravity-credits 还能出 claude-opus-4-6-thinking、claude-sonnet-4-6、gpt-oss-120b-medium（以 /v1/models 实际返回为准）。

## 接入客户端
- **Hermes**：部署好网关后，按 `hermes-custom-providers` 技能加 custom provider（base_url=http://<ip>:8317/v1）
- Claude Code：`ANTHROPIC_BASE_URL=http://<ip>:8317 ANTHROPIC_API_KEY=<KEY>`
- 任意 OpenAI 兼容 SDK 同理

## 坑（Pitfalls）
1. **进程 stdin 通常不可用**（Hermes 后台进程）——不要用 process submit 喂回调 URL，直接服务器 curl localhost callback 地址
2. 用户常复制**中间页 URL**（accounts.google.com/signin/oauth/firstparty/nativeapp）——那不是回调，引导其点 Continue/允许后复制 **localhost 开头** 的跳转失败地址
3. OAuth 授权链接仅约 5 分钟有效，用户卡壳就重新跑登录命令
4. AWS 等云主机：安全组不放行 8317 公网不通；实例无 IAM 角色/无 aws cli 凭证时无法自动开端口，让用户在控制台加 入站 TCP 8317
5. 多账号：往 auth-dir 放多个凭证文件即自动轮询负载均衡（同提供商）
