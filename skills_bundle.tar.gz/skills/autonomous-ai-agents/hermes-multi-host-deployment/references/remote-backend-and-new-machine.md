# 换机/双机实录：容量、体积、远端后端（2026-11-07）

用户问：「装到 Mac 上需要多大内存」→「完整复制过去并一直与本机同步能做到吗」。
本次会话只做了只读核查与方案设计，**没有落地执行**；下文方案参数来自官方文档与本机 `--help` 实读，体积/RSS 来自当场实采。

## 1. 本机实测体积（`~/.hermes` 共 5.0G）

```
state.db                 386M
workspace/               2.1G
hermes-agent/  (源码)    1.6G
backups/                 592M
state-snapshots/         155M
lsp/                     111M
bin/                      85M
logs/                     33M
skills/                   32M
public-skills-candidates/ 22M
cron/                     4.0M
public-skills-approved/   4.2M
cache/                    3.8M
config.yaml+memories+private+scripts+platforms  <1.5M
```

真正需要跨机搬的（config + memories + skills + private + scripts + platforms）合计 **37M**。
`find -maxdepth 2 -size +5M` 抓到的几个大头：`state.db` 386M、`bin/uv` 66M、`skills-premerge` tar 25M、`bin/tirith` 23M、`models_dev_cache.json` 6M。

## 2. 内存实采（同一时刻）

`free -m`：total 12934 / used 5947 / available 6986，swap 1535 已满。
`ps -eo rss --sort=-rss` 头部：python 685M、uvicorn 620M、MainThread 402M、python 361M、**hermes 308M**、codex 232M、postgres 106M。

→ 结论：`hermes` 本体只有 ~300M，其余是附加服务。给用户报需求时用本体量级（CLI 300–600MB、桌面版再加 0.8–1.2GB、浏览器再 +0.3–0.5GB），不要报整机 used。

## 3. 文档核查过程（含踩坑）

- 先抓 `/docs/getting-started/installation` → 成功。确认：macOS 只有 Apple Silicon（Intel 不支持）；桌面包内含 agent、Python、依赖与预构建界面，首次启动不构建运行时；源码安装会带 Chromium（Chrome for Testing）与 cua-driver。
- 再抓 `/docs/desktop/` 和 `/docs/desktop/connecting-to-remote-backend` → **均 404**。
- 正确路径：`/docs/user-guide/desktop`（web_search 命中）。教训：Desktop 相关文档在 `user-guide` 下，不要凭 URL 结构猜。
- 该页给出：Desktop 与 CLI/TUI/Dashboard 共享同一 config、API keys、sessions、skills、memory；`Settings → Gateways → Connection mode` 提供 **Remote gateway**（填自建 `hermes serve` 的 URL）与 **Hermes Cloud** 两种非本地后端；Gateways 是 machine-level，可登记本地/远端/Cloud/SSH host 多个。

## 4. `hermes serve --help` 实读要点

```
--port PORT    默认 9119，0 = OS 自动分配
--host HOST    默认 127.0.0.1
--insecure     DEPRECATED / NO-OP。2026-06 加固后不再关闭认证；公网 bind 始终要求 auth provider（password 或 OAuth）。bind 127.0.0.1 + 隧道保持本地
--skip-build   跳过 web UI 构建
--isolated     命名 profile 时起独立服务，而非路由到机器级服务
--stop / --status
--ssh-session-token-file / --ssh-owner-nonce   Desktop SSH 一次性会话令牌
```
定位是「桌面端与远端客户端连接的 JSON-RPC/WebSocket 网关，headless，从不打开浏览器 UI」。

## 5. 本次给出的方案（未执行）

**A（推荐）**：源机 `hermes serve --host 127.0.0.1 --port 9119`，Tailscale 或 SSH 转发，Mac 桌面 App 走 Remote gateway。代价：Mac 断网不可用；收益：整条链路留在源机。

**B**：首迁 37M 六个目录，之后单向 rsync 只推 `skills/`+`memories/`+`config.yaml`，db 类不参与。代价：会话历史不互通、新机技能回不来。

硬拒项：双向文件同步 `~/.hermes`（WAL 锁库损坏）、整包搬 1.6G 源码与平台二进制。

## 6. 下次接手要补的

- 方案 A 尚未真机验证 Tailscale/SSH 隧道 + Desktop Remote gateway 端到端连通。真正执行时需验证：Mac 侧登录成功、会话列表可见、工具调用落回源机、断线重连。
- 若用户选 B，`hermes doctor` 在目标机的输出需核验安装来源与依赖，别只看服务起来。
