---
name: hermes-multi-host-deployment
description: "Hermes 换机/多机：容量估算、远端后端、跨机单向同步边界。"
version: 1.0.0
author: 柠檬
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [hermes, deployment, migration, remote-backend, capacity, sync]
    related_skills: [hermes-agent, hermes-backup, hermes-gateway-ops]
---

# Hermes 换机 / 多机部署

回答「装到另一台电脑要多少内存」「能不能完整复制过去一直同步」「Mac/笔记本当终端怎么连回来」这类问题。
与 `hermes-backup` 的分工：备份恢复的是**同一台机的时间点回滚**；这里说的是**换机、双机共存、跨机同步**。

## When to Use

- 用户问新机（Mac / Windows / 笔记本 / 小主机）装 Hermes 的硬件需求
- 用户说「完整复制过去」「一直与本机同步」「两台机数据互通」
- 用户想在新机上用同一套技能/记忆/会话
- 不适用：本机备份、恢复、prune —— 走 `hermes-backup`

## 一、容量：先算清「客户端」这件事

Hermes 是客户端，模型在云端，本机只有 Python 运行时 + 前端外壳，**无 GPU 需求**。
官方/社区口径：RAM 最低 1GB、推荐 2GB，磁盘 10–20GB SSD（安装包含 Python、Node、Chromium）。

| 装法 | 常驻内存 |
|---|---|
| 纯 CLI | 300–600MB |
| 桌面版（Electron 外壳） | +0.8–1.2GB |
| 开 `browser_exec`（自带 Chromium） | 再 +300–500MB |

回答模板：**8GB 能用、16GB 舒服、24GB+ 只有为了本机跑本地模型才需要**（那时瓶颈是统一内存带宽与模型体积，与 Hermes 无关）。磁盘比内存更容易先吃紧。

**macOS 安装包只支持 Apple Silicon**，Intel Mac 不受支持，只能源码安装。这条必须主动说。

> 别直接把源机 `ps -eo rss` 的数字当需求。本机 RSS 含附加服务（MCP、uvicorn、子进程），远高于一个干净安装。

## 二、动手前先量体积——同步方案取决于这个

```bash
du -sh ~/.hermes
du -sh ~/.hermes/*/ | sort -h
find ~/.hermes -maxdepth 2 -type f -size +5M -printf '%s\t%p\n' | sort -rn | head -15
```

典型分布（本机 5.0G 实测，含大量历史数据）：

| 目录 | 规模 | 是否跨国搬运 |
|---|---|---|
| `state.db` | 数百 MB | ❌ SQLite+WAL，绝不能双向同步 |
| `workspace/` | GB 级 | ❌ |
| `hermes-agent/`（源码） | ~1.6G | ❌ 目标机自己装 |
| `backups/` `state-snapshots/` | 数百 MB | ❌ |
| `lsp/` `bin/` | ~200M | ❌ 平台二进制，拷过去是废的 |
| `skills/` `config.yaml` `memories/` `private/` `scripts/` `platforms/` | **几十 MB** | ✅ 真正要搬的只有这些 |

体积数字必须当场实测，不要复用历史值。

## 三、硬结论：不要做「一直同步」

- `state.db` 是 SQLite WAL 模式，两个进程同时写会锁库/损坏。rsync / Syncthing / Resilio 双向同步正在写入的 db 等于埋雷。
- `sessions.db`、`cron/*.db`、`executions.db` 同理不跨机。
- `bin/`、`lsp/` 是当前平台二进制，跨 OS 无效。
- 用户说「同步」时**不要顺着字面做双向文件同步**，先给下面两个方案让他选。

## 四、方案 A（推荐）：目标机只当显示屏 = 远端后端

数据只有一份，根本不存在同步问题。

```bash
# 源机
hermes serve --host 127.0.0.1 --port 9119     # 默认 9119，无头 JSON-RPC/WebSocket 网关
# 目标机桌面 App：Settings → Gateways → Connection mode → Remote gateway，填隧道地址并登录
```

- `hermes serve` 是桌面端与远端客户端的后端，headless，从不打开浏览器 UI。
- `--insecure` 自 2026-06 加固后**已是 no-op**；公网 bind 强制要求 password/OAuth provider。**不要裸奔公网**，用 Tailscale 或 SSH 端口转发，或 `webapp.public_url` + 反代。
- Gateways 页是 machine-level：可登记多个 gateway（本地 / 远端 / Hermes Cloud / SSH host），一个会话同时只选一个；profile 从连上的 gateway 发现。
- 代价：目标机断网即不可用。
- 收益：会话、技能、记忆、cron、Bot、反代、探针、转存链路全留在跑熟的源机，换的只是 UI。

## 五、方案 B：目标机独立跑（一次性迁移 + 单向同步）

1. 首迁只搬几十 MB：`config.yaml`、`memories/`、`skills/`、`private/`、`scripts/`、`platforms/`。
2. 之后单向 rsync/git 源机 → 目标机，**只推不拉**，范围限 `skills/`、`memories/`、`config.yaml`。
3. `state.db` / `sessions.db` / `cron/*.db` 一律不参与。
4. `private/` 含 token，走 SSH 或加密传输，别丢 iCloud / 网盘 / 公共仓库。
5. 目标机装好后用 `hermes doctor` 验安装来源与依赖。

代价：两边会话历史不互通，目标机的新技能回不来（除非手动合）。

## 六、取舍原则

默认推荐 A。这类用户资产的价值不在文件，而在源机上跑着的整条链路（媒体反代、云盘转存、DDNS、探针、群聊 Bot）。搬到新机要么重搭要么失效，「源机继续跑 + 新机当终端」是唯一不折腾的路线。

方案选择要给明确推荐，不要让用户自己权衡；同时把两个代价（断网不可用 / 历史不互通）都摆出来。

## 坑

1. **顺着「同步」字面做双向同步** —— 直接损坏 state.db，且用户以为已经搞定
2. **把整机 `~/.hermes` 打包搬过去** —— 里面 1.6G 源码 + 几百 MB SQLite + 平台二进制，且新机数据库与源码版本可能不匹配
3. **只报内存不说 Apple Silicon 限制** —— 用户装完才发现 Intel Mac 不支持
4. **公网裸 bind `hermes serve`** —— `--insecure` 已失效，必须走隧道或配认证 provider
5. **拿历史体积数字直接回答** —— 每次重新 `du`，本机数据增长很快
6. **官方文档路径猜错** —— Desktop 文档在 `/docs/user-guide/desktop`，`/docs/desktop/*` 返回 404；先搜索再抓

## 支持文件

- `references/remote-backend-and-new-machine.md` — 2026-11-07 实录：5.0G 体积逐目录拆解、内存分档实测、远端后端方案验证与文档来源（含 404 路径教训）
