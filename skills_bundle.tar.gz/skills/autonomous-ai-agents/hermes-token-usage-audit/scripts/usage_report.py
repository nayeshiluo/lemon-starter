#!/usr/bin/env python3
"""只读 Hermes 用量报表：按 provider / 天 / 会话 / 来源摊开 state.db 的调用记录。

用法:
    python3 usage_report.py                      # 近 3 天全部 provider
    python3 usage_report.py --days 7 --provider 周三
    python3 usage_report.py --days 2 --top 15 --json

只读：不写库、不改配置。sqlite3 CLI 缺失也能跑（纯 stdlib）。
"""
import argparse
import collections
import datetime
import json
import os
import sqlite3
import sys

DEFAULT_DB = os.path.expanduser("~/.hermes/state.db")


def connect(db):
    # 网关在跑，打开写锁时给足等待；本脚本只读
    c = sqlite3.connect(f"file:{db}?mode=ro", uri=True, timeout=15)
    return c


def fetch(c, since, provider):
    where = ["u.last_seen >= ?"]
    args = [since]
    if provider:
        # 必须用 like：同一家会有 '周三' 与 'custom:周三' 两种标签
        where.append("u.billing_provider LIKE ?")
        args.append(f"%{provider}%")
    sql = f"""
        SELECT u.billing_provider, u.model, u.task, u.api_call_count,
               u.input_tokens, u.output_tokens,
               u.cache_read_tokens, u.cache_write_tokens,
               u.estimated_cost_usd, u.actual_cost_usd,
               u.first_seen, u.last_seen,
               s.id, s.source, s.chat_type, s.title, s.message_count
        FROM session_model_usage u
        JOIN sessions s ON s.id = u.session_id
        WHERE {' AND '.join(where)}
    """
    return c.execute(sql, args).fetchall()


def fmt_ts(ts):
    if not ts:
        return "-"
    return datetime.datetime.fromtimestamp(ts).strftime("%m-%d %H:%M")


def build(rows):
    prov = collections.defaultdict(lambda: [0, 0, 0, 0, 0.0])   # calls,in,out,cacheR,cost
    byday = collections.defaultdict(lambda: [0, 0, 0])            # calls,in,out
    sess = collections.defaultdict(lambda: [0, 0, 0, 0, "", "", "", "", 0.0])
    src = collections.defaultdict(lambda: [0, 0])

    for (bprov, model, task, calls, tin, tout, cr, cw, est, act,
         first, last, sid, source, chat_type, title, msgs) in rows:
        cost = (act or 0) or (est or 0)

        a = prov[bprov]
        a[0] += calls; a[1] += tin; a[2] += tout; a[3] += cr; a[4] += cost

        d = datetime.datetime.fromtimestamp(last).strftime("%m-%d")
        b = byday[d]
        b[0] += calls; b[1] += tin; b[2] += tout

        k = (sid, title or "(untitled)", source or "?", chat_type or "-", model or "?")
        s = sess[k]
        s[0] += calls; s[1] += tin; s[2] += tout; s[3] += cr; s[4] = cost
        s[5] = fmt_ts(first); s[6] = fmt_ts(last); s[7] = task or "-"; s[8] = msgs or 0

        r = src[source or "?"]
        r[0] += calls; r[1] += tin

    return prov, byday, sess, src


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--db", default=DEFAULT_DB)
    ap.add_argument("--days", type=float, default=3.0)
    ap.add_argument("--provider", default=None,
                    help="子串匹配 billing_provider，如 周三 / command")
    ap.add_argument("--top", type=int, default=10)
    ap.add_argument("--json", action="store_true")
    a = ap.parse_args()

    since = datetime.datetime.now().timestamp() - a.days * 86400
    c = connect(a.db)
    rows = fetch(c, since, a.provider)
    if not rows:
        print("无匹配记录（检查 --provider 子串或放宽 --days）")
        return 1

    prov, byday, sess, src = build(rows)

    if a.json:
        out = {
            "window_days": a.days,
            "provider_filter": a.provider,
            "totals_by_provider": {
                k: dict(calls=v[0], input=v[1], output=v[2],
                        cache_read=v[3], cost_usd=round(v[4], 6))
                for k, v in sorted(prov.items(), key=lambda x: -x[1][1])
            },
            "by_day": {k: dict(calls=v[0], input=v[1], output=v[2])
                       for k, v in sorted(byday.items())},
            "top_sessions": [
                dict(session_id=k[0], title=k[1], source=k[2], chat_type=k[3],
                     model=k[4], calls=v[0], input=v[1], output=v[2],
                     cache_read=v[3], cost_usd=round(v[4], 6),
                     first_seen=v[5], last_seen=v[6], task=v[7], messages=v[8])
                for k, v in sorted(sess.items(), key=lambda x: -x[1][1])[:a.top]
            ],
        }
        print(json.dumps(out, ensure_ascii=False, indent=2))
        return 0

    print(f"窗口：近 {a.days:g} 天" + (f"｜provider ~ {a.provider}" if a.provider else ""))
    print("\n== 按 provider（billing_provider 原样，注意 custom: 变体）")
    for k, v in sorted(prov.items(), key=lambda x: -x[1][1]):
        print(f"  {k:<22} calls={v[0]:>6} in={v[1]:>10} out={v[2]:>9} cacheR={v[3]:>10} cost=${v[4]:.4f}")

    print("\n== 按天（last_seen 归属）")
    for k in sorted(byday):
        v = byday[k]
        print(f"  {k}  calls={v[0]:>6} in={v[1]:>10} out={v[2]:>9}")

    print(f"\n== Top {a.top} 会话（按 input）")
    for k, v in sorted(sess.items(), key=lambda x: -x[1][1])[:a.top]:
        sid, title, source, chat_type, model = k
        print(f"  {v[0]:>5} calls  in={v[1]:>9} out={v[2]:>8} cacheR={v[3]:>9} "
              f"msgs={v[8]:>5}  {source:<9}{chat_type:<9}{sid:<28} {title[:30]}")
        print(f"        task={v[7]:<12} {v[5]} → {v[6]}")

    print("\n== 按来源")
    for k, v in sorted(src.items(), key=lambda x: -x[1][1]):
        print(f"  {k:<12} calls={v[0]:>6} in={v[1]:>10}")

    tot_calls = sum(v[0] for v in prov.values())
    tot_in = sum(v[1] for v in prov.values())
    if tot_calls:
        print(f"\n单次调用平均输入 {tot_in / tot_calls:,.0f} tokens"
              f"（>9000 提示长会话滚动，不是模型贵）")
    return 0


if __name__ == "__main__":
    sys.exit(main())
