# 用量归因实录：2026-11-06 周三模型 198 次调用

用户诉求：「这两天 周三模型 哪里调用最多，我感觉用的好快」。

## 结论

全部集中在 **11-06 一天**：198 次调用 / 239 万 input / 15.9 万 output / 3399 万 cache_read。
不是某个 Bot 在偷跑，是当天早 8:39 那次「全链路切 Command 主力 + 周三备用」的**并行改造**：
三路 TUI 并行迁移 + 两个千条消息的 cli 老会话还在续用。

## 按天

| 日期 | calls | input | output | cache_read |
|---|---|---|---|---|
| 11-04 | 90 | 489,955 | 108,444 | 3,232,896 |
| 11-05 | 37 | 253,192 | 53,558 | 1,576,640 |
| 11-06 | **198** | **2,394,724** | 158,525 | 33,996,544 |
| 11-07 | 0 | — | — | — |

## Top 会话（按 input）

| session | 来源 | calls | input | 事由 |
|---|---|---|---|---|
| `mvuoexhwzgw3br` | cli | 69 | 1,251,651 | 添加模型站并配置接口地址（10-30 起的老会话，11-06 09:02 续用） |
| `mvu4yb0dnff0t3` | cli | 22 | 353,338 | 分析每日错误日志（同为老长会话，1996 条消息） |
| `22c6e3` / `33ae9a` / `06cac5` | tui ×3 并行 | 99 | 763,609 | 08:39 三路并行模型迁移 |
| `cron_5c7c83ec…` / `cron_f53c86a3…` | cron | 31 | 145,944 | 安全巡检 + HostBrr 监控 |

单次调用平均输入 **9,655 tokens**，input 中 92% 是重复上下文 —— 这是「长会话滚动」的典型指纹，不是模型单价问题。

## 关键口径发现

**`billing_provider` 有前缀变体**，同一家 provider 在库里同时存在多种标签：

```
{'custom': 2684, 'command': 85, 'custom:command': 10,
 '周三': 198, '', 6, 'custom:周三': 37}
```

`周三` 198 次是从 `custom:` 之外算的；如果按 `custom:周三` 那 37 次看，会漏掉主体。
→ 一律 `like '%周三%'`。

库里 198 次（裸 `周三`）+ 37 次（`custom:周三`）= 235，跨 11-04~11-06。
但按 `last_seen >= 11-04` 全量捞，`周三` 家族合计 325 次 —— 说明 `first_seen` 在 10-30 的老会话也贡献了调用，
**按 `first_seen` 切窗口会整段漏掉爆点**，必须用 `last_seen`。

## `hermes sessions archive` 过滤器失效实录

想归档上面两个 cli 老会话，CLI 三种过滤器全部落空：

| 命令 | 结果 |
|---|---|
| `--title "添加模型站并配置接口地址"` | No sessions match |
| `--title "添加模型站"`（缩短子串） | 仍 No sessions match |
| `--source cli --min-messages 1000` | No sessions match |
| `--source cli`（不加限制） | 36 条，但**不含**这两个目标（最新只到 10-31） |
| `--provider 周三` | 只捞到 2 个 cron 会话 |

同时 `hermes sessions list --limit 500` 里这两个会话明明可见。
→ 结论：CLI 的候选池口径（未归档 + 已结束 + 时间窗）与本机这些**未结束、活跃续用**的 cli 会话不匹配。
`--archived` 参数也不存在（`unrecognized arguments`）。

## 实际做法：直改 SQL + 三步体检

```python
import sqlite3
c = sqlite3.connect("/home/ubuntu/.hermes/state.db")
c.execute("pragma busy_timeout=15000")   # 网关在用这个库
for sid in ("mvuoexhwzgw3br", "mvu4yb0dnff0t3"):
    c.execute("update sessions set archived=1 where id=?", (sid,))
c.commit()
```

归档前查过：

1. **血缘**：`set_session_archived()` 会递归归档 `end_reason='compression'` 的祖先/后代，直改 SQL 只动一行。
   实测 `mvuoexhwzgw3br` 有 10 个子会话，`end_reason` 全是 `agent_close`（子代理记录），**不是压缩链** → 只归档根是对的。
   若出现 `end_reason='compression'`，必须改用 CLI 或自己递归，否则 Desktop 里会被未归档的压缩根「复活」。
2. **引用**：`grep -rl "<sid>" ~/.hermes/cron/ /home/ubuntu/*/` 只命中 request_dump，无 cron/脚本按 id 调度。
3. **归档 ≠ 删**：归档后 `select count(*) from messages where session_id=?` 分别为 1732 / 1996，与归档前一致。

验收：`hermes sessions list --limit 60 | grep -E "添加模型站|分析每日错误日志"` → 无输出（已从默认列表消失）。

## 顺带证伪

迁移之后本机各 Bot（群霸双 Bot / LemonOps / userbot / smart-group-bot）的周三**备用**路由当天 0 次调用：
`journalctl -u <unit> --since ... | grep -icE "ikunlvshihan|周三"` 全为 0，`lemon-userbot/model_selection.json` 当前是 beam。
→ 备用模型闲置正是「主力已迁到 Command」的正证，汇报时要主动说出来。
