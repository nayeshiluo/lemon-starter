---
name: hermes-token-usage-audit
description: "查 Hermes 自身模型用量：哪个 provider/会话烧得多、怎么归档老会话。"
version: 1.0.0
author: 柠檬
license: MIT
platforms: [linux, macos]
metadata:
  hermes:
    tags: [hermes, usage, tokens, cost, session-store, sqlite, archiving]
    related_skills: [agent-memory-curation, hermes-ai-chain-alert-triage, hermes-multi-host-deployment]
---

# Hermes 用量归因与会话瘦身

回答「这两天 X 模型哪里调用最多 / 用得好快 / 额度怎么没了」，并处理「归档老会话」。

**不是**查余额（那看 provider 面板），也不是查链路故障（那走 `hermes-ai-chain-alert-triage`）。这里只做**本机归因**：把 `state.db` 里的调用记录按 provider / 会话 / 天摊开，指出钱花在哪。

## When to Use

- 「周三/command/某模型 这两天调用最多是哪」「额度用得好快」
- 「哪些会话最烧」「老会话要不要归档」
- 迁移模型后想核对「新主力实际吃了多少」
- 不适用：只是想知道某个 key 还剩多少额度 → 直接问 provider，本地无数据

## 数据源（唯一真相：本机 state.db）

`~/.hermes/state.db` 两张表就够，**不要**去 grep `agent.log` 数调用（日志有轮转、无 token 字段）：

| 表 | 关键列 |
|---|---|
| `session_model_usage` | `session_id, model, billing_provider, billing_base_url, billing_mode, task, api_call_count, input_tokens, output_tokens, cache_read_tokens, cache_write_tokens, reasoning_tokens, first_seen, last_seen` |
| `sessions` | `id, source(cli/tui/telegram/cron), chat_type, chat_id, title, model, message_count, api_call_count, archived, pinned, end_reason, parent_session_id, last_activity_at` |

主键是 `(session_id, model, billing_provider, billing_base_url, billing_mode, task)` —— **同一会话会拆成多行**（不同 task：空串 / `compression` 等），聚合时按需 group。

跑法：`sqlite3` CLI 里本机常常没装，直接用 `python3 -c` 的 stdlib `sqlite3`。现成脚本见 `scripts/usage_report.py`。

## 口径陷阱（读错就会误报「某个 Bot 在偷跑」）

1. **`billing_provider` 带前缀变体**：同一家会同时出现 `周三`、`custom:周三`、`command`、`custom:command`。原因是走 fallback 配置的那一跳会被标成 `custom:<name>`，直连 provider 段则是裸名。**永远用 `like '%<名字>%'` 过滤**，不要 `= '周三'`。
2. **`input_tokens` 不是「新读的上下文」**：长会话里 90%+ 输入是重复上下文，靠 `cache_read_tokens` 扛（实测一次 319 万 input 配 3880 万 cache_read）。报账时 input / cache_read **分开列**，别把两者相加当成「烧了 4000 万 token」。
3. **按 `last_seen` 切窗口，不是 `first_seen`**：一个 10-30 开的老会话可能 11-06 还在续用。用 `first_seen` 筛会把真正的爆点整段漏掉。
4. **`sessions.input_tokens` 是累计值**，包含会话全部历史；跨天归因必须走 `session_model_usage`。
5. **cron 会话也算**：`cron_<id>_<timestamp>` 是独立 session，别只筛 cli/telegram。
6. **单次调用平均输入 = input/api_call_count**：实测 >9000 就该怀疑长会话滚动，而不是模型贵。

## 排查顺序

1. 取当前日期（`date`），确定「这两天」的具体窗口。
2. `grep -n "name: <模型名>" ~/.hermes/config.yaml` 确认 provider 真实标签（同一 base_url 可能有多个 name）。
3. 跑 `scripts/usage_report.py --days 3 [--provider 周三]`，得到：按天总量、按会话 Top N、按来源分布。
4. **对 Top 会话逐个看来源与标题**（`sessions.title/source/message_count`）：区分「一次并行改造」「长期续用的老会话」「定时任务」。
5. 判断是**一次性事件**（迁移/排障并行开多个会话）还是**结构性成本**（上千条消息的老会话天天续用）。
6. 汇报：结论先行，按输入 token 给表，附「不是某 Bot 偷跑」的证伪（如各 Bot 备用路由当天 0 次）。

## 归档老会话

`hermes sessions archive` 是**软归档**（`archived=1`，消息不删），但它的过滤器常匹配不到目标：

- `--title` 要求**子串且精确到列表里可见**的标题，长标题带标点会「No sessions match」
- `--source cli` 只覆盖旧的一段，最近在用的 cli 会话不在候选池
- `--provider 周三` 实测只捞出 cron 会话

所以**先 dry-run 确认命中，命不中就直改 SQL**：

```python
import sqlite3
c = sqlite3.connect("/home/ubuntu/.hermes/state.db")
c.execute("pragma busy_timeout=15000")          # 网关在跑，必须给超时
c.execute("update sessions set archived=1 where id=?", (sid,))
c.commit()
```

归档前必查三件事：

1. **是不是压缩链的根/枝**：`set_session_archived()` 会连整条 compression 血缘一起归档，直改 SQL **只动一行**。查 `select id,end_reason,parent_session_id from sessions where parent_session_id=?`；子会话 `end_reason='agent_close'` 是**子代理记录，不是压缩链**，不归档是对的。若确有 `end_reason='compression'` 的祖先/后代，改用 CLI 或递归处理。
2. **有没有被 cron / 脚本按 id 引用**：`grep -rl "<session_id>" ~/.hermes/cron/ /home/ubuntu/*/`。
3. **归档 ≠ 删除**：`messages` 行数必须前后一致，汇报时把条数报出来当正证。

验收：`hermes sessions list --limit 60` 里不再出现该标题；`select count(*) from messages where session_id=?` 与归档前一致。

## 汇报格式

结论先行给出「花在哪、几次调用、多少 input」；按天给趋势（哪天是爆点）；Top 会话表带**来源 + 标题 + 调用数 + input**；一句话判因（一次性并行改造 / 老会话滚动 / 定时任务）；最后给最小动作建议（归档哪几个、以后新开会话），不主动加监控。

## 坑

1. **只报总量不报会话** —— 用户问的是「哪里调用最多」，缺了 Top 会话表等于没答。
2. **把当日 0 次当「没问题」** —— 备用模型 0 次是**迁移成功的证据**，要主动说出来，否则用户以为没查。
3. **直接 `=` 匹配 provider** —— 见口径第 1 条，会漏掉 `custom:` 变体（本次 198 次里有 33 次是 `custom:周三`）。
4. **归档完不复验消息条数** —— 软归档出错最怕变成隐性删除，必须报前后一致。
5. **顺手加「用量巡检 cron」** —— 用户明确反过度设计，答「不用加」比加监控对。
6. **中文标题用 `wc -c` 量** —— 无关本技能，但同类：长度一律按字符。

## 支持文件

- `scripts/usage_report.py` — 只读用量报表：`--days N [--provider 名字] [--top N] [--json]`，输出 provider 总量 / 按天 / Top 会话 / 按来源四段，自动用 `like '%名字%'` 兼容 `custom:` 前缀
- `references/usage-audit-2026-11-06.md` — 实测实录：11-06 周三 198 次调用的归因过程（三个并行迁移会话 + 两个千条老会话）、`hermes sessions archive` 三种过滤器失效的具体表现、SQL 归档与验收
