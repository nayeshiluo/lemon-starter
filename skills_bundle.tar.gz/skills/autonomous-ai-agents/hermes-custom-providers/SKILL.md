---
name: hermes-custom-providers
description: "配 OpenAI 兼容端点/中转站，并给自建 bot 分配模型角色。"
version: 1.0.1
author: Hermes Agent
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [hermes, providers, custom-endpoint, openai-compatible, config]
    related_skills: [hermes-agent]
---

# Hermes 自定义 OpenAI 兼容 Provider 配置

## When to Use

用户给出一个 OpenAI 兼容端点的 `base_url`（如 `http://host:port/v1`）+ API key + 模型列表，要求"装上 / 配置 / 测试能不能用"。典型来源：中转站、API 代理、内网推理服务。也适用于在 Hermes 中新增任何 custom provider 端点（含已有 provider 的扩展）。

这类端点一律注册为 `custom_providers` 列表条目。

**也包括：用户自建/试用的第三方 bot 问「我现有这些模型怎么调用合适 / 能加几个模型 / 怎么切换」。**
此时不是给 Hermes 配 provider，而是给那个应用的角色（main/decision/moderation/vision/compress/embed）
选型并分配 fallback —— 直接跳到下面「为外部应用分配模型角色」一节，别从标准流程第 1 步重新走。
（2026-11 实测教训：本技能的 description 原先只写「为 Hermes 添加端点」，导致这类任务根本没想到加载它，
于是重犯了「用行为探针断言 system 被剥离」这个已记录的错。）

## 全量复测与清单更新验收

- “重新测一遍”是独立复验：重新取目录，保存逐模型结构化结果（HTTP、耗时、正文、reasoning 长度、错误类型），以代码核对目录集合、已测集合和成功集合。未实际测过的别名/日期版本不能列入“已验证”。
- 最小 chat 默认给足输出预算（例如 `max_tokens=512`）。20–32 token 可能全被推理耗尽；HTTP 200 且只有 reasoning 时提高预算再测，不能直接判不兼容。此前限额不能替代本轮结果，也不能把一次成功保证为长期稳定。
- 凭据在本地 Python 进程内读取，直接用 HTTP 客户端发送；不要拼进 shell/curl 参数。受限线程池逐项落盘，报告前检查去重与计数。并发数依账号池容量选定，失败项按下文纪律复测。
- 用户说“模型加进去”，只修改目标 provider 的 `models`，先备份、原子写并回读；比较完整解析对象，断言除预期字段外其他 provider、全局默认、fallback 都未变化。YAML 序列可能缩进或无缩进，不依赖固定空格数定位块；优先保留格式的结构化编辑。
- 接口文本探测、真实 Hermes 调用、离线选择器和在线菜单分别验收；没测到的层不宣称完成。收尾只报数量、检查结果及默认/备用链是否未动，不重复长篇交付说明。

## Provider 实测与坑位速查

- 接入前至少：`/v1/models` 可用性 + 带 key 的最小 chat 实测；不要只看 `/models`。按实测筛 `models`，默认模型选真实返回可见正文的。
- **reasoning-only 陷阱**：部分中转/模型会返回 `message.content=null` 但有 `reasoning`/`reasoning_content`；Hermes/终端可能表现为空回复。不要设为默认，除非端到端确认可见输出。
- 并行探测模型时，用 `subprocess.run([...])` 直传参数，避免 shell 引号/重定向拼接导致假失败。
- 具体中转站实测记录见 `references/lg-leguanai-relay-notes.md`（LG/leguanai 示例）及同目录其他 provider notes。

## SSH 密钥录入：先核对执行账号

- 不要只让用户找抽象的“安全凭据入口”。用户选择 SSH 录入时，给出可直接执行的 `getpass.getpass()` 隐藏输入方式：专用凭据文件，目录 `0700`、文件 `0600`，密钥不放命令参数、聊天或截图。
- `Path.home()` 是 **SSH 执行账号**的家目录，不一定是 Hermes 服务账号。给录入命令前说明目标机器和账号；用户说已保存后，先按实际登录账号定向检查。服务账号目录找不到时，不要马上让用户重录或断言失败；根据已知提示符核对对应目录，必要时使用已授权的 `sudo -n`。只报告存在、非空与权限，绝不打印内容。已验证：root SSH 录入的文件不会落在 ubuntu 的家目录。
- SSH 加密录入不等于上游传输加密。用户给 HTTP 地址时，可先本机保存和核验；携带密钥请求前说明明文风险并确认接受。“已保存”仅说明录入完成，不自动表示接受 HTTP。风险已明确接受后不重复询问，也不擅改用户地址或强迫另找 HTTPS。
- 凭据文件存在不等于接入完成；后续仍需配置备份、模型实测和真实 Hermes 链路验收。核对发现自己查错账号时，直接承认并继续，不做全盘目录扫描。
- 要换新密钥又不许它进聊天时，装一个**只暂存、不改 live** 的隐藏输入命令，而不是让用户贴进对话：配方、身份核验表、测试矩阵见 `references/credential-rotation-staging-and-pruning.md`，起点代码 `templates/credential_stage.py`。
- ⚠️ **只验「Key 有效」不够，必须验「是不是目标那一个」**：多个机器人/多条线路都有效时，贴错位置同样能通过有效性检查。Bot Token 要同时比对 `getMe` 用户名与同一 bot id 前缀；模型 Key 要在 `/models` 之外再跑一次带 nonce 的真实推理。
- ⚠️ **改完 key 要分清「哪些消费方热生效、哪个必须重启」**，别一律重启也别一律不重启：
  ① 自建 bot 若 `key_env` 是**每次调用实时读文件**（群霸 `services/ai_service.py:_read_env_val()`、
  lemon-ops `main.py:_resolve_pool_key()`）→ 改完 `.env` 即刻生效，**不用重启**；
  ② Hermes 自己把 `.env` 在**启动时**灌进进程内存 → `hermes-gateway` 必须重启。
  判定 `key_env` 是不是热读，去读该服务源码里 `key_env` 的解析函数，**不要用 `/proc/<pid>/environ` 判断**——
  dotenv 注入的变量不进 exec 环境，那里查不到属正常，据此判「没生效」必错。另 `pgrep -f 'hermes_cli.main gateway run'`
  会匹配到你自己那条 shell 命令行造成假阳性，用 `systemctl show -p MainPID` 取进程。
- 换完 key 的最短全链验收（Hermes 层，比 curl 多验一层 provider 解析 + key_env 取值）：
  ```bash
  ~/.hermes/hermes-agent/venv/bin/python -m hermes_cli.main \
    -z '只回复两个字：收到' -m '<provider 下的模型名>' --provider '<provider 名>' -t ''
  ```
  `-t ''` 关掉工具集避免触发副作用。输出正文（本次 `收到`，约 6s）才算整条链路通。

### 让用户自己粘贴密钥时：路径写死 + 事后验证（2026-11-10 实测踩坑）

- **复制粘贴块里禁止写 `~/.hermes/.env`，一律写死 `/home/ubuntu/.hermes/.env`**。本次用户把命令贴进 **root** shell：
  `/root/.hermes` 只有骨架（`cron/ sessions/ skills/ ...`）**没有 `.env`**，块首的 `cp -a ~/.hermes/.env ...` 直接失败，
  后续 python 抛 `FileNotFoundError`，密钥一个字节都没落盘，而用户回「我应该成功了」。正确写法四要素：
  ① 备份不放首行或用 `cp -a ... 2>/dev/null || true`，不让它中断整段；
  ② python 里 `t = p.read_text() if p.exists() else ""`，缺文件就新建；
  ③ 结尾 `chown <服务账号>:<组>` + `chmod 600`，root 跑也安全；
  ④ 让脚本自己打印 `写入完成 len=<n> 前缀 sk-***`，**这是唯一成功凭据**，让用户只回这一行（长度+前缀，不贴全文）。
- **「用户说已保存」≠ 文件改了，必须分开取证**：`stat -c '%y %s' /home/ubuntu/.hermes/.env` mtime 没变就是没写
  （本次仍是 Nov 8 11:33，一眼定案）；再 `sudo -n tail -25 /root/.bash_history` 看他实际在哪个账号、贴了什么 —— 
  能直接看到块首那条 `cp` 的意图，比猜快得多。查到是自己给错路径就直说，别让用户重录两遍。
- **顺手验现有 key，别假设「只是换了 URL」**：拿 `.env` 里现有 key 同时打**新老两个端点**，本次两边都回
  `401 {"type":"new_api_error"}` —— 说明该 provider 早就死了。汇报时把「端点变更」与「凭据失效」分开写，
  否则用户会以为只改 base_url 就能用。
- **密钥可能含正则/替换特殊字符**：`re.sub` 用 **lambda** 做替换（`lambda m: "IKUN_API_KEY="+k`），
  不要用替换字符串（`\` 与 `&` 会被解释器吃掉）；python 段用**单引号** `python3 -c '...'` + 环境变量传值，
  不要在双引号里写 `\$`（粘贴/多层转义后极易失真）。完整可粘贴配方见
  `references/secret-env-write-handoff.md`。

## 接入交付补充纪律

- **并行改多个服务时，边做边报，不要等全部跑通才汇报。** 2026-11 实测：一口气改 9 个服务的模型链，
  全程不汇报，用户中途问「发生了什么 / 为什么不汇报结果」，之后又问「都搞定了吗」。
  正确节奏：每完成一个服务就落一句结论（服务名 + 真调用结果），长任务先给一句可见的处理说明。
  「等全部做完再一次性汇报」在用户视角等于失联。
- **报「已完成」的唯一依据是真业务函数调用，不是「服务 active + 配置 grep 到新值 + 菜单正常」。**
  本次同一轮里，LemonOps 与 lemon-userbot 的配置、systemd 状态、命令菜单**全部正常**，
  但真实调用抛 `RuntimeError: fleet endpoint pool unavailable`，整条 `/ai` 是断的。
  直到用户说「复验一遍」才暴露。每个服务至少跑一次它自己的入口函数：
  `call_llm_api()` / `call_gemini_llm()` / `ask_ai()` / `AIClient.review()`，看返回值不看日志有无 error。
- **用户说「复验一遍」时，当作独立审计而不是复述上一轮结论**：重新跑真调用、重新抓日志、
  按服务列表逐项打勾；抓到问题直接承认「上一轮汇报时漏了什么」，不要含糊过去。
- 用户明确要求接入某个宿主时，不得擅自交付直连模型替代品。接口连通、宿主会话执行和功能效果分开验收；拒绝或限制的部分应提前说明，不在用户等待后才揭示替代实现。
- 批量探测前先校准单个请求，并读取脱敏失败正文。HTTP 403 + `error code: 1010` 是 WAF 信号，不等于套餐无权；在允许的兼容场景用固定 User-Agent 复测一次，确认成功才开始批量。明确套餐/账号权限拒绝不反复请求。
- 配置中的模型白名单不等于选择器只显示这些模型。注册后比较配置模型数、实际选择器模型数及具体项目；上游发现或缓存可能合并目录。未经验证的 `discover_models` 等开关不能宣称有效，未解决的界面问题明确报未完成，不编造修法。
- Command Code 接入的协议划分、已验证 WAF 修复及菜单验收边界见 `references/commandcode-provider.md`。
  **它的能力边界与全量实测矩阵见 `references/command-provider-models.md`**（别重复探测）：
  95 模型里 57 可用；**没有 TTS/ASR** —— `/audio/speech` 与 `/audio/transcriptions` 均 404，
  `Qwen/Qwen3.8-Omni-Flash` 名字带 Omni 但只出文本、`input_audio` 直接 400；
  **没有 embedding**（`/embeddings` 404）；UA 白名单（Python urllib 403 `error code: 1010`，axios/curl 200）。
  用户问「新模型库有没有能用的语音模型」时直接给这个结论，别只按模型名猜。

## 标准流程

1. **探测端点**（先于一切配置）：
   ```bash
   curl -s -m 15 -o /dev/null -w "HTTP %{http_code} 耗时 %{time_total}s\n" "$BASE/v1/models" -H "Authorization: Bearer $KEY"
   ```
   ⚠️ 安全扫描会把 `curl ... | python3 -c` 判为 HIGH「Pipe to interpreter」，虽 smart approval 会放行，但批量探测优先写成 .py 文件执行，避免每条命令都被拦一道。
2. **拉取服务端真实模型列表**（`GET /v1/models`）。**用户给的模型名 ≠ 服务端有的**：本次用户列了 6 个，服务端实际只支持 4 个，另外 2 个返回 `model_not_found`。
3. **逐个实测模型**（chat completions，不要只看列表）：
   ```bash
   curl -s -m 60 "$BASE/v1/chat/completions" -H "Authorization: Bearer $KEY" -H "Content-Type: application/json" \
     -d '{"model":"<m>","messages":[{"role":"user","content":"回复两个字：能用"}],"max_tokens":20}'
   ```
   - 返回 `choices` → 可用
   - `error.type == "model_not_found"` → 该模型名不支持，不注册，向用户如实报告
   - `error.type == "upstream_error"` → **暂时性故障，重试一次再判定**（本次 gemini-3.1-pro-preview 首测失败、重试成功）
4. **写 key 到 `~/.hermes/.env`**：`<NAME>_API_KEY=sk-...`（如 `FRP3_API_KEY=...`），不写进 config.yaml。
5. **追加 provider 到 `custom_providers`** —— ⚠️ 不能用 `hermes config set`（见 Pitfalls），用 `references/append-custom-provider.md` 里的 Python 脚本。
6. **用 Hermes 真实链路验证**（比 curl 多验证 provider 解析）：
   ```bash
   hermes chat -q "直接回复：能用" --provider "Frp3.ccszxc.xin" -m "deepseek-v4-flash"
   ```
   每个可用模型各跑一次。输出含回复框即通过。
   - 用户自定义的 provider 名可以是**单个汉字/中文短名**（如 `帝`），`--provider 帝 -m glm-5.3-flash` 实测解析正常，
     不必为了「怕解析出问题」改成英文名；只要避开内置 provider 名（见 Pitfalls）即可。
7. 改配置前先备份：`cp ~/.hermes/config.yaml ~/.hermes/config.yaml.bak-$(date +%Y%m%d%H%M%S)`；改完跑 `hermes config check`。
8. **离线验证「菜单落点」**（新 provider 是否真进了 `/model` 切换界面与 ☰ 命令菜单）——跑
   `scripts/verify_provider_registration.py <provider子串>`，见下节。

### 注册后离线验证「菜单落点」（不要靠用户去客户端翻菜单确认）

用户说「菜单和切换模型的界面都加上」时，两处落点由**同一份 provider+models 数据**驱动，离线就能验完：

```bash
~/.hermes/hermes-agent/venv/bin/python3 <skill>/scripts/verify_provider_registration.py 反重力
# 期望：① /model 选择界面里出现「反重力 (N 个模型)」并逐条列出模型名
#       ② ☰ 命令菜单注册条数 + 含 /model: True
```

- **导入路径坑（实测踩到）**：`list_picker_providers` 定义在 `hermes_cli.model_switch`，**不在** `hermes_cli.providers`
  （导错模块直接 `ImportError: cannot import name 'list_picker_providers'`）。gateway 里那段是函数内 import，
  grep 到的行所在模块 ≠ 定义模块，别照抄。
- ☰ 命令菜单**只能放命令，放不了模型**（Telegram BotCommand 限制）。模型一律经 `/model` 进入，`/model` 已靠
  `platforms.telegram.extra.command_menu.priority`（prepend）置顶。用户要「一键直达」时只能加**无参插件命令**
  （如 `/g38`，带参命令会被菜单生成器跳过）；如实说明「菜单里放不了模型」，别假装修好了。
- 群聊菜单是 **adapter.py 里硬编码的 6 条**（`help/model/stop/summary/clear/whoami`），不接受配置注入——
  用户要求给「群菜单」加条目时先说明这点，别去改 command_menu 配置空转。
- 菜单改完不必重启 gateway：Telegram 端在 post-connect 任务里调 `setMyCommands`，下次连接自动刷新。

### 全站换厂迁移：三个必踩的坑（2026-11 实测）

把多个自建服务从旧厂家切到新厂家时，除本 skill 上述流程外，这三项一定会遇到：

### 0. 换「站」（同一 provider 换 base_url）比换模型危险：源码里有硬编码域名门控 ⚠️

用户说「周三的 url 和 key 和模型我都换一下 / 所有之前用 X 的都替换掉」时走这条，**别只改 config.yaml**。
本次实测 12 类落点，其中三类会**静默**炸掉：

1. `config.yaml` 里 base_url 有**两份独立副本**（`custom_providers[名]` + `fallback_providers[]` 同名条目），
   加上各 bot 的 `ai_endpoints.json`（带 `/chat/completions` 后缀），`grep -n "<旧域名>"` 应命中 2 次以上。
2. **本地补丁按 hostname 硬编码判断**：`agent/chat_completion_helpers.py`（摘要旁路）与
   `agent/transports/chat_completions.py`（主循环）里 `urlsplit(base_url).hostname == "<旧域名>"` 决定要不要剥
   `tool` 消息的 `name`。换域名后补丁不匹配 → 每个带 tool 的请求 400，而配置、菜单、`config check` 全都正常。
   改法：`in ("<旧域名>", "<新域名>")`，**保留旧域名**以便回滚。
3. 两份记录型 patch（`~/.hermes/patches/production-*/production.patch`、
   `~/hermes-jobs/backup/hermes-patch/summary-strip-tool-name.patch`）的 `+` 行 + 两份
   `patch-guard.json`（线上 + ops-private 模板）的 `markers["域名门控"]` 与 `gates[].domain` 必须同步，
   否则 `patch_guard --check` 报 `behavior_failed: 安装源码与已验收本地差异不再匹配` / `patch_lost`。

完整 12 类落点清单、`git apply --reverse --check` 判据、"哪份该改哪份该留作历史"的边界、
验收七阶梯与两个瞬时坑（GLM reasoning 吃光 max_tokens、上游 `sqlite3: database is locked` 403 需重试）
见 `references/provider-endpoint-migration-fanout.md`。

#### 0.1 用户说「换 url + 换 key，所有用到这家的都换掉」→ 先只读盘点，别照着话去改 ⚠️

2026-11-14 实测：用户要求把「周三」的 url 改成 `https://token.thxnk.cc/v1` 并换 key，全站同步。
实际盘完发现 **URL 上一轮迁移就已经全换好了**，真缺口只有 key 还是旧的（新站 `/v1/models` 回 `Invalid token`）。

- **第一步永远是只读盘点 + 现状判定**，把「哪些已经达标 / 哪些确实还是旧的」先回报；照字面改 url 只会产出无意义 diff，还掩盖真问题。
- 每个引用点先分清**活配置**与**历史产物**：`artex/data/tasks/**` 的 xboard 前端产物、`backups/`、`*.bak-*`、
  `.codex/shell_snapshots/`、`~/.hermes/cache/` 都要排除，否则 50+ 条假命中把真落点淹掉。同名域名同样会骗人
  （vps-la 上 `thxnk` 命中是 Emby 直连规则 `DOMAIN-SUFFIX,thxnk.cc` 与 Telegram 缓存文本，与 provider 无关）；
  `周三` 会命中 dayjs 的 `zh-cn` locale。
- **key 通常只需改一处**：所有消费方（Hermes 两份 base_url 副本 + bot `ai_endpoints.json` + 种子脚本）都走
  `key_env: IKUN_API_KEY`，改 `~/.hermes/.env` 即全场生效 —— 汇报时把「为什么一处够」讲清。
- 探测时**不要 `set -a; . ~/.hermes/.env` 再 curl**：整份 `.env` 灌进 shell 会带入代理等变量，本次两条 curl 全变
  `000` 白等 70 秒；只 `grep -m1 '^<KEY_ENV>='` 取出目标那一个 key。`/v1/models` 与 `/chat/completions` 的鉴权结论
  可能不一致（本次旧 key：models 401 `Invalid token`，chat 仍出正文且返回的 `model` 与请求不符），**两个都打、分开报**。
- 缺新 key 时只问一次，**不要先改 url、不要猜 key**。完整落点表、盘点命令与汇报模板见
  `references/provider-url-key-rotation-audit.md`。

⚠️ **改完别一句「都换好了」收尾**：`/model` 菜单与 Bot 端点池**热生效不用重启**，但源码里的域名门控
（第 2 条）**必须重启 gateway 才进内存**。用户说「先不重启」时，要把这层差别讲清楚——否则 Telegram 侧
带工具结果的请求仍会 400，而菜单看起来完全正常。各层生效时机表见该参考文件 §8。

### 1. reasoning 模型 `max_tokens` 太小 → 200 但正文为空 ⚠️

`reflection/beam:free`、`stealth/glyph-cluster` 这类 reasoning 模型，**思维链和正文共用同一个 token 池**：

```
max_tokens=20  → content=""  finish_reason=length  reasoning_len=33
max_tokens=64  → content="MAIN_OK"  finish_reason=stop
```

看到「HTTP 200 但 choices[0].message.content 为空」先查 `max_tokens`，**不要当成链路故障去排查端点**。安全下限 64，实际服务建议 ≥256。

迁移时逐个核对各服务的 token 预算：群霸 `main` 2048 / `decision` 512 / `compress` 1024、AdKiller 700、LemonOps 2500、TeleBox `persona` 512 / `music` 200，都在安全区。

### 2. 共享端点池改用 `key_env` 后，消费方没跟着改 ⚠️

凭据从 JSON 明文 `key` 改成 `key_env` 引用（指向 `~/.hermes/.env`）后，**每个读这个池的服务都要自己解析 `key_env`**，否则表现为整体不可用：

```
RuntimeError: fleet endpoint pool unavailable
```

已踩过两次：`lemon-userbot/userbot.py:_load_fleet_endpoints()`、`lemon-ops-bot/main.py:_load_fleet_endpoints()`。标准补法：

```python
def _resolve_pool_key(node):
    key = str(node.get("key") or "").strip()
    if key:
        return key
    env_name = str(node.get("key_env") or "").strip()
    if not env_name:
        return ""
    val = os.environ.get(env_name, "").strip()
    if val:
        return val
    for path in ("/home/ubuntu/.hermes/.env", "<服务目录>/.env"):
        # 逐行匹配 NAME= 后 strip 引号
        ...
```

群霸自己的 `services/ai_service.py:_read_env_val()` 本来就支持，所以它不报错——**只有独立实现的服务才会挂**，这就是最容易漏的地方。

### 3. 网关式桥接要按「插件真实请求格式」验，不能只看日志

多插件服务（如 TeleBox）各插件协议不同：`agent`/`uai`/`persona`/`xmsl`/`ai`/`sum` 走 OpenAI `/chat/completions`，`music` 走 Gemini 原生 `/v1beta/models/{m}:generateContent`。搭本地桥统一转发时：

- 桥必须同时兼容两种协议，Gemini 请求要做 `contents/parts` ↔ `messages` 互转
- 非对话端点（`/images/generations`、`generateContent` 要图片输出）**原样透传**给原上游，否则图片生成能力会被桥废掉
- 透传时上游 `HTTPError` 要按原状态码回传，别一律压成 502（否则 429 额度冷却会被误读成桥故障）
- 验收必须**逐个插件打真实请求路径**；`journalctl` 里路由计数为 0 只说明没人触发，不说明桥坏

### 4. 清理旧 provider 前先查引用

删 `custom_providers` 条目 / 端点池节点前，先枚举所有引用点：`model`、`fallback_providers`、`auxiliary.*`、各服务独立配置。带 `disabled_nodes` 的池还要同步清理指向已删 id 的残留（多数实现不校验，但会留脏数据）。

**顺带**：换厂后同厂多模型备份比跨厂单备更实用。梯队建议 `主力 free 模型 → 同厂第二个 free 模型 → 跨厂备用`，第一跳防单模型限流，第二跳防整厂故障。

## 接入本地/远端 ollama（含面板反向代理场景）

当 ollama 跑在远端机器（如 InstaBox 沙箱），通过 HTTP 面板鉴权后透传 `/v1/*` 时，有五个专属坑。

> ⚠️ **先问清用户要哪种用法**：用户说「我想让 hermes 用，或者其他人用」时，**主线是接进 Hermes 当 provider**，分享给别人是次要的。
> 2026-10-23 实测：把重点放在多令牌 / 三级权限 / 审计日志上做了一整轮，用户回「**不是 我想调用它的模型和算力**」——主线没做等于白干。
> 顺序：先注册 provider + `hermes chat` 实测跑通，再谈分权限给人用。

### 1. Hermes 发 `thinking` 字段 → ollama 400 → 静默 fallback ⚠️

Hermes 可能在请求体里追加 `thinking`/`reasoning_effort`/`extra_body` 字段（取决于全局 reasoning 配置）。ollama **不识别这些字段**，返回：

```
HTTP 400: "qwen2.5:3b" does not support thinking
```

Hermes 捕获 BadRequestError 后触发 fallback，**表现为调用被静默切到其他 provider**，看不到报错。  
**调试方法**：看 `~/.hermes/logs/errors.log`，搜 `API call failed`，找 `summary=HTTP 400: ... does not support thinking`。

**解法**：在代理/面板层透传前剥离这些字段：

```python
for key in ("thinking", "reasoning_effort", "extra_body"):
    body_dict.pop(key, None)
```

只需在 `/v1/chat/completions` 和 `/v1/completions` 路径上做，`/v1/models` 等查询接口不需要。

### 2. `models` 必须是字符串列表，不能是字典列表

写成 `[{'name': 'qwen2.5:3b'}]` 后 hermes `/model` 菜单里不出现该模型，也无法用 `--provider` 指定。  
必须是 `['qwen2.5:3b', 'qwen3:1.7b']`。追加 provider 后 `yaml.safe_load` 回读验证 `models` 字段类型。

### 3. config.yaml 字符串行替换极易损坏文件，必须用 yaml.dump 原子写

手动字符串替换 `custom_providers:` 块会导致 `yaml.parser.ParserError: expected <block end> but found '-'`（2026-10-23 实测）。  
**正确写法**：`yaml.safe_load → 修改 dict → yaml.dump → os.replace 原子写`。

恢复路径（做了备份的情况下）：

```bash
LATEST=$(ls -t ~/.hermes/config.yaml.bak-* | head -1)
cp "$LATEST" ~/.hermes/config.yaml
python3 -c "import yaml; yaml.safe_load(open('/home/ubuntu/.hermes/config.yaml')); print('OK')"
```

### 4. 远端面板/隧道代理有首字节超时，长 prompt 流式必现 502 ⚠️

**现象**：短 prompt 一切正常；长 prompt（Hermes 的 system prompt ~2050 tokens）流式请求 **21 秒必现**
`HTTP 502: The sandbox service disconnected or is unavailable`。这个 502 是**平台端口代理**返回的，不是你的面板代码抛的。

**根因**：ollama 要等 prefill 完成才发响应头。prefill 期间面板一个字节都没往客户端写，远端代理判定连接空闲就掐断。

**修法**：面板必须**先回响应头再打上游** —— 后台线程 `urlopen`，主线程每 3 秒发 SSE comment 心跳。

```python
q = queue.Queue()

def worker():
    try:
        rq = urllib.request.Request(OLLAMA + p, data=body, method="POST")
        rq.add_header("Content-Type", "application/json")
        with urllib.request.urlopen(rq, timeout=900) as r:
            for line in r:
                q.put(("d", line))
        q.put(("e", None))
    except urllib.error.HTTPError as ex:
        q.put(("x", (ex.code, ex.read())))
    except Exception as ex:
        q.put(("x", (502, str(ex).encode())))

threading.Thread(target=worker, daemon=True).start()
# 立刻发头 → 循环 q.get(timeout=3)，超时就写 b": ping\n\n"
```

修完首字节 0.8–1.0s，4800 字符 system prompt 2.9s 完成。

### 5. `BaseHTTPRequestHandler` 默认 HTTP/1.0，流式会挂死

**现象**：加了心跳后 502 消失，但客户端读 **200 秒超时、一个字节都收不到**。

**根因**：`BaseHTTPRequestHandler.protocol_version` 默认 `"HTTP/1.0"`，没有 chunked 编码。不设 `Content-Length` 时客户端只能靠连接关闭判断结束，而流式连接一直开着 → 永久等待。

**修法**：两处都要改。

```python
class H(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"          # 必须

# 流式响应头
self.send_header("Transfer-Encoding", "chunked")

# 写入时手动编码
self.wfile.write(f"{len(data):X}\r\n".encode() + data + b"\r\n")
self.wfile.flush()
# 结束写 b"0\r\n\r\n"
```

⚠️ 改成 HTTP/1.1 后**所有**响应都必须有正确的 `Content-Length` 或 chunked，否则客户端挂住。普通 JSON 响应走 `_send()` 已有 Content-Length，204 不需要。

### 验证全链路（不要只信 curl 通）

```bash
# 1. curl 直接打代理接口，确认 200
TOKEN=$(cat ~/.ib/panel_token)
curl -s -m 30 "https://<面板URL>/v1/chat/completions" \
  -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" \
  -d '{"model":"qwen2.5:3b","messages":[{"role":"user","content":"能用吗"}],"stream":false}' | head -c 200

# 2. hermes chat 全链路验证（确认无 "Switched to fallback" 字样）
cd /tmp && hermes chat -q "直接回复：能用" --provider InstaBox -m qwen2.5:3b 2>&1 | \
  grep -Ev "^Resume|^  hermes|^Session:|^Title:|^Duration:|^Messages:"
```

## 本地 loopback 网关接入（CLIProxyAPI / 自建中转）的三个专属要点

1. **密钥走 `key_env`**：provider 条目写 `key_env: <NAME>_API_KEY`（值进 `~/.hermes/.env`），同时把主 model 块的
   `base_url`/`api_key` 清空，否则旧主模型的残留端点会覆盖新 provider。
2. **同网关换模型当第一兜底（但必须是不同上游账号池）**：本地网关下挂多模型时，`fallback_providers` 第一条用**同一 base_url 的另一个模型**
   （如 gemini 主用 + 同网关 claude 兜底）。Gemini 上游对多轮函数调用角色交替校验严苛（400），同网关 Claude 立即
   接管且**不增加故障域**；网关整体挂掉才落到链尾的外部 provider。
   ⚠️ **「同网关」≠「同故障域」——同账号池的模型会一起死**。2026-10-20 实测反重力（`127.0.0.1:8317`）16 个模型：
   9 个 gpt 系（`gpt-5.6-luna/terra/sol`、`gpt-6-luna/sol/astra/6.1-sol`、`codex-auto-review`）**同时**报
   `HTTP 429 {"code":"model_cooldown","last_upstream_error":"usage_limit_reached: The usage limit has been reached"}`，
   因为它们共用同一个 **codex 账号池**配额；而同网关的 `gemini-*` / `claude-*` / `gpt-oss-120b-medium` 全部 200 存活。
   → **兜底必须选不同上游通道的模型**（gemini/claude ↔ gpt-codex 互为兜底才有效）；用 `gpt-6-luna` 给 `gpt-5.6-*` 兜底、
   或用同池另一个 gpt 模型兜底，配额耗尽时会一起失效，等于没有兜底。审计时先按「上游账号池」给模型分组，再挑跨组兜底。
3. **网关侧反证**：`sudo journalctl -u cliproxyapi --since "5 min ago" --no-pager | grep POST`
   要看到 `200 ... POST "/v1/chat/completions"`，才能确认流量真走网关而**不是静默 fallback 到别人**。
   （同段日志里的 `404 GET /props`、`404 GET /version` 是客户端能力探测噪音，正常。）
   完整实录、11 模型实测数据与三层验证法见 `references/antigravity-gateway-provider-setup.md`。

## 切换全局默认模型 + 配置 fallback 链（非交互）

用户要求"把主模型换成 X / 备用模型设成 Y"时（或 /model 切换后回 `--global`），全套非交互改法：

### 1. 切全局默认模型

```bash
hermes config set model.default <model>
hermes config set model.provider custom
hermes config set model.base_url <endpoint>/v1
hermes config set model.api_key "$(grep -E '^<KEY_ENV>=' ~/.hermes/.env | head -1 | cut -d= -f2- | tr -d '"' | tr -d "'")"
```

- `model.api_key` 直接写明文进 config.yaml（与 custom_providers 用 key_env 引 .env 不同，主 model 块只认 api_key 字段）。
- **调节全局默认思维强度（Reasoning Effort）**：
  切换主模型时，如需同步固化全局思考强度，使用：
  ```bash
  hermes config set agent.reasoning_effort <none|minimal|low|medium|high|xhigh|max|ultra>
  ```
  CLI 会自动持久化到 `config.yaml` 的 `agent.reasoning_effort` 键下（运行时对话中也可直接通过 `/reasoning <level> --global` 固化，或直接通过 `/reasoning` 呼出交互式按钮面板点选）。

  ⚠️ **致命认知：`reasoning_effort` 对绝大多数 custom provider（中转站）是空操作，改了不等于生效。**
  `run_agent.py::_supports_reasoning_extra_body()` 是**白名单制** —— 只有 `nousresearch.com` / `ai-gateway.vercel.sh` / `models.github.ai` / `githubcopilot.com` / `ollama.com` / lmstudio provider / **base_url 含 `openrouter`** 才会把 reasoning 打进请求体；其余一律 `return False`，`extra_body.reasoning` 整段不生成。
  而 `resolve_reasoning_config()` 与这个 gate **完全解耦**，照样返回 `{'enabled': True, 'effort': 'max'}` —— 配置文件、`/reasoning` 面板、`hermes config get` 三处全显示 max，**唯独线上请求没这个字段**。光读配置发现不了。
  **唯一可信判定：发一次最小请求读 `usage.completion_tokens_details.reasoning_tokens`**，>0 才是真思考。2026-09-04 实测 justwoker `reasoning_tokens=0`（顶层 `reasoning_effort` / `thinking` 字段还会直接 403），本地 CPA gemini-proxy `reasoning_tokens=80` ✅。
  用户要求「开到最高思维」时，先查会话实际绑定的 provider，走中转站就**如实告知档位不可控**并建议切白名单端点 —— 绝不要改完配置就报「已开到最大」。完整机理、取证代码与实测矩阵见 `references/reasoning-effort-not-delivered-to-relays.md`。
- **从旧 provider 切到已注册的 custom provider 时必须清掉残留的 `model.base_url` / `model.api_key`**：只改 `model.default` + `model.provider` 不够——旧主模型（如 gemini-proxy 的 `http://localhost:8317/v1` + 旧 key）的 base_url/api_key 字段会**残留覆盖**新 provider 的端点，文档视角看似已切换、实际还在打旧地址或旧 key。清法：
  ```bash
  hermes config set model.base_url ""
  hermes config set model.api_key ""
  ```
  清空后主模型走 custom_providers 条目自身的 base_url + key_env（如呆布 → TAGAA_API_KEY）。改完 `hermes config get model` 应显示 `provider: 呆布` 且 base_url/api_key 为空，再用 `hermes chat -q` 实测。
- **「全局默认」≠「所有会话」——channel_overrides 不跟随全局切换**：`model.default` 只对无覆盖的会话生效；`telegram.channel_overrides` 里绑定的群/私聊（如 `<PRIVATE_IDENTIFIER>`）仍走自己的覆盖值。用户问"重置后为什么不是模型 X"多半卡在这一层；用户说「全盘覆盖 / 所有地方都用 X」时必须同步三处：① `model.default` + `model.provider`；② 各 `channel_overrides` 条目的 `model`；③ custom provider 条目自身的 `model` 字段。`models` 可用清单里的旧版本条目（如 gemini-3.7）**保留不动**——那是 `/model` 手动切换的候选，不影响默认值。改完 `grep -n '<model-name>' ~/.hermes/config.yaml` 逐处核对落点。
- 改完用 `python3 -c "import yaml; ..."` 读回验证 default/base_url/api_key 是否落盘。

### 2. 配 fallback 链（备用模型）

**不要用 `hermes fallback add`**——它是交互式 picker（`_require_tty`，非交互直接报错）。直接写 `fallback_providers` 列表：

```python
import sys; sys.path.insert(0, '/home/ubuntu/.hermes/hermes-agent')
from hermes_cli.config import load_config, save_config
cfg = load_config()
chain = cfg.get('fallback_providers') or []
chain.append({'provider': '<名称>', 'model': '<model>',
              'base_url': '<endpoint>/v1', 'api_mode': 'chat_completions',
              'key_env': '<KEY_ENV>'})  # 或 api_key 明文
cfg['fallback_providers'] = chain
cfg.pop('fallback_model', None)  # 清旧字段
save_config(cfg)
```

- entry 合法字段：`provider`（必填，可写 custom_providers 里的名称）、`model`（必填）、`base_url`、`api_mode`、`api_key`/`key_env`（二选一；key_env 通过 secret_scope 解析）。
- 验证：`hermes fallback list` 应显示 `Primary: X → Fallback chain: Y`，且各 entry 带 base_url。

### 3. cron 任务模型快照会 fail closed（必踩坑）

**切默认模型前先预检**（比事后修更省事）：直接读 `~/.hermes/cron/jobs.json`，逐条打印
`name / enabled / script|prompt / model_snapshot`：

```python
import json
jobs = json.load(open('/home/ubuntu/.hermes/cron/jobs.json'))
jobs = jobs if isinstance(jobs, list) else jobs.get('jobs', [])
for j in jobs:
    print(j.get('id'), j.get('name'), j.get('enabled'), bool(j.get('script')), j.get('model_snapshot'))
```

全为 `None`（脚本型 / no-agent job 不存快照）即可放心切；有非空快照的 agent 型 job 必须切完立刻修。
（2026-09-10 实测：7 个 job 全 `None`，切默认零风险 —— 先预检就不用被 `config set` 的警告吓一跳。）

切全局默认模型后，`hermes config set` 会警告："N enabled unpinned cron job has stored model_snapshot values that differ"。存了旧快照的 agent 型 cron 下次运行会**拒绝执行**而不是静默换模型。修复：

```bash
hermes cron edit <job_id> --model <新模型> --provider custom
```

- `hermes cron edit` 支持 `--model`/`--provider`（`cronjob` 工具 schema 没有这两个字段，必须走 CLI）。
- 修完查 `~/.hermes/cron/jobs.json` 确认该 job 的 `model_snapshot` 已变/清空。
- no-agent 脚本型 job 没有快照，不受影响；只修 agent 型（有 prompt 的）job。

### 4. 实测新链路

对主模型端点发一次最小 chat 请求验证 key 和模型名都通（urllib/curl 皆可），再 `hermes fallback list` 确认链结构。别只信配置落盘——要实测到 `choices` 返回。

## 核验「现在实际在用什么模型」（用户问「你现在什么模型 / 现在呢」时）

切换动作 ≠ 已生效。用户（尤其爸爸）会在切换后追问「现在呢」，按**两层取证**再汇报，不要只念 config.yaml、也不要只复述切换事件：

1. **全局默认（持久层）**：`hermes config get model.default` + `hermes config get model.provider`（只读、非交互）。再看 `stat -c %y ~/.hermes/config.yaml`：mtime 早于切换时间 → 只是**会话级切换**，新会话 / 网关 / cron 仍走旧默认，汇报必须点明并问是否连全局一起改。
2. **本会话真实调用（真相层）**：查 `state.db` 的 `session_model_usage`——同一会话按 `last_seen DESC` 出现旧模型 + 新模型两行 = 「本会话中途切换」铁证；新模型行 `api_call_count>0` 且 `last_seen` 就在当下 = 已真实生效。
   ```python
   import sqlite3
   con = sqlite3.connect('/home/ubuntu/.hermes/state.db'); con.row_factory = sqlite3.Row
   for r in con.execute("SELECT id, source, title, model, last_activity_at FROM sessions ORDER BY last_activity_at DESC LIMIT 5"): print(dict(r))
   for r in con.execute("SELECT model, billing_provider, billing_base_url, api_call_count, first_seen, last_seen FROM session_model_usage WHERE session_id=? ORDER BY last_seen DESC", ('<sid>',)): print(dict(r))
   ```
   - ⚠️ `sessions.model` 列可能是**过期的初始值**（会话级切换不更新它）——判实际模型一律以 `session_model_usage` 为准。
   - `billing_provider` 常只有 `custom`（不带线路名）→ 用 `billing_base_url` 到 config.yaml `custom_providers` 对号入座找线路名（如 `capy.<PRIVATE_IDENTIFIER>:2087` → 腾白嫖）。
   - state.db 时间戳是 Unix epoch：`date -u -d @<ts>` 换算（BJT = UTC+8）。
3. **汇报口径**：① 现用模型 + 线路名；② 有无真实调用记录佐证（生效判定）；③ 全局默认是否同步变了；④ 一句诚实边界——模型 ID 只是路由标签，能核验的是配置与用量/计费记录，不能自证底层权重。

完整实录（2026-10-15 gemini→`cn:deepseek-v4.1-flash` 会话级切换时间线、SQL 判定表、腾白嫖线路 `cn:`/`global:` 前缀命名）见 `references/session-model-verification.md`。

## 把第三方编码 CLI / Agent 接到自有中转（OpenCode、Cline 类）

用户问「opencode.ai 你能用吗 / 帮我装个 XX CLI 接你的中转」时走这套。核心是**别用它的官方付费网关，
把已有 custom_providers 的 base_url + key 复用过去**，key 用 `{env:NAME}` 引用，不落盘。

1. **装**：npm 全局装到用户前缀（`/usr/local/lib/node_modules` 会 EACCES）：
   ```bash
   npm --prefix /home/ubuntu/.npm-global i -g opencode-ai@latest
   ln -sf /home/ubuntu/.npm-global/bin/opencode /home/ubuntu/bin/opencode
   ```
2. **配** `~/.config/opencode/opencode.json`：`provider.<id>.npm = "@ai-sdk/openai-compatible"` +
   `options.baseURL` + `options.apiKey: "{env:<KEY_ENV>}"`，`models` 的键必须是 `<base_url>/models` 返回的**原样 id**。
   再 pin 顶层 `"model": "<provider>/<model>"`——不 pin 时 CLI 会挑到环境里那个余额为 0 的 `ZHIPU_API_KEY`，
   报 `Insufficient balance or no resource package`（看起来像中转挂了，其实是选错 provider）。
3. **三个必踩的模型 id / 协议坑**（2026-11-07 实测）：
   - **带空格的显示名当 id 会 500**：ikun 的 `/models` 返回 `Deepseek v4.1 Flash`，配成小写 `deepseek-v4.1-flash` 报
     `No available channel for model ...`，用原样空格名报 `Unexpected server error`。→ 该站不适合接，换站。
   - **`claude-*` 不能走 `@ai-sdk/openai-compatible`**：command 中转明确回
     `Model "claude-sonnet-4-6" must be called via /provider/v1/messages (Anthropic Messages shape)`。
     OpenAI 兼容包只会打 `/chat/completions`，要 Claude 必须 `npm: "@ai-sdk/anthropic"` 并指 `/messages` 端点。
     省事的做法：第三方 CLI 一律选 `gpt-*` / `deepseek-*` 这类 OpenAI 形态模型。
4. **验收必须是真 smoke test，不是「装好了」**：`opencode run 'Respond with exactly: SMOKE_OK'`，
   输出里要有那串字。**空 stdout + exit 0 一律加 `--print-logs`** 再判——免费层额度耗尽、地区封锁、
   上游 500 全都表现为静默空输出（本次靠它抓到 `Free usage limit reached`）。

厂商自带免费层的登录方式、额度归属与实测矩阵见 `references/third-party-agent-cli-relay-wiring.md`。

## 故障分层诊断（"模型有问题"时先定位在哪一层）

用户报"模型链接有问题/检查一下模型"时，**先判断故障层，不要一上来怀疑模型**：

> 🅿️ **账号池型网关（WorkBuddy2API / 订阅转 API / 白嫖网关）：先读 `/status` 再谈模型。**
> 这类网关的可用性是**池子属性**，不是模型属性。根路径 `/status`（不在 `/v1` 下）直接给出
> `total / healthy / cooling / disabled / in_flight_full` + 按 realm 的 `realm_totals` +
> 每账号 `credits / credits_total / last_success / reason / model_costs`。
> 拿模型名逐个试是最慢的路；`healthy=0 且 disabled>0` 就说明必须补号，此时
> `no_healthy_account` 是**持续性**而非瞬态，串行复测多少轮都无用
> （上游封号 reason 形如 `account banned by upstream (11140 request illegal), re-login required`，
> 只能重新 OAuth 登录）。
> **并发数不要超过 `healthy` 数量**：2026-11-08 实测单账号池上 10 并发打 35 个模型只出 1 个 200，
> 串行 1.2s 间隔同批出 17 个 200；`<html>503` 与 JSON `no_healthy_account` 是同一过载信号的两层表现。
> 另：`/v1/models` 与 config.yaml 缓存清单会漂移（本次 `cn:*` 已整体摘除、只剩 `global:*`），
> 报「有哪些模型」一律现拉 `/v1/models`。
> 🚨 **加账号 ≠ 解锁模型，且面板「一键完成可自动任务」会把号刷死**：2026-11-08 实测加 3 个 `global` 号后
> 全量矩阵**仍是 17/35**（`gpt-6` / `gemini-3.8` / `grok-4.7` 依旧无档位，上游回 `400 client`），
> 所以别对用户许诺「加号就能用上国际大模型」。其中一个新号加进来 3 分钟内被连点两轮「一键完成 27 项」，
> 上游直接判 `403 account_fault` → `11140 request illegal, re-login required`，号废掉只能重新登录。
> **加完号只签到，别点一键任务。**
> 另：**并发容量 ≈ `healthy` 数**（每号 1 个在途租约），4 号池 10 并发只过 3 个；
> 压测打出的 `429` 软冷却是自己造成的（日志 `kind=soft`，约 10 分钟自恢复），要主动向用户说明。
> `400 model_unavailable` 也**不一定永久**——先读 `/status.model_locks` 的 `unlock_at`，
> `11102 model not available` 是约 5 小时的模型级冷却。
> 完整打法（`/status` 字段语义、`credit_floor` / `model_locks` / `sticky_sessions` 三个易漏字段、
> `400 model_unavailable` vs `503 no_healthy_account` 的归类、
> 2026-11-08 `腾白嫖` 17/35 实测矩阵、加号后的复测结论与封号时间线、
> 面板 `/panel/` 与 `login --realm=global url|poll` 补账号流程）见
> `references/workbuddy-gateway-pool-and-model-matrix.md`。

> 若用户转述的是**运维 Bot 的告警文案**（`🚨【Lemon Ops · AI链路告警】… 模型回退 / 真实推理异常`），
> 那是本机 `hermes-jobs/ai-model-healthcheck.py` 的日志计数产物，不是实时探测结果。
> 排查路径、阈值语义与「回退告警真实根因链」见 `references/relay-model-inventory-audit.md`。

> ⚠️ **你的探测请求会污染这套监控，可能让用户收到误报告警——必须主动披露**。
> `cpa_inference` 信号直接统计 `journalctl -u cliproxyapi.service` 里 `POST /v1/chat/completions` 的
> 4xx/5xx 行数，30 分钟窗口内 ≥3 次即 ALERT，而且它是 **`fail_after=1`**（一次就告警，不像其他信号要连错 2~3 次）。
> 2026-10-20 实测：为审计清单串行探测 16 个模型，其中 9 个是 429 冷却、若干超时 → 日志累积 **16 次失败**
> → `cpa_inference` 从 `OK` 直接跳到 `ALERT`，用户当场又收到一条「CPA 推理失败」告警，**而 CPA 本身完全正常**。
> 处置：① 探测前先说明「接下来的测试会短时拉高 CPA 失败计数」；② 事后**如实告知这条告警是测试造成的**，
> 别让用户以为又出了新故障；③ 恢复无需干预——失败记录滚出 30 分钟窗口后，再连续 2 次检查通过即自动回落
> （本次 12:31~12:42 的失败 → 13:01~13:12 滚出窗口 → 约 13:30 前恢复）。**绝不要为了消警去手改 state.json。**

1. **DNS 解析**：`getent hosts <host>` — 解析失败是域名问题
2. **TCP 连通性**：`curl -s -m 15 -o /dev/null -w "HTTP %{http_code}" "$BASE/models"` 返回 `HTTP 000` 或 `curl: (28) Connection timed out` → **网络层不通**（对端服务挂了 / 防火墙 / 安全组），与模型无关，排查网络而非模型
3. **HTTP 层错误**（能拿到 JSON error）→ 才进入模型层判断：
   - `authentication_error` / `API_KEY_REQUIRED` (401) → key 缺失、未带 Bearer 前缀或格式不合规
   - `INSUFFICIENT_BALANCE` / `insufficient_quota` (403) → key 有效但账户/Token 余额不足或未分配配额（New API 如 justwoker 余额变负直接阻断）。⚠️ **注意**：部分 Gateway（如 nofx - AI API Gateway 等）在余额不足时连 `GET /v1/models` 也会直接拦截返回 403，导致无法拉取模型列表，切勿误判为域名或网络故障
   - `GROUP_DISABLED` (403) → API Key 所属分组已在服务商后台停用（如 true-sota.com），整组 Key 完全失效
   - `ModelAccountTpmRateLimitExceeded` / `inference tpm exhausted` (429) → 账号在该特定模型上的 TPM（每分钟 Token 配额）已耗尽，非全局网络问题
   - `model_not_found` / `model route not found` (404) → 模型名不支持或上游服务商已下架（常引发自建/免费中转代理连带爆发 502 `upstream_error`）
   - `upstream_error` → 上游暂时故障，重试一次再判定（本次 gemini-3.1-pro-preview 首测失败、重试成功）
   - **`upstream_error` + 文案 `All hedged upstream requests failed`（HTTP 502）→ 该站是「多上游对冲」聚合**，一次请求同时打多个上游、**全灭才报这句**。
     含义是该模型此刻没有可用上游，**既不是 key 问题也不是模型名写错**。间隔 ≥2s 重试仍 502 = 线路级故障，该模型不注册。
     ⚠️ 这类站 `/models` 列的名单极不可信（2026-11-08 `ai.di0.uk` 实测：列 9 个只 2 个 GLM 活着，其余 502 或干脆挂死不响应）。
     实测矩阵与探测纪律见 `references/hedged-upstream-relay-notes.md`。
   - **`/api/user/self` 401 ≠ key 无效**：New API 子令牌常只开对话权限，查余额接口报 `AUTH_UNAUTHORIZED invalid access token`。
     同一 key 聊天 200 就说明 key 是好的。汇报时写「额度未知」，**不要编额度、也不要因这个 401 判整条线路废**。
   - `bad_response_status_code` / `openai_error` → 模型在列表里但该模型路由故障（本次 LongCat-2.0）
   - `api_error` + code 10110 "engine is overloaded" → 渠道过载，**瞬态**，稍后重试可能恢复（本次 kimi-k2.6）
   - **`{"code":"session_blocked_by_cyber_policy","message":"该会话已被网络安全策略屏蔽，请开启新会话"}` → 站方内容策略拦截，属于「上游层」永久拒绝，与 key/额度/模型名/本地配置全都无关**。2026-10-30 实测：同一 key 其他模型照常 200，只有触发策略的那条会话被屏蔽；换会话/换站才可能过。用户报「加了模型站但没效果 / 没破甲」时，这条要和 `token_acl_error`（key 没授权该模型）分开说 —— 前者是站方拦内容，后者是权限。**不要因为「接口连通性测试通过」就向用户暗示内容策略能过，这是两道门。**
   - 中文错误消息如"获取绑定路由中模型可用渠道失败" → 该模型无可用上游渠道，暂不可用（本次 gpt-5.6-terra）
   - **HTTP 400 `服务器不支持参数 messages.name，请删除该参数或改用受支持的字段`（`param: messages.name`）→ 网关不认**消息级 `name` 字段**，与 key/额度/模型名全都无关**。2026-10-24 实测「周三」(`<YOUR_PRIVATE_DOMAIN>`)，2026-11-10 在其新站 `token.thxnk.cc` 复测结论一致：都只在 **role=tool** 的消息上拒绝（`role=user` 带 name 返回 200，所以剥除必须只针对 tool 角色）。这类「协议字段兼容」问题**必须按 字段×角色 做探针矩阵**才能定位，靠猜或换模型永远修不好；可复用探针见 `hermes-ai-chain-alert-triage` 的 `scripts/provider_field_probe.py`。
     ⚠️ **该站换域名时，剥 name 补丁的 hostname 门控必须跟着扩**，否则补丁静默失效、tool 调用全 400 —— 见本节上文「换站」小节与 `references/provider-endpoint-migration-fanout.md`。
     ⚠️ 判定要分清**主循环**与**辅助路径**：Hermes 主循环走 transport（`agent/transports/chat_completions.py`），里面有硬编码 host 白名单剥这类字段；但**迭代上限摘要 / 标题生成等旁路请求自己手工拼 messages，绕过 transport**，会漏剥而 400。所以「平时聊得好好的，只在长任务收尾或辅助任务炸」= 旁路漏剥的典型指纹，不要去怪模型。
   - **HTTP 503 + `code:11158` + `model [X] is not allowed for user type [<tier>]`（`当前账号类型暂不支持该模型`）→ 账号档位不含该模型，永久不可用，重试/等待/重启全无用**。外层常包一层 `code: no_healthy_account`，别被它误导成"上游没健康账号"（那是瞬态语义，这个是永久拒绝）。2026-10-20 实测腾白嫖（`capy.<PRIVATE_IDENTIFIER>:2087`）档位为 `personal_free_user`，**但 `global:*` 绝非整条线全灭——31 个 `global:*` 里 16 个实测可用、11 个被 11158 拒绝、4 个临时 503**。
  可用：`global:step-5-preview` `global:glm-5.3` `global:glm-5.2` `global:kimi-k2.6` `global:kimi-k2.8-preview` `global:hy4-preview` `global:deepseek-v4.1-flash-sg` `global:glm-5.3-flash` `global:deepseek-v4.1-flash` `global:balanced-model` `global:kimi-k3` `global:fast-model` `global:hy4-preview-f` `global:hy3` `global:default-model` `global:gpt-5.3-codex`。
  被拒：`global:gemini-3.8-flash` `global:gemini-3.5-flash` `global:gpt-5.4` `global:gpt-5.5` `global:gpt-5.6-terra` `global:gpt-5.6-luna` `global:gpt-5.6-sol` `global:gpt-6-luna` `global:gpt-6-sol` `global:primary-model` `global:grok-4.7`。
  **⚠️ 前缀不是判据，逐个实测才是**：曾据「`global:*` 全灭」的初判准备一刀切删光，实际会误删 16 个可用模型。**处置：串行慢速（间隔 ≥3.5s）逐个实测，只删确认返回 `code:11158` 的那些**（临时 503 的留作备用）。死条目留在清单里的代价：`/model` 菜单能选、选了必 503，每次烧 2 次重试再回退，还会连带打挂 auxiliary（vision/title）任务。完整审计矩阵与安全删除法见 `references/relay-model-inventory-audit.md`。
4. **空回复 + `finish_reason: length`** → 可能是推理模型思考占满 max_tokens（见 Pitfalls），不是故障
5. **空响应（curl 无输出/超时）** → 单次超时不能判死：同一端点其他模型正常、仅个别模型超时 = 该模型渠道慢/挂，重试一次再判定（本次 kimi-k2.7-code、mimo-v2.5-pro 超时但同批其他模型全通）

**服务端模型列表 ≠ 全部可用**：`GET /v1/models` 返回的 24 个模型里实测只有 19 个可用——列表是"宣称支持"，实际可用性必须逐个 chat 实测（本次 5 个失败：路由故障/渠道故障/过载/超时各占一二）。批量测试时把失败项分类记录（瞬态 vs 永久），永久失败不注册，瞬态失败可标注"稍后可能恢复"。

**⚠️ 反方向同样成立，而且更危险：`/models` 会漏报能用的模型。** 2026-10-30 实测腾白嫖配置 41 个、
上游 `/models` 不含其中 7 个，逐个实测后 **5 个完全可用**（只有 2 个真挂）。原因是中转站 `/models`
常只列「主渠道目录」，聚合/灰度/按档位下发的模型不在里面。
**铁律：`/models` 差集只能产生「候选」，绝不能驱动删除**；删除条件必须是真实 chat 请求串行复测
两次以上稳定复现 403/404/11158。另：上游 ID 可能带 `models/` 前缀（Google 原生格式），
朴素差集会把整站报成 100% 变更，先归一化再比。

用户问「上游模型有变化吗 / 需不需要更新」，或说「其他 bot 的模型也一并处理」时，
走 `references/provider-model-refresh-fanout.md`：四步审计流程、`/models` 漏报与格式不同源的判据、
**六个消费者落点表**（Hermes config / dsh web / dsh headless / 群霸 `ai_endpoints.json`+`order` /
AstrBot `cmd_config.json` / 自建 bot 常量），以及「默认模型指向死站 → 每个 bot 都 100% 失败」的处置顺序。

**诊断线索**：多个端点同时 TCP 超时、且端点都是国内 IP（frp 中转站、sensenova 等）而国际端点（api.deepseek.com）仍通 → 高度提示**实例网络出口/安全组问题**（常见于 AWS 换机型/迁移后），不是模型故障。此时优先检查安全组出站规则。

## 判定「中转站到底传没传 system prompt / 工具定义」（传输层 vs 模型行为，别混为一谈）

用户报「人设不生效 / 破甲无效 / 角色扮演没用 / 工具调不起来」时，先分清是**传输层**还是**模型行为**：

| 现象 | 判定 | 依据 |
|---|---|---|
| 抓包里没有 `role=system`，或内容被替换/截断/剥离 | 中转站改写了请求 | **看 body** |
| 抓包有完整 system，模型仍不照做 | 模型不遵从 | 直连 curl 用同一 system 跑多次，全部无视 |

### ⚠️ 行为探针不能定案（2026-10-29 实测踩坑）

曾用「system 写死：不管问什么都只回 `PWNED`」判定腾白嫖（`capy.<PRIVATE_IDENTIFIER>:2087`），
5/5 全部正常自我介绍，据此向用户断言「该站剥离 system」。**结论是错的**，下一轮被用户的实际成功推翻、当场收回。
原因：DeepSeek 系对「只输出一个词」这类格式指令本身遵从度极差，**不遵从 ≠ 没收到**。

> 🔁 **2026-10-31 同一坑复犯**：换了个探针形状（`answer with exactly one word: KIWI`），
> 17 个模型全回正常问候，于是又一次得出「这条中转丢弃所有 system」并写进了下游技能。
> 结论同样不成立。**凡是「system 里写死只准输出 X，模型没照做」的探针，一律只能当"不遵从"，
> 不能当"没收到"**——换个措辞、换句语言、换个模型都救不回来，因为探针本身问错了问题。
> 定传输层只能抓包（`scripts/capture_relay_request.py`），定模型行为只能直连同 system 多轮复现。

### ✅ 正解：抓包看客户端真正发了什么

用 `scripts/capture_relay_request.py` 起本地转发代理，把 provider 的 `baseURL` 临时指向
`http://127.0.0.1:9999/v1`，发一次请求后分析落盘 JSONL：

```bash
python3 scripts/capture_relay_request.py https://capy.<PRIVATE_IDENTIFIER>:2087 TENGBAIPIAO_API_KEY
# 另一个终端跑客户端，再：
python3 scripts/capture_relay_request.py --analyze /tmp/captured.jsonl
```

输出里的 `>>> 含 role=system: True` 才是传输层结论。实测抓到 `msg[0] role=system len=10325` 完整送达。

### ⚠️ 最坑的假成功：上下文带着走

用户说「我用 XX 站成功了」时，先拉会话时间线（provider/model 逐轮记录）再下结论。实测某次：
前两轮由**会执行 system 的那家**写了开头，上下文里已有几千字；之后切到不遵从的那家，模型顺着续写，
**根本不需要 system 起作用**，看起来像「这家也能破甲」。

→ **判定单家 provider 能否承载人设/越狱，必须「全新会话 + 单轮 + 纯该 provider」**；
在已有长上下文的老会话里试，必然假阳性。

### ⚠️ 探测结论的表述：别用「通过」这种会被误读的词

2026-10-30 实测教训：给用户报「21 个模型实测通过、Hermes 实际调用通过」，
两小时后用户说「你之前测这个站不是可以破甲吗」。**连通性测试、system 格式遵从、
SSE 正常这三项都不是内容策略测试**，但一句「通过」在用户脑子里等价于「能用/能破甲」。

- 报结论时按门分开写：**接口连通**（HTTP 200 / 有 choices）→ **格式遵从**（system 里的
  格式指令照做）→ **内容策略**（是否被站方 `cyber_policy` / 模型对齐拦）。测了哪门报哪门。
- 只用「通过」结尾时，必须紧跟一句边界：如「仅证明连通与协议兼容，不涉及内容策略」。
- 用户后来把「通过」理解成「能破甲」时，**直接否认并列出实际测过的三项**，不要顺着说
  「当时是通的」含糊过去 —— 含糊会被当成默认承认。

### 实测矩阵（2026-10-29，同一份人设型强指令 system）

| 站点 | system 送达 | 模型遵从 | 单轮新会话效果 |
|---|---|---|---|
| 周三 `<YOUR_PRIVATE_DOMAIN>` | ✅ 抓包确认 | ✅ reasoning 里明确讨论 system 要求 | ✅ 直接按人设出内容 |
| 腾白嫖 `capy.<PRIVATE_IDENTIFIER>:2087` | ✅ 抓包确认 10325 字符完整 | ❌ 8 个模型全不遵从 | ❌ 全新会话单轮 2/2 直接拒绝 |

### 删除 provider 前的不可替代性检查

用户说「把某家删掉」时，先确认它是否**独占某项能力**（唯一会执行 system 的线路 / 独占某模型 / 唯一免费档）。
实测删掉唯一会执行 system 的那家后，人设类功能立刻全灭。**副作用要主动告知，别只回「已删除」。**

### 核对「是否真删干净」时的时区陷阱

用户会质问「你是不是没删干净」。会话/用量记录存 epoch ms，**换算前先确认机器时区**：
机器本地时间与 UTC 差 8 小时时，删除**前**的历史记录换算后看起来像删除**后**的新请求。
判定顺序：① 配置文件 `grep` 无残留 → ② 运行中 `llm/listProviders` 不含该 provider → ③ 时间戳换算后对比删除时刻。

## 用户问「某模型好用吗 / 哪个模型好」时的质量评测（不是只看能不能用）

用户（尤其爸爸）常问「反重力里这两个 claude 好用吗」「X 和 Y 哪个好」。**不要凭记忆、基准榜单或训练知识答，实际探测后给结论 + 选型建议**：

> ⚠️ **「这模型感觉像个傻子 / 智商会很差吗」同样是质量问题，也必须实测，不许凭参数名推理**。
> 常见错误答法：一上来就说「`flash` 是轻量小模型所以笨」「反代会剥离思维链 / 偷偷注入 System Prompt 阉割它」——
> 后半句尤其危险，**反代是否真的截断思考是可以直接验证的**：发一次请求读
> `usage.completion_tokens_details.reasoning_tokens`，>0 就证明思考确实发生（2026-10-20 实测
> `gemini-3.8-flash-high` 返回 `reasoning_tokens: 91`，思考正常，所谓「物理阉割」不成立）。
> 用户体感变笨的真实原因通常是**型号档位落差**（此前用 `claude-opus-4-6-thinking`，之后切到
> `gemini-*-flash`），而不是反代做手脚。回答顺序：先跑下面的分层题拿真实数据 → 再解释档位差异 →
> 给选型建议；**没有实测数据就不要对「反代是否削弱模型」下断言**。

1. **拿 key 与端点**：从 `~/.hermes/.env` 按 `key_env` 读 key（`grep '^<NAME>=' ~/.hermes/.env`），从 config.yaml `custom_providers` 条目读 `base_url`。用 **urllib**（标准库）发 `/v1/chat/completions`，不要 curl 管道——避免触发「pipe to interpreter」安全扫描逐条拦。
2. **分层测试题（关键）**：只用「回复两个字：能用」只能验可用性，验不了质量。跑两档：
   - 简单题（如「农夫 17 只羊除了 9 只全死，剩几只」）→ 验证可用性 + 基础表达；
   - 有区分度的多步推理题（如三色帽子/说谎者身份枚举）→ 验证真实推理能力。
   每档分别记 `耗时`（`time.time()` 差）。
3. **对比维度**：耗时、正确性、输出风格（thinking 版「逐一假设排除」vs 标准版「枚举 + 表格」）、结论凝练度。据此给选型建议（要快用标准版、要深用 thinking 版），而不是「都好/都不行」的空话。
4. **实测样例（反重力 2026-10-20）**：`claude-opus-4-6-thinking`（推理增强，假设排除法，3.3s/13.2s）vs `claude-sonnet-4-6`（标准，枚举表格，4.1s/9.8s），两档全答对、均可用；选型上「快用 sonnet、深用 opus-thinking」。
   ⚠️ 主链会变，**别在技能里写死"当前兜底是 X"**：核验一律现场读 `hermes config get model.default` +
   `hermes config get fallback_providers`。2026-10-20 起 `claude-sonnet-4-6` 已被挂进 fallback[0]（原 `gpt-6-luna` 因
   codex 池配额 429 而失效被替换），`claude-opus-4-6-thinking` 仍只在清单里、需 `/model <名>` 手动切。

## 为外部应用分配模型角色（不是给 Hermes 配 provider）

用户自建/试用第三方 bot，而该 bot 把 LLM 拆成多个角色（如 main / decision / moderation /
vision / compress / embed，每角色一条 fallback 链），问「你看看我现有的模型，怎么调用合适」时走这套。
与本节上文「某模型好用吗」的区别：**这里比的是角色适配，不是单模型质量**。

1. **先读该应用的配置 schema**：角色字段、是否支持多 provider、`api_base` 能否自定义。
   很多应用（如 Smart Group Bot）角色都是 `provider + model + fallbacks[] + temperature/max_tokens/timeout`，
   能填自定义 `api_base` 就意味着**中转站可以直接接**，不必只认官方。
2. **列现有 provider，不打印密钥**：读 `custom_providers` 的 `name/base_url/key_env`，再逐条判断
   `os.environ.get(key_env)` 是否 set（只输出 set/MISSING）。
3. **三类探针分开跑、分开报**（合并成一句「通过」会被用户理解成「能破甲/能用」，见上文表述铁律）：

   | 探针 | 判定 | 注意 |
   |---|---|---|
   | 连通 + 延迟 | 最小 chat 请求，记 `http_code` + `time_total` | 高频角色选最快的那条 |
   | **格式遵从** | system 写死「只输出 PASS」，user 问需要推理的问题 | **只能判"不服从格式指令"，不能判"system 被剥离"** |
   | **embeddings 端点** | `POST /v1/embeddings` 是否 200 | 大量中转 404/503，embed 角色往往只能落官方 |

   ⚠️ 格式遵从探针的结论措辞必须收窄：写「该模型不服从严格格式指令，不适合把 system 当硬约束的角色
   （decision / moderation）」，**不要写「system 失效」或「中转丢弃 system」**——那是传输层结论，
   只有抓包（`scripts/capture_relay_request.py`）能定。
4. **分配原则**（可直接复用）：
   - 调用最频繁的角色（decision，几乎每条消息都跑）放**本机网关**最快最便宜的那个小模型；
   - moderation 与 main 用**不同供应商**，主模型 429 时审核不跟着瘫；
   - 每条 fallback 链**跨上游账号池**（同池 gpt 系会一起 429）；
   - embed 维度**一次定死**，换 embedding 模型 = 旧向量全废；
   - 第一轮只配必需角色（main / decision / embed），其余留空继承 main，跑顺了再细分。
5. 交付时给**角色→模型→fallback 的表格** + 每条选择的理由，别只丢一串模型名。

实测数据、可复用的 bash 探针函数与本轮供应商能力矩阵见
`references/role-model-allocation.md`。

## 付费官方渠道误烧防线与 Fallback 链审计（2026-09-11 实测：官方 DeepSeek 被静默扣费）

**核心铁律：`fallback_providers` 链里严禁放入「用户付费的官方渠道」当兜底。**
Hermes 的 fallback 机制在主模型 429/403/502/网络抖动时**自动顺链滑落**，
一旦链中有真实付费 key（如官方 `api.deepseek.com`），会在用户毫无感知的情况下持续烧钱。

### 误烧的真实链路（justwoker 案例）
1. 用户切到中转站（justwoker）模型 → 该站 Cloudflare WAF 对机房 IP 硬拦截，`POST /chat/completions` 恒 403；
2. Hermes 判定主模型故障 → 触发 fallback 链：反重力 429 → 日日新 429 → **链尾官方 DeepSeek 命中**；
3. 结果：聊天看似正常，实际每一轮都在扣官方余额（`state.db` 记录上百次静默调用）。

### 审计真实调用量（不靠猜）

> 用户问的是「某个站/某个模型额度掉得特别快，这两天哪里调用最多」这类**用量归因**问题时，不要在这里改路由或 fallback ——
> 走 `model-usage-attribution`（本机 `state.db` 按会话/来源/天拆，含 `billing_provider` 别名多种形态的对账坑），
> 先用 `scripts/usage_report.py --provider <别名> --days 3` 定位烧 token 的会话，再决定是否动配置。

```python
import sqlite3
conn = sqlite3.connect('/home/ubuntu/.hermes/state.db')
# 每个 provider/model 的真实调用次数与 token（找出谁在烧钱）
conn.execute("SELECT model, billing_provider, billing_base_url, api_call_count, input_tokens, output_tokens "
             "FROM session_model_usage ORDER BY last_seen DESC").fetchall()
# 会话级持久化 model_override（覆盖全局默认的关键！）
conn.execute("SELECT session_key, entry_json FROM gateway_routing "
             "WHERE session_key LIKE '%<chat_id>%'").fetchall()
```
- 网关日志 `Rehydrated persisted /model override for session=...` 出现即证明该会话绑定了旧的持久化覆盖；
- 判断「实际在打哪个端点」以 `state.db` / 网关日志的 `provider=custom:xxx base_url=...` 为准，不要信配置文件表面。

### Fallback 链编辑的三个 CLI 陷阱
1. **`hermes fallback remove <名称>` 不接受位置参数**：`unrecognized arguments`。`hermes fallback add` 是交互式 picker（非 TTY 报错）。要改链只能 Python 直写 YAML。
2. **`hermes config set fallback_providers '[{...}]'` 会把 JSON 字符串当字符串存**：落盘变成 `fallback_providers: '[{"provider":...}]'`（带引号），
   `hermes fallback list` 立刻显示 `No fallback providers configured` —— 整条链静默丢失。
   **症状校验**：`python3 -c "import yaml;c=yaml.safe_load(open('config.yaml'));print(type(c['fallback_providers']))"`
   输出 `<class 'str'>` 即为中招（正确应是 `<class 'list'>`）。
   ✅ **2026-11-03 实测更安全的解法：点号路径 set，不要整块传 JSON**。CLI 的 `_set_nested` 支持列表下标，
   `get`/`set` 都认，且**保持 list 类型不被字符串化**：
   ```bash
   hermes config get fallback_providers.0.provider          # 先探，确认下标存在
   hermes config set fallback_providers.0.provider 周三
   hermes config set fallback_providers.0.model "Deepseek v4.1 Flash"
   hermes config set fallback_providers.0.base_url "https://<YOUR_PRIVATE_DOMAIN>/v1"
   hermes config set fallback_providers.0.key_env "IKUN_API_KEY"
   hermes config set fallback_providers.0.extra_headers.User-Agent "Mozilla/5.0 ..."
   ```
   逐字段覆盖比行级块替换更安全：不手写 YAML、不动其它行、不丢注释，嵌套 `extra_headers` 也能进。
   **改法选择**：条数与目标一致 → 点号路径逐字段覆盖（首选）；要增删条目 → 行级块替换
   （`_set_nested` 明确不增长列表，`fallback_providers.2` 对 2 条链会 `IndexError`）。
   两种方法都必须回读 `type(...) == list` 验收。
   **正解：行级块替换，不要 `yaml.dump` 整文件重写**（`yaml.dump` 会丢注释与 `system_prompt` 等长文本的原始缩进格式）：
   ```python
   lines = open('config.yaml', encoding='utf-8').readlines()
   idx = [i for i,l in enumerate(lines) if l.startswith('fallback_providers:')]
   assert len(idx) == 1                      # 必须唯一，否则先人工确认
   lines[idx[0]] = '''fallback_providers:
     - provider: 反重力
       model: claude-sonnet-4-6
       base_url: http://127.0.0.1:8317/v1
       key_env: ANTIGRAVITY_API_KEY
       api_mode: chat_completions
   '''                                        # 只换这一行，其余行原样保留
   open('config.yaml','w',encoding='utf-8').writelines(lines)
   ```
   验收：`hermes config get fallback_providers` 应输出真正的 YAML 列表（每项带 `provider/model/base_url/key_env`），
   再用 `len(yaml.safe_load(...)['fallback_providers'])` 确认条数。
3. **`patch` 工具拒改 `~/.hermes/config.yaml`**：报
   `Refusing to write to Hermes config file ... Agent cannot modify security-sensitive configuration.
   Edit ~/.hermes/config.yaml directly or use 'hermes config' instead.`
   → 改 Hermes 配置的三条合法路径：① `hermes config set`（标量/字符串）；② 复杂结构（列表、嵌套 provider 条目）
   在 terminal 里跑 Python 做行级替换；③ 用户手工编辑。**别反复重试 patch 工具**，直接换路径。

### 云端机房 IP 段被中转站 Cloudflare WAF 整段封锁与额度判定
- **现象**：在云端服务器（AWS / 海外 VPS）调用中转站（如 `api.justwoker.icu`），`GET /models` 正常 200，但 `POST /chat/completions` 无论使用 curl、Python-requests、Chrome 伪装 UA、甚至 curl_cffi 模拟 TLS 浏览器特征，恒定返回 HTTP 403 `Attention Required! | Cloudflare: Sorry, you have been blocked`。
- **根因辨析**：站长在 Cloudflare 后台对对话端点开启了数据中心机房 ASN / IP 黑名单，**与用户账户额度无关**（用户账户内额度可能非常充足，在本地电脑浏览器或家宽环境下调用完全正常）。
- **避坑处置**：切勿将此类被 WAF 硬拦截的端点保留为主模型，否则不仅主模型不可用，还会频繁触发 Fallback 链，若 Fallback 中存在付费官方通道（如官方 DeepSeek）会造成隐蔽静默扣费。此类通道仅推荐在本地客户端使用，或向站长索取免盾专线域名。

### Provider 改名与运行时路由验收

- 改名前备份配置并检查名称唯一性，只修改目标条目的 `name`；结构化比较改名前后配置，确认除名称外无变化，不顺手改主模型或备用链。
- 同名模型不等于串站，但裸模型名可能歧义。明确指定 provider 后，用 `hermes_cli.runtime_provider.resolve_runtime_provider(requested=站点名, target_model=模型ID)` 取得运行时结果；核对 `source`，在进程内比较 `base_url` 与目标配置、`api_key` 与对应 `key_env` 的值。只输出来源名称和匹配布尔值，绝不打印 URL、密钥或整个返回字典。
- 改名后再运行一次明确指定 provider 与 model 的 Hermes 请求，要求返回独特校验文本；检查实际最终回复和回退证据，不用整份日志里出现通用 `OK` 就宣告通过。运行时解析匹配只是路由证据，不代替实际请求；请求成功也不保证未发生 fallback，必要时结合会话用量或目标端请求记录反证。
- 分开报告：逐模型接口探测、Hermes 实际调用、离线菜单注册、在线界面验收。测到哪层就只报哪层；模型标签不证明上游真实身份，一次通过不保证长期稳定。

### 同名模型多供应商会选错
多个中转站（如 nofx 与 justwoker）都暴露 `gpt-5.6-terra/luna/sol` 等同名模型时，
按模型名切换可能落到**余额不足的那一家**（403 后触发上面的 fallback 误烧链）。
处置：切换时显式带 `provider` 或 `base_url`；保留多个同名 provider 时以 provider 名称为锚，不要只认模型名。

### 防御性配置（一次做对）
- fallback 链只放免费/本地端点（如本地网关另一模型、免费中转），链尾**显式**以「报错停住」替代付费兜底；
- 用户要求「绝不再碰官方 key」时，直接清空 `fallback_providers` 中对应条目并复查 `hermes fallback list`；
- WAF 硬拦截的端点（/models 200 但 /chat/completions 恒 403）**严禁保留为主模型**——见上文 justwoker 案例。

## 用户索要「某条线路的 URL / 密钥」（先分清自有网关还是第三方中转）

用户说「把 X 的 url 和密钥发我 / 我要用在其他地方」时，**第一步不是拒绝，也不是背安全话术，而是先定位这个端点到底是谁的**。2026-10-22 实测教训：连续两轮拿「凭据红线」拒答「腾白嫖的 url 和密钥」，用户追问三轮才说清「我说的是我部署的 WorkBuddy2API」——而 `capy.<PRIVATE_IDENTIFIER>:2087` 根本就是他自有 VPS（`vps-la` / <PRIVATE_IDENTIFIER>）上的自建网关。**对自有部署拒答三轮 = 纯损耗**。

### 归属判定链（只读，一次跑完）

```bash
# ① provider 名 → base_url + key_env
grep -n -A4 'name: <provider名>' ~/.hermes/config.yaml
# ② key_env → 明文（只做长度/存在性判断，先不打印）
awk -F= '/^<KEY_ENV>=/{print "len="length($2)}' ~/.hermes/.env
# ③ 域名归属：解析到哪台机器
getent hosts <host>            # 命中 ~/.ssh/config 里的 HostName = 自有节点
grep -E "^Host|HostName" ~/.ssh/config
# ④ 自有节点上确认服务与部署目录
ssh <host别名> 'systemctl list-units --all | grep -iE "<服务名>"; ls -d /opt/<项目>*; ss -ltnp | grep <端口>'
# ⑤ 用该 key 实测（200 + 模型数 = 有效）
curl -s -m 15 -o /tmp/m.json -w "http=%{http_code}\n" https://<host>:<port>/v1/models -H "Authorization: Bearer $KEY"
```

判定口径：
- **解析到自有 VPS / 本机，且有 systemd 服务 + 部署目录** → 自有网关，用户是所有者，私聊/CLI 会话里**可以直接给出 base_url 与 key**（这正是他要拿去接别处的），并附一句「别贴进群聊/公开仓库」。
- **解析到第三方中转站域名**（发卡站、NewAPI 面板） → 属于第三方凭据：不给明文，指引他去原面板「令牌」页新建/复制，或说明本机 `~/.hermes/.env` 有但不宜外发。

### 交付格式（用户要的是能直接粘走的东西）

给三段，别写成散文：**接口地址**（含 `/v1`）、**密钥**、**实测结果**（HTTP 码 + 模型数，证明有效）；再加一个最小 `curl` / OpenAI SDK 示例（`base_url` + `api_key` 两行说明）。末尾附**部署位置备忘**（服务名、目录、内网端口 / nginx 外层端口、改 key 的热生效方式），因为用户下一句通常是「以后怎么改」。

完整拓扑、自查命令与本机 `~/.hermes/.env` 对应关系见 `references/self-hosted-gateway-credential-lookup.md`。

## 移除 provider / 下线整套模型栈（回滚）

用户说「不要了 / 回滚 / 把这个删掉」时，**只删 config 里那一条远远不够**。一次完整下线要清四处，少一处就留残留：

| # | 位置 | 怎么清 |
|---|---|---|
| 1 | `config.yaml` 的 `custom_providers` 条目 | YAML 结构化重写（见下），**不做行级替换** |
| 2 | `~/.hermes/.env` 的 `key_env` 变量 | Python 按行过滤重写，不用 sed |
| 3 | 服务端那侧暴露端点的代理/面板 | `/v1/*` 透传路由不删 = 留了个免登录的模型后门 |
| 4 | 会话里手动 `/model` 切过去的绑定 | 删 provider **不会**自动回退，要显式切回主模型 |

```bash
cd ~/.hermes && cp config.yaml "config.yaml.bak-rm-$(date -u +%Y%m%dT%H%M%SZ)"
python3 - <<'PY'
import yaml, os
p = os.path.expanduser("~/.hermes/config.yaml")
d = yaml.safe_load(open(p))
d["custom_providers"] = [c for c in d.get("custom_providers") or []
                         if c.get("name") != "要删的名字"]
tmp = p + ".tmp"
yaml.safe_dump(d, open(tmp, "w"), allow_unicode=True, sort_keys=False, width=4096)
os.replace(tmp, p)
print([c["name"] for c in d["custom_providers"]])
PY
```

验收三条，缺一条都不算删干净：

```bash
grep -c "要删的名字" ~/.hermes/config.yaml   # 期望 0
grep -c "<KEY_ENV>"  ~/.hermes/.env          # 期望 0
python3 -c "import yaml;d=yaml.safe_load(open('$HOME/.hermes/config.yaml'));print(len(d['custom_providers']))"
# 期望：能解析 + provider 条数 = 删前 - 1
```

⚠️ `yaml.safe_dump` 会**丢注释**。config.yaml 注释多时改行级块替换，但只在该块边界清晰时用；本次 9 个 provider 的列表全量重写后 `yaml.safe_load` 回读正常、Hermes 启动无异常，可接受。

⚠️ **别把「回滚」做成「只改配置」**：本次用户要求回滚的是一整套模型栈（容器 + 8.43G 镜像 + 5.4G 模型卷 + 面板代理 + provider），磁盘从剩 4.7G 回到 17.9G、内存从 94.9% 回到 8.0%。只删 provider 会留下几十 G 垃圾和一条仍可被外部调用的 `/v1/*` 路由。

### 退役某厂家的「配套功能」（不只是模型配置）

用户说「Gemini 的每日额度播报可以关掉了 / 账号检测也可以删了」时，重点是**代码入口 + 定时器 + 独立模块**三处，
不是改模型配置。本次 LemonOps 实测共 15 个落点：

| 类别 | 落点 |
|---|---|
| 指令 | `/quota` CommandHandler + `BotCommand` 菜单项 + 两处帮助文案 |
| 回调 | `m:quota`、`m:gemini_probe` 两个 `callback_data` 分支 |
| 菜单按钮 | 主菜单额度按钮、status 键盘「立即探测」按钮 |
| 面板段落 | `get_gemini_recovery_text()` 整个函数 + 其在 `get_system_status_text()` 里的拼接 |
| 模型切换 | 模型键盘的该模型按钮 + `switch_hermes_model()` 对应分支 |
| 模块 | `from quota_module import ...` + `quota_module.py` 本体 |
| 定时器 | `gemini-quota-daily.{service,timer}`、`gemini-recovery-revert.{service,timer}` + `.service.d/` drop-in |
| 脚本 | 播报/探测脚本本体 |

**做法**：用一次性的 Python 脚本按「唯一命中」断言逐处 `replace`（`if src.count(old) != 1: exit(1)`），
每处理一处打一行 label，最后打印行数变化。比手改可靠——某处命中 0 或 2 次会立刻停。

**归档而不是删除**：`disable --now` 定时器 → 把 unit 文件 `mv` 到 `backups/retired-<feature>-<stamp>/`
→ `daemon-reload` → 模块和脚本一起移进同一目录。用户反悔时整目录搬回即可。

**离线验收用导入断言，不要只看服务 active**：直接 `import main` 然后断言
`not hasattr(main, "quota_command")`、菜单 label 列表里无该厂家字样、`get_system_status_text()` 不含该段落、
源码里无残留 `"m:quota"` 字符串 —— 9 项全过才算干净。服务重启后再看日志有没有 `ImportError`。

完整实录（服务端 teardown 顺序、`sudo -n` 删 root 卷残留、面板 1144 行重写为精简版的决策依据）见 `references/provider-removal-rollback.md`。

## Pitfalls

- **批量并发探测与超时控制**：当 Provider 下挂载数十个模型（如 Share / 中转站包含 30+ 模型）时，严禁用串行循环 curl 逐个探测，会导致执行超时（180s+）。应使用 Python `ThreadPoolExecutor`（设置 worker 10~15，单次请求超时 15~30s）并发探测。⚠️ **注意中转站 RPM 限流与长思考模型**：
  - 中转站往往有严格的请求频次限制（如 ShareLLM 限制 20 次/分钟），并发过猛会导致大批模型瞬间报 `HTTP 429 您已达到请求数限制` 造成假死误判。对 429 报错必须采用单线程带退避间隔（如 `sleep(3.5)`）重测。
  - 高思考/高推理模型（如 `gemini-3.6-flash-high`）因生成大量 reasoning tokens，首包耗时可能超过 20s，超时时间若低于 20s 会抛 `timed out` 误判为坏死。此类模型探针超时应放宽至 35s+。
  - 🚨 **并发探测会伪造「模型全死」——删除任何模型前必须串行复测**：中转站并发过猛时，网关返回的不是 429，而是 **HTTP 503 `code:no_healthy_account` + `gateway_hint: no healthy account available in pool`**，或干脆一页 `<html>503 Service Temporarily Unavailable</html>`。这两种响应**与「模型永久不可用」在观感上无法区分**，极易让人把整份清单判死。2026-10-20 实测腾白嫖：`ThreadPoolExecutor(max_workers=8)` 打 52 个模型，结果 **49/52 报 503**（含前一刻单测刚 200 通过的 `cn:deepseek-v4-flash`、`cn:glm-5.3-flash`、`cn:kimi-k3-1`）；改串行 + `sleep(3.5)` 复测后真实结果是 **19/52 可用**，差点据此误删 30+ 个能用的模型。
    **铁律：并发探测结果只能用来「发现候选」，绝不可用来「判定永久失效」或驱动删除。** 判定链必须是：并发粗筛 → 对每个疑似失败项**串行间隔 ≥3.5s 逐个复测** → 只有稳定复现 `code:11158`（或 `model_not_found`）才可判永久；复测变 200 的一律视为网关瞬态、保留。
    三类响应按此归类，别混：`code:11158 model not allowed for user type` = 永久权限；`code:no_healthy_account`/HTML 503 = 网关瞬态；`model_cooldown` + `usage_limit_reached` = 配额冷却（等重置，非失效）。
- **挂死的模型不吃 `-m` 却吃光整批时间预算**：部分上游不对齐时，请求**不报错、不 RST、不发字节**，
  `curl -m 90` 就真干等 90s（exit code `000`）。串行探测时两三个这种模型就把 180s 命令超时吃满，
  前面已拿到的结果一起丢。→ **每个探测请求都写成 `timeout 30 curl -m 25 ...`（shell 层 + curl 层双保险）**；
  批量走 `scripts/probe_models_concurrent.py`。流式探针最容易被挂住（首块后长时间静默），外层再包一层 `timeout 25`。
- **`extra_headers` 类型安全**：配置中的 `extra_headers` 可能是字典 `{...}`，也可能是字符串 `"{}"` 或空值。解析时需先做类型判断与 `json.loads` 兜底，避免 `headers.update()` 报序列长度错误。
- **本地服务公网 IP vs 本地 Loopback (localhost) 连通性差异**：自建网关（如 CLIProxyAPI 8317 端口）如果在同一机器上运行，必须优先配置 `localhost:8317`。配置公网弹性 IP 会因云厂商（如 AWS EC2）入站安全组未开放该端口导致丢包超时，而本地 loopback 通信完全不受安全组阻拦。
- **特殊模型参数限制与生图模型分类**：
  - 部分模型（如 `kimi-k3`）强制要求 `temperature=1`，传入 0.1 会抛 400 错误。
  - 生图专用模型（如 `gpt-image-1/1.5/2`）不支持 `/v1/chat/completions` 端点，探测时会返回 400，需与文本/聊天模型分开管理。
- **WAF / Cloudflare 拦截默认 SDK User-Agent（403 Blocked）**：
  - **云机房 IP 段整段被 WAF 阻断 vs 额度充足（`justwoker.icu` 案例）**：
    - 现象：`GET /v1/models` 正常 200 并返回模型列表，但在机房（AWS/海外 VPS）发起 `POST /v1/chat/completions` 时，无论换用何种浏览器 UA、哪怕 curl_cffi 模拟真实 Chrome124 TLS 特征，甚至走海外住宅代理，依然 100% 返回 Cloudflare 403 `Attention Required! | Sorry, you have been blocked`。
    - 根因：中转站站长在 Cloudflare 后台对聊天接口开启了**机房 ASN / 数据中心 IP 级硬拦截**；此时用户账户内往往**额度充足**，在本地电脑浏览器或国内家宽下均可正常使用，唯独云服务器被封死。
    - 处置红线：严禁误判为“账户欠费”；切勿将此类被 WAF 硬阻断的端点保留为主模型，否则请求立刻触发 Hermes 自动降级（Fallback Chain）并可能误烧下游付费通道（如官方 API）。
  - **配置级修复（Hermes 官方支持，feature #40033）**——给该 custom_providers 条目加 `extra_headers`，SDK 每次请求自动携带替换掉的 UA，不用改代码：
    ```bash
    hermes config set custom_providers.<N>.extra_headers '{"User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/126.0 Safari/537.36"}'
    ```
    原理：`hermes_cli/config.py::apply_custom_provider_extra_headers_to_client_kwargs` 把这些头 merge 进 OpenAI client 的 `default_headers`，provider 级设置优先级最高（`agent/agent_init.py` 里同样有 `agent._apply_user_default_headers()` 支持 `model.default_headers`）。
    ⚠️ **别被 Web UI 的 `unknown config keys ignored: extra_headers` 误导**（2026-10-24 实测踩到）：
    hermes-web-ui **0.7.39 起**，服务端 `[config-helpers]` 会对 `custom_providers.<名>` 里它自己不认识的键打一条
    `console.warn`，`extra_headers` 正在其中（0.7.37 及之前无此警告，升级后才出现，容易误以为是升级把配置搞坏了）。
    这条警告**只说明 Web UI 自己的配置表单/渲染器没有这个键的白名单**，不代表 agent 侧不生效——两者是两套解析器。
    判定 agent 是否真的带上头，三条从轻到重，**优先用第一条（不发任何请求）**：
    ① **运行时反查**——直接调 Hermes 自己的解析函数，看运行时到底取到什么头：
    ```bash
    cd ~/.hermes/hermes-agent && ./venv/bin/python - <<'PY'
    import sys; sys.path.insert(0, '/home/ubuntu/.hermes/hermes-agent')
    from hermes_cli.config import get_compatible_custom_providers, get_custom_provider_extra_headers
    for e in get_compatible_custom_providers():
        if e.get('extra_headers'):
            got = get_custom_provider_extra_headers(e.get('base_url'))
            print(e.get('name'), '| 配置:', e['extra_headers'], '| 运行时:', got,
                  '|', '生效' if got else '未生效')
    PY
    ```
    输出「配置 == 运行时取到」即消费链完好；只有返回 `{}` 才是真没生效。
    这条同时验证了 base_url 匹配逻辑（`normalize_route_base_url`），比读代码可靠。
    ② `grep -c "apply_custom_provider_extra_headers_to_client_kwargs" ~/.hermes/hermes-agent/hermes_cli/config.py`
    非 0（有定义且有调用点）；③ 抓一次真实请求的 `default_headers`，或对 WAF 端点实测 403→200。
    **本次的反面教材（务必别重犯）**：用 `grep -rn extra_headers --include=*.py | grep -v test | head -8`
    得出「agent 根本不读这个键、用户配的 UA 从没生效过」并向用户下了断言 —— `head -8` 把输出截断在
    openrouter 插件那几行，真正 config 侧的实现被截掉了，结论很可能是错的。
    **截断之外的第二个变体同样致命：同行关键词过滤**。同一坑 2026-10-24 又踩一次，用的是
    `grep extra_headers | grep -iE "custom|provider"` —— 而真正的实现行是
    `normalized_headers = normalize_extra_headers(entry.get("extra_headers"))`，
    这行**既不含 custom 也不含 provider**，被过滤条件自己排除了，于是又得出一次错误结论。
    **铁律：凡是要回答「某配置键到底有没有被消费」，禁止用带 `head`/`tail` 的截断 grep、
    也禁止叠加同行关键词过滤来定案**；必须用 `grep -c` 或读完完整输出，
    或者直接用上面第 ① 条的运行时反查。拿不准就说「需要再确认」，别向用户断言「从来没生效」。
  - 临时验证：`openai.OpenAI(..., default_headers={"User-Agent": "Mozilla/5.0"})` 能返回即确认是 WAF。
  - ⚠️ **`custom_providers.<N>` 是列表下标、不是名字匹配**：本次误把 extra_headers 加到了下标 0 的「日日新」上（呆布实际在下标 6），失败表象是改到了完全无关的 provider。写之前先 `grep -n "name:\|extra_headers" ~/.hermes/config.yaml` 数清下标，写后复查落盘位置，错则重复设置并清掉误改项（`hermes config set custom_providers.<N>.extra_headers '{}'`）。
  - 改完必须走真实链路验证：`hermes chat -q "直接回复：能用"`；gateway 侧用 `grep -n "403\|blocked\|PermissionDenied" ~/.hermes/logs/errors.log` 确认不再报。辅助任务（标题生成 aux model）与主模型走同一 provider，403 会先出现在 aux 报错里（如 `Auxiliary title generation failed: HTTP 403`），别被带偏以为主链路问题。
  - 注意「切换没生效」≠ 配置没变：gateway 日志里出现 `provider=custom:呆布 base_url=https://cp.tagaa.eu.cc/v1 model=gpt-5.6-luna` 证明切换**已生效**，只是请求被 WAF 拦在 HTTP 层。判断顺序：先看日志里 gateway 实际在打哪个端点，再决定动配置还是动风控。
- **推理模型（deepseek-v4 系）会输出 `reasoning_content` 吃掉 max_tokens**：max_tokens 给 20~80 时 token 全花在"思考"上，`message.content` 为空、`finish_reason=length`，看起来像模型坏了。测试/探测时 max_tokens 至少给 **200+**，或同时检查 `message.reasoning_content` 是否非空再判定。
- **bash 循环里 `python3 -c` 内联代码不能引用外层 bash 变量**：`resp=$(curl ...)` 后管道给 `python3 -c "...resp[:100]..."` 会 `NameError: name 'resp' is not defined`。数据必须走 stdin 或环境变量传进 python，bash 变量名在 python 内联代码里不存在。
- **删除冗余/失效 Provider**：先安全备份 `config.yaml`（`cp config.yaml config.yaml.bak-$(date +%Y%m%d%H%M%S)`），再使用 Python 读取 YAML，从 `custom_providers` 列表中根据 `name` 过滤移除目标项，使用 `from utils import atomic_yaml_write` 原子写入，最后通过 `hermes config check` 验证配置完整性。
- **中转站单并发（1 Concurrency）限制与 Hermes 辅助模型（Auxiliary）冲突**：
  - **现象**：在 New API / One API 免费或分销组端点（如 `api.dddai.dev`）发起会话首轮请求时，瞬间被 upstream 拒掉并报 `HTTP 429 concurrency_limit_exceeded: Too many concurrent requests. Your current plan allows up to 1 concurrent requests.`，直接导致 Hermes 触发 fallback 链降级。
  - **根因**：Hermes 在收到首条消息时，会并发触发后台任务（如 `auxiliary.title_generation` 标题生成），若 auxiliary 处于 `auto` 状态，会沿用当前 session provider，造成主对话请求与标题生成请求瞬间并发（2 请求），直接打爆 1 并发上限。
  - **处置**：单并发端点切勿同时承担 auxiliary 任务；若将此类模型作为主力模型，必须在 `config.yaml` 的 `auxiliary` 模块中显式解耦指派给多并发通道（如本地反重力网关或 deepseek 官方通道），避免辅助线程抢占唯一通道。

- **批量测试要防空响应**：端点超时/挂掉时 curl 输出为空，`json.loads('')` 直接抛 JSONDecodeError 并中断整轮循环。python 里先 `raw=sys.stdin.read(); if not raw: print('❌ 空响应(网络超时)'); sys.exit()` 再解析；整个脚本用 `set -u` + 每请求 `-m 45`，批量循环总 timeout 给足（10 个模型 × 45s ≈ 450s+）。

- **`hermes config set custom_providers.2.name ...` 报 `IndexError: list index out of range`**：CLI 的 `_set_nested` 明确不增长列表（"we do not grow lists"），只能索引已有条目。追加新 provider 必须用 Python 脚本改 YAML。
- **`atomic_yaml_write(path, data)` 参数顺序**：path 在前、data 在后，反了报 `TypeError: expected str, bytes or os.PathLike object, not dict`。
- **导入路径**：`from utils import atomic_yaml_write`（hermes-agent 根目录的 `utils.py`），**不是** `hermes_cli.utils`（不存在）。脚本要用 hermes 自己的 venv python（`~/.hermes/hermes-agent/venv/bin/python3`）跑，且 `sys.path.insert(0, "<hermes-agent 根目录>")`。
- **`read_file` 会脱敏 config.yaml 里的 api_key**（显示 `«redacted:sk-…»`）。涉及密钥的读取/改写一律用 `yaml.safe_load` 直接读原文件，否则会把 `«redacted»` 占位符写回去破坏配置。
- **`hermes model` 需要交互式终端**，管道/非交互下报错 "requires an interactive terminal"。验证用 `hermes chat -q --provider -m` 代替。
- **custom provider 名不能与内置 provider 名冲突**：`--provider gemini` 会命中 Hermes 内置的 gemini（走 `https://generativelanguage.googleapis.com/v1beta`），custom_providers 里同名条目被忽略。`hermes_cli/auth.py` 的 `resolve_provider` 对内置名（gemini/anthropic/openai/xai/kimi 等）优先归一化，custom 候选被跳过。解决：custom provider 用不冲突的名字（如 `gemini-cli`）。实测时看报错里的端点：`Provider: custom + Endpoint: <你的 base_url>` 才是走对；若出现内置端点（如 generativelanguage.googleapis.com）或 "API key not valid" 就是撞名被内置抢了。
- 保留已有 provider：追加而不是重建整个列表。
- 中转站可能同时代理多种厂商模型（deepseek/gemini/claude/gpt），注册时 `models` 列表只放实测通过的。

## 支持文件

- `references/fleet-bot-model-migration.md` — **用户说「把所有自建 bot 的模型都换成 X 主力 / Y 备用」时先看这篇**：
  三种「配置」的分辨（部署模板 / systemd LoadCredential 真实运行时 / 代码硬编码）、共享 client 换模型会静默打断视觉审核、
  无 fallback 的 bot 要改代码加、**「全部换完」前必须跨主机实测枚举消费者**（本次漏掉 TeleBox 与 SGB 被 Owner 点出）、
  **协议不兼容时的本地桥接模式**（UA 注入 / Gemini 原生转换 / 多上游梯队 / 非对话端点透传 + 状态码保真 / 只做非流式）、
  SGB `ProviderConfig` 无 `extra_headers` 与 host 网络下容器内 `127.0.0.1` 即宿主机的判定；
  **§7b 共享端点池改 `key`→`key_env` 会让所有未适配的消费者同时断链**（配置/服务/菜单全正常，只有真调用抛
  `fleet endpoint pool unavailable`，本次复验才抓到）；**§7c SGB `runtime_config` 的 `id` 必须恒为 1、
  密钥必须进 `runtime_config_secrets` 加密列**（塞 payload 会 miss credentials）；
  **§7d reasoning 模型 max_tokens 低于阈值 = 200 但正文空 + `finish_reason=length`**（beam 实测 20 空 / 64 起正常）与各服务预算清单。
- `references/role-model-allocation.md` — **用户拿自建/试用 bot 的「多角色模型怎么配」来问时看这篇**：
  连通/延迟、格式遵从、embeddings 端点三类探针的 bash 函数、供应商能力矩阵（含 `哄哄` 不服从严格格式指令、
  多家中转 `/embeddings` 404/503、官方 Gemini `gemini-embedding-001` dim=3072）、
  main/decision/moderation/compress/vision/embed 的分配模板与「跨上游池 fallback / 维度锁定」纪律。
- `references/credential-rotation-staging-and-pruning.md` — **用户说「密钥泄露了，帮我轮换」或「这家还能用吗，不能用就删」时先看这篇**：轮换 vs 删线路的分诊（401 才是 Key 问题，503/11158/quota 是模型或额度问题，某模型家族全挂不等于整条线路该删）、隐藏录入命令的完整配方与 7 项测试矩阵、身份核验表（Bot Token 比 bot id 前缀 + `getMe`；模型 Key 比 `/models` + nonce 推理）、Hermes 消费者切换与撤销顺序、**只裁剪部分失效模型的块级行手术 + 全文档等值断言**。
- `templates/credential_stage.py` — 上述隐藏录入命令的可复制起点：零密钥参数、非 TTY 拒绝、`O_EXCL` + `0600` 暂存、拒绝旧值/重复暂存/身份核验失败、异常不回显；只改顶部 CONFIG 段即可换成新 provider。
- `references/secret-env-write-handoff.md` — **用户说「密钥我自己输，给我 ssh 指令」时先看这篇**：
  root/ubuntu 两个 `~/.hermes` 的差异（root 侧只有骨架、无 `.env`，`~` 写法必然写错位）、可直接粘贴的写入配方
  （路径写死 + `cp ... || true` + `read_text() if exists()` + `re.sub` 用 lambda + 单引号 `python3 -c`）、
  事后三连验证（`stat` mtime / `bash_history` 反查执行账号 / 新老端点各打一次 401 判定 key 是否早已失效）。
- `scripts/probe_endpoint.sh` — 一键探测：连通性 + 服务端模型列表 + 逐个模型 chat 实测
- `scripts/capture_relay_request.py` — **抓包代理**：记录客户端真正发往中转站的请求体，
  判定 `system prompt` / `tools` / 自定义字段有没有被发出去。用户报「人设不生效 / 破甲无效 /
  工具调不起来」时先跑它，别用行为探针定案（行为探针分不清「没传到」和「传到了模型不遵从」）。
  起代理 → 客户端 `baseURL` 临时指向 `127.0.0.1:9999/v1` → `--analyze` 看 `role=system` 在不在。
- `scripts/probe_models_concurrent.py` — 并发实测端点下**全部**模型（ThreadPoolExecutor）+ 区分
  「可用/只有 reasoning 无正文/上游拒绝（含 details.reason）」+ 额外测 `tool_calls`；key 从 `~/.hermes/.env` 按
  `KEY_ENV` 读取不进命令行。把上一条「串行 curl 会超时」的坑直接做成了现成脚本，优先用它。
- `scripts/verify_provider_registration.py` — 离线复现 `/model` 选择界面与 ☰ 命令菜单的真实内容，
  验证新 provider 的菜单落点（不开 Telegram、不靠用户点按钮）；含 `list_picker_providers` 导入路径坑。
- `references/antigravity-gateway-provider-setup.md` — 本地 CLIProxyAPI（反重力）网关接入 Hermes 的完整实录：
  provider 条目（`key_env` 用法）、11 个模型实测数据与首包耗时、同网关 claude 当第一兜底的 fallback 链、
  三层验证法（离线菜单 / `hermes chat -q` / 网关 journal 反证）、cron 预检与会话级覆盖、ToS 封号风险提示。
- `references/append-custom-provider.md` — 追加 provider 的 Python 脚本（含坑位注释）
- `references/hedged-upstream-relay-notes.md` — 「多上游对冲」型聚合站的识别与实测：`All hedged upstream requests failed` 语义、
  `ai.di0.uk`（provider 名 `帝`）9 模型里仅 2 个 GLM 可用的完整矩阵、`/api/user/self` 401 不等于 key 废、
  挂死模型的超时纪律与最终注册条目。用户丢来一个陌生中转 key 让「试试能不能用」时可先翻这篇。
- `references/true-sota-provider-models.md` — True-SOTA 通道（true-sota.com）8 可用模型清单及 Cloudflare UA 拦截绕过记录。
- `references/same-provider-key-fallback.md` — 同一 Provider 多 Key 额度容灾与自动 Fallback 链配置方案（主备 Key 无缝续航）。
- `references/share-provider-models.md` — Share 通道（sharellm.cn）24 模型实测清单：19 可用 / 5 不可用（含失败原因分类）。未来会话引用此清单可免重新探测；用户指定\
- `references/zhipu-provider-models.md` — 智谱 AI（open.bigmodel.cn）端点配置与 GLM-4 / GLM-5 全系列实测可用模型清单。
- `references/router-ai-claude-provider-notes.md` — Router.ai 端点配置、Claude 原生 Bedrock 链路（`toolu_bdrk_` 真实 Tool Calling 结构）实测及模型清单。
- `references/empero-free-provider.md` — Empero 免费社区端点（free.empero.org）配置、模型状态（glm-5.3-flash / qwen3.8-flash）及注意事项。
- `references/router-ai-provider-notes.md` — Router.ai（9的白嫖）端点配置、Claude 原生 Bedrock 特征、12 个实测模型清单与公共 Key 瞬态失效处理。
- `references/atria-provider-notes.md` — Atria ASI（api.atria-asi.ai）端点配置、上海 AI Lab 底座 Atria-Dawn-Preview 深度推理模型评测与 CoT 特性记录。
- `references/dddai-provider-models.md` — DDDAI 通道（api.dddai.dev）端点配置、gpt-6-luna / gpt-5.6-luna 实测可用清单、Codex 底层特征（reasoning_tokens 实测可见）、Cloudflare WAF UA 拦截绕过、**单并发 1 Concurrency 与 Hermes auxiliary 标题生成冲突根因及处置策略**。
- `references/newfouapi-provider-models.md` — NewFouAPI 通道（<YOUR_PRIVATE_DOMAIN>）端点配置、16 可用模型清单及 Tool Calls 实测记录。
- `references/lfree-bot-provider-notes.md` — LFree（New API Bot 聚合专线）端点特征、完整子路径路由（/bot/<id>/v1）、8 可用模型清单及 Tool Calls 实测记录。
- `references/new-api-bot-routing-endpoints.md` — New API / One API 聚合应用（Bot/渠道专线，形如 `/bot/<id>`）端点识别、401 令牌隔离陷阱、OpenAI Base URL 构造规范与工具调用实测。
- `references/nofx-justwoker-provider-notes.md` — NOFX（gpt-5.6系列/生图隔离）与 Justwoker（claude-opus-5体系/New API）端点配置与实测记录；**含「用户要求换成 Claude 模型」的多通道择优落地路径**：justwoker 主备 Key 双失效（余额负 + Invalid token）、本地 CPA 网关 Claude 报 `max_tokens must be greater than thinking.budget_tokens`（curl 通但 Hermes 不通，Hermes 自带提示会误导去降 max_tokens）、最终 Share 通道 `claude-opus-5` 可用。用户说「换成 Claude」时先看这篇。
- `references/nofx-provider-models.md` — NOFX 通道（nofx.one）端点配置、gpt-5.6 全系列模型实测清单、生图模型隔离与 403 余额排障记录。
- `references/reasoning-effort-not-delivered-to-relays.md` — ⚠️ **必读**：`agent.reasoning_effort` 对中转站是空操作（`_supports_reasoning_extra_body()` 白名单制）、用 `reasoning_tokens` 实测判定思考是否真发生、会话级 `model_override` 优先于全局默认；附 Cloudflare 裸 UA 伪装成 403 密钥失效、New API 真实余额只能从 403 报文读出的两个高复用坑。用户说「开到最大思考模式」时先看这篇。
- `references/gemini-proxy-38-migration.md` — gemini-proxy（本地 8317）全盘切换 gemini-3.8-flash-high 的三处落点记录（全局默认/群覆盖/provider 主模型）与「默认 vs 覆盖」判定链。
- `references/prank-honeypot-endpoint-detection.md` — 恶搞/钓鱼端点（Prank/Honeypot Endpoints）识别特征：捏造未来模型、固定 ASCII 字符画劫持响应、mock 思维链等辨识准则。
- `references/google-official-gemini-provider.md` — ⚠️ **官方 Gemini API 接入正解**（替代已被 Google 禁止第三方接入的 antigravity 网关）：`AQ.` 前缀 key（不再只是 `AIza`）获取与地区限制、用内置 gemini provider（GOOGLE_API_KEY）而非 custom_providers、`reasoning_effort: max` 会被官方 API 400 拒绝（只能是 high/low/medium/minimal/none）、删除 antigravity/gemini-proxy 完整清单（config 三处 + auth.json + systemd + 归档）。附加两个坑：**免费档 429 配额陷阱**（列模型 200 但生成全 429 = 高频探测打爆 RPM/RPD，非 key 失效；AQ 新 key 有 429 limit:0 已知 bug）与 **别名不进 /model 菜单**（菜单只列 provider+模型，用 `/model 别名` 带参命令）。
- `references/gemini-quota-alias-pitfalls.md` — 官方 Gemini API 两个补充坑点实录：免费档 429 配额打爆判定（列模型通=key 活着、quota exceeded vs API key not valid、RPM 分钟恢复/RPD 太平洋午夜重置、AQ key 429 limit:0 已知 bug）与用户自定义别名不进 /model inline 菜单（用带参命令切换）。
- `references/frontier-model-selection-benchmarks-2026.md` — 业界前沿主流模型基准（Claude Opus 4.6+/Gemini 3.8/GPT-5.5/Grok 4.1/DeepSeek）与场景化选型决策参考，避免使用旧世代老黄历误导。
- `references/antigravity-validation-required.md` — antigravity `VALIDATION_REQUIRED` 排障实录：重新 OAuth（免隧道手动粘贴回调）、plt 死循环、client_secret 提取；**最终结论：antigravity 第三方接入违反 Google 服务条款会被封号，正解是切官方 API key**。
- `references/provider-url-key-rotation-audit.md` — **用户说「这家的 url 和 key 都换掉，所有用到的地方都同步」时先看这篇**：
  先只读盘点再动手的判据（本次 URL 早已迁移、真缺口只有 key）、周三/ikun → `token.thxnk.cc` 的 5 处活引用表
  （config 两份 base_url 副本 / `.env` 的 `IKUN_API_KEY` / 群霸 `ai_endpoints.json` / `seed_models.py`）、
  跨机（vps-la / vps-hk / aliyun / diaomao）零引用的核对结果、必须排除的噪声目录清单、
  「不要 source 整份 `.env` 再 curl」、「`/v1/models` 与 `/chat/completions` 鉴权结论可能不一致」两个探测坑与汇报模板；
  **二段已补「拿到新 key 之后」的全套**：root-only 最小可粘贴配方（`read -rsp` + `chown ubuntu` + `chmod 600`）、
  **热生效 vs 必须重启的判定表**（自建 bot `_read_env_val`/`_resolve_pool_key` 每次读文件 → 热生效；
  Hermes 启动时 dotenv → gateway 必须重启）、`/proc/<pid>/environ` 查不到 dotenv 变量与
  `pgrep -f` 匹配到自身命令行的两个取证假象、四层验收阶梯（models 200 → chat `max_tokens`≥200 →
  `hermes -z ... --provider 名 -t ''` → gateway active）。
- `references/provider-endpoint-migration-fanout.md` — **用户说「这个 provider 的 url / key / 模型都换一下」或
  「所有之前用 X 的都替换掉」时先看这篇**：12 类落点清单（config 两份 base_url 副本 / bot `ai_endpoints.json` /
  源码里硬编码 hostname 的两处剥 name 门控 / 两份记录型 patch 的 `+` 行 / 两份 patch-guard 的 marker+gate /
  探针与一次性部署脚本）、`git apply --reverse --check` 与 `patch_guard --check` 的验收口径、
  「改哪份 / 哪份按历史保留」的边界、七层验收阶梯，以及 GLM reasoning 吃光 max_tokens 与
  上游 `sqlite3: database is locked` 403 两个瞬时坑。
- `references/ikun-provider-models.md` — ikun撸时涵 通道（<YOUR_PRIVATE_DOMAIN>）端点配置与实测：**Cloudflare error 1010 浏览器签名黑名单（必须 extra_headers 伪装 UA，非额度问题）**、模型 ID 带空格大小写（`Deepseek V4 Flash`）小写写法一律 503、4 模型充值前后对比实测、reasoning_content 判定法（该站不透出 reasoning_tokens）。
- `references/session-model-verification.md` — 会话实际模型核验（用户问「你现在什么模型 / 现在呢」时）：`session_model_usage` 取证 SQL、会话级 vs 全局默认切换判定表、`billing_base_url` 反查 provider 线路、2026-10-15 gemini→`cn:deepseek-v4.1-flash` 切换实录与可复用汇报口径。
- `references/workbuddy-gateway-pool-and-model-matrix.md` — **用户问「XX 里模型还能用吗 / 有哪些能用 / 我还有账号没登录」时先看这篇**：WorkBuddy2API `/status` 端点字段语义（`realm_totals` / 每账号 `credits` / `reason`）、`no_healthy_account` 的**两种成因**（并发瞬态 vs 该 realm 账号全封禁）判定、三态响应归类（`400 model_unavailable` 无路由 / `503 no_healthy_account` 无号 / `503 11158` 无档位）、**单账号池并发伪造「只剩 1 个可用」实测**、2026-11-08 `global:*` 17/35 实测矩阵与 2026-10-20 对比漂移、面板 `/panel/`（回环 7863，SSH 隧道）与 `login --realm=cn|global url|poll` 补账号流程、汇报纪律。
- `references/self-hosted-gateway-credential-lookup.md` — **用户要「某线路的 url 和密钥」时先看这篇**：口语化 provider 别名（腾白嫖/反重力/呆布）的归属判定链（config.yaml → key_env → `.env` → `getent hosts` → `~/.ssh/config` → 节点上的 systemd/部署目录 → 带 key 实测）；WorkBuddy2API（`capy.<PRIVATE_IDENTIFIER>:2087` = 自有 `vps-la`、`/opt/workbuddy2api-panel`、内网 7863）完整拓扑；自有部署 vs 第三方中转的凭据披露边界与交付模板。
- `references/relay-model-inventory-audit.md` — **运维 Bot 报「AI链路告警 / 模型回退次数超限」时先看这篇**：`ai-model-healthcheck.py` 告警机制（扫 `Fallback activated:`、30 分钟窗口 ≥2 次）、probe 校验令牌与 17s 超时对 thinking 模型偏紧、回退告警真实根因链（幽灵模型条目 → 503 11158 → 烧 2 次重试 → 连带打挂 auxiliary）、**并发探测伪造「全灭」事故（49/52 假 503）与串行 ≥3.5s 复测铁律**、腾白嫖 31 个 `global:*` 完整实测矩阵、带行号内容校验的安全删除流程；**⑦「解决它」之后的 fallback 链重建**（反重力 16 模型实测、codex 账号池整批 429 → 兜底必须跨上游池、`fallback_providers` 字符串化后的行级替换修复）；**⑧ 探测污染 `cpa_inference` 监控的误报机制**（`fail_after=1`、Agent 自身请求被计入、恢复算术与向用户披露口径）。
- `references/ollama-proxy-provider-setup.md` — 远端 ollama 通过面板 /v1/* 透传接入 Hermes 的完整实录（InstaBox 实例）：thinking 字段剥离代码、provider 注册模板、字符串列表 vs 字典列表坑、config 损坏恢复流程、全链路验证命令。⚠️ **该实例已于 2026-10-23 被用户全量回滚（小模型扛不住 2050 token system prompt），文件顶部有废止说明；三条通用坑仍可复用。**
- `references/provider-removal-rollback.md` — **用户说「模型相关全部回滚 / 不要了」时先看这篇**：7 处引用点清单（容器/镜像/模型卷/面板代理/provider/.env key/CLI 子命令/技能文档）、`sudo -n` 删 root 卷残留、横切功能「重写 > 20 次 patch」决策规则、接口级验收断言（应下线接口必须 404）、实测回收数字（磁盘 4.7→17.9 GiB、内存 94.9%→8.0%）。
