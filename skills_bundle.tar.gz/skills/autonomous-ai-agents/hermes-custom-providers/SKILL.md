---
name: hermes-custom-providers
description: "为 Hermes 添加自定义 OpenAI 兼容模型端点（中转站/API 代理）并测试可用性。"
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [hermes, providers, custom-endpoint, openai-compatible, config]
    related_skills: [hermes-agent]
---

# Hermes 自定义 OpenAI 兼容 Provider 配置

## When to Use

用户给出一个 OpenAI 兼容端点的 `base_url`（如 `http://host:port/v1`）+ API key + 模型列表，要求"装上 / 配置 / 测试能不能用"。典型来源：中转站、API 代理、内网推理服务。也适用于在 Hermes 中新增任何 custom provider 端点（含已有 provider 的扩展）。

这类端点一律注册为 `custom_providers` 列表条目。

## 标准流程

1. **探测端点**（先于一切配置）：
   ```bash
   curl -s -m 15 -o /dev/null -w "HTTP %{http_code} 耗时 %{time_total}s\n" "$BASE/v1/models" -H "Authorization: Bearer $KEY"
   ```
   ⚠️ 安全扫描会把 `curl ... | python3 -c` 判为 HIGH「Pipe to interpreter」，虽 smart approval 会放行，但批量探测优先写成 .py 文件执行，避免每条命令都被拦一道。
2. **拉取服务端真实模型列表**（`GET /v1/models`）。**用户给的模型名 ≠ 服务端有的**：本次用户列了 6 个，服务端实际只支持 4 个，另外 2 个返回 `model_not_found`。
3. **逐个实测模型**（chat completions，不要只看列表）：
   ```bash
   curl -s -m 60 "$BASE/v1/chat/completions" -H "Authorization: Bearer $KEY" -H "Content-Type: application/json" \
     -d '{"model":"<m>","messages":[{"role":"user","content":"回复两个字：能用"}],"max_tokens":20}'
   ```
   - 返回 `choices` → 可用
   - `error.type == "model_not_found"` → 该模型名不支持，不注册，向用户如实报告
   - `error.type == "upstream_error"` → **暂时性故障，重试一次再判定**（本次 gemini-3.1-pro-preview 首测失败、重试成功）
4. **写 key 到 `~/.hermes/.env`**：`<NAME>_API_KEY=sk-...`（如 `FRP3_API_KEY=...`），不写进 config.yaml。
5. **追加 provider 到 `custom_providers`** —— ⚠️ 不能用 `hermes config set`（见 Pitfalls），用 `references/append-custom-provider.md` 里的 Python 脚本。
6. **用 Hermes 真实链路验证**（比 curl 多验证 provider 解析）：
   ```bash
   hermes chat -q "直接回复：能用" --provider "Frp3.ccszxc.xin" -m "deepseek-v4-flash"
   ```
   每个可用模型各跑一次。输出含回复框即通过。
7. 改配置前先备份：`cp ~/.hermes/config.yaml ~/.hermes/config.yaml.bak-$(date +%Y%m%d%H%M%S)`；改完跑 `hermes config check`。
8. **离线验证「菜单落点」**（新 provider 是否真进了 `/model` 切换界面与 ☰ 命令菜单）——跑
   `scripts/verify_provider_registration.py <provider子串>`，见下节。

### 注册后离线验证「菜单落点」（不要靠用户去客户端翻菜单确认）

用户说「菜单和切换模型的界面都加上」时，两处落点由**同一份 provider+models 数据**驱动，离线就能验完：

```bash
~/.hermes/hermes-agent/venv/bin/python3 <skill>/scripts/verify_provider_registration.py 反重力
# 期望：① /model 选择界面里出现「反重力 (N 个模型)」并逐条列出模型名
#       ② ☰ 命令菜单注册条数 + 含 /model: True
```

- **导入路径坑（实测踩到）**：`list_picker_providers` 定义在 `hermes_cli.model_switch`，**不在** `hermes_cli.providers`
  （导错模块直接 `ImportError: cannot import name 'list_picker_providers'`）。gateway 里那段是函数内 import，
  grep 到的行所在模块 ≠ 定义模块，别照抄。
- ☰ 命令菜单**只能放命令，放不了模型**（Telegram BotCommand 限制）。模型一律经 `/model` 进入，`/model` 已靠
  `platforms.telegram.extra.command_menu.priority`（prepend）置顶。用户要「一键直达」时只能加**无参插件命令**
  （如 `/g38`，带参命令会被菜单生成器跳过）；如实说明「菜单里放不了模型」，别假装修好了。
- 群聊菜单是 **adapter.py 里硬编码的 6 条**（`help/model/stop/summary/clear/whoami`），不接受配置注入——
  用户要求给「群菜单」加条目时先说明这点，别去改 command_menu 配置空转。
- 菜单改完不必重启 gateway：Telegram 端在 post-connect 任务里调 `setMyCommands`，下次连接自动刷新。

### 本地 loopback 网关接入（CLIProxyAPI / 自建中转）的三个专属要点

1. **密钥走 `key_env`**：provider 条目写 `key_env: <NAME>_API_KEY`（值进 `~/.hermes/.env`），同时把主 model 块的
   `base_url`/`api_key` 清空，否则旧主模型的残留端点会覆盖新 provider。
2. **同网关换模型当第一兜底**：本地网关下挂多模型时，`fallback_providers` 第一条用**同一 base_url 的另一个模型**
   （如 gemini 主用 + 同网关 claude 兜底）。Gemini 上游对多轮函数调用角色交替校验严苛（400），同网关 Claude 立即
   接管且**不增加故障域**；网关整体挂掉才落到链尾的外部 provider。
3. **网关侧反证**：`sudo journalctl -u cliproxyapi --since "5 min ago" --no-pager | grep POST`
   要看到 `200 ... POST "/v1/chat/completions"`，才能确认流量真走网关而**不是静默 fallback 到别人**。
   （同段日志里的 `404 GET /props`、`404 GET /version` 是客户端能力探测噪音，正常。）
   完整实录、11 模型实测数据与三层验证法见 `references/antigravity-gateway-provider-setup.md`。

## 切换全局默认模型 + 配置 fallback 链（非交互）

用户要求"把主模型换成 X / 备用模型设成 Y"时（或 /model 切换后回 `--global`），全套非交互改法：

### 1. 切全局默认模型

```bash
hermes config set model.default <model>
hermes config set model.provider custom
hermes config set model.base_url <endpoint>/v1
hermes config set model.api_key "$(grep -E '^<KEY_ENV>=' ~/.hermes/.env | head -1 | cut -d= -f2- | tr -d '"' | tr -d "'")"
```

- `model.api_key` 直接写明文进 config.yaml（与 custom_providers 用 key_env 引 .env 不同，主 model 块只认 api_key 字段）。
- **调节全局默认思维强度（Reasoning Effort）**：
  切换主模型时，如需同步固化全局思考强度，使用：
  ```bash
  hermes config set agent.reasoning_effort <none|minimal|low|medium|high|xhigh|max|ultra>
  ```
  CLI 会自动持久化到 `config.yaml` 的 `agent.reasoning_effort` 键下（运行时对话中也可直接通过 `/reasoning <level> --global` 固化，或直接通过 `/reasoning` 呼出交互式按钮面板点选）。

  ⚠️ **致命认知：`reasoning_effort` 对绝大多数 custom provider（中转站）是空操作，改了不等于生效。**
  `run_agent.py::_supports_reasoning_extra_body()` 是**白名单制** —— 只有 `nousresearch.com` / `ai-gateway.vercel.sh` / `models.github.ai` / `githubcopilot.com` / `ollama.com` / lmstudio provider / **base_url 含 `openrouter`** 才会把 reasoning 打进请求体；其余一律 `return False`，`extra_body.reasoning` 整段不生成。
  而 `resolve_reasoning_config()` 与这个 gate **完全解耦**，照样返回 `{'enabled': True, 'effort': 'max'}` —— 配置文件、`/reasoning` 面板、`hermes config get` 三处全显示 max，**唯独线上请求没这个字段**。光读配置发现不了。
  **唯一可信判定：发一次最小请求读 `usage.completion_tokens_details.reasoning_tokens`**，>0 才是真思考。2026-09-04 实测 justwoker `reasoning_tokens=0`（顶层 `reasoning_effort` / `thinking` 字段还会直接 403），本地 CPA gemini-proxy `reasoning_tokens=80` ✅。
  用户要求「开到最高思维」时，先查会话实际绑定的 provider，走中转站就**如实告知档位不可控**并建议切白名单端点 —— 绝不要改完配置就报「已开到最大」。完整机理、取证代码与实测矩阵见 `references/reasoning-effort-not-delivered-to-relays.md`。
- **从旧 provider 切到已注册的 custom provider 时必须清掉残留的 `model.base_url` / `model.api_key`**：只改 `model.default` + `model.provider` 不够——旧主模型（如 gemini-proxy 的 `http://localhost:8317/v1` + 旧 key）的 base_url/api_key 字段会**残留覆盖**新 provider 的端点，文档视角看似已切换、实际还在打旧地址或旧 key。清法：
  ```bash
  hermes config set model.base_url ""
  hermes config set model.api_key ""
  ```
  清空后主模型走 custom_providers 条目自身的 base_url + key_env（如呆布 → TAGAA_API_KEY）。改完 `hermes config get model` 应显示 `provider: 呆布` 且 base_url/api_key 为空，再用 `hermes chat -q` 实测。
- **「全局默认」≠「所有会话」——channel_overrides 不跟随全局切换**：`model.default` 只对无覆盖的会话生效；`telegram.channel_overrides` 里绑定的群/私聊（如 `-1004495899387`）仍走自己的覆盖值。用户问"重置后为什么不是模型 X"多半卡在这一层；用户说「全盘覆盖 / 所有地方都用 X」时必须同步三处：① `model.default` + `model.provider`；② 各 `channel_overrides` 条目的 `model`；③ custom provider 条目自身的 `model` 字段。`models` 可用清单里的旧版本条目（如 gemini-3.7）**保留不动**——那是 `/model` 手动切换的候选，不影响默认值。改完 `grep -n '<model-name>' ~/.hermes/config.yaml` 逐处核对落点。
- 改完用 `python3 -c "import yaml; ..."` 读回验证 default/base_url/api_key 是否落盘。

### 2. 配 fallback 链（备用模型）

**不要用 `hermes fallback add`**——它是交互式 picker（`_require_tty`，非交互直接报错）。直接写 `fallback_providers` 列表：

```python
import sys; sys.path.insert(0, '/home/ubuntu/.hermes/hermes-agent')
from hermes_cli.config import load_config, save_config
cfg = load_config()
chain = cfg.get('fallback_providers') or []
chain.append({'provider': '<名称>', 'model': '<model>',
              'base_url': '<endpoint>/v1', 'api_mode': 'chat_completions',
              'key_env': '<KEY_ENV>'})  # 或 api_key 明文
cfg['fallback_providers'] = chain
cfg.pop('fallback_model', None)  # 清旧字段
save_config(cfg)
```

- entry 合法字段：`provider`（必填，可写 custom_providers 里的名称）、`model`（必填）、`base_url`、`api_mode`、`api_key`/`key_env`（二选一；key_env 通过 secret_scope 解析）。
- 验证：`hermes fallback list` 应显示 `Primary: X → Fallback chain: Y`，且各 entry 带 base_url。

### 3. cron 任务模型快照会 fail closed（必踩坑）

**切默认模型前先预检**（比事后修更省事）：直接读 `~/.hermes/cron/jobs.json`，逐条打印
`name / enabled / script|prompt / model_snapshot`：

```python
import json
jobs = json.load(open('/home/ubuntu/.hermes/cron/jobs.json'))
jobs = jobs if isinstance(jobs, list) else jobs.get('jobs', [])
for j in jobs:
    print(j.get('id'), j.get('name'), j.get('enabled'), bool(j.get('script')), j.get('model_snapshot'))
```

全为 `None`（脚本型 / no-agent job 不存快照）即可放心切；有非空快照的 agent 型 job 必须切完立刻修。
（2026-09-10 实测：7 个 job 全 `None`，切默认零风险 —— 先预检就不用被 `config set` 的警告吓一跳。）

切全局默认模型后，`hermes config set` 会警告："N enabled unpinned cron job has stored model_snapshot values that differ"。存了旧快照的 agent 型 cron 下次运行会**拒绝执行**而不是静默换模型。修复：

```bash
hermes cron edit <job_id> --model <新模型> --provider custom
```

- `hermes cron edit` 支持 `--model`/`--provider`（`cronjob` 工具 schema 没有这两个字段，必须走 CLI）。
- 修完查 `~/.hermes/cron/jobs.json` 确认该 job 的 `model_snapshot` 已变/清空。
- no-agent 脚本型 job 没有快照，不受影响；只修 agent 型（有 prompt 的）job。

### 4. 实测新链路

对主模型端点发一次最小 chat 请求验证 key 和模型名都通（urllib/curl 皆可），再 `hermes fallback list` 确认链结构。别只信配置落盘——要实测到 `choices` 返回。

## 故障分层诊断（"模型有问题"时先定位在哪一层）

用户报"模型链接有问题/检查一下模型"时，**先判断故障层，不要一上来怀疑模型**：

1. **DNS 解析**：`getent hosts <host>` — 解析失败是域名问题
2. **TCP 连通性**：`curl -s -m 15 -o /dev/null -w "HTTP %{http_code}" "$BASE/models"` 返回 `HTTP 000` 或 `curl: (28) Connection timed out` → **网络层不通**（对端服务挂了 / 防火墙 / 安全组），与模型无关，排查网络而非模型
3. **HTTP 层错误**（能拿到 JSON error）→ 才进入模型层判断：
   - `authentication_error` / `API_KEY_REQUIRED` (401) → key 缺失、未带 Bearer 前缀或格式不合规
   - `INSUFFICIENT_BALANCE` / `insufficient_quota` (403) → key 有效但账户/Token 余额不足或未分配配额（New API 如 justwoker 余额变负直接阻断）。⚠️ **注意**：部分 Gateway（如 nofx - AI API Gateway 等）在余额不足时连 `GET /v1/models` 也会直接拦截返回 403，导致无法拉取模型列表，切勿误判为域名或网络故障
   - `GROUP_DISABLED` (403) → API Key 所属分组已在服务商后台停用（如 true-sota.com），整组 Key 完全失效
   - `ModelAccountTpmRateLimitExceeded` / `inference tpm exhausted` (429) → 账号在该特定模型上的 TPM（每分钟 Token 配额）已耗尽，非全局网络问题
   - `model_not_found` / `model route not found` (404) → 模型名不支持或上游服务商已下架（常引发自建/免费中转代理连带爆发 502 `upstream_error`）
   - `upstream_error` → 上游暂时故障，重试一次再判定（本次 gemini-3.1-pro-preview 首测失败、重试成功）
   - `bad_response_status_code` / `openai_error` → 模型在列表里但该模型路由故障（本次 LongCat-2.0）
   - `api_error` + code 10110 "engine is overloaded" → 渠道过载，**瞬态**，稍后重试可能恢复（本次 kimi-k2.6）
   - 中文错误消息如"获取绑定路由中模型可用渠道失败" → 该模型无可用上游渠道，暂不可用（本次 gpt-5.6-terra）
4. **空回复 + `finish_reason: length`** → 可能是推理模型思考占满 max_tokens（见 Pitfalls），不是故障
5. **空响应（curl 无输出/超时）** → 单次超时不能判死：同一端点其他模型正常、仅个别模型超时 = 该模型渠道慢/挂，重试一次再判定（本次 kimi-k2.7-code、mimo-v2.5-pro 超时但同批其他模型全通）

**服务端模型列表 ≠ 全部可用**：`GET /v1/models` 返回的 24 个模型里实测只有 19 个可用——列表是"宣称支持"，实际可用性必须逐个 chat 实测（本次 5 个失败：路由故障/渠道故障/过载/超时各占一二）。批量测试时把失败项分类记录（瞬态 vs 永久），永久失败不注册，瞬态失败可标注"稍后可能恢复"。

**诊断线索**：多个端点同时 TCP 超时、且端点都是国内 IP（frp 中转站、sensenova 等）而国际端点（api.deepseek.com）仍通 → 高度提示**实例网络出口/安全组问题**（常见于 AWS 换机型/迁移后），不是模型故障。此时优先检查安全组出站规则。

## 付费官方渠道误烧防线与 Fallback 链审计（2026-09-11 实测：官方 DeepSeek 被静默扣费）

**核心铁律：`fallback_providers` 链里严禁放入「用户付费的官方渠道」当兜底。**
Hermes 的 fallback 机制在主模型 429/403/502/网络抖动时**自动顺链滑落**，
一旦链中有真实付费 key（如官方 `api.deepseek.com`），会在用户毫无感知的情况下持续烧钱。

### 误烧的真实链路（justwoker 案例）
1. 用户切到中转站（justwoker）模型 → 该站 Cloudflare WAF 对机房 IP 硬拦截，`POST /chat/completions` 恒 403；
2. Hermes 判定主模型故障 → 触发 fallback 链：反重力 429 → 日日新 429 → **链尾官方 DeepSeek 命中**；
3. 结果：聊天看似正常，实际每一轮都在扣官方余额（`state.db` 记录上百次静默调用）。

### 审计真实调用量（不靠猜）
```python
import sqlite3
conn = sqlite3.connect('/home/ubuntu/.hermes/state.db')
# 每个 provider/model 的真实调用次数与 token（找出谁在烧钱）
conn.execute("SELECT model, billing_provider, billing_base_url, api_call_count, input_tokens, output_tokens "
             "FROM session_model_usage ORDER BY last_seen DESC").fetchall()
# 会话级持久化 model_override（覆盖全局默认的关键！）
conn.execute("SELECT session_key, entry_json FROM gateway_routing "
             "WHERE session_key LIKE '%<chat_id>%'").fetchall()
```
- 网关日志 `Rehydrated persisted /model override for session=...` 出现即证明该会话绑定了旧的持久化覆盖；
- 判断「实际在打哪个端点」以 `state.db` / 网关日志的 `provider=custom:xxx base_url=...` 为准，不要信配置文件表面。

### Fallback 链编辑的两个 CLI 陷阱
1. **`hermes fallback remove <名称>` 不接受位置参数**：`unrecognized arguments`。`hermes fallback add` 是交互式 picker（非 TTY 报错）。要改链只能 Python 直写 YAML。
2. **`hermes config set fallback_providers '[{...}]'` 会把 JSON 字符串当字符串存**：落盘变成 `fallback_providers: '[{"provider":...}]'`（带引号），
   `hermes fallback list` 立刻显示 `No fallback providers configured` —— 整条链静默丢失。
   正解：用 `yaml.safe_load` 读原文件 → 赋真正的 Python list → `yaml.dump` 写回（保留 `allow_unicode=True, sort_keys=False`），
   然后 `hermes fallback list` 验证链结构。

### 云端机房 IP 段被中转站 Cloudflare WAF 整段封锁与额度判定
- **现象**：在云端服务器（AWS / 海外 VPS）调用中转站（如 `api.justwoker.icu`），`GET /models` 正常 200，但 `POST /chat/completions` 无论使用 curl、Python-requests、Chrome 伪装 UA、甚至 curl_cffi 模拟 TLS 浏览器特征，恒定返回 HTTP 403 `Attention Required! | Cloudflare: Sorry, you have been blocked`。
- **根因辨析**：站长在 Cloudflare 后台对对话端点开启了数据中心机房 ASN / IP 黑名单，**与用户账户额度无关**（用户账户内额度可能非常充足，在本地电脑浏览器或家宽环境下调用完全正常）。
- **避坑处置**：切勿将此类被 WAF 硬拦截的端点保留为主模型，否则不仅主模型不可用，还会频繁触发 Fallback 链，若 Fallback 中存在付费官方通道（如官方 DeepSeek）会造成隐蔽静默扣费。此类通道仅推荐在本地客户端使用，或向站长索取免盾专线域名。

### 同名模型多供应商会选错
多个中转站（如 nofx 与 justwoker）都暴露 `gpt-5.6-terra/luna/sol` 等同名模型时，
按模型名切换可能落到**余额不足的那一家**（403 后触发上面的 fallback 误烧链）。
处置：切换时显式带 `provider` 或 `base_url`；保留多个同名 provider 时以 provider 名称为锚，不要只认模型名。

### 防御性配置（一次做对）
- fallback 链只放免费/本地端点（如本地网关另一模型、免费中转），链尾**显式**以「报错停住」替代付费兜底；
- 用户要求「绝不再碰官方 key」时，直接清空 `fallback_providers` 中对应条目并复查 `hermes fallback list`；
- WAF 硬拦截的端点（/models 200 但 /chat/completions 恒 403）**严禁保留为主模型**——见上文 justwoker 案例。

## Pitfalls

- **批量并发探测与超时控制**：当 Provider 下挂载数十个模型（如 Share / 中转站包含 30+ 模型）时，严禁用串行循环 curl 逐个探测，会导致执行超时（180s+）。应使用 Python `ThreadPoolExecutor`（设置 worker 10~15，单次请求超时 15~30s）并发探测。⚠️ **注意中转站 RPM 限流与长思考模型**：
  - 中转站往往有严格的请求频次限制（如 ShareLLM 限制 20 次/分钟），并发过猛会导致大批模型瞬间报 `HTTP 429 您已达到请求数限制` 造成假死误判。对 429 报错必须采用单线程带退避间隔（如 `sleep(3.5)`）重测。
  - 高思考/高推理模型（如 `gemini-3.6-flash-high`）因生成大量 reasoning tokens，首包耗时可能超过 20s，超时时间若低于 20s 会抛 `timed out` 误判为坏死。此类模型探针超时应放宽至 35s+。
- **`extra_headers` 类型安全**：配置中的 `extra_headers` 可能是字典 `{...}`，也可能是字符串 `"{}"` 或空值。解析时需先做类型判断与 `json.loads` 兜底，避免 `headers.update()` 报序列长度错误。
- **本地服务公网 IP vs 本地 Loopback (localhost) 连通性差异**：自建网关（如 CLIProxyAPI 8317 端口）如果在同一机器上运行，必须优先配置 `localhost:8317`。配置公网弹性 IP 会因云厂商（如 AWS EC2）入站安全组未开放该端口导致丢包超时，而本地 loopback 通信完全不受安全组阻拦。
- **特殊模型参数限制与生图模型分类**：
  - 部分模型（如 `kimi-k3`）强制要求 `temperature=1`，传入 0.1 会抛 400 错误。
  - 生图专用模型（如 `gpt-image-1/1.5/2`）不支持 `/v1/chat/completions` 端点，探测时会返回 400，需与文本/聊天模型分开管理。
- **WAF / Cloudflare 拦截默认 SDK User-Agent（403 Blocked）**：
  - **云机房 IP 段整段被 WAF 阻断 vs 额度充足（`justwoker.icu` 案例）**：
    - 现象：`GET /v1/models` 正常 200 并返回模型列表，但在机房（AWS/海外 VPS）发起 `POST /v1/chat/completions` 时，无论换用何种浏览器 UA、哪怕 curl_cffi 模拟真实 Chrome124 TLS 特征，甚至走海外住宅代理，依然 100% 返回 Cloudflare 403 `Attention Required! | Sorry, you have been blocked`。
    - 根因：中转站站长在 Cloudflare 后台对聊天接口开启了**机房 ASN / 数据中心 IP 级硬拦截**；此时用户账户内往往**额度充足**，在本地电脑浏览器或国内家宽下均可正常使用，唯独云服务器被封死。
    - 处置红线：严禁误判为“账户欠费”；切勿将此类被 WAF 硬阻断的端点保留为主模型，否则请求立刻触发 Hermes 自动降级（Fallback Chain）并可能误烧下游付费通道（如官方 API）。
  - **配置级修复（Hermes 官方支持，feature #40033）**——给该 custom_providers 条目加 `extra_headers`，SDK 每次请求自动携带替换掉的 UA，不用改代码：
    ```bash
    hermes config set custom_providers.<N>.extra_headers '{"User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/126.0 Safari/537.36"}'
    ```
    原理：`hermes_cli/config.py::apply_custom_provider_extra_headers_to_client_kwargs` 把这些头 merge 进 OpenAI client 的 `default_headers`，provider 级设置优先级最高（`agent/agent_init.py` 里同样有 `agent._apply_user_default_headers()` 支持 `model.default_headers`）。
  - 临时验证：`openai.OpenAI(..., default_headers={"User-Agent": "Mozilla/5.0"})` 能返回即确认是 WAF。
  - ⚠️ **`custom_providers.<N>` 是列表下标、不是名字匹配**：本次误把 extra_headers 加到了下标 0 的「日日新」上（呆布实际在下标 6），失败表象是改到了完全无关的 provider。写之前先 `grep -n "name:\|extra_headers" ~/.hermes/config.yaml` 数清下标，写后复查落盘位置，错则重复设置并清掉误改项（`hermes config set custom_providers.<N>.extra_headers '{}'`）。
  - 改完必须走真实链路验证：`hermes chat -q "直接回复：能用"`；gateway 侧用 `grep -n "403\|blocked\|PermissionDenied" ~/.hermes/logs/errors.log` 确认不再报。辅助任务（标题生成 aux model）与主模型走同一 provider，403 会先出现在 aux 报错里（如 `Auxiliary title generation failed: HTTP 403`），别被带偏以为主链路问题。
  - 注意「切换没生效」≠ 配置没变：gateway 日志里出现 `provider=custom:呆布 base_url=https://cp.tagaa.eu.cc/v1 model=gpt-5.6-luna` 证明切换**已生效**，只是请求被 WAF 拦在 HTTP 层。判断顺序：先看日志里 gateway 实际在打哪个端点，再决定动配置还是动风控。
- **推理模型（deepseek-v4 系）会输出 `reasoning_content` 吃掉 max_tokens**：max_tokens 给 20~80 时 token 全花在"思考"上，`message.content` 为空、`finish_reason=length`，看起来像模型坏了。测试/探测时 max_tokens 至少给 **200+**，或同时检查 `message.reasoning_content` 是否非空再判定。
- **bash 循环里 `python3 -c` 内联代码不能引用外层 bash 变量**：`resp=$(curl ...)` 后管道给 `python3 -c "...resp[:100]..."` 会 `NameError: name 'resp' is not defined`。数据必须走 stdin 或环境变量传进 python，bash 变量名在 python 内联代码里不存在。
- **删除冗余/失效 Provider**：先安全备份 `config.yaml`（`cp config.yaml config.yaml.bak-$(date +%Y%m%d%H%M%S)`），再使用 Python 读取 YAML，从 `custom_providers` 列表中根据 `name` 过滤移除目标项，使用 `from utils import atomic_yaml_write` 原子写入，最后通过 `hermes config check` 验证配置完整性。
- **批量测试要防空响应**：端点超时/挂掉时 curl 输出为空，`json.loads('')` 直接抛 JSONDecodeError 并中断整轮循环。python 里先 `raw=sys.stdin.read(); if not raw: print('❌ 空响应(网络超时)'); sys.exit()` 再解析；整个脚本用 `set -u` + 每请求 `-m 45`，批量循环总 timeout 给足（10 个模型 × 45s ≈ 450s+）。

- **`hermes config set custom_providers.2.name ...` 报 `IndexError: list index out of range`**：CLI 的 `_set_nested` 明确不增长列表（"we do not grow lists"），只能索引已有条目。追加新 provider 必须用 Python 脚本改 YAML。
- **`atomic_yaml_write(path, data)` 参数顺序**：path 在前、data 在后，反了报 `TypeError: expected str, bytes or os.PathLike object, not dict`。
- **导入路径**：`from utils import atomic_yaml_write`（hermes-agent 根目录的 `utils.py`），**不是** `hermes_cli.utils`（不存在）。脚本要用 hermes 自己的 venv python（`~/.hermes/hermes-agent/venv/bin/python3`）跑，且 `sys.path.insert(0, "<hermes-agent 根目录>")`。
- **`read_file` 会脱敏 config.yaml 里的 api_key**（显示 `«redacted:sk-…»`）。涉及密钥的读取/改写一律用 `yaml.safe_load` 直接读原文件，否则会把 `«redacted»` 占位符写回去破坏配置。
- **`hermes model` 需要交互式终端**，管道/非交互下报错 "requires an interactive terminal"。验证用 `hermes chat -q --provider -m` 代替。
- **custom provider 名不能与内置 provider 名冲突**：`--provider gemini` 会命中 Hermes 内置的 gemini（走 `https://generativelanguage.googleapis.com/v1beta`），custom_providers 里同名条目被忽略。`hermes_cli/auth.py` 的 `resolve_provider` 对内置名（gemini/anthropic/openai/xai/kimi 等）优先归一化，custom 候选被跳过。解决：custom provider 用不冲突的名字（如 `gemini-cli`）。实测时看报错里的端点：`Provider: custom + Endpoint: <你的 base_url>` 才是走对；若出现内置端点（如 generativelanguage.googleapis.com）或 "API key not valid" 就是撞名被内置抢了。
- 保留已有 provider：追加而不是重建整个列表。
- 中转站可能同时代理多种厂商模型（deepseek/gemini/claude/gpt），注册时 `models` 列表只放实测通过的。

## 支持文件

- `scripts/probe_endpoint.sh` — 一键探测：连通性 + 服务端模型列表 + 逐个模型 chat 实测
- `scripts/probe_models_concurrent.py` — 并发实测端点下**全部**模型（ThreadPoolExecutor）+ 区分
  「可用/只有 reasoning 无正文/上游拒绝（含 details.reason）」+ 额外测 `tool_calls`；key 从 `~/.hermes/.env` 按
  `KEY_ENV` 读取不进命令行。把上一条「串行 curl 会超时」的坑直接做成了现成脚本，优先用它。
- `scripts/verify_provider_registration.py` — 离线复现 `/model` 选择界面与 ☰ 命令菜单的真实内容，
  验证新 provider 的菜单落点（不开 Telegram、不靠用户点按钮）；含 `list_picker_providers` 导入路径坑。
- `references/antigravity-gateway-provider-setup.md` — 本地 CLIProxyAPI（反重力）网关接入 Hermes 的完整实录：
  provider 条目（`key_env` 用法）、11 个模型实测数据与首包耗时、同网关 claude 当第一兜底的 fallback 链、
  三层验证法（离线菜单 / `hermes chat -q` / 网关 journal 反证）、cron 预检与会话级覆盖、ToS 封号风险提示。
- `references/append-custom-provider.md` — 追加 provider 的 Python 脚本（含坑位注释）
- `references/true-sota-provider-models.md` — True-SOTA 通道（true-sota.com）8 可用模型清单及 Cloudflare UA 拦截绕过记录。
- `references/same-provider-key-fallback.md` — 同一 Provider 多 Key 额度容灾与自动 Fallback 链配置方案（主备 Key 无缝续航）。
- `references/share-provider-models.md` — Share 通道（sharellm.cn）24 模型实测清单：19 可用 / 5 不可用（含失败原因分类）。未来会话引用此清单可免重新探测；用户指定\
- `references/zhipu-provider-models.md` — 智谱 AI（open.bigmodel.cn）端点配置与 GLM-4 / GLM-5 全系列实测可用模型清单。
- `references/empero-free-provider.md` — Empero 免费社区端点（free.empero.org）配置、模型状态（glm-5.3-flash / qwen3.8-flash）及注意事项。
- `references/lfree-bot-provider-notes.md` — LFree（New API Bot 聚合专线）端点特征、完整子路径路由（/bot/<id>/v1）、8 可用模型清单及 Tool Calls 实测记录。
- `references/new-api-bot-routing-endpoints.md` — New API / One API 聚合应用（Bot/渠道专线，形如 `/bot/<id>`）端点识别、401 令牌隔离陷阱、OpenAI Base URL 构造规范与工具调用实测。
- `references/nofx-justwoker-provider-notes.md` — NOFX（gpt-5.6系列/生图隔离）与 Justwoker（claude-opus-5体系/New API）端点配置与实测记录；**含「用户要求换成 Claude 模型」的多通道择优落地路径**：justwoker 主备 Key 双失效（余额负 + Invalid token）、本地 CPA 网关 Claude 报 `max_tokens must be greater than thinking.budget_tokens`（curl 通但 Hermes 不通，Hermes 自带提示会误导去降 max_tokens）、最终 Share 通道 `claude-opus-5` 可用。用户说「换成 Claude」时先看这篇。
- `references/nofx-provider-models.md` — NOFX 通道（nofx.one）端点配置、gpt-5.6 全系列模型实测清单、生图模型隔离与 403 余额排障记录。
- `references/reasoning-effort-not-delivered-to-relays.md` — ⚠️ **必读**：`agent.reasoning_effort` 对中转站是空操作（`_supports_reasoning_extra_body()` 白名单制）、用 `reasoning_tokens` 实测判定思考是否真发生、会话级 `model_override` 优先于全局默认；附 Cloudflare 裸 UA 伪装成 403 密钥失效、New API 真实余额只能从 403 报文读出的两个高复用坑。用户说「开到最大思考模式」时先看这篇。
- `references/gemini-proxy-38-migration.md` — gemini-proxy（本地 8317）全盘切换 gemini-3.8-flash-high 的三处落点记录（全局默认/群覆盖/provider 主模型）与「默认 vs 覆盖」判定链。
- `references/google-official-gemini-provider.md` — ⚠️ **官方 Gemini API 接入正解**（替代已被 Google 禁止第三方接入的 antigravity 网关）：`AQ.` 前缀 key（不再只是 `AIza`）获取与地区限制、用内置 gemini provider（GOOGLE_API_KEY）而非 custom_providers、`reasoning_effort: max` 会被官方 API 400 拒绝（只能是 high/low/medium/minimal/none）、删除 antigravity/gemini-proxy 完整清单（config 三处 + auth.json + systemd + 归档）。附加两个坑：**免费档 429 配额陷阱**（列模型 200 但生成全 429 = 高频探测打爆 RPM/RPD，非 key 失效；AQ 新 key 有 429 limit:0 已知 bug）与 **别名不进 /model 菜单**（菜单只列 provider+模型，用 `/model 别名` 带参命令）。
- `references/gemini-quota-alias-pitfalls.md` — 官方 Gemini API 两个补充坑点实录：免费档 429 配额打爆判定（列模型通=key 活着、quota exceeded vs API key not valid、RPM 分钟恢复/RPD 太平洋午夜重置、AQ key 429 limit:0 已知 bug）与用户自定义别名不进 /model inline 菜单（用带参命令切换）。
- `references/antigravity-validation-required.md` — antigravity `VALIDATION_REQUIRED` 排障实录：重新 OAuth（免隧道手动粘贴回调）、plt 死循环、client_secret 提取；**最终结论：antigravity 第三方接入违反 Google 服务条款会被封号，正解是切官方 API key**。
