#!/usr/bin/env python3
"""离线复现线上「两个菜单」的真实内容（不开 Telegram、不等用户点按钮确认）。

用途：新注册/改名一个 custom provider 后，验证它到底有没有进入
  ① `/model` 切换界面（Telegram inline picker）
  ② ☰ 命令菜单（setMyCommands 最终注册的命令）
直接跑 gateway 的**同一条代码路径**，比让用户去客户端翻菜单可靠得多。

用法：
  ~/.hermes/hermes-agent/venv/bin/python3 verify_provider_registration.py [provider子串]
  例：verify_provider_registration.py 反重力

⚠️ 导入路径坑（实测）：
  - `list_picker_providers` 在 `hermes_cli.model_switch`，**不在** `hermes_cli.providers`
    （后者导入会 ImportError: cannot import name 'list_picker_providers'）。
  - slash 命令实现里是函数内 import，grep 到的 import 行所在的模块 ≠ 定义模块，别照抄。
"""
import sys

HERMES_ROOT = "/home/ubuntu/.hermes/hermes-agent"   # 按实际安装位置改
sys.path.insert(0, HERMES_ROOT)

from hermes_cli.config import load_config, get_compatible_custom_providers
from hermes_cli.model_switch import list_picker_providers           # ← 定义在这里
from hermes_cli.commands import telegram_menu_commands, telegram_menu_max_commands

needle = sys.argv[1] if len(sys.argv) > 1 else ""

cfg = load_config()
provs = list_picker_providers(
    user_providers=cfg.get("providers"),
    custom_providers=get_compatible_custom_providers(cfg),
    excluded_providers=(cfg.get("model_catalog") or {}).get("excluded_providers"),
)

print(f"=== ① /model 切换界面：{len(provs)} 个 provider ===")
found = False
for p in provs:
    if isinstance(p, dict):
        name, models = p.get("name"), (p.get("models") or [])
    else:
        name, models = getattr(p, "name", str(p)), (getattr(p, "models", None) or [])
    hit = bool(needle) and needle in str(name)
    found = found or hit
    print(f"  - {name} ({len(models)} 个模型){'   <<<< 目标' if hit else ''}")
    if hit:
        for m in models:
            print(f"        • {m}")
if needle:
    print(f"\n「{needle}」是否进入 /model 选择界面：{'是 ✅' if found else '否 ❌'}")

cmds, hidden = telegram_menu_commands(max_commands=telegram_menu_max_commands())
print(f"\n=== ② ☰ 命令菜单：注册 {len(cmds)} 条 / 隐藏 {hidden} 条 ===")
print("  " + ", ".join(f"/{n}" for n, _ in cmds))
print("含 /model：", any(n == "model" for n, _ in cmds))

# 结论备忘：☰ 菜单**只能放命令，放不了模型**。模型是通过 /model 进去的；
# 用户若要求「模型出现在菜单里」，只能加一条无参插件命令做一键切换（如 /g38），
# 或依赖已置顶的 /model（platforms.telegram.extra.command_menu.priority 里带 model）。
