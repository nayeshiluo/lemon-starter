#!/usr/bin/env python3
"""抓包代理：记录客户端真正发往中转站的请求体，用于判定
「system prompt / 自定义字段 / 工具定义 到底有没有被发出去」。

用法：
    export <KEY_ENV>=...                 # 或直接传第 2 参数为 key 字面量
    python3 capture_relay_request.py https://capy.<PRIVATE_IDENTIFIER>:2087 TENGBAIPIAO_API_KEY

然后把你怀疑的客户端（dsh / Hermes / 任意 SDK）的 baseURL 临时指向
    http://127.0.0.1:9999/v1
发一次请求，再分析落盘的 JSONL：

    python3 capture_relay_request.py --analyze /tmp/captured.jsonl

为什么需要它（2026-10-29 实测教训）：
    行为探针（例如「system 写死只回 PWNED，看它回不回」）无法区分
    「system 没传到」与「传到了但模型不遵从」。DeepSeek 系对「只输出一个词」
    这类格式指令遵从度极差，5/5 全不遵从，当时被误判为「中转站剥离 system」，
    抓包后才发现 system 10325 字符完整送达。**判定传输层只看 body，不看回复。**
"""
import http.server
import json
import os
import sys
import urllib.error
import urllib.request

UPSTREAM = sys.argv[1] if len(sys.argv) > 1 else os.environ.get("UPSTREAM", "")
KEY_ARG = sys.argv[2] if len(sys.argv) > 2 else None
LISTEN = int(os.environ.get("CAPTURE_PORT", "9999"))
LOG = os.environ.get("CAPTURE_LOG", "/tmp/captured.jsonl")

# 透传给上游的请求头（其余如 Host / Content-Length 由 urllib 重建）
PASS_HEADERS = ("authorization", "content-type", "accept", "user-agent")


def resolve_key():
    """key 可以是环境变量名，也可以是字面量；不进日志、不打印。"""
    if not KEY_ARG:
        return None
    return os.environ.get(KEY_ARG) or KEY_ARG


def analyze(path):
    """把落盘的请求体逐条摘要，重点看 messages 的 role/长度与关键词是否在场。"""
    if not os.path.exists(path):
        print(f"没有抓到请求：{path}")
        return
    for i, line in enumerate(open(path, "rb").read().split(b"\n")):
        if not line.strip():
            continue
        try:
            d = json.loads(line)
        except Exception:
            print(f"--- request {i + 1}: 非 JSON，跳过")
            continue
        print(f"--- request {i + 1}")
        print(f"  model: {d.get('model')}")
        print(f"  top keys: {list(d.keys())}")
        for j, m in enumerate(d.get("messages") or []):
            c = m.get("content")
            if isinstance(c, list):
                txt = " ".join(x.get("text", "") for x in c if isinstance(x, dict))
            else:
                txt = c or ""
            print(f"  msg[{j}] role={m.get('role')} len={len(txt)} head={txt[:80]!r}")
        blob = json.dumps(d, ensure_ascii=False)
        print(f"  tools={len(d.get('tools') or [])} total_chars={len(blob)}")
        # 判定要点：system 在不在、内容像不像你期望的那份
        has_sys = any(m.get("role") == "system" for m in (d.get("messages") or []))
        print(f"  >>> 含 role=system: {has_sys}   <-- 这一项才是传输层结论")


class Handler(http.server.BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def do_POST(self):
        n = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(n)
        with open(LOG, "ab") as f:
            f.write(body + b"\n")

        hdrs = {k: v for k, v in self.headers.items() if k.lower() in PASS_HEADERS}
        key = resolve_key()
        if key and "authorization" not in {k.lower() for k in hdrs}:
            hdrs["Authorization"] = f"Bearer {key}"

        req = urllib.request.Request(UPSTREAM + self.path, data=body, headers=hdrs, method="POST")
        try:
            with urllib.request.urlopen(req, timeout=180) as r:
                data, code = r.read(), r.status
                ct = r.headers.get("Content-Type", "application/json")
        except urllib.error.HTTPError as e:
            data, code = e.read(), e.code
            ct = e.headers.get("Content-Type", "application/json")
        except Exception as e:  # 网络层失败也回 502，别让客户端挂住
            data = json.dumps({"error": {"message": str(e)}}).encode()
            code, ct = 502, "application/json"

        self.send_response(code)
        self.send_header("Content-Type", ct)
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def log_message(self, *a):
        pass


if __name__ == "__main__":
    if "--analyze" in sys.argv:
        idx = sys.argv.index("--analyze")
        analyze(sys.argv[idx + 1] if len(sys.argv) > idx + 1 else LOG)
        sys.exit(0)

    if not UPSTREAM:
        sys.exit("用法: capture_relay_request.py <上游base，如 https://host:2087> [KEY_ENV名或key字面量]")
    print(f"抓包代理: 127.0.0.1:{LISTEN}  ->  {UPSTREAM}")
    print(f"落盘: {LOG}")
    print("把客户端 baseURL 临时指向 http://127.0.0.1:%d/v1 后发一次请求。" % LISTEN)
    http.server.HTTPServer(("127.0.0.1", LISTEN), Handler).serve_forever()
