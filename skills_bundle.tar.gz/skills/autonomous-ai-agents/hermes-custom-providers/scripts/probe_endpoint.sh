#!/usr/bin/env bash
# 探测 OpenAI 兼容端点：连通性 + 服务端模型列表 + 逐个模型 chat 实测
# 用法: probe_endpoint.sh <base_url> <api_key> [model1 model2 ...]
#   base_url 含 /v1 后缀（如 http://host:port/v1）
set -u
BASE="${1:?用法: probe_endpoint.sh <base_url> <api_key> [模型名...]}"
KEY="$2"
shift 2

echo "== 连通性 =="
curl -s -m 15 -o /dev/null -w "HTTP %{http_code} 耗时 %{time_total}s\n" \
  "$BASE/models" -H "Authorization: Bearer $KEY" || { echo "端点不可达"; exit 1; }

echo "== 服务端模型列表 =="
curl -s -m 20 "$BASE/models" -H "Authorization: Bearer $KEY" \
  | python3 -c "import json,sys; print('\n'.join(m['id'] for m in json.load(sys.stdin)['data']))" 2>/dev/null \
  || echo "(列表解析失败)"

if [ $# -eq 0 ]; then
  echo "== 未指定模型，跳过逐个测试 =="
  exit 0
fi

echo "== 逐个模型实测 =="
for m in "$@"; do
  # max_tokens 给 200：推理模型（deepseek-v4 系）的 reasoning_content 会吃掉小预算
  resp=$(curl -s -m 45 "$BASE/chat/completions" \
    -H "Authorization: Bearer $KEY" -H "Content-Type: application/json" \
    -d "{\"model\":\"$m\",\"messages\":[{\"role\":\"user\",\"content\":\"回复两个字：能用\"}],\"max_tokens\":200}")
  echo "$resp" | python3 -c "
import json,sys
raw=sys.stdin.read()
if not raw.strip():
    print('❌ 空响应（网络超时或端点无响应）')
    sys.exit(0)
try:
    d=json.loads(raw)
    if 'choices' in d:
        c=d['choices'][0]
        msg=c.get('message',{}).get('content','') or ''
        fin=c.get('finish_reason','')
        if msg.strip():
            print('✅ ' + msg.strip()[:30].replace(chr(10),' ') + ' | 结束=' + fin)
        else:
            rc=c.get('message',{}).get('reasoning_content','')
            print(('⚠ 空回复 结束=' + fin + '（思考占满预算:' + rc[:40] + '）') if rc else '⚠ 空回复 结束=' + fin)
    else:
        print('❌ ' + json.dumps(d.get('error',d))[:150])
except Exception as e:
    print('❌ 解析失败: ' + raw[:100].replace(chr(10),' '))" | sed "s/^/  [$m] /"
done
