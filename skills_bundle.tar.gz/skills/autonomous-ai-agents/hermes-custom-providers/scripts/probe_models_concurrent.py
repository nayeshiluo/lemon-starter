#!/usr/bin/env python3
"""并发实测某个 OpenAI 兼容端点下的**全部**模型，只保留实测通过项 + 附函数调用能力判定。

比 `scripts/probe_endpoint.sh` 更强的地方：
  - ThreadPoolExecutor 并发（本地网关 11 个模型 ~5s 跑完），不再串行等到超时
  - 区分「真可用 / 只有 reasoning 无正文 / 上游拒绝」，并打印上游 reason 字段
  - 额外测一次 OpenAI 格式 tool_calls（Agent 主脑必备能力）

用法：
  P=~/.hermes/hermes-agent/venv/bin/python3
  # key 从 .env 里按环境变量名取，避免密钥进命令行历史
  BASE=http://127.0.0.1:8317/v1 KEY_ENV=ANTIGRAVITY_API_KEY $P probe_models_concurrent.py
  # 也可显式给模型名覆盖自动拉取：
  BASE=... KEY_ENV=... $P probe_models_concurrent.py claude-sonnet-4-6 gemini-3.8-flash-high
"""
import concurrent.futures, json, os, sys, time, urllib.error, urllib.request

BASE = os.environ.get("BASE", "http://127.0.0.1:8317/v1").rstrip("/")
KEY = os.environ.get("KEY") or ""
if not KEY and os.environ.get("KEY_ENV"):
    env_path = os.path.expanduser("~/.hermes/.env")
    name = os.environ["KEY_ENV"]
    for line in open(env_path, encoding="utf-8"):
        if line.startswith(name + "="):
            KEY = line.split("=", 1)[1].strip().strip('"').strip("'")
            break
if not KEY:
    sys.exit("缺少密钥：设置 KEY 或 KEY_ENV（从 ~/.hermes/.env 读取）")

TIMEOUT = int(os.environ.get("PROBE_TIMEOUT", "60"))   # 高思考模型首包可达 20s+，别给太小
WORKERS = int(os.environ.get("PROBE_WORKERS", "4"))    # 中转站有 RPM 限制时降到 1~2 并加退避


def _post(path: str, payload: dict):
    req = urllib.request.Request(
        f"{BASE}{path}", data=json.dumps(payload).encode(),
        headers={"Authorization": f"Bearer {KEY}", "Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=TIMEOUT) as r:
        return json.loads(r.read())


def list_models() -> list[str]:
    try:
        req = urllib.request.Request(f"{BASE}/models", headers={"Authorization": f"Bearer {KEY}"})
        with urllib.request.urlopen(req, timeout=20) as r:
            data = json.loads(r.read())
        return [m.get("id") for m in (data.get("data") or []) if m.get("id")]
    except Exception as e:                       # 拉不到就用显式列表
        print(f"⚠️ 无法自动拉取模型列表（{e}），请显式传入模型名")
        return []


def probe(m: str):
    try:
        d = _post("/chat/completions", {"model": m,
                 "messages": [{"role": "user", "content": "只回复两个字：能用"}], "max_tokens": 300})
        ms = (d.get("choices") or [{}])[0].get("message", {})
        txt = (ms.get("content") or "").strip()
        if not txt and ms.get("reasoning_content"):
            return m, "⚠️ 只有思考无正文", "finish=" + str((d.get("choices") or [{}])[0].get("finish_reason"))
        return m, "✅ 可用", (txt or "(空)")[:20]
    except urllib.error.HTTPError as e:
        raw = e.read().decode(errors="replace")
        try:
            err = json.loads(raw).get("error", {})
            msg = err.get("message") or err.get("code") or raw[:80]
            for det in (err.get("details") or []):        # Google 系把语义放在 details.reason
                if isinstance(det, dict) and det.get("reason"):
                    msg = f"{msg} | {det['reason']} | {det.get('domain', '')}"
        except Exception:
            msg = raw[:100]
        return m, f"❌ HTTP {e.code}", str(msg)[:130]
    except Exception as e:
        return m, "❌ 异常", f"{type(e).__name__}: {e}"[:130]


def probe_tool_calls(m: str):
    try:
        d = _post("/chat/completions", {
            "model": m, "messages": [{"role": "user", "content": "北京天气？用工具查"}],
            "tools": [{"type": "function", "function": {"name": "get_weather",
                       "description": "查天气",
                       "parameters": {"type": "object",
                                      "properties": {"city": {"type": "string"}},
                                      "required": ["city"]}}}],
            "max_tokens": 200})
        tc = (d.get("choices") or [{}])[0].get("message", {}).get("tool_calls")
        return json.dumps(tc, ensure_ascii=False)[:200] if tc else "无 tool_calls"
    except Exception as e:
        return f"失败: {e}"


models = sys.argv[1:] or list_models()
if not models:
    sys.exit("没有可测模型")

ok = []
t0 = time.time()
with concurrent.futures.ThreadPoolExecutor(max_workers=WORKERS) as ex:
    for m, status, detail in ex.map(probe, models):
        print(f"{status:16} {m:28} {detail}")
        if status.startswith("✅"):
            ok.append(m)
print(f"\n可用 {len(ok)}/{len(models)}（{round(time.time()-t0,1)}s）：{', '.join(ok)}")
if ok:
    claude = next((m for m in ok if "claude" in m.lower()), ok[0])
    print(f"\n=== tool_calls 实测（{claude}）===")
    print(probe_tool_calls(claude))
print("\n提醒：注册进 provider 的 `models` 只放上面 ✅ 的项；失败项分类记录（瞬态可重试 / 永久不注册）。")
