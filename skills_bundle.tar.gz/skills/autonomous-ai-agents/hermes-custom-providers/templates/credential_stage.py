#!/home/ubuntu/.hermes/hermes-agent/venv/bin/python3
"""模板：隐藏输入暂存新凭据（不改运行配置）。

复制后只改顶部 CONFIG 段，其余逻辑保持：零密钥参数、非 TTY 拒绝、
O_EXCL + 0600 暂存、拒绝与旧值相同、拒绝重复暂存、身份核验、
错误详情不回显。装到 /usr/local/bin 前先跑 tests 段（见
references/credential-rotation-staging-and-pruning.md）。
"""

import getpass
import json
import os
from pathlib import Path
import re
import sys
import urllib.request

# ── CONFIG：按目标改这一段 ──────────────────────────────────────────
HOME = Path('/home/ubuntu/.hermes')          # 凭据所属 profile / 服务目录
ENV_FILE = HOME / '.env'                      # 或服务自己的 .env / config.json
ENV_NAME = 'SOMEPROVIDER_API_KEY'             # 要替换的那一行
PENDING = Path('/home/ubuntu/.config/lemon-cloudflare/provider.pending.token')
BASE_URL_PATH = '/models'                     # 用于身份核验的只读端点
EXPECTED_MODELS_MIN = 1                       # 至少返回几个模型才算验证通过
# ────────────────────────────────────────────────────────────────────


def configured(env_file=ENV_FILE, env_name=ENV_NAME):
    """返回当前值；配置异常直接拒绝，不做猜测。"""
    if not env_file.is_file():
        raise ValueError('凭据文件不存在；未保存。')
    matches = re.findall(r'^' + re.escape(env_name) + r'=(.*)$',
                         env_file.read_text(), re.M)
    if len(matches) != 1:
        raise ValueError('凭据条目不唯一；未保存。')
    return matches[0].strip().strip('"\'')


def identity(token, base_url):
    """身份核验：能列出模型还不够，要证明这是目标服务。"""
    class NoRedirect(urllib.request.HTTPRedirectHandler):
        def redirect_request(self, *args, **kwargs):
            return None

    try:
        req = urllib.request.Request(
            base_url.rstrip('/') + BASE_URL_PATH,
            headers={'Authorization': 'Bearer ' + token,
                     'Accept': 'application/json'})
        with urllib.request.build_opener(NoRedirect()).open(req, timeout=20) as r:
            doc = json.loads(r.read(500000))
        data = doc.get('data')
        return isinstance(data, list) and len(data) >= EXPECTED_MODELS_MIN
    except Exception:
        return False


def stage(token, env_file=ENV_FILE, pending=PENDING, validator=identity):
    if not isinstance(token, str) or not re.fullmatch(r'(?:sk-)?[A-Za-z0-9_-]{20,250}', token):
        raise ValueError('格式不正确；请只粘贴新值。未保存。')
    if pending.is_symlink() or pending.parent.is_symlink() or not pending.parent.is_dir():
        raise ValueError('暂存目录异常；未保存。')
    previous = configured(env_file)
    if token == previous:
        raise ValueError('这是旧值；未保存。')
    if pending.exists():
        raise ValueError('已有待处理新值；未覆盖，请回聊天说明。')
    if not validator(token, 'https://example.invalid/v1'):
        raise ValueError('身份核验未通过；未保存，现有配置不变。')
    fd = os.open(pending, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    try:
        os.fchmod(fd, 0o600)
        if os.getuid() == 0:                      # root 录入时对齐原属主
            st = env_file.stat()
            os.fchown(fd, st.st_uid, st.st_gid)
        with os.fdopen(fd, 'w') as f:
            f.write(token + '\n')
            f.flush()
            os.fsync(f.fileno())
    except BaseException:
        try:
            os.close(fd)
        except OSError:
            pass
        if pending.exists():
            pending.unlink()
        raise RuntimeError('暂存失败；现有配置不变。') from None
    return pending


def main():
    if len(sys.argv) != 1 or not sys.stdin.isatty() or not sys.stderr.isatty():
        print('请在目标机器的 SSH 交互终端直接运行；不接受密钥参数或管道。')
        return 2
    print('仅暂存新凭据，不修改运行配置、不重启服务、不撤销旧值。')
    try:
        stage(getpass.getpass('粘贴新值并按回车（输入隐藏）：'))
    except (EOFError, KeyboardInterrupt):
        print('\n已取消；现有配置不变。')
        return 1
    except ValueError as exc:
        print(str(exc))                            # 只有静态自产错误
        return 1
    except Exception:
        print('暂存失败；详情不回显，请回聊天说明。')
        return 1
    print('已安全暂存，身份核验通过；尚未切换消费者或撤销旧值。')
    print('请回聊天说“已录入”，不要发送密钥或截图。')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
