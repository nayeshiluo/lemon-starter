# Google 官方 Gemini API（generativelanguage.googleapis.com）接入 Hermes

antigravity 网关（CLIProxyAPI / Gemini Code Assist OAuth）是**违规接入**（Google 服务条款
禁止第三方工具经 antigravity 访问，2026 有大量封号案例），正解是官方 API key 直连。
2026-09-09 本机完整落地实录。

## Key 获取与地区限制

- 申请入口：https://aistudio.google.com 或 ai.google.dev（小号可领）
- **API key 新格式是 `AQ.` 开头（约 53 字符）**，不一定是老文档说的 `AIza` 开头——两种都是官方 key
- ⚠️ **地区限制**：Google AI Studio 不支持香港节点；换日本/美国等节点时若仍弹地区限制，
  大概率是代理出口 IP 被标记（机场共享机房段）——先改**全局模式**，再开
  `https://ipinfo.io` 确认出口国家，不行就换节点/换国家
- 验证 key：`GET https://generativelanguage.googleapis.com/v1beta/models?key=<KEY>`
  返回 200 + 模型列表即有效；直接 curl 用 `x-goog-api-key: <KEY>` 头（不是 Bearer）

## Hermes 配置（关键：用内置 gemini provider，不要走 custom_providers）

- 内置 `gemini` provider 认 `GOOGLE_API_KEY` 或 `GEMINI_API_KEY`（.env 里）
- ⚠️ `.env` 里旧的 `GEMINI_API_KEY=798dc84f...` 是 CLIProxyAPI 网关自己的 key——
  如果两个变量都在且旧值优先，Hermes 会报 `API key not valid`。**把 GEMINI_API_KEY 也刷新成官方 key**
  或只留 GOOGLE_API_KEY
- 命令：
  ```bash
  hermes config set model.provider gemini
  hermes config set model.default gemini-3.6-flash
  ```
- ⚠️ **`hermes config set providers.6.name ...` 会创建顶层 `providers:` 字典，不是
  `custom_providers` 列表**！这会把配置写坏（顶层出现 `providers: {'6': {...}}`）。
  追加 custom_providers 必须用 Python 读 yaml → append → `utils.atomic_yaml_write`（见
  append-custom-provider.md）。
- ⚠️ `api_mode: gemini` 不是 Hermes 认识的原生模式（自定义 provider 只有
  chat_completions 等）；内置 gemini provider 无需 api_mode 字段
- 默认模型别名：`hermes config set model.aliases.谷歌官 gemini/gemini-3.6-flash`，
  之后 `/model 谷歌官` 或 `hermes chat -m 谷歌官` 可用（中文别名 OK）

## ⚠️ reasoning_effort: max 会被官方 Gemini API 拒绝

官方 API 只接受 `high | low | medium | minimal | none`，传 `max` 直接 400
（`Invalid reasoning_effort: max. Valid values are: high, low, medium, minimal, none`）
→ 触发 fallback 看起来像"模型没生效"。切官方 Gemini 时把
`agent.reasoning_effort` 降到 `high`（这是官方支持的最高档）。

## 删除 antigravity / gemini-proxy 的完整清单

1. config.yaml：`model.aliases` 里 gemini38 别名、`telegram.channel_overrides` 里
   provider=custom:gemini-proxy 的条目、`custom_providers` 里 name=gemini-proxy 条目
2. auth.json：`credential_pool` 里 `custom:gemini-proxy`
3. systemd：`/etc/systemd/system/cliproxyapi.service` → disable + rm + daemon-reload
4. 运行目录 `/home/ubuntu/cliproxyapi` 与 `/home/ubuntu/.cli-proxy-api`
   （含 antigravity-*.json 账号）→ **移入 backups/ 归档（chmod 600/700），别直接删**
5. 验证：grep 无残留 `gemini-proxy|8317|antigravity`；`hermes config check` 零错误；
   `hermes chat -q "..." --provider gemini -m gemini-3.6-flash` 实际回复
6. cron jobs.json 检查 model_snapshot 无旧 provider（agent 型 cron 存快照，会 fail closed）

## 网关重启

改配置后 gateway 不重启不生效：从网关进程内直接 restart 会被拦截，用后台子代理执行
`sudo systemctl restart hermes-gateway.service`（或 systemd-run 延迟重启脚本）。