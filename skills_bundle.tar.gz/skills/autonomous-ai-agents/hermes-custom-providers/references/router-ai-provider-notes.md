# Router.ai (9的白嫖) 端点与公共 Key 特征记录

## 1. 端点基本信息
- **Base URL**: `https://api.router.ai/v1`
- **Key 环境变量**: `ROUTER_AI_API_KEY`
- **协议模式**: `chat_completions` (OpenAI 兼容)
- **典型特征**: 上游直连 Anthropic/AWS Bedrock，工具调用返回包含原生特征的 `toolu_bdrk_` 前缀 ID。

## 2. 支持模型
- `claude-sonnet-4-6`
- `claude-opus-5`
- `claude-haiku-4-5-20251001`
- `claude-sonnet-5`
- `claude-opus-5-5`
- `claude-sonnet-4-5-20250929`
- `claude-opus-4-8`
- `claude-opus-4-7`
- `claude-opus-4-6`
- `claude-opus-4-5`
- `claude-fable-5`
- `claude-fable-5-1`

## 3. 踩坑与高频故障模式
1. **公共 Key 瞬态失效（401 Unauthorized / Invalid API key）**：
   - 来源于公开电报频道/社群分享的公共 Token 生命周期极短（数小时至数分钟不等），极易被并发刷爆或被作者主动轮换重置。
   - 排障时先做纯 Python 快速探测（避免进入 hermes 交互或耗尽默认超时），一旦报 401 明确告知用户为 Key 失效/轮换，等待用户输入新 Key 替换 `.env`。
2. **Hermes 辅助任务（Auxiliary）超时与卡死防范**：
   - 使用 `hermes chat -q --provider ...` 验证链路时，如果全局配置中辅助任务（如 `auxiliary.title_generation`）绑定的模型处于 Cooling Down 或 429 状态，CLI 会长时间等待并最终触发 180s 超时退出（Exit 124）。
   - 验证 Provider 连通性时，优先使用轻量 Python 直调 `POST /v1/chat/completions`，避免被外层 CLI 辅助线程挂起误导。
