# Share 通道（sharellm.cn）实测模型清单（2026-08-13）

中转站实测：base_url `https://sharellm.cn/v1`，key 存 `~/.hermes/.env` 的 `SHARE_API_KEY`，已注册为 provider 名 `Share`（key_env: SHARE_API_KEY，默认模型 deepseek-v4-flash，api_mode: chat_completions）。

## 服务端列表 24 个 → 实测 19 可用 / 5 不可用

### ✅ 可用（已注册进 config.yaml custom_providers）
- LongCat 系外全部主流：claude-opus-5、gpt-5.6-luna、grok-4.5、kimi-k3、kimi-k2.5
- deepseek-v4-flash、deepseek-v4-pro
- glm-5、glm-5.1、glm-5.2
- qwen3.7-max、qwen3.7-plus、qwen3.8-max、Qwen3.5-2B
- minimax-m2.5、minimax-m2.7、minimax-m2.7-highspeed、minimax-m3
- step-3.7-flash

### ❌ 不可用（实测失败，未注册）
| 模型 | 失败原因 |
|---|---|
| LongCat-2.0 | `bad_response_status_code`（openai_error） |
| gpt-5.6-terra | 获取绑定路由中模型可用渠道失败 |
| kimi-k2.6 | engine overloaded（api_error 10110，可能稍后恢复） |
| kimi-k2.7-code | 空响应（网络超时） |
| mimo-v2.5-pro | 空响应（网络超时） |

## 2026-09-04 巡检更新（38 模型复测 → 36 可用 / 2 移除）

### ❌ 失效已从 config.yaml 移除
- `sensenova-u1-fast`：HTTP 404（上游已下架）
- `gpt-5.6-terra`：HTTP 503（分组 free 下模型无可用渠道）

### ✅ 实测健康存活（36 个）
- `claude-opus-5`、`gpt-5.6-luna`、`grok-4.5`、`grok-4.6`、`kimi-k2.5`、`kimi-k3`
- `deepseek-v4-flash`、`deepseek-v4-flash-0731`、`deepseek-v4-flash-vision`、`deepseek-v4-pro`、`deepseek-v4-pro-0813`
- `glm-5`、`glm-5.2`、`glm-5.3`、`glm-5.3-flash`
- `qwen3.7-max`、`qwen3.7-plus`、`qwen3.8-27b`、`qwen3.8-flash`、`qwen3.8-max`
- `minimax-m2.5`、`minimax-m2.7`、`minimax-m2.7-highspeed`、`minimax-m3`
- `agnes-2.5-flash`、`agnes-2.5-pro`、`agnes-2.5-pro-alpha`
- `dots3-note`、`hy3`、`laguna–s-2.1`、`mimo-v2.5`、`mimo-v2.5-pro`、`nemotron-3-ultra`、`nemotron-3.5-lightning`、`sensenova-6.8-flash-lite`、`step-3.7-flash`

### 探针避坑
- **20次/分频控**：ShareLLM 对 Free 分组有严格的 RPM 限制（20 req/min），高并发探测会触发 HTTP 429 导致可用模型假死，复核需保持单线程 3.5s+ 间隔。

## 注意
- 批量探测 24 个模型用 skill 的 `scripts/probe_endpoint.sh`（每模型 max_tokens 给 200，防推理模型 reasoning_content 吃光预算）。
- "服务端列表 ≠ 可用"：必须逐个 chat completions 实测，不能只看 GET /models 列表。
- 中转站模型会变动（kimi-k2.6 过载类错误可能恢复），未来会话若用户指定了"不可用"清单里的模型，重测一次再判定，别拿旧清单直接拒。
