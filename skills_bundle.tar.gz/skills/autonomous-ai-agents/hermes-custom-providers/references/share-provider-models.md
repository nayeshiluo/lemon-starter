# Share 通道（sharellm.cn）实测模型清单（2026-08-13）

中转站实测：base_url `https://sharellm.cn/v1`，key 存 `~/.hermes/.env` 的 `SHARE_API_KEY`，已注册为 provider 名 `Share`（key_env: SHARE_API_KEY，默认模型 deepseek-v4-flash，api_mode: chat_completions）。

## 服务端列表 24 个 → 实测 19 可用 / 5 不可用

### ✅ 可用（已注册进 config.yaml custom_providers）
- LongCat 系外全部主流：claude-opus-5、gpt-5.6-luna、grok-4.5、kimi-k3、kimi-k2.5
- deepseek-v4-flash、deepseek-v4-pro
- glm-5、glm-5.1、glm-5.2
- qwen3.7-max、qwen3.7-plus、qwen3.8-max、Qwen3.5-2B
- minimax-m2.5、minimax-m2.7、minimax-m2.7-highspeed、minimax-m3
- step-3.7-flash

### ❌ 不可用（实测失败，未注册）
| 模型 | 失败原因 |
|---|---|
| LongCat-2.0 | `bad_response_status_code`（openai_error） |
| gpt-5.6-terra | 获取绑定路由中模型可用渠道失败 |
| kimi-k2.6 | engine overloaded（api_error 10110，可能稍后恢复） |
| kimi-k2.7-code | 空响应（网络超时） |
| mimo-v2.5-pro | 空响应（网络超时） |

## 注意
- 批量探测 24 个模型用 skill 的 `scripts/probe_endpoint.sh`（每模型 max_tokens 给 200，防推理模型 reasoning_content 吃光预算）。
- "服务端列表 ≠ 可用"：必须逐个 chat completions 实测，不能只看 GET /models 列表。
- 中转站模型会变动（kimi-k2.6 过载类错误可能恢复），未来会话若用户指定了"不可用"清单里的模型，重测一次再判定，别拿旧清单直接拒。
