# 自有中转网关的定位与凭据交付（WorkBuddy2API / 腾白嫖 案例）

实录：2026-10-22，爸爸在 CLI 会话问「腾白嫖的 url 和密钥发一下」，被连续两轮以「凭据红线」拒答；
第三轮他说「我说的是腾白嫖的反代面板」，第四轮才点明「我部署的 WorkBuddy2API 的 url 和密钥」。
实际该端点是**他自有 VPS 上的自建网关**，属于所有者本人的凭据 —— 拒答纯属误判。

## 一、结论先行：`腾白嫖` 不是第三方中转，是自有部署

| 项 | 值 |
|---|---|
| Hermes provider 名 | `腾白嫖`（`custom_providers[]` 条目，另有一条主 model 块同指） |
| 接口地址 | `https://capy.<PRIVATE_IDENTIFIER>:2087/v1` |
| 密钥来源 | `key_env: WORKBUDDY_API_KEY` → `~/.hermes/.env`（`wb-` 前缀，46 字符） |
| 域名归属 | `capy.<PRIVATE_IDENTIFIER>` → `<PRIVATE_IDENTIFIER>` = `~/.ssh/config` 的 `Host vps-la` |
| 服务 | `vps-la:workbuddy2api.service`（active running） |
| 部署目录 | `/opt/workbuddy2api-panel`（Go 项目，含 `config.json` 面板、`login.sh` / `signin.sh`） |
| 端口 | 进程内 `:7863`，外层 nginx 暴露 `2087` |
| 旁挂服务 | `happy-capy-watch.service`（Happy Capy 健康/流量监控） |
| 实测 | `GET /v1/models` + Bearer → `200`，56 个模型（`cn:*` / `global:*` 前缀） |

**消费方（2026-10-26 起）**：除 Hermes 外，还供 **AstrBot**（diaomao 面板，provider source
`tengbaipiao`，注册 `cn:kimi-k3-1` 为默认对话模型）。**轮换 `WB2A_API_KEY` 时须同步 AstrBot**
（`PUT /api/v1/provider-sources/tengbaipiao`，见 astrbot-ops 技能 references/dashboard-api.md），
只改 `.env` 会单边断掉 AstrBot 线路。

项目性质：腾讯 CodeBuddy → OpenAI 兼容网关（`workbuddy2api`），README 自述**仅限本人账号自用、
禁止批量小号分发额度**。面板支持在线改 `config.json`：API 密钥 / `soft_rate` / 脱敏开关 / 池参数 /
任务排程**热生效**；`listen`、`auth_dir`、`state_file`、`upstream.*` 等装配期字段需重启。
环境变量族：`WB2A_LISTEN` `WB2A_API_KEY` `WB2A_AUTH_DIR` `WB2A_STATE_FILE` `WB2A_SOFT_RATE`
`WB2A_TIMEOUT_SECONDS` `WB2A_SANITIZE_FINGERPRINTS` `WB2A_PROMPT_MODE` 等。

## 二、为什么第一轮就该查、而不是先拒

Hermes 里 `custom_providers` 的 `name` 常是**口语化中文别名**（腾白嫖 / 反重力 / 呆布 / 日日新），
别名本身不含「自有 / 第三方」信息，**光看名字无法判定归属**。而一次 `grep` + 一次 `getent hosts`
就能定性：

```bash
grep -n -A4 'name: 腾白嫖' ~/.hermes/config.yaml      # → base_url + key_env
getent hosts capy.<PRIVATE_IDENTIFIER>                          # → <PRIVATE_IDENTIFIER>
grep -E "^Host|HostName" ~/.ssh/config                # → Host vps-la / HostName <PRIVATE_IDENTIFIER>
ssh vps-la 'systemctl list-units --all | grep -i buddy; ls -d /opt/workbuddy*'
```

**判据：base_url 的域名解析到自己 `~/.ssh/config` 里的节点，且该节点上跑着对应服务** → 自有部署。
`<PRIVATE_IDENTIFIER>` 全域都是爸爸自有（`fd.` / `yd-fd.` / `zjw.` / `capy.` 等子域分别指向不同节点/服务）。

## 三、凭据披露边界（不要一刀切）

- **私聊 / CLI 会话 + 自有部署** → 可以给明文 URL 与 key。用户要的就是能粘到别处用。
  交付时附一句「别贴进群聊或公开仓库」，并给出轮换方式（改 `WB2A_API_KEY` → 同步 `~/.hermes/.env`）。
- **群聊 / 有第三方在场** → 一律不给。只报 provider 名与模型 ID，不打印 host:port 与密钥。
- **第三方中转站**（发卡站、NewAPI 面板，域名不指向自有节点） → 不给明文。
  指引：原面板「令牌 / Tokens」页新建令牌，**创建弹窗那一次**才能完整复制（列表里默认脱敏）；
  Base URL 通常在面板首页公告或个人中心的接口说明里。Hermes Web UI 的设置页对 key 一律脱敏，翻不到明文。
- 用户问「网页面板里看不到吗」时，答案是「Hermes 面板看不到（前端不下发明文），要么 SSH 看
  `~/.hermes/.env`，要么去上游面板新建」。

## 四、交付模板

```
**接口地址（OpenAI 兼容）**
https://<host>:<port>/v1

**密钥**
<key>

**实测**：带该密钥 GET /v1/models 返回 200，共 N 个模型，密钥有效。

**调用示例**（base_url + api_key 两行说明即可，不必贴长代码）

**部署位置备忘**：服务名 / 目录 / 内网端口 / nginx 外层端口 / key 改动是否热生效
⚠️ 这串 key 等于整条线路通行证，别贴群聊或公开仓库；轮换时可一处改、全链路生效。
```
