# reasoning_effort 对中转站是空操作：白名单机制与实测判定法

**触发场景**：用户说「模型开到最大思考模式」「把思维开到最高」。你改完
`agent.reasoning_effort: max` 就宣布「已开到最大」——**这是错的**，多数情况下线上行为没变。

## 1. 根因：`_supports_reasoning_extra_body()` 是白名单制

`run_agent.py:7134` 起（本机行号，随版本浮动，用 `grep -n "_supports_reasoning_extra_body" run_agent.py` 定位）：

```python
def _supports_reasoning_extra_body(self) -> bool:
    if base_url_host_matches(self._base_url_lower, "nousresearch.com"):   return True
    if base_url_host_matches(self._base_url_lower, "ai-gateway.vercel.sh"): return True
    if base_url_host_matches(self._base_url_lower, "models.github.ai") \
       or base_url_host_matches(self._base_url_lower, "githubcopilot.com"):
        return bool(github_model_reasoning_efforts(self.model))
    if (self.provider or "").strip().lower() == "lmstudio":
        return any(opt and opt != "off" for opt in self._lmstudio_reasoning_options_cached())
    if base_url_host_matches(self._base_url_lower, "ollama.com"):
        return self._ollama_supports_thinking_cached()
    if "openrouter" not in self._base_url_lower:
        return False            # ← 任何中转站域名走到这里直接 False
    ...
```

`agent/transports/chat_completions.py:551` 消费这个 gate：

```python
if params.get("supports_reasoning", False) and not params.get("is_lmstudio", False):
    ...
    extra_body["reasoning"] = {"enabled": True, "effort": _effort}
```

`supports_reasoning=False` ⇒ **`extra_body.reasoning` 整段不生成**。

### 会误导人的地方
`resolve_reasoning_config()`（`hermes_constants.py:1099`）与 gate **完全解耦**，它照样返回正确值：

```
claude-opus-5-thinking  → {'enabled': True, 'effort': 'max'}
gemini-3.8-flash-high   → {'enabled': True, 'effort': 'max'}
gpt-5.6-terra           → {'enabled': True, 'effort': 'max'}
```

`/reasoning` 面板、`hermes config get agent.reasoning_effort`、`config.yaml` 三处全都显示 `max`，
**唯独请求体里没有这个字段**。仅靠读配置无法发现问题。

## 2. 唯一可信的判定法：读 `reasoning_tokens`

不要看配置，直接对端点发最小请求，读 `usage.completion_tokens_details.reasoning_tokens`：

```python
import json, urllib.request
body = json.dumps({"model": M,
                   "messages": [{"role":"user","content":"2+2=?"}],
                   "max_tokens": 64}).encode()
req = urllib.request.Request(f"{BU}/chat/completions", data=body,
        headers={"Authorization": f"Bearer {K}", "Content-Type": "application/json",
                 # ⚠️ 带浏览器 UA，否则 Cloudflare 可能拦裸请求（见下）
                 "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/126.0 Safari/537.36"})
with urllib.request.urlopen(req, timeout=60) as r:
    d = json.loads(r.read().decode())
rt = (d.get('usage') or {}).get('completion_tokens_details', {}).get('reasoning_tokens')
# rt > 0  → 思考真实发生
# rt == 0 → 未思考，或档位由服务端决定、我们控制不了
```

也可顺手检查 `choices[0].message.reasoning_content` / `.reasoning` 是否非空。

## 3. 2026-09-04 实测矩阵

对 justwoker（`https://api.justwoker.icu/v1`，`claude-opus-5-thinking`）四种下发方式：

| 下发方式 | 结果 |
|---|---|
| 裸请求（Hermes 现状） | HTTP 200，`reasoning_tokens=0` |
| `reasoning: {enabled:true, effort:"max"}` | HTTP 200，`reasoning_tokens=0`（字段被忽略） |
| 顶层 `reasoning_effort: "max"` | **HTTP 403 拒绝** |
| `thinking: {type:"enabled", budget_tokens:32000}` | **HTTP 403 拒绝** |

对照组 gemini-proxy（本地 CLIProxyAPI `http://localhost:8317/v1`，`gemini-3.8-flash-high`）：
同样一句「2+2=?」裸请求 → HTTP 200，**`reasoning_tokens=80`** ✅ 思考真实发生。

**推论**：模型名里的 `-thinking` / `-high` 后缀是**中转站服务端**决定的固定档位，不是我们可调的旋钮。

## 4. 结论、选型与话术

- 用户要「最高思维」时，**先查当前会话实际绑定的 provider**：
  ```python
  import sqlite3, json
  c = sqlite3.connect('file:$HOME/.hermes/state.db?mode=ro', uri=True)
  for k, ej in c.execute('SELECT session_key, entry_json FROM gateway_routing'):
      mo = (json.loads(ej).get('model_override') or {})
      print(k, mo.get('provider'), mo.get('model'), mo.get('base_url'))
  ```
  会话级 `model_override` 会盖掉全局 `model.default`——全局是 gemini-proxy 不代表当前对话在用它。
- 在白名单内（Portal / OpenRouter / GitHub Models / Ollama / LM Studio）→ 改 `agent.reasoning_effort` 有效。
- 走中转站 → **如实告知「档位不可控」**，建议切本地 CPA 网关、OpenRouter 或官方直连。
- 绝不要改完配置就报「已开到最大」。这条属于「未实际验证就报成功」，是明确的用户红线。

## 5. 顺带两个复用性很高的坑

- **Cloudflare 拦裸 UA 会伪装成 403 密钥失效**：不带 `User-Agent` 探活 justwoker 返回
  `403 error code: 1010`，很容易误判为「Key 挂了」。补上浏览器 UA 后同一 Key 直接 HTTP 200。
  探活脚本一律带 UA（provider 侧则用 `extra_headers` 固化，见 SKILL.md 的 WAF 节）。
- **New API 系中转站的余额藏在 403 报文里**：`/v1/dashboard/billing/subscription` 常返回
  `hard_limit_usd: 100000000` 这种假的天量额度，不可信。真实余额要靠一次真实推理触发的
  403 文案读出来：`用户额度不足, 剩余额度: ＄-0.001844` —— 负数即已透支。
