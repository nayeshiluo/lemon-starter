# 本地 CLIProxyAPI（反重力）网关 → Hermes provider 接入实录（2026-09-10 实测）

> 前置排障（账号 VALIDATION_REQUIRED、OAuth 授权用哪个号、坏号污染号池）见 `cliproxyapi` 技能的
> Pitfalls 段与 `references/antigravity-validation-required.md`。本文只记**网关通了之后怎么接进 Hermes**。
> 旧版记录（provider 名为 `gemini-proxy`）见 `references/gemini-proxy-38-migration.md`；本次改名 `反重力`，
> 三处落点逻辑不变，**新增了 key_env 用法 + 同网关兜底 + 离线验证菜单落点**。

## 0. 本次结论（一句话）
网关 `127.0.0.1:8317` 通了、11 个模型逐个实测全可用、且支持 `tool_calls` → 注册为 custom provider「反重力」，
全局默认切 `gemini-3.8-flash-high`，兜底链第一跳用**同网关的 `claude-sonnet-4-6`**。

## 1. provider 条目（写入 `~/.hermes/config.yaml` 的 `custom_providers` 列表）

```yaml
- name: 反重力                     # 不能与内置 provider 名冲突；名字会直接显示在 /model 菜单里
  base_url: http://127.0.0.1:8317/v1
  key_env: ANTIGRAVITY_API_KEY      # 密钥只进 ~/.hermes/.env，不进 config.yaml
  model: gemini-3.8-flash-high
  api_mode: chat_completions
  models: [ 11 个实测可用项 ]
```

`.env` 追加 `ANTIGRAVITY_API_KEY=<网关 api-keys 里的值>`（写前判重，别追加两行）。

主 model 块必须**清空** `base_url` / `api_key`，否则旧主模型的残留端点会覆盖新 provider：

```yaml
model:
  default: gemini-3.8-flash-high
  provider: custom:反重力
  base_url: ''
  api_key: ''
```

## 2. 实测数据（并发探测，只注册 ✅ 项）

| 模型 | 结果 | 首包 |
|---|---|---|
| gemini-3.8-flash-high | ✅ | 1.0s |
| gemini-3.7-flash-high | ✅ | 1.4s |
| gemini-3.6-flash-high | ✅ | 1.2s |
| gemini-3-flash | ✅ | 1.7s |
| gemini-3.1-pro-low | ✅ | 10.2s |
| gemini-3.1-flash-lite | ✅ | 10.0s |
| gemini-3.1-flash-image | ✅ | 2.0s |
| gemini-pro-agent | ✅ | 3.3s |
| claude-sonnet-4-6 | ✅ | 1.5s |
| claude-opus-4-6-thinking | ✅ | 13.7s |
| gpt-oss-120b-medium | ✅ | 1.3s |

`claude-sonnet-4-6` 的 `tool_calls` 实测返回 `get_weather{"city":"北京"}` —— 可当 Agent 主脑。
`claude-opus-4-6-thinking` / `gemini-3.1-*` 首包 10s+，探针超时要给 35s+，否则误判为坏。

## 3. Fallback 链（同网关多模型容灾）

```
Primary:  gemini-3.8-flash-high   (via custom:反重力)
Fallback: 1. claude-sonnet-4-6    (via 反重力, 同 base_url)
          2. deepseek-v4-flash    (via 日日新)
          3. deepseek-v4-flash    (via 官方)
```

**同网关换模型当第一兜底**的理由：Gemini 上游对多轮函数调用的角色交替校验严苛（400
`function call turn comes immediately after a user turn`），遇到时同网关的 Claude 立刻接管，
不增加故障域；网关整体挂掉才落到链尾的外部 provider。

## 4. 三层验证（缺一容易「配置看着对、实际没生效」）

1. **离线菜单落点**：`scripts/verify_provider_registration.py 反重力`
   → 应看到「反重力 (11 个模型)」出现在 provider 列表，且 ☰ 菜单含 `/model`。
2. **Hermes 真实链路**：`hermes chat -q "直接回复：反重力已接上"` → 有回复框即通。
3. **网关侧反证**（证明流量真的走网关而不是 fallback）：
   ```bash
   sudo journalctl -u cliproxyapi --since "5 min ago" --no-pager | grep -E "POST"
   # 期望：info 200 | ... | POST "/v1/chat/completions"
   ```
   ⚠️ 该条日志出现 `warn 404 GET /props`、`404 GET /version` 是客户端能力探测，属正常噪音。

## 5. 切换默认模型前后的两个检查

- **cron 模型快照预检**：切默认前先看 `~/.hermes/cron/jobs.json` 里各 job 的 `model_snapshot`。
  本次 7 个 job 全为 `None`（脚本型 job 无快照）→ 不会触发 fail-closed；有值的 agent 型 job 必须
  `hermes cron edit <id> --model <新> --provider custom` 修掉，否则下次运行直接拒绝执行。
- **会话级覆盖**：`model.default` 只影响新会话；正在跑的 Telegram 会话/`channel_overrides` 仍有旧值，
  要用户发 `/new` 或 `/model` 切过去。用户说「全部对话都用 X」时三处都要核对
  （`model.default` + `channel_overrides[].model` + provider 自身的 `model`）。

## 6. 风险（每次接入前如实告知用户）
- Antigravity 服务条款禁止第三方工具接入，**账号可能因走网关被封**（本机大号 2026-09 曾封、后申诉恢复）。
- 网关通了 ≠ 永久可用：账号再被 Google 拦会立刻 403，兜底链能保证对话不哑，但主力模型会静默降级。
- 合规正路仍是 Google AI Studio 官方 key（见 `references/google-official-gemini-provider.md`）。
