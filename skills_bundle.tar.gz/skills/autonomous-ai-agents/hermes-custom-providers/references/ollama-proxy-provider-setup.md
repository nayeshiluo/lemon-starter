# 远端 ollama 通过面板代理接入 Hermes — 实录（InstaBox，2026-10-23）

> ⚠️ **本方案已于 2026-10-23 被用户全量回滚，不要照抄重建。**
> 用户原话：「原先的关于模型的东西 全部回滚吧 不要了 没啥用」。
> 原因不是技术不通（链路确实跑通了），而是 **3b/4b 小模型扛不住 Hermes 约 2050 token 的 system prompt，
> 人设必丢**，且 4b 的 thinking 关不掉（942 thinking tokens 只为回一句「你好」）。
> 现状：InstaBox 上 ollama 容器 / 8.43G 镜像 / 5.4G 模型卷 / 面板 `/v1/*` 代理 / Hermes `InstaBox` provider 已全部删除，
> 该机器改为**视频采集节点**（见技能 `instabox-node-ops` 第八节）。
>
> **仍然有效的部分**：坑 1（thinking 字段 400）、坑 2（`models` 必须字符串列表）、坑 3（config 必须 yaml 结构化重写）
> 这三条对任何「Hermes → 自建 OpenAI 兼容代理」都成立，可以复用。
> **只在用户明确要求「把本地小模型接进 Hermes」时**才重跑本流程，并且要先把上面的人设丢失代价讲清楚。
> 回滚流程见 `references/provider-removal-rollback.md`。

## 场景

ollama 跑在 InstaBox 沙箱（127.0.0.1:11434），外部通过面板（`ib-panel`，8080 端口）鉴权访问。
面板已有 Bearer token 多级权限系统（read/run/admin），新增 `/v1/*` 透传路由作为 OpenAI 兼容层。
面板公网地址：`https://8080-agqu3tamyadjlenwmmfpknjvnu.instabox.tech`。

## 面板 /v1/* 代理核心代码

```python
def _proxy_v1(self, method, p, body):
    """把 /v1/* 透传给 ollama；流式原样转发"""
    send_body = body
    # 剥离 ollama 不支持的 thinking 相关字段
    if body and p.rstrip("/") in ("/v1/chat/completions", "/v1/completions"):
        try:
            d = json.loads(body) if isinstance(body, bytes) else body
            if isinstance(d, dict):
                for key in ("thinking", "reasoning_effort", "extra_body"):
                    d.pop(key, None)
                send_body = json.dumps(d, ensure_ascii=False).encode()
        except Exception:
            pass
    req = urllib.request.Request(OLLAMA + p, data=send_body, method=method)
    req.add_header("Content-Type", "application/json")
    try:
        resp = urllib.request.urlopen(req, timeout=900)
    except urllib.error.HTTPError as e:
        return self._send(e.code, e.read(), "application/json")
    except Exception as e:
        return self._send(502, {"error": f"ollama 不可达: {e}"})

    ct = resp.headers.get("Content-Type", "application/json")
    if "event-stream" in ct or "ndjson" in ct:
        self.send_response(200)
        self.send_header("Content-Type", ct)
        self.send_header("Cache-Control", "no-cache")
        self.send_header("X-Accel-Buffering", "no")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        try:
            for line in resp:
                self.wfile.write(line)
                self.wfile.flush()
        except Exception:
            pass
        return
    return self._send(200, resp.read(), ct)
```

路由添加位置（在 `do_GET` / `do_POST` 鉴权后）：

```python
if p.startswith("/v1/"):
    if not allow(role, "run"):
        return deny("run")
    audit(info["name"], role, method, p, 200)
    raw = getattr(self, '_raw_body', None)   # POST 时已读入的原始字节
    return self._proxy_v1(method, p, raw)
```

## Hermes provider 注册模板

```python
import sys, yaml, os
cfg_path = '/home/ubuntu/.hermes/config.yaml'
cfg = yaml.safe_load(open(cfg_path))
providers = cfg.get('custom_providers') or []
providers = [p for p in providers if p.get('name') != 'InstaBox']
providers.append({
    'name': 'InstaBox',
    'base_url': 'https://8080-agqu3tamyadjlenwmmfpknjvnu.instabox.tech/v1',
    'key_env': 'INSTABOX_API_KEY',
    'api_mode': 'chat_completions',
    'default_model': 'qwen2.5:3b',
    'models': ['qwen2.5:3b', 'qwen3:1.7b'],   # 字符串列表！不能是 [{'name':...}]
})
cfg['custom_providers'] = providers
tmp = cfg_path + '.tmp'
with open(tmp, 'w', encoding='utf-8') as f:
    yaml.dump(cfg, f, allow_unicode=True, default_flow_style=False)
os.replace(tmp, cfg_path)
# 验证
cfg2 = yaml.safe_load(open(cfg_path))
for p in cfg2['custom_providers']:
    if p.get('name') == 'InstaBox':
        print(p)
```

Key 写 `.env`（不在命令行暴露明文）：

```python
key = open('/home/ubuntu/.ib/panel_token').read().strip()
lines = [l for l in open('/home/ubuntu/.hermes/.env').readlines()
         if not l.startswith('INSTABOX_API_KEY=')]
lines.append('INSTABOX_API_KEY=' + key + '\n')
open('/home/ubuntu/.hermes/.env', 'w').writelines(lines)
```

## 实测数据（2026-10-23，4 vCPU EPYC，面板 /v1/* 透传）

| 模型 | tok/s | 首包 | 备注 |
|---|---|---|---|
| qwen2.5:3b | 31.9 | 1.9s | 干净，推荐 |
| qwen3:1.7b | 59.4 | 1.9s | 有思考链但干净 |
| qwen3:4b | 30.6 | 4.7s | thinking 关不掉，不推荐 |

## 踩坑记录

### 坑 1：Hermes 带 `thinking` → ollama 400 → 静默 fallback

- **现象**：`hermes chat --provider InstaBox` 输出了答案，但有 `Switched to fallback model` 字样
- **诊断**：`grep "API call failed" ~/.hermes/logs/errors.log | tail -5`
  - 看到 `summary=HTTP 400: "qwen2.5:3b" does not support thinking`
- **根因**：Hermes 全局 `reasoning_effort` 设置触发，把 `thinking` 字段追加进了请求体
- **解法**：代理层剥离（见上方代码）
- **验证**：再跑 `hermes chat`，输出里不再有 `Switched to fallback`

### 坑 2：`models` 写成字典列表

- **现象**：provider 注册成功，但 `/model` 菜单没出现 InstaBox 的模型
- **根因**：`models: [{'name': 'qwen2.5:3b'}]` 格式 hermes 不识别
- **解法**：改成 `models: ['qwen2.5:3b', 'qwen3:1.7b']`

### 坑 3：行级字符串替换损坏 config.yaml

- **现象**：`yaml.safe_load` 报 `ParserError: expected <block end> but found '-'` at line 562
- **根因**：用字符串替换重写 `custom_providers:` 块时，缩进/换行计算出错
- **恢复**：`cp $(ls -t ~/.hermes/config.yaml.bak-* | head -1) ~/.hermes/config.yaml`
- **教训**：改 config.yaml 一律用 `yaml.safe_load → dict 修改 → yaml.dump → os.replace`，绝不做字符串层面的块替换

## 全链路验证命令

```bash
# 1. 先 curl 验证代理接口
TOKEN=$(cat ~/.ib/panel_token)
curl -s -m 30 "https://8080-agqu3tamyadjlenwmmfpknjvnu.instabox.tech/v1/chat/completions" \
  -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" \
  -d '{"model":"qwen2.5:3b","messages":[{"role":"user","content":"能用吗"}],"stream":false}' | head -c 300

# 2. hermes chat 全链路（成功标志：无 "Switched to fallback" 字样）
cd /tmp && hermes chat -q "直接回复：能用" --provider InstaBox -m qwen2.5:3b 2>&1 | \
  grep -Ev "^Resume|^  hermes|^Session:|^Title:|^Duration:|^Messages:"

# 3. 看错误日志（若 fallback 了就从这里找根因）
grep "API call failed\|Switched to fallback" ~/.hermes/logs/errors.log | tail -10
```
