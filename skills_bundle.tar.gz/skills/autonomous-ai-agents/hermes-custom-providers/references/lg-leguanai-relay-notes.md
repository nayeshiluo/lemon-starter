# LG (leguanai.qutama.de) relay — onboarding notes

Verified: 2026-11-10 (Asia/Shanghai). Endpoint `https://leguanai.qutama.de/v1` (OpenAI-compatible, `new_api_error` style).

## Auth / discovery
- `GET /v1/models` requires `Authorization: Bearer <key>`; no-auth returned 401.
- ⚠️ **带正确 key 也返回 `{"data":[]}`（2026-11-15 复测）。** 后果：任何靠自动扫描模型列表的客户端
  （Open Minis、Cherry Studio 之类）扫不到任何模型，**必须手动填模型 ID**；Hermes 侧对应
  `discover_models: false` + `models:` 白名单。不要因为列表空就判 key 失效——用一次最小 chat 判活。
- Working key format observed: `sk-*` (length not authoritative). A 401 `Invalid token` with valid-looking format means wrong/expired/revoked key for this endpoint — do not register provider until `/v1/models` succeeds.

## 渠道池失效：整站会突然全线报错（2026-11-15 实测）
15:02→15:07 之间，十几分钟前全量探测还正常的模型，突然所有模型统一返回：

```
{"error":{"code":"model_not_found","message":"No available channel for model <id> under group vip (distributor)","type":"new_api_error"}}
```

- 这是 **new-api 渠道池没有可用上游**（分组 vip/distributor 下无渠道），不是 key 错、不是 UA 错、不是模型名错。
- 判据：**同一时刻换任意模型、任意 UA 全部同样报错** → 站点侧问题，别再调客户端配置。
- 与 UA 白名单区分：UA 不对时换回 Chrome UA 就好；渠道池挂时换 UA 无效。
- 报给用户要直说"上游渠道/额度问题，不是你填错"，并给复测时间点，别让他反复重配客户端。

### 2026-11-16 升级：从「无渠道」变成「无权限」（同一站，性质变了）

次日 10:01 CST 复测，8 个模型 + `/v1/models` 全部改为：

```
No permission to access group vip
```

即 **key 已被移出/降级出 `vip` 分组**，比「无渠道」更彻底（连清单都拒）。
key 本身仍有效（无效 key 会报 `Invalid token`，这里带 request id 的业务拒绝）。
→ 同一站隔夜演进的两层故障都只能找站方；客户端与 Hermes 配置侧一个字都不用改。

两条可复用的判据（已写进 SKILL.md「Provider 实测与坑位速查」）：

- **bogus-model 探针**：用 `definitely-not-a-model-xyz` 请求，回的也是
  `No available channel ... under group vip (distributor)` → 故障在分组层，换模型名无意义。
- **request id 夹时间窗**：id 前 14 位是服务端 **UTC**
  （`20261115150212...` = `2026-11-15 15:02:12 UTC` = `23:02:12 CST`），
  用「最后一条成功 + 第一条失败」夹出断点；本地日志是 CST，混用会差 8 小时。

## 客户端接入（手机端）见 references/mobile-app-relay-wiring.md

## Model probe results (minimal chat: `Reply with exactly: LGOK`, `max_tokens` small)
Usable (returned expected/usable content in probe):
- `deepseek-v4-pro`, `deepseek-v4-pro-202606`
- `step-5-preview`
- `minimax-m3.1-flash`
- `glm-5.3-flash-lg1`
- `lmodel`
- LG aliases also probed OK for registration candidates: `deepseek-v4-1-flash-261017`, `deepseek-v4-flash-ga-260731`, `deepseek-v4.1-flash-lg1`, `deepseek-v4.1-flash-lg2`, `hy3-lg1`, `hy3-lg2`, `space-bunny`

Caution / excluded from default set:
- `hy3`, `hy4`, `open`: probe returned `message.content=null` with `reasoning`/`reasoning_content` populated (reasoning-only). Hermes/chat flows may surface empty visible output; do not make default without a real end-to-end visible-response check.
- `glm-5.3-flash`, `deepseek-v4.1-flash`, `mimo-v2.6-flash`, `nemotron-3.5-lightning`, `inkling-2-small`, `iceman`, `flint-40b`: probe returned OpenCode Zen Free usage-limit/upstream error in this session; treat as quota/routing/transient until re-probed.

## Hermes registration (verified)
```yaml
custom_providers:
  - name: LG
    api_mode: chat_completions
    base_url: https://leguanai.qutama.de/v1
    key_env: LG_API_KEY
    discover_models: false
    model: deepseek-v4-pro
    extra_headers:
      User-Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36
```
Acceptance: `hermes chat -q 'LGOK' --provider LG --model deepseek-v4-pro` and `--provider custom:LG` returned `LGOK`. Backup config before atomic write; run `hermes config check`.

## Pitfall
When probing many models in parallel via `execute_code`, prefer `subprocess.run([...])` with direct args (or careful quoting) over ad-hoc shell payload interpolation; shell quoting + redirection mistakes can produce false `No such file`/bad probe artifacts unrelated to the model.

## 2026-11-15 全量 25 模型「口径」复测（用户问「哪个是破甲模型」）

结论：**LG 无可确认的破甲/无限制模型**。清单 25 个，17 个可测并自述「有内容限制/安全策略」。

- **路由到 OpenCode Zen Free 撞额度的（7，可等重置后补测）**：`deepseek-v4.1-flash`、`flint-40b`、`glm-5.3-flash`、`iceman`、`inkling-2-small`、`mimo-v2.6-flash`、`nemotron-3.5-lightning`
  → `OpenCode Zen Free: Free usage limit reached ... not asked again before 14:35 UTC+0`。这是**额度**，不是模型坏。
- **清单里有、后端禁用（1）**：`lmodel` → `Qoder CN: unknown or disabled model "lmodel"`。配置里留着会每次重试再失败。
- **reasoning-only 需提额**：`hy3-lg1` 在 `max_tokens=200` 时正文空、只有 reasoning（`finish_reason=length`），给 512 才答「有」。`hy3` / `hy4` / `open` 同族，探针一律 ≥512。
- **自述假阳性（重要）**：首轮 `deepseek-v4-flash-ga-260731`、`space-bunny` 答「允许」；三组问法 + `temperature=0.3` 复验后
  前者全否（纯取样噪声），后者仅「非自愿暴力」一题答「可以」、成人内容仍否 → 判**口径不稳**，不作结论。
- 可测且稳定自述受限的 17 个：`deepseek-v4-1-flash-261017`、`deepseek-v4-flash-ga-260731`、`deepseek-v4-pro`、
  `deepseek-v4-pro-202606`、`deepseek-v4.1-flash-lg1`、`deepseek-v4.1-flash-lg2`、`glm-5.3-flash-lg1`、
  `HY-Vision-2.0-instruct`、`hy3`、`hy3-lg1`、`hy3-lg2`、`hy4`、`mimo-v2.6-pro`、`minimax-m3.1-flash`、
  `open`、`space-bunny`、`step-5-preview`。

复跑：`scripts/probe_model_compliance_selfreport.py --base-url https://leguanai.qutama.de/v1 --key-env LG_API_KEY`。

## 2026-11-17 复测：分组回到 `default`，可用模型缩到 8 个

key 恢复可用（不再是 `No permission to access group vip`），`/v1/models` 返回 8 个，全部实测 chat 正文 OK：

`deepseek-v4-1-flash`、`deepseek-v4-1-flash-261017`、`deepseek-v4-flash-ga`、`deepseek-v4-flash-ga-260731`、`deepseek-v4-pro`、`deepseek-v4-pro-202606`、`HY-Vision-2.0-instruct`、`hy3`

⚠️ **上文历史别名已全线失效**（`No available channel ... under group default`，换 UA 无效）：`glm-5.3-flash-lg1/lg2`、`deepseek-v4.1-flash-lg1/lg2`、`step-5-preview`、`minimax-m3.1-flash`、`mimo-v2.6-pro`、`space-bunny`、`lmodel`、`hy3-lg1/lg2`、`hy4`、`open`。**该站可用模型集合随渠道池漂移极快（每次隔几天就换一批），历史清单只能当候选，每次接入/批量入库前必须重新逐个探测。**判分组层故障仍用 bogus-model 探针。
