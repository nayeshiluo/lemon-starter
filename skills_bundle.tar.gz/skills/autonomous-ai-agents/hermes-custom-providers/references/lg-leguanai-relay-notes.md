# LG (leguanai.qutama.de) relay — onboarding notes

Verified: 2026-11-10 (Asia/Shanghai). Endpoint `https://leguanai.qutama.de/v1` (OpenAI-compatible, `new_api_error` style).

## Auth / discovery
- `GET /v1/models` requires `Authorization: Bearer <key>`; no-auth returned 401.
- Working key format observed: `sk-*` (length not authoritative). A 401 `Invalid token` with valid-looking format means wrong/expired/revoked key for this endpoint — do not register provider until `/v1/models` succeeds.

## Model probe results (minimal chat: `Reply with exactly: LGOK`, `max_tokens` small)
Usable (returned expected/usable content in probe):
- `deepseek-v4-pro`, `deepseek-v4-pro-202606`
- `step-5-preview`
- `minimax-m3.1-flash`
- `glm-5.3-flash-lg1`
- `lmodel`
- LG aliases also probed OK for registration candidates: `deepseek-v4-1-flash-261017`, `deepseek-v4-flash-ga-260731`, `deepseek-v4.1-flash-lg1`, `deepseek-v4.1-flash-lg2`, `hy3-lg1`, `hy3-lg2`, `space-bunny`

Caution / excluded from default set:
- `hy3`, `hy4`, `open`: probe returned `message.content=null` with `reasoning`/`reasoning_content` populated (reasoning-only). Hermes/chat flows may surface empty visible output; do not make default without a real end-to-end visible-response check.
- `glm-5.3-flash`, `deepseek-v4.1-flash`, `mimo-v2.6-flash`, `nemotron-3.5-lightning`, `inkling-2-small`, `iceman`, `flint-40b`: probe returned OpenCode Zen Free usage-limit/upstream error in this session; treat as quota/routing/transient until re-probed.

## Hermes registration (verified)
```yaml
custom_providers:
  - name: LG
    api_mode: chat_completions
    base_url: https://leguanai.qutama.de/v1
    key_env: LG_API_KEY
    discover_models: false
    model: deepseek-v4-pro
    extra_headers:
      User-Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36
```
Acceptance: `hermes chat -q 'LGOK' --provider LG --model deepseek-v4-pro` and `--provider custom:LG` returned `LGOK`. Backup config before atomic write; run `hermes config check`.

## Pitfall
When probing many models in parallel via `execute_code`, prefer `subprocess.run([...])` with direct args (or careful quoting) over ad-hoc shell payload interpolation; shell quoting + redirection mistakes can produce false `No such file`/bad probe artifacts unrelated to the model.
