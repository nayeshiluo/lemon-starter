# DDDAI 通道 (api.dddai.dev) 端点与可用模型实测记录

## 1. 端点配置与画像
* **Base URL**: `https://api.dddai.dev/v1`
* **架构/系统**: New API / One API 免费分销组 (`free (distributor)`)
* **虚拟额度**: Soft limit $100,000,000 (无限额度)
* **WAF 规则**: **Cloudflare WAF 针对非浏览器 User-Agent 拦截**。默认的 Python/urllib/SDK 裸请求恒定报 `HTTP 403 Forbidden`。请求头必须附带 `User-Agent: Mozilla/5.0...`。

## 2. 模型可用性与实测矩阵 (2026-09)
接口 `GET /v1/models` 仅开放 2 个模型；经实测其余所有常用模型均报 503 无可用渠道：

| 模型名称 | 状态 | 耗时 | Tool Calls (函数调用) | Stream 流式 | 底层特征与备注 |
| :--- | :---: | :---: | :---: | :---: | :--- |
| `gpt-6-luna` | ✅ 可用 | ~1.68s | ✅ 支持原生 Function Calling | ✅ 正常 | 自报 OpenAI Codex (基于 GPT-5 编程模型，带 3840 Prompt Cache) |
| `gpt-5.6-luna` | ✅ 可用 | ~1.82s | ✅ 支持原生 Function Calling | ✅ 正常 | 自报 OpenAI Codex (基于 GPT-5 编程模型，带 3840 Prompt Cache) |
| `gpt-5.6-terra` / `gpt-4o` / `claude-3-7-sonnet` / `deepseek-chat` | ❌ 不可用 | - | - | - | HTTP 503 `No available channel for model ... under group free` |

## 3. Hermes Custom Provider 配置模版
由于该站存在 Cloudflare WAF 校验，必须配置 `extra_headers` 携带浏览器 UA：
```yaml
- name: dddai
  base_url: https://api.dddai.dev/v1
  key_env: DDDAI_API_KEY
  models:
    - gpt-6-luna
    - gpt-5.6-luna
  extra_headers:
    User-Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36
```
