# DDDAI 通道 (api.dddai.dev) 端点与可用模型实测记录

## 1. 端点配置与画像
* **Base URL**: `https://api.dddai.dev/v1`
* **架构/系统**: New API / One API 免费分销组 (`free (distributor)`)
* **虚拟额度**: Soft limit $100,000,000 (无限额度)
* **WAF 规则**: **Cloudflare WAF 针对非浏览器 User-Agent 拦截**。默认的 Python/urllib/SDK 裸请求恒定报 `HTTP 403 Forbidden`。请求头必须附带 `User-Agent: Mozilla/5.0...`。
* **并发限制（极易踩坑）**: 上游严格限制 **最大单并发（1 Concurrent Request）**。

## 2. 模型可用性与实测矩阵 (2026-09)
接口 `GET /v1/models` 仅开放 2 个模型；经实测其余所有常用模型均报 503 无可用渠道：

| 模型名称 | 状态 | 耗时 | Tool Calls (函数调用) | Stream 流式 | 底层特征与备注 |
| :--- | :---: | :---: | :---: | :---: | :--- |
| `gpt-6-luna` | ✅ 可用 | ~1.68s | ✅ 支持原生 Function Calling | ✅ 正常 | 自报 OpenAI Codex (基于 GPT-5 编程模型，带 3840 Prompt Cache) |
| `gpt-5.6-luna` | ✅ 可用 | ~1.82s | ✅ 支持原生 Function Calling | ✅ 正常 | 自报 OpenAI Codex (基于 GPT-5 编程模型，带 3840 Prompt Cache) |
| `gpt-5.6-terra` / `gpt-4o` / `claude-3-7-sonnet` / `deepseek-chat` | ❌ 不可用 | - | - | - | HTTP 503 `No available channel for model ... under group free` |

## 3. Hermes Custom Provider 配置模版
由于该站存在 Cloudflare WAF 校验，必须配置 `extra_headers` 携带浏览器 UA：
```yaml
- name: 滴滴滴
  base_url: https://api.dddai.dev/v1
  key_env: DDDAI_API_KEY
  model: gpt-6-luna
  api_mode: chat_completions
  models:
    - gpt-6-luna
    - gpt-5.6-luna
  extra_headers:
    User-Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36
```

## 4. 核心陷阱：单并发（1 Concurrency）与 Hermes 辅助模型冲突
* **现象**：在 `hermes chat` 甚至交互对话中，发送第一条消息直接报：
  `openai.RateLimitError: 429 concurrency_limit_exceeded: Too many concurrent requests. Your current plan allows up to 1 concurrent requests.`
  随后 Hermes 判定主模型故障并立即滑落至 `fallback_providers` 链。
* **根因**：Hermes 会在会话启动或首轮交互时，并发启动 `auxiliary.title_generation`（会话标题自动生成）或上下文嗅探请求。由于默认 `auxiliary` 设为 `auto`（继承当前会话的 provider），导致主对话流与辅助标题生成在同一微秒向端点发出 2 个并发请求，上游直接拒绝第二个请求。
* **处置策略**：
  1. 若将此类单并发中转站设为主模型，严禁让 `auxiliary` 任务走同一通道。应在 `config.yaml` 中将 `auxiliary` 或 `auxiliary.title_generation` 显式解耦指派至具备多并发能力的高速模型（如本地反重力网关或快速开源模型）。
  2. 在日常交互中避免快速连续回车发消息，确保上一条回复完成/流关闭后再发起下一轮交互。
