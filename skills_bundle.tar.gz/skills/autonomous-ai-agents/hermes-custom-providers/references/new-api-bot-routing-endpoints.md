# New API / One API 聚合应用（Bot/渠道专线）端点接入实录

## 1. 识别特征：`/bot/<id>` 路由链接

用户有时给出的不是标准的中转站根域名（如 `https://api.example.com`），而是带路径的链接，例如：
`https://ai.lfree.org/bot/<YOUR_BOT_ID>
配合一个 `sk-...` 格式的 API Key。

### 核心机理与避坑
- **架构归属**：这是 **New API / One API** 体系中的「聚合机器人 / 应用（Bot）/ 渠道专属分组」功能。
- **401 Invalid token 陷阱**：
  - 如果拿这个 Key 直接去打根目录 `https://domain.tld/v1/models`，**必定返回 HTTP 401 `Invalid token`**。
  - 因为该 Token 是在特定 Bot 应用分组下生成的，权限和路由被严格隔离在该应用上下文内。
- **OpenAI 兼容 Base URL 构造规范**：
  - 必须将完整路径保留并追加 `/v1`：
    `https://ai.lfree.org/bot/<YOUR_BOT_ID>/v1`
  - 完整端点：
    - 列出模型：`GET https://domain.tld/bot/<id>/v1/models`
    - 对话补全：`POST https://domain.tld/bot/<id>/v1/chat/completions`

## 2. 探测与实测规范

使用该 Base URL 探测时，重点核查三项：

1. **真实可用性与上游映射（挂羊头卖狗肉排查）**：
   - 中转站 Bot 分组经常使用别名重定向。例如本次实测 `claude-opus-5` 响应仅 1.77s，自我介绍为 DeepSeek，且带有 `reasoning_content`，实际为 DeepSeek-R1 映射。
   - 部分模型虽然在 `/v1/models` 列表中返回，但上游实际未配置渠道（如 `laguna-s-2.1` 返回 `401 Model not supported`），必须以真实 chat 返回 `choices` 为准。

2. **思考模型 max_tokens 截断（finish_reason: length）**：
   - 带推理思考的模型（如 `muse-spark`、`nemotron-3.5-lightning`、`big-pickle`）在生成正文前会消耗数百个 token 用于思考。
   - 若测试请求设置 `max_tokens: 100~150`，会被思考过程直接占满，导致 `content` 为空且 `finish_reason: length`，容易被误判为“坏死模型”。测试时 `max_tokens` 必须给足 **400~1500**。

3. **原生 Function Calling (Tool Calls) 验证**：
   - Hermes 重度依赖工具调用能力。测试此类中转端点时，必须注入一组 mock tools（如 `get_weather`）测试 `tool_choice: "auto"`。
   - 本次实测验证表明，New API Bot 分组下的 `claude-opus-5`、`nv/kimi-k3`、`big-pickle`、`mimo-v2.5`、`muse-spark` 均可完美返回结构化 `tool_calls`。
