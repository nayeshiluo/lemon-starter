# 让用户自己粘贴密钥进 `.env`（不给对话、不进 shell 历史）

场景：用户说「密钥我自己输」「你给我 ssh 指令，我从那边输入」，或拒绝把 key 贴进聊天。
目标：用户一条命令搞定，你事后能**独立验证**它真落盘了。

---

## 1. 环境事实（2026-11-10 实测，本机）

| 项 | 值 |
|---|---|
| Hermes 服务账号 | `ubuntu`，`~` → `/home/ubuntu`（目录属主 ubuntu） |
| live 凭据文件 | `/home/ubuntu/.hermes/.env`（`-rw------- ubuntu ubuntu`） |
| root 的 `~/.hermes` | **只有骨架**（`cron/ hooks/ logs/ memories/ pairing/ private/ sessions/ skills/ SOUL.md`），**没有 `.env`** |
| root 登录情况 | `/root/.bash_history` 可读（`sudo -n tail`），`last` 能看到 root 的 pts 会话 |

结论：**用户很可能在 root shell 里粘贴**，任何 `~/.hermes/...` 都会落到 `/root/.hermes/...` → 写错位置。

---

## 2. 可直接粘贴的配方（root / ubuntu 都能跑）

```bash
umask 077
read -rsp '粘贴新密钥后回车: ' K; echo
[ -n "$K" ] || { echo '空密钥，退出'; exit 1; }
ENVF=/home/ubuntu/.hermes/.env          # ← 写死，不用 ~
cp -a "$ENVF" "$ENVF.bak-$(date +%Y%m%d%H%M%S)" 2>/dev/null || true
K="$K" ENVF="$ENVF" python3 -c '
import os, re, pathlib
p = pathlib.Path(os.environ["ENVF"]); k = os.environ["K"].strip()
assert k and not any(c.isspace() for c in k), "密钥含空白或为空"
t = p.read_text() if p.exists() else ""
t = re.sub(r"(?m)^IKUN_API_KEY=.*$", lambda m: "IKUN_API_KEY=" + k, t)   # lambda：key 里的 \ 和 & 不会被解释
if "IKUN_API_KEY=" not in t:
    t = t.rstrip("\n") + "\nIKUN_API_KEY=" + k + "\n"
p.write_text(t)
print("写入完成 len=", len(k), "前缀", k[:4] + "***")
'
unset K
chown ubuntu:ubuntu "$ENVF"; chmod 600 "$ENVF"; ls -l "$ENVF"
```

要点：
- **`cp` 后面必须有 `|| true`**：`/root/.hermes/.env` 不存在时它失败，不能让它把整段打断（本次就是这么死的）。
- **`p.read_text() if p.exists() else ""`**：文件缺失就新建，而不是 `FileNotFoundError`。
- **`re.sub` 用 lambda**：替换字符串里的 `\1`、`&` 会被解释，key 恰好含这些字符就会被静默改坏。
- **单引号 `python3 -c '...'` + 环境变量传值**：双引号里写 `\$` 经过粘贴/多层 shell 后极易失真。
- 结束打印 `len=` + 前缀 4 字符：**既证明写进去，又不泄露全文**。让用户只回这一行。

预期输出：
```
写入完成 len= 51 前缀 sk-****
-rw------- 1 ubuntu ubuntu 2056 Nov 10 07:52 /home/ubuntu/.hermes/.env
```

---

## 3. 事后验证三连（别信「我应该成功了」）

```bash
# ① 文件到底动没动
stat -c '%y %s %U' /home/ubuntu/.hermes/.env     # mtime 没变 = 没写

# ② 用户在哪个账号、贴了什么（root 侧）
sudo -n tail -25 /root/.bash_history

# ③ 新 key 是否真有效（新老端点各打一次，不打印 key）
set -a; . /home/ubuntu/.hermes/.env; set +a
for U in https://token.thxnk.cc/v1 https://<YOUR_PRIVATE_DOMAIN>/v1; do
  printf '%s -> ' "$U"
  curl -s -m 20 -o /tmp/m.json -w '%{http_code}\n' "$U/models" -H "Authorization: Bearer $IKUN_API_KEY"
done
```

本次实测结果：`/home/ubuntu/.hermes/.env` mtime 仍是 **Nov 8 11:33**（未写），
且现有 51 字符 key 在**新老端点都 401 `new_api_error`** —— 说明「周三」这条线早就是死的，
并不只是 URL 要换。所以汇报必须把两件事分开：**端点迁移** vs **凭据已失效**。

---

## 4. 换 url + key + 模型清单的完整顺序

1. 探测新端点（无 key 也先打一次，确认是 New API 家族：`{"type":"new_api_error"}`、401 需 token）。
2. 用户落盘 key（上面配方）→ 你验证 mtime + `/v1/models` 200。
3. `GET /v1/models` 拉真实清单，与 config 里旧 `models` 做差集只产生**候选**。
4. 逐个串行实测（间隔 ≥3.5s）再定清单，别用 `/models` 差集驱动删除。
5. 备份 → 改 `base_url` + `models` + `model`（`key_env` 变量名尽量不动，减少连带面）→ `hermes config check`。
6. `hermes chat -q "直接回复：能用" --provider <名> -m <模型>` 逐模型真链路验收。

> 若用户主动提出改 env 变量名（如 `IKUN_API_KEY` → `ZHOU3_API_KEY`），要连带改
> `config.yaml` 里所有 `key_env:` 引用与每个消费方服务，别只改 `.env`。
