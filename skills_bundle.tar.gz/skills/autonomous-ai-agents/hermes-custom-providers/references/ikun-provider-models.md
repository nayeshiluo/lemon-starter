# ikun撸时涵 通道（<YOUR_PRIVATE_DOMAIN>）端点配置与实测记录

2026-10-15 实测。爸爸给的中转站，域名 `<YOUR_PRIVATE_DOMAIN>`，New API 架构（报错里带 `new_api_error` + request id）。

## provider 条目（已落盘 config.yaml）

```yaml
- name: ikun撸时涵
  base_url: https://<YOUR_PRIVATE_DOMAIN>/v1
  key_env: IKUN_API_KEY        # 值在 ~/.hermes/.env
  model: Deepseek V4 Flash
  api_mode: chat_completions
  extra_headers:
    User-Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/<YOUR_SERVER_IP> Safari/537.36
  models:
    - Deepseek V4 Flash
    - Deepseek V4 Pro
    - GLM 5.3
    - GLM 5.3 Flash
```

## ⚠️ 坑 1：Cloudflare error 1010（必须伪装 UA）

用默认 Python/urllib UA 直连 `GET /v1/models` 直接吃
`HTTP 403 / error code: 1010` —— 这是 Cloudflare 的**浏览器签名黑名单**（banned your access based on your browser's signature），
不是 key 问题、也不是额度问题。加浏览器 UA 立刻 200；`curl` 默认 UA 也能过（curl 没被禁）。

**处置**：provider 条目必须带 `extra_headers.User-Agent`，否则 Hermes 的 openai SDK 默认 UA 同样被拦。
（同类案例见 SKILL.md 里 justwoker / true-sota 的 WAF 段，但本条是 1010 浏览器签名，不是 ASN 段封。）

## ⚠️ 坑 2：模型 ID 带空格和大小写，小写名一律 404

服务端注册的模型名是**人类可读带空格**的：
`Deepseek V4 Flash` / `Deepseek V4 Pro` / `GLM 5.3` / `GLM 5.3 Flash`。

试常用小写写法 `deepseek-v4-flash`、`glm-5.3` → `503 model_not_found`（`No available channel for model ... under group vip (distributor)`）。
写 provider `models` 与 `-m` 参数时**必须原样带空格引号包裹**。

## 实测矩阵（2026-10-15）

初次测试（未充值）：4 个模型全部
`HTTP 403 insufficient_user_quota：用户额度不足, 剩余额度: ¥0.000000` —— key 有效但账号零余额。
充值后复测：

| 模型 | chat 正文 | 首包耗时 | tool_calls | reasoning_content |
|---|---|---|---|---|
| Deepseek V4 Flash | ✅ 接口能用 | 1.9s | ✅ | 有（67 字符）|
| Deepseek V4 Pro | ✅ 接口能用 | 17.6s | ✅ | 有（133 字符）|
| GLM 5.3 | ✅ 接口能用 😊 | 7.2s | ✅ | 有（230 字符）|
| GLM 5.3 Flash | ✅ 接口能用 | 3.0s | ✅ | 有（411 字符）|

`usage.completion_tokens_details.reasoning_tokens` 返回 `None`（New API 未透出该字段），
但 `message.reasoning_content` 非空 → 确实是推理模型。想判定思考是否真发生，此处只能看 `reasoning_content`，不能靠 `reasoning_tokens`。

## 三层验证结果

1. `GET /v1/models` → 200，4 个模型
2. `hermes chat -q ... --provider "ikun撸时涵" -m "Deepseek V4 Flash"` → 输出「能用」✅
   （`-m "GLM 5.3 Flash"` 同样通过）
3. `verify_provider_registration.py ikun撸时涵` → `/model` 界面出现「ikun撸时涵 (4 个模型)」，☰ 菜单含 `/model` ✅

## 余额查询

`GET /v1/dashboard/billing/subscription` 返回 `has_payment_method: true`，
但 `soft_limit_usd/hard_limit_usd` 是 New API 的占位值（<YOUR_USER_IDENTIFIER>），**读不出真实余额**。
判断欠费只能靠 403 报文里的「剩余额度: ¥x」。
