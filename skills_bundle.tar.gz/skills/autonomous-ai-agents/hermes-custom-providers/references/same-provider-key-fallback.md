# 同一 Provider 多 Key 额度容灾与自动 Fallback 链配置方案

## 1. 业务场景
当用户针对同一个第三方 OpenAI 兼容端点（如 New API、One API、中转站网关）提供多个 API 密钥，并提出“原密钥额度耗尽后自动切换备用密钥”的需求时，直接覆盖环境变量会导致原 Key 剩余额度被丢弃，且在额度耗尽时直接报错中断。

## 2. 架构设计与实现方案
通过在 Hermes 中注册二级 Custom Provider，并将其置于 `fallback_providers` 链首位，实现同端点同模型家族的无缝静默容灾：

1. **凭证隔离存入 `.env`**：
   - 主密钥：`<NAME>_API_KEY`（如 `JUSTWOKER_API_KEY`）
   - 备用密钥：`<NAME>_BACKUP_API_KEY`（如 `JUSTWOKER_BACKUP_API_KEY`）
   - 使用 `save_env_value` 存入 `~/.hermes/.env`。

2. **在 `custom_providers` 注册备用节点**：
   ```yaml
   - name: justwoker-backup
     display_name: Justwoker 备用 (Claude Opus 5)
     base_url: https://api.justwoker.icu/v1
     key_env: JUSTWOKER_BACKUP_API_KEY
     model: claude-opus-5-thinking
     models:
       - claude-opus-5
       - claude-opus-5-thinking
     extra_headers:
       User-Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/126.0 Safari/537.36
   ```

3. **置顶配置 `fallback_providers`**：
   ```yaml
   fallback_providers:
     - provider: justwoker-backup
       model: claude-opus-5-thinking
       key_env: JUSTWOKER_BACKUP_API_KEY
       base_url: https://api.justwoker.icu/v1
       api_mode: chat_completions
     - provider: 日日新
       model: deepseek-v4-flash
       key_env: HERMES_CUSTOM_TOKEN_SENSENOVA_CN_API_KEY
       base_url: https://token.sensenova.cn/v1
       api_mode: chat_completions
   ```

4. **容灾流转机制**：
   - 正常状态：Hermes 调用主 Provider (`justwoker` / `JUSTWOKER_API_KEY`)。
   - 额度耗尽 (HTTP 403 `INSUFFICIENT_BALANCE` / HTTP 429 `insufficient_quota`)：Hermes 自动触发 `fallback_providers` 第一梯队。
   - 效果：同端点、同模型（`claude-opus-5-thinking`）平滑接力，会话上下文与推理模式不受任何影响。

## 3. 实网运行验证案例（2026-09-04 巡检）
- **现象**：主 Key `JUSTWOKER_API_KEY` 实际产生欠费阻断（`HTTP 403: 用户额度不足, 剩余额度: ＄-0.001844`）。
- **表现**：因 `fallback_providers` 第一梯队直接挂载 `justwoker-backup`（使用 `JUSTWOKER_BACKUP_API_KEY`），备用节点健康度 100% 通过（`claude-opus-5` 及 `claude-opus-5-thinking` 实测正常响应），成功验证了多 Key 容灾配置对保障可用性的关键作用。
- **后续处理**：当主 Key 长期不再充值时，可在配置清理时将原主节点退役，直接由备用节点接管为主配置。
