# NewFouAPI（<YOUR_PRIVATE_DOMAIN>）端点特征与模型可用性实测

## 端点信息

- **用户中心 / 登录页**：`https://<YOUR_PRIVATE_DOMAIN>/user`（New API / API Hub 轻量网关架构）
- **OpenAI 兼容 Base URL**：`https://<YOUR_PRIVATE_DOMAIN>/v1`
- **鉴权方式**：`Authorization: Bearer sk-...`
- **特点**：无需反代代理直接可连，首字延迟低（多款模型在 0.5s~1.5s 之间），支持流式和部分工具调用。

## 模型可用性矩阵（2026-09 实测，共 27 款）

### 1. 稳定可用且支持 Tool Calls（推荐用于 Agent / Hermes）
- `gemini-3.1-flash-lite`：延迟 ~1.9s，完美支持 Native Tool Calls / Function Calling。
- `moonshotai/kimi-k2.7-code`：延迟 ~4.6s，完美支持 Native Tool Calls / Function Calling。

### 2. 稳定可用通用模型
- `auto`：延迟 ~1.4s，自动智能分流。
- `deepseek-v4-flash` / `deepseek-ai/deepseek-v4-flash`：延迟 ~5.5s，带完整思维流及正文回复。
- `gpt-5.6-luna`：延迟 ~3.2s，通用问答正常（不支持 Tool Calling）。
- `nvidia/nemotron-3-super-120b-a12b`：延迟 ~0.8s，秒级出词。
- `nemotron-3-120b-a12b`：延迟 ~11.8s，Cloudflare Workers AI 算力驱动，带 reasoning 推理流。注意：低 max_tokens 时可能耗尽在思考流中，返回 `content: null`，测试需给足 max_tokens。
- `gpt-oss-120b`：延迟 ~8.8s，自带长推理。
- `glm-4.7-flash`：延迟 ~11.6s，带思维链输出。
- `voxtral-small-2507`：延迟 ~0.48s，极速秒回。
- `c4ai-aya-vision-32b`：延迟 ~0.50s。
- `nex-agi/nex-n2.5-pro:free`：延迟 ~0.68s。
- `openrouter/free`：延迟 ~0.74s。
- `command-a-plus-05-2026`：延迟 ~0.84s。
- `cohere-north-mini-code`：延迟 ~1.69s。

### 3. 生图专用模型（勿用于 Chat 端点）
- `flux-1-schnell`
- `@cf/black-forest-labs/flux-1-schnell`
- `agnes-image-2.0-flash`
- 现象：调用 `/v1/chat/completions` 或 `/v1/images/generations` 返回 HTTP 400，需专用生图接口。

### 4. 不可用 / 故障模型（严禁注册进 Hermes 列表）
- `agnes-2.0-flash`、`agnes-2.5-pro`、`agnes-3.0-flash`、`glm-4.5-flash`、`deepseek-ai/deepseek-v4-flash-0731`：上游无响应，请求 >12s 恒定超时。
- `qwen3.8-flash-next`：上游 HTTP 400，渠道未配置或已下线。
- `z-ai/glm-5.3-free`：上游 HTTP 502/503，可用渠道不存在。
- `stealth/union-alpha`：上游 HTTP 404，测试已结束。
