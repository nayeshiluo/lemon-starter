# 白嫖网关「模型能不能用」的账号池诊断法（WorkBuddy2API / 腾白嫖实测）

场景：用户问「XX 里那些模型是不是还能用 / 有哪些能用 / 我还有账号没登录」。
这类网关的可用性**不是模型属性，是账号池属性** —— 先读池子状态，再谈模型清单。

实录：2026-11-08 21:40 CST，`腾白嫖`（`capy.<PRIVATE_IDENTIFIER>:2087`）35 个 `global:*` 模型实测。

---

## 一、先看 `/status`，别一上来逐个模型探测

WorkBuddy2API 在**根路径**（不是 `/v1` 下）暴露池状态，比 `/v1/models` 有用得多：

```python
import json, urllib.request
base = "https://<host>:<port>"
req = urllib.request.Request(base + "/status", headers={"Authorization": "Bearer " + KEY})
j = json.loads(urllib.request.urlopen(req, timeout=20).read())
```

顶层字段（实测存在）：`accounts` / `total` / `healthy` / `cooling` / `disabled` /
`in_flight_full` / `realm_totals` / `credit_floor` / `sticky_sessions` / `model_locks`。

`realm_totals` 按 `cn` / `global` 分域给出 `{total, healthy, cooling, disabled, in_flight_full}` ——
**一眼就能回答「哪个域还有活号」**，不用拿模型名去试。

每个 `accounts[]` 条目可读：`realm` / `credits` / `credits_total` /
`credits_earliest_expiry` / `disabled` / `cooling` / `reason` / `success_count` / `err_total` /
`last_success` / `token_usage.last_model` / `model_costs[]`。

`model_costs[]` 还会给出**该账号实际用过**的模型与 `cost_per_1k`（有的档位计 0 成本），
比猜「哪个模型免费」可靠。

三个容易看漏但决定可用性的字段：

| 字段 | 语义 | 影响 |
|---|---|---|
| `credit_floor` | 积分地板（实测 `100`） | `credits < credit_floor` 的号**直接不参与调度**，不是"还能用一点" |
| `model_locks[]` | 模型级锁定，带 `unlock_at` / `fully_unlock_at` / `reason` | 见 §三，`11102` 锁约 5 小时，**不是账号权限问题** |
| `sticky_sessions` | 当前绑定了会话粘性的会话数 | 串行探测时同一会话可能**全钉在一个号上**（实测连 8 次都落同一个 uid），看不到真实轮转 |

### 用 `reason` 区分「暂时没号」和「号被永久封」

本次实测三种 reason 语义完全不同：

| reason 文案 | 语义 | 处置 |
|---|---|---|
| `429 rate limit`（`cooling:false` 时无意义） | 历史限流记录，不代表当前不可用 | 忽略 |
| `account banned by upstream (11140 request illegal), re-login required` | **上游封号，必须重新 OAuth 登录** | 只重试没用，走登录流程 |
| 无 reason + `disabled:true` | 面板手工停用 | 看是谁停的 |

**这条修正了 SKILL.md 里「`no_healthy_account` = 网关瞬态」的单一定性**：
`no_healthy_account` 有两种成因 ——
1. 并发打爆 / 在途租约满 → **瞬态**，串行重测即恢复；
2. 该 realm 的账号全部 `disabled` 或封禁 → **持续性**，重测多少次都一样，必须补账号。

判据：看 `/status` 的 `realm_totals.<realm>.healthy`。
`healthy=0` 且 `disabled>0` → 成因 2，别再浪费一轮串行复测。

---

## 二、并发会伪造「只剩一个模型能用」

同一批 35 个模型，两种打法结论天差地别：

| 打法 | 结果 |
|---|---|
| `ThreadPoolExecutor(max_workers=10)` 一次性全打 | **1/35 通过**，其余 21 个 `<html>503`、13 个 JSON `no_healthy_account` |
| 串行、每请求间隔 1.2s | **17/35 通过** |

根因：池里只有 1 个健康账号，并发把在途租约（`in_flight_full`）打满。
外层 nginx 的 `<html>503 Service Temporarily Unavailable` 与网关 JSON
`no_healthy_account` 都是同一个过载信号的不同表现层，**都不代表模型不可用**。

→ 对**单账号 / 少量账号**的白嫖网关，并发数不要超过 `healthy` 数量；
探测一律串行 + `sleep(1.2~3.5)`。已有 `scripts/probe_models_concurrent.py` 适合多账号池，
单账号场景要手动降并发或直接串行。

---

## 三、三态响应的正确归类（本次实测）

| 响应 | 含义 | 判定 |
|---|---|---|
| `200` + `choices` | 可用 | — |
| `200` + `content=""` + `reasoning_content` 非空 | 推理模型吃光 `max_tokens` | 加大到 1000+ 复测，**不是坏** |
| `503` + `code:no_healthy_account` | 池里没健康号（瞬态或封号，见 §1） | 查 `/status` 再定 |
| `503` + `<html>` | 外层 nginx 过载/限流 | 降并发重测 |
| `400` + `code:model_unavailable` | 网关**没有这个模型的路由**，或该模型被**临时锁定** | **先查 `model_locks` 再判**，见下 |
| `503` + `code:11158 model not allowed for user type` | 账号档位不含该模型 | 永久（除非换号/升档） |

⚠️ `400 model_unavailable` **不一定永久**。2026-11-08 22:22 复测发现 `auto-chat` / `o4-mini`
这两个在 `/status.model_locks` 里有明确记录：

```json
{"model":"auto-chat","realm":"global","total":3,"servable":0,"locked":3,
 "state":"locked","unlock_at":"2026-11-09T03:46:42+08:00",
 "fully_unlock_at":"2026-11-09T04:21:10+08:00","reason":"11102 model not available"}
```

这是**上游 `11102 model not available` 触发的 5 小时模型级冷却**，到 `unlock_at` 自动解锁，
与账号权限无关。所以遇到 `400 model_unavailable` 的正确顺序是：
**先读 `/status.model_locks` 看有没有 `state:locked` + `unlock_at`，有就是临时，没有才判无路由。**

⚠️ `400 model_unavailable` 与 `503 no_healthy_account` 必须分开报：
前者是「网关根本没这条路由」，后者是「有路由但没号」，用户要不要加号取决于这个区别。

---

## 四、模型清单会漂移，别用 config.yaml 的缓存清单

本次 `config.yaml` 里 `腾白嫖` 缓存了 36 个模型（含 11 个 `cn:*`），
网关 `/v1/models` 实际只返回 35 个、**全是 `global:*`，`cn:*` 已整体摘除**。

→ 回答「有哪些模型」一律现拉 `/v1/models`；`cn:` / `global:` 前缀是**网关命名约定**
（`cn` = 国内版 CodeBuddy 账号，`global` = 国际版），不是模型厂商标识。

---

## 五、2026-11-08 `global:*` 实测矩阵（17/35 可用）

串行、间隔 1.2s、`max_tokens=80`，仅一个 global 健康账号在线。

**可用（17）**：`glm-5.3-flash` `glm-5.3` `glm-5.2` `deepseek-v4.1-flash`
`deepseek-v4.1-flash-sg` `hy4free` `hy4std` `hy4-preview` `hy4-preview-f` `hy3`
`minimax-m3.1-flash` `kimi-k3`(9.3s，最慢) `default-model` `fast-model`
`balanced-model` `max-model` `enhance-1.0`

**空正文但实际可用（需 `max_tokens≥1000`）**：`hy4std`（22.3s / reasoning 3540 tok）、
`hy4-preview-f`、`deepseek-v4.1-flash`

**503 `no_healthy_account`（16，当时无号有权限）**：`gpt-6-astra` `gpt-6-luna` `gpt-6-sol`
`gpt-6.1-sol` `gpt-5.6-sol` `gpt-5.6-terra` `gpt-5.6-luna` `gpt-5.4` `gpt-5.5`
`gemini-3.8-flash` `grok-4.7` `kimi-k3.1-pro` `kimi-k3.1-pro-highspeed` `primary-model`
`hy-image-3.5` `kling-video-v3`

**400 `model_unavailable`（2，网关无路由）**：`auto-chat` `o4-mini`

### 与 2026-10-20 矩阵对比（说明清单漂移速度）

- 消失：`step-5-preview` `kimi-k2.6` `kimi-k2.8-preview` `gpt-5.3-codex`
- 新增：`gpt-6-*` 系列 `gemini-3.8-flash` `grok-4.7` `max-model` `minimax-m3.1-flash`
  `kimi-k3.1-pro*` `hy-image-3.5` `kling-video-v3`（**新增的多为无权限项**）
- 稳定可用：GLM 5.2/5.3 系、DeepSeek v4.1 系、混元 hy3/hy4 系、三个别名

→ 结论口径：**这个网关的"国际版"当前实际只剩国产模型（GLM / DeepSeek / 混元 / MiniMax / Kimi），
GPT-6 / Gemini / Grok / 图像 / 视频全部无权限**。别把 `/v1/models` 列了 gpt-6 当成能用。

---

## 六、补账号（用户说「我还有账号没登录」时）

网关在 `vps-la`，面板**只监听回环 `127.0.0.1:7863`**，路径 `/panel/`，未对外。
两条路：

**A. 面板（推荐，一次点完、热加载免重启）**

```bash
# 用户本机开隧道
ssh -L 7863:127.0.0.1:7863 vps-la
# 浏览器 → http://127.0.0.1:7863/panel/ → 右上「添加账号」→ 选国内版/国际版
```
面板内完成 OAuth 设备授权 → 凭证落盘 `auths/workbuddy-<uid>.json` → **热加载进池，不用重启服务**，
顺带完成首次签到。

**B. CLI（`/opt/workbuddy2api-panel/login.sh`，需 Go 编译 `cmd/login`）**

```bash
cd /opt/workbuddy2api-panel
sudo -u workbuddy2api ./login --realm=global url    # 打印授权 URL，state 落 $TMPDIR/wb2api-login-state.json
# 用户在浏览器完成登录
sudo -u workbuddy2api ./login --realm=global poll   # 取 token → 落盘
```

- `--realm=cn|global` 必填且 `url` 与 `poll` **必须同 realm**（脚本有 `validateRealmMatch` 防混域）。
- 凭证目录：`/var/lib/workbuddy2api/auths/`（owner `workbuddy2api`，`UMask=0077`，读要 `sudo -n`）。
- 批量签到：`./signin.sh`；积分查询：`cmd/credit`。

**登录后必须重跑 `/status` + 串行实测**：新号能解锁哪些模型取决于其套餐/积分档，
不是「登了就全开」——本次 16 个 `no_healthy_account` 里，`gpt-6` 系要的档位远高于国产模型。

---

## 六b、加完账号之后的实测结论（2026-11-08 22:16~22:23）

用户一次加了 3 个 `global` 号，池从 3 个变 6 个（4 global + 2 cn 已封）。**必须重跑全量，别假设"加号=解锁"。**

### 1. 模型权限一个都没多 ⚠️

加号前后各跑一遍串行全量 35 个，结果**完全一致：17/35**。
`gpt-6-*` / `gpt-5.6-*` / `gpt-5.4` / `gpt-5.5` / `gemini-3.8-flash` / `grok-4.7` /
`kimi-k3.1-pro*` 仍然是 `no_healthy_account`，网关日志显示上游对新号返回的是 `400 client`
（不是 403/11158），说明**这些免费档账号本身就不含国际大模型档位**。

→ 向用户汇报时不要写"加号后能解锁更多模型"，除非实测矩阵真的变了。
`no_healthy_account` 对"有路由但所有号都没该档位权限"也是同一个文案，**别把它当成"没号"就许诺加号能解决**。

### 2. 🚨 面板「一键完成可自动任务」会把号刷死

这是本次最贵的教训。新号加进池 3 分钟就变 `disabled`，日志时间线：

```
22:16:31  panel: global 注册激活 uid=96d898de 完成
22:16:32  panel: 新账号已热加载（免重启生效）
22:17:02  panel: 一键完成可自动任务 uid=96d898de 共 27 项
22:17:17  panel: 一键完成可自动任务 uid=96d898de 共 27 项     ← 连点第二轮
22:19:29  WARN: [upstream] chat_stream acct=...: upstream 403 account_fault
```

随后该号 `disabled:true`，`reason = account banned by upstream (11140 request illegal), re-login required`，
`last_success = 0001-01-01`（一次都没成功过）。**刚加号就狂刷 27 项任务 = 上游风控直接判死。**

→ 加完账号**只做签到，别点「一键完成」**；给用户的操作提示里要写明这条。
→ 已经被这么刷死的号，重试无效，只能重新 OAuth 登录。

### 3. 并发上限 = 健康号数（精确量化）

4 个 global 健康号时，10 并发打 `default-model`：**3 个 200、7 个 503**，总耗时 3.3s。
说明网关对**每个账号只给 1 个在途租约**，并发容量 ≈ `healthy` 数。

- 探测/压测前先读 `healthy`，并发数不要超过它。
- 把这类网关挂到群霸 `main` 或批量定时任务前，先想清楚峰值并发。
- 串行请求会因**会话粘性**全落同一个号（实测连 8 次都在 `47125a5b`），
  要验证轮转得换 `conversation_id` 或并发发。

### 4. 压测会把号打进 429 软冷却，10 分钟自恢复

并发打爆后日志出现：

```
WARN: [pool] fallback_earliest_expiry acct=<mail>(<uid>) until=2026-11-08T22:30:06+08:00 kind=soft
```

`kind=soft` = 429 软冷却（`soft_rate` 600s 起指数退避）。**这是自己探测造成的，不是号坏了**，
22:30 自动恢复。汇报时必须主动说明，否则用户会以为加号加出问题。

---

## 七、汇报纪律

- 别把「接口连通」说成「能用/能破甲」（见 SKILL.md 表述铁律）。
- 可用 / 无权限 / 无路由 **三类分开列表**，并注明实测时间与打法（串行 or 并发）。
- 有账号被封时主动说「重试无用，要重新登录」，别让用户以为等一会儿会自己好。
- 池里只剩 1 个健康号时，明确告知**别挂高并发位**（群霸 main / 定时批量任务），
  并给出额度余量（`credits/credits_total`）。
