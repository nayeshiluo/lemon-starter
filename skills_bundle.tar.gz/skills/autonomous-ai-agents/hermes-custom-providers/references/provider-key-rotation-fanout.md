# 上游换 key（密钥轮换）的全量扇出清单

2026-11-16 实录：用户一句「周三的密钥又要换掉了，你准备处理一下」。
换 key 看起来只是改一行 `.env`，实际同一条上游的 key 被**多个系统各自抄了一份**，
漏一处就是「Hermes 好了、网关/bot 还在 401」。这是**换 key**，不是换模型
（换模型的扇出见 `provider-model-refresh-fanout.md`）。

---

## 一、绝对不要把 key 贴进聊天

用户手里有新 key 时，**不要让他把 key 发到对话框**。给一段本机脚本，
`getpass` 隐藏输入、自动备份、只回显 `len` 与 6 位前缀，改完让用户回那行输出：

```python
# 在服务器上执行；只改 ~/.hermes/.env 的某个 key，形如 IKUN_API_KEY
import getpass, os, re, shutil, time
from pathlib import Path
p = Path('/home/ubuntu/.hermes/.env')
bak = p.with_suffix(p.suffix + '.bak-<tag>-' + time.strftime('%Y%m%d%H%M%S'))
shutil.copy2(p, bak)
t = p.read_text(encoding='utf-8')
k = getpass.getpass('粘贴新的 KEY（不回显）: ').strip()
if not k:
    raise SystemExit('未输入，未改动')
if re.search(r'^KEY_NAME=(.*)$', t, re.M):
    old = re.search(r'^KEY_NAME=(.*)$', t, re.M).group(1).strip().strip('"').strip("'")
    if old == k:
        raise SystemExit('与当前值相同，未改动')
    t = re.sub(r'^KEY_NAME=.*$', lambda m: 'KEY_NAME=' + k, t, flags=re.M)
else:
    t += ('\n' if t and not t.endswith('\n') else '') + 'KEY_NAME=' + k + '\n'
p.write_text(t, encoding='utf-8')
os.chmod(p, 0o600)
print(f'写入完成 len={len(k)} 前缀={k[:6]}...')
```

用户回「写入完成 len=51 前缀=sk-6BC...」即可确认落盘，**全程没有明文进聊天记录**。

---

## 二、扇出清单：同一条上游 key 的落点

先 `grep -rl "<上游域名>"` 全机扫，再按下表逐项判定「引用 vs 真副本」：

| 落点 | 位置 | 特征 / 处置 |
|---|---|---|
| Hermes 主配置 | `~/.hermes/.env`（`key_env` 引用） | 运行时读文件，**改完不用重启 gateway** |
| **magpie 网关** | `~/.config/magpie/providers.json` → `providers[].key` | **独立明文副本，必须单独改**；见下节 |
| dsh | `~/.dsh/settings.yaml` | 若写的是 `apiKeyEnv: MAGPIE_GATEWAY_KEY` → 经 magpie，**不用单独改 key** |
| 多 Bot 池（群霸类） | `data/ai_endpoints.json` → `key_env: IKUN_API_KEY` | 代码常「先 `os.getenv` 再兜底读 `~/.hermes/.env`」→ **文件改了即生效，不用重启** |
| 角色化 Bot | `data/bot.db` → `runtime_config_secrets` | 独立表存密文；本机实测 41 张表全文 `grep thxnk` 命中 0 → 不涉及 |
| 其他机器 | 远端 `/opt /home /root /etc` | 逐机 `grep -rl <域名>`；实测 vps-la / vps-hk / aliyun / diaomao / yecao 均无残留 |
| 模板/清单类 | `patch-guard.template.json`、`credential-inventory.json`、`*.patch.yml` | 只有域名白名单或清单，**不含 key，别乱改** |

⚠️ 别把「文件里有上游域名」当成「文件里有 key」。`provider_models_cache.json`、
`sessions.json`、`tirith` 会话记录都只是历史/模型缓存，改它们毫无意义。

---

## 三、判断「某处挂的是新 key 还是旧 key」：比 sha256，不读明文

```python
import hashlib
h = lambda s: hashlib.sha256(s.encode()).hexdigest()[:10]
# magpie: providers-state.json 的 keyList[].id 就是 sha256 前 10 位
```

- 一致 → 已是新 key；不一致 → 该处还是旧的。
- magpie `masked`（`sk-o…9Ml8`）只露首尾，肉眼比对容易看错，用 sha 前 10 位最稳。
- ⚠️ **改完之后 `providers-state.json` 的 `keyList[].id` / `masked` 会一直是旧值**（2026-11-16 亲测）：
  `magpie provider key` 只写 `providers.json`，`providers-state.json` 是 UI 缓存，
  连 `magpie provider test <id>` 都不刷新它。**别拿这条缓存判成功或失败**——
  判据只有两个：`providers.json` 里 key 的 sha 是否等于新 key，以及经网关实调是否 200。
  面板显示旧掩码属于「已知无害残留」，汇报时单列一条说明，不要含糊成「都好了」。

---

## 四、验收：三层，缺一层都可能假通过

1. **上游直连**：带浏览器 UA 打 `GET /v1/models` + 最小 `chat/completions`。
   **不带 UA 会被 Cloudflare 1010 / UA 白名单拦成 403，看起来像 key 坏**。
2. **本机网关**：经 magpie 打 `token-xxx/<model>`，200 且 `message.content` 有字
   （reasoning 型模型 content 可能空、但 `finish_reason` 正常，别误判）。
3. **真实客户端**：`hermes -z '只回复两个字：收到' --provider <名> -m '<模型>'` 出字。
   bot 类则用它自己的 `load_ai_nodes()` / `get_active_chain()` 取节点后实打一次。

**手工测试前先 `env -u <KEY_NAME>`**：代码是「`os.getenv` 优先」，而当前 shell 里可能残留
上一轮导出���旧 key —— 不清掉就会测到旧值，得出「换了 key 还 401」的假结论
（本轮真实踩到：loader 读到的 sha 与 `.env` 里新 key 的 sha 不一致）。

---

## 五、收尾汇报口径

给三行：**改了什么（哪个落点 + 是否重启）/ 没动什么（及为什么不需要动）/ 剩下什么坑**。
最后那条最有价值——例如「以后换这条上游要改两处：`.env` + magpie，并重启 magpie」，
这是原技能库里没有记录、本次才暴露的重复性动作，必须回写进技能。

---

## 六、用户说「你再复验一遍」时的独立审计（2026-11-16 二轮实测）

当复验而不是复述上一轮结论：重新取目录、重新实调每个消费方、重新取证「生效」，并**主动交代本轮新发现**。

### 1. magpie 换 key 后必须重启（不是可选）

- 现象：`magpie provider key <id> <new>` 打勾、`providers.json` 里 sha 已是新 key，但**运行中的进程发请求仍 401 `Invalid token`**（旧 key 还在内存）。
- 处置：`systemctl --user restart magpie.service` → 立刻 200。CLI 打勾只证明写盘，不证明运行实例换脑。
- 3025/3430 端口分布：`magpie serve --web=0.0.0.0:3430` → API `127.0.0.1:3425`、面板 `*:3430`；重启后 `ss -ltnp | grep -E ':3425|:3430'` 确认 PID 已变。

### 2. 探测 bot 的模型池前先取真实 bot_id（别自己编）

- `lemon-group-bot` 这类服务里 `load_bot_ai_config(bid)` **文件不存在时会自动 `save_bot_ai_config()`**，
  写一个空 `order: []` 的 `data/ai_bot_<bid>.json`。用 `<PRIVATE_IDENTIFIER>_bot` / `<PRIVATE_IDENTIFIER>_bot` 这种"看起来像"的 id 去探，会凭空多出两个配置文件。
- 正确姿势：`ls data/ai_bot_*.json` 拿真实 id（通常是数字型 Telegram bot id，如 `<PRIVATE_IDENTIFIER>`），再用 `get_active_chain('<id>')`。
- 已污染就自查：`find data -maxdepth 1 -newermt '-15 minutes' -type f`，确认是本次生成后删除，并在汇报里写明「我误建过、已清理」，不要静默处理。

### 3. 全系统「旧 key 还有谁持有」扫描

遍历 `/proc/*/environ` 按 sha 比对，只输出 `NEW/OLD` + 长度 + 进程名，永不打印明文。
注意它只能反映**启动时**环境：进程内 dotenv 加载的值不在这里，所以「未设置」不等于没配；
它的用途是抓「继承了旧值的长跑进程」。

### 4. 复验的 max_tokens 一律 ≥1024

`Deepseek v4.1 Flash` 在 `max_tokens=256` 时 reasoning 吃满预算 → HTTP 200 但 `content` 为空（512 偶现）。
复验若用小预算，会把模型特性误判成「新 key 也坏」。逐模型记录 `content_len` / `reasoning_len` / `finish_reason` 再判。

### 5. 汇报形态

一张「消费方 → 处理动作 → 验收证据（HTTP 码 + 耗时）」表 +
「没改也不用改的项」+「已知无害残留」（面板旧掩码、图片模型不收 chat）+「本轮我自己的误操作」。
四段分开写，别合并成一句「全部正常」。
