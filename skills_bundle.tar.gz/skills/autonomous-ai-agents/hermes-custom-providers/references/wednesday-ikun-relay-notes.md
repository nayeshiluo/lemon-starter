# 「周三」provider 档案（第三方 New API 中转站）

> **2026-11-10 站点迁移**：周三已从 `<YOUR_PRIVATE_DOMAIN>` 换到 `https://token.thxnk.cc/v1`（同为 New-API 架构，key 换新，仍存 `IKUN_API_KEY`）。新站 `/v1/models` 只有 `Deepseek v4.1 Flash`、`GLM 5.3` 两个，`Deepseek V4 Pro` / `GLM 5.3 Flash` 已不存在。下文凡是写旧域名/4 模型的数字，都按 2026-11-10 之前的历史记录读。
> 新站行为实测：`role=tool` 带 `name` → 400 `invalid_request`；`role=user` 带 `name` → 200。所以剥 name 补丁的域名门控已扩成 `in ("<YOUR_PRIVATE_DOMAIN>", "token.thxnk.cc")`。

> **2026-11-16 站点失联（域名记录被删，非宕机）**：`token.thxnk.cc` 在 1.1.1.1 / 8.8.8.8 / <YOUR_SERVER_IP> 全部 NXDOMAIN，
> 但主域 `thxnk.cc` 与 `api.thxnk.cc` 仍正常解析到 Cloudflare（`<YOUR_SERVER_IP>` / `<YOUR_SERVER_IP>`）
> → **只有 token 子域的 DNS 记录被删**。用 `curl --resolve token.thxnk.cc:443:<YOUR_SERVER_IP>` 硬连，
> 返回 `http=530` + `error code: 1016`（CF Origin DNS error），确认源站记录已失效而非服务端 5xx。
> 时间线：2026-11-15 21:53 CST 仍能响应（400 `messages.name` 参数错，说明后端活着），2026-11-16 10:20 CST 已彻底解析不了。
> 影响：Hermes `fallback_providers` 里的周三失效（主链 `custom:command` 不受影响）、群霸 `ai_endpoints.json` 的
> `zhousan` 节点同域失效（该节点此前已因 429 停用）。**结论只能找站方要新域名**，客户端改任何参数都救不回来。
> 恢复前别把这条从 `fallback_providers` 当「还能用」——回退到死域名只会多等一次 DNS 超时。

会话实录：2026-10-25，用户问「目前你这个模型的上游，建一样的中转站需要什么」。先被按 fallback 链误答为腾白嫖，用户纠正「模型不是周三的吗」，随后实测核实如下。

## 事实（2026-10-25 实测）
| 项 | 值 |
|---|---|
| Hermes provider 名 | `周三`（config.yaml `custom_providers[]` 条目，主 model `Deepseek v4.1 Flash`） |
| 接口地址 | `https://token.thxnk.cc/v1`（旧：`<YOUR_PRIVATE_DOMAIN>`，已废） |
| key_env | `IKUN_API_KEY`（`~/.hermes/.env`） |
| 归属 | **第三方中转站，非自有节点**：域名解析到 Cloudflare `2001:db8::1…` / `2001:db8::1…`（套 CF 藏源站） |
| 面板程序 | New API（首页 `<title>New API</title>` + meta「Unified AI API gateway and admin dashboard.」实锤） |
| 在售模型 | Deepseek v4.1 Flash、Deepseek V4 Pro、GLM 5.3、GLM 5.3 Flash（`/v1/models` 恰好返回这 4 个） |
| 接入要求 | 必须带浏览器 User-Agent `extra_headers`（与「滴滴滴」同款 UA），否则可能被 WAF 拦 |

## New API 面板识别指纹（对周三站实测）
`GET /v1/models`（带合法 key）的 JSON 特征四件套：
- `"object":"list","success":true`
- 每个 model 条目 `"created":<YOUR_USER_IDENTIFIER>`
- `"owned_by":"openai"`
- `"supported_endpoint_types":["openai"]`

再配合首页 `<title>New API</title>` 即可定性。域名解析到 Cloudflare 段说明面板前置了 CF。

## 凭据边界
第三方中转站：聊天里只报 provider 名与模型 ID，不打印明文 key。用户自用可让他直接查 `~/.hermes/.env`（他自己配的）。

## 与腾白嫖的关系
两条完全不同的路线：周三 = 正规批发官方额度转售（Deepseek/智谱官方 key 垫资）；腾白嫖 = 自有 WorkBuddy2API 白嫖 CodeBuddy 积分（见 `self-hosted-gateway-credential-lookup.md`，其上游项目 2026-10-21 已停维）。