# 「周三」provider 档案（第三方 New API 中转站）

会话实录：2026-10-25，用户问「目前你这个模型的上游，建一样的中转站需要什么」。先被按 fallback 链误答为腾白嫖，用户纠正「模型不是周三的吗」，随后实测核实如下。

## 事实（2026-10-25 实测）
| 项 | 值 |
|---|---|
| Hermes provider 名 | `周三`（config.yaml `custom_providers[]` 条目，主 model `Deepseek v4.1 Flash`） |
| 接口地址 | `https://<YOUR_PRIVATE_DOMAIN>/v1` |
| key_env | `IKUN_API_KEY`（`~/.hermes/.env`） |
| 归属 | **第三方中转站，非自有节点**：域名解析到 Cloudflare `2001:db8::1…` / `2001:db8::1…`（套 CF 藏源站） |
| 面板程序 | New API（首页 `<title>New API</title>` + meta「Unified AI API gateway and admin dashboard.」实锤） |
| 在售模型 | Deepseek v4.1 Flash、Deepseek V4 Pro、GLM 5.3、GLM 5.3 Flash（`/v1/models` 恰好返回这 4 个） |
| 接入要求 | 必须带浏览器 User-Agent `extra_headers`（与「滴滴滴」同款 UA），否则可能被 WAF 拦 |

## New API 面板识别指纹（对周三站实测）
`GET /v1/models`（带合法 key）的 JSON 特征四件套：
- `"object":"list","success":true`
- 每个 model 条目 `"created":<YOUR_USER_IDENTIFIER>`
- `"owned_by":"openai"`
- `"supported_endpoint_types":["openai"]`

再配合首页 `<title>New API</title>` 即可定性。域名解析到 Cloudflare 段说明面板前置了 CF。

## 凭据边界
第三方中转站：聊天里只报 provider 名与模型 ID，不打印明文 key。用户自用可让他直接查 `~/.hermes/.env`（他自己配的）。

## 与腾白嫖的关系
两条完全不同的路线：周三 = 正规批发官方额度转售（Deepseek/智谱官方 key 垫资）；腾白嫖 = 自有 WorkBuddy2API 白嫖 CodeBuddy 积分（见 `self-hosted-gateway-credential-lookup.md`，其上游项目 2026-10-21 已停维）。