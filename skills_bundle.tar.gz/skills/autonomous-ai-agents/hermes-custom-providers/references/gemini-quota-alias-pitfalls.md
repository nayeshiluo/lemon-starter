# Gemini 官方 API：免费档 429 配额陷阱 + 别名不进 /model 菜单（2026-09-09 实测）

本机接入官方 Gemini（generativelanguage.googleapis.com）时的两个新坑，补充进
`google-official-gemini-provider.md` 主流程（该文件因去重守卫未能直接 patch，此处单独记录）。

## ⚠️ 免费档配额（429 quota exceeded）——高频探测打爆的误判陷阱

免费档 key 的 RPM（每分钟请求）/ RPD（每天请求）额度很低，**连续排查/批量探测十几发就会打爆**
（本机实测：为验证 key 连续测 10+ 次，直接把免费档打爆）。表现：

- `GET /v1/models` 仍 200（列模型不烧生成配额）→ key 本身有效
- `generateContent` / OpenAI 兼容 `chat/completions` 全部 `429 quota exceeded`
  （`You exceeded your current quota, please check your plan and billing details`）

**判定顺序（别误判成 key 失效/被封）**：
1. 先列模型：`GET .../models?key=<KEY>` 返回 200 + 模型列表 → key 活着
2. 区分 429 文案：`quota exceeded` = 配额耗尽（等冷却）；`API key not valid` = key 问题
3. RPM 分钟级自动恢复（等 1~2 分钟单发轻测）；RPD 按**太平洋时间午夜**重置（≈北京 15:00-16:00）
4. ⚠️ 2026-06 起 `AQ.` 前缀新 key 有已知 bug：免费档新 key 直接报 `429 limit: 0`/
   RESOURCE_EXHAUSTED（Google AI 开发者论坛多帖），老 `AIza` key 正常——若新 key 一上来就
   429 且额度为 0，优先怀疑这个已知问题而非自己打爆

**排查纪律**：验证官方 key 时**单发轻量测试**（1 次 generateContent "回复：正常"）即可，
不要循环/重复探测。

## ⚠️ 用户自定义别名不进 /model 菜单

`hermes config set model.aliases.<名> <provider>/<model>` 配的别名，在 CLI 与网关的
`/model <名>` **带参数命令**中可用，但**不会**出现在 /model 的 inline 交互菜单
（picker 只列 provider 名 + 模型清单，如 `gemini | Google AI Studio` 行及其模型清单）。
用户反馈"菜单里看不到【谷歌官】"是正常行为——引导其直接输入 `/model 谷歌官`
（或 `hermes chat -m 谷歌官`）即可，无需把别名硬塞进菜单。