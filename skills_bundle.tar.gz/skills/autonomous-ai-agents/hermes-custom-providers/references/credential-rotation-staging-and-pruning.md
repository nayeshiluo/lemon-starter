# 中转站 Key / Bot Token 的隐藏录入、身份核验与配置裁剪

适用：用户承认曾把模型 Key、Bot Token 贴进过对话，要求逐项轮换；或要求清理失效模型。
已实测走通：周三、哄哄、滴滴滴（中转站 API Key）、`@<PRIVATE_IDENTIFIER>_bot` / `@dafeiyu120_bot`（Bot Token）。
不保存任何真实密钥、指纹、端点或账号清单。

## 一、先判「轮换」还是「删线路」

**站点活着 ≠ 全线可用，某个模型家族挂了 ≠ 整条线路该删。**

1. 逐模型实测（不要只看 `/v1/models` 的宣称清单）：对配置里每个 model 发一次最小请求。
2. 分类：`401` = Key 失效（该轮换/撤销）；`503` / `no_healthy_account` / `11158` / `quota` = 模型或额度问题（**不是** Key 问题）。
3. 只要有一个模型正常返回内容，**线路保留**，处置是「裁剪死模型」；只有 Key 本身失效才删 Key。
4. 用户问「这家还能用吗」时，先跑这一步再回答，别凭印象或上次结论作答。实测里出现过同一站 `grok-*` 全 503 而 `gpt-*-luna` 正常的情况。

## 二、隐藏录入：给用户一条能直接执行的命令

不要让用户在聊天、截图、PDF 或命令行参数里交新密钥。固定做法：装一个**只暂存、不改 live** 的命令，用户在 SSH 交互终端里跑，`getpass` 隐藏输入。

起点用 `templates/credential_stage.py`（改顶部 CONFIG 段即可）。要点：

- 零密钥参数；`sys.argv` 必须为空；非 TTY（管道/非交互）直接拒绝并返回 2，不能退化成明文回显。
- 暂存文件 `O_EXCL | O_NOFOLLOW` + `0600`，父目录 `0700`；**绝不覆盖 live**；已有待处理文件时拒绝并让用户回聊天说明。
- 拒绝与旧值相同、拒绝格式不符、拒绝身份核验失败——三种情况都**不落盘**。
- 异常只回静态文案（`ValueError` 自产消息），不打印上游异常正文、值、前后缀或哈希。
- 装到 `/usr/local/bin/lemon-<名>-import`：`sudo install -o root -g root -m 0755`，装后断言 `installed.read_bytes() == source.read_bytes()` 且属主为 root，再跑一次非交互调用确认返回 2。
- 明确告诉用户：**连接哪台机器、哪个账号**（`Path.home()` 是 SSH 账号的家目录，不一定是服务账号；root 录入的文件不会落在 ubuntu 家目录）。提示「看到‘输入隐藏’再粘贴，不要在普通 Shell 提示符后粘贴」，并提醒清剪贴板。

### 身份核验必须验「是不是目标」，不能只验「有效」

这是本轮最值得复用的一条：**另一个同样有效的凭据贴错位置，一样会通过“有效性”检查。**

| 凭据类型 | 核验方式 |
|---|---|
| Telegram Bot Token | `GET /bot<token>/getMe`，同时断言 `result.username == 期望机器人` **且** `token.split(':')[0] == 旧token.split(':')[0]`（同一 bot id 前缀）。多机器人环境下只验有效性会把别的 bot 装进这个服务。 |
| 模型中转 Key | `GET /models` 返回 `data` 列表且非空；再加一次真实 `chat/completions` 带随机 nonce 要求原样回复，确认 `choices[0].message.content` 含 nonce。只验列表会把「能列模型但生成全挂」的 Key 当成功。 |
| 云服务 Token | 官方 verify 返回 `success` 且状态 active；详情接口 403 时标「完整策略未核实」，不反复重试。 |

推理模型 `max_tokens` 给 200+，否则思考占满预算、`content` 为空会被误判为坏 Key。

### 测试矩阵（随机假值，不碰生产值）

复制模板后先写测试再装：

1. 旧值被拒；2. 格式不符被拒；3. 身份核验失败被拒且未落盘；4. 新值暂存成功、权限 `0600`、**live 文件字节未变**；5. 重复暂存被拒（不覆盖）；6. 非交互调用返回 2；7. 真实 PTY 下提示出现、空输入被拒（`pty.openpty()` + `select` 读提示后再喂 `\n`）。

只测纯函数不算验收：非交互拒绝和隐藏输入要真跑一次 CLI 才作数。

## 三、切换顺序（Hermes 消费者）

1. 加密备份 live 文件（`sudo` + `Fernet`，解密后字节比对），确认可回滚。
2. 原子替换：只改目标那一行/那一条，`os.chown` 保持原属主、`os.replace`，并断言「把新值换回旧值后与原文完全相等」。
3. 重启网页侧（`hermes-web-ui.service`）与消息网关（`hermes-gateway.service`）——**由用户在独立终端做**，网页重启会掐断当前会话自己的进程。
4. 按 `selfhosted-service-audit` 的 `references/credential-rotation-and-egress-verification.md` §5b 验收：`.env` 不进 exec 环境（`/proc/<pid>/environ` 看不到是正常的）、用 `load_hermes_dotenv` + `resolve_runtime_provider` 验启动解析、用 `session_model_usage.billing_base_url` 证明没有静默回退、用 `_SYSTEMD_INVOCATION_ID` 取当次启动日志。
5. 全部消费者验收通过后，才让用户到后台删除/撤销旧值。
6. 用户确认删除后，用**旧值**再请求一次拿到 `401`，同时确认新值仍 `200`。只有这一步做完才算轮换完成；网络失败不等于旧值已失效。

Bot Token 的撤销只能由拥有该机器人的账号在 BotFather 里做（`/mybots` → 选 bot → `API Token` → `Revoke`）。**不要为自动化轮换另开正在运行的人形号 session 副本。** 撤销后旧 Token 立即失效、机器人停止工作，所以录入命令必须提前装好测好。

## 四、裁剪失效模型（保留线路）

只删配置里那条 provider 的**部分模型**时，用块级行手术，不要 `yaml.safe_dump` 整份重写（丢注释、易波及别处）：

```python
lines = raw.splitlines(keepends=True)
start = 该条目 'base_url:' 行索引 - 1
end   = 下一个 '  - api_mode:' 行索引
removed = [l for l in lines[start:end] if l.strip().startswith('- ')
           and l.strip()[2:].strip() in dead_models]
assert sorted(removed) == sorted('- ' + m for m in dead_models)   # 精确命中，不多删
updated = ''.join(l for l in lines if l not in removed)
old_doc, new_doc = yaml.safe_load(raw), yaml.safe_load(updated)
# 断言：目标条目 models 精确等于预期；base_url/key_env/extra_headers 未变；
#       把目标条目从两份文档摘掉后 old_doc == new_doc（其余配置逐字等价）
```

- 写入前加密备份，写后 `hermes config check`。
- **默认模型若指向被删的模型，必须同时改到保留下来的模型**，否则 `/model` 菜单正常但默认调用直接失败。
- 裁剪只影响菜单与可选项，已开着的进程可能仍缓存旧清单；不要求重启，但要如实说明生效边界。

## 五、汇报口径

- 分开报：`staged / policy_verified / consumer_updated / runtime_verified / old_rejected`，不能把「新值可用」写成「轮换完成」。
- 明确说清哪一步是**用户必须在原厂后台做的**（删旧值、BotFather 撤销、Atria 控制台吊销），别把本地删除说成已撤销。
- 本地删除只移除入口与 Key 行，**不会**让官网那串 Key 失效；这点必须讲明。
