# Command Code（commandcode.ai）接入与实测矩阵

2026-11-06 实测，账号为 GOAT 套餐（$10/月，含最多 $100 额度折算）。价格、套餐与模型目录都会变，
每次接入先现查 `/v1/models` 与官方 Pricing 页，不要把本文当长期事实。

## 一、端点

| 用途 | 路径 |
|---|---|
| OpenAI Chat Completions | `https://api.commandcode.ai/provider/v1/chat/completions` |
| OpenAI Responses | `.../provider/v1/responses` |
| Anthropic Messages | `.../provider/v1/messages` |
| 模型列表 | `.../provider/v1/models` |

- Base URL 填到 `/provider/v1`，不要再带 `/chat/completions`（Hermes 侧会自己拼）。
- **Claude 系只挂在 `/messages`**（`supported_endpoints: ["/messages"]`）。硬塞进
  `chat_completions` 的 provider 会 400。要么单独按 Anthropic 协议接，要么不要注册这些模型。
- `/models` 每条带 `supported_endpoints`，**先按它分组再决定注册哪些**，比逐个试快得多。

## 二、必踩：Cloudflare 1010（不是没权限，是 UA）

用 `Python-urllib/x.y`、`undici`、SDK 默认 UA 直接打 `chat/completions`，整站返回：

```
HTTP 403
error code: 1010
```

`/models` 却照常 200 —— 所以「列表能拉、对话全 403」时不要判成套餐无权或模型下架。
**必须带浏览器 UA**，落法是 provider 条目加 `extra_headers`：

```yaml
- name: command
  base_url: https://api.commandcode.ai/provider/v1
  key_env: COMMAND_API_KEY
  api_mode: chat_completions
  extra_headers:
    User-Agent: Mozilla/5.0
```

实测同一 key 加 UA 后 84 个候选里 57 个 200。**任何中转层（dsh overlay、自建 bot 的
endpoint 表、探针脚本）也必须透传这个头**，只给 Hermes 配了头、下游 bot 没带，那边会继续 403。

## 三、实测矩阵（2026-11-06，95 个标签 / 84 个 chat 候选 / 57 可用）

可用（节选，全部返回非空正文）：`reflection/beam:free`、`stealth/glyph-cluster:free`、
`deepseek/deepseek-v4.1-flash`、`deepseek/deepseek-v4.1-flash-fast`、`deepseek/deepseek-v4-pro`、
`deepseek/deepseek-v4-flash`、`deepseek/deepseek-v4-flash-vision-exp`、`z-ai/glm-5.3-flash`、
`zai-org/GLM-5.3`、`moonshotai/Kimi-K3.1-Pro`、`MiniMaxAI/MiniMax-M3`、`Qwen/Qwen3.8-Max`、
`xai/grok-4.6`、`mistral/mistral-large-4` 等。

失败分类（用于判断「该不该再试」）：

| 形态 | 模型 | 判读 |
|---|---|---|
| 403 | `gpt-6-astra` `gpt-6.1-sol` `gpt-6.1-terra` `gpt-6-sol` `gpt-5.6-terra` `gpt-5.5` `gpt-5.4` `gpt-5.3-codex` `gpt-5.4-mini` `google/gemini-4-argon` `google/gemini-3.6-flash` `google/gemini-3.5-flash` `google/gemini-3.5-flash-lite` `google/gemini-3.1-flash-lite` `sakana/fugu-ultra` `meta/muse-spark-1.1` `meta/muse-wonder-1.0` | 该档位无权，别再重试 |
| 400 | `zai-org/GLM-5.1` `MiniMaxAI/MiniMax-M2.7` `thinkingmachines/inkling` `inkling-small` | 请求被拒，非权限 |
| 404 | `Qwen/Qwen3.6-Max-Preview` `stepfun/Step-3.5-Flash` | 目录里有、路由没有 |
| 空正文 | `stealth/crouton-alpha` `meta/muse-spark-1.3` `1.3-contributor` `muse-spark-open` | 有 choices 但 content 空，不可用 |

## 四、免费模型与套餐额度是两件事

官方 GOAT 页当前写：

- **Glyph Cluster、Crouton Alpha**：各每天最多 1000 次请求（限时预览）。
- **Beam 1.0**：不扣额度、无每日上限，但注明「容量允许期间」。
- 套餐额度用完后付费模型停、**免费模型仍可用**。
- 页面上每个模型标的 `$100` 之类是**额度折算**，不是每个模型的独立余额，不能相加。

实测 `stealth/glyph-cluster:free` 与 `reflection/beam:free` 都能正常出文；`crouton-alpha` 空正文。

## 五、按角色选型（实测，不是看名字猜）

| 角色 | 选择 | 依据 |
|---|---|---|
| 群聊总结 / 归因类文本 | `reflection/beam:free` | 中文归因题答对，3.72s；工具往返 1.64s；SSE 正常 |
| 长文 / 复杂文本 | `deepseek/deepseek-v4.1-flash` | 归因正确 4.0s，工具往返 1.84s |
| 识图 / 视觉 | `deepseek/deepseek-v4-flash-vision-exp` | 红方+蓝圆的测试图描述完全正确 |
| **不要**用于归因 | `z-ai/glm-5.3-flash` | 同一道「报告负责人」题把人认错（小王 vs 小李） |
| **不要**用于视觉 | `reflection/beam:free`、`stealth/glyph-cluster:free` | 明确 400：`This API supports text input only` / `does not support image or file input` |

**免费 ≠ 全能**：两个免费模型都是纯文本，别拿它们顶掉有识图职责的 bot。

## 六、注册后菜单模型数偏多（未解决，如实报）

`custom_providers` 里只写实测通过的 57 个，但 `/model` 选择器仍显示 95 个（上游目录被合并）。
加 `discover_models: false` 未改变结果。**不要因此宣称「菜单只显示可用模型」**——菜单里
存在不可用条目，用户点到会 403。

## 七、验收顺序

1. `/models` + `supported_endpoints` 分组（先排除只走 `/messages` 的 Claude）
2. 单个请求校准 UA（不加 UA 全 403，会误判成整站废）
3. 并发粗筛 → 对失败项串行复测再定性
4. 注册后 `hermes chat --provider command -m <id>` 实测一条独特校验文本
5. 离线核菜单落点（`scripts/verify_provider_registration.py`），并如实说明菜单数 > 可用数
