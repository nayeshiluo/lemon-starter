# 多台自建 bot 的模型迁移：先找"共享 client"和"真实入口"

> 类场景：用户说「把 A 机器上的机器人、B 机器上的机器人，模型都换成 Command 主力 + 周三备用，
> 淘汰腾白嫖和 Gemini 的活跃调用」。这类任务不是改 Hermes 自己的 `config.yaml`，而是改**别人写的服务**。
> 本文记的是审计阶段必须核到的落点，以及一个真实翻车教训（预算耗尽在审计里）。

## 0. 先分清三种"配置"

| 类型 | 例子 | 是否生效 |
|---|---|---|
| 部署模板 / 仓库副本 | `/opt/ad-killer/config.json`（指向 `127.0.0.1:18317` + 旧 gemini 模型） | ❌ 运行时根本不读 |
| 真实运行时配置 | `/etc/ad-killer/config.json`，经 systemd `LoadCredential` 投递，代码读 `$AD_CONFIG` | ✅ |
| 代码里的默认值 / 硬编码 fallback | `AIClient` 里 `config['model']`、写死的备用端点 | ✅ 会盖过你的想象 |

**判定方法**：`systemctl cat <svc>` → 看 `ExecStart` / `Environment*` / `LoadCredential` / `DynamicUser`；
再 grep 代码里 `os.environ.get("<VAR>", "<默认路径>")`。只改仓库里的模板 = 完全无效，而且 git status 还会显示"有改动"，
骗你以为已经改好了。

`DynamicUser=yes` 的额外含义：
- 配置/凭据走 `LoadCredential=name:/etc/...`，进程内路径是 `$CREDENTIALS_DIRECTORY/name`，权限由 systemd 给（通常 0400、属主是动态 uid）；
- 状态目录是 `$STATE_DIRECTORY`、日志是 `$LOGS_DIRECTORY`，别去猜 `/var/lib/...`；
- **新增一个凭据文件必须同时改 unit**（`LoadCredential=ai-fallback-key:/etc/ad-killer/ai-fallback-key`）+ `daemon-reload`，光放文件进程读不到。

## 1. 共享 client = 换模型会静默打断别的功能

AdKiller 实测结构（`/opt/ad-killer`）：

```python
# bot.py:358-361
avatar_client = None
if ai is not None and isinstance(getattr(ai,'client',None), AIClient):
    avatar_client = AIClient(ai.client.config, ai.client.key)   # 复用同一份 config！
self.profile = Worker(Reader(Telegram(api.token)), avatar_client=avatar_client)
```

`profile_ads.py:371-381`（头像 AI 识别）和 `admission_profile.py:64-68` 都调 `avatar_client.review(...)`，
而 `review()` 里只有一个 `self.config['model']`。

→ **只把 `model` 换成纯文本模型，头像/图像审核会在下一次入群审核时静默失效**（模型 400 或回一段非 JSON，
`ReviewError` 被 worker 吞成 `label:"error"`，用户只看到"AI不可用"）。

迁移前的固定动作：`grep -rn "AIClient(\|\.review(" <服务目录>`，把所有复用同一 config 的调用点列出来，
再决定是拆 `vision_model` 字段（按 message 里有没有 `photo` 分流）还是给视觉单独建 client。

## 2. 没有 UA 的客户端在 UA 门禁线路上必挂

`ai.py` 原来的请求头只有：

```python
headers={'Authorization':'Bearer '+self.key,'Content-Type':'application/json'}
```

urllib 会补 `Python-urllib/3.x`。对 Cloudflare 1010 / WAF 类中转（腾白嫖、ikun 等）这就是 403。
**配置层改不了**（这不是 Hermes 的 `extra_headers`），必须在代码里加 `'User-Agent':'Mozilla/5.0'`。
同理，任何自建 bot 的 `requests.post(..., headers={...})` 都要先确认 UA。

## 3. 没有 fallback 的 bot 要"加"而不是"配"

AdKiller 的 `AIClient.review()` 是单次调用，失败直接 `raise ReviewError('model_http_…')`，
`ReviewWorker` 归类为 `AI不可用`。**它没有 fallback 机制可配**。要"周三备用"只能改代码：

```python
def _call(self, base_url, key, model, content): ...   # 抽出单次请求
try:
    return self._call(cfg['base_url'], self.key, model, content)
except ReviewError:
    if not (cfg.get('fallback_base_url') and cfg.get('fallback_model') and self.fallback_key):
        raise
    return self._call(cfg['fallback_base_url'], self.fallback_key, cfg['fallback_model'], content)
```

三个必须一起做的点：
1. fallback 的 base_url/key/model 都要能配（key 走独立 credential 文件，不进 config.json 明文）；
2. **fallback 也必须能处理图片**，否则主模型挂掉时头像审核整条失效——选备用模型时先实测它接不接受 image_url；
3. `parse_review()` 失败（返回非 JSON / 标签非法）也走 fallback，比只兜 HTTP 错更实用。

## 4. 证据必须落盘（本次的真实翻车）

本次审计把探针写成 heredoc 直跑，`exit 0` 但**每个模型的返回没有写文件**，压缩后无法作为验收证据；
随后又在"一条命令一个 heredoc"的节奏里把工具调用预算耗尽，**备份、改动、重启、验收全部没做**。

下次的硬性做法：
- 审计脚本一次写成文件（本地 `fleet_remote/*.py`），远端用 stdin 传，**所有结果 append 到 JSON 文件**再读回汇总；
- 顺序固定：`备份 → 改一个服务 → 验收 → 再改第二个`，不要"先把两台都审计到 100% 再动手"；
- 每台机器先落一份 `systemctl cat` + 关键文件 sha256 + 备份路径，写进结果 JSON 的骨架，后面只补字段。

## 5. 备份与回滚清单（systemd 服务）

```bash
TS=$(date -u +%Y%m%dT%H%M%SZ)
tar -czf /root/ad-killer-backup-$TS.tgz -C / opt/ad-killer etc/ad-killer etc/systemd/system/ad-killer.service
# 代码目录若在 git 里，另存 git diff 作为变更证据（本次 /opt/ad-killer 是干净 git 仓库）
```

- 凭据文件备份要保留权限（`install -m 600`），且**备份包里含密钥 → 不要放到可下载目录**；
- 改完用 `systemctl show -p InvocationID --value <svc>` 记录本次启动 ID，作为"确实重启过"的证据；
- 重启前确认同机独立 worker（如 `ad-killer-cleanup-*`）没在跑，别把清理任务拦腰截断。

## 6. 「全部换完」之前必须实测枚举消费者（本次被 Owner 当面点出）

第一轮按记忆列了服务清单就报「都换完了」，结果漏掉两个真实消费者：
一个独立平台的**第二人型号**（TeleBox）和一个群管 Bot（SGB）。教训不是「记性差」，而是
**「全部」这个词要求的是实测清单，不是印象清单**。

固定动作（每台主机都跑，别只跑当前机）：

```bash
systemctl list-units --all --plain --no-pager | grep -iE 'bot|userbot|assistant|agent'
docker ps -a --format '{{.Names}}\t{{.Image}}\t{{.Status}}'
```

拿到清单后逐个判「有没有模型调用」，别按项目名猜：

```bash
grep -rlInE 'chat/completions|generateContent|/v1/models|base_url|api_base|model' \
  --include=*.py --include=*.ts --include=*.js --include=*.json --include=*.yaml <服务目录> \
  | grep -vE 'node_modules|venv|\.git'
```

反面样本（本次真实存在但第一轮没查）：
- `/opt/telebox-test` + `telebox-second-account.service`（Node/TS，7 个插件都有模型调用）；
- `smart-group-bot-bot-1`（Docker，模型配置在 sqlite `runtime_config.payload`，不在任何 json 文件里）。

**配置文件搜不到 ≠ 没有模型调用**：SGB 这类把配置存 DB 的服务，grep 文件是查不到的，
必须读库（`select payload from runtime_config`）。枚举阶段就要把「配置在 DB」这种情况列进来。

## 7. 协议不兼容时用本地桥接，别去改别人的源码

老服务写死的端点常常不是标准 OpenAI 兼容，直接换 `base_url` 会坏在三处：
上游按 UA 拦人、协议是 Gemini 原生 `:generateContent`、端点不止对话（还有 `/images/generations`）。

**做法：在服务本机起一个薄桥接（`127.0.0.1` 高端口），服务只改 base_url，不碰源码。**
桥接固定承担四件事：

1. **统一注入上游必需 header**（UA、鉴权）—— 服务侧通常不支持自定义 header，这一层替它补；
2. **协议转换**：Gemini `contents/parts` ↔ OpenAI `messages`，响应再包回 `candidates/parts`；
3. **多上游梯队**：主力 → 次选（同厂另一模型）→ 备用站，服务侧只看到一个端点；
4. **非对话端点原样透传**给原上游，并**原样回传上游状态码**。

第 4 条是保命项，两个必踩的细节：

- 桥接不认识的路径（`/v1/images/generations`、`/v1/images/edits`、视频任务）必须透传，
  否则出图能力直接消失；Gemini 侧还要判 `generationConfig.responseModalities` 含 `IMAGE`
  时同样透传，不能当文本请求转走。
- `urllib` 对 4xx/5xx 抛 `HTTPError`，不捕获就会把上游 `429 model_cooldown` 压成自己的 `502`，
  排查时会误以为是桥接坏了。必须 `except HTTPError: return e.code, ..., e.read()`。
  验收方法：同一请求分别打**原上游**和**桥接**，两边的状态码与错误正文必须一致。

桥接自身的边界要主动说清：**只做非流式**。被迁移服务若开了 `stream: true`，
要么补 SSE 透传，要么先把它的 `stream` 关掉再切。

部署形状（`systemd` + 目录外置密钥，别把 key 写进代码）：

```
/opt/<name>-ai-bridge/bridge.py          # 0755
/etc/<name>-ai-bridge/config.json        # 0600，写 primary/secondary/fallback/passthrough_base
/etc/<name>-ai-bridge/{command,zhou}.key # 0600，config 里用 "file:/..." 引用
```

`ProtectHome=true` + `ProtectSystem=strict` 时记得把配置目录加进 `ReadOnlyPaths`，
否则进程读不到自己的 config。

## 7b. 共享端点池改了 key 形态 = 所有消费者同时断链（本次复验才抓到的真故障）

服务之间共享一个 `ai_endpoints.json` 式的端点池时，**池的 schema 变更是跨服务的破坏性变更**。

本次事故链：把池里 `command`/`zhousan` 的明文 `key` 换成 `key_env`（凭据进 `.env`），
但**每个消费方各写了一份 `_load_fleet_endpoints()`**，只有群霸的 `ai_service.py` 支持 `key_env` 解析：

| 消费者 | 解析逻辑 | 结果 |
|---|---|---|
| 群霸 `services/ai_service.py` | 原生支持 `key_env`（`_read_env_val`） | ✅ |
| `lemon-userbot/userbot.py` | 只读 `node["key"]` | ❌ `fleet endpoint pool unavailable` |
| `lemon-ops-bot/main.py` | 只读 `node["key"]` | ❌ 同上，`/ai` 指令整条断 |

两个断掉的消费者**配置全对、服务也 active、菜单也正常**，只在真调用时抛 `RuntimeError`。
上一轮汇报「已完成」时只验了 LemonOps 的**菜单**，没跑 `/ai` —— 用户要求复验才暴露。

**规则**：
1. 改共享池的字段形态前，`grep -rn "_load_fleet_endpoints\|ai_endpoints" <所有服务目录>` 列出全部消费者；
2. 每个消费者补上同样的兜底 resolver（进程环境 → `~/.hermes/.env` 按行匹配），不要假定「池改了大家都认」；
3. 验收必须**逐服务跑一次真实业务函数**（`call_llm_api()` / `call_gemini_llm()` / `ask_ai()`），
   不是「服务 active + 配置文件 grep 到新值」；
4. 更好的做法是让池**同时接受两种形态**（`key` 明文 ∪ `key_env` 引用），迁移期不会断链。

## 7c. SGB 的 runtime_config 有两个硬约束，绕过就静默不生效

SGB 的模型配置存在 sqlite `runtime_config` 表的 `payload` JSON 里。手写这条记录时：

**① `id` 必须恒为 1。** `INSERT` 一行 `id=2` 后，运行时仍读 `id=1`（代码按 `id=1` 取），
配置看起来已写入、重启后毫无变化。正确做法是 `UPDATE runtime_config SET payload=?, revision=revision+1 WHERE id=1`，
多出来的行要删掉。

**② 密钥不能留在 payload 里，必须写 `runtime_config_secrets`（Fernet 加密列）。**
`RuntimeConfig.storage_payload()` 会调 `with_secrets({})`，把 `providers.*.api_key` **清空**。
payload 里塞明文 key 的表象是：配置读出来 key 是空串 → `litellm.InternalServerError:
Missing credentials. Please pass an api_key...` → 每个角色 2 次重试后 `LLM exhausted`。

写入形状（`CONFIG_MASTER_KEY` 从容器 env 取）：

```python
from bot.services.runtime_config import SecretCipher
cipher = SecretCipher(os.environ["CONFIG_MASTER_KEY"])
for name, val in {"providers.command.api_key": KEY, "providers.embed-local.api_key": "local"}.items():
    con.execute("INSERT INTO runtime_config_secrets (name,ciphertext,updated_by,updated_at) "
                "VALUES (?,?,0,datetime('now')) ON CONFLICT(name) DO UPDATE SET ciphertext=excluded.ciphertext",
                (name, cipher.encrypt(val)))
```

写完必须**回读解密验证**（`cipher.decrypt(...)` 长度非 0），再看日志里
`stage=<role> | model=... | LLM response` 才算通。

顺带：`docker exec` 跑容器内脚本时，容器 `/tmp` 可能不可写（uid 不匹配），
改用 `docker exec -i <c> python3 - < 本地脚本.py`（stdin 传入）比 `docker cp` 稳。
读 `config.toml` 需要 `-u root`，否则 `PermissionError`。

## 7d. reasoning 模型的 max_tokens 阈值：低于阈值 = 200 但正文空

`reflection/beam:free` 这类 reasoning 模型，思维链与正文**共用同一个 token 预算**。
实测（同一 prompt，只改 max_tokens）：

| max_tokens | content | finish_reason |
|---|---|---|
| 20 | `""` | `length` |
| 64 | `MAIN_OK` | `stop` |
| 256 / 1024 | `MAIN_OK` | `stop` |

**HTTP 200 + 空正文 + `finish_reason=length` 不是链路故障**，是预算不够。
排查顺序：先看 `finish_reason`，再调大 max_tokens 到 200+ 复测，最后才怀疑上游。

迁移后要逐个核角色的预算，本次全部安全：

| 服务 | 角色 | max_tokens |
|---|---|---|
| SGB | main / vision / compress / decision / moderation | 2048 / 2048 / 1024 / 512 / 1024 |
| AdKiller | review | 700 |
| LemonOps | `/ai` | 2500 |
| TeleBox | persona / music | 512 / 200 |

以后谁把预算调到 64 以下，症状就是「200 但空回复」，别当链路坏。

## 7e. TeleBox（Node/TS 人型号）7 个插件的落点与协议速查

改 base_url 前先确认每个插件**自己怎么拼路径**，拼错就是 404 而非配置错误。
配置文件全在 `/opt/telebox-test/app/assets/<plugin>/`：

| 插件 | 配置文件字段 | 拼接规则 | 协议 |
|---|---|---|---|
| `agent` | `agent/config.json` → `providers.*.base_url` | `base_url` + `/chat/completions` | OpenAI |
| `uai` | `uai/config.json` → 同上 | 同上 | OpenAI |
| `persona` | `persona/config.json` → `base_url` | `base_url` + `/chat/completions` | OpenAI |
| `xmsl` | `xmsl/config.json` → `baseUrl` | 同上（注意字段名是 `baseUrl` 驼峰） | OpenAI |
| `ai` | `ai/config.json` → `configs.*.url` | `url` + `/chat/completions` | OpenAI |
| `sum` | `sum/summary_config.json` → `aiConfig.providers.*.base_url` | **`normalizedBaseUrl()` 会先 strip 掉末尾 `/v1` 或 `/v1beta`**，再拼 `/v1/chat/completions` | OpenAI |
| `music` | `music/music_config.json` → `music_gemini_base_url` | `base_url` + `/v1beta/models/<model>:generateContent?key=` | **Gemini 原生** |

两个坑：
- `sum` 的 `normalizedBaseUrl` 已经把 `/v1` 归一化掉，所以填 `.../v1` 或 `...` 都对；填 `.../v1/v1` 才错。
- `music` 是 Gemini 原生协议且 key 走 **query 参数**，桥接必须实现 `:generateContent` 转换，
  不能只做 OpenAI 兼容（`persona` 的 `type: gemini` 同理）。

迁移后按插件**真实请求格式**逐个打一遍（不是只打一个 `/chat/completions` 就算完）——
本次 7 条全 200 才算交付。同时注意 `plugins/tts.ts` 走的是 **Azure TTS**（`zh-CN-XiaoxiaoNeural` + region），
与模型站无关，别以为换了模型厂家语音也跟着换。

## 8. 有的应用 schema 根本不给你加 header（SGB 的 StrictModel）

SGB 的 `ProviderConfig(StrictModel)` 只有 `name / provider / api_key / api_base / stream / chat_endpoint`，
**没有 `extra_headers`** —— 想在它里面给 command 补 Mozilla UA 是做不到的（多传键会被 StrictModel 拒）。
这类应用同样只能走第 7 条的本地桥接。

顺带一个可复用的判定：**容器是 `network_mode: host` 时，容器内 `127.0.0.1` 就是宿主机**，
桥接/本地 embedding 服务不需要额外网络配置（实测容器内直接 curl 到宿主机 `127.0.0.1:8491` 成功）。
非 host 网络则要用 `host.docker.internal` 或网关 IP，别照抄。
