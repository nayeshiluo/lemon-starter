# NOFX 通道 (nofx.one) 模型实测清单与端点配置

## 端点概要
* **网关端点**：`https://17674ef6d3e7.nofx.one/v1`
* **协议兼容**：OpenAI (`/v1/chat/completions`, `/v1/images/generations`), Anthropic (`/v1/messages`), Gemini (`/v1beta/`)
* **鉴权方式**：`Authorization: Bearer $NOFX_API_KEY` 或 `x-api-key`
* **环境变量**：`NOFX_API_KEY`

## 模型实测清单

| 模型名称 | 端点 | 实测状态 | 响应耗时 | 特性说明 |
| :--- | :--- | :---: | :---: | :--- |
| `gpt-5.6-terra` | `/v1/chat/completions` | ✅ 可用 | ~2.3s | 极速响应分支，推荐设为主默认/日常使用 |
| `gpt-5.6-sol` | `/v1/chat/completions` | ✅ 可用 | ~3.6s | 高速稳定分支 |
| `gpt-5.6` | `/v1/chat/completions` | ✅ 可用 | ~26.5s | 旗舰复杂推理模型 |
| `codex-auto-review` | `/v1/chat/completions` | ✅ 可用 | ~1.3s | 代码审查专精模型 |
| `gpt-image-2` | `/v1/images/generations` | ✅ 可用 | ~22.5s | **纯生图模型**，不支持 Chat Completions (报 400)，返回 Base64 图像 |

## 诊断与排障要点
* **403 `INSUFFICIENT_BALANCE`**：
  * 当后台 Token 未分配额度或账户余额为 0 时，`GET /v1/models` 和所有调用均直接抛 `403 INSUFFICIENT_BALANCE`。
  * 遇到此报错不代表密钥格式错误或服务不可达，需在 nofx 控制台为 Token 分配额度后即可恢复。
* **生图与对话端点隔离**：
  * 在配置 `custom_providers` 的 `models` 列表时，切勿将 `gpt-image-2` 混入 chat 列表，避免 agent 调用对话时触发 400 报错。
