# 下线一家中转站前的全量盘点

触发语：「command / LG / 某家过两周我要删掉，目前有哪些地方用到它」「我要对它进行更换」。

这是**只读审计任务**，不是改配置任务。先把引用面盘干净、把用量摆出来，再谈替换顺序；
用户没说删就**不要动任何生产路由**。

## 一、盘点矩阵（本机 naye，2026-11 `command` 中转实测）

| 层 | 查什么 | 注意 |
|---|---|---|
| Hermes 默认路由 | `config.yaml` → `model.default` + `model.provider` | **常就是这家**，单看 `fallback_providers` 会漏 |
| Hermes fallback | `fallback_providers[].provider/base_url/key_env/model` | 读 `purpose` 字段理解它为什么在那儿 |
| Hermes 辅助能力 | `auxiliary.vision` / `summarization` / `compression` 的 `provider` + `fallback_chain` | `fallback_chain: []` = 硬依赖，最难替代 |
| Hermes 模型清单 | `custom_providers[<名>].models` 条数 | 删条目 = 这些模型 ID 全部失效（本次 95 个） |
| 群聊 bot 共享池 | `<bot>/data/ai_endpoints.json` | 一般只写 `key_env`，key 不落地 |
| 群聊 bot 每实例 | `data/ai_bot_<botid>.json` 的 `order` / `disabled_nodes` / `summary_model_overrides` | 节点排在 order 第几位决定影响面；`order: []` 的 bot 不构成阻塞 |
| Docker 化 bot | `bot.db` → `runtime_config.payload` → `models.{main,vision,decision,moderation,compress}` | 每个角色各有 `provider` + `fallbacks[]`，**grep 源码查不到** |
| coding agent CLI | `~/.config/opencode/opencode.json` 的 `model`；`~/.dsh/settings.yaml` | opencode 可能把这家 pin 成默认值 |
| 其它网关 | magpie `~/.config/magpie/providers.json` 的 provider 列表 | 与 Hermes 里 magpie 的 `models` 清单是两回事：本次 magpie 有 `command` provider，但 Hermes 的 magpie 清单里 `command/*` 为 0 条，所以不影响 Hermes |
| 进程环境 | 遍历 `/proc/*/environ` 找 `<NAME>_KEY` | 判断是否有常驻进程缓存了凭据 |
| 远端主机 | 逐台 `ssh <h> 'grep -rln "<host>" /opt /home /root /etc/systemd'` | 本次 5 台（vps-la/vps-hk/aliyun/diaomao/yecao）全空，但必须扫过才能说"没有" |

排除噪声：`backup*`、`*.bak*`、`/deploy/`、`state-snapshots`、`__pycache__`、`/dist/`、`node_modules`、
`.git/`、`cache/blocked`、`private/model-migration-*`。不排除会被 50+ 条假命中淹掉真落点。

容器内 SQLite 的读法（表结构不是固定的，先看列名）：

```python
import sqlite3, json
c = sqlite3.connect('/app/data/bot.db')
print([r[1] for r in c.execute("pragma table_info(runtime_config)")])
# 实测列：id, schema_version, revision, payload, updated_by, updated_at
d = json.loads(c.execute("select payload from runtime_config order by rowid desc limit 1").fetchone()[0])
for role in ('main', 'vision', 'decision', 'moderation', 'compress'):
    r = d['models'].get(role) or {}
    print(role, r.get('provider'), r.get('model'), [f.get('provider') for f in r.get('fallbacks') or []])
```

## 二、用量归因（决定"能不能直接删"）

```sql
-- 按天（北京时区）看是否仍有真实调用
select date(last_seen,'unixepoch','+8 hours') d, count(distinct session_id), sum(api_call_count), sum(input_tokens)
from session_model_usage where billing_base_url like '%commandcode%' group by 1 order by 1 desc limit 10;

-- 按模型，配合 max(日期) 判断哪个模型已自然停用
select model, sum(api_call_count), max(date(last_seen,'unixepoch','+8 hours'))
from session_model_usage where billing_base_url like '%commandcode%' group by 1 order by 2 desc;
```

判定口径：

- **每天都非零 = 不能直接删**，必须先把消费方迁走再说（本次近 10 天无一天为 0，当天仍有 22 次调用）。
- `billing_provider` 会分裂成 `command` / `custom` / `custom:command` 三种写法，**按 `billing_base_url` 归集才不漏**。
- 也要看 `sessions.model` 的近期分布：cron 会话常因未指定 model 而落到 `fallback_providers[0]`，
  等于「偷偷在用这家」——本次就有一条 cron 会话在跑 `stealth/glyph-cluster:free`。
- 表结构坑：`sessions` 的时间列是 `started_at` / `last_activity_at`，**没有 `updated_at`**；
  `session_model_usage` 是 `first_seen` / `last_seen`。写 SQL 前先 `pragma table_info`。

## 三、替换顺序

1. **先解决唯一的视觉源**。全 provider 扫一遍带 `vision`/`vl`/`omni` 的候选（本次只有 LG 的
   `HY-Vision-2.0-instruct`/`nemotron-3.5-super-vl` 与 magpie 下 `trae-cn/Doubao-Seed-*`），
   然后**逐个实测能不能真收图**——名字带 omni 不等于支持图片输入，别按名推断。
2. 再迁主模型 + `fallback_providers`（有现成替代项时风险低）。
3. 群聊 bot：删两个节点、清 `*_model_overrides`，注意 `disabled_nodes` 里可能还留着指向已删 id 的残留。
4. Docker 化 bot：改 `runtime_config` 后**必须 `docker restart`**，apply callback 只在本进程内触发。
5. coding agent CLI 改默认 `model`。
6. 收尾复扫 `/proc/*/environ` 与增量用量，确认没人再打这个域名。

## 四、汇报口径

分三块，不要揉成一段：

- **必须改**（表格：位置 / 当前值 / 影响），标出哪一处是硬依赖
- **用量现状**（按天 + 按模型，用来回答"能不能直接删"）
- **硬约束 + 建议顺序**（明确说"视觉这一环必须先实测出替代源"，其余都能平滑切）

结论要区分「仍在用」与「有引用但已停用」：`disabled_nodes` 命中、`order: []` 的 bot 都不构成阻塞项，
不要把它们算成"必须改的地方"来吓人。

## 五、别踩

- 用假 `bot_id` 调 `lemon-group-bot` 的 `ai_service.load_bot_ai_config()` / `load_ai_nodes()`
  会**自动创建** `data/ai_bot_<假id>.json`（`order` 为空）。探测请用真实 bot id（从
  `ls data/ai_bot_*.json` 取，多为数字 Telegram bot id）；误建了用
  `find data -maxdepth 1 -newermt '-15 minutes'` 自查并删掉，然后**如实告知用户**。
- 用户只问"有哪些地方会用到"，**不等于**授权改路由。盘点阶段一个字都不要写。

## 六、执行阶段实录（2026-11-16 `command` → 周三，含一次真实事故）

用户说「你换了，然后模拟测试一下」= 授权全量替换 + 自测。

### 6.1 先实测候选，别照着配置清单挑

盘出来「把 command 换成 X」时，X 必须逐个发真实请求验过。本次实测结果很说明问题：

| 候选 | 结果 |
|---|---|
| 周三 `Deepseek v4.1 Flash` | 200 / 3.1s ✅ 选为主模型 |
| 周三 `GLM 5.3` | 200 / 3.5s ✅ |
| magpie `workbuddy2api/global:glm-5.3` | 200 / 1.8s ✅ 选为 fallback 首层 |
| magpie `workbuddy2api/global:glm-5.3-flash` | 200 / 6.4s ✅ |
| 腾白嫖 `cn:*`（原 fallback 目标） | **503 `no_healthy_account`**（整池，模型无关） |
| 哄哄 `deepseek-v4.1-flash` | **502 `Upstream service temporarily unavailable`** |
| magpie `free-pi/*`（原 fallback 目标） | **403 `ads_required`** —— 广告制，本来就不该当兜底 |
| 反重力 `gpt-5.6-sol` / magpie `codex/gpt-6-astra` | 400 `not supported when using Codex with a ChatGPT account` |

**结论**：原有 fallback 里两条其实是死的，「换 provider」顺手把兜底链修活了。
`free-pi` 这类「免费无限」宣传的通道要按 `ads_required` 判，别当稳定兜底。

### 6.2 最终链路（可作为同类替换的模板）

```
主模型   custom:周三 / Deepseek v4.1 Flash
fallback magpie / workbuddy2api/global:glm-5.3           （跨故障域：本地网关）
         周三   / GLM 5.3                                  （同站不同模型）
         magpie / workbuddy2api/global:glm-5.3-flash      （网关内另一池）
vision   整块删除（用户明确「视觉不要了」）
```

三层刻意覆盖两个独立故障域（本机 magpie 网关 / 周三中转），不要三层全落同一个网关。

### 6.3 事故：行级块替换把 config.yaml 从 950 行写成 23 行

写 fallback 块时用「找以 `']` 结尾的行」判断块结束位置，结果多行标量一路吃到文件末尾，
`database` / `agent` / `telegram` / `custom_providers` 全被删。**恢复靠事前的整文件 `cp` 备份**，
`cp` 回来 + `yaml.safe_load` 校验 32 个顶层键后重做。

正确做法见 SKILL.md「4.1 执行阶段」第 1 条：**用下一个顶层键 `database:` 定边界 + 锚点断言**，
写完四连校验（能解析 / 顶层键数 == 备份 / 关键长字段在 / diff 只含预期段）。

### 6.4 fallback 机制的真实性验证

配置正确 ≠ 会切换。造故障验证（本次实测成功落到首层）：

```bash
hermes config set model.default "nonexistent-model-fallback-test"   # 标量键安全
hermes -z "只回复：fallback已接管" -t ""                             # 输出正常
# state.db: sessions.model = workbuddy2api/global:glm-5.3, billing_base_url = http://127.0.0.1:3425/v1/
hermes config set model.default "Deepseek v4.1 Flash"
```

`sessions.billing_*` 显示首层模型和地址 = 铁证，比 grep 日志可靠。
另：三层单独用 `--provider`/`-m` 各跑一次 `hermes -z`，确认每层自身可用。

### 6.5 容器化 bot（smart-group-bot）的改法与验证陷阱

改 `runtime_config.payload` 的正确姿势：读最新 revision → 改 dict →
`update ... set payload=?, revision=rev+1, updated_by=?, updated_at=?` → `docker restart`。
`vision` 角色直接 `models.pop('vision')`；providers 里删掉该家条目。
写前先在容器内 `sqlite3.backup()` 做冷备（70MB 级别，`docker cp` 不可靠）。

⚠️ **验证时最大的陷阱**：容器内 `load_settings('/app/config.toml')` 读的是**过时静态配置**
（本次读到 `gemini-3-flash` + 已废的 8317 端点，四个角色全 401），
而实际运行时是 `RuntimeConfigManager.initialize()` 用 `bot.db` 覆盖进去的。
拿静态文件构造 `LLMService` 去测，会得出「改坏了」的错误结论。
→ 要么走 `RuntimeConfigManager` 的真实加载路径，要么如实报「该项未验证」，不要拿静态结果充数。
容器内跑脚本还有两个权限坑：`docker cp` 进去的文件属主 1000、容器进程非 root 读不了，
需 `docker exec -u root chmod 644`；`/app/config.toml` 同样非 root 不可读，脚本得 `-u root` 跑。
