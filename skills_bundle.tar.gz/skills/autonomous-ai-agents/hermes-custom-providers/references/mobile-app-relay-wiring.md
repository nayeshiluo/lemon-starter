# 手机端 AI 客户端接中转站（Open Minis 实测，2026-11-15）

场景：用户问「LG/某中转的模型怎么在 XX 客户端里用，我该怎么填」。
手机端客户端普遍只有「OpenAI / Anthropic / Gemini」三类入口，没有独立的
「自定义 OpenAI 兼容端点」条目——**要走 OpenAI 那一栏 + 自定义 base URL**。

## 0. 通用四件套（任何客户端都按这个顺序给）

1. **provider 类型**：OpenAI 兼容中转一律选 `OpenAI`，不要选带 Responses/Codex 字样的类型。
2. **base URL + 是否自动补 `/v1`**：二选一，绝不能两个都写 `/v1`（会拼成 `/v1/v1` → 404）。
3. **模型名**：中转的 `/v1/models` 常常是空的（LG 就是），必须手动加模型 ID，别指望自动扫描。
4. **User-Agent**：中转站常按 UA 放行，客户端若支持自定义 UA 就填一个浏览器 UA。

给用户写填法时用表格（字段 / 填什么），并把「地址与 /v1 别重复」单独拎出来当坑位提示。

## 1. Open Minis（openminis.app，iOS + Android，GPL v3）

识别特征：移动端开源 AI Agent，自带 Alpine Linux 沙盒、浏览器自动化、Skills、设备集成。
用户口中的「minis」基本就是它。字段名已从源码核实
（`src/ios/Providers/ProviderInstance.swift`、`src/android/.../data/model/ProviderConfig.kt`）。

### 入口
设置 → AI 提供商（Providers）→ 添加 → 类型选 **OpenAI**。

### 字段映射

| 界面字段 | 源码字段 | 填什么 |
|---|---|---|
| 类型 | `providerType` | `openAI`（**不要** `openAIResponses` / “Responses API (v3)”） |
| 名称/标签 | `label` | 随便，如 `LG` |
| 凭证 / API Key | `credentialType = apiKey` | 中转的 key |
| 自定义 API 地址 | `customBaseURL` | 只到域名，如 `https://leguanai.qutama.de` |
| 自动附加 "/v1" | `appendV1Suffix`（默认 true） | **打开** |
| 自定义 User-Agent | `customUserAgent` | 浏览器 UA（见下） |
| Azure 模式 | `azureMode`（默认 false） | **关** |

浏览器 UA（LG 这类中转用）：
`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36`

### 已核实的行为
- `providerType` 枚举只有：anthropic / gemini / openAI / openRouter / xAI / kimiCode /
  githubCopilot / openAIResponses / antigravity / unsupported。**没有独立“自定义 OpenAI 兼容”类型**，
  自建端点一律借用 `openAI` + `customBaseURL`。
- 默认走 **Chat Completions**；只有选 `openAIResponses` 类型（或内部 `forceResponsesAPI`）才打
  `/v1/responses`。中转是 chat_completions 的，选错类型会 404。
- `customUserAgent` 是**真支持**的：`applyUserAgentOverride()` 里非空即覆盖，空则回落到
  `Minis/<ver> (iOS/Android <ver>; <model>)` 品牌 UA。它作用于 chat / models / responses 请求；
  OAuth 类 provider 保留各自的客户端 UA 不被覆盖。
- `appendV1Suffix=false` 是给「URL 已含完整路径」的端点用的（如 `https://host/api/v2`）。

### 排查顺序（客户端侧）
1. 报 404 / 路径双 `/v1` → 检查 `customBaseURL` 与 `appendV1Suffix` 是否重复。
2. 报 `model_not_found` 或模型列表空 → 手动加模型 ID；先在中转侧用最小 chat 验活，别怀疑 key。
3. 报 401 → key 或分组问题，回中转侧验。
4. 报 `No available channel ... under group <x>` → **中转侧渠道池挂了，不是客户端配置**。
   同一时刻换模型/换 UA 全报同样错即可确认。

## 2. 其他同类客户端（未逐个实测，只列入口类型）
Cherry Studio / Chatbox / RikkaHub 等：同样是「OpenAI 兼容」条目 + base URL + 手动模型名，
坑位一致（`/v1` 重复、模型列表空、UA 白名单）。实测过再往这里补具体字段。
