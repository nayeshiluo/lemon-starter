# Atria ASI 接入与评测记录

## 基本信息
- **服务商**：Atria ASI (`https://api.atria-asi.ai`)
- **底座自述**：上海人工智能实验室（Shanghai AI Laboratory）
- **协议兼容**：OpenAI 兼容接口 (`/v1/models`, `/v1/chat/completions`)
- **Key 环境变量**：`ATRIA_API_KEY` (写入 `~/.hermes/.env`)
- **Provider 命名**：`Atria`

## 可用模型与来源核验
- 官方 API 门户与文档（https://api.atria-asi.ai/ 、https://api.atria-asi.ai/docs）现推荐模型 ID `Atria-Dawn`，公告称兼容旧 `Atria-Dawn-Preview`。官方文档标注当前 Dawn 为纯文本、512K 上下文；不可把 Preview 的规格套给 Dawn。
- 官方 Hugging Face 模型卡 https://huggingface.co/internlm/Atria-Dawn-Preview 说明 Preview 由上海人工智能实验室开发，基于 GLM-5.2 744B MoE。该证据只支持 Preview 的技术来源，不能证明当前 Dawn 托管接口底座完全相同。
- 官方门户公告称 API 额度收紧，并建议国内或高用量用户考虑其链接的端砚 Token Plan；额度、价格与当前可用性须实时核验，不能沿用历史免费假设。
- 现存配置指向官方模型卡列出的品牌 API 域名，可核对为官网接入，不代表已独立证明上游运行权重或不留存数据。实测结果与官方自报跑分分开陈述。

## 耗时与特性
- 首包及全量返回因思考耗时相对较长（约 8~25s，推理过程生成大量 reasoning tokens）。
- 适合高难度编程、长思考推理任务，不建议挂在即时群聊快速问答场景。
- 注册时 models 仅列入 `Atria-Dawn-Preview` 即可。
