# Atria ASI 接入与评测记录

## 基本信息
- **服务商**：Atria ASI (`https://api.atria-asi.ai`)
- **底座自述**：上海人工智能实验室（Shanghai AI Laboratory）
- **协议兼容**：OpenAI 兼容接口 (`/v1/models`, `/v1/chat/completions`)
- **Key 环境变量**：`ATRIA_API_KEY` (写入 `~/.hermes/.env`)
- **Provider 命名**：`Atria`

## 可用模型
- `Atria-Dawn-Preview`：具备 CoT 思维链深度推理能力（返回 `completion_tokens_details.reasoning_tokens`），逻辑与数理推导能力扎实，代码生成质量高。

## 耗时与特性
- 首包及全量返回因思考耗时相对较长（约 8~25s，推理过程生成大量 reasoning tokens）。
- 适合高难度编程、长思考推理任务，不建议挂在即时群聊快速问答场景。
- 注册时 models 仅列入 `Atria-Dawn-Preview` 即可。
