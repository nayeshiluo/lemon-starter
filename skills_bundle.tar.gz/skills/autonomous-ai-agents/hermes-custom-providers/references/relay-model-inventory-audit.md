# 中转站模型清单审计与「模型回退」告警排查

2026-10-20 实录。适用场景：运维 Bot 报「AI链路告警 / 模型回退次数超限」，或怀疑某 provider 的
`models` 清单里混入不可用条目。

---

## 一、告警来源：`ai-model-healthcheck.py`

本机 AI 链路告警由 **`/home/ubuntu/hermes-jobs/ai-model-healthcheck.py`** 产生（另有历史副本在
`hermes-jobs/jobs/cpa-legacy-retire-20261016/ai-model-healthcheck.retirement-candidate.py`，勿误改）。

关键机制：

| 项 | 值 |
|---|---|
| 扫描目标 | `/home/ubuntu/.hermes/logs/agent.log`（+ `.log.1`，各读尾部 8MB） |
| 判定字符串 | 行内含 `Fallback activated:` |
| 统计窗口 | `EVENT_WINDOW_SECONDS = 30*60` |
| 告警阈值 | 窗口内 ≥2 次 → `hermes_fallback` 置 ALERT |
| 告警文案 | `Hermes 过去30分钟累计发生 N 次模型回退` |
| 状态文件 | `hermes-jobs/status/ai-model-health.state.json` |
| 运行日志 | `hermes-jobs/status/ai-model-health.log`（`AI_MONITOR <ISO> status {...} probe PASS/FAIL`） |

**告警是「日志计数」而非「实时探测」**——它只数回退行，不判断回退原因。所以先看 `agent.log`
里那几行 `Fallback activated: A → B (provider)` 再往下查。

信号状态语义：`OK` → `ALERT`（刚触发）→ `ACTIVE`（持续中）→ `RECOVERED` → `OK`。
窗口滚过后会**自动**回落，不必手动清。

### 另一个 probe 信号（别混淆）

脚本另有 `probe_model()`：每小时发一次带随机校验令牌的真实推理请求
（`challenge = "CHECK-" + secrets.token_hex(4)`，要求模型原样回传，防「罐头 OK」）。
连续 2 次失败 → `Gemini 主模型真实推理异常`。

- **超时 17s 对 thinking 模型偏紧**：`gemini-3.8-flash-high` 实测 `reasoning_tokens=91`，
  正常 2.6~3.3s，但上游拥塞时可达 **389s**（本次在 `agent.log` 里抓到
  `API call #13 ... latency=389.0s`）。17s 阈值会把「慢」误报成「异常」。
- 该信号与「模型回退」是两个独立信号，**同一条告警里不会同时出现**，读文案区分。

---

## 二、「模型回退」告警的真实根因链（本次案例）

时间均为北京时间（UTC+8）。会话 `mvgj548yxtpvjx`：

1. **19:50** 主模型 `gemini-3.8-flash-high`（CPA `127.0.0.1:8317`）一次调用耗时 **389s**；
2. **19:51:00** 该流被中断（`stream_interrupt_abort`），会话随即被切到
   `global:gpt-5.6-terra`（provider 腾白嫖 `capy.<PRIVATE_IDENTIFIER>:2087`）；
3. **19:51:12 / 19:51:17** 两次 HTTP 503
   `{"code":11158,"msg":"model [gpt-5.6-terra] is not allowed for user type [personal_free_user]"}`；
4. Hermes 重试 2 次（`attempt 1/3`、`2/3`）全失败 → **`Fallback activated: global:gpt-5.6-terra → gpt-6-luna (反重力)`**；
5. **19:53:02** 连 **auxiliary vision** 也继承了 `gpt-5.6-terra`，`vision_analyze` 直接 503 报错；
6. **19:55:05** 同样链路再炸一次 → 30 分钟窗口凑满 2 次 → 告警。

**结论：主模型没坏，是清单里挂了账号档位不支持的模型。** 切过去必 503，每次都烧 2 次重试再回退，
还会连带打挂 auxiliary（vision/title）任务——这是「幽灵条目」的典型代价。

日志取证命令（定向、不整份打印）：

```bash
grep 'Fallback activated:' ~/.hermes/logs/agent.log | tail -20
grep -n '2026-10-20 11:5' ~/.hermes/logs/agent.log | grep -iE 'ERROR|WARNING|switch|latency='
grep 'hermes_fallback' /home/ubuntu/hermes-jobs/status/ai-model-health.log | tail -3
```

---

## 三、并发探测伪造「全灭」事故（最重要教训）

第一次审计用 `ThreadPoolExecutor(max_workers=8)` 并发打 52 个模型：

```
OK: 3 / 52      ← 49 个报 503
```

其中 `cn:deepseek-v4-flash`、`cn:glm-5.3-flash`、`cn:kimi-k3-1` 前一刻单测还是 **200 通过**，
并发后全变 503。响应形态两种：

```json
{"error":{"code":"no_healthy_account","gateway_hint":"no healthy account available in pool; check /status or retry later", ...}}
```
```html
<html><head><title>503 Service Temporarily Unavailable</title></head>
```

改 **串行 + `sleep(3.5)`** 复测 6 个关键模型 → 全部恢复正常，只有 11158 的仍然被拒。
再串行跑完 31 个 `global:*`，真实结果：

```
OK=16  DENIED=11  OTHER(临时503)=4  TOTAL=31
```

**若按并发结果一刀切删除，会误删 16 个可用模型。** 铁律见 SKILL.md Pitfalls：
并发只用于粗筛，判定永久失效必须串行复测。

---

## 四、腾白嫖（`capy.<PRIVATE_IDENTIFIER>:2087`）实测矩阵 2026-10-20

档位 `personal_free_user`。

### 永久拒绝（`code:11158`）— 已从清单删除

`global:gemini-3.8-flash`、`global:gemini-3.5-flash`、`global:gpt-5.4`、`global:gpt-5.5`、
`global:gpt-5.6-terra`、`global:gpt-5.6-luna`、`global:gpt-5.6-sol`、`global:gpt-6-luna`、
`global:gpt-6-sol`、`global:primary-model`、`global:grok-4.7`

### 可用（保留）

`global:step-5-preview` `global:glm-5.3` `global:glm-5.2` `global:kimi-k2.6` `global:kimi-k2.8-preview`
`global:hy4-preview` `global:deepseek-v4.1-flash-sg` `global:glm-5.3-flash` `global:deepseek-v4.1-flash`
`global:balanced-model` `global:kimi-k3` `global:fast-model` `global:hy4-preview-f` `global:hy3`
`global:default-model` `global:gpt-5.3-codex`
（`cn:*` 21 个全部保留，抽样 200 通过：`cn:deepseek-v4-flash` `cn:glm-5.3-flash` `cn:kimi-k3-1` `cn:step-5-preview` `cn:hy3-x` `cn:minimax-m3`）

### 临时 503（保留备用，非权限问题）

`global:deep-model`、`global:auto-chat`（`no_healthy_account`）、
`global:enhance-1.0`（`code:11134 provider temporarily unavailable`）、`global:o4-mini`

---

## 五、安全删除流程（带内容校验，防误删）

不要 `yaml.dump` 整文件重写（会丢注释与格式）。用**行号 + 内容双重校验**：

```python
targets = {508,510,511,515,519,520,526,527,530,532,537}
lines = open('config.yaml', encoding='utf-8').readlines()
expected = ['global:gemini-3.8-flash', ...]   # 与 targets 一一对应的模型名
ok = True
for ln in sorted(targets):
    content = lines[ln-1].strip()
    m = content[2:] if content.startswith('- ') else content
    if m not in expected:
        print(f'MISMATCH line {ln}: {content!r}'); ok = False
if not ok:
    raise SystemExit(1)          # 任何一行对不上就整体放弃，绝不盲删
out = [l for i,l in enumerate(lines,1) if i not in targets]
open('config.yaml','w',encoding='utf-8').writelines(out)
```

配套动作（缺一不可）：

1. **备份 + md5 双验**：
   `cp -a config.yaml /home/ubuntu/ops-backups/config-purge-<TS>/config.yaml.bak`
   然后 `md5sum config.yaml <备份>` 确认一致。
2. **确认行号归属同一 provider**：`awk 'NR<=<行> && /^  - name:/ {last=NR": "$0} END{print last}' config.yaml`
   —— 本次 11 行全落在「腾白嫖」段（481~539），下一个 provider「周三」从 540 起。跨段误删会毁别的 provider。
3. **YAML 解析校验**：`yaml.safe_load(open('config.yaml'))` 不抛异常。
4. **残留检查**：逐项确认删掉的模型名在**该 provider 段内**已消失。
   ⚠️ 同名模型可能存在于**别的 provider**（本次 `gpt-5.6-terra` 还出现在「反重力」段第 431 行，
   那是另一条链路，不能动）——`grep` 到就往上找最近的 `- name:` 确认归属。
5. **真实链路验收**：`hermes config get model.default` 正常返回、`hermes models | grep <删掉的模型>` 为 0 条。

---

## 六、审计报告口径（用户要「查一下日志分析原因」时）

先给**结论一句话**（主模型没坏 / 是清单里的死条目），再给：

1. 告警来源（脚本路径 + 判定机制 + 阈值）
2. 时间线表格（北京时间，含每次回退的 A → B 路径与错误码）
3. 根因（错误码归类 + 实测证据）
4. 当前状态（最新一次回退时间、之后有无新增、信号会自动回落）
5. 处置建议 + 是否已执行

区分「已验证事实」与「推断」；采样时间随指标一起给出，别用回复时间冒充。

---

## 七、用户说「解决它」之后：fallback 链重建实录

删完幽灵条目只是止血；**原来的兜底模型往往也已经死了**，必须一并体检。

### 7.1 反重力（`127.0.0.1:8317`）16 模型实测 2026-10-20

串行间隔 2.5s 逐个测：

```
OK        5.7s  gemini-3.1-flash-lite
OK        2.1s  claude-opus-4-6-thinking
TimeoutError    gemini-3.8-flash-high      ← 主模型，瞬时抖动，75s 重测 3.3s 通过
OK        3.9s  gemini-3-flash
OK        2.3s  gpt-oss-120b-medium
OK       14.8s  gemini-3.5-flash-lite
HTTP400         gpt-5.5
429冷却         gpt-5.6-luna / gpt-5.6-terra / gpt-5.6-sol
429冷却         gpt-6-luna / gpt-6-sol / gpt-6-astra / gpt-6.1-sol
OK        1.5s  claude-sonnet-4-6
429冷却         codex-auto-review
可用 6 / 16
```

**关键结构性发现**：9 个挂掉的全是 gpt/codex 系，错误一致为
`HTTP 429 {"code":"model_cooldown","last_upstream_error":"usage_limit_reached: The usage limit has been reached","message":"All credentials for model g... are cooling down via provider codex (las..."}`
—— 它们**共用同一个 codex 账号池**，配额耗尽时整组同时冷却；同网关的 `gemini-*`/`claude-*`/`gpt-oss` 走别的上游，全部存活。

→ 原配置 `fallback_providers: [反重力 / gpt-6-luna]` 是**无效兜底**：主模型 gemini 挂掉时，兜底的 gpt-6-luna 正在同池冷却。
→ 重建为**跨上游通道两级链**：

```yaml
fallback_providers:
  - provider: 反重力          # 同网关、不同上游（claude 通道），快
    model: claude-sonnet-4-6
    base_url: http://127.0.0.1:8317/v1
    key_env: ANTIGRAVITY_API_KEY
    api_mode: chat_completions
  - provider: 腾白嫖          # 跨站冗余，网关整体挂掉时接管
    model: cn:kimi-k3-1
    base_url: https://capy.<PRIVATE_IDENTIFIER>:2087/v1
    key_env: WORKBUDDY_API_KEY
    api_mode: chat_completions
```

实测：`claude-sonnet-4-6` → OK 1.5s；`cn:kimi-k3-1` → OK 3.8s。
（`cn:kimi-k3-1` 用 `max_tokens=10` 时 `content` 为空、只有 `reasoning_content`，是思考吃满 token，**不是故障**；
给到 200 即正常返回 `content: 'OK'` + `reasoning_content: '...'` + `finish_reason: stop`。）

### 7.2 `fallback_providers` 被写成字符串后的修复

`hermes config set fallback_providers '<JSON>'` 会落成
`fallback_providers: '[{"provider":...}]'`（整行带单引号 = 字符串）。症状与正解见 SKILL.md
「Fallback 链编辑的两个 CLI 陷阱」第 2 条：**行级块替换**，不要 `yaml.dump` 整文件重写。

修复后验收三连：

```bash
hermes config get fallback_providers          # 输出真正的 YAML 列表
python3 -c "import yaml;print(len(yaml.safe_load(open('config.yaml'))['fallback_providers']))"
# 再按 key_env 从 .env 取 key，逐个发最小 chat 请求确认 200
```

---

## 八、探测污染监控：`cpa_inference` 的副作用（本次实际误报）

`cpa_inference` 是这套脚本里**唯一 `fail_after=1`** 的信号，机制：

```python
# ai-model-healthcheck.py:95
def cpa_events(since_epoch):
    # Only POST inference failures. Ignore unrelated Hermes discovery probes (404).
    rc, output = run(["journalctl", "-u", "cliproxyapi.service",
                      "--since", local_since, "--no-pager", "-o", "cat"], 8)
    for line in output.splitlines():
        if 'POST' not in line or '/v1/chat/completions' not in line: continue
        if re.search(r"\b(?:400|401|403|404|408|409|422|429|5\d\d)\s*\|", line):
            failures += 1
    return failures
# 调用处：counts >= 3 → ALERT，fail_after=1（一次检查即告警）
```

**它数的是 CPA 访问日志，不区分调用方** —— Agent 自己的探测请求与真实业务请求同等计入。

本次事故时间线（UTC）：

```
12:31:36~12:33:16  第一次并发探测 52 模型（max_workers=8）→ 大量 429/503
12:42:32~12:42:56  串行探测反重力 16 模型 → 9 个 429
                   ↓
12:33  cpa=OK      fallback=ACTIVE
12:34  cpa=ALERT   fallback=RECOVERED   ← 探测把 cpa 打成告警，用户收到误报
12:44  cpa=ACTIVE  fallback=OK
```

30 分钟窗口内累计 **16 次**失败，全部落在自己的测试时段。

**恢复算术**：最后失败 12:42 → 滚出窗口 13:12 → 再需连续 2 次检查通过（约 10 分钟一轮）→ **13:30 前后自动恢复**。
无需干预，**更不要手改 `ai-model-health.state.json`**（那是篡改监控数据，会让后续判断失去可信度）。

**给用户的披露口径**（本次实际采用，用户未质疑）：

> ⚠️ 我造成的副作用：探测时发出的请求被 CPA 日志记为 16 次 429/400，`cpa_inference` 用 `fail_after=1` 立即告警，
> 所以你可能又收到一条 CPA 告警。**这是测试导致的误报，CPA 本身没故障** —— 主模型实测 3.3s 正常、
> 业务调用 Deepseek 3.4~14.2s 全成功。失败记录 13:12 滚出窗口，预计 13:30 前自动恢复，不用手动干预。

### 探测前的检查清单

1. 先看 `ai-model-health.state.json` 里 `cpa_inference.active` 当前是否为 true —— 若已告警，再探测只是延续，不会新增误报；
2. 探测规模控制在必要范围（本次 52 个全量并发是过度行为，先并发粗筛出「疑似失败」再用串行精确判定即可）；
3. 探测完主动查一次 `grep 'cpa_inference' ai-model-health.log | tail -2`，把状态变化如实写进汇报。
