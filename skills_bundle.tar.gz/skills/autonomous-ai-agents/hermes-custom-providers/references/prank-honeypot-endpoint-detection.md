# 恶搞/钓鱼端点（Prank/Honeypot Endpoints）识别案例与排查特征

## 典型案例背景
用户分享所谓自用反代/组内到期 API（如 `ai.saltyfish.live/v1`），宣称支持尚未发布的模型代号（如 `claude-fable-5-1`, `claude-opus-5-5`, `gpt-6-astra`）。

## 核心识别特征

1. **宣称未来/不存在的模型名称**：
   - 虚构版本号如 Claude 5.x / 5.5、GPT-6 系、Gemini 超前预览版。
   - `GET /v1/models` 虽然返回 HTTP 200，但返回的列表清一色为超前或编造模型。

2. **请求内容劫持与固定模板回复（Prank Payload）**：
   - 发送任何 Prompt（哪怕是简单文本校验或身份询问），返回的内容均为预置的固定文本（如 ASCII 字符画、字符图形）或恶搞文本。
   - `reasoning_content` 中包含非关联的固定 mock 思维链（例如：`'Okay, the user wants me to generate a milk frog'`）。
   - 响应与请求内容完全不相关，不具有真实的文本生成与指令遵循能力。

3. **上游服务伪装与不稳定**：
   - 部分路由直接抛 Cloudflare Worker 错误（如 `HTTP 500 error code: 1101`）。
   - 站点首页无实际业务或直接 500。

## 排查准则
- 探测中转站与反代 API 时，**绝不能仅看 `GET /v1/models` 返回 200 即判定可用**。
- 必须通过 `POST /v1/chat/completions` 发送带有明确校验语义的 Prompt（如“直接回复：能用”或严格指定输出格式），并校验返回内容是否忠实遵循指令。
- 若发现模型返回固定无关字符画或思维链中含有 mock/恶搞标记，直接判定为恶意/恶搞端点，禁止将其写入 `custom_providers` 或 fallback 链。
