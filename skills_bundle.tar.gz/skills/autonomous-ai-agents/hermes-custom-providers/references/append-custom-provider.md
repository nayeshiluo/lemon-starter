# 追加 custom provider 的 Python 脚本

CLI 的 `hermes config set custom_providers.N.*` 不能增长列表（`_set_nested` 对不存在的索引抛 `IndexError: list index out of range`），所以追加新 provider 必须直接用 Python 改 YAML。

## 脚本（保存为 /tmp/add_provider.py 运行）

```python
#!/usr/bin/env python3
"""追加自定义 provider 到 config.yaml 的 custom_providers，保留现有条目。"""
import sys
sys.path.insert(0, "/home/ubuntu/.hermes/hermes-agent")  # hermes-agent 根目录

import yaml

path = "/home/ubuntu/.hermes/config.yaml"
with open(path) as f:
    cfg = yaml.safe_load(f)          # 直接读原文件，避开 read_file 的密钥脱敏

providers = cfg.get("custom_providers", [])
names = [p.get("name") for p in providers]
print("现有 providers:", names)

if "Frp3.ccszxc.xin" in names:       # 幂等：同名已存在则跳过
    print("已存在，跳过")
else:
    providers.append({
        "name": "Frp3.ccszxc.xin",
        "base_url": "http://frp3.ccszxc.xin:61295/v1",
        "key_env": "FRP3_API_KEY",    # 引用 .env 里的变量，密钥不落 config.yaml
        "model": "deepseek-v4-flash", # 默认模型
        "api_mode": "chat_completions",
        "models": [                    # 只放实测通过的模型
            "deepseek-v4-flash",
            "deepseek-v4-pro",
            "gemini-3-flash-preview",
            "gemini-3.1-pro-preview",
        ],
    })
    cfg["custom_providers"] = providers
    # path 在前、data 在后；from utils import atomic_yaml_write（根目录 utils.py）
    from utils import atomic_yaml_write
    atomic_yaml_write(path, cfg)
    print("已追加新 provider")

# 可选验证
with open(path) as f:
    cfg2 = yaml.safe_load(f)
print("现在 providers:", [p.get("name") for p in cfg2.get("custom_providers", [])])
```

## 运行方式（必须用 hermes 的 venv）

```bash
# 用 hermes 自己 venv 的 python 跑，沙箱/系统 python 缺 hermes 依赖
/home/ubuntu/.hermes/hermes-agent/venv/bin/python3 /tmp/add_provider.py
```

## 关键坑

| 坑 | 报错 | 修正 |
|---|---|---|
| `from hermes_cli.utils import atomic_yaml_write` | `ModuleNotFoundError: No module named 'hermes_cli.utils'` | 改为 `from utils import atomic_yaml_write`（根目录） |
| `atomic_yaml_write(cfg, path)` 参数反了 | `TypeError: expected str, bytes or os.PathLike object, not dict` | path 在前、data 在后：`atomic_yaml_write(path, cfg)` |
| 用 execute_code 沙箱跑 | `No module named 'hermes_cli'` | 用 `~/.hermes/hermes-agent/venv/bin/python3` 跑 |
| 用 read_file 读回再写 | api_key 变成 `«redacted:sk-…»` 占位符 | 全程用 `yaml.safe_load` 直接读原文件 |

改配置前先备份：`cp ~/.hermes/config.yaml ~/.hermes/config.yaml.bak-$(date +%Y%m%d%H%M%S)`。
