# LFree (New API Bot 聚合专线) 接入与实测记录

## 1. 架构与端点特征

- **系统架构**: New API 网关（应用 / Bot 聚合专线）
- **控制台 / 前端地址**: `https://ai.lfree.org/bot/<YOUR_BOT_ID>
- **⚠️ 核心避坑（Base URL 路由路径）**:
  - 用户给出的链接如果带 `/bot/<id>`，直接访问 `https://ai.lfree.org/v1/models` 会报错：`401 Invalid token (new_api_error)`。
  - 直接 GET `https://ai.lfree.org/bot/<YOUR_BOT_ID> 会返回 `404 page not found`。
  - **正确且唯一的 OpenAI 兼容 Base URL 必须包含完整子路径**：`https://ai.lfree.org/bot/<YOUR_BOT_ID>/v1`。
- **认证方式**: `Authorization: Bearer <YOUR_LFREE_API_KEY>` (配置于 `~/.hermes/.env` 的 `LFREE_API_KEY`)。

## 2. 8 个可用模型实测清单与内核解析

服务端列表宣告 9 个模型，实测 8 个可用，1 个不支持：

| 模型名 | 实测延迟 | 真实内核 / 特性 | Tool Calls (Function Calling) | 适用场景 |
| :--- | :---: | :--- | :---: | :--- |
| `claude-opus-5` | **1.77s** | **DeepSeek-R1**（带思考链，极速） | ✅ 支持 | 高频日常问答、代码辅助、群聊快速响应（首选） |
| `big-pickle` | 9.59s | DeepSeek-R1（自我介绍为 DeepSeek） | ✅ 支持 | 长逻辑推理任务 |
| `nv/kimi-k3` | 5.13s | Kimi（月之暗面，思考逻辑严谨） | ✅ 支持 | 复杂创作、知识整理、分析 |
| `mimo-v2.5` | 7.76s | 小米 MiMo（通用对话） | ✅ 支持 | 常规非推理任务 |
| `nemotron-3.5-lightning` | 3.17s | Nvidia Nemotron（带英文思考过程） | ✅ 支持 | 英文/技术问答 |
| `muse-spark` | 2.47s | Meta Muse Spark（带思考链） | ✅ 支持 | 创意写作、中英问答 |
| `muse-spark-1.2-contributor` | 3.24s | Meta Muse Spark | ✅ 支持 | 补充候选 |
| `muse-spark-1.3-contributor` | 8.42s | Meta Muse Spark（长思考链，max_tokens需>500） | ✅ 支持 | 深度发散讨论 |
| `laguna-s-2.1` | - | ❌ 401: `Model laguna-s-2.1 is not supported` | ❌ 不支持 | 禁用/不注册 |

## 3. 群聊与生产应用落地建议

- **群霸项目 (`lemon-group-bot`) 最佳编排**：
  - **主用节点**: `LFree·Claude` (`claude-opus-5`)，兼顾极速响应与结构化输出。
  - **第一兜底**: `反重力·Gemini3.8` (`gemini-3.8-flash-high`)，遇 429 或中转故障时零延迟无缝接管。
  - **第二兜底**: `反重力·Claude` (`claude-sonnet-4-6`)。
  - **第三兜底**: `日日新·DeepSeek` (`deepseek-v4-flash`)。
- **请求头规范**:
  - 自建请求（如 aiohttp 或 requests）必须携带标准浏览器 `User-Agent`，防止 Cloudflare WAF 对裸客户端 UA 阻断。
