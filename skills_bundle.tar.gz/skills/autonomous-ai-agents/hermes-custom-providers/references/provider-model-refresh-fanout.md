# 存量 provider 模型清单刷新（用户说「查一下上游模型有没有变化 / 需不需要更新」）

2026-10-30 实录。场景：用户给过一个站，几周后问「上游模型变了吗、要不要更新」，
或者某个站悄悄死了导致一堆 bot 同时报错。**这是「刷新」而不是「新增」**，两个坑完全不同。

---

## 一、审计流程（四步，每步都要留证据）

```python
# ① 遍历 config.yaml 所有 custom_providers，拉上游 /models，与配置 models 求差
# ② 差集分两侧：配置有上游无 = 疑似失效；上游有配置无 = 疑似新增
# ③ 对「疑似失效」逐个发真实 chat 请求 —— 绝不能只看差集就删（见 §二）
# ④ 对「疑似新增」逐个实测，通过的才加
```

脚本要点：

- key 解析要兼容三种写法：`key_env` → `.env` 变量；`api_key` 为 `${VAR}`；`api_key` 直接是值或变量名。
- `extra_headers` 必须带上（有的站靠 UA 过 Cloudflare，不带全站 403）。
- 并发 5~6 路即可；**判定永久失效前必须串行复测**（并发会把网关打成 503，见 `relay-model-inventory-audit.md` §三）。
- 输出只打「站名 / 上游数 / 配置数 / 失效数 / 新增数」，**不要打印 base_url 与密钥**。

---

## 二、⚠️ 最大的坑：`/models` 会漏报可用的模型

SKILL.md 已写过「列表里的模型 ≠ 都可用」（列表高估）。**反方向同样成立，而且更危险：**

> 2026-10-30 实测腾白嫖：配置 41 个模型，上游 `/models` 只返回 52 个且**不含**其中 7 个。
> 逐个实测后发现 **5 个其实完全可用**（`cn:glm-5v-turbo`、`cn:kimi-k2.6`、`cn:kimi-k2.7`、
> `global:kimi-k2.8-preview`，以及重试后恢复的 `cn:minimax-m3`），真正失效的只有 2 个。

原因：中转站 `/models` 常常只是「主渠道目录」，聚合渠道、灰度模型、按账号档位下发的模型不在里面。

**铁律：`/models` 的差集只能产生「候选」，绝不能直接驱动删除。**
删除条件必须是「真实 chat 请求稳定复现 403/404/11158」（串行复测两次以上）。
差集里消失但实测 200 的模型，**一律保留**。

---

## 三、`/models` 的 ID 格式可能和配置不同源

2026-10-30 实测 `Gemini官方`：上游返回 `models/gemini-2.5-flash`、`models/antigravity-preview-05-2026`
（Google 原生格式），配置里写的是 `gemini-3.8-flash`。朴素差集于是报「配置 2 个全失效 + 上游新增 60 个」，
**100% 是格式噪音**。

判据：上游 ID 里出现 `models/` 前缀、或返回条数远大于该站实际可调模型数 → 先归一化再比：

```python
norm = {m.split('/', 1)[1] if m.startswith('models/') else m for m in upstream}
```

归一化后仍对不上的，再用实测定论。

---

## 四、一个站死了会连带一串消费者 —— 刷新必须全量扇出

用户说「其他 bot 的模型也一并处理」时，别只改 Hermes `config.yaml`。**同一批模型被多个系统各自抄了一份**，
每个都是一处要改的落点：

| 消费者 | 配置位置 | 特征 |
|---|---|---|
| Hermes 自身 | `~/.hermes/config.yaml` → `custom_providers[].models` / `.model` | `/model` 菜单与默认模型 |
| dsh web profile | `$DSH_HOME/profiles/web/cordis.patch.yml` | `llm-pi-ai.providers` + `agent-default-model` |
| dsh headless profile | `$DSH_HOME/profiles/headless/cordis.patch.yml` | **独立一份，改 web 不影响它** |
| 群霸类多 Bot | `data/ai_endpoints.json`（端点+默认模型）、`data/ai_bot_<id>.json`（`order` / `disabled_nodes`） | 模型清单在 `order` 里按顺序 fallback |
| AstrBot 类 | `data/cmd_config.json` → `provider_sources` + `provider[]` | `provider` 是 list，真端点在 `provider_sources` |
| userbot / 自建 Bot | 各自的 `model_selection.json`、代码里的 `DEFAULT_*_MODEL` 常量 | 有的模块是死代码，先 grep 调用点 |
| 角色化 Bot（如 Smart Group Bot） | `data/bot.db` → `runtime_config.payload` 的 JSON | main / vision / decision / moderation / compress / embed **各自一套 provider+model+fallbacks**；密钥在 `runtime_config_secrets` 独立表；走带 revision 校验的热更新 API，别直接改 SQL |
| 破甲/IM 前端（如 `@pojai120_bot`） | 项目里的 `DEFAULT_SITE` / `DEFAULT_MODEL` 常量 | 每次请求按 Hermes `custom_providers` 现读生成 dsh overlay；改常量即可，但 overlay 必须透传站点 `extra_headers` |

### 4.1 「人型号」不等于「有模型调用」——逐账号核实，别按名字推断

2026-11-06 实测：用户说「两个人型账号的模型都要换」，实际盘点后

- 主号（`@zmz1008`，naye `lemon-userbot`）：`userbot.py` 里 `,sum` / `,ai` / 生图 prompt 扩写共用
  `call_llm_api`，`model_selection.json` + 代码默认常量 + 硬编码 fallback 三处都要改。
- 第二个人型（Charles，vps-la）：只跑 `lemon-channel-harvest` → `/root/channel_music_harvester.py`，
  **全链路零 LLM 调用**（grep `chat/completions` / `8317` / `openai` 命中 0）。vps-la 上的
  `/opt/lemon-userbot` 是一份完整部署副本，但 `systemctl show lemon-userbot` 为 `not-found`、
  无进程 —— **残留副本，不是运行入口**。

结论：**先按 systemd 的 `WorkingDirectory` / `ExecStart` / `MainPID` 建立「服务 → 源码」映射，
再 grep 该源码有没有 LLM 调用点**；只看目录名或「人型号」这个称呼就断言「它也有模型要换」，
会凭空造出一处不存在的改动，也会漏掉真正在跑的那一处。

## 4.2 实操顺序

1. **全量只读扫一遍**，列出每个消费者「当前指向哪个模型」，再判断哪些真的受影响。
   不要一上来就改——本会话 AstrBot 的 4 个模型、userbot 的主链路、运维 Bot 全部实测可用，一处没动。
2. 只改**实测失效**的那几处，每处先 `.bak-<用途>-<时间戳>` 备份。
3. 群霸这类 `order` 列表型配置：把死端点从 `order` **移出**并追加到 `disabled_nodes`，
   不要直接删条目（删了 `ai_endpoints.json` 里还有、`order` 里没了，状态不一致）。
4. **每改一处就重启对应服务并看 journal 首行**，不要攒到最后一起重启——出问题无法定位是谁改坏的。
5. 收尾给一张「改了什么 / 没动什么 / 还剩什么没解决」三栏表。用户最关心的是「哪些我没动」，
   不是逐条复述改动。

---

## 五、默认模型指向死站时的处置

一个 provider 全部模型 403（`token_acl_error`）时，**凡是默认模型指向它的消费者都会 100% 失败**，
表现为「Bot 能连上但每次都报错」。本会话 NewFouAPI 6 个模型全 403，而 dsh 的
`agent-default-model` 正是 `newfou / deepseek-v4-flash` —— 这就是「dsh 开箱即跑不通」的真因。

处置：

1. 先把该 provider 的 `models` 换成实测可用的那批，`model`（默认）也一并改。
2. 再逐 profile / 逐 bot 改默认指向。
3. 验收必须是**真实调用返回预期文本**，不是 `systemctl is-active`。
   `hermes chat --provider <名> -m <模型> -q '只回复 XXX'` 要看到 XXX 才算过。

---

## 六、汇报口径

按「硬故障 / 可清 / 无问题 / 可选扩充」四类给结论，别列一长串模型名让用户自己看：

- **必须修**：整站 403、默认指向死站 —— 说清「谁的默认指向它，所以哪个 Bot 会挂」
- **可以清**：稳定 503 的个别模型 —— 附重试次数，区分「列表没列全但能用」
- **没问题**：配置与上游一致的站，明确说「没动」
- **可选**：上游新增里值得加的（报数量，别全列）

并注明「模型标签只是站方命名，不证明上游真实身份」。

---

## 七、换梯队（「A 厂家做主力、B 做备用」）是一增一减，不是只改默认

用户这句话的含义比 `model.default` 大得多。完整动作：

1. `model.default` + `model.provider` 指向新主力（custom provider 用 `custom:<名>`）。
2. **`fallback_providers` 里要删掉被淘汰厂商的条目**，只留用户指定的备用。
   2026-11-06 实测：备用链原本是 `周三 → 反重力(claude-sonnet-4-6)`，反重力属 Gemini 系反代，
   用户要求淘汰该厂商，却只说了「周三做备用」——**只加不减的话，被淘汰的厂商仍会以备用身份
   被自动调用**，用户以为已经不用了，实际每次主力抖动都在偷偷打它。
3. 各消费者默认模型同步改（见 §四 表：dsh 两个 profile、群霸 `order`、AOT/角色化 Bot、
   IM 前端常量）。少改一处，那处就是下一个「为什么还是旧模型」。
4. **备用必须跨上游账号池**：同厂同池的两个模型一起 429，等于没有备用。用户点名的备用厂商
   与主力不同厂，才算真容灾。
5. 验收双证：`hermes fallback list` 结构正确 + 主力与备用各发一次带唯一校验词的请求都返回。
   只看配置落盘不算。

汇报时说清「从备用链里摘掉了哪一条、为什么」，别只报「备用已设为 B」。
