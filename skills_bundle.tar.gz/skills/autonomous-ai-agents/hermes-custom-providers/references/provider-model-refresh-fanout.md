# 存量 provider 模型清单刷新（用户说「查一下上游模型有没有变化 / 需不需要更新」）

2026-10-30 实录。场景：用户给过一个站，几周后问「上游模型变了吗、要不要更新」，
或者某个站悄悄死了导致一堆 bot 同时报错。**这是「刷新」而不是「新增」**，两个坑完全不同。

---

## 一、审计流程（四步，每步都要留证据）

```python
# ① 遍历 config.yaml 所有 custom_providers，拉上游 /models，与配置 models 求差
# ② 差集分两侧：配置有上游无 = 疑似失效；上游有配置无 = 疑似新增
# ③ 对「疑似失效」逐个发真实 chat 请求 —— 绝不能只看差集就删（见 §二）
# ④ 对「疑似新增」逐个实测，通过的才加
```

脚本要点：

- key 解析要兼容三种写法：`key_env` → `.env` 变量；`api_key` 为 `${VAR}`；`api_key` 直接是值或变量名。
- `extra_headers` 必须带上（有的站靠 UA 过 Cloudflare，不带全站 403）。
- 并发 5~6 路即可；**判定永久失效前必须串行复测**（并发会把网关打成 503，见 `relay-model-inventory-audit.md` §三）。
- 输出只打「站名 / 上游数 / 配置数 / 失效数 / 新增数」，**不要打印 base_url 与密钥**。

---

## 二、⚠️ 最大的坑：`/models` 会漏报可用的模型

SKILL.md 已写过「列表里的模型 ≠ 都可用」（列表高估）。**反方向同样成立，而且更危险：**

> 2026-10-30 实测腾白嫖：配置 41 个模型，上游 `/models` 只返回 52 个且**不含**其中 7 个。
> 逐个实测后发现 **5 个其实完全可用**（`cn:glm-5v-turbo`、`cn:kimi-k2.6`、`cn:kimi-k2.7`、
> `global:kimi-k2.8-preview`，以及重试后恢复的 `cn:minimax-m3`），真正失效的只有 2 个。

原因：中转站 `/models` 常常只是「主渠道目录」，聚合渠道、灰度模型、按账号档位下发的模型不在里面。

**铁律：`/models` 的差集只能产生「候选」，绝不能直接驱动删除。**
删除条件必须是「真实 chat 请求稳定复现 403/404/11158」（串行复测两次以上）。
差集里消失但实测 200 的模型，**一律保留**。

---

## 三、`/models` 的 ID 格式可能和配置不同源

2026-10-30 实测 `Gemini官方`：上游返回 `models/gemini-2.5-flash`、`models/antigravity-preview-05-2026`
（Google 原生格式），配置里写的是 `gemini-3.8-flash`。朴素差集于是报「配置 2 个全失效 + 上游新增 60 个」，
**100% 是格式噪音**。

判据：上游 ID 里出现 `models/` 前缀、或返回条数远大于该站实际可调模型数 → 先归一化再比：

```python
norm = {m.split('/', 1)[1] if m.startswith('models/') else m for m in upstream}
```

归一化后仍对不上的，再用实测定论。

---

## 四、一个站死了会连带一串消费者 —— 刷新必须全量扇出

用户说「其他 bot 的模型也一并处理」时，别只改 Hermes `config.yaml`。**同一批模型被多个系统各自抄了一份**，
每个都是一处要改的落点：

| 消费者 | 配置位置 | 特征 |
|---|---|---|
| Hermes 自身 | `~/.hermes/config.yaml` → `custom_providers[].models` / `.model` | `/model` 菜单与默认模型 |
| dsh web profile | `$DSH_HOME/profiles/web/cordis.patch.yml` | `llm-pi-ai.providers` + `agent-default-model` |
| dsh headless profile | `$DSH_HOME/profiles/headless/cordis.patch.yml` | **独立一份，改 web 不影响它** |
| 群霸类多 Bot | `data/ai_endpoints.json`（端点+默认模型）、`data/ai_bot_<id>.json`（`order` / `disabled_nodes`） | 模型清单在 `order` 里按顺序 fallback |
| AstrBot 类 | `data/cmd_config.json` → `provider_sources` + `provider[]` | `provider` 是 list，真端点在 `provider_sources` |
| userbot / 自建 Bot | 各自的 `model_selection.json`、代码里的 `DEFAULT_*_MODEL` 常量 | 有的模块是死代码，先 grep 调用点 |
| 角色化 Bot（如 Smart Group Bot） | `data/bot.db` → `runtime_config.payload` 的 JSON | main / vision / decision / moderation / compress / embed **各自一套 provider+model+fallbacks**；密钥在 `runtime_config_secrets` 独立表；走带 revision 校验的热更新 API，别直接改 SQL |
| 破甲/IM 前端（如 `@pojai120_bot`） | 项目里的 `DEFAULT_SITE` / `DEFAULT_MODEL` 常量 | 每次请求按 Hermes `custom_providers` 现读生成 dsh overlay；改常量即可，但 overlay 必须透传站点 `extra_headers` |

### 4.1 「人型号」不等于「有模型调用」——逐账号核实，别按名字推断

2026-11-06 实测：用户说「两个人型账号的模型都要换」，实际盘点后

- 主号（`@zmz1008`，naye `lemon-userbot`）：`userbot.py` 里 `,sum` / `,ai` / 生图 prompt 扩写共用
  `call_llm_api`，`model_selection.json` + 代码默认常量 + 硬编码 fallback 三处都要改。
- 第二个人型（Charles，vps-la）：只跑 `lemon-channel-harvest` → `/root/channel_music_harvester.py`，
  **全链路零 LLM 调用**（grep `chat/completions` / `8317` / `openai` 命中 0）。vps-la 上的
  `/opt/lemon-userbot` 是一份完整部署副本，但 `systemctl show lemon-userbot` 为 `not-found`、
  无进程 —— **残留副本，不是运行入口**。

结论：**先按 systemd 的 `WorkingDirectory` / `ExecStart` / `MainPID` 建立「服务 → 源码」映射，
再 grep 该源码有没有 LLM 调用点**；只看目录名或「人型号」这个称呼就断言「它也有模型要换」，
会凭空造出一处不存在的改动，也会漏掉真正在跑的那一处。

## 4.2 实操顺序

1. **全量只读扫一遍**，列出每个消费者「当前指向哪个模型」，再判断哪些真的受影响。
   不要一上来就改——本会话 AstrBot 的 4 个模型、userbot 的主链路、运维 Bot 全部实测可用，一处没动。
2. 只改**实测失效**的那几处，每处先 `.bak-<用途>-<时间戳>` 备份。
3. 群霸这类 `order` 列表型配置：把死端点从 `order` **移出**并追加到 `disabled_nodes`，
   不要直接删条目（删了 `ai_endpoints.json` 里还有、`order` 里没了，状态不一致）。
4. **每改一处就重启对应服务并看 journal 首行**，不要攒到最后一起重启——出问题无法定位是谁改坏的。
5. 收尾给一张「改了什么 / 没动什么 / 还剩什么没解决」三栏表。用户最关心的是「哪些我没动」，
   不是逐条复述改动。

---

## 五、默认模型指向死站时的处置

一个 provider 全部模型 403（`token_acl_error`）时，**凡是默认模型指向它的消费者都会 100% 失败**，
表现为「Bot 能连上但每次都报错」。本会话 NewFouAPI 6 个模型全 403，而 dsh 的
`agent-default-model` 正是 `newfou / deepseek-v4-flash` —— 这就是「dsh 开箱即跑不通」的真因。

处置：

1. 先把该 provider 的 `models` 换成实测可用的那批，`model`（默认）也一并改。
2. 再逐 profile / 逐 bot 改默认指向。
3. 验收必须是**真实调用返回预期文本**，不是 `systemctl is-active`。
   `hermes chat --provider <名> -m <模型> -q '只回复 XXX'` 要看到 XXX 才算过。

---

## 六、汇报口径

按「硬故障 / 可清 / 无问题 / 可选扩充」四类给结论，别列一长串模型名让用户自己看：

- **必须修**：整站 403、默认指向死站 —— 说清「谁的默认指向它，所以哪个 Bot 会挂」
- **可以清**：稳定 503 的个别模型 —— 附重试次数，区分「列表没列全但能用」
- **没问题**：配置与上游一致的站，明确说「没动」
- **可选**：上游新增里值得加的（报数量，别全列）

并注明「模型标签只是站方命名，不证明上游真实身份」。

---

## 七、换梯队（「A 厂家做主力、B 做备用」）是一增一减，不是只改默认

用户这句话的含义比 `model.default` 大得多。完整动作：

1. `model.default` + `model.provider` 指向新主力（custom provider 用 `custom:<名>`）。
2. **`fallback_providers` 里要删掉被淘汰厂商的条目**，只留用户指定的备用。
   2026-11-06 实测：备用链原本是 `周三 → 反重力(claude-sonnet-4-6)`，反重力属 Gemini 系反代，
   用户要求淘汰该厂商，却只说了「周三做备用」——**只加不减的话，被淘汰的厂商仍会以备用身份
   被自动调用**，用户以为已经不用了，实际每次主力抖动都在偷偷打它。
3. 各消费者默认模型同步改（见 §四 表：dsh 两个 profile、群霸 `order`、AOT/角色化 Bot、
   IM 前端常量）。少改一处，那处就是下一个「为什么还是旧模型」。
4. **备用必须跨上游账号池**：同厂同池的两个模型一起 429，等于没有备用。用户点名的备用厂商
   与主力不同厂，才算真容灾。
5. 验收双证：`hermes fallback list` 结构正确 + 主力与备用各发一次带唯一校验词的请求都返回。
   只看配置落盘不算。

汇报时说清「从备用链里摘掉了哪一条、为什么」，别只报「备用已设为 B」。

---

## 八、整家供应商清退（retirement）：与「刷新模型」不是同一件事

2026-11-16 实录：Owner 说「这家的密钥又要换掉了，你准备处理一下」，实际意图是**半个月内把这家厂商整个删掉**。
§四 的扇出表对「换模型」够用，**对「整家清退」会漏三处落点**，而且清退有独有的两个收尾动作。

### 8.1 比 §四 多出来的三个落点

| 落点 | 位置 | 为什么刷新时想不到 |
|---|---|---|
| magpie 等本机网关**自己**的 provider 表 | `~/.config/magpie/providers.json` | Hermes 只是它的一个客户端。网关里留着这家 = 面板还能选、`auto/*` 组还会路由过去 |
| 编码 CLI 的 provider 配置 | `~/.config/opencode/opencode.json`（`provider{}` + `model`） | 它不是 Hermes provider，是独立直连，`grep custom_providers` 永远看不到 |
| Hermes `custom_providers` 里的**整块**（不是单个模型） | `~/.hermes/config.yaml` | 换模型只改 `models[]`；清退要把 95 个模型的整块删掉 |

清退前先做一次**全机残留扫描**，一次拿全再动手，别边改边找：

```bash
grep -rl "api.<vendor-domain>" \
  ~/.hermes/config.yaml ~/.hermes/.env ~/.config/opencode/ ~/.config/magpie/ \
  <各 bot 的 data/> ~/.dsh/ 2>/dev/null
```

### 8.2 ⚠️ `config.yaml` 的列表字段绝不能交给 `hermes config set`

```bash
hermes config set fallback_providers '[{...}]'   # 会把 JSON 数组写成**带引号的字符串标量**
# 结果：fallback_providers 变成 str，len=664，Hermes 读不到备用链
```

`hermes config set` 只适合 `model.default` / `model.provider` 这类标量。**列表一律文本手术**：

1. 先做全量备份（`config.yaml` 28973 字节 → 记行数 + 顶层键数当基线）
2. 用脚本按行锚点替换/删除，写完立刻复核三件事：
   `yaml.safe_load` 能过 / 顶层键数不变 / 除目标字段外 model+fallback+custom_providers 逐项相等
3. 修坏了先回滚备份文件，**不要在坏文件上继续叠加修改** —— 本次第一版修复脚本把 950 行删成 23 行，
   全靠备份才救回来

删 `custom_providers` 里单个 provider 块的行锚点写法（不依赖缩进宽度，兼容有/无缩进的序列）：

```python
start = next(i for i,l in enumerate(lines) if l.rstrip() == '  - name: <provider>')
end = next((j for j in range(start+1, len(lines))
            if lines[j].startswith('  - name:') or (lines[j] and not lines[j].startswith((' ','\t')))),
           len(lines))
open(p,'w').write('\n'.join(lines[:start] + lines[end:]))
```

删完必须比对：顶层键数 32 未变、`custom_providers` 由 11→10、其余 10 个 provider 名逐个在、
`model` 与 `fallback_providers` 三项完全未变。**只看「文件还能解析」不够** —— 少删一段或
多删一段都能解析成功。

### 8.3 各落点的具体动作与验收

- **Hermes**：`model.default` / `model.provider` 指向新主力 → 重写 `fallback_providers` 三段
  → 删 `custom_providers` 整块 → `hermes fallback list` 结构对 + `hermes -z "只回复两个字：通过" -t ""` 真出字。
- **magpie 网关**：`magpie provider rm <id>`（先 `cp providers.json` 备份）。
  验收看两件：`/v1/models` 里 `<id>/*` 前缀清零、其余 provider 的模型仍 200。
  **注意 `auto/*` 组会随之下线对应条目**（`auto/gpt-6-sol` 消失是正常的，代表它原来只由这家提供）。
- **opencode**：删掉直连 provider，改指本机网关（`baseURL: http://127.0.0.1:3425/v1`）。
  key 用 **`{file:<同目录文件名>}`** 而不是 `{env:...}`：宿主 shell 里的 provider key 往往是
  Hermes 进程继承下来的，用户自己 SSH 登录的 shell 未必有，`{env:}` 会静默拿到空值。
  key 文件 `chmod 600` 只放一行值。验收用非交互模式真跑一次：
  `opencode run "只输出两个字：通过"`，输出首行会打印 `build · <provider>/<model>`，看它是不是新模型。
- **角色化 Bot**（smart-group-bot 这类 DB 驱动的）：见 `smart-group-bot-ops` 的
  「复验模型角色必须走 runtime_config」——**读 `config.toml` 会拿到废弃 provider 并误报 401**。

### 8.4 选替代模型的现实约束

主线候选常全线失效，别按模型名推断可用性，一次实测一张表：

| 现象 | 真因 |
|---|---|
| `400 model [...] is not allowed for user type [personal_free]` | 账号档位不够，不是配置错 |
| `503 auth_unavailable: no auth available (providers=codex)` | CLIProxyAPI 那边没这个账号的授权 |
| `400 The 'X' model is not supported when using Codex with a ChatGPT account` | 模型与账号类型不匹配 |
| `403 The site owner has blocked access based on your browser's signature` | 站点 UA 封禁（这家原 provider 自己也这样） |
| `403 ads_required` | 免费池要求看广告，不适合当默认 |

本次编码模型的可用解是 `codex/gpt-5.6-terra` / `codex/gpt-5.6-luna` / `workbuddy2api/global:glm-5.3`
（均 200，1.5–2.0s）——**gpt-6 系全部不可用**，这就是为什么不能拿「名字更新」当选型依据。

### 8.5 两个收尾动作（刷新流程里没有）

1. **全机残留扫描必须区分「活跃配置」与「历史备份」**：收尾时只剩
   `ai_endpoints.json.bak-<时间戳>` 命中才叫干净，`.bak` 命中不算问题。
2. **供应商的 API key 先留在 `.env`，别跟着配置一起删。** 账号还没真删之前，
   留着 key 才能回滚、才能对比新旧行为。清退完成时明确告知「key 暂留，等账号注销再清」，
   别让 Owner 以为已经彻底断了。**等 Owner 回一句「这家我不用了，全部删掉」再走 §九。**

汇报口径同 §六，但要加一栏「哪些落点这次**没动**以及为什么」（例如 dsh 全链路 0 引用、
其余 5 台远端主机 0 引用）—— 用户最想确认的是「有没有漏的地方」，不是逐条复述改动。

---

## 九、彻底清除阶段（Owner：「command 已经可以全部删除了，我已经不用了」）

§8.5 暂留的 key 与历史副本在这一步收。**这不是「再改一次配置」——活跃配置在 §8 已清零，
这一阶段的对象是凭据副本**，扫描口径完全不同，照 §8.1 再扫一遍会得出「已经干净了」的错误结论。

### 9.1 按 key 的**值**扫，不是按变量名扫

`grep -l COMMAND_API_KEY` 只能找到「引用处」；真正的风险是历史产物里**明文存了 key 值**：

```python
ck = <从 .env 读出的该家 key 实际值>          # 不用打印，只在进程内比对
for f in 候选集合:   # .env.bak-* / private/*.json / workspace/*.json|*.py / backups/*/
    if ck and ck in open(f, errors='ignore').read():
        print(f)
```

2026-11-16 实测命中 8 个：4 个 `.env.bak-*`、3 个当次回滚备份里的 `providers.json`、
1 个 workspace 的 staged-nodes 中间文件。**后两类只有按值扫才找得到**（它们没有变量名）。

### 9.2 `.env` 删行可以脚本做，`rm` 会撞审批门

- `.env` / `.env.bak-*` 删掉某一行用 python 写回即可（`[l for l in lines if not l.startswith('KEY=')]`），
  天然带断言（删 1 行 / 剩 N 行），实测不被安全扫描拦。
- **`rm -f` 批量删文件会触发审批门，超时即视为未批准。** 被拦后**不重试、不换写法绕**，
  把「删这几个文件」单列成一句请求交给 Owner 点头，先做完不破坏的部分（删 .env 行、清备份）。
  本次就是卡在这一步：`.env` 行已清掉，两个 workspace 文件停在待批准。
- **sudo 建过的备份属主是 root**（`-rw------- root root`），`grep` 直接 Permission denied ——
  会被误读成「这里没有这条」。先 `sudo -n grep -c` 判真伪，再 `sudo -n python3 -c` 删行。

### 9.3 清完的验收矩阵（四层，缺一层就可能报假成功）

| 层 | 判据 |
|---|---|
| 活跃配置 | 逐文件 `grep -ci "<域名>\|<KEY_NAME>"` = 0：config.yaml / .env / opencode / magpie / 各 bot 的 `data/` |
| DB 驱动 Bot | 容器内读 `runtime_config` 最新 revision，`models.providers[]` 里没有该家 |
| 凭据副本 | 按 9.1 值扫描，命中只剩**明确保留**的历史备份 |
| 运行 | 主模型真出字 + 网关两条模型 200 + 各服务 `is-active` |

「活跃配置 0 命中」不等于「这台机器干净」，也不等于「已彻底断掉」——运行层必须再真发一次请求，
否则删的是没人读的文件也能叫成功。

### 9.4 汇报分「已删 / 等你批准 / 保留」

别把「三个文件等你点头」混进「已清理」里一句带过。含明文旧 key 的中间文件即使不影响运行，
也必须单列为待处理项并说明理由（`rm` 需要 Owner 批准）。用户要的是「还剩什么」，不是改动复述。
