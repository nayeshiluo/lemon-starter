# 第三方编码 CLI 接自有中转：OpenCode 实录（2026-11-07）

## 1. 已落地的配置（本机 ~/.config/opencode/opencode.json）

```json
{
  "$schema": "https://opencode.ai/config.json",
  "provider": {
    "command": {
      "npm": "@ai-sdk/openai-compatible",
      "name": "Command",
      "options": {
        "baseURL": "https://api.commandcode.ai/provider/v1",
        "apiKey": "{env:COMMAND_API_KEY}"
      },
      "models": { "gpt-5.6-sol": { "name": "gpt-5.6-sol" } }
    },
    "nodeai": {
      "npm": "@ai-sdk/openai-compatible",
      "name": "哄哄",
      "options": {
        "baseURL": "https://nodeai.cc/v1",
        "apiKey": "{env:NODEAI_API_KEY}"
      },
      "models": { "deepseek-v4.1-flash": { "name": "deepseek-v4.1-flash" } }
    }
  },
  "model": "command/gpt-5.6-sol"
}
```

两个都跑过 `opencode run 'Respond with exactly: OPENCODE_SMOKE_OK'` → 返回 `OPENCODE_SMOKE_OK`。
key 走 `{env:...}`，密钥不落盘、不进 Git。

## 2. 装与版本

```bash
npm --prefix /home/ubuntu/.npm-global i -g opencode-ai@latest   # 直接 -g 会 EACCES /usr/local/lib/node_modules
ln -sf /home/ubuntu/.npm-global/bin/opencode /home/ubuntu/bin/opencode
opencode --version   # 1.19.5
```

npm 会拦包自带 `postinstall`（`--allow-scripts=opencode-ai` 才放行），CLI 仍可用；若缺平台二进制再放行。

## 3. 厂商免费层：能不能白嫖

### 登录方式（查证自 console 前端 JS，不是猜）

`https://opencode.ai/auth` → `https://opencode.ai/console/login`（SPA，curl 只拿到空壳）。
前端 `index-*.js` 里认证实现只有：

- `GitHubSocialProvider` / `GoogleSocialProvider`（OAuth）
- `auth/register` + `auth/verify-email`（邮箱 + 验证码）
- 企业 SSO：`google-saml / okta-saml / entra-saml / custom-saml`

**没有手机号 / SMS / OTP** —— 「用接码平台注册」不成立，接码只能配合邮箱注册（邮箱本身仍要能用）。

CLI 侧拿凭据不是浏览器回调，而是粘贴 key：

```
opencode auth login -p opencode
# 提示：Create an api key at https://opencode.ai/auth  →  Enter your API key
```

无头服务器可完成；手机登录 Console 建 key 再贴回来也行。

### 免费模型清单（Console free tier，`opencode/<id>`）

`glm-5.3-flash-free`、`deepseek-v4.1-flash-free`、`big-pickle`、`iceman-free`、`flint-40b-free`、
`mimo-v2.6-flash-free`、`nemotron-3-ultra-free`、`nemotron-3.5-lightning-free`、`nemotron-3.5-super-vl-free`、
`inkling-2-small-free`、`crouton-alpha-free`、`beam-free`、`jev-1.13-free`

Go 订阅（$10/月）里另有三个 unlimited 免费模型（Crouton Alpha Free / Beam Free / Iceman Contributor Free）——
那是订阅权益，不是免费层。免费层文档明确要求「用 OpenCode 客户端」。

### 额度实测（关键结论）

| 动作 | 结果 |
|---|---|
| `opencode run -m opencode/glm-5.3-flash-free '...'` | stdout 空、exit 0 |
| 同上 + `--print-logs` | `AI_APICallError: Free usage limit reached. Free models work in OpenCode; subscribe to OpenCode Go to keep going` |
| 换出口 IP（本机 → vps-la socks5 → SG <PRIVATE_IDENTIFIER>）重试 | **同一条限制**，额度按匿名安装/账号计，不按 IP |
| `opencode/nemotron-3-ultra-free` | `UnknownError: Unexpected server error` |
| `crouton-alpha-free` / `beam-free` | 文档明确不覆盖中国（含港澳），地区受限 |

结论：不是「没登录所以不能用」，是额度已耗尽；换 IP 不能重置。恢复只有订阅 Go 或换账号（后者属滥用，账号可能被封，不做批量）。
**遇到「有免费模型吧，我能用吗」这类问题，直接给这张实测表，别再重复探测。**

## 4. 副产品：HTTP CONNECT → SOCKS5 桥

Node/undici 不认 `HTTPS_PROXY=socks5h://...`（`UnsupportedProxyProtocol fetching ...`）。
只有 socks5 出口、客户端只支持 http 代理时，用 `socks5-proxy-setup/scripts/http2socks.py <port>`
起本地 http-CONNECT 桥，再 `HTTPS_PROXY=http://127.0.0.1:<port>` 指过去即可（实测经 vps-la 出网正常）。
