# 中转站（New API）故障分层归因

触发：用户问「XX 站现在能用吗 / 啥时候坏的 / 是不是也出问题了」，或探针报 provider 失败。
核心纪律：**先分层，再下结论**；站方侧的故障在客户端改任何参数都救不回来，别瞎调。

## 一、按响应体分层（New API 语义）

| 层 | 典型响应 | 含义 | 谁修 |
|---|---|---|---|
| DNS | `curl: (6) Could not resolve host` | 域名记录没了 | 站方 |
| 权限/分组 | `No permission to access group X` | key 被踢出分组 / 降级 / 欠费 | 站方 |
| 渠道 | `No available channel for model X under group Y (distributor)` | 分组在，但下面一个渠道都没有 | 站方 |
| 额度 | `Free usage limit reached` / quota 类 | 单模型或账号限额 | 等额度 / 换模型 |
| 客户端 | `404` 打 `/v1/v1`、`400 invalid_request`（如 `messages.name`） | 路径或参数填错 | 自己 |

判据要点：报错里出现 `under group X` 时，**换模型名毫无意义**——故障在分组层。

## 二、bogus model 探针（最关键的判据）

用一个肯定不存在的模型名请求 `/v1/chat/completions`：

- 回 `No available channel for model definitely-not-a-model-xyz under group vip` → **分组级故障**（连不存在的模型都进不了分组）
- 回 `model not found` / `unknown model` → 才是模型名问题
- 回 `No permission to access group` → 连分组都进不去，比渠道故障更彻底

再配 `GET /v1/models`：返回 `{"data":[],"object":"list","success":true}` = key 认证通过但分组下无渠道，与上面互相印证。
返回 `{"error":{"message":"No permission to access group ..."}}` = 权限层，连清单都拒。

## 三、错误码演进本身就是证据，别只说「还是不行」

同一站隔几小时报错变了，性质就变了。2026-11 实录（LG / leguanai）：

- `2026-11-15 23:02 CST`：`No available channel ... under group vip (distributor)` → 渠道被清空
- `2026-11-16 10:01 CST`：`No permission to access group vip` → key 已被移出分组

后者更彻底（`/v1/models` 一并拒）。两次都只能找站方，客户端侧不动配置。
**汇报时必须写清是哪一层**，不要笼统说「上游挂了」。

## 四、request id 里带上游时间戳 → 用它夹出故障时间窗

New API 的 request id 形如 `202611151502120463350498268d9d6GVRxIzxO`，前 14 位是**服务端 UTC 时间**：

```
2026-11-15 15:02:12 UTC  =  2026-11-15 23:02:12 CST
```

用户问「啥时候坏的」时：最后一条成功记录 + 第一条失败 request id，夹出时间窗。
坑：本地日志是 CST，request id 是 UTC，混用会差 8 小时。

## 五、整站死 vs 子域记录被删

- **主域与其他子域正常解析，只有目标子域 NXDOMAIN** → 该子域记录被删，不是服务器宕机，也不是本机 DNS 问题
- 别只看本机：三家公共 DNS 都查一遍才算硬结论
  `for r in 1.1.1.1 8.8.8.8 <YOUR_SERVER_IP>; do nslookup <host> $r; done`
- 再判服务是否还活着：用已知 CF IP 硬连 + Host 头
  `curl --resolve token.thxnk.cc:443:<YOUR_SERVER_IP> https://token.thxnk.cc/v1/models`
  返回 `http=530` + body `error code: 1016` = Cloudflare **Origin DNS error**（CF 仍认这个 hostname，但源站记录失效/被删）

## 六、影响面要查全

`grep -rl "<域名>" <项目目录> /etc/systemd/system`，排除 `logs/`、`.log`、`sessions/`、`node_modules/`、`.git/`。典型落点：

- `~/.hermes/config.yaml` 的 `custom_providers[]` **和** `fallback_providers[]`（备用链最容易被漏）
- 自建 bot 的 `data/ai_endpoints.json`（如群霸的 `zhousan` 池）
- `~/.hermes/workspace/` 里的部署脚本、`state.db`

同时**实测主链**再断言「主链没受影响」，别因为它是备用就跳过验证：

```bash
~/.hermes/hermes-agent/venv/bin/python -m hermes_cli.main \
  -z '只回复两个字：收到' -m '<model>' --provider '<provider>' -t ''
```

## 七、给用户的收尾

- 说清「哪一层坏、断在什么时间、影响哪几条链路、谁修」
- 备用链指向死域名时，可以建议摘掉（回退到死域名只会多等一次超时），但改前备份 config 并确认它确实在 `fallback_providers` 里
- 两个站同时挂但症状不同（一个权限、一个 DNS）时，明确说「症状不同，但时间接近，可能是同一批站方问题」，不要强行归因为同一根因

## Pitfalls

- 拿单次 `curl` 的空输出当「服务挂了」：先看是 `curl: (6)` 还是 HTTP 码，DNS 失败与 5xx 是两回事。
- 只测一个模型就说「站挂了」，或只测到分组级报错就逐个换模型名试——都不对。
- 把「额度限流」误判成「站方跑路」：`Free usage limit reached` 带恢复时间戳（如 `before 14:35 UTC+0`），是可等的。
- 建议改配置前不备份、不核 `fallback_providers` 现状。
