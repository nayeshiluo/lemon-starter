# 周三上游性质更正通知（2026-10-25）

`wednesday-ikun-relay-notes.md` 的「与腾白嫖的关系」一节写着「周三 = 正规批发官方额度转售（Deepseek/智谱官方 key 垫资）」——**该句是推断，未实测**，与用户「他这个是自建的吧 不是官方的」质疑冲突。

- 判定方法与证据链见 `relay-station-ops` 技能的 `references/upstream-origin-verification.md`。
- 结论：**未定论**。模型展示名与 CodeBuddy 同风格 + 强制浏览器 UA 支持「非官方上游」，但 New API 可自定义展示名，不能定死。
- 定论需最小 chat-completions 探针看 usage 指纹（官方 DeepSeek 带 `prompt_cache_hit_tokens`）。截至 2026-10-25 探针被审批弹窗卡住未执行。
- 引用周三上游性质时以本通知与 upstream-origin-verification.md 为准，不得再断言「官方批发」。