# NOFX 与 Justwoker 接入与实测记录

## 1. NOFX API Gateway (nofx.one)

- **控制台**: `https://<id>.nofx.one`
- **Base URL**: `https://<id>.nofx.one/v1`
- **认证方式**: `Authorization: Bearer <sk-...>`
- **特性与避坑**:
  - 新建 Token / 初始状态若未分配额度，所有端点（包括 `GET /v1/models`）均返回 `403 Forbidden` (`INSUFFICIENT_BALANCE`)。
  - 额度生效后可用模型：`gpt-5.6-terra` (极速)、`gpt-5.6-sol`、`gpt-5.6`、`codex-auto-review`。
  - **生图接口特例**：`gpt-image-2` 仅支持 `/v1/images/generations`，请求 `/v1/chat/completions` 会直接返回 `400 invalid_request_error`（“This model is not supported on the Chat Completions endpoint”）。因此注册 provider 的 models 列表时，必须排除纯生图模型，仅保留文本/聊天模型。

## 2. Justwoker (api.justwoker.icu)

- **系统架构**: New API 网关
- **Base URL**: `https://api.justwoker.icu/v1`
- **认证方式**: `Authorization: Bearer <sk-...>` 或 Anthropic 原生 `x-api-key: <sk-...>`
- **特性与实测**:
  - 支持模型：`claude-opus-5-thinking`、`claude-opus-5`
  - 底层为 Anthropic Claude 体系（Claude Code CLI 深度工程编程代理环境），逻辑严密，适合重构、复杂算法与技术排障。
  - 短对话响应快 (~1.5s)，深度思考长文本任务生成耗时在 15s~25s 左右。
