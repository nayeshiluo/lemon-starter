# NOFX 与 Justwoker 接入与实测记录

## 1. NOFX API Gateway (nofx.one)

- **控制台**: `https://<id>.nofx.one`
- **Base URL**: `https://<id>.nofx.one/v1`
- **认证方式**: `Authorization: Bearer <sk-...>`
- **特性与避坑**:
  - 新建 Token / 初始状态若未分配额度，所有端点（包括 `GET /v1/models`）均返回 `403 Forbidden` (`INSUFFICIENT_BALANCE`)。
  - 额度生效后可用模型：`gpt-5.6-terra` (极速)、`gpt-5.6-sol`、`gpt-5.6`、`codex-auto-review`。
  - **生图接口特例**：`gpt-image-2` 仅支持 `/v1/images/generations`，请求 `/v1/chat/completions` 会直接返回 `400 invalid_request_error`（“This model is not supported on the Chat Completions endpoint”）。因此注册 provider 的 models 列表时，必须排除纯生图模型，仅保留文本/聊天模型。

## 2. Justwoker (api.justwoker.icu)

- **系统架构**: New API 网关
- **Base URL**: `https://api.justwoker.icu/v1`
- **认证方式**: `Authorization: Bearer <sk-...>` 或 Anthropic 原生 `x-api-key: <sk-...>`
- **特性与实测**:
  - 支持模型：`claude-opus-5-thinking`、`claude-opus-5`
  - 底层为 Anthropic Claude 体系（Claude Code CLI 深度工程编程代理环境），逻辑严密，适合重构、复杂算法与技术排障。
  - 短对话响应快 (~1.5s)，深度思考长文本任务生成耗时在 15s~25s 左右。
- **⚠️ 主备 Key 双失效实测（2026-09-04）**：`JUSTWOKER_API_KEY` 报 `insufficient_user_quota`（余额 `＄-0.001844`，New API 余额转负直接阻断），`JUSTWOKER_BACKUP_API_KEY` 报 `Invalid token` —— **备用 Key 也已失效，主备容灾同时失守**。切换主模型到 justwoker 前必须先实测两个 Key，不能假定备用可用。

---

## 3. 「切换到 Claude 模型」的落地路径（多通道择优，2026-09-04 实测）

用户说"换成 Claude 的模型"时，**不要只改配置就宣布切换成功** —— 必须实测到 `hermes chat -q` 有回复框才算成。本地有多个通道挂着 Claude，实测排序：

| 通道 | 模型 | 结果 |
|---|---|---|
| justwoker / justwoker-backup | `claude-opus-5-thinking` | ❌ 主 Key 余额负、备 Key Invalid token |
| gemini-proxy (本地 CPA :8317) | `claude-sonnet-4-6` / `claude-opus-4-6-thinking` | curl ✅ 通，但 **Hermes 走不通**（见下） |
| **Share (sharellm.cn)** | **`claude-opus-5`** | ✅ **可用，最终选用** |

### 坑 A：`max_tokens` must be greater than `thinking.budget_tokens` (HTTP 400)

本地 CPA 网关的 Claude thinking 模型，curl 裸测（`max_tokens: 50`）完全正常，但经 Hermes 发出必报：

```
HTTP 400: `max_tokens` must be greater than `thinking.budget_tokens`
❌ The provider rejected the request because max_tokens exceeds its output cap
```

Hermes 自带的错误提示会把人**引向错误方向**（它说"降低 model.max_tokens"，实际是网关注入的 thinking budget 与 max_tokens 冲突）。同一端点的 `claude-sonnet-4-6` 与 `claude-opus-4-6-thinking` 都复现。判定：该通道的 Claude 模型不适配 Hermes 请求体，**换通道比调参数快**。

### 坑 B：切 provider 必须清空残留的 `model.base_url` / `model.api_key`

只改 `model.default` + `model.provider` 不够 —— 旧通道的 base_url/api_key 会残留并覆盖新 provider 的端点，配置看着切了、实际还在打旧地址。完整切换动作：

```bash
hermes config set model.base_url ""      # 先清，顺序无所谓但两个都要清
hermes config set model.api_key ""
hermes config set model.provider Share   # custom_providers 里的 name，不带 custom: 前缀也可
hermes config set model.default claude-opus-5
hermes config get model                  # 回读确认 base_url/api_key 为空
hermes chat -q "直接回复：已切换"        # 必须实测到回复框
```

`hermes config get model` 显示 `api_key: ''` / `base_url: ''` 时，主模型走 custom_providers 条目自身的 base_url + key_env，这才是正确状态。

### 通道快速探测脚本

```bash
KEY=$(grep '^<NAME>_API_KEY=' ~/.hermes/.env | cut -d= -f2- | tr -d '"'"'"'')
curl -s -m 30 "$BASE/v1/chat/completions" \
  -H "Authorization: Bearer $KEY" -H "Content-Type: application/json" \
  -H "User-Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/126.0 Safari/537.36" \
  -d '{"model":"<m>","messages":[{"role":"user","content":"回复两个字：能用"}],"max_tokens":50}'
```

带 UA 伪装（防 Cloudflare WAF 把裸 SDK UA 拦成 403），`max_tokens` 给足防思考模型吃满。
curl 通 ≠ Hermes 通（见坑 A），**两层都要验**。
