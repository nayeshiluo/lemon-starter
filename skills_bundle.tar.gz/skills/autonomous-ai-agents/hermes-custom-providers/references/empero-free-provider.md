# Empero 免费社区模型端点 (free.empero.org)

## 基本信息

- **官网 / 实验室**: [Empero Research Lab](https://empero.org) (德国独立开源 AI 实验室)
- **Base URL**: `https://free.empero.org/v1`
- **Web UI / Playground**: `https://free.empero.org/gui`
- **认证方式**: OpenAI 兼容协议，接受任意 API Key（如 `free`）
- **环境变量名建议**: `SHIGUANG_BAIPYAO_API_KEY=free`

## 模型列表与实测状态

| 模型 ID | 类型 / 架构 | 状态 | 备注 |
|---|---|---|---|
| `glm-5.3-flash` | 深度推理 / 思考模型 | ✅ 可用 | 底层路由至 Z.AI，返回 `reasoning` 字段，响应迅速 |
| `qwen3.8-flash` | 通用 / 思考模型 | ⚠️ 偶发不稳定 | 高峰期可能返回 `upstream_down`，可重试 |

## 接入配置示例 (Hermes custom_providers)

```yaml
- name: 拾光群里的白嫖
  base_url: https://free.empero.org/v1
  key_env: SHIGUANG_BAIPYAO_API_KEY
  model: glm-5.3-flash
  api_mode: chat_completions
  models:
    - glm-5.3-flash
    - qwen3.8-flash
```

## 注意事项

1. **隐私与数据记录**: 官方用于开源模型训练与学术研究，所有 Prompt/Completion 会被记录（IP 进行哈希匿名化处理）。请勿传输敏感数据。
2. **推理模型 token 消耗**: `glm-5.3-flash` 会产生 reasoning_tokens，单次探测或调用时 `max_tokens` 需设足（建议 200+），避免输出被截断。
