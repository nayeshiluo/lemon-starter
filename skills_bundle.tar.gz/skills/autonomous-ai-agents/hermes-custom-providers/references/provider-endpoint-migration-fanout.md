# 同一 provider 换站（base_url + key + 模型清单一起换）的全量落点

2026-11-10 实录：周三从 `https://<YOUR_PRIVATE_DOMAIN>/v1` 迁到 `https://token.thxnk.cc/v1`，
用户要求「所有之前用周三的都同步替换掉」。**只改 config.yaml 一处是必然翻车的**——本次共 13 类落点。

> 最容易被漏的两类：**§9 `state.db` 里的会话级 model override（优先级高于 config，漏了报错会伪装成"新配置没生效"）**
> 和 **§3/§4 的补丁文件 + 守卫 marker（漏了补丁守卫立刻误报 patch_lost）**。

## 0. 先判「换站」还是「换 key」

拿 `.env` 里**现有** key 同时打**新老两个端点**：

```bash
set -a; . /home/ubuntu/.hermes/.env; set +a
for U in https://new.host/v1 https://old.host/v1; do
  curl -s -m 20 -o /tmp/x.json -w "$U  HTTP %{http_code}\n" "$U/models" \
    -H "Authorization: Bearer $IKUN_API_KEY"; head -c 120 /tmp/x.json; echo
done
```

本次两边都 `401 {"type":"new_api_error"}` → 说明**该 provider 早就死了**，不是"只换 URL 就行"。
汇报时必须把「端点变更」与「凭据失效」分开写，否则用户以为改 base_url 就够了。

## 1. 运行时配置落点（4 处，全部要改）

| # | 位置 | 说明 |
|---|---|---|
| 1 | `~/.hermes/.env` 的 `<NAME>_API_KEY` | 新 key。**路径写死 `/home/ubuntu/.hermes/.env`**，见 `secret-env-write-handoff.md` |
| 2 | `config.yaml` → `custom_providers[<名>].base_url` + `models` | 主清单 |
| 3 | `config.yaml` → `fallback_providers[]` 里的同名字段 | **独立一份副本，很容易漏**。`grep -n "<旧域名>" config.yaml` 应命中 2 次 |
| 4 | 各 bot 的端点池（如 `lemon-group-bot/data/ai_endpoints.json` 的 `zhousan.url`） | 注意带 `/chat/completions` 后缀；两个 bot 常共用同一 data 目录（`systemctl cat` 看 `WorkingDirectory` 确认） |

**反向确认 bot 的 key 需不需要单独改**：读消费代码，若它走
`_read_env_val(key_env)` 且回落到 `/home/ubuntu/.hermes/.env`（群霸 `services/ai_service.py:102` 就是这样），
则 **key 只改一处即可，但 url 各存一份必须单独改**。
`load_shared_endpoints()` 无缓存，改 json 即热生效、不用重启 Bot。

## 2. ⚠️ 源码里硬编码 hostname 的本地补丁（最容易静默失效）

Hermes 有本地补丁：**只对特定网关剥离 `tool` 消息的 `name` 字段**（这类 New-API 站带 `name` 直接 400）。
判断写的是 `urlsplit(base_url).hostname == "<旧域名>"` —— **换域名后补丁静默失效，整条 tool 调用链会 400**。

```bash
grep -rn "<旧域名>" ~/.hermes/hermes-agent/agent/ --include="*.py"
# 本次命中：
#   agent/chat_completion_helpers.py  （迭代上限摘要路径，旁路手拼 messages）
#   agent/transports/chat_completions.py （主循环 transport）
```

改法：**保留旧域名，扩成元组**，回滚时不用再改第二遍：

```python
strip_tool_result_name = (
    urlsplit(str(agent.base_url or "")).hostname
    in ("<YOUR_PRIVATE_DOMAIN>", "token.thxnk.cc")
)
```

先验新站到底要不要剥（按 字段×角色 矩阵，别猜）：

```bash
# role=tool + name        → 本次 400 invalid_request（必须剥）
# role=user + name        → 本次 200（不能剥，剥了反而丢信息）
```

改完离线断言行为，不要只看代码：

```python
from agent.transports.chat_completions import ChatCompletionsTransport
t = ChatCompletionsTransport()
msgs = [{"role":"tool","name":"terminal","tool_call_id":"c1","content":"ok"}]
for base in ("https://token.thxnk.cc/v1", "https://other.example/v1"):
    print(base, t.convert_messages([dict(m) for m in msgs], model="X", base_url=base))
# 新站应无 name；别家应保留 name
```

## 3. 记录型补丁文件必须同步，否则补丁守卫立刻报警

本地改动被两份 patch 文件记录，`git apply --reverse --check` 是它们的"未漂移"判据：

| 文件 | 用途 |
|---|---|
| `~/.hermes/patches/production-20261028-v2/production.patch` | 全量本地差异，守卫的 `whole_patch` behavior 用它 |
| `~/hermes-jobs/backup/hermes-patch/summary-strip-tool-name.patch` | 摘要路径剥 name 的重放补丁（守卫告警里会给出重放命令） |

**语义别搞反**：patch 正向是 `上游原版 → 本地改后`，所以改动落在这两份文件的 `+` 行上：
`+            == "api...."` → `+            in ("api...", "token.thxnk.cc")`。

```bash
cd ~/.hermes/hermes-agent
git apply --reverse --check ~/.hermes/patches/production-20261028-v2/production.patch && echo PASS
```

不同步的症状：`patch_guard --check` 报
`FAIL 完整本地差异与安装源码匹配: behavior_failed local probe exited 1` /
`patch failed: agent/transports/chat_completions.py:254`。

## 4. 守卫配置的 marker 也要改（两份）

`patch-guard.json` 的 `markers["域名门控"]` 是**源码子串断言**，改了源码不改 marker 会报 `patch_lost`；
`gates[].domain` 是**"该域名还在 config 里吗"**的探针，留着旧域名会报 `gate_unused`。

- `~/hermes-jobs/patch-guard.json`（线上）
- `~/hermes-ops-private/projects/hermes-local-patches/guard/patch-guard.template.json`（模板，别只改线上）

验收：

```bash
cd ~/hermes-jobs && ~/.hermes/hermes-agent/venv/bin/python3 \
  ~/.hermes/skills/autonomous-ai-agents/hermes-ai-chain-alert-triage/scripts/patch_guard.py \
  --config patch-guard.json --check --no-notify
# 期望：检查完成：ok（20 目标 + 1 门控 + 5 import + 5 behavior，异常 0）
```

⚠️ 别用 `verify_patch_guard.py` 当验收 —— 它是**自测套件**（用假 marker 跑 9 个故障场景），
输出一堆 `❌` 是预期行为。线上验收走 `patch_guard.py --check`。

## 5. 探针/验证脚本与一次性部署脚本里的旧地址

用户说「都替换掉」时这些也在范围内（不然下次跑脚本又写回旧值）：

```
hermes-jobs/name-probe-zhou3.py            # 探针的目标网关 + 脱敏 replace
hermes-jobs/verify-name-patch.py           # GW 常量
hermes-jobs/verify-patch-behavior.py       # CASES 里"周三网关"那条的 base_url
~/.hermes/skills/autonomous-ai-agents/hermes-ai-chain-alert-triage/scripts/verify_bypass_patch_behavior.py
                                           # TARGET_BASE_URL（离线行为验收模板的 CONFIG 区）
smart-group-bot/seed_models.py             # ProviderConfig.api_base
.hermes/workspace/*.py|*.sh|*.json|*.yml   # staged 节点集 / 一次性迁移脚本
```

改完做语法闸门：`python3 -m py_compile <files>`、`bash -n <files>`、
`python3 -c "import yaml/json; ..."` 回读结构化文件。

**不要改**：备份（`*.bak*`、`backups/`、`recovered-git-*/`）、日志、`sessions/`、
Codex rollout jsonl、`state/rich_sent_index.json`（历史消息正文）、
`provider_models_cache.json`（按 base_url 做键的缓存，新键自会新增，旧条目无害）。
技能文档里的旧数据按**历史记录**保留，只在顶部加迁移横幅，不改写成假的新数字。

## 6. 验收阶梯（每层都要过，缺一层不算完）

```
① curl /v1/models        → 200 + 真实模型清单（本次新站只剩 2 个，旧的 4 个里有 2 个已不存在）
② curl chat 逐模型        → 200 + 非空 content
③ hermes chat -q --provider <名> --model <M>  → 真链路出正文
④ bot 侧 test_single_node()                    → 200 OK（bot 自己的函数，不是裸 curl）
⑤ patch_guard.py --check                       → ok
⑥ verify-name-patch.py（端到端 400→200）        → 总体验收: 通过
⑦ hermes config check                          → Config version 34 ✓
```

⚠️ `hermes config check` 的输出末尾是一长串 `○ <ENV_NAME>` 未设置清单，`tail -15` **只会看到 env 噪音**。
判据行在开头，用 `hermes config check 2>&1 | grep -E "Config version|✗|invalid|error"` 取。

## 7. 两个坑

- **模型清单要现拉 `/v1/models`，不能照抄旧配置**：本次 4 个模型里有 2 个（`Deepseek V4 Pro`、
  `GLM 5.3 Flash`）新站根本不存在。删之前仍按铁律（`/models` 差集只产生候选）——但这里是**用户主动换站**，
  旧模型属于旧站资产，直接按新站清单对齐并说明即可。
- **`GLM 5.3` 带 reasoning**：`max_tokens=64` 时 HTTP 200 但 `content: ""`（思维链吃光预算），
  给到 800+ 才出正文。测活时别按小预算判死。
- **上游瞬时 `403 {"message":"sqlite3: database is locked","code":"pre_consume_token_quota_failed"}`**
  （预扣额度阶段）是站方抖动，不是配置错：重试/隔几秒即可，本次 `verify-name-patch.py` 第一次因此报
  `总体验收: 未通过`，重跑就过。判据是**同一 payload 稍后能 200**，别据此回滚。

## 8. 收尾：哪一层需要重启、哪一层不用（别一刀切说「都要重启」）

`hermes-gateway` 是常驻进程（`systemctl status` 看启动时间 4 天前也不奇怪），但**各层生效时机不同**：

| 层 | 是否要重启 | 依据 |
|---|---|---|
| `/model` 菜单里的 provider + 模型清单 | **不用** | picker 每次调用 `_load_gateway_config()` 从磁盘重读（mtime 键控缓存），新值立即生效 |
| Bot（群霸）端点池 `ai_endpoints.json` | **不用** | `load_shared_endpoints()` 无缓存，每次读文件 |
| **源码补丁**（§2 的剥 name 门控） | **必须重启** | 进程里是旧字节码 |
| 进程内已加载的 fallback 链 / 已建会话 | 重启才彻底 | 长连接与内存态不会自我刷新 |

所以「菜单已经显示 2 个模型」**不能**当成「全部生效」的证据：本次按用户要求没重启，
就必须明确告知「菜单/配置已生效，但剥 name 门控还在旧代码里，带工具结果的周三日落请求仍会 400」。
只报「改完了」= 埋雷。

### 8b. 顺手核一下 picker 缓存（只读，不用开界面）

模型清单缓存在 `~/.hermes/provider_models_cache.json`，键是 **`custom:<base_url>`**、带凭据指纹与 1h TTL。
**换站后 base_url 变了 → 新键没有缓存 → 自动 live fetch**，旧域名那条是死数据（删不删都行，删了更干净）。

```bash
cd ~/.hermes/hermes-agent && venv/bin/python3 - <<'PY'
import os,sys; sys.path.insert(0,'.')
from hermes_cli.models import cached_fetch_api_models
print(cached_fetch_api_models(os.environ["IKUN_API_KEY"], "https://<新站>/v1", force_refresh=True))
print(cached_fetch_api_models(os.environ["IKUN_API_KEY"], "https://<新站>/v1"))
PY
```

这就是「用户在 /model 里会看到几个模型」的离线答案，比让用户去客户端翻菜单快。
函数签名注意：位置参数是 `(api_key, base_url, ...)`，**没有** `env_names` 参数。

## 9. ⚠️ 会话状态数据库里的旧 base_url（第 5 类落点，最容易被漏且优先级最高）

`state.db` 里存着**按会话持久化的 model override**，它的优先级**高于 config.yaml**。
只改 config 的话，用户下次在那个群里说话，网关仍拿旧 base_url 去打已经 401 的站——而且报错看起来像"新配置没生效"，极易误判。

两类可执行状态（**要改**）：

| 表.列 | 含义 |
|---|---|
| `gateway_routing.entry_json` 里的 `model_override.base_url` | 网关按 source 路由的活动会话 override，改动后下一次被读取 |
| `sessions.model_config` 里的 `gateway_runtime.base_url` | 会话级运行时快照 |

两类审计历史（**绝不能改**）：`sessions.billing_base_url`、`session_model_usage.billing_base_url`
——那是**计费归属**，改了等于把过去的花费记到新站头上。同理别动 `messages.*`、
`system_prompts.prompt`、`sessions.title`（历史正文）。

**扫描方法**：`grep -lI` 会跳过二进制，`.db` 永远筛不出来。用 `strings` + 列级 SQL：

```python
import sqlite3, json
c = sqlite3.connect('file:/home/ubuntu/.hermes/state.db?mode=ro', uri=True)
OLD = 'https://<旧站>/v1'
# 1) 哪些表/列提到了旧域名
for t in [r[0] for r in c.execute("select name from sqlite_master where type='table'")]:
    for col in [d[1] for d in c.execute(f'PRAGMA table_info("{t}")')]:
        try:
            n = c.execute(f'select count(*) from "{t}" where cast("{col}" as text) like ?',
                          (f'%{OLD}%',)).fetchone()[0]
        except Exception:
            continue
        if n: print(f'{t}.{col}: {n}')
```

**改之前先导回滚记录**（只存被改的那几行原文，比整库备份快得多）：
`~/.hermes/backups/state-db-<provider>-url-rollback-<date>.json`，
内容 `{"sessions":[{id, model_config}], "routing":[{session_key, entry_json}]}`。

改法要点：`json.loads` → 只替换 `gateway_runtime.base_url` / `model_override.base_url`
（**必须判等旧值再替换**，否则会把别家 provider 的 url 也扫进去）→ `json.dumps(..., ensure_ascii=False)` 写回。
`state.db` 在 WAL 模式下可写，但**运行中的 gateway 内存里仍是旧值**——改完必须并入重启那一档告诉用户。

## 10. `config.yaml` 不能走 patch/write_file 工具

`patch` / `write_file` 对 `~/.hermes/config.yaml` 会被安全策略直接拒绝
（`Refusing to write to Hermes config file ... Agent cannot modify security-sensitive configuration`）。
**不是 bug**，用 terminal 里的 python 做精确文本替换，替换前后各断言一次命中次数：

```bash
python3 - <<'PY'
import pathlib
p = pathlib.Path('/home/ubuntu/.hermes/config.yaml'); t = p.read_text()
old, new = 'https://<旧站>/v1', 'https://<新站>/v1'
assert t.count(old) == 2, t.count(old)     # custom_providers + fallback_providers 各一份
p.write_text(t.replace(old, new))
PY
hermes config check 2>&1 | grep -E "Config version|✗|invalid|error"
```

删模型同理：`assert t.count("      - <模型名>\n") == 1` 再 replace，避免误删别家的同名行。

## 11. 用户事后问「都换掉了吧，对吧？」时，报告的形状

用户会用一句话要求复核（本次原话：「核实一下…都同步换掉了 对吧」）。**不能只回「对」**，
他会立刻追问细节；也不要只列改动——他要的是**可判定的边界**。四段式：

1. **已确认（带证据）**：表格 `项 | 状态 | 证据`。证据必须是可复现的原话，例如
   `旧站用新 key 仍 401`、`bot 侧 test_single_node 两模型 200（1.63s/1.01s）`、`patch_guard: ok（异常 0）`。
   密钥只报 `长度 + 前缀 + md5 前 8`，绝不回显全文。
2. **你（用户）漏的 / 我补的**：单独一段，写清漏了会怎样（"不改就会继续打死站"），不要混进第 1 段洗白。
3. **故意没动的 + 理由**：计费归属、历史消息正文、补丁元组里的旧域名、过期灾备快照……
   这一段是可信度的关键，缺了会显得"要么全改要么全没改"。
4. **还剩什么动作**：需要重启/需用户决定的，单独列出，别埋在段落里。

同时把这个迁移"顺手发现的过期资产"主动提出来（本次：`hermes-ops-private/…/production-2026xxxx`
灾备快照有 2 个 patch 与工作区不再一致 → 归档已过期），给出「要不要我重新生成」的选项，不要擅自改。
