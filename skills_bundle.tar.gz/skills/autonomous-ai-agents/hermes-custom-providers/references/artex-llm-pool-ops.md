# ARTEX (artex.<PRIVATE_IDENTIFIER>) 部署与模型池运维

> ARTEX = 自托管渗透测试智能体框架（ruoji6/artex，Docker），与 Hermes 无关的独立应用。
> 本文件覆盖：访问门禁排障、版本升级、`llm_profiles` 模型池增删改。模型池部分即本技能「为外部应用分配模型角色」的实例。

## 部署拓扑（2026-11-17 核实）

- 目录：`/home/ubuntu/artex/`（`docker-compose.yml` + `Caddyfile` + `data/`）
- 容器：`artex-artex-1`（主服务 127.0.0.1:8787）、`artex-postgres-1`、`artex-authproxy`（Caddy 127.0.0.1:8899）、`artex-cpa-relay`（socat:83xx）
- 入口：Cloudflare 命名隧道 `artex-tunnel.service`（token 文件在 `~/.config/lemon-cloudflare/`）→ authproxy:8899 → 8787

## 坑 1：整站 403 = 门禁 Cookie 过期，不是服务故障

authproxy 的 Caddyfile 实现了授权门禁：只认 Cookie `artex_gate=<k值>`（Max-Age 30 天），过期/被浏览器清掉后所有路径裸 403 `Forbidden`（`server: cloudflare` + `Server: Caddy`）。
排查顺序：本机 `curl http://127.0.0.1:8787/` = 200 而 `https://artex.<PRIVATE_IDENTIFIER>/` = 403 → 链路全好，纯 Cookie 问题。
修复：让用户开带授权参数的入口 URL（`/?k=<Caddyfile 里 @grant 的值>`），种回 Cookie 后 302 回首页。不要去重启容器——没用且打断任务。

## 坑 2：升级 = 改 compose 镜像 tag 重建，数据在 PG 卷里

1. `cp docker-compose.yml docker-compose.yml.bak-日期`，sed 换 `ruoji6/artex:vX.Y.Z` tag
2. `docker compose pull artex && docker compose up -d artex`（**不加 `--remove-orphans`**——authproxy/cpa-relay 是独立 compose 起的，会被当孤儿删掉）
3. 验收：容器 Up + `curl 127.0.0.1:8787` = 200 + `docker logs` 出现 `backend listening`、`reloaded N task(s)`、`built provider for LLM profile`；外网走门禁 403 是正常态
4. 版本/changelog 以 GitHub Releases 为准（RuoJi6/ARTEX），Docker Hub tags 与之同步

注意：`docker compose up -d` 在 Hermes 终端里会被前台守护进程检测拦下，须 background=true 跑。

## 模型池：postgres `llm_profiles` 表

- 连接：`docker exec artex-postgres-1 psql -U artex -d artex`（用户是 `artex` 不是 `postgres`）
- 关键列：`name, format('openai'), base_url, model, api_key, is_default, priority, pool_exclude, context_window_k, streaming`。`priority` 数值越小越靠前；`pool_exclude=true` 则不进自动池
- **面板改的还是这张表**，直接 SQL 增改与面板等效；改完 `docker restart artex-artex-1` 让 engine 重建 provider（日志确认）
- 插入整组 profile 的做法：`INSERT ... SELECT '前缀/'||m, ... FROM unnest(ARRAY[...]) m, llm_profiles p WHERE p.id=1` 复制默认行的其余字段，避免手写 27 列
- key 明文落库（`api_key`）+ 尾 4 位 hint；从 `~/.hermes/.env` 取 key 时不要让它出现在终端输出里

## 坑 3：中转站换域后旧 profile 全坏且无人知晓

ARTEX 里的 profile 指向旧域名（如周三 `<YOUR_PRIVATE_DOMAIN>`）时，key 已失效返回 `Invalid token`，但面板/任务不会主动报。**每次整理模型池先对每个 base_url 重新探测**：`/v1/models` + 每模型最小 chat，再决定迁移/合并/删除。周三现站为 `token.thxnk.cc/v1`（仅 `Deepseek v4.1 Flash` / `GLM 5.3` / `Flux`，Flux 是图片模型聊天端点 400）。

## 坑 4：入库前逐模型实测，别按历史清单搬

LG 站可用模型集合隔几天就换一批（详见 lg-leguanai-relay-notes.md 2026-11-17 段）。批量入库流程：`/v1/models` 取清单 → 逐个最小 chat（max_tokens≥512 防 reasoning-only 假死）→ 只把返回正文的写入 `llm_profiles`，priority 排在主力之后做手动备用。

## 坑 5：大版本升级后前端路由全改名 ≠「页面坏了」（v0.3.30 实录）

升级 v0.3.26→v0.3.30 后用户报「除任务界面外其他页面全显示"此页面无法加载"」。真相：**新版前端把路由重排成两棵树**，旧一级路径服务端 404（返回 `__next_error__` HTML），API 与静态资源全部 200 正常。

- 新结构：`/system/{settings,llm,agents,logs,tools,intercept,notify,skills,mcp}` 与 `/function/{tasks,traffic,findings,workspace(原companies),schedules,commands,repeater,sync,llm-records,assets}`；`/tasks` 未变所以能进。
- 诊断法（不开浏览器）：`curl -b <jar> http://127.0.0.1:8787/<path>/index.txt?_rsc=x` —— 返回 `1:"$Sreact.fragment"` = 路由存在；`__next_error__` = 404。
- 全量路由清单：`docker cp artex-artex-1:/app/artex /tmp/ && strings /tmp/artex | grep -oE 'webui/dist/[a-z0-9_/.-]+'`。
- 处置：告诉用户从侧边栏菜单导航（链接是新的）、换掉收藏夹旧 URL；不要回滚版本。

