# 智谱 AI (BigModel) Provider 模型实测与配置清单

## 端点信息
* **Base URL**: `https://open.bigmodel.cn/api/paas/v4`
* **协议**: 标准 OpenAI 兼容（chat_completions）
* **Key 环境变量**: `ZHIPU_API_KEY` (存入 `~/.hermes/.env`)

## 实测可用模型列表 (Chat Completions)
* `glm-4-flash`：免费轻量 / 极速响应，适合日常辅助及快速问答
* `glm-4-plus`：智谱旗舰大模型，综合推理能力强
* `glm-4-air` / `glm-4-airx`：高性价比模型 / 推理增强
* `glm-4-long`：百万 Token 超长上下文
* `glm-4-flashx`：超快推理增强
* `glm-4v-plus` / `glm-4v` / `glm-4v-flash`：多模态视觉理解与图文解析
* `glm-4.5` / `glm-4.5-air` / `glm-5.2` / `glm-5.3-flash`：GLM 演进与预研版本

## Hermes Provider 配置示例
```yaml
- name: 智谱
  base_url: https://open.bigmodel.cn/api/paas/v4
  key_env: ZHIPU_API_KEY
  api_mode: chat_completions
  model: glm-4-flash
  models:
    - glm-4-flash
    - glm-4-plus
    - glm-4-air
    - glm-4-airx
    - glm-4-long
    - glm-4-flashx
    - glm-4v-plus
    - glm-4v
    - glm-4v-flash
    - glm-4.5
    - glm-4.5-air
    - glm-5-turbo
    - glm-5.2
    - glm-5.3-flash
```
