# Router.ai (Claude 纯血 / Bedrock 官方链路端点实测记录)

## 端点概述
- **Base URL**: `https://api.router.ai/v1`
- **协议类型**: 标准 OpenAI 兼容接口 (`/v1/chat/completions`, `/v1/models`)
- **渠道特性**: 原生 Claude / AWS Bedrock 真实上游路由

## 实测详情 (2026-10)

### 1. 连通性与模型列表
- `GET /v1/models` 返回 HTTP 200，支持 150+ 模型。
- 覆盖 Claude 全系列衍生版本：
  - `claude-sonnet-4-6`
  - `claude-opus-5`
  - `claude-haiku-4-5-20251001`
  - `claude-sonnet-5`、`claude-opus-5-5` 等

### 2. 真实性验证 (反冒牌 / 反套壳)
- 经自我介绍测试，明确返回由 Anthropic 研发。
- **Tool Calling (Function Calling) 结构验证**：
  在 `tools` + `tool_choice: "required"` 测试中，返回标准的 `tool_calls` 结构：
  ```json
  {
    "id": "toolu_bdrk_01DE3xyHwLxxzEJK1qYhZij1",
    "type": "function",
    "function": {
      "name": "get_weather",
      "arguments": "{\"city\":\"北京\"}"
    }
  }
  ```
  - 工具调用 ID 前缀为 `toolu_bdrk_`，确认为 AWS Bedrock 托管的官方原生 Claude 链路，非第三方小模型套壳。

### 3. Hermes Provider 接入建议
若配置为 Hermes `custom_providers`：
```yaml
custom_providers:
  - name: RouterAI
    base_url: https://api.router.ai/v1
    key_env: ROUTERAI_API_KEY
    model: claude-sonnet-4-6
    models:
      - claude-sonnet-4-6
      - claude-opus-5
      - claude-haiku-4-5-20251001
```
- 注意：由于工具调用支持良好，可安全用作主模型或 fallback 链备选。
