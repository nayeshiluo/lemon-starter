# Command（commandcode.ai）实测档案 — 2026-11

厂家直连 Provider 计划端点。**这里是验证过的事实，不是文档抄录。**

## 接入参数

| 项 | 值 |
|---|---|
| Base URL | `https://api.commandcode.ai/provider/v1` |
| 鉴权 | `Authorization: Bearer <key>` |
| 对话 | `/chat/completions`（另有 `/responses`、`/messages`；Claude 系只走 `/messages`） |
| 模型目录 | `/models`，95 个，带 `supported_endpoints` 区分可用路由 |
| 必需 header | `User-Agent: Mozilla/5.0`（见下「UA 陷阱」） |

## UA 陷阱（最致命的一条）

Cloudflare 前置会拦 UA：

- `curl` 不带 UA → **200**（curl 自带 `curl/x.y`，被放行）
- Python `urllib` 默认 `Python-urllib/3.x` → **403**，正文 `error code: 1010`
- Node `axios` 默认 UA → **200**

所以**首次批量探测 84 个模型全部 403**，误判成「整站不可用」。加 `User-Agent: Mozilla/5.0`
后 57 个可用。写 provider 时把 UA 放进 `extra_headers`：

```yaml
extra_headers:
  User-Agent: Mozilla/5.0
```

同理：用 axios/curl 探通**不能**推断 Python 侧也通，反之亦然。探针语言要和实际调用语言一致。

## 可用性分层（实测 84 个 chat 候选）

| 结果 | 数量 | 说明 |
|---|---|---|
| 200 | 57 | 可注册 |
| 403 | 17 | 路由/权限不允许 |
| 400 | 4 | 参数或能力不符 |
| 404 | 2 | 不存在 |
| 空响应 | 4 | 有 choices 但 content 为空 |

## 免费档模型（GOAT 套餐期）

- `reflection/beam:free` — 无日限，主力首选，中文归因/工具调用/SSE 全过
- `stealth/glyph-cluster:free` — 1000 次/天
- `stealth/crouton-alpha` — 1000 次/天，实测返回空
- 页面上的 `$100` 是**额度倍数**，不是独立余额

## 模型能力（按职责实测）

| 用途 | 模型 | 结果 |
|---|---|---|
| 文本主力 | `reflection/beam:free` | 归因正确 3.7s、工具调用 1.6s、SSE 通过 |
| 文本次选/低延迟 | `deepseek/deepseek-v4.1-flash` | 归因正确 4.0s、工具往返正确 |
| 视觉 | `deepseek/deepseek-v4-flash-vision-exp` | 识图正确（"左侧红色正方形，右侧蓝色圆形"） |
| 视觉备用 | 无 | Beam / Glyph 明确拒绝图片（400），**不能拿文本模型顶视觉** |
| 不推荐 | `z-ai/glm-5.3-flash` | 中文归因答错（把负责人答成小王） |

**推理型模型吃 token**：`reflection/beam:free` 带 `reasoning` 字段，`max_tokens=20/32` 时
可能整个预算被 reasoning 吃掉、`content` 返回空串。小预算探测会误判成「模型不可用」——
探测时给 `max_tokens >= 64`，或只看 `usage` 里的 reasoning 占比。

## 语音：没有（2026-11 实测，别再重复试）

95 个模型里只有 1 个名字带语音语义：`Qwen/Qwen3.8-Omni-Flash`。逐项实测：

| 请求 | 结果 |
|---|---|
| chat 文本对话 | 200，正常 |
| `POST /audio/speech` | **404** `404 Not found. Check the docs for available routes.` |
| `POST /audio/transcriptions` | **404** 同上 |
| `modalities: ["text","audio"]` | 200，但只回 `content` 文本，**无 audio 字段** |
| `content: [{type:"input_audio", ...}]` | **400** `Invalid input` / `param: messages.0.content` |

**结论：既不能 TTS 也不能 ASR。** 需要语音走别的路（`edge-tts` 免密钥，或豆包 openspeech 正式凭据）。
汇报时要说「名字带 Omni 但不等于能出声」，否则用户会以为配错了。

## 无 embedding

`POST /embeddings` → 404。同厂也没有 `embed|bge` 类模型 ID。需要向量时用本地
`bge-small-zh-v1.5`（512 维）另起服务，别拿聊天模型 ID 去填 `embed` 角色。

## 已知坑

- **菜单显示数 ≠ 可用数**：Hermes `/model` 会把上游目录（95 个）合并展示，即使
  `discover_models: false`。57 个可用之外的点选会失败，要主动告知。
- **同名模型跨站串站**：与反重力 / 滴滴滴 / 哄哄 有 8+2+2 个同名 ID。运行时按
  `custom_provider:<名字>` + 独立端点 + 独立密钥解析，实测不串站 —— 但仍需实测确认，
  不能靠「名字不同就是独立」推断。
- 该 key 的明文前缀是 `user_`，长度 93；判定密钥是否就位时只打印长度与前缀，别打全串。
