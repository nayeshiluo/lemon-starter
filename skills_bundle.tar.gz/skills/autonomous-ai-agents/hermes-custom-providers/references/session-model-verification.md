# 会话实际模型核验（session_model_usage 取证法）

2026-10-15 实录：用户在 CLI 问「你现在什么模型」→ 运行时切换事件（gemini-3.8-flash-high → cn:deepseek-v4.1-flash）后追问「现在呢」。全程只读取证，闭环汇报。

## 为什么需要它

- 出现「模型切换」事件（`/model`、平台 note）但**切换动作 ≠ 已生效**，必须取证；
- `config.yaml` 只代表「全局默认」，会话可能有 override（channel_overrides / 会话级切换）；
- `sessions.model` 列在**会话级切换后不更新**（本次仍是旧值 `gemini-3.8-flash-high`），不能拿它当真相；
- 唯一真相：`session_model_usage` 的逐模型调用记录（模型名、billing_base_url、调用次数、首末时间）。

## 取证步骤（只读）

```python
import sqlite3
con = sqlite3.connect('/home/ubuntu/.hermes/state.db'); con.row_factory = sqlite3.Row
# ① 找当前会话（CLI 新会话 id 形如 mv93m70raosz4g；TG/网关形态 20261015_xxxx_xxxxxx）
for r in con.execute("SELECT id, source, title, model, last_activity_at FROM sessions ORDER BY last_activity_at DESC LIMIT 5"):
    print(dict(r))
# ② 逐模型真实用量（真相层）
for r in con.execute("SELECT model, billing_provider, billing_base_url, api_call_count, input_tokens, output_tokens, first_seen, last_seen FROM session_model_usage WHERE session_id=? ORDER BY last_seen DESC", ('<session_id>',)):
    print(dict(r))
```

补充取证：
- 全局默认：`hermes config get model.default`、`hermes config get model.provider`（只读、免交互）；
- `stat -c %y ~/.hermes/config.yaml` 的 mtime 对比切换时间；
- epoch 换算：`date -u -d @<YOUR_USER_IDENTIFIER>`；BJT = UTC + 8。

## 判定表

| 证据 | 结论 |
|---|---|
| session_model_usage 出现两行，新模型 last_seen 最新 | 本会话中途切换，新模型生效中 |
| 新模型行存在但无真实调用记录 | 配置已改但未生效，别报「已生效」 |
| config.yaml mtime 早于切换时间 | 全局默认未变；新会话 / 网关 / cron 仍走旧默认 |
| config.yaml mtime 晚于切换时间且 model.default 已变 | 全局默认已切；再查 channel_overrides 与 cron model_snapshot |

## 本次实报口径（可复用模板）

1. 当前会话 = `cn:deepseek-v4.1-flash`，走自定义渠道（billing_base_url 反查 → 腾白嫖线路）；已实际调用 8 次、最近一次即当下 → 真实生效；
2. 全局默认未动（`gemini-3.8-flash-high` / `custom:反重力`）→ 属会话级切换；
3. 诚实边界：模型 ID 是路由标识，能核验的是配置与计费/用量记录，不能自证底层权重；
4. 反问是否把全局默认一起切换。

## 线路反查与命名坑

- `billing_provider` 常只显示 `custom`（不带线路名）→ 必须用 `billing_base_url` 对 config.yaml `custom_providers[].base_url` 找线路名。本次 `https://capy.<PRIVATE_IDENTIFIER>:2087/v1` → 「腾白嫖」。
- 腾白嫖线路模型带前缀命名：`cn:deepseek-v4.1-flash` / `global:deepseek-v4.1-flash` / `cn:step-5-preview` / `global:hy3` 等。**`cn:`/`global:` 是上游线路选择前缀，不是 provider 名**；Hermes 侧该模型所属 provider 仍是「腾白嫖」。
- 汇报给用户（含 CLI/群聊）时不要打印 provider 内部 host:port 与密钥，只报 **provider 名 + 模型 ID**；时间统一换算成北京时间。

## 常见误判

- ❌ 拿 `sessions.model` 列报当前模型（会话级切换后是旧值）；
- ❌ 拿 config.yaml 的 `model.default` 报「本会话现在是什么」（那是全局默认）；
- ❌ 只因为收到切换 note 就报「已切换生效」——必须有 `session_model_usage` 的真实调用记录。
