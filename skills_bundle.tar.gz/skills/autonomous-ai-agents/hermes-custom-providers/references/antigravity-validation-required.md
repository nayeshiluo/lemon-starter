# Antigravity (Gemini Code Assist) `VALIDATION_REQUIRED` 账号验证排障

CLIProxyAPI 的 gemini 通道走的是 Google「Gemini Code Assist (antigravity)」OAuth，
而非 Gemini AI Studio API key。它有一个与 token 无关的账号级风控错误，极容易误判。

## 错误现象与定性

调用 `POST /v1/chat/completions`（本地 8317 网关）返回：

```json
{"error":{"code":403,"message":"Verify your account to continue.",
 "status":"PERMISSION_DENIED",
 "details":[{"reason":"VALIDATION_REQUIRED","domain":"cloudcode-pa.googleapis.com",
   "metadata":{"validation_url":"https://accounts.google.com/signin/continue?...&plt=...",
   "validation_error_message":"Verify your account to continue."}}]}}
```

**定性（官方资料确认，2026 年普遍问题）**：
- `VALIDATION_REQUIRED` = **账号级安全验证未完成**，`cloudcode-pa.googleapis.com` 返回。
- **不是 token 问题**：`tokeninfo` 端点验 access_token 依然有效、`refresh_token` 也完好。
- **不是项目级问题**：与 billing / permissions / project_id 无关。
- 关键区分：重新 OAuth 授权**成功后仍报 VALIDATION_REQUIRED** → 说明账号本身被 Google
  风控连坐（常见诱因：同设备/同网络/同支付方式关联的另一个账号被封，如「大号被封 → 小号连坐」）。

## 诊断顺序（避免误判）

1. `GET /v1/models` 正常返回模型列表、但 `chat/completions` 报 VALIDATION_REQUIRED →
   是账号验证，不是网关挂了。
2. 验 token 是否真的有效（排除「小号掉了」的误判）：
   ```python
   # tokeninfo 验证 access_token
   urllib.request.urlopen(f'https://oauth2.googleapis.com/tokeninfo?access_token={at}')
   # 返回 email + expires_in > 0 → token 健康，问题在账号验证
   ```
3. 网关日志 `~/.cli-proxy-api/logs/error-v1-chat-completions-*.log` 里
   `Auth: provider=antigravity, auth_id=antigravity-<email>.json, label=<email>` 确认网关实际在用小号。

## 网关状态机陷阱：VALIDATION_REQUIRED → auth_unavailable

网关进程在后台尝试刷新 token 失败后，会把该账号标记为不可用，后续请求从
`VALIDATION_REQUIRED` 变成 `503 auth_unavailable: no auth available (providers=antigravity)`。
此时 `systemctl restart cliproxyapi` 可恢复识别（但验证问题仍在，需先解决验证）。

## 死循环陷阱（必踩）：agent 自己在网关里思考会顶掉验证链接

`validation_url` 里的 `plt` 参数是**绑定当前 access_token 的一次性令牌**。如果 agent 的
**默认模型本身就配在 gemini-proxy 网关**（即 `model.provider: custom:gemini-proxy`），那么
agent 每回复一条消息就会向网关发一次 gemini 请求，Google 就生成一条新的 plt —— 把用户
正在点的那条验证链接顶掉。用户反复点都报「出了点问题，无法验证您的信息」。

**解法：先切走默认模型，再让用户验证。**
```bash
hermes config set model.provider nofx          # 或任何非网关 provider
hermes config set model.default gpt-5.6-sol
```
切走后 agent 不再打网关，plt 稳定，用户才能一次性验证通过。**在用户验证完成前不要对网关发任何 chat 请求。**

## 重新 OAuth 授权（免 SSH 隧道，手动粘贴回调）

plt 链接点不开/反复失败时，正解是重新走一遍 OAuth（`access_type=offline` + `prompt=consent`
会拿全新 refresh_token）：

```bash
cd /home/ubuntu/cliproxyapi
./cli-proxy-api -config /home/ubuntu/cliproxyapi/config.yaml \
  -antigravity-login -no-browser -oauth-callback-port 18317
```

- 进程打印 OAuth 授权 URL（`accounts.google.com/o/oauth2/v2/auth?...`）并停在
  `Waiting for antigravity authentication callback...` / `Paste the antigravity callback URL`。
- **无需 SSH 隧道**：用户在自己浏览器打开授权 URL → 登录目标账号 → 点允许 →
  浏览器跳到 `http://localhost:18317/oauth-callback?code=...&state=...&scope=...`（打不开是正常的）。
- 用户把地址栏完整 URL 复制回给 agent，agent 用 `process(action='submit')` 粘贴给进程，
  进程自动 `code → token` 交换并写回 `~/.cli-proxy-api/antigravity-<email>.json`。
- 成功输出：`Antigravity authentication successful` / `Authenticated as <email>`。

**注意**：`-config` 必须用绝对路径；不带 `-config` 会报 `open /home/ubuntu/config.yaml: no such file or directory`。
启动要用 `terminal(background=true)`，因为进程要长驻等待回调，不能前台跑。

## 提取 antigravity 内置 client_secret（用于手动刷新/验证）

网关二进制里内置了 antigravity 官方 OAuth client 的 secret：

```bash
strings -n 20 /home/ubuntu/cliproxyapi/cli-proxy-api | grep -iE "GOCSPX-|client_secret"
# 命中形如 GOCSPX-<32字符>；client_id 见授权 URL 里的 client_id= 参数
```

## 授权成功后仍 VALIDATION_REQUIRED 的两条出路

1. **治本**：让用户登录 `https://myaccount.google.com/security`，补全安全验证
   （手机号绑定、两步验证），处理黄色/红色警告条后重新 OAuth 一次。
   ⚠️ 2026-09-09 实测：即使补全安全验证 + 重新 OAuth 授权成功（拿到全新 refresh_token），
   调用仍报 VALIDATION_REQUIRED —— 被拦截的是**接入方式**，不是 token。别再让用户卡在这条路上。
2. **绕开（正解）**：直接用 Gemini AI Studio 官方 **API key** 配官方 provider，
   完全不走 antigravity OAuth。⚠️ 新 key 前缀是 **`AQ.`**（不是老文档说的 `AIza`），
   两者都算官方 key。完整流程见 `references/google-official-gemini-provider.md`。
   注意 `.env` 里的 `GEMINI_API_KEY=798dc84f...` 是网关自己的 key、不是 AI Studio key，别混淆。

## ⚠️ 为什么不要再走 antigravity（2026-09-09 最终结论）

- Antigravity（Gemini Code Assist）**服务条款明确禁止第三方工具通过 Antigravity 访问服务**；
  Google 2026-06-18 起终止个人账号的 Gemini CLI 登录（官方仓库 google-gemini/gemini-cli
  与 OpenClaw docs 实证）。用 CLIProxyAPI 网关走 antigravity OAuth = **违规接入**。
- 本机大号 `zjw100802062` 正是因此被封（2026-09-09），小号被风控连坐：
  重授权/补安全验证都无法解除 VALIDATION_REQUIRED。
- **正解 = 删除反重力网关、改用官方 API key**（删除清单见 google-official-gemini-provider.md 末尾）。
