# True-SOTA 通道（true-sota.com）实测与模型清单

## 端点基本信息
- **Base URL**: `https://true-sota.com/v1`
- **WAF / Cloudflare 特性**: Cloudflare 会拦截默认 Python `urllib` UA（报错 `HTTP 403 - error code: 1010`）。需注入标准 `User-Agent`（如 `Mozilla/5.0` 或 `curl/7.81.0` 或 `OpenAI/Python`）。
- **注册名称**: `turesota`
- **默认模型**: `gpt-5.6`

## 状态变迁记录（2026-09-04 巡检）
- **当前状态**：❌ **整通道停用（HTTP 403 GROUP_DISABLED）**。
- **报错详情**：`{"code":"GROUP_DISABLED","message":"API Key 所属分组已停用"}`。
- **结论**：上游服务商在后台停用了该 API Key 所属的用户分组，全部 13 个模型均无法调用。需更换有效 Key 或从 `custom_providers` 移除。

## 模型可用性实测（历史归档 2026-08-20 实测）

### 可用模型（Chat Completions 正常）
- `gpt-5.6`
- `gpt-5.6-sol`
- `gpt-5.6-terra`
- `gpt-5.5`
- `gpt-5.4`
- `gpt-5.4-2026-03-05`
- `gpt-5.4-mini`
- `codex-auto-review`

### 不可用 / 异常模型
- `gpt-4o-audio-preview`（HTTP 502 上游网关错误）
- `gpt-4o-realtime-preview`（HTTP 502 上游网关错误）
- `gpt-image-1` / `gpt-image-1.5` / `gpt-image-2`（非 ChatCompletions 接口，不可用于文本对话）
