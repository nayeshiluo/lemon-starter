# 跨 Provider 同名模型冲突矩阵

适用：多个 `custom_providers` 条目的 `models` 列表包含相同模型 ID 时，Hermes 裸调路由规则与风险。

## 路由规则

裸调（不带 `custom:XXX` 前缀）时，Hermes 按 `custom_providers` 数组**首次出现的顺序**路由，后面同名的 provider 被遮蔽。遮蔽是静默的——没有警告，日志里只能看到最终命中的 provider。

## 已知冲突（2026-10-26 实测，各 provider 的 config.yaml index）

| 模型 ID | 冲突 provider | 裸调实际走哪里 | 风险 | 处置建议 |
|---|---|---|---|---|
| `claude-sonnet-4-6` | 反重力 (idx 1) vs 哄哄 (idx 7) | **反重力（3p 组）** | 🔴 高 | 3p 组按 token 成本扣减，兜底时整段上下文重发会无感烧穿周额度（实测 50 次调用 517 万 input token）；要走哄哄须加 `custom:哄哄` 前缀，或从反重力 models 列表删除 `claude-sonnet-4-6` |
| `gpt-5.6-luna` | 反重力 (idx 1) vs 滴滴滴 (idx 4) | **反重力（3p 组）** | 🔴 高 | 裸调耗 3p 额度；要走滴滴滴须 `custom:滴滴滴` |
| `gpt-6-luna` | 反重力 (idx 1) vs 滴滴滴 (idx 4) | **反重力（3p 组）** | 🔴 高 | 同上 |
| `gemini-3.1-flash-lite` | 反重力 (idx 1) vs NewFouAPI (idx 2) | 反重力（Gemini 组） | 🟡 低 | Gemini 组额度充裕（98%+），不影响使用；要省 Gemini 配额用 `custom:NewFouAPI` |
| `deepseek-v4-pro` | 官方 deepseek.com (idx 0) vs 哄哄 (idx 7) | 官方 deepseek.com | 🟢 无 | 两家底层相同，只是计费入口不同 |

注：index 随 config.yaml 增删 provider 而变，上表以 2026-10-26 实测为准，后续增删后须重新核对。

## 排查方法

```python
import re, collections
call = re.compile(r"API call #\d+: model=(\S+) provider=(\S+) in=(\d+)")
agg = collections.defaultdict(lambda: [0, 0])
for l in open("/home/ubuntu/.hermes/logs/agent.log", errors="replace"):
    m = call.search(l)
    if not m: continue
    mdl, prov, i = m.group(1), m.group(2), int(m.group(3))
    agg[(prov, mdl)][0] += 1; agg[(prov, mdl)][1] += i
for k, v in sorted(agg.items(), key=lambda x: -x[1][1]):
    print(f"{v[0]:4d} calls  in={v[1]:>10,}  {k[0]} / {k[1]}")
```

按 `(provider, model)` 分组后，如果发现意料外的 provider 路由，对照上表判断是哪个冲突导致的。

## 处置原则

1. **调整 config.yaml 中的顺序**：让想优先使用的 provider 的 index 更小。
2. **从先命中的 provider 的 `models` 列表中删除该 ID**：裸调就会落到下一个声明该 ID 的 provider。
3. **调用时显式加 `custom:XXX` 前缀**：不改配置，每次调用时手动指定。

## 铁律

把按 token 成本计费的付费模型组（如反重力 3p 组：`claude-*`/`gpt-*`/`gpt-oss-*`）暴露为同名 ID 后，它会在 fallback 兜底时被无感消耗。兜底 `fallback_providers` 的首选项**必须**选额度充足或免费的通道，不能是付费组。

## 与 fallback_providers 的关系

`fallback_providers` 里的模型与 `custom_providers` 遮蔽规则无关——fallback 链按条目的 `base_url`+`model`+`key_env` 直接打特定端点，不经过 custom_providers 的路由查表。但 `fallback_providers` 里如果写的是付费组的模型，同样会在主模型抖动时无感消耗（2026-10-26 教训：把 `claude-sonnet-4-6` 放在 fallback[0] 导致 517 万 input token 静默消耗）。
