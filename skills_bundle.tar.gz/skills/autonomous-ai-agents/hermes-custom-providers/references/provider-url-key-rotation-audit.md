# 「换 url + 换 key，全站同步」的只读盘点流程（2026-11-14 实测，周三 / ikun → token.thxnk.cc）

用户原话：「周三的 url 改成 https://token.thxnk.cc/v1  密钥我也要同步换掉 所有涉及到这个模型商的都同步换掉」。

## 结论先行：先盘点，再判断到底缺什么

本次实际状态与用户描述**不一致**：URL 早在上一轮迁移（2026-11-10）就已全部指向新站，
真正的缺口只有 **key 还是旧的**（新站 `/v1/models` 回 `Invalid token`）。
如果一上来就「按指示改 url」，会改出一堆无意义的 diff，还会把「URL 已达标 / key 已死」这个真问题掩盖掉。

**纪律：这类请求第一步永远是只读盘点 + 现状判定，把结论先回报，只在确实缺输入（新 key）时向用户索要，不动任何文件。**

## 落点盘点（周三 provider，naye 本机）

真实活引用只有 4 处，全部靠同一个环境变量供 key，所以 **key 只需改一处**：

| # | 位置 | 字段 | 说明 |
|---|---|---|---|
| 1 | `~/.hermes/config.yaml` `custom_providers[]` → `name: 周三` | `base_url` + `key_env: IKUN_API_KEY` | 注意 `models` 列表（Deepseek v4.1 Flash / Flux / GLM 5.3） |
| 2 | `~/.hermes/config.yaml` `fallback_providers[]` 同名条目 | `base_url` + `key_env` | **同一 provider 的第二份副本**，改漏就只改了菜单没改兜底 |
| 3 | `~/.hermes/.env` | `IKUN_API_KEY=` | 唯一密钥源，所有消费方都读它 |
| 4 | `/home/ubuntu/lemon-group-bot/data/ai_endpoints.json` → `zhousan` | `url` 带 `/chat/completions` 后缀 + `key_env` | 群霸端点池 |
| 5 | `/home/ubuntu/smart-group-bot/seed_models.py` | `os.environ.get("IKUN_API_KEY")` + `api_base` | 种子脚本 |

**跨机核对结果：`vps-la` / `vps-hk` / `aliyun` / `diaomao` 全部为 0 引用**（`dshlab` 别名指向 InstaBox，BatchMode 下 publickey 拒绝，属正常）。
vps-la 上 grep 到的 `thxnk` 命中全是**无关同名域名**：`/opt/emby-rules-portal/data/emby-direct.list` 的 `DOMAIN-SUFFIX,thxnk.cc`（Emby 直连规则）与
`/opt/telebox-test/app/assets/fbi/cache.json` 里的聊天缓存文本；`周三` 命中全是 dayjs 的 `zh-cn` locale 和 emby 备份。
→ **别把同名域名/中文词命中当成 provider 引用**，逐条看上下文再定。

## 盘点命令（只读，带噪声过滤）

```bash
# 本机：按 provider 域名 / key_env 名 / 中文别名三路搜，排除历史与产物目录
grep -rIl -E 'thxnk|IKUN_API_KEY|周三' /home/ubuntu \
  --include='*.json' --include='*.yaml' --include='*.yml' --include='*.py' \
  --include='*.js' --include='*.sh' --include='*.toml' --include='*.env' \
  --exclude-dir=.hermes --exclude-dir=node_modules --exclude-dir=.cache \
  --exclude-dir=.git --exclude-dir=venv --exclude-dir=.venv 2>/dev/null

# 再看 .hermes 自己（config + .env）
grep -n -i -E 'thxnk|IKUN|周三' ~/.hermes/config.yaml

# .env 里所有 key 名（只看名字，不打印值）
grep -oE '^[A-Z0-9_]+' ~/.hermes/.env | tr '\n' ' '

# 其他主机
for H in vps-la vps-hk aliyun diaomao; do
  ssh -o BatchMode=yes -o ConnectTimeout=8 $H \
    "grep -rIl -E 'thxnk|IKUN_API_KEY' /opt /root /home /etc 2>/dev/null \
     | grep -v -E 'node_modules|/\\.git/|backup|cache' | head -10"
done
```

**已知噪声，必须排除**：`/home/ubuntu/artex/data/tasks/**`（几十份 xboard 前端产物，含 `thxnk` 字样）、
`**/backups/**`、`*.bak-*`、`.codex/shell_snapshots/`、`~/.hermes/public-skills-candidates/`、
`~/.hermes/cache/`、`profile-member-index-*/`。
不过滤会得到 50+ 条假命中，把真落点淹掉。

## 探测纪律（本次踩到的两个坑）

1. **不要 `set -a; . ~/.hermes/.env; set +a` 之后再 curl**：整份 `.env` 灌进 shell 会带入
   `*_PROXY` / 各类无关变量，本次两条 curl 全部 `000`（25s + 45s 全超时），白烧 70 秒。
   正确做法：**只取目标那一个 key**，
   ```bash
   K=$(grep -m1 '^IKUN_API_KEY=' /home/ubuntu/.hermes/.env | cut -d= -f2- | tr -d '"'"'"'"')
   ```
2. **`/v1/models` 与 `/chat/completions` 的鉴权结论可能不一致，两个都要打、分开报**：
   本次同一把旧 key，`/v1/models` → `401 {"type":"new_api_error","message":"Invalid token"}`，
   而 `/chat/completions` 仍返回了正文（且 `model` 字段是 `GLM 5.3`，与请求的 `Deepseek v4.1 Flash` 不符）。
   → 只打一个端点就下「key 废了」或「key 好的」结论都不稳；汇报时把
   「端点可达性 / models 鉴权 / 真实 chat」三行分开写，并注明 chat 返回的 model 与请求不一致这个异常。

## 汇报模板（本次使用的口径）

1. 结论先行：URL 已全部是 `https://token.thxnk.cc/v1`，无遗漏点（列 4 处）。
2. 唯一真缺口：key 还是旧的（附实测 `Invalid token` 证据）。
3. 改动面：「把新 key 发我，我改 `.env` 一处全场生效」——说明**为什么一处够**（5 个引用点全走 `key_env`）。
4. 承诺验收：改完实测 `/v1/models` + 一次真实对话，再回结果。

用户没给新 key 之前**不要**先改 URL、不要猜 key、不要反复索要；一次问清即可。

---

# 二段：拿到新 key 后的执行、生效范围与验收（同场实测，models_http=200 之后）

## 1. 用户只有 root 时的最小可粘贴配方（本次一次成功）

```bash
cd /home/ubuntu
cp -a .hermes/.env .hermes/.env.bak-$(date +%F)
read -rsp "粘贴新的 IKUN key: " K; echo
sed -i "s|^IKUN_API_KEY=.*|IKUN_API_KEY=$K|" .hermes/.env
chown ubuntu:ubuntu .hermes/.env && chmod 600 .hermes/.env
set -a; . .hermes/.env; set +a
curl -sS -o /dev/null -w "models_http=%{http_code}\n" --max-time 25 \
  https://token.thxnk.cc/v1/models -H "Authorization: Bearer $IKUN_API_KEY"
```

- `read -rsp` 不落 shell 历史、不回显；让用户**只回 `models_http=` 那一行**，不要贴 key。
- `chown ubuntu:ubuntu` + `chmod 600` 是 root 跑完的必做项，否则服务账号后续写 `.env` 会权限失败。
- `sed` 对 51 位 alnum 的 `sk-` key 安全；**key 含 `|`、`&`、`\` 时换 python lambda 替换**
  （见 `secret-env-write-handoff.md`），不要赌。
- 用户说「我只有 root」时直接给这套，不用再劝换账号——加上 chown 即等价。

## 2. 生效范围判定：谁要重启，谁不用（本次实测结论）

| 消费方 | `key_env` 解析方式 | 改 `.env` 后 |
|---|---|---|
| 群霸 `lemon-group-bot`（`services/ai_service.py:_read_env_val()`） | 每次调用：`os.getenv` 优先，回落逐行读 `/home/ubuntu/.hermes/.env` | **热生效，不用重启** |
| `lemon-ops-bot`（`main.py:_resolve_pool_key()`） | 同上，`os.environ` → `.env` 文件 | **热生效，不用重启** |
| Hermes 自身（`config.yaml` 的 `key_env`） | 启动时 dotenv 灌进进程内存 | **必须 `systemctl restart hermes-gateway`** |

踩过的两个取证陷阱：

- **`/proc/<pid>/environ` 里查不到 `IKUN_API_KEY` 是正常的**，dotenv 注入不进 exec 环境。
  本次据此误判「key 没生效」，实际 `.env` 与进程内都是新值。判定只能靠源码解析方式 + 真实调用。
- **`pgrep -f 'hermes_cli.main gateway run'` 会匹配到你自己的 shell 命令行**（命令文本里含这个字符串），
  本次一度看到两个 PID 一个 `key=NEW` 一个 `OLD`，全是假象。取真进程用
  `systemctl show hermes-gateway.service -p MainPID --value`。

## 3. 四层验收阶梯（逐层打勾，别跳层）

1. `GET /v1/models` → `200`，并数出模型数（本次 3 个：`Deepseek v4.1 Flash` / `Flux` / `GLM 5.3`）。
2. 真实 `/chat/completions`，**`max_tokens` ≥ 200**。本次 `max_tokens=8` 时 `content=''`（全被
   `reasoning_content` 吃掉，`usage` 正常返回），提到 200 才出 `收到`。
3. Hermes 层全链（验 provider 解析 + key_env 取值，curl 覆盖不到）：
   ```bash
   ~/.hermes/hermes-agent/venv/bin/python -m hermes_cli.main \
     -z '只回复两个字：收到' -m 'Deepseek v4.1 Flash' --provider 周三 -t ''
   ```
   实测 5.7s 输出 `收到`。
4. `systemctl is-active hermes-gateway` = `active` + 近 3 分钟日志无 traceback。
   注意重启瞬间日志里会残留旧进程退出前打的 `Switched to fallback model: ...`，那是历史行，不是新故障。

跨机/无关键路径一并报清楚：vps-la / vps-hk / aliyun / diaomao 零引用；dshlab 走的是 dsh 不经该 provider，
SSH 不通不影响结论——**不要因为一台连不上就说「可能还有遗漏」**，先确认那台跑的是什么。

## 4. 收尾口径

列「改了什么 / 本来就不用改的 / 实测证据 / 没重启的及原因 / 排除的范围」五段，
最后一句给出模型清单变化（本次顺带把「周三 2 模型」纠正为实际 3 个）。别只说「都换好了」。

