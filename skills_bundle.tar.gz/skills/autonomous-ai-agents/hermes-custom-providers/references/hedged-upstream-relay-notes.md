# 帝（ai.di0.uk）中转实测 + 「对冲上游」型聚合站的探测方法

2026-11-08 实测。用户给 key + `https://ai.di0.uk`，要求「试一下能不能用 → 加进去，命名 帝」。

## 端点特征

- New API 系面板，`/v1/models` 返回 9 个模型，`created` 全部伪造为 `<YOUR_USER_IDENTIFIER>`（无信息量，别拿来判断新旧）。
- **错误文案 `{"error":{"message":"All hedged upstream requests failed","type":"upstream_error"}}`（HTTP 502）**
  是「多上游对冲」写法：请求同时打多个上游、全灭才报这个。含义 = 该模型在该时刻**没有可用上游**，
  既不是 key 问题、也不是模型名写错。判定规则：串行间隔 ≥2s 重试一次；仍 502 就是线路级故障，该模型不注册。
- `/api/user/self` 返回 `401 AUTH_UNAUTHORIZED invalid access token` —— 该 key **只有对话权限**，
  查不到余额/额度。这不是 key 无效（同一个 key 聊天 200），是 New API 的子令牌没给面板权限。
  汇报时明确说「额度未知」，不要编额度，也不要因为 401 就判整条线路废。

## 实测矩阵（同一 key，串行，间隔 2–3s）

| 模型 | 结果 |
|---|---|
| `glm-5.3-flash` | ✅ 200，2.5–4.1s，3 连测稳定，流式有 |
| `glm-5.3` | ✅ 200，带 `reasoning_content`（reasoning_tokens 141） |
| `deepseek-v4-flash-0731` / `deepseek-v4-pro-0813` | ❌ 502 hedged upstream（重试仍 502） |
| `kimi-k3` / `minimax-m3` / `mistral-large-2-instruct` | ❌ 502 同上 |
| `gemma-4-31b-it` / `gpt-oss-20b` | ❌ 完全无响应：90s 无字节、curl exit code 000 |

结论：9 个里只有 2 个 GLM 是活的，一半以上上游已断。当廉价备用池可以，主力别指望。

## 两条探测纪律（本次踩到）

1. **挂死模型会吃掉整批时间预算**。`gemma-4-31b-it` / `gpt-oss-20b` 不返回、不报错、不 RST，
   `curl -m 90` 也照样干等到 90s，串行跑就会撞 180s 命令超时，前面拿到的结果一起丢。
   → 每个请求都套 `timeout 30 curl -m 25 ...`，双保险；批量探测优先用
   `scripts/probe_models_concurrent.py`（ThreadPoolExecutor + 单请求超时）。
2. **流式测试最容易被挂住**：`-m 60` 的流式请求在首块后可能长时间不再发数据，整个命令仍被外层 timeout 掐断（exit 124）。
   → 流式只用来验「有没有 + 首块时间」，外面再包一层 `timeout 25`。

## 注册结果（已落地）

```yaml
- name: 帝
  base_url: https://ai.di0.uk/v1
  key_env: DI_API_KEY
  model: glm-5.3-flash
  api_mode: chat_completions
  models: [glm-5.3-flash, glm-5.3]
```

- key 进 `~/.hermes/.env` 的 `DI_API_KEY`，不落 config.yaml。
- 只注册实测活的两个；死模型**不进 `models`** —— 否则 `/model` 能选、选了必 502，每次烧 2 次重试再回退，还会连带打挂 auxiliary（vision/title）。
- provider 名是单个汉字 `帝`，`hermes chat -q --provider 帝 -m glm-5.3-flash` 实测正常，中文短名没有解析问题。
- 验收三层全过：`hermes chat` 真调用返「帝已接入」、`/model` 菜单显示「帝 (2 个模型)」、☰ 菜单 60 条含 `/model`。
