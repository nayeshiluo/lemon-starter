# Key Sync Session — web-ui 401 / api_server refused to start

Real-world fix transcript (2026-08-12). Symptom chain that led to the two-location key rule.

## Symptom 1: gateway api_server refused to start
gateway.log:
```
ERROR gateway.platforms.api_server: [Api_Server] Refusing to start: API_SERVER_KEY is required for the API server, including loopback-only binds on 127.0.0.1.
WARNING gateway.run: ✗ api_server failed to connect
```
config.yaml at the time:
```yaml
platforms:
  api_server:
    extra:
      port: 8642
      host: 127.0.0.1
    enabled: true
    key: ''          # <-- empty key = hard refusal
    cors_origins: '*'
```
First fix: `hermes config set platforms.api_server.key "$KEY"` → gateway started,
`✓ api_server connected`, LISTEN on 127.0.0.1:8642. But panel still failed.

## Symptom 2: panel 401 after gateway was healthy
Panel showed:
```
Error: API Error 401: {"error": {"message": "Invalid gateway API key (API_SERVER_KEY)", "type": "gateway_auth_error", "code": "gateway_auth_failed"}}
```
Root cause: web-ui BFF reads the key from `.env`, gateway read it from config.yaml.
`.env` had NO `API_SERVER_KEY` entry → BFF sent no/old key → 401.

Second fix: append `API_SERVER_KEY=$KEY` to `~/.hermes/.env`. No panel restart needed
(BFF reads the file per request). Verification: correct key → 200 on /v1/models,
wrong key → 401.

## web-ui source locations (v0.4.0-era, /usr/lib/node_modules/hermes-web-ui/dist)
- `services/hermes/gateway-manager.js` `getApiKey(profileName)` (~line 279):
  reads `<profileDir>/.env`, regex `^API_SERVER_KEY\s*=\s*"?([^"\n]+)"?` per call — NOT cached.
- `services/hermes/gateway-manager.js` `writeProfilePort()` (~line 190-210):
  rewrites config.yaml api_server section and sets `key = ''` — can blank a config-only key.
- `routes/hermes/proxy-handler.js` (~line 75): `mgr.getApiKey(profile)` attaches the key to proxied requests.
- README architecture line: `Browser → BFF (Koa, :8648) → Hermes Gateway (:8642)`.

## gateway source (hermes-agent repo)
`gateway/platforms/api_server.py` ~line 1382:
```python
self._api_key: str = extra.get("key", _get_scoped_secret("API_SERVER_KEY", ""))
```
So config key wins if non-empty; empty/missing falls back to the API_SERVER_KEY
scoped secret (from .env) — which is why the .env copy survives GatewayManager rewrites.

## Linger / auto-restart caveat
web-ui server.log when it tried to manage the gateway itself:
```
[GatewayManager] gateway restart output: ⚠ Cannot restart gateway as a service — linger is not enabled.
[GatewayManager] ✗ default: failed to start — Gateway health check timed out after 15000ms
```
Fix on headless servers: `sudo loginctl enable-linger <user>` if you want web-ui to
manage the gateway, otherwise restart manually (kill + relaunch `hermes gateway`).

## Config key path gotcha (real mistake made during fix)
`hermes config set api_server.key X` writes a TOP-LEVEL `api_server:` block — the CLI
warns "not a recognized config key" and suggests `mcp_servers.key`. Correct path is
`platforms.api_server.key`. Stray top-level entry removed with
`hermes config unset api_server.key`.

## Useful probes
```bash
ss -tlnp | grep 8642                      # gateway API listening?
grep -E "api_server|Refusing" ~/.hermes/logs/gateway.log | tail -5   # connect status
curl -s -o /dev/null -w "%{http_code}\n" -H "Authorization: Bearer $KEY" http://127.0.0.1:8642/v1/models  # 200
curl -s -o /dev/null -w "%{http_code}\n" -H "Authorization: Bearer wrong" http://127.0.0.1:8642/v1/models # 401
```
