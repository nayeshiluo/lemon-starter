---
name: hermes-gateway-api-server
description: "用于 Hermes web-ui 401 或网关 api_server 故障时"
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [hermes, gateway, web-ui, api-server, troubleshooting, 401, auth]
---

# Hermes Gateway API Server & Web-UI Panel Connectivity

## When to use
- Hermes web-ui panel (hermes-web-ui, default :8648) shows `Error: API Error 401: Invalid gateway API key (API_SERVER_KEY)` or similar auth failures.
- Gateway log shows `[Api_Server] Refusing to start: API_SERVER_KEY is required` and/or `✗ api_server failed to connect`.
- You configured an api_server key but the panel still cannot talk to the gateway, or the gateway API server is not listening.

## Architecture (read this first)
Browser → web-ui BFF (Koa, :8648) → Hermes Gateway API (:8642)

- The gateway `api_server` platform (default 127.0.0.1:8642) authenticates every request with a bearer key.
- The web-ui BFF proxies browser requests to the gateway and attaches that key to each proxied call.

## THE key rule: two locations must hold the SAME key
1. `config.yaml` → `platforms.api_server.key` — read by the gateway process at startup.
2. `~/.hermes/.env` → `API_SERVER_KEY=...` — read by the web-ui BFF on EVERY request (`getApiKey()` regexes the .env file; it does NOT cache).

If they differ, or `.env` lacks the variable, the panel gets 401 `Invalid gateway API key (API_SERVER_KEY)` even while the gateway itself is perfectly healthy. The 401 message names the env var because that is the web-ui's lookup source, not necessarily where the gateway got its key.

## Fix steps (proven sequence)
1. Generate a key: `KEY=$(python3 -c "import secrets; print(secrets.token_urlsafe(32))")`
2. Write to config with the CORRECT dotted path:
   `hermes config set platforms.api_server.key "$KEY"`
   (see pitfall 1 — `api_server.key` alone writes to the wrong place)
3. Append to .env: `printf '\nAPI_SERVER_KEY=%s\n' "$KEY" >> ~/.hermes/.env`
4. Restart the gateway (below).
5. Verify with a protected endpoint (below).
6. The panel needs NO restart — the BFF re-reads .env per request.

## Gateway restart (headless server, no systemd service)
- With `loginctl show-user <user> | grep Linger` = no, there is no user service; web-ui's own "start/restart gateway" fails with a linger warning and a 15s health-check timeout. Do it manually.
- Manual restart: kill the `hermes gateway` process (`ps aux | grep "hermes gateway"`), then relaunch it in background (e.g. terminal background).
- Confirm success: `ss -tlnp | grep 8642` shows LISTEN, and gateway.log shows `✓ api_server connected` (previously `✗ api_server failed to connect`).

## Verification (auth actually enforced)
- `/health` is PUBLIC — returns 200 even without any key. It is NOT a valid auth test.
- Use a protected endpoint, e.g. `GET /v1/models`:
  - correct key → `curl -s -o /dev/null -w "%{http_code}" -H "Authorization: Bearer $KEY" http://127.0.0.1:8642/v1/models` → 200
  - wrong key → same curl with `Bearer wrong-key` → 401 (proves the key check is live and your key is accepted)

## Pitfalls
1. `hermes config set api_server.key X` writes a TOP-LEVEL custom key — wrong location. The CLI even warns "not a recognized config key" and suggests unrelated keys. The schema path is `platforms.api_server.key` (inside the `platforms:` section). Clean up any stray top-level entry with `hermes config unset api_server.key`.
2. web-ui's GatewayManager rewrites the api_server section of config.yaml on port resolution / restart attempts (it can set `key = ''`). A config-only key can be silently blanked → gateway refuses to start. Keeping the key in `.env` (API_SERVER_KEY) survives this because the gateway falls back to the scoped secret when the config key is empty.
3. Never hand-edit config.yaml (Hermes invariant) — always `hermes config set` with the correct dotted path.
4. web-ui's own "Auth enabled — token: <hex>" log line is the PAGE login token, unrelated to the gateway API key. Two separate auth layers; do not confuse them.
5. 用户报"面板打不开"但服务侧 curl 全通（8648 LISTEN、`127.0.0.1:8648` 200、公网 IP:8648 200）时，**先确认发给用户的地址带了 `#/?token=<hex>` 页面登录 token**——只发裸 `http://IP:8648` 会卡在登录页，现象就是"进不去"。token 在 `hermes-web-ui start` 启动输出或 `~/.hermes-web-ui/server.log`；`/api/health` 无 Bearer key 返回 401 是受保护端点正常行为，不是 key 失配。详见 hermes-gateway-ops 技能。（2026-08-14 实录）

## References
- `references/key-sync-session.md` — session detail: exact log lines, web-ui source locations (getApiKey regex, writeProfilePort key blanking), and the full fix transcript.
