#!/usr/bin/env bash
# 每日清理：内存与无用文件
# 保留 7 天 journal / 1 天 /tmp 媒体 / 3 天 Hermes 快照 / 7 天缓存；非 root 时跳过 drop_caches
set -uo pipefail

echo "🛠 每日清理 $(date '+%Y-%m-%d %H:%M:%S')"
echo ""
echo "📊 清理前状态："
df -h / | tail -1 | awk '{print "磁盘: 已用 "$5"（可用 "$4"）"}'
free -h | awk '/Mem:/{print "内存: 已用 "$3" / 共 "$2"（可用 "$7"）"}'
echo ""

# 1. /tmp 临时测试音视频及无用大文件（>1 天）与常规文件（>3 天）
find /tmp -maxdepth 1 -type f \( -name "*.mp3" -o -name "*.mp4" -o -name "*.m4a" -o -name "bench*" -o -name "tmp*" -o -name "test_*" \) -mtime +1 -delete 2>/dev/null || true
find /tmp -maxdepth 1 -name "*.session" -mtime +1 -delete 2>/dev/null || true
find /tmp -type f -mtime +3 -delete 2>/dev/null || true
find /tmp -type d -mtime +3 -empty -delete 2>/dev/null || true
echo "🧹 /tmp 临时文件与测试媒体已清理"

# 2. NPM 缓存（完全无用）
rm -rf "$HOME/.npm" 2>/dev/null || true
if [ "$(id -u)" = "0" ] || sudo -n true 2>/dev/null; then
  sudo rm -rf /root/.npm 2>/dev/null || true
fi
echo "🧹 NPM 缓存已清理"

# 3. Hermes 快照轮转（保留最近 3 份）
if [ -d "$HOME/backups" ]; then
  ls -dt "$HOME/backups"/hermes-* 2>/dev/null | tail -n +4 | xargs rm -rf 2>/dev/null || true
  echo "🧹 Hermes 历史快照已轮转（保留最近 3 份）"
fi

# 4. Hermes 音频缓存（>7 天）
if [ -d "$HOME/.hermes/audio_cache" ]; then
  find "$HOME/.hermes/audio_cache" -type f -mtime +7 -delete 2>/dev/null
  echo "🧹 Hermes 音频缓存已清理（>7 天）"
fi

# 5. 用户级缓存（>7 天）
if [ -d "$HOME/.cache" ]; then
  find "$HOME/.cache" -type f -mtime +7 -delete 2>/dev/null
  echo "🧹 ~/.cache 已清理（>7 天）"
fi

# 6. journal 日志（保留至 100M）
if command -v journalctl >/dev/null 2>&1; then
  if sudo -n journalctl --vacuum-size=100M >/dev/null 2>&1; then
    echo "🧹 journal 日志已压缩至 100M"
  else
    journalctl --vacuum-size=100M >/dev/null 2>&1 && echo "🧹 journal 日志已压缩至 100M" || true
  fi
fi

# 7. apt 缓存
if command -v apt-get >/dev/null 2>&1; then
  sudo -n apt-get clean >/dev/null 2>&1 || apt-get clean >/dev/null 2>&1 || true
  echo "🧹 apt 缓存已清理"
fi

# 8. SQLite 数据库轻量维护
python3 - <<'PYEOF' 2>/dev/null || true
import sqlite3, os
home = os.path.expanduser("~/.hermes")
dbs = ["kanban.db", "response_store.db"]
for db in dbs:
    p = os.path.join(home, db)
    if os.path.exists(p):
        try:
            conn = sqlite3.connect(p, timeout=10.0)
            conn.execute("PRAGMA wal_checkpoint(PASSIVE);")
            conn.execute("PRAGMA optimize;")
            conn.close()
        except Exception:
            pass
PYEOF
echo "🗄️ SQLite 辅助数据库维护完成"

# 9. 释放内存页面缓存（需 root）
if [ "$(id -u)" = "0" ]; then
  sync && echo 3 > /proc/sys/vm/drop_caches 2>/dev/null && echo "🧠 内存页面缓存已释放"
else
  echo "ℹ️ 非 root 用户，跳过 drop_caches（内存由系统自动回收）"
fi

echo ""
echo "📊 清理后状态："
df -h / | tail -1 | awk '{print "磁盘: 已用 "$5"（可用 "$4"）"}'
free -h | awk '/Mem:/{print "内存: 已用 "$3" / 共 "$2"（可用 "$7"）"}'
echo ""
echo "✅ 清理完成"
