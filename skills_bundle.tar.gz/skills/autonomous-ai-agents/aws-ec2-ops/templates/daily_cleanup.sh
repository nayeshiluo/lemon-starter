#!/usr/bin/env bash
# Conservative scheduled cleanup. Shared temp/session/cache/DB/backup data is out of scope.
set -Eeuo pipefail
trap 'rc=$?; echo "FAILED: daily cleanup (exit=$rc)" >&2; exit "$rc"' ERR
dry_run=0
if [ "$#" -gt 1 ]; then echo "FAILED: usage: daily_cleanup.sh [--dry-run]" >&2; exit 2; fi
case "${1:-}" in
  "") ;;
  --dry-run) dry_run=1 ;;
  *) echo "FAILED: unknown argument" >&2; exit 2 ;;
esac
echo "Daily cleanup $(date -u '+%Y-%m-%dT%H:%M:%SZ')"
df -h /
free -h
echo "SKIPPED: shared /tmp, Telethon sessions, npm/user/audio caches, snapshots, SQLite and drop_caches"
if [ "$dry_run" -eq 1 ]; then
  echo "DRY-RUN: would vacuum journal older than 7 days and clean APT package cache"
  echo "SUCCESS: dry-run completed; no cleanup performed"
  exit 0
fi
# Never prompt in a scheduled job. Missing tools or insufficient privileges must fail visibly.
command -v journalctl >/dev/null
command -v apt-get >/dev/null
if [ "$(id -u)" -eq 0 ]; then
  journalctl --vacuum-time=7d
  apt-get clean
else
  command -v sudo >/dev/null
  sudo -n journalctl --vacuum-time=7d
  sudo -n apt-get clean
fi
echo "SUCCESS: daily cleanup completed"
