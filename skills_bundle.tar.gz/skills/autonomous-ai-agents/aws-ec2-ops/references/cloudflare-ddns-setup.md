# AWS EC2 无弹性 IP 场景下的 Cloudflare DDNS 自动化配置

## 适用场景
AWS EC2 释放弹性 IP 避免每小时 $0.005 计费后，使用动态公网 IPv4 + Cloudflare 域名实现永久免费、免记 IP 直连 SSH 与管理。

## 关键机制
1. **IP 变化规则**：
   - 操作系统内 `sudo reboot` 或控制台 `Reboot`：公网 IP 不变。
   - 控制台 `Stop` ➔ `Start`：公网 IP 释放并重新分配。
2. **Cloudflare 关键要求**：
   - 必须配置为 `proxied: false`（DNS Only / 灰云直连），否则 CDN 只代理 HTTP(S) 流量，SSH（22 端口）及自定义端口无法连接。
   - TTL 设为 60 秒极速刷新。

## 架构组成与文件规范

### 1. 配置与脚本位置
目录：`/home/ubuntu/lemon-ddns/`

- **`config.json`**：
  ```json
  {
    "api_token": "<CF_API_TOKEN_WITH_ZONE_DNS_EDIT>",
    "zone_id": "<CF_ZONE_ID>",
    "domains": ["aws.yourdomain.com", "ec2.yourdomain.com"],
    "proxied": false,
    "ttl": 60
  }
  ```

- **`ddns.py`**：
  - 自动获取公网 IP（带多个 fallback：`api.ipify.org`, `icanhazip.com`, `ifconfig.me`, `checkip.amazonaws.com`）
  - 校验 Cloudflare A 记录，不存在则自动创建，存在且不一致则更新，一致则退出。

### 2. Systemd 自动保活服务与定时器
- `/etc/systemd/system/lemon-ddns.service`:
  ```ini
  [Unit]
  Description=Lemon Cloudflare DDNS Service
  After=network-online.target
  Wants=network-online.target

  [Service]
  Type=oneshot
  User=ubuntu
  ExecStart=/usr/bin/python3 /home/ubuntu/lemon-ddns/ddns.py
  StandardOutput=append:/home/ubuntu/lemon-ddns/ddns.log
  StandardError=append:/home/ubuntu/lemon-ddns/ddns.log

  [Install]
  WantedBy=multi-user.target
  ```

- `/etc/systemd/system/lemon-ddns.timer`:
  ```ini
  [Unit]
  Description=Run Lemon Cloudflare DDNS every 2 minutes
  After=network-online.target

  [Timer]
  OnBootSec=30s
  OnUnitActiveSec=2min
  AccuracySec=10s

  [Install]
  WantedBy=timers.target
  ```

- **启用指令**：
  ```bash
  sudo systemctl daemon-reload
  sudo systemctl enable --now lemon-ddns.timer
  sudo systemctl start lemon-ddns.service
  ```
