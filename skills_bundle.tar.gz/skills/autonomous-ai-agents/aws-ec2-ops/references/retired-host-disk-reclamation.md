# 退役旧机/DR 机的定位与磁盘回收（2026-11-05 实录）

整机迁移完成后，源机常被降级为 DR 或闲置，但**它往往不在任何常规运维入口里**：不在 `~/.ssh/config`、不在 `vps-healthcheck.sh`、不在日志汇总的采集清单。结果是磁盘一路涨到 87% 没人知道。

## 1. 定位：用户说"aws 那台机"指的是哪台

**不要用配置里的标签反推主机身份。** 本轮踩过的错：

| 错误推断 | 实际 |
|---|---|
| `digest.py` 里 `SOURCES['aws']` → 以为有台 AWS 机在采集 | `collect('aws', …)` 是**本地调用**，单元列表全是本机的 `hermes-gateway`/`cliproxyapi`/`lemon-group-bot` |
| `<YOUR_PRIVATE_DOMAIN>` / `<YOUR_PRIVATE_DOMAIN>` 指向 `<YOUR_SERVER_IP>` → 以为那是 AWS | `<YOUR_SERVER_IP>` 归属 **Leaseweb 新加坡 AS59253**，不是 AWS 网段；`aws`/`ec2` 只是历史域名沿用 |
| `~/.aws` 不存在、无 awscli → 以为没有 AWS 机 | 真实旧机是 `<YOUR_SERVER_IP>`（`ip-172-31-4-215`，ap-southeast-1） |

正确顺序：

1. 查 `~/.ssh/` 下有没有 `migration-*` 目录（本轮 `migration-greencloud-20261027/`）
2. 查 `/var/lib/hermes-migration/<date>/reverse-ssh/` —— 整机迁移反向 SSH 用的 key 和 pinned known_hosts 都在这里
3. 仍找不到就 `session_search` 迁移当天的会话，里面通常有完整 SSH 命令行与实例 IP
4. 最后才用 CF DNS / DDNS 配置交叉验证，且只当线索，不当结论

`known_hosts` 里是 hash 过的条目，`cut -f1` 只能看到 `|1|…=`，**读不出 IP**，别指望用它反查。

## 2. 接入退役机的固定命令形态

迁移 key 是 root-only，必须走 `sudo -n`：

```bash
K=/var/lib/hermes-migration/<YOUR_USER_IDENTIFIER>/reverse-ssh
sudo -n ssh -i $K/id_ed25519 \
  -o UserKnownHostsFile=$K/known_hosts \
  -o StrictHostKeyChecking=yes -o BatchMode=yes -o ConnectTimeout=12 \
  ubuntu@<YOUR_SERVER_IP> "bash -s" <<'EOF'
hostname; TZ=Asia/Shanghai date '+%F %T %Z'; uptime
df -h /; free -m | head -2
EOF
```

- `known_hosts` 只钉了那一台，`StrictHostKeyChecking=yes` 能防止连错机。
- 远端脚本用 `bash -s` + heredoc 传入，**不要把多行命令塞进 `ssh host "..."`**（引号地狱）。
- `hostname` 返回 `ip-172-31-4-215` 这类内网名，说明确实是 EC2；这也是确认身份的第一手证据。

## 3. 清理前的四档分类（DR 机专用）

DR 机的判据不是"业务停了吗"，而是"删了之后还能不能顶上来 / 还能不能回溯"。

| 档 | 内容 | 处置 |
|---|---|---|
| **唯一留存** | 目标机上没有对应副本的快照（本轮 `hermes-20261025_030012`） | **绝不删** |
| **取证材料** | `naye-recovery-*/forensics.tar.gz`、`*-report.json` | **绝不删**；时间戳本身是证据 |
| **回退资产** | `final-snapshots-<date>/`、`repository/`、迁移包 | 保留到旧机正式退役 |
| **可回收冗余** | 目标机已验证的重复快照、`.npm-global`、`/var/cache/apt`、旧 unified | 核对后删 |

### 冗余对账必须双向

删源机副本前，先在**目标机**上验证幸存副本：

```bash
for d in /home/ubuntu/backups/unified/20261026_034106 \
         /home/ubuntu/backups/unified/20261027_033004; do
  (cd "$d" && sha256sum -c SHA256SUMS 2>&1 | tail -3)
done
```

`sha256sum -c` 全 OK 之后才删源机那份。名字对得上不算证据，**哈希对得上才算**。

清单要两侧并列核对，只比目录名会漏掉"目标机没有的那一份"：

```
源机 unified: 20261026_034106, 20261027_033004
目标机 unified: 20261026_034106, 20261027_033004, 20261105_×5   → 源机两份可删
源机 hermes-*: <YOUR_USER_IDENTIFIER>, <YOUR_USER_IDENTIFIER>, <YOUR_USER_IDENTIFIER>
目标机 hermes-*: <YOUR_USER_IDENTIFIER>, <YOUR_USER_IDENTIFIER>, <YOUR_USER_IDENTIFIER>×3                 → 10-25 是唯一副本，留
```

## 4. 目录体积评估：不要用截断的列表下判断

本轮真实险情：`ls -la <dir> | head -6` 只看到 `cache/`、`maintenance-result.json`、`preservation.log`，据此判断"只剩 cache 可删"，`rm -rf cache` 之后 `find` 才暴露出 `repository/` **3.6 G** 和 `restore-check/` 640 M —— 差一步就把 restic 的回滚副本当成缓存删了。

规则：

- 评估体积一律用 `find <dir> -maxdepth 1 -mindepth 1 -exec du -sh {} \; | sort -rh`，**完整列，不截断**。
- `ls` 只用来确认"有没有这个文件"，不用来算总账。
- `du -sh $DIR/*` 在 root-only 目录下会被非 root shell 提前展开而静默失败（见 SKILL.md §6），必须 `sudo sh -c "du -sh $DIR/*"` 或改用上面的 `find`。

## 5. restic 维护副本的目录解剖

`~/backups/restic-before-staging-maintenance-<date>/` 这类目录是 restic 做 prune/维护**之前**打的完整副本：

```
repository/               ← 真身，维护前的完整仓库，可回滚（3.6 G）
restore-check/            ← 恢复演练产物，可删（640 M）
cache/                    ← restic 本地缓存，删了会自动重建（可删）
verification.json         ← state: ALL_DATA_VERIFIED + 每个 snapshot 的新旧 ID 映射
restore-verification.json
maintenance-result.json   ← before/kept/removed 快照 ID，state: VERIFIED
preservation.log          ← "read all data / no errors were found"
```

判读要点：

- `verification.json` 的 `state: ALL_DATA_VERIFIED` 表示**副本本身已验证可读**，不等于"可以删了"。它证明的是"这份回滚副本是好的"。
- `maintenance-result.json` 的 `kept` / `removed` 告诉你维护删了哪些快照；`preserved_repository` 字段指向的就是 `repository/`。
- **`cache/` 和 `repository/` 体积差一个量级，名字只差三个字母**，务必分开确认。
- 主仓库在别处（本轮 vps-la `/var/lib/naye-restic/repositories/naye`）且健康时，这份副本的保留价值只剩"回滚到维护前"。删不删交所有者决定，不要自行清。

## 6. 采集盲区的修法

旧机磁盘能涨到 87% 无人知，是因为它完全不在监控里：

- `digest.py` 的 `SOURCES` 只覆盖本机 + vps-la + diaomao + vps-hk，**没有这台 AWS**
- `vps-healthcheck.sh` 的 `check_remote` 只跑 `vps-la`、`vps-hk`

发现这种情况时如实报告"这台机器是采集盲区"，并给出两条可选修法（加进 healthcheck 的 remote 列表 / 给 digest 加一个真实 SSH 采集项），**由所有者决定是否扩监控** —— 不要顺手加常驻巡检。

## 7. 本轮结果（仅作量级参考，数字会变）

| 机器 | 起始 | 结束 | 释放 | 主要来源 |
|---|---|---|---|---|
| naye | 67% | 60% | 7.85 G | 两次失败备份留下的 offsite 工作区各 3.0 G + docker build cache |
| vps-la | 83% | 79% | 1.22 G | 无引用镜像 + 停用 9 天的容器 |
| diaomao | 69% | 62% | 620 M | 10-16 迁移源快照（**含 /etc /root 凭据**）+ journal vacuum |
| 旧 AWS | 87% | 78% | 2.0 G | 目标机已验证的重复快照 + `.npm-global` + apt cache |

diaomao 那条值得单独记：迁移包 `manifest.json` 里写明 `"Private archive includes credentials"`。**含凭据的归档长期滞留在盘上本身就是风险**，迁移稳定运行后应优先清掉，而不是等磁盘满了才想起来。
