# 单写者分组切换 Runbook（整机迁移的业务切换阶段）

适用：旧机继续在线做回退、新机已隔离恢复并通过离线校验，现在要把**真实业务身份**从旧机交到新机。
不适用：只做审计、只搬文件、还没到切业务。

## 1. 为什么必须分组

每个身份只能有一个写者。同时在线会触发下面这些真实故障：

| 身份 | 双写后果 |
|---|---|
| OAuth refresh token（CPA auth-dir） | 两个进程各自刷新，先刷的使后刷的 `invalid_grant`，账号掉线 |
| Telethon `auth_key`（.session） | `AUTH_KEY_DUPLICATED`，会话可能直接失效，需要重新登录 |
| Bot token 长轮询 | 两边抢 `getUpdates`，日志 `Conflict: terminated by other getUpdates`，消息随机丢 |
| `ssh -R` 反向隧道端口 | 远端端口被旧连接占着，新机带 `ExitOnForwardFailure=yes` 直接失败 |
| DDNS / 定时任务 / 队列消费者 | 重复上报、重复下发、重复发信 |

## 2. 分组模型

| 组 | 典型内容 | 备注 |
|---|---|---|
| A 网关与隧道 | API 网关、反向隧道、cloudflared named tunnel | 先切，后面所有组都依赖它 |
| B 会话绑定客户端 | Telethon 人形号 | 最敏感，单独一组，别和 Bot 混 |
| C Bot 轮询 | 多实例 Bot（同 token 家族靠 env 区分实例） | 同目录多 unit 的必须逐个切、验 409 |
| D Agent 与 UI | Hermes gateway / web-ui | 验记忆、历史、模型路由、PTY |
| E 调度 | cron / systemd timers / Hermes jobs | 最后一个开，前置消费者全部单写者确认后再启 |

## 3. 每组固定七步（顺序不可换）

1. **记录旧状态**：`MainPID`、`ActiveEnterTimestamp`、监听端口、采样时间（UTC + Asia/Shanghai 双写）。
2. **停旧**：先停隧道，再停服务（见 §4 端口绑定顺序）。
3. **最终增量同步**：停写之后再同步，别在服务运行时同步会被写的文件。
4. **哈希门禁**：**在新机启动之前**逐文件比 sha256，任一不一致就 abort。这一步的价值是「此刻旧机还完整、回滚零成本」。
5. **装 unit 起服务**：候选 unit 先落 `/etc/systemd/system/`，覆盖前把原文件备份到迁移证据目录。
6. **真实验收**：按 §5 的服务类判据，不看 `is-active`。
7. **旧机 disable**（不是 mask）：文件保留，回滚只需 `enable --now`。

每组的每一步写进一个 JSON 证据文件（`{stage, ts:{utc,asia_shanghai}, steps:[...]}`），出问题先读回执，别凭记忆。

## 4. 端口绑定顺序

`-R 127.0.0.1:18318:127.0.0.1:8317` 这类反向隧道带 `ExitOnForwardFailure=yes`：远端端口还挂在旧连接上，新机隧道必然起不来。
顺序固定为：**旧隧道停 → 旧服务停 → 新服务起 → 新隧道起**。

## 5. 验收判据（按服务类，缺一项都不算过）

- **API 网关**：从 config 里取真实 `api-keys` 打 `/v1/models` → 200 + 模型条数；日志有 `full client load complete - N clients (N auth files)`，N 与 auth-dir 文件数一致。
- **cloudflared named tunnel**：`journalctl --user -u <unit> | grep -c 'Registered tunnel connection'` ≥ 1，且 precheck `status=pass`。只有 precheck 行、没有 Registered 行 = 还没挂上。
- **反向隧道**：**从远端那台机器**测，不是在新机测：`ss -lnt | grep <port>` 有监听，再 `curl` 一次。连接被拒 = 隧道没通；401/200 = 通了，只是要鉴权。别把 401 当失败。
- **Telethon**：日志出现 `UserBot running as: <name> (@<username>)`，且全文无 `AUTH_KEY_DUPLICATED` / `AUTH_KEY_UNREGISTERED`。
- **Bot 轮询**：日志无 `Conflict: terminated by other getUpdates`，且能在业务日志里看到新消息处理。
- **旧机存量消费者**：挂临时桥之后，**从旧机本地**再打一次同一端点，确认旧机上的 bot / agent 没掉功能。

## 6. 旧机存量消费者：临时桥

切完上游、但消费端还在旧机上时，别急着改旧机配置。挂一条瞬态隧道让旧地址继续可用：

```bash
systemd-run --user --unit=migration-<svc>-bridge \
  -p Restart=always -p RestartSec=5 \
  /usr/bin/ssh -N -i <key> -p 22 -o BatchMode=yes -o ExitOnForwardFailure=yes \
  -L 127.0.0.1:8317:127.0.0.1:8317 <new-host>
```

- 用 `systemd-run --user` 而不是 `nohup`/`setsid`：不落配置文件、可 `systemctl --user stop` 拆、进程可被追踪。
- 拆桥时机：旧机上最后一个消费者也迁完之后。拆桥前先确认没有 unit 还 `Wants` 旧地址。
- 同时把旧机原 unit `disable`，否则旧机一重启就复活第二个写者。

## 7. 切换期最容易误判的三件事

1. **root 的 `systemctl --user` 看不到用户 unit**：`ssh root@` 下执行 `systemctl --user is-active <unit>` 返回空，会误报「隧道没起来」。必须 `sudo -u <user> XDG_RUNTIME_DIR=/run/user/<uid> systemctl --user ...`。
2. **`is-active` = active ≠ 功能恢复**：端口在听、进程活着，仍可能一条业务链路都通不了。按 §5 逐类验。
3. **被服务写过的文件 hash 会变**：session、auth json、令牌文件必须在停旧之后再取，否则哈希门禁永远对不上，或者更糟——带着半写状态过去。

## 8. 回滚的真实形状

`disable` 之后，回滚**不是「重启一下」**：

1. 先停新机对应 unit（保住单写者）；
2. 旧机 `enable --now`；
3. 重新验证身份可用性。

会话类要特别小心：新机若已成功登录并刷新过 token（Telethon session / OAuth refresh），旧机那份副本**可能已经失效**，必须重新验证而不是假设可用。给用户的回滚承诺只能写到「有这个路径」，不能承诺固定分钟数无损。

## 9. 目标机上线前必查（本轮踩过的）

- `stat -c '%a %U:%G' / /home /var`：镜像可能给 `0700 root`，所有非 root 服务 `status=200/CHDIR` 起不来。
- `/home/<user>` 属主 + 750。
- `/etc/hosts` 有 `<YOUR_SERVER_IP> <hostname>`，否则每条 `sudo` 都刷 `unable to resolve host`。
- 受保护 user unit 的 `default.target.wants` 软链先摘，再 `loginctl enable-linger`。
- 顶层目录属主对照表：把旧机与新机 `/home/<user>` 的 `uid:gid` 逐项比对，恢复流程常把目录留成 `root:root`，服务能读不能写，故障延后爆发。

## 10. rsync 静默漏拷

非 root 的 rsync 遇到旧机上 `root` 拥有的子目录会报 `opendir ... Permission denied (13)` 并返回 **rc=23**，其余文件照传 —— 结果是备份/诊断子目录整块漏掉，而脚本里 `rc != 0` 常被忽略。

做法：发送端用 `sudo -n rsync`，完成后用 `du -sh` + 文件计数对账，不要用「rsync 退出码 0/非 0」当唯一判据，也不要因为主流程没报错就当搬全了。

## 11. 停服务前先找「复活者」

停掉 ≠ 停了。本轮真实事故：旧机 crontab 里 `lemon_ops_guard.py` 每 5 分钟 `systemctl restart lemon-ops`，切换脚本停完 8 秒复查是 `inactive`、进程数 0，几十秒后旧机自己又活过来，新机随即刷 `Conflict: terminated by other getUpdates request`（409），一度误判成「新机自己起了多实例」。

停服务前枚举四类复活源：

```bash
crontab -l > /tmp/crontab-before-<date>.txt; crontab -l | grep -nE 'systemctl (start|restart)|<svc>'
sudo crontab -l; ls /etc/cron.d/ /etc/crontab
systemctl list-timers --all | grep -i <svc>              # health / watchdog timer
systemctl cat <unit> | grep -E 'Restart=|ExecStartPre'    # Restart=always / 前置拉起
grep -rln "systemctl restart <svc>" ~ --include='*.sh' --include='*.py' | head
```

- cron 守护：先备份 crontab，再注释该行（前缀写 `# [MIGRATION-<date> 暂停: ...]`，既留痕又便于回滚与后续在目标机重启用）。
- timer 守护：`systemctl disable --now <x>.timer`，只 stop service 不够。
- **验证必须等过一个完整守护周期**再复查 `is-active` + `ps -eo pid,cmd | grep -c '[p]attern'`，不能停完立刻下结论。
- 症状对照：新机日志出现 409 / `Conflict: terminated by other getUpdates` / `AUTH_KEY_DUPLICATED` → 先怀疑「旧机或第三处还有实例在跑」，不要先怀疑新机自身。
- 这些守护脚本本身也是待迁资产：注释掉不等于删掉，迁到新机后要在目标机重新启用，否则新机也失去自愈。

## 12. DDNS / 动态 IP 更新器必须冻结

- 两台同时跑 DDNS 会各自把同一条 A 记录改成自己的 IP，来回打架，外部访问随机命中旧机或新机。
- 顺序：切前 `systemctl disable --now` 旧机 DDNS timer → 切完在目标机启用。启用即等于「把记录指向新机」，不需要手工改 DNS。
- 动之前先读 DDNS 配置确认它管哪些记录（本轮 `aws.` 与 `ec2.` 两条同域记录一起改）；只该改一条时别把整个脚本原样搬过去。
- A 记录直连（`proxied=false`）+ 短 TTL 时，DDNS 翻转 1–2 分钟生效；若是橙云代理或 Tunnel CNAME，得走 tunnel 连接器迁移，靠 DDNS 改不动。

## 13. 自己可能就挂在被切的服务下面

- 切 Agent / Web UI 之前先查自己的祖先链：

```bash
ps -o pid,ppid,pgid,cmd -p $$
p=$$; for i in 1 2 3 4 5 6; do read -r pp cmd < <(ps -o ppid=,cmd= -p $p); echo "$pp $cmd"; p=$pp; [ "$p" = 1 ] && break; done
```

- 若祖先就是待停的 unit（本轮：会话挂在 `hermes-web-ui` 的 agent-bridge → node server 之下），停它 = 当场切断自己的会话和汇报通道。
- 做法：**让存活的一侧驱动切换**。目标机持有迁移密钥，反向 SSH 回旧机执行「停旧 → 快照 → 拉增量 → 起新 → 验收」，脚本用 `systemd-run --unit=<name> --collect` 脱离会话运行，日志落盘。
- 打通反向 SSH 三步：`ssh-keyscan -t ed25519 <old-ip>` 钉死主机指纹写入独立 known_hosts（不用首次信任）；旧机 `authorized_keys` 先 `cp -a` 备份再追加迁移公钥；用 `-o IdentitiesOnly=yes -o BatchMode=yes` 实测 `echo OK; hostname` 通过再往下走。
- 切换前把「会话会断多久、之后从哪里继续」写给用户，别让用户以为服务挂了。

## 14. 日志窗口要从重启点算起

- `journalctl --since "-5min"` 会把修复前的历史冲突行算进来，得出「还在 409」的假阳性（本轮就发生过一次）。
- 用 `systemctl show <unit> -p ActiveEnterTimestamp` 取重启时刻，再 `--since "<该时刻>"` 过滤。
- `grep -c Conflict` 必须明确统计区间，结论里把区间写出来（「自 13:12:23 起 0 次」，而不是「最近没有」）。

## 15. 反向代理配置就是搬迁依赖图

- 动 web 入口前先完整读 Caddyfile / nginx conf：一个域名常同时反代多个后端（本轮 `/sub/*`→8688 subconverter、`/getruleset*`→25500、`/`→8648 Web UI）。
- 只搬主服务会留下 502；把这些同域后端一起列进搬迁清单与切换顺序。
- 证书目录（如 `/var/lib/caddy/.local/share/caddy/certificates/...`）属 `caddy` 用户 `0700`，读取要 `sudo`；跨机复制证书保持 `0600` + `chown caddy`，否则 caddy 起不来。

## 16. 切换后收尾：三类「两头都干净」的静默漏迁

切换完成的判据不是「服务 active + 域名 200」，而是旧机的每一项资产在目标机上有明确归属。本轮真正漏掉的三项都属于**新旧两头都看起来干净**，最容易在验收里被放过。

### 16.1 冻结的旧机 crontab 会伪装成「没有任务要迁」

为防单写者冲突把旧机 cron 行整行注释（`# [MIGRATION-FROZEN-<date>] ...`）之后：

- 旧机 `crontab -l | grep -vc '^#'` → `0`，看着「已无任务」；
- 目标机 `crontab -l` → `no crontab for <user>`，看着「没有历史包袱」；
- 实际 16 条业务任务（备份、媒体流水线、看门狗、告警桥）全部消失，且不会有任何报错。

正确判定与修复：

```bash
# 直接读 spool，绕过 crontab -l 的「注释即空」假象
sudo cat /var/spool/cron/crontabs/<user> > /tmp/old_crontab_frozen.txt
grep -c 'MIGRATION-FROZEN' /tmp/old_crontab_frozen.txt        # 冻结条数
```

- 去掉冻结前缀后在目标机重装：`crontab /tmp/new_crontab.txt`，再 `crontab -l | grep -vc '^#'` 复核条数、`systemctl is-active cron` 复核守护。
- 装之前逐条 `[ -e <script> ]` 校验脚本路径存在，缺脚本的条目宁可留注释并上报，不要装一条必然失败的 cron。
- **为单写者而注释的守护（如 ops 自愈）在目标机要恢复成启用**，不要连注释一起搬过去 —— 否则新机永久失去自愈。
- 时区语义要核对：旧机若 `TZ=UTC`、目标机 `Asia/Shanghai`，同一行 cron 会整体偏移 8 小时，装完必须抽查下一次触发时间（`journalctl -u cron` 或实际落日志）。

### 16.2 特权平价会静默降级

老 AWS/Ubuntu 镜像由 cloud-init 写 `/etc/sudoers.d/90-cloud-init-users`，给 `ubuntu` 开 `NOPASSWD`；商业 VPS 的 Debian 镜像默认**没有**。切换后 agent 会话以非 root 用户运行，`apt`、`systemctl restart <系统服务>`、改 `/etc`、读 root-only 证据目录全部失败，而且**不会主动提示「权限姿态变了」** —— 表现为一串看似偶发的 `Permission denied`。

收尾必做：

```bash
ls /etc/sudoers.d/                      # 两端对比
sudo -n true && echo OK                 # 目标机实测，不要只看文件
```

需要恢复平价时按最小步骤改，并明确告知所有者这是一次安全姿态变更：

```bash
sudo cp -a /etc/sudoers /etc/sudoers.bak-<date>
printf '<user> ALL=(ALL) NOPASSWD:ALL\n' | sudo tee /etc/sudoers.d/90-<user>-nopasswd
sudo chmod 0440 /etc/sudoers.d/90-<user>-nopasswd
sudo visudo -c -f /etc/sudoers.d/90-<user>-nopasswd && sudo visudo -c | tail -1
```

同一类还有**系统服务账户**（`User=monitor-agent` 之类）不会随文件树迁移，漏了就是 `217/USER` 重启死循环，见 SKILL.md「切换期实测坑」。

### 16.3 验收计数必须按清单集合比，不能按名字模式 grep

本轮用 `systemctl list-timers | grep -E 'lemon|hermes'` 对账，把 `emby-v6-watch`、`gemini-quota-daily`、`gemini-recovery-revert` 判成「未迁移」，实际三个都 `enabled` —— 纯粹是名字不含这两个词造成的假阴性，差一步就白补三个 timer。

- 正确做法：从旧机盘点清单取**单元名集合**，在目标机逐个 `systemctl is-enabled <name>` / `is-active` 比对，差异集为空才算过。
- 任何「grep 出来的数量」都只是线索，不能当验收结论；报告里写的是集合差，不是匹配行数。

### 16.4 切换后反连旧机 / 自取 root 的 known_hosts 陷阱

- 迁移密钥的 `known_hosts` 通常只钉了目标机，从新机连旧机会直接 `Host key verification failed`（不是密钥问题，是主机指纹不认）。
- 先 `ssh-keyscan -t ed25519 <ip>` → `ssh-keygen -lf` 输出与台账里记录的指纹**逐字比对**，一致才追加进该 `known_hosts`；不一致就停下，别用 `-o StrictHostKeyChecking=no` 绕过。
- 切换后 agent 以非 root 用户运行、而迁移证据目录 root-only 时，可用迁移密钥 `ssh -i <key> root@127.0.0.1` 取回 root（先 keyscan `127.0.0.1` 并核对该机**自身**主机指纹），否则整场收尾会卡在权限上反复试探。

### 16.5 DNS 翻转放在本机验收之后，并内置回滚

固定顺序：**停旧 → 最终快照 → 拉增量 → 起新 → 本机验 `webui:端口` 与 `https` → 通过才 enable DDNS**。

- 本机验收不过就重启旧机 web 栈并中止，**不翻 DNS**；所有者只经历一次短暂断线，DNS 从未指向未就绪的新机（本轮第一次尝试即按此回滚）。
- 本机 `curl https://127.0.0.1/` 返回 `000` 不一定是故障（缺 SNI，见 SKILL.md Caddy 条目），用 `--resolve <domain>:443:127.0.0.1` 重测再决定是否回滚，避免假故障把切换打成乒乓。
- 切完的独立证据：DNS 连续多次解析到新 IP、旧机 `80/443` 已关（只剩 SSH 做回退通道）、外部域名 `https=200`。三条一起看才算单写者干净。

### 16.6 Root 与 User crontab 双重装入陷阱（任务双跑与 root 属主污染）

当自动化切换/bootstrap 脚本以 root 权限运行（如通过 `systemd-run` 脱离会话执行）并调用 `crontab <file>` 时，若未显式指定 `-u <user>`，该 crontab 会被静默装入 **root 的 spool**（`/var/spool/cron/crontabs/root`）。后续若又以普通用户装了一遍，会导致两份完全相同的 crontab 同时运行：

- **危害 1：任务双跑**。每分钟所有的 watchdog、alert-bridge、数据采集各跑两次，加剧系统负载与 API 速率限制。
- **危害 2：文件属主污染打崩备份**。以 root 运行的定时脚本会在用户目录下生成 `root:root 0600` 的状态文件或日志（如 `hermes-jobs/status/*.state.json`、`status/memory-trend.tsv`）。随后以普通用户运行的日常备份（`tar czf`）在读取这些文件时直接抛 `Permission denied`，导致 `tar` 退出码非 0，备份安全门禁判定 `fatal_tar_status` 致命失败！
- **排查与修复**：
  ```bash
  sudo ls -la /var/spool/cron/crontabs/         # 查看有哪些用户的 spool
  sudo crontab -l -u root                      # 核对 root 是否有多余任务
  sudo crontab -r -u root                      # 清空 root 的重复任务（若无需 root 定时）
  find /home/<user> -maxdepth 3 -user root     # 排查被污染成 root 属主的文件并 chown 回复
  ```

### 16.7 活跃服务持有已删除 Inode（Unlinked SQLite Inode / Deleted WAL FD 陷阱）

在数据库恢复或文件覆盖阶段，若关键常驻服务（如 `hermes-gateway`、`lemon-userbot`）在此前已经启动，而后操作者或脚本执行了 `cp state.db ...`、解压覆盖或删除了旧的 `-wal`/`-shm` 文件，Linux 内核会保留旧 inode 直到所有进程关闭该文件描述符。

- **现象**：通过 `ls -l /proc/<pid>/fd/` 可看到大量指向 `/home/<user>/.hermes/state.db (deleted)`、`state.db-wal (deleted)` 的符号链接。
- **危害 1：数据更新黑洞**。服务进程继续在内存/已删除的底层 inode 中读写，完全不感知磁盘上新放的文件；一旦该服务在未来某一时刻重启，在持 deleted FD 期间产生的所有新会话/状态数据**永久丢失**。
- **危害 2：阻断日常备份门禁**。规范的 SQLite 备份脚本（如 `backup_hermes.sh`）具有健康门禁，会扫描 `/proc/*/fd` 是否持有 deleted wal FD。一旦命中直接中止（`发现 deleted state.db-wal FD，持有者 pid=...; 备份失败: state.db 健康门禁未通过`）。
- **危害 3：级联导致异地加密备份失败**。本地 Hermes 备份失败会导致缺少当天的快照包（如 `model_proxy.tar.gz`），随后的统一异地备份（`phase5-backup-schedule.sh`）在 `offsite_backup.py` 中因找不到依赖组件抛出 `ValueError: Snapshot file missing or symlinked`，整条容灾备份链路彻底瘫痪。
- **强制规范**：任何跨机恢复、覆盖数据库或清理 `-wal` 文件后，必须扫描活跃消费者的 fd：
  ```bash
  sudo ls -l /proc/$(systemctl show <unit> -p MainPID --value)/fd/ 2>/dev/null | grep -i "deleted"
  ```
  若存在 deleted FD，必须立刻执行 `systemctl restart <unit>` 释放旧句柄并重新绑定磁盘上的真实 inode，随后必须立即完整实跑一次端到端备份验证（`backup_hermes.sh` + 异地备份链路）验收。

## 17. 相关

- 一致性数据与 WAL 陷阱、新机权限坑、user unit 管理：见本技能 SKILL.md「切换期实测坑」。
- 加密归档解封：`references/authenticated-archive-recovery.md`。
- 隔离验证结构：`references/isolated-migration-validation.md`。
- Telethon 会话边界（`AUTH_KEY_DUPLICATED` 官方口径）：`lemon-userbot` 技能。
