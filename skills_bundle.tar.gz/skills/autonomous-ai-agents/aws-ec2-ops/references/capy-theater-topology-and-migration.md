# Capy 影厅与多机协同拓扑运维实录（2026-10 实测）

## 一、架构事实与物理部署

在整机迁移或多节点运维排障时，用户口中的业务名称常常与底层部署架构存在映射差异。以「Capy 影厅」为例：

1. **物理宿主：** 位于 `vps-la`（Ubuntu 24.04 LTS，<PRIVATE_IDENTIFIER>），而非 AWS 主控机。
2. **容器编排：** 由 6 个 Docker 容器组成：
   - `happy-capy`
   - `happy-capy-web`（前端 Nginx，页面标题为「登录 · Capy 影厅」）
   - `happy-capy-guard`
   - `happy-capy-share-backend-1`
   - `happy-capy-share-web-1`（繁体页面「Capy 影廳」）
   - `happy-capy-share-auth`
3. **同机服务依赖关系：**
   - 腾白嫖（`workbuddy2api.service`）是同机独立运行的原生 systemd 服务（以专用 `workbuddy2api` 用户运行）。
   - Capy 影厅的前端 Nginx 内部配置有一条单向反向代理，指向本地回环上的 `workbuddy2api` 端口。
   - **运维红线：** 两者归属与权限体系独立，不可合并部署；但存在单向运行时依赖，重启或维护时必须注意依赖顺序，不可单边切断。

## 二、整机迁移中的归属与交接规范

当执行 AWS 主控服务器整机迁移时，必须严格区分「本机常驻业务」与「远端受控业务」：

1. **容器不搬迁：** Capy 影厅的容器实例与底层数据卷（`happy-capy-share_app_data` 及 `/opt/happy-capy/data`）必须**保留在 `vps-la` 原位，绝不搬迁容器**。
2. **仅交接控制端调度：** 旧 AWS 主控机上仅挂载了针对 Capy 影厅的：
   - 证书自动续期脚本（周级 cron）
   - 状态监控与告警守护脚本（分钟级）
3. **切换红线：** 新机恢复后，仅接管对应的定时管理脚本；切换时必须遵守「旧机停 ➔ 验证新机 ➔ 新机启」的时序，严禁双机同时对远端服务发起证书重写或告警探测，避免触发接口频率限制或报警冲突。
