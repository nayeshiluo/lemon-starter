# 实例退役前的依赖审计与异地备份目标迁移（实录）

场景：用户问「旧 AWS 那台机器是不是对我已经没用了，可以删了吗」。旧机已完成整机迁移（新主力机接管业务），本次任务实际是**退役判断 + 把旧机残留职责迁走**。

## 1. 第一轮判据：不要看"上面跑什么"，要看"谁在依赖它"

只读拿到的事实（UTC 09:29，uptime 25 天）：

| 项目 | 结果 |
|---|---|
| 系统服务 | 只有 `ssh` / `komari-agent` / `redis-server`（`dbsize=0`）+ 系统默认单元 |
| 端口 | 只有 22；80/443 均不监听 |
| 用户级服务 | `desktop-commander-remote.service`（受保护控制入口，设备 online） |
| crontab | **有 1 条：`adkiller_offsite_pull.py` 每天 05:10 从 vps-la 拉 AdKiller `state.db`** |
| 其他 5 台机器 | `grep -rl <IP>` 全部为空（配置无引用） |
| CF `<YOUR_PRIVATE_DOMAIN>` 区 | 10 条记录无一条指向该 IP；`aws.`/`ec2.` 两个域名已解析到新主力机 |

**结论形状**：机器业务面已空，但它是某服务的**唯一异地备份接收端**，删掉即断链。这一条差点被"服务全空"掩盖。

### 漏判点：备份任务的方向是反的

脚本头部注释写得很清楚：vps-la 本地有 14 份快照，但同机快照随整机故障一起消失，所以由**旧 AWS 主动 SSH 出去拉**（入站流量不计费、不占 100GB/月 出网额度）。因此在旧机上看到的不是"被备份方"，而是"备份链的接收方"——只看旧机本地有没有数据会完全看不出来。

## 2. 接入探测

- `ping` 100% 丢包，但 `echo >/dev/tcp/<IP>/22` 是 open → **安全组只放行 SSH，ping 不通不代表机器死了**。
- `~/.ssh/config` 里没有这台机器的 Host 条目；`ubuntu@`/`root@` 用预期钥匙全是 `Permission denied (publickey)`。
- 枚举法找到可用组合：

```bash
for k in codex_ssh_ed25519 lemon_aliyun_admin lemon_hytron_admin lemon_diaomao_ops_20261105 migration-greencloud-20261027; do
  for u in ubuntu root; do
    timeout 12 ssh -i ~/.ssh/$k -o ConnectTimeout=6 -o BatchMode=yes -o StrictHostKeyChecking=no $u@<IP> "echo OK"
  done
done
# → SUCCESS codex_ssh_ed25519/ubuntu
```

- **枚举次数多了会触发 fail2ban**：之后连续两次 `kex_exchange_identification: read: Connection reset by peer`，几秒后同样的命令直接成功。见到 reset 先等 5–10 分钟再试，别写进结论说"主机不可达"。
- 无 `aws` CLI、`~/.aws/` 为空、无 IAM 凭证 → 不装 CLI，云侧动作留给用户控制台。

## 3. 迁移异地备份接收端（AWS → 阿里云）

目标机选择依据：内存/磁盘余量（1.7GB RAM、35G 空闲）优于另一台 1GB 的小机；每天约 4MB 拉取对已有转发业务无影响。

步骤与踩坑：

1. 建 `ubuntu` 用户级目录、`~/.ssh/config`（`Host vps-la` + 显式 `IdentityFile` + `StrictHostKeyChecking yes`）、`ssh-keyscan -p 2222 -H` 写 `known_hosts`，先 `sudo -u ubuntu ssh vps-la 'echo SSH-OK'` 验证单向连通。
2. **目标机没有 rsync、`apt-get install` 撞 `dpkg frontend lock`** → 不要反复装包，改 `tar -C src -cf - . | ssh host "tar -C dst -xf -"` 或逐文件 `scp`。tar 管道在大目录上也可能超时，超时后必须核对目标端实际文件数，不能假设失败。
3. **传输"成功"必须逐项复核，不能只看退出码**：
   - 一次 `scp` 在批量循环里报 `Connection closed`，留下 **0 字节** 文件；
   - 重传后该文件又只有 1.6M（源 3.5M），`PRAGMA integrity_check` 报 `database disk image is malformed`；
   - 第三次单独重传才 `ok`。
   - 收尾核对：`diff <(ls src|sort) <(ssh host 'ls dst|sort')` 为空 **且** 抽样 `integrity_check` 为 `ok` **且** 份数一致。
4. cron 用目标机的服务账户装：`crontab -u ubuntu -`（用 `-u` 显式指定，否则装进 root spool）。装完 `crontab -u ubuntu -l` 复核。
   **注意包装器只在原机器上**：本环境的 `cron-status.py` 台账包装器随旧机一起退役，新接收机上装的是裸 cron 行，
   它不会出现在 `hermes-jobs/jobs/<name>/status` 里，只有日志可查——交付时要如实说明，或者把包装器一并部署过去。
5. 手动触发一次验证输出，例如 `{"status":"ok","skipped":true,"snapshot":"state-20261115-200235.db","integrity":"ok"}`（`skipped` 是幂等命中，不是失败）。
6. 最后才摘掉**源机**上旧的 cron 行，并 `crontab -l | grep -i <job>` 确认已无残留。

## 4. 交付给用户的删前清单

1. 确认受保护控制入口（`desktop-commander-remote`）是否还要——外部设备 online 但近 14 天无真实工具调用；
2. 监控面板侧删除对应节点（否则留死节点）；
3. 未持 token 的 DNS 区是否存在指向该 IP 的记录（如实写"未核实"）；
4. EBS 卷随实例删除一起消失，`~/backups` 与旧项目副本若无第二份，先打包拉走；
5. terminate 由用户在控制台执行。

## 5. 用户说「都删了吧」之后的删除阶段（可做 / 不可做）

授权到手后仍要分清两类动作，**能自己做完的做完再报**：

1. **搬走不可再生数据**：`du -sh ~/backups/*` 看体量，`git -C <dir> status --porcelain` 为空即「代码在 git」，不必搬；只把备份归档打包：
   ```bash
   ssh -i <key> ubuntu@<旧机> "tar -czf - /home/ubuntu/backups /home/ubuntu/.config/*.env" \
     | ssh <新机> "mkdir -p <dst> && cat > <dst>/old-host-backups-<date>.tar.gz"
   ```
   546M → 321M 实测几分钟。**收尾必须验成员数**：`tar -tzf <包> | wc -l`（本例 773）并抽 grep 关键目录，别只看文件大小。
2. **删监控面板节点**：本环境 Komari 是 naye 上的本地 SQLite（`~/komari/data/komari.db`，容器挂 `./data`），
   节点在 `clients` 表。流程：`sudo cp komari.db /tmp/komari.db.bak-<ts>` → `delete from clients where uuid=?`
   → `docker restart komari` → `curl -o /dev/null -w '%{http_code}' 127.0.0.1:8091/`（200）→ 再查一次 `select name from clients` 核剩余节点数。
   注意 `db` 属主是 root（容器写的），普通用户 `cp` 会 Permission denied，必须 `sudo`。
3. **受保护控制入口停不掉是正常的**：`systemctl stop desktop-commander*` 会被 deny 规则硬拦
   （`[a-z_]*=*systemctl *stop*desktop-commander*`）。**不要绕过**——整机删除时它随实例消失，直接在交付里说明即可。
4. **不可逆动作留给用户**：无 `aws` CLI / 无 `~/.aws/credentials` → terminate 只能用户在控制台做。
   交付时提醒：EBS 卷、弹性 IP、快照不随实例自动清理，会留收费孤儿资源。

交付三档写清：**已核实完成 / 未能核实项 / 需要用户动手的一步**。本次唯一未核实项是某个 CF zone 的全量 DNS
（token 只在 Worker 里），只能对已知子域逐个 `dig` 并说明「橙云隐藏源站，无法据此证明不存在指向」。

## 6. 可复用要点

- 退役审计的第一问永远是"**谁在依赖它**"，第二问才是"它自己在跑什么"。
- 跨机 `grep` 一定要在**遍历端**排除 `proc/sys/dev`，并过滤 `*.log` / `history` / `known_hosts`。
- 备份接收端迁移的正确顺序：目标机准备好 → 搬存量 → 装新 cron → 手动跑通 → 摘旧 cron；任一步都要有"份数 + 完整性"双证据。
- 不可逆动作（terminate、删 DNS、删面板节点）留在用户手上，代做的是审计与可逆迁移。
