# 安全组入站规则排障实录（2026-08-15）

## 场景
Hermes web-ui 面板（端口 8648）从外网打不开，但：
- 进程在跑：`ps aux | grep hermes-web-ui` → Node.js 进程存活
- 本地监听 `0.0.0.0:8648`：`ss -tlnp | grep 8648` → LISTEN
- 本地 curl 返回 200：`curl -s -o /dev/null -w "%{http_code}" http://127.0.0.1:8648/`
- 服务器自测公网也通：`curl -s -o /dev/null -w "%{http_code} %{remote_ip}" --connect-timeout 5 http://<公网IP>:8648/` → 200
- 但用户从外网访问超时/拒绝连接

## 根因
AWS 安全组 `launch-wizard-1` 默认只放行 SSH（22 端口），未添加 8648 入站规则。

## 无 IAM 角色时的排查命令

### 获取 IMDSv2 token
```bash
TOKEN=$(curl -s -X PUT "http://169.254.169.254/latest/api/token" -H "X-aws-ec2-metadata-token-ttl-seconds: 21600")
```

### 查询安全组名称
```bash
curl -s -H "X-aws-ec2-metadata-token: $TOKEN" http://169.254.169.254/latest/meta-data/security-groups
# → launch-wizard-1
```

### 查询安全组 ID
```bash
MAC=$(curl -s -H "X-aws-ec2-metadata-token: $TOKEN" http://169.254.169.254/latest/meta-data/network/interfaces/macs/ | head -1)
curl -s -H "X-aws-ec2-metadata-token: $TOKEN" "http://169.254.169.254/latest/meta-data/network/interfaces/macs/${MAC}security-group-ids/"
# → sg-03ae9ea2a5b62475e
```

### 查询实例 ID 和区域
```bash
curl -s -H "X-aws-ec2-metadata-token: $TOKEN" http://169.254.169.254/latest/meta-data/instance-id
# → i-08d5b067d06d7ce8d

curl -s -H "X-aws-ec2-metadata-token: $TOKEN" http://169.254.169.254/latest/meta-data/placement/region
# → ap-southeast-1
```

### 确认无 IAM 角色
```bash
curl -s -H "X-aws-ec2-metadata-token: $TOKEN" http://169.254.169.254/latest/meta-data/iam/ 2>/dev/null
# → 404 (no IAM role)
```

### 确认 AWS CLI 无凭证
```bash
which aws  # apt 已安装
aws sts get-caller-identity 2>&1 | grep "Unable to locate"
# → "Unable to locate credentials"
```

## 给用户的操作指引（无 IAM 角色时）

无法从实例内修改安全组，需用户通过 AWS 控制台操作：

```
需要手动添加一条入站规则到安全组：
- 安全组 ID：sg-03ae9ea2a5b62475e
- 安全组名称：launch-wizard-1
- 区域：ap-southeast-1（新加坡）
- 类型：自定义 TCP
- 端口范围：8648
- 来源：0.0.0.0/0
- 操作路径：AWS 控制台 → EC2 → 安全组 → 选择该安全组 → 入站规则 → 编辑入站规则 → 添加规则 → 保存
```

## 注意事项
- 实例的弹性 IP 是 52.221.30.161（eipalloc-0c957f83916ef5e70），稳定不变
- web-ui 面板是独立的 Node.js 进程（`hermes-web-ui`），不是 `hermes dashboard` 命令
- 面板地址格式：`http://<公网IP>:8648/#/?token=<hex>`（token 在 `hermes-web-ui start` 输出或 `~/.hermes-web-ui/server.log` 中）
- 页面 token 与 gateway API key 是两层独立认证，互不影响