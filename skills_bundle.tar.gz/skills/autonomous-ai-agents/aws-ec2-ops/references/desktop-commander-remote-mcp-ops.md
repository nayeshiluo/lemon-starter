# Desktop Commander / Remote MCP 运维与排障手册

## 概述与架构

Desktop Commander（`@wonderwhy-er/desktop-commander`）是一套让外部大模型（如 ChatGPT / OpenAI MCP 客户端）通过云端中继（Supabase Broadcast 通道 `https://mcp.desktopcommander.app`）远程访问与控制宿主机的 Remote MCP 设备服务。

系统分为两层：
1. **远程桥接层（Remote Device）**：运行 `desktop-commander remote --disable-no-sleep`，通过 WebSocket 长连接接入云端中继，监听来自客户端的 tool call，并向云端上报设备在线心跳（Device ID 绑定）。
2. **本地执行层（Local MCP Child Process）**：远程进程在收到 tool call 时，会在本地以 stdio 管道方式启动本地 MCP 服务器（`dist/index.js` 或全局 `desktop-commander` 命令），负责真正执行终端命令、搜索（ripgrep）、文件读写等。

---

## 典型故障与根因审计

### 1. `Desktop Commander MCP not found` 崩溃循环
- **现象**：远程能收到 tool call，但每个工具调用均立即报错：
  ```text
  ❌ Tool call start_process failed: Desktop Commander MCP not found.
  Please install it globally via `npm install -g @wonderwhy-er/desktop-commander` or build the local project.
  ```
- **根因**：
  若在 systemd unit 中使用了 `ExecStart=/usr/local/bin/npx @wonderwhy-er/desktop-commander@latest remote ...`，程序实际上被解包在 `~/.npm/_npx/<hash>/node_modules/` 临时目录。
  当宿主机执行日常清理（如 `rm -rf ~/.npm` 或清理临时目录）后，正在运行的 node 进程的磁盘文件被删除。当新的工具调用需要唤起或重启本地 MCP 子进程时，既找不到 `../../dist/index.js`，PATH 中也没有全局 `desktop-commander`，导致后续调用永久失败。
- **永久根治方案**：
  1. 全局安装二进制：`sudo npm install -g @wonderwhy-er/desktop-commander@latest`
  2. 验证 `/usr/local/bin/desktop-commander` 可执行并位于系统 PATH 中。
  3. 服务配置直调 `/usr/local/bin/desktop-commander remote --disable-no-sleep`，严禁在守护进程中使用 `npx`。

### 2. `Invalid Refresh Token: Already Used` 与设备授权失效
- **现象**：
  ```text
  💾 Found persisted session for device <UUID>
  [DEBUG] Failed to set session: Invalid Refresh Token: Already Used
  ⚠️ Persisted session invalid: Invalid Refresh Token: Already Used
  🔐 Starting device authorization flow...
  ```
- **排障与恢复步骤**：
  1. 此为 OAuth Refresh Token 轮转安全机制，旧 Token 被注销后必须重新走 OAuth Device Code 授权。
  2. 查日志抓取设备验证码：
     ```bash
     XDG_RUNTIME_DIR=/run/user/1000 journalctl --user -u desktop-commander-remote.service -n 20 --no-pager
     ```
  3. 获取到验证 URL 与 8 位 Code（如 `5MD9-T6L3`，有效期 15 分钟）：
     - 网址：`https://mcp.desktopcommander.app/device/verify`
  4. 用户在浏览器登录对应账号（如 `<YOUR_EMAIL>@gmail.com`）并确认输入授权码。
  5. 后台服务轮询检测到授权成功后，会自动写入 `~/.desktop-commander/device.json`，并打印 `Device ready` 自动上线，无需再次手动重启。

---

## 推荐守护进程配置（Systemd User Service）

路径：`~/.config/systemd/user/desktop-commander-remote.service`

```ini
[Unit]
Description=Desktop Commander Remote MCP
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
ExecStart=/usr/local/bin/desktop-commander remote --disable-no-sleep
Restart=always
RestartSec=5
WorkingDirectory=/home/ubuntu
Environment=HOME=/home/ubuntu
Environment=PATH=/home/ubuntu/.local/bin:/usr/local/bin:/usr/bin:/bin

[Install]
WantedBy=default.target
```

### 运维命令备忘

```bash
# 检查状态
XDG_RUNTIME_DIR=/run/user/1000 systemctl --user status desktop-commander-remote.service

# 查看实时日志
XDG_RUNTIME_DIR=/run/user/1000 journalctl --user -u desktop-commander-remote.service -f

# 重载并重启
XDG_RUNTIME_DIR=/run/user/1000 systemctl --user daemon-reload
XDG_RUNTIME_DIR=/run/user/1000 systemctl --user restart desktop-commander-remote.service

# 确认用户 linger 已开启（确保免登录常驻）
loginctl show-user ubuntu -p Linger --value  # 必须为 yes
```
