# 大文件流式 CMS AuthEnvelopedData (AES-GCM) 迁移解密方案

## 故障背景与根因

在跨机器系统迁移或大文件备份还原中，当使用 `openssl cms -encrypt -binary -aes-256-gcm -stream -outform DER -recip <cert>` 打包大于 2GiB（如 ~3.7GiB 的用户目录归档）时，在接收端直接使用 OpenSSL CLI 解密会遇到致命限制：

```bash
openssl cms -decrypt -binary -inform DER -in archive.tar.zst.cms -inkey recipient.key.pem -out /dev/null
```
**报错：**
```text
Error reading SMIME Content Info
4007DAEC847F0000:error:038C0100:memory buffer routines:BUF_MEM_grow_clean:malloc failure:../crypto/buffer/buffer.c:128:
4007DAEC847F0000:error:068C0100:asn1 encoding routines:asn1_d2i_read_bio:malloc failure:../crypto/asn1/a_d2i_fp.c:276:
```

### 真实根因（非 OOM，非机器 RAM 耗尽）
1. **OpenSSL 架构缺陷**：`d2i_CMS_bio` 在解包 DER/BER 时，底层通过 `asn1_d2i_read_bio` 将整个 ASN.1 对象累积读取到 `BUF_MEM` 内存缓冲区中，并未像加密端一样提供真正的单向流式（Streaming）处理。
2. **硬编码缓冲区上限**：OpenSSL 的 `crypto/buffer/buffer.c` 中硬编码了扩容上限保护 `LIMIT_BEFORE_EXPANSION = 0x5ffffffc`（约 1.5GiB），当请求的分配长度超过该值或后续 `INT_MAX` 时，`BUF_MEM_grow_clean` 会主动抛出 `ERR_R_MALLOC_FAILURE`。
3. **加内存/Swap/使用 `-stream` 均无法解决**：因为这是 ASN.1 BIO 反序列化在 C 代码层的长度边界限制，与物理内存剩余量无关。

---

## 解决方案：Python 纯流式有界 BER 解析与 AES-GCM 解密

使用 Python 的 `cryptography` 库，在目标机上实现针对 CMS AuthEnvelopedData 的纯流式解码：
1. 流式解析外层 BER 封装，仅读取信封头与 RecipientInfo。
2. 通过本地私钥使用 RSA PKCS#1 v1.5 解开加密的对称内容密钥（CEK，32 bytes）。
3. 提取 GCMParameters 中的 Nonce（通常 12 bytes）与 ICV 长度（通常 16 bytes）。
4. 对 `EncryptedContent` 进行逐块（如 1MB Chunk）流式 AES-256-GCM 解密，同时将解密后的密文流直接写入私有 `.part` 暂存文件。
5. 最终读取尾部 16-byte GCM Tag，执行 `decryptor.finalize_with_tag(tag)` 强校验认证。校验通过后，通过原子链接/硬链接重命名发布，严禁未认证明文外泄。

---

## 核心脚本实现

```python
import argparse
import hashlib
import json
import os
import secrets
import stat
import sys
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import padding
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes

CHUNK = 1024 * 1024
MAX_ARCHIVE = 12 * 1024**3
MAX_CONTENT = 8 * 1024**3
MAX_META = 65536

class FormatError(ValueError): pass

class BER:
    def __init__(self, src):
        self.src = src
        self.pos = 0
        self.stack = []
        self.sha = hashlib.sha256()
        self.max_read = 0

    def read(self, n):
        if not 0 <= n <= CHUNK: raise FormatError("unbounded read refused")
        if self.pos + n > MAX_ARCHIVE: raise FormatError("archive limit exceeded")
        if any(end is not None and self.pos + n > end for end in self.stack):
            raise FormatError("container overrun")
        self.max_read = max(self.max_read, n)
        out = bytearray()
        while len(out) < n:
            part = self.src.read(n - len(out))
            if not part: raise FormatError("truncated input")
            out.extend(part)
            self.sha.update(part)
            self.pos += len(part)
        return bytes(out)

    def head(self):
        tag, length = self.read(2)
        if tag & 31 == 31: raise FormatError("high-tag unsupported")
        if length == 128:
            end = None
        elif length & 128:
            n = length & 127
            raw = self.read(n)
            length = int.from_bytes(raw, "big")
            end = self.pos + length
        else:
            end = self.pos + length
        return tag, end

    def enter(self, expected_tag):
        tag, end = self.head()
        if tag != expected_tag: raise FormatError(f"tag mismatch: {tag} != {expected_tag}")
        self.stack.append(end)

    def leave(self):
        end = self.stack.pop()
        if end is None:
            eoc = self.read(2)
            if eoc != b"\x00\x00": raise FormatError("missing EOC")
        else:
            if self.pos != end: raise FormatError("length mismatch at leave")

def unseal(src, private_key, dst):
    r = BER(src)
    r.enter(0x30) # ContentInfo
    # 验证 OID: id-ct-authEnvelopedData (1.2.840.113549.1.9.16.1.23)
    # 提取 KeyTransRecipientInfo，RSA 解密得到 CEK
    # 提取 GCMParameters 得到 Nonce 与 Tag length
    # 流式 Cipher(algorithms.AES(cek), modes.GCM(nonce, min_tag_length=icvlen)).decryptor()
    # 循环 dec.update(chunk) 写入 dst 并更新 SHA256
    # 提取尾部 Tag 字节，执行 dec.finalize_with_tag(tag)
    # 严格认证通过后返回元数据字典
```

---

## 规避与防护原则

1. **先做小包/多规格差分**：在将大包解包前，必须先用同密钥生成的小包（几十MB）分别通过 OpenSSL CLI 与 Python 脚本解密，确认两者 SHA256 完全一致。
2. **必须测试损坏 Tag 拒解**：主动翻转 Tag 尾字节，确保解密器必然抛出 `InvalidTag` 且未保留 `.part` 文件，杜绝静默跳过验证。
3. **数据库必须独立提取覆盖**：主用户大包通常是在旧机服务运行中打下的，在线 `state.db` / `bot.db` 必然存在热 WAL 状态，解包后会报 SQLite 损坏错误。必须在解完主包后，**立刻从单独的 `sqlite-consistent` 快照包中提取干净一致的主数据库进行覆盖**，并复验 `PRAGMA integrity_check`。
