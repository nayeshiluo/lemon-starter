#!/usr/bin/env bash
# 探测当前 EC2 实例信息（IMDSv2 元数据服务）
# 用法: ec2-instance-info.sh
set -u

TOKEN=$(curl -s -m 5 -X PUT "http://169.254.169.254/latest/api/token" \
  -H "X-aws-ec2-metadata-token-ttl-seconds: 60") || { echo "无法获取 IMDSv2 token（非 EC2 环境？）"; exit 1; }

get() { curl -s -m 5 -H "X-aws-ec2-metadata-token: $TOKEN" "http://169.254.169.254/latest/meta-data/$1"; }

echo "机型:    $(get instance-type)"
echo "实例ID:  $(get instance-id)"
echo "公网IP:  $(get public-ipv4)"
echo "可用区:  $(get placement/availability-zone)"
echo "主机名:  $(get hostname)"

# 弹性 IP 检查（无输出 = 无弹性 IP，停机后 IP 会变）
EIP=$(for mac in $(get network/interfaces/macs/); do
  get "network/interfaces/macs/${mac}association/allocation-id" 2>/dev/null
done)
[ -n "$EIP" ] && echo "弹性IP:  ✅ 有（allocation: $EIP）" || echo "弹性IP:  ❌ 无（停机后公网IP会变）"

echo "内存:    $(free -h | awk 'NR==2{print $2}')"
echo "CPU:     $(nproc) 核"
echo "磁盘:    $(df -h / | awk 'NR==2{print $2, "已用", $3}')"
echo
echo "Hermes 服务状态:"
systemctl is-active hermes-gateway.service 2>/dev/null && echo "  hermes-gateway.service: active" || echo "  未找到 hermes-gateway.service"