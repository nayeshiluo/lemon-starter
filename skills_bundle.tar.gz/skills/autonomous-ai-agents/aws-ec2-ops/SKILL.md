---
name: aws-ec2-ops
description: "AWS EC2 实例运维：机型升级、迁移、元数据查询、Hermes 托管实例管理"
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux]
metadata:
  hermes:
    tags: [aws, ec2, migration, ops, hosting]
    related_skills: [hermes-agent]
---

# AWS EC2 实例运维（Hermes 托管场景）

## 操作安全边界（优先于下文示例）

只读诊断不授权任何清理、停服或配置变更。每日清理仅按本技能保守模板执行；其他缓存清理、服务停用、卸载和资源调整必须单独核实依赖、取得授权并保留回滚条件。禁止将这些操作追加到每日脚本。

## When to Use

用户需要操作运行 Hermes 的 AWS EC2 实例：改机型（"机型太小"）、迁移到新实例（"换实例"）、查实例信息、或处理停机/重启场景。**核心约束：这个实例上运行着 Agent 自身，不能先关旧再开新。**
- **用户发来移动端运维 App（如 ServerCat）截图询问「这几个占用高的是什么/服务器是不是要爆了」** → 见 `references/servercat-metrics-interpretation.md`（拆解网络双色比例满环误区、被截断的「建连... 2552」真实为 AttemptFails、开机累计硬件流量 vs AWS 月度账单、Linux 页面缓存机制）。

## 核心原则：先建后拆，绝不先关旧的

```
❌ 错误：关旧实例 → 开新实例          （Agent 失联，无法继续）
✅ 正确：开新实例 → 迁移数据 → 验证 → 关旧实例
```

对于**原地改机型**（不换实例盘），则是：
```
✅ 原地改：停止 → 改机型 → 启动（EBS 卷保留，数据不丢）
```

### 何时用原地改 vs 迁移

| 场景 | 方案 |
|------|------|
| 只嫌机型太小，同一台机器 | **原地改**（stop → modify → start） |
| 想换区域、换 AMI、换机器 | **迁移**（先开新的，再搬数据） |

## 原地改机型（In-place Resize）

1. **获取实例信息**（IMDSv2 元数据服务）：
   ```bash
   # 获取 token（IMDSv2 需要）
   TOKEN=$(curl -s -X PUT "http://169.254.169.254/latest/api/token" \
     -H "X-aws-ec2-metadata-token-ttl-seconds: 60")
   
   # 查询
   curl -s -H "X-aws-ec2-metadata-token: $TOKEN" \
     http://169.254.169.254/latest/meta-data/instance-type
   curl -s -H "X-aws-ec2-metadata-token: $TOKEN" \
     http://169.254.169.254/latest/meta-data/instance-id
   curl -s -H "X-aws-ec2-metadata-token: $TOKEN" \
     http://169.254.169.254/latest/meta-data/public-ipv4
   curl -s -H "X-aws-ec2-metadata-token: $TOKEN" \
     http://169.254.169.254/latest/meta-data/placement/availability-zone
   ```

2. **检查弹性 IP**：无弹性 IP 的实例停机后公网 IP 会变，Telegram 需重新连接（自动重连，但 DNS/SSH 地址会变）。检查方法：
   ```bash
   curl -s -H "X-aws-ec2-metadata-token: $TOKEN" \
     http://169.254.169.254/latest/meta-data/network/interfaces/macs/ | \
     while read mac; do
       curl -s -H "X-aws-ec2-metadata-token: $TOKEN" \
         "http://169.254.169.254/latest/meta-data/network/interfaces/macs/${mac}association/allocation-id"
     done
   # 有输出 = 有弹性 IP；空 = 无
   ```

3. **AWS CLI 可用性检查**：
   ```bash
   which aws || echo "无 aws cli"
   aws sts get-caller-identity 2>&1 | grep -q "Unable to locate" && echo "无 IAM 角色/凭证"
   ```
   - 无 IAM 角色 → 无法通过 CLI 操作 AWS（需用户通过控制台操作）
   - 有 awscli 但无凭证 → `apt-get install awscli` 安装（snap 或 apt 都行）

4. **操作步骤**（用户通过 AWS 控制台）：
   - 登录 AWS 控制台 → EC2 → 实例 → 勾选实例
   - 实例状态 → 停止 → 等待"已停止"
   - 右键 → 实例设置 → 更改实例类型 → 选新机型 → 保存
   - 实例状态 → 启动

5. **重启后自动恢复**：
   - Hermes Gateway 是 systemd 服务（`hermes-gateway.service`），`enable` 状态，机器启动后自动启动
   - Telegram bot 使用轮询，重启后自动重连
   - 所有配置、技能、记忆在 `~/.hermes/` EBS 卷上，原样保留

6. **改完机型必须复测模型端点连通性**（本次真实教训）：
   - 换实例后公网 IP 变化、**安全组可能不同** → 之前可用的端点可能全线超时
   - 典型症状：国内 IP 的端点（frp 中转站 `HTTP 000`、sensenova 连接超时）全挂，国际端点（api.deepseek.com）仍通 → 优先怀疑**实例网络出口/安全组出站规则**，不是模型故障
   - 验证：`curl -s -m 15 -o /dev/null -w "%{http_code}" "$BASE/models" -H "Authorization: Bearer $KEY"`；HTTP 000 = 网络层不通
   - 让用户去 AWS 控制台检查新实例安全组的**出站规则**是否允许全部流量（`0.0.0.0/0`）

## 迁移到新实例 / 独立 VPS（跨提供商迁移）

1. **先盘点，后选迁移路线**
   - 本轮授权若仅为审计，只读旧机，不连接新机、不打包、不停启服务、不上传。新机 IP 不等于 SSH 端口；密钥认证须确认允许使用的公钥，不索取私钥。
   - 以实际安装的 unit/drop-in、进程解释器与工作目录、用户及系统 cron、systemd timers、Hermes jobs/profile、数据库、符号链接、外部隧道为清单来源；不能只看项目目录或 active 状态。
   - 覆盖全部用户家目录的私有资产、系统级配置与服务账户、Web UI 状态、SSH/CLI/OAuth/设备身份、业务数据和非 Git 项目；用途不明先保留，不借迁移清理。
2. **保全代码与一致性数据**
   - 检查源码分支、local commits、未提交/未跟踪/ignored 状态、worktree 与 stash；重新 clone、GitHub 镜像或常规 Hermes 数据包不保证含当前本地补丁。保留完整工作树、Git 恢复材料、锁文件和实际已安装依赖版本。
   - 在线 SQLite 用匹配运行时的 backup API；逐库校验，明确跨库原子一致性未保证。不能把 live 主库裸 rsync 后当作一致快照，也不能将 live WAL 与已备份主库混装。Redis、PostgreSQL、容器卷另按实际存在情况做一致备份。
   - 现有备份逐通道核验真实包成员、哈希、时间与恢复验证；“打包规则包含”“本地包验证”“异地当前存在”“取回解密恢复”四种证据分开。公钥证书不能解密，不读取私钥正文来做盘点。
   - 传输与归档保持私有、加密和最小权限，不提交凭据到 Git，不把敏感大包作为聊天附件。先核算暂存空间和出网预算，不在小旧机上盲目复制整个根盘再压缩。
3. **新机隔离恢复，保留旧机独立控制入口**
   - 依据新旧系统、CPU 架构、libc、Python/Node、原生模块与服务选项兼容性重建运行环境；虚拟环境和系统二进制不是跨发行版可直接拷贝的保证。不要顺便升级 Hermes/业务版本，或无需要就装 Docker、改 BBR、加新自动化。
   - 恢复原逻辑用户、HOME、路径、权限与服务账户映射；不能把原 `/home/ubuntu` 的服务直接换到 `/root`。保留符号链接及真实目标。
   - 不覆盖新机网络、fstab、machine-id、SSH host keys 或 cloud-init；系统配置按需适配，保留带外控制与回滚。
   - **并行的是机器准备和离线验证，不是同身份业务同时在线。** 新机首次恢复禁用/隔离真实 Telegram polling、Telethon session、OAuth refresh、DDNS、Cloudflare tunnel、定时任务和队列消费者，避免抢登录、重复写入/发信/下发。
   - `desktop-commander-remote.service` 是受保护外部控制入口；普通整机迁移授权不等于入口停用/重启/撤销授权。单独核实外部客户端依赖与工具会话状态，验证独立恢复入口后才可按所有者明确授权最小交接，旧入口不得被批量脚本间接中断。
4. **分组切换和真实验收**
   - 接入获准后先只读确认新机磁盘、系统、端口、公钥及救援控制台；隔离副本核对哈希、权限、SQLite/FTS、依赖、网页鉴权和本地权限测试。
   - 要切业务时明确影响、备份、最终增量和回滚；逐组先交出旧机该身份的写/消费权，再启新机并真实验收，不能要求所有真实消费者两边同时运行后才停旧。
   - 验收覆盖完整链路：Hermes 记忆/历史/模型、Web UI、Bot收发、队列去重、媒体流水线、外部工作节点、隧道、定时任务和备份。端口监听、HTTP首页或 active 不等于全功能恢复。
   - 按清单逐项计数，不遗漏项；未验证就写未验证。旧机继续保留作回退；关机/退役/删除需另行明确授权，不承诺零停机或绝对无丢失。

## 迁移长任务：接续执行与进度证据

- **开始窗口不等于已调度。** 约定日期须实读时钟并按 Asia/Shanghai 换算；分别记录“计划窗口”“提醒”“实际执行任务”。没有创建并验证任务就不能说到点会自动开工；不得让用户靠追问才发现停在上一阶段。
- **后台传输退出，不会自动启动下一步。** 启动前明确接续者和成功门禁；单个 `terminal(background=True, notify_on_complete=True)` 只覆盖那条命令。跨会话流程应使用已获准、可恢复的有限阶段执行器或现有调度能力；没有接续者时明确说“该批完成后将停在校验前”，不能承诺持续无人值守迁移。不要为此擅自新增常驻巡检。
- **状态与产物一起持久化。** 每批至少记录批次、源范围/排除项、原始采样时间与时区、各管道退出码、字节数/哈希、当前阶段、下一步、阻塞与是否已切业务。恢复会话先读回执并核实目标机，不只依赖内存或旧 process ID；进程句柄失效不等于任务失败或成功，也不应因此重跑。
- **分开报告完成层级。** 传输完成 → 两端密文相符 → 认证解密/解压通过 → 包成员与清单核对 → 隔离恢复与业务验证 → 最终增量/单写者交接。只能按已实际通过的层级汇报；归档内生成成员哈希只是建立清单，没有源端对照不能叫“逐文件一致”。
- **小样本不证明大包恢复。** 大量传输前，接收端用实际工具/版本验证代表性大小的加密与解密链路、资源预算及认证失败门禁。只成功解密小 fixture，不足以批准任意大小主包；未解出的密文即使哈希相同也不是可恢复备份。未验证的解密补救方案不得写成可靠流程。
- **热归档与一致快照分开。** `tar` 返回 1 必须逐项读警告，不能统一视成功；若是文件读取中变化，只能标作保全材料，切换前还需一致数据库快照和增量。socket/设备节点不应作为可复原运行状态；归档成员数、库文件数、现役库数、历史/隔离库数分别统计。
- **进度汇报短而诚实。** 固定给“截至实测时间、已完成、当前动作/真实卡点、尚未开始、旧机影响”。未知总量不报百分比，不把“传输结束后停住”继续说成正在传，不宣称固定分钟数无损回退。若发生接续遗漏，直接承认并说明当前实际动作。

取证层级、已验证接入方法与阶段回执设计见 `references/migration-progress-and-verification.md`。

## 切换期实测坑（2026-10-27 单写者切换）

- **SQLite 一致快照被残留 WAL 重放弄脏**：一致快照 `state.db` 拷到新机后仍报 `2nd reference to page`。根因是同目录残留从撕裂在线副本带来的 `state.db-wal` / `state.db-shm`，SQLite 打开时把旧 WAL 重放到干净库上。修法：先删 `*.db-wal` `*.db-shm` 再放库；验收要五项一起看 `PRAGMA quick_check`、`integrity_check`、`page_count`、业务表行数、`foreign_key_check`，只看 quick_check 会漏。
- **新机镜像可能把 `/`、`/home`、`/var` 设成 `0700 root`**：所有 `User=<非root>` 服务直接 `status=200/CHDIR` 起不来，日志常伴随 `Failed to connect stdout to the journal socket, ignoring: Permission denied`。上线非 root 服务前先 `stat -c '%a %U:%G' / /home /var`，Debian 默认应 `755`；`/home/<user>` 保持 `750` 且属主该用户。
- **user-scope unit 不能用 root 的 `systemctl --user` 管**：`ssh root@` 下 `systemctl --user` 操作的是 root 的管理器，`is-active` 返回空、`enable` 报 `Unit file ... does not exist`。必须 `sudo -u <user> XDG_RUNTIME_DIR=/run/user/<uid> systemctl --user ...`，并先 `loginctl enable-linger <user>`。
- **开 linger 前先摘掉不该开机自启的 user unit 软链**（尤其受保护控制入口）：清 `~/.config/systemd/user/default.target.wants/` 里对应 symlink，否则 linger 一开就被拉起。
- **切单写者时给旧机存量消费者挂临时桥**：旧机 `systemd-run --user --unit=<name> ... ssh -N -L 127.0.0.1:PORT:127.0.0.1:PORT 新机`，旧机上的 bot / agent 继续用原地址访问已迁走的上游，等消费端迁完再 stop 拆桥。同时 `disable` 旧机 unit（文件保留），防重启后复活第二个 OAuth 写者。
- **停掉 ≠ 停了：先找「复活者」再切**：旧机 cron 守护（本轮 `lemon_ops_guard.py` 每 5 分钟 `systemctl restart`）、`Restart=always`、health/watchdog timer 都会在几十秒内把刚停的服务拉回来，新机随即刷 `Conflict: terminated by other getUpdates`（409），极易误判成「新机多实例」。停之前枚举 `crontab -l` / `/etc/cron.d` / `list-timers` / `grep -rln "systemctl restart <svc>"`，注释或 disable 后**等过一个完整守护周期**再复查 `is-active` + 进程计数；这些守护脚本本身也是待迁资产，迁完要在目标机重新启用。
- **DDNS 不能两边同时开**：两台各跑 DDNS 会把同一条 A 记录改成自己的 IP 来回打架。切前 disable 旧机 timer，切完在目标机启用即自动把记录指向新机（先读配置确认它管哪些记录，别把不该动的记录一起改）。
- **agent 自己可能挂在被切的服务下**：切 Hermes/Web UI 前先 `ps -o ppid=,cmd=` 回溯祖先链；若祖先就是待停 unit（本轮会话挂在 `hermes-web-ui` 的 agent-bridge 下），停它即切断自己。改由**目标机**持迁移密钥反向 SSH 回旧机驱动「停旧→快照→拉增量→起新→验收」，脚本用 `systemd-run --unit=... --collect` 脱离会话，日志落盘。
- **日志窗口从重启点算起**：`journalctl --since "-5min"` 会把修复前的冲突行算进来造成假阳性，改用 `ActiveEnterTimestamp` 之后的时间点，并在结论里写明统计区间。
- **切业务阶段按组走固定七步**：分组模型（网关/会话客户端/Bot/Agent+UI/调度）、端口绑定顺序（旧隧道→旧服务→新服务→新隧道）、哈希门禁必须在**新机启动前**、按服务类的验收判据（401 不等于失败、precheck 不等于挂上、`is-active` 不等于功能恢复）、`disable` 之后回滚不是「重启一下」、rsync rc=23 静默漏拷 root 属主子目录 —— 全部见 `references/single-writer-cutover-runbook.md`。
- **Caddy/反代本地验收严禁裸连 IP（SNI 缺失误判故障）**：`curl https://127.0.0.1/ -H "Host: domain"` 不发 TLS SNI 扩展，Caddy 匹配不到域名证书直接抛 `TLS alert: internal error (592)`，curl 退出码返回 `000`。若自动化切换脚本据此做健康检查，会误判服务故障并触发无谓回滚！正确验收姿势：必须使用 `curl -sk --resolve <domain>:443:127.0.0.1 https://<domain>/`，显式携带 SNI 握手。
- **标准系统目录权限漂移排查（镜像预置非标准权限陷阱）**：部分商业/精简 VPS 镜像（如 GreenCloud Debian）会意外将 `/`、`/home`、`/var` 或 `/var/lib` 设为 `0700 root:root`。这会导致两大隐蔽故障：① 任何非 root 运行的服务（如 Caddy `User=caddy` 读 `/var/lib/caddy`、Web UI 读 `/home/ubuntu`）直接报 `status=200/CHDIR` 或 `permission denied` 无法读取证书与状态；② `journald` socket 无法被非 root 进程连接，日志静默丢失。新机上线前必须执行基线扫描：`for d in / /etc /usr /var /var/lib /var/log /tmp /run /opt /home; do stat -c "%a %U:%G %n" "$d"; done`，将标准系统目录规范修复为 Debian 默认的 `0755 root:root`（`/tmp` 为 `1777`）。
- **专用系统服务账户（System User）迁移遗漏**：依赖独立系统账户（如 `User=monitor-agent`）的 systemd 服务，若未随迁移脚本在新机创建对应用户与用户组，启动时会瞬间报 `217/USER` 退出死循环（restart counter 飙升）。迁移前除业务普通用户（如 `ubuntu`、`codexops`）外，必须通过 `grep -rhE "^(User|Group)=" /etc/systemd/system/` 提取所有自定义服务账户，在新机通过 `groupadd --system` 与 `useradd --system --shell /usr/sbin/nologin` 预先补齐。

- **冻结的旧机 crontab 会伪装成「没有任务要迁」**：为单写者把旧机 cron 行整行注释后，旧机 `crontab -l | grep -vc '^#'` 是 0，目标机 `crontab -l` 报 `no crontab for <user>`，两头都「干净」，实际十几条备份/流水线/看门狗全丢且不报错。判定要直接读 `sudo cat /var/spool/cron/crontabs/<user>`，去冻结前缀后在目标机 `crontab <file>` 重装并复核条数；为单写者而注释的守护在目标机要恢复启用，装前逐条 `[ -e <script> ]` 校验路径。
- **切换后特权平价会静默降级**：老 AWS/Ubuntu 镜像由 cloud-init 给 `ubuntu` 开 `NOPASSWD` sudo，商业 VPS 的 Debian 镜像默认没有；切换后 agent 以非 root 运行，`apt`、重启系统服务、改 `/etc`、读 root-only 证据目录全部失败却不提示「权限姿态变了」。收尾必做 `ls /etc/sudoers.d/` 两端对比 + `sudo -n true` 实测；需要恢复时先 `cp -a /etc/sudoers` 备份，再写 `90-<user>-nopasswd` 并 `visudo -c -f` 校验，同时明确告知所有者这是一次安全姿态变更。
- **验收计数按清单集合比，不按名字模式 grep**：`systemctl list-timers | grep -E 'lemon|hermes'` 会把不含这些词的 timer（本轮 `emby-v6-watch`、`gemini-quota-daily`、`gemini-recovery-revert`）判成未迁移，实际都 `enabled`。正确做法是从旧机盘点取单元名集合，在目标机逐个 `is-enabled`/`is-active` 比对，差异集为空才算过；grep 命中数只能当线索。
- **切换后反连旧机/自取 root 的 known_hosts 陷阱**：迁移密钥的 `known_hosts` 只钉了目标机，从新机连旧机会 `Host key verification failed`（不是密钥问题）。先 `ssh-keyscan -t ed25519 <ip>` 并用 `ssh-keygen -lf` 与台账指纹逐字比对，一致才追加，不一致就停；切换后 agent 以非 root 运行且迁移目录 root-only 时，可用迁移密钥 `ssh -i <key> root@127.0.0.1` 取回 root（先 keyscan `127.0.0.1` 核对该机自身指纹）。
- **DNS 翻转必须在本机验收之后并内置回滚**：固定顺序「停旧 → 最终快照 → 拉增量 → 起新 → 本机验 `webui` 与 `https` → 通过才 enable DDNS」；不过就重启旧机 web 栈并中止，不翻 DNS。本机 `curl https://127.0.0.1/` 的 `000` 可能是缺 SNI 的假故障，用 `--resolve` 重测再决定回滚。切完的独立证据是三条同看：DNS 连续多次解析到新 IP、旧机 `80/443` 已关只剩 SSH、外部域名 `https=200`。
- **Systemd Timer 仅 enable 未 start 导致定时静默失联**：`systemctl enable foo.timer` 仅建立 `timers.target.wants` 开机自启符号链接，当前运行态仍为 `inactive`！若切换脚本未执行 `systemctl start` 或 `enable --now`，所有定时任务（备份校验、证书检查、补丁守卫、存储维护、监控等）将静默停止触发，表面看 `is-enabled` 绿灯欺骗性极强。上线必须显式使用 `systemctl enable --now <timer>`，并用 `systemctl is-active <timer>` 二次确认。
- **Timer 迁移丢掉配对 Service 单元（FragmentPath 为空陷阱）**：仅打包迁移 `*.timer` 容易漏掉配对的 `*.service`。Timer 虽然可以正常 `active`，但一旦到达触发时刻调度对应的服务时，因 service 不存在直接静默报错或 `status=not-found`。迁移时必须对齐拉取 `*.timer` 及其对应的同名 `*.service`。
- **双机共存阶段反向 SSH 隧道双写/端口竞争冲突**：旧机停止主业务后，其后台常驻的端口反向转发服务（如 `lemon-quote-tunnel`、`migration-cpa-bridge`）若仍在运行，会导致两台主机同时向远端服务器（如 `vps-la:4888`）建立反向隧道发生冲突，或旧机继续监听 8317 造成业务回流。拆除过渡桥必须三步闭环：① `systemctl stop <tunnel>`；② `systemctl disable <tunnel>`；③ 在旧端与远端执行 `ss -ltn | grep :PORT` 确实验证监听数归零。
- **Root 与 User crontab 双重装入陷阱（任务双跑与 root 属主污染）**：自动化脚本以 root 运行调用 `crontab <file>` 若未显式带 `-u <user>`，会将任务装进 root 的 spool。导致两份完全一样的定时脚本每分钟并发跑两遍，加重 API 限制；更严重的是 root 跑出的状态文件（如 `status/*.state.json`、`status/memory-trend.tsv`）会是 `root:root 0600`，使后续普通用户运行的日常备份（`tar czf`）直接因 `Permission denied` 致命退出（`fatal_tar_status`）。切换后必须检查 `sudo crontab -l -u root`，多余的立刻 `sudo crontab -r -u root` 并 `chown` 恢复文件属主。
- **常驻服务持有已删除 Inode 陷阱（Unlinked SQLite Inode / Deleted WAL FD）**：若在常驻服务（如 `hermes-gateway`）启动之后再覆盖或更新数据库（如 `cp state.db ...` 或清理旧 WAL），进程会一直读写在已 unlinked 的旧 Inode 上（通过 `ls -l /proc/<pid>/fd/` 显示 `(deleted)`）。导致三大恶果：① 服务新产生的消息不会写入磁盘，下次重启全部丢失；② 规范备份脚本的健康门禁扫描到 deleted WAL FD 直接中止；③ 级联导致异地加密备份因缺少当天基础快照组件直接崩溃（`Snapshot file missing or symlinked`）。任何数据库覆盖后，必须先扫描活跃服务 FD，有 deleted 则立即 `systemctl restart` 重绑真实 Inode，并完整实跑一次端到端备份验证。
- **Hermes Cron 随迁引发宿主特异性监控误报刷屏**：迁移 Hermes 数据时，`hermes cron` 任务表与 `~/.hermes/scripts/` 脚本会全量同步至新机。若旧机有专属本地服务的探针任务（如本轮 `daa275f93227`「Codex 远程链路监控」，执行 `codex-relay-alert.sh` 本地检测 `desktop-commander-remote.service`），而该服务作为受保护控制入口仍留存在旧机、新机并未启动时，新机定时脚本会在本地判定为 `inactive`，每 30 分钟向 Telegram 发送虚假告警。**处置规范**：迁移核对时须对齐 `hermes cron list`，区分通用任务与宿主机独有监控；对留存在旧机的服务，在新机必须立即 `hermes cron pause <job_id>` 暂停任务，或将监控脚本适配为通过 SSH 探针检测旧机，禁止任由空置告警周期性骚扰用户。

## 隔离恢复与迁移回归门禁

- **用户期待完整接管，而非几个目录搬完。** 账号授权、本地补丁/未跟踪资产、CLI 状态、Web 上传、库与队列、系统单元和跨机链路都要有清单；远端/云端系统先核实归属，通常留原位，只交接主控承担的管理任务。
- **先认证再恢复。** 两端密文 SHA256 相同只证明传输一致；流式解密须完整验证认证标签，验证前明文仅留私有隔离 `.part`，不可直接管入 tar 解包。代表性大样本和坏标签/截断/错误哈希/禁止覆盖测试通过后，才处理真实大包；窄格式实测补救及边界见 `references/authenticated-archive-recovery.md`。
- **跨发行版先验证，不无谓升级。** 保存实际解释器、包版本、锁文件差异及链接目标，在断网、只读代码、空 HOME 的环境验证。虚拟环境不能默认可搬，也不能仅因 OS 不同就断言必须全重建；解释器/导入成功仍不等于应用恢复。
- **失败先做同版本对照，不为全绿改语义。** 源端与目标使用同一工作树内容（含未提交修改）、依赖与 fixture；逐个比较失败 case ID、断言和日志，不只比失败数。两端都失败只能说明可能已有问题，不能证明安全、不能当通过，也不授权改线上逻辑或放宽测试。
- **可选包与真实依赖分开。** 导入缺失先对照源环境与实际调用路径；测试工具缺失不等于业务依赖丢失，不借迁移盲目安装/升级。
- **隔离必须可证实。** 网络命名空间、私有 mount、只读源码与空 HOME/HERMES_HOME/CODEX_HOME配套，禁挂真实 SSH/OAuth/session/聊天库并禁自动插件/懒安装。父目录将被遮蔽时，先把源码/运行时 bind 到临时树，再递归 bind 临时树；否则后续 mount 的源会解析到被遮蔽的空路径。结构见 `references/isolated-migration-validation.md`。
- **报告证明到哪一层。** 解包后与归档成员清单核对只证明归档→恢复文件一致，不是与持续变化的线上源逐文件一致；ACL/xattr、特殊节点、绝对软链接、热库、最终增量各列门禁。未验收或没有接续者就明确停点，不承诺固定时长无损回退。

## 磁盘空间与资源优化（小盘/小内存 EC2 实例维护）

在 20-30G EBS 小系统盘、2GB RAM（如 t3.small / lightsail）的 EC2 实例上，长时间构建/运行后资源调优要点：

### 1. 磁盘占用排查与清理
- **排查占用避坑（必须加 `-x` 避免跨文件系统超时）**：
  ```bash
  # 严禁直接 sudo du -h -d 1 /（极易卡死在 /proc、/sys 或挂载点导致超时）
  # 必须使用 -x (--one-file-system) 限制在根文件系统内：
  sudo du -hx -d 1 / 2>/dev/null | sort -hr
  # 查看 home 下大目录与大文件
  du -h -d 1 /home/ubuntu 2>/dev/null | sort -hr | head -n 15
  find /home/ubuntu -type f -size +50M -exec ls -lh {} + 2>/dev/null
  ```
- **常见空间大户与安全清理**：
  - `uv` 缓存：`uv cache clean`（`~/.cache/uv`，常占数百 MB；先确认无并发安装、构建或运行依赖，再按授权清理）。
  - `npm` 缓存（注意排查普通用户与 root 双重缓存）：
    - `npm cache clean --force`（`~/.npm` 与 `/root/.npm`，可能累积 1.2G+；先排除 npx 常驻依赖和并发安装，再按授权清理）。
  - pip 缓存：`pip cache purge`（`~/.cache/pip` 与 `/root/.cache/pip`）。
  - apt 安装包缓存：`sudo apt-get clean`（清理 `/var/cache/apt/archives`，可腾出上百 MB）。
  - Hermes 历史损坏与冗余备份轮转：
    - `~/.hermes/state.db.pre_fkfix_*`、`~/.hermes/state_db_backup_*`。
    - **SQLite 自动自愈与救援残留**：`~/backups/state_autoheal_*.db`、`state_pre_fts_rebuild_*.db`、`state_rescued_*_clean.db`。每次 FTS 重建或数据库自愈都会生成整库备份（单个 80MB~140MB），几天累积即可消耗 500MB+，定期审计必须检查并保留经验证的恢复点；删除候选必须单独审查并获批，不能仅按日期或数量删除。
    - `~/backups/hermes-*`：只读核查容量与有效备份；轮转仅由专用备份脚本管理。禁止用文件名排序后批量删除，禁止在日常清理中轮转快照。
    - 废弃的旧虚拟环境（如遗留的 `.venv` vs 当前活跃的 `venv`，删除前确认无服务调用）。
  - **Git 仓库跟踪二进制压缩包的恶性膨胀与 gc 超时避坑**：
    - 若自动备份脚本将构建生成的 `*.tar.gz` 频繁 commit 进 git 仓库，`.git` 历史对象会以每天数十至数百 MB 膨胀（即使单个文件只有几十 MB）。
    - ⚠️ **避坑**：在单核 / 1.9GB RAM 低配实例上，对数百 MB 二进制 loose objects 的仓库直接前台运行 `git gc --prune=now` 会极度消耗 CPU 与内存，极易触发 180s+ 命令超时或引发 Swap 颠簸。大仓库优化应使用后台执行或轻量打包参数。
  - `/tmp` 目录安全清理规则：
    - **严禁执行 `rm -rf /tmp/*`**（会误删如 `hermes-agent-bridge.sock`、redis 或 systemd 活跃 socket/锁导致崩溃）。
    - 仅定向清理已过期的独立测试/压测目录（如 `sim_drill_*`、`pytest-*`、`*e2e`、解压测试的临时二进制如 `xray_bin`）。
    - 清理前确认生产者和任务生命周期，并用 `lsof /tmp/<target>` 辅助检查；无 lsof 输出不等于可安全删除。
  - **PyTorch & CUDA 巨头瘦身（实测可释放 ~4.5GB - 5.5GB）**：
    - 纯 CPU 实例（如 1.9GB 内存 t3 系列）若因 `marker-pdf` / `surya-ocr` 等引入 CUDA 版 torch（`nvidia-*` 驱动库 ~2.7G + `torch` ~1.1G + `triton` ~700M），属于巨大空间浪费且会导致 OOM。
    - **安全卸载流程**：
      1. 脚本核查反向依赖：使用 `importlib.metadata` 确认业务代码无直接依赖；
      2. 批量卸载：`uv pip uninstall --python <path_to_venv_python> marker-pdf surya-ocr torch torchvision triton cuda-bindings cuda-pathfinder cuda-toolkit nvidia-cublas nvidia-cuda-cupti nvidia-cuda-nvrtc nvidia-cuda-runtime nvidia-cudnn-cu13 nvidia-cufft nvidia-cufile nvidia-curand nvidia-cusolver nvidia-cusparse nvidia-cusparselt-cu13 nvidia-nccl-cu13 nvidia-nvjitlink nvidia-nvshmem-cu13 nvidia-nvtx`；
      3. 校验依赖图谱：`uv pip check --python <path_to_venv_python>` 确认无断裂；
      4. 验证核心服务（`hermes-gateway` 等）正常运行。

### 2. 磁盘排查避坑：uv 硬链接导致 lsof / fuser 误报占用
- **现象**：排查废弃临时虚拟环境（如 `~/.ocr_tmp`）是否能删除时，执行 `lsof +D ~/.ocr_tmp` 显示常驻关键服务（如 Hermes Gateway、lemon-userbot）正在读取该目录下的 `.so`。
- **根因**：`uv` 构建不同虚拟环境时默认使用硬链接（Hard Link），使得多个 venv 共享相同的底层 inode。`lsof` 依据 inode 检索映射，会将正在运行的正常 venv 关联的 inode 以临时目录路径列出，造成“该临时目录正在被系统关键进程使用”的假象。
- **验证与确认方法**：
  1. `ls -l <file>` 查看 link count，若 > 1 说明存在多重硬链接；
  2. `ps aux | grep <pid>` 查看进程启动命令，确认其 `--python` 或工作目录实际指向主环境（如 `~/.hermes/hermes-agent/venv`）；
  3. 确认进程未直接使用临时目录作为执行入口后，删除临时目录仅会递减硬链接计数，不会破坏正在运行的主环境。

### 3. 内存（RAM）与常驻进程排查
- **排查命令**：
  ```bash
  free -h
  df -h /tmp  # ⚠️ 关键：检查 tmpfs 占用了多少物理内存
  ps aux --sort=-%mem | head -n 15
  vmstat 1 5
  ```
- **核心判定标准**：
  - 真正可用内存看 `available` 列，而非单纯看 `free`（Linux 默认会将空闲 RAM 借给 `buff/cache` 加速磁盘 IO，程序需要时会秒级自动回收）。
  - **🔥 警惕 `/tmp` tmpfs 偷吃物理内存陷阱**：
    - 在 Ubuntu EC2 实例中，`/tmp` 默认挂载为 `tmpfs`（直接消耗物理 RAM）。
    - 压测、脚本验证、音视频处理（如测试用的 `*.mp4`、`*.mp3`、benchmark 生成的文件）如果落在 `/tmp`，会**原样吃掉物理 RAM**！在 1.9GB RAM 小实例上，数百 MB 的测试媒体残留会直接挤爆内存，逼迫系统将常驻服务打入 Swap 甚至触发 OOM。
    - 排查时如果发现 Swap 高且物理内存紧张，优先执行 `ls -lhS /tmp | head -n 15`，定向清理遗留的大媒体和测试文件。
  - 检查 Swap 负载：通过 `vmstat 1 5` 观察 `si` (swap in) 与 `so` (swap out) 列。若 `si=0, so=0` 且 I/O 等待 `wa=0%`，说明 Swap 中为历史构建留下的冷数据，系统无颠簸（Thrashing），不必焦虑；若空闲 RAM 充足想重置指标，可执行 `sudo swapoff -a && sudo swapon -a`。

### 4. 自动化常态化维护（Cron 守护模式）
使用 `templates/daily_cleanup.sh`，先备份当前脚本、核对差异，再测试部署；保持现有任务时间不变。
- 先运行 `bash daily_cleanup.sh --dry-run` 验证只读路径；此模式不代表已执行清理。
- 定时脚本只清理超过 7 天的归档 journal 和 APT 包缓存；要求成功退出，失败必须上报，禁止吞错后报告成功。
- 不递归删除共享 `/tmp` 文件，不按扩展名或时间删除 Telethon `.session`，不删除整块 `~/.npm`、`~/.cache` 或音频缓存，避免破坏仍在使用的文件与 npx 依赖。
- 不在日常清理中修改任何 SQLite 数据库、不触发 drop_caches、不轮转备份。数据库维护使用专用审查流程。
- 如需回收临时媒体空间，先确认生产者、专属目录、任务已结束和无占用，预览精确目标并获得相应批准；未建立可靠生命周期前保留文件，不依据 mtime 推断“无人使用”。
- **闲置与无用守护进程释放**：
  - **KVM VPS 固件更新守护进程内存陷阱（fwupd）**：在云服务器与 KVM 虚拟机（如 RackNerd、轻量 VPS）上，`fwupd`（固件升级守护进程）没有任何硬件固件可供更新，却常驻霸占 **200MB ~ 220MB 物理内存**！直接停止、禁用并屏蔽（mask）可瞬间释放巨额 RAM：`systemctl stop fwupd && systemctl disable fwupd && systemctl mask fwupd && pkill -9 -f fwupd`。
  - **Docker 守护进程**：若系统全面采用原生 Systemd + 本地 Python/Node.js 运行，而未跑任何 Docker 容器，后台 `dockerd` + `containerd` 会白白常驻占用 **~52MB** 内存。可安全停用并禁用自启：`sudo systemctl stop docker containerd && sudo systemctl disable docker containerd`。
  - **无 IAM 角色的 AWS SSM Agent 避坑**：若实例未分配 AWS IAM 角色，预装的 `amazon-ssm-agent`（snap 服务）会持续向 AWS SSM 端点发起无效鉴权重试，日志频繁刷屏 `AccessDeniedException: Systems Manager's instance management role is not configured for account`，白白吃掉 **11MB ~ 50MB RAM** 与 CPU 周期。因无 IAM 角色根本无法使用 SSM，可安全停用并禁用：`sudo systemctl stop snap.amazon-ssm-agent.amazon-ssm-agent.service && sudo systemctl disable snap.amazon-ssm-agent.amazon-ssm-agent.service`。

### 5. 删除备份/快照前的冗余性对账（这一步不能省）

用户明确要求过：**"你得先确认那个没用了 你才能删掉"**。"看起来是一次性目录 / 看起来已经传上去了"都不算确认。

**核对清单（缺一项就不能删）**：

1. **全盘引用检索**：`rg -l '<目录名>' /home/ubuntu /etc/systemd /etc/cron*` —— 命中只在目录自身内部才算无引用。
2. **无进程占用**：`lsof +D <dir>`（空输出是必要条件，不是充分条件）。
3. **无 git worktree 注册**：`git worktree list` 确认没有仓库把它当工作树。
4. **无本地独有提交**：`git reflog` 只有 `clone`/`checkout` 说明没有本地创作内容。
5. **内容有第二份留存**：把 SHA/提交号拿到**另一个现存仓库或 bundle** 里 `git cat-file -t <sha>` 验证，而不是凭"应该推过了"推断。
6. **备份快照额外一条**：逐项对上远端实际清单（`ls -la vps-la:<远端目录>/*.enc`），**本地有、远端无的那一份就是唯一留存，绝对不能删**。

**真实险情**：某次按"清掉最旧两份"准备删 10-18/10-19 的备份快照，逐项对账才发现 10-19 那次上传失败、远端根本没有对应包 —— 差一步删掉唯一副本。**先对账，再给建议**；给用户列"可删清单"时就要把"远端有无对应副本"一列摆出来。

**失败任务的清理步骤会永久不跑（`set -e` 级联）**：备份/构建脚本常写成 `set -euo pipefail` + 末尾 `prune`/`rm` 收尾。任何一步失败 → 收尾永不执行 → 产物按天累积 → 磁盘更满 → 下次失败更早 → 死循环。判据是"产物份数 > 策略允许的份数"。看到这种堆积，**先修失败点，别只删产物**，否则明天照样堆。

**保护"唯一留存"不被自动轮转删掉**：轮转脚本通常用 `re.fullmatch(r'[0-9]{8}_[0-9]{6}', name)` 选目标。给目录加后缀（`20261019_033003.keep-nooffsite`）即不匹配，比改生产脚本安全（不动代码、可逆、语义自解释）。

### 6. 迁移工作目录的分级清理（整机迁移收尾必做）

整机迁移会在目标机留下一个巨大工作目录（实测 `/var/lib/hermes-migration/<date>/` 占 **29G**，把 113G 的盘推到 41%）。用户问「磁盘怎么都用了 40%」时，**先定位到这个目录再谈业务数据**——它不是业务增长，是脚手架。

定位链条：`df -h /` → `sudo du -x -d1 -h /`（`/var` 最大）→ `sudo du -x -d1 -h /var/lib` → 命中 `hermes-migration`。

⚠️ **`sudo du -sh $DIR/*` 会静默失败**：glob 由**非 root 的当前 shell** 展开，root-only（0700）目录列不出来，命令退化成无参数 `du -sh` 并被 `2>/dev/null` 吞掉，输出空白——看起来像"目录是空的/命令没跑"。必须 `sudo sh -c "du -sh $DIR/*"`，让 root 侧展开。

**按「旧机是否还活着」分三档，不能一刀切**：

| 档 | 典型内容 | 何时可删 |
|---|---|---|
| **脚手架** | `staging/`（解压验证副本）、`recovery-tools/<test-tmp>/`、`*-payload.json`（二进制 base64 中转） | **现在**——现役已在真实路径，`/proc` 零引用 |
| **回退资产** | `archives/`（加密整机包）、`old-final-snapshots/`、`final-snapshots/`、`transport-key/`、`reverse-ssh/` | **旧机 terminate 之后** |
| **证据** | `evidence/`、`*-report.json`、`before-bootstrap/` | 长期保留（几十 MB，是"当时到底改了什么"的唯一记录） |

两条硬规则：

- **解密私钥与密文同生命周期**：`transport-key/` 与 `archives/` 必须一起删或一起留。单删私钥 → 包永久打不开；单删包 → 私钥成了无主凭据。
- **`reverse-ssh/` 是凭据残留**：它是连旧机的迁移密钥，旧机退役后必须清，别当普通文件留着。

删除前占用核查（不依赖额外二进制）：`lsof +D` 可能因 uv 硬链接误报（见 §2），`fuser` 也不一定装。直接扫 `/proc` 同时看 fd 和 cwd 最可靠：

```bash
sudo python3 - <<'PY'
import os
target = '/var/lib/hermes-migration'
hits = []
for pid in filter(str.isdigit, os.listdir('/proc')):
    try:
        for fd in os.listdir(f'/proc/{pid}/fd'):
            t = os.readlink(f'/proc/{pid}/fd/{fd}')
            if t.startswith(target): hits.append((pid, t))
    except OSError: pass
    try:
        if os.readlink(f'/proc/{pid}/cwd').startswith(target): hits.append((pid, 'CWD'))
    except OSError: pass
print('OCCUPIED:', hits[:5] or 'none')
PY
```

清理后必须复验四项：`df -h /` 数字、全部核心服务 `is-active`、关键库 `PRAGMA quick_check`、站点 HTTP 200。实测清 23G 后 14 个服务与两个站点全正常。

**给用户的答复形态是「分档 + 时间表」，不是「能删/不能删」**：用户问「哪些什么时候可以删除」时要给出三列表（项目 / 大小 / 前置条件）和一条时间线（现在 / 旧机 stop 后 / 旧机 terminate 后），并明确写出"旧机还活着时删回退资产等于自断退路"。

## AWS 出网流量与免费额度排查（无 IAM 角色场景）

### 1. AWS 免费额度计费规则（核心原则）
- **入网流量 (Inbound / Download)**：**100% 免费**（$0.00/GB，无限额）。
- **出网流量 (Outbound / Data Transfer Out to Internet)**：AWS 提供全球统一的永久免费额度 **100 GB/月**（除特定受限区域外）。
- **超额单价**：超出 100 GB 后，新加坡（`ap-southeast-1`）等亚太区域公网出网单价约 **$0.114 - $0.12 / GB**。

### 2. 无 IAM 角色时从底层统计流量
```bash
# 查网卡累计收发字节数 (ens5 为 EC2 主网卡)
cat /proc/net/dev
# 查系统开机时间（推算当前统计周期）
uptime
```
- **Receive (Bytes)**：入网总流量（免费）。
- **Transmit (Bytes)**：出网总流量（与 100 GB 免费额度比对）。若开机天数内出网已超 100 GB，则已产生超额计费。

### 3. 常见业务流量特性与避坑
| 业务类型 | 典型场景 | 流量消耗特性 | 风险评级 |
|---------|---------|-------------|---------|
| **云端离线任务** | 追追剧/电影天堂/磁力抓取 → API 下发光鸭/115 离线 | 仅发送微小 JSON API 请求，**出网几乎为 0** | 🟢 极低风险 |
| **TG 直传视频双轨中转** | Telegram 下载 MP4 → 本地中转上传至 Google Drive + 光鸭 | 消耗 **2x 视频体积的出网流量**（双倍上传） | 🔴 极高风险（极易爆表） |
| **PT / 本地下载转存** | qBittorrent 本地下载 → 上传至网盘/做种 | 1:1 消耗出网流量；做种产生额外 P2P 出网 | 🟡 中高风险 |

## 安全组入站规则排障（无 IAM 角色场景）

当 EC2 实例上运行的服务（如 Hermes web-ui 面板 8648 端口）从外网打不开，但本地 `curl 127.0.0.1:端口` 返回 200 时，**几乎肯定是 AWS 安全组未放行入站端口**。

### 诊断流程（纯只读，不需要 AWS 凭证）

```bash
# 1. 获取 IMDSv2 token
TOKEN=$(curl -s -X PUT "http://169.254.169.254/latest/api/token" -H "X-aws-ec2-metadata-token-ttl-seconds: 21600")

# 2. 查安全组名称和 ID
curl -s -H "X-aws-ec2-metadata-token: $TOKEN" http://169.254.169.254/latest/meta-data/security-groups
# 返回如：launch-wizard-1

# 3. 查安全组 ID（通过 MAC 地址）—— 给用户控制台操作用
MAC=$(curl -s -H "X-aws-ec2-metadata-token: $TOKEN" http://169.254.169.254/latest/meta-data/network/interfaces/macs/ | head -1)
curl -s -H "X-aws-ec2-metadata-token: $TOKEN" "http://169.254.169.254/latest/meta-data/network/interfaces/macs/${MAC}security-group-ids/"
# 返回如：sg-03ae9ea2a5b62475e

# 4. 查实例 ID 和区域
curl -s -H "X-aws-ec2-metadata-token: $TOKEN" http://169.254.169.254/latest/meta-data/instance-id
curl -s -H "X-aws-ec2-metadata-token: $TOKEN" http://169.254.169.254/latest/meta-data/placement/region

# 5. 服务器自测公网可达性（确认安全组是唯一瓶颈）
curl -s -o /dev/null -w "%{http_code}" --connect-timeout 5 http://<公网IP>:<端口>/
# 200 = 安全组已放行，问题在别处；000 = 安全组/网络层拦截
```

### 确认无 IAM 角色后，给用户的精确信息

```bash
which aws && aws sts get-caller-identity 2>&1 | grep -q "Unable to locate" && echo "无 IAM 角色/凭证，无法从实例内操作 AWS"
```

无 IAM 角色时，**不要在实例内尝试安装 awscli 或配置凭据**——直接告诉用户去 AWS 控制台操作。给出以下精确信息：

```
需要手动添加一条入站规则到安全组：
- 安全组 ID：sg-xxxxx（从元数据获取）
- 安全组名称：launch-wizard-1（从元数据获取）
- 区域：ap-southeast-1（从元数据获取）
- 类型：自定义 TCP
- 端口范围：<端口号，如 8648>
- 来源：0.0.0.0/0（或指定 IP）
- 操作路径：AWS 控制台 → EC2 → 安全组 → 选择该安全组 → 入站规则 → 编辑入站规则 → 添加规则 → 保存
```

### 风格约定：故障诊断时对用户要有明确结论

用户（爸爸）的风格偏好：**不要详细解释诊断过程，直接给出结果和可操作的下一步**。排查到安全组阻塞后，直接给出安全组 ID、区域、需要添加的规则，然后问用户是否能自己操作或提供凭证——不要回溯每一步做了什么检查。

## Pitfalls

- **IMDSv2 需要 token**：不能用原始方式访问元数据，必须先 `PUT /latest/api/token` 获取 token
- **`hermes model` 需要交互式终端**：管道/非交互下报错，验证用 `hermes chat -q --provider -m` 代替
- **无弹性 IP 时 IP 会变**：停机（Stop/Start）释放公网 IP，新 IP 可在控制台或启动后通过元数据服务获取；系统内 `sudo reboot` 或控制台重启（Reboot）则**保持 IP 不变**。
- **动态 IP 零成本直连方案（Cloudflare DDNS）**：为避免 AWS 弹性 IP 收费（$0.005/小时），采用轻量 DDNS 脚本 + `systemd.timer` 定时/开机同步到域名（如 `aws.yourdomain.com`）。
- **DDNS SSH 直连必须关闭 CDN 代理（灰云）**：Cloudflare DNS 记录必须设置 `proxied: false`（DNS Only），若开启橙色小黄云代理将只转发 HTTP/HTTPS，会导致 SSH（端口 22）及其他非标端口无法连接。
- **`hermes config set` 不能增长 `custom_providers` 列表**：见 `hermes-custom-providers` 技能
- **`read_file` 脱敏 `api_key`**：涉及密钥的读写用 `yaml.safe_load` 直接读原文件
- **无 IAM 角色时不要试图装 awscli**：apt/pip 安装后仍缺凭证，浪费用户时间；直接给控制台操作指引
- **du 根目录扫描必须加 -x 避免超时**：执行 `du -h -d 1 /` 极易卡在 `/proc`、`/sys` 伪文件系统或网络挂载点导致超时，必须使用 `sudo du -hx -d 1 /`。
- **tmpfs 挂载的 /tmp 吞噬物理内存**：在低配 EC2（如 1.9G RAM）上，`/tmp` 默认挂载为 tmpfs，脚本测试或媒体转码留下的 `*.mp4`、`*.mp3` 会直接霸占物理 RAM 并把常驻服务挤压进 Swap，排查高内存/Swap 时切记先查 `df -h /tmp` 与 `ls -lhS /tmp`。
- **KVM / 云 VPS 上 fwupd 内存吃满陷阱**：在虚拟化环境（KVM VPS）中，Ubuntu 默认启动的固件更新服务 `fwupd.service` 无法更新任何真实硬件，却常驻霸占 200MB+ 物理 RAM，应果断 `mask` 禁用。
- **systemd-journald 日志无上限累积**：长时间运行未加配置的系统，`/var/log/journal` 易默默吃掉 1GB~2GB 磁盘空间，排查空间必须将其纳入 `--vacuum-size=100M` 检查项。
- **守护进程严禁依赖 npx 启动**：npx 运行程序存放在 `~/.npm/_npx/` 临时缓存中，一旦触发磁盘/包管理器清理或临时文件回收，正在运行的 node 守护进程将失去磁盘文件，后续尝试动态 spawn 本地 MCP（如 Desktop Commander 报 `Desktop Commander MCP not found`）将全线崩溃。所有生产与常驻 systemd 守护进程必须使用 `npm install -g` 全局固化安装，并在 unit 文件中显式指定 `/usr/local/bin` 绝对路径。
- **安全组检查优先于进程/端口检查**：用户报"面板打不开"时，先确认服务在本地监听且公网不通，再查安全组——不要只查进程状态

## 关联技能

- `hermes-custom-providers` — 配置自定义模型提供商
- `hermes-agent` — 安装、配置、启动 Hermes
- `hermes-gateway-ops` — 面板/web-ui 排障、网关运维

## References

- `references/authenticated-archive-recovery.md` — 大文件流式 CMS AuthEnvelopedData (AES-GCM) 跨机器解密与 OpenSSL 缓冲溢出规避指南
- `references/single-writer-cutover-runbook.md` — 整机迁移的业务切换阶段：单写者分组、七步切换门禁、按服务类验收判据、临时桥、回滚真实形状、rsync 漏拷与权限对照，以及**切换后收尾**（冻结 crontab 伪装成空、sudo 特权平价、按清单集合而非名字 grep 验收、反连旧机/自取 root 的 known_hosts、DNS 翻转与回滚顺序）
- `references/capy-theater-topology-and-migration.md` — Capy 影厅远端 Docker 部署拓扑与主控机管理职责划分实录
- `references/servercat-metrics-interpretation.md` — ServerCat 与移动端运维监控指标解读实录：网络双色比例环误判、截断的「建连...」为 AttemptFails、开机累计硬件流量 vs AWS 月度账单、Linux 页面缓存机制
- `references/security-group-inbound-diagnosis.md` — 安全组入站规则排障实录（无 IAM 角色场景）：元数据查询命令、控制台操作指引
- `references/cloudflare-ddns-setup.md` — 无弹性 IP 场景下的 Cloudflare DDNS 自动化配置与 Systemd Timer 保活实录
- `references/desktop-commander-remote-mcp-ops.md` — Desktop Commander 与 Remote MCP 设备桥接守护运维实录：npx 缓存丢失引发本地 MCP 崩溃、OAuth 设备码换取流程与 Systemd User Service 配置