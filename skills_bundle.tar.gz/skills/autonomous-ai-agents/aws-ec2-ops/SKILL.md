---
name: aws-ec2-ops
description: "AWS EC2 实例运维：机型升级、迁移、元数据查询、Hermes 托管实例管理"
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux]
metadata:
  hermes:
    tags: [aws, ec2, migration, ops, hosting]
    related_skills: [hermes-agent]
---

# AWS EC2 实例运维（Hermes 托管场景）

## When to Use

用户需要操作运行 Hermes 的 AWS EC2 实例：改机型（"机型太小"）、迁移到新实例（"换实例"）、查实例信息、或处理停机/重启场景。**核心约束：这个实例上运行着 Agent 自身，不能先关旧再开新。**

## 核心原则：先建后拆，绝不先关旧的

```
❌ 错误：关旧实例 → 开新实例          （Agent 失联，无法继续）
✅ 正确：开新实例 → 迁移数据 → 验证 → 关旧实例
```

对于**原地改机型**（不换实例盘），则是：
```
✅ 原地改：停止 → 改机型 → 启动（EBS 卷保留，数据不丢）
```

### 何时用原地改 vs 迁移

| 场景 | 方案 |
|------|------|
| 只嫌机型太小，同一台机器 | **原地改**（stop → modify → start） |
| 想换区域、换 AMI、换机器 | **迁移**（先开新的，再搬数据） |

## 原地改机型（In-place Resize）

1. **获取实例信息**（IMDSv2 元数据服务）：
   ```bash
   # 获取 token（IMDSv2 需要）
   TOKEN=$(curl -s -X PUT "http://169.254.169.254/latest/api/token" \
     -H "X-aws-ec2-metadata-token-ttl-seconds: 60")
   
   # 查询
   curl -s -H "X-aws-ec2-metadata-token: $TOKEN" \
     http://169.254.169.254/latest/meta-data/instance-type
   curl -s -H "X-aws-ec2-metadata-token: $TOKEN" \
     http://169.254.169.254/latest/meta-data/instance-id
   curl -s -H "X-aws-ec2-metadata-token: $TOKEN" \
     http://169.254.169.254/latest/meta-data/public-ipv4
   curl -s -H "X-aws-ec2-metadata-token: $TOKEN" \
     http://169.254.169.254/latest/meta-data/placement/availability-zone
   ```

2. **检查弹性 IP**：无弹性 IP 的实例停机后公网 IP 会变，Telegram 需重新连接（自动重连，但 DNS/SSH 地址会变）。检查方法：
   ```bash
   curl -s -H "X-aws-ec2-metadata-token: $TOKEN" \
     http://169.254.169.254/latest/meta-data/network/interfaces/macs/ | \
     while read mac; do
       curl -s -H "X-aws-ec2-metadata-token: $TOKEN" \
         "http://169.254.169.254/latest/meta-data/network/interfaces/macs/${mac}association/allocation-id"
     done
   # 有输出 = 有弹性 IP；空 = 无
   ```

3. **AWS CLI 可用性检查**：
   ```bash
   which aws || echo "无 aws cli"
   aws sts get-caller-identity 2>&1 | grep -q "Unable to locate" && echo "无 IAM 角色/凭证"
   ```
   - 无 IAM 角色 → 无法通过 CLI 操作 AWS（需用户通过控制台操作）
   - 有 awscli 但无凭证 → `apt-get install awscli` 安装（snap 或 apt 都行）

4. **操作步骤**（用户通过 AWS 控制台）：
   - 登录 AWS 控制台 → EC2 → 实例 → 勾选实例
   - 实例状态 → 停止 → 等待"已停止"
   - 右键 → 实例设置 → 更改实例类型 → 选新机型 → 保存
   - 实例状态 → 启动

5. **重启后自动恢复**：
   - Hermes Gateway 是 systemd 服务（`hermes-gateway.service`），`enable` 状态，机器启动后自动启动
   - Telegram bot 使用轮询，重启后自动重连
   - 所有配置、技能、记忆在 `~/.hermes/` EBS 卷上，原样保留

6. **改完机型必须复测模型端点连通性**（本次真实教训）：
   - 换实例后公网 IP 变化、**安全组可能不同** → 之前可用的端点可能全线超时
   - 典型症状：国内 IP 的端点（frp 中转站 `HTTP 000`、sensenova 连接超时）全挂，国际端点（api.deepseek.com）仍通 → 优先怀疑**实例网络出口/安全组出站规则**，不是模型故障
   - 验证：`curl -s -m 15 -o /dev/null -w "%{http_code}" "$BASE/models" -H "Authorization: Bearer $KEY"`；HTTP 000 = 网络层不通
   - 让用户去 AWS 控制台检查新实例安全组的**出站规则**是否允许全部流量（`0.0.0.0/0`）

## 迁移到新实例 / 独立 VPS（跨提供商迁移）

1. **原则：双机并行热迁移，先建后验再停旧**
   - 新 VPS（如 RackNerd / 独立独服）先开通并初始化基础环境（BBR 加速、Docker、Node.js 20+、Python 3.11/3.12、Swap 扩容）。
   - 全量同步配置与数据：`rsync -avz --exclude 'node_modules' --exclude '.cache' --exclude '*.log' ~/.hermes/ root@new-vps:~/.hermes/`
   - 同步辅助服务模块（CLIProxyAPI、UserBot、Ops Bot、Subconverter、爬虫流水线）。
2. **全项连通性与服务端口验收清单**：
   - `8648` (Hermes Web-UI)
   - `8317` (CLIProxyAPI 双账号 Gemini 代理)
   - `8688` (Subconverter 订阅聚合)
   - `8999` (qBittorrent WebUI)
   - Telegram Bots (UserBot + 运维 Bot 消息收发)
3. **确认新环境全部 100% 验收通过后，再停用或降级旧 AWS 实例**。

## 磁盘空间与资源优化（小盘/小内存 EC2 实例维护）

在 20-30G EBS 小系统盘、2GB RAM（如 t3.small / lightsail）的 EC2 实例上，长时间构建/运行后资源调优要点：

### 1. 磁盘占用排查与清理
- **排查占用命令**：
  ```bash
  df -h /
  du -sh /home/ubuntu/.[!.]* /tmp /var/log 2>/dev/null | sort -hr | head -n 10
  ```
- **常见空间大户与安全清理**：
  - `uv` 缓存：`uv cache clean`（`~/.cache/uv`）
  - `npm` 缓存：`npm cache clean --force`
  - Playwright 浏览器内核：`~/.cache/ms-playwright`（约 650MB，用于无头网页抓取）
  - 临时 OCR / 转换缓存：`~/.ocr_tmp`、`/tmp` 遗留临时库
  - Hermes 历史损坏数据库备份：`~/.hermes/state.db.malformed-backup-*`
  - PyTorch CPU vs GPU：纯 CPU 机器若装了 CUDA 版 torch 会多吃 ~4GB 空间。

### 2. 内存（RAM）与常驻进程排查
- **排查命令**：
  ```bash
  free -h
  ps aux --sort=-%mem | head -n 15
  ```
- **核心判定标准**：
  - 真正可用内存看 `available` 列，而非单纯看 `free`（Linux 默认会将空闲 RAM 借给 `buff/cache` 加速磁盘 IO，程序需要时会秒级自动回收）。
- **闲置守护进程释放**：
  - 若系统全面采用原生 Systemd + 本地 Python/Node.js 运行，而未跑任何 Docker 容器，后台 `dockerd` + `containerd` 会白白常驻占用 **~52MB** 内存。
  - 可安全停用并禁用自启：`sudo systemctl stop docker containerd && sudo systemctl disable docker containerd`。

## AWS 出网流量与免费额度排查（无 IAM 角色场景）

### 1. AWS 免费额度计费规则（核心原则）
- **入网流量 (Inbound / Download)**：**100% 免费**（$0.00/GB，无限额）。
- **出网流量 (Outbound / Data Transfer Out to Internet)**：AWS 提供全球统一的永久免费额度 **100 GB/月**（除特定受限区域外）。
- **超额单价**：超出 100 GB 后，新加坡（`ap-southeast-1`）等亚太区域公网出网单价约 **$0.114 - $0.12 / GB**。

### 2. 无 IAM 角色时从底层统计流量
```bash
# 查网卡累计收发字节数 (ens5 为 EC2 主网卡)
cat /proc/net/dev
# 查系统开机时间（推算当前统计周期）
uptime
```
- **Receive (Bytes)**：入网总流量（免费）。
- **Transmit (Bytes)**：出网总流量（与 100 GB 免费额度比对）。若开机天数内出网已超 100 GB，则已产生超额计费。

### 3. 常见业务流量特性与避坑
| 业务类型 | 典型场景 | 流量消耗特性 | 风险评级 |
|---------|---------|-------------|---------|
| **云端离线任务** | 追追剧/电影天堂/磁力抓取 → API 下发光鸭/115 离线 | 仅发送微小 JSON API 请求，**出网几乎为 0** | 🟢 极低风险 |
| **TG 直传视频双轨中转** | Telegram 下载 MP4 → 本地中转上传至 Google Drive + 光鸭 | 消耗 **2x 视频体积的出网流量**（双倍上传） | 🔴 极高风险（极易爆表） |
| **PT / 本地下载转存** | qBittorrent 本地下载 → 上传至网盘/做种 | 1:1 消耗出网流量；做种产生额外 P2P 出网 | 🟡 中高风险 |

## 安全组入站规则排障（无 IAM 角色场景）

当 EC2 实例上运行的服务（如 Hermes web-ui 面板 8648 端口）从外网打不开，但本地 `curl 127.0.0.1:端口` 返回 200 时，**几乎肯定是 AWS 安全组未放行入站端口**。

### 诊断流程（纯只读，不需要 AWS 凭证）

```bash
# 1. 获取 IMDSv2 token
TOKEN=$(curl -s -X PUT "http://169.254.169.254/latest/api/token" -H "X-aws-ec2-metadata-token-ttl-seconds: 21600")

# 2. 查安全组名称和 ID
curl -s -H "X-aws-ec2-metadata-token: $TOKEN" http://169.254.169.254/latest/meta-data/security-groups
# 返回如：launch-wizard-1

# 3. 查安全组 ID（通过 MAC 地址）—— 给用户控制台操作用
MAC=$(curl -s -H "X-aws-ec2-metadata-token: $TOKEN" http://169.254.169.254/latest/meta-data/network/interfaces/macs/ | head -1)
curl -s -H "X-aws-ec2-metadata-token: $TOKEN" "http://169.254.169.254/latest/meta-data/network/interfaces/macs/${MAC}security-group-ids/"
# 返回如：sg-03ae9ea2a5b62475e

# 4. 查实例 ID 和区域
curl -s -H "X-aws-ec2-metadata-token: $TOKEN" http://169.254.169.254/latest/meta-data/instance-id
curl -s -H "X-aws-ec2-metadata-token: $TOKEN" http://169.254.169.254/latest/meta-data/placement/region

# 5. 服务器自测公网可达性（确认安全组是唯一瓶颈）
curl -s -o /dev/null -w "%{http_code}" --connect-timeout 5 http://<公网IP>:<端口>/
# 200 = 安全组已放行，问题在别处；000 = 安全组/网络层拦截
```

### 确认无 IAM 角色后，给用户的精确信息

```bash
which aws && aws sts get-caller-identity 2>&1 | grep -q "Unable to locate" && echo "无 IAM 角色/凭证，无法从实例内操作 AWS"
```

无 IAM 角色时，**不要在实例内尝试安装 awscli 或配置凭据**——直接告诉用户去 AWS 控制台操作。给出以下精确信息：

```
需要手动添加一条入站规则到安全组：
- 安全组 ID：sg-xxxxx（从元数据获取）
- 安全组名称：launch-wizard-1（从元数据获取）
- 区域：ap-southeast-1（从元数据获取）
- 类型：自定义 TCP
- 端口范围：<端口号，如 8648>
- 来源：0.0.0.0/0（或指定 IP）
- 操作路径：AWS 控制台 → EC2 → 安全组 → 选择该安全组 → 入站规则 → 编辑入站规则 → 添加规则 → 保存
```

### 风格约定：故障诊断时对用户要有明确结论

用户（爸爸）的风格偏好：**不要详细解释诊断过程，直接给出结果和可操作的下一步**。排查到安全组阻塞后，直接给出安全组 ID、区域、需要添加的规则，然后问用户是否能自己操作或提供凭证——不要回溯每一步做了什么检查。

## Pitfalls

- **IMDSv2 需要 token**：不能用原始方式访问元数据，必须先 `PUT /latest/api/token` 获取 token
- **`hermes model` 需要交互式终端**：管道/非交互下报错，验证用 `hermes chat -q --provider -m` 代替
- **无弹性 IP 时 IP 会变**：停机（Stop/Start）释放公网 IP，新 IP 可在控制台或启动后通过元数据服务获取；系统内 `sudo reboot` 或控制台重启（Reboot）则**保持 IP 不变**。
- **动态 IP 零成本直连方案（Cloudflare DDNS）**：为避免 AWS 弹性 IP 收费（$0.005/小时），采用轻量 DDNS 脚本 + `systemd.timer` 定时/开机同步到域名（如 `aws.yourdomain.com`）。
- **DDNS SSH 直连必须关闭 CDN 代理（灰云）**：Cloudflare DNS 记录必须设置 `proxied: false`（DNS Only），若开启橙色小黄云代理将只转发 HTTP/HTTPS，会导致 SSH（端口 22）及其他非标端口无法连接。
- **`hermes config set` 不能增长 `custom_providers` 列表**：见 `hermes-custom-providers` 技能
- **`read_file` 脱敏 `api_key`**：涉及密钥的读写用 `yaml.safe_load` 直接读原文件
- **无 IAM 角色时不要试图装 awscli**：apt/pip 安装后仍缺凭证，浪费用户时间；直接给控制台操作指引
- **安全组检查优先于进程/端口检查**：用户报"面板打不开"时，先确认服务在本地监听且公网不通，再查安全组——不要只查进程状态

## 关联技能

- `hermes-custom-providers` — 配置自定义模型提供商
- `hermes-agent` — 安装、配置、启动 Hermes
- `hermes-gateway-ops` — 面板/web-ui 排障、网关运维

## References

- `references/security-group-inbound-diagnosis.md` — 安全组入站规则排障实录（无 IAM 角色场景）：元数据查询命令、控制台操作指引
- `references/cloudflare-ddns-setup.md` — 无弹性 IP 场景下的 Cloudflare DDNS 自动化配置与 Systemd Timer 保活实录