#!/usr/bin/env python3
"""模型用量归因报告（纯只读）。

用法:
  python3 usage_report.py --provider 周三 --days 3
  python3 usage_report.py --provider 周三 --days 3 --db /home/ubuntu/.hermes/state.db

输出: provider 形态清单 / 按天聚合 / 按输入 token 排序的会话明细 / 爆点判定。
不写库、不改配置、不打网络。
"""
import argparse
import collections
import datetime
import sqlite3
import time

DEFAULT_DB = "/home/ubuntu/.hermes/state.db"


def ts(x):
    return datetime.datetime.fromtimestamp(x).strftime("%m-%d %H:%M") if x else "-"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--provider", required=True, help="provider 别名子串，如 周三 / command")
    ap.add_argument("--days", type=int, default=2, help="回看天数，默认 2")
    ap.add_argument("--db", default=DEFAULT_DB)
    a = ap.parse_args()

    cut = time.time() - a.days * 86400
    c = sqlite3.connect(f"file:{a.db}?mode=ro", uri=True)

    print(f"== 窗口: 最近 {a.days} 天  provider LIKE '%%{a.provider}%%'")

    print("\n== 所有 billing_provider 形态（同期，含未匹配项，用于核对别名写法）")
    for bp, n in c.execute(
        "select billing_provider, sum(api_call_count) from session_model_usage"
        " where last_seen>=? group by 1 order by 2 desc", (cut,)
    ):
        print(f"  {bp!r:<20} calls={n}")

    rows = c.execute(
        """select s.id, s.source, s.chat_type, s.title, u.model, u.task,
                  u.api_call_count, u.input_tokens, u.output_tokens,
                  u.cache_read_tokens, u.first_seen, u.last_seen, s.started_at, s.message_count
             from session_model_usage u join sessions s on s.id=u.session_id
            where u.billing_provider like ? and u.last_seen>=?
            order by u.input_tokens desc""",
        (f"%{a.provider}%", cut),
    ).fetchall()

    if not rows:
        print("\n无匹配记录。先看上面的 provider 形态清单，确认别名写法。")
        return

    print("\n== 按天聚合")
    day = collections.defaultdict(lambda: [0, 0, 0, 0])
    for r in rows:
        d = day[datetime.datetime.fromtimestamp(r[11]).strftime("%m-%d")]
        d[0] += r[6]; d[1] += r[7]; d[2] += r[8]; d[3] += r[9]
    for k in sorted(day):
        d = day[k]
        print(f"  {k}  calls={d[0]:>5}  in={d[1]:>9}  out={d[2]:>8}  cacheR={d[3]:>10}")

    tot = [sum(x[i] for x in day.values()) for i in range(4)]
    peak = max(day.items(), key=lambda kv: kv[1][1])
    share = peak[1][1] / tot[1] * 100 if tot[1] else 0
    print(f"\n  合计 calls={tot[0]} in={tot[1]} out={tot[2]} cacheR={tot[3]}")
    print(f"  爆点: {peak[0]} 占输入 {share:.0f}%")
    if tot[0]:
        print(f"  单次平均输入: {tot[1]/tot[0]:.0f} tokens "
              f"({'长会话滚雪球，查 started_at' if tot[1]/tot[0] > 8000 else '正常量级'})")

    print("\n== 明细（按输入 token 降序）")
    hdr = f"  {'session':<30}{'src':<10}{'calls':>6}{'in':>10}{'out':>8}{'cacheR':>11}  {'started':<12} 事由"
    print(hdr)
    for r in rows:
        print(f"  {r[0][:29]:<30}{r[1]:<10}{r[6]:>6}{r[7]:>10}{r[8]:>8}{r[9]:>11}  "
              f"{ts(r[12]):<12} {str(r[3] or '')[:30]}")

    old = [r for r in rows if r[12] and r[12] < cut + (a.days - 1) * 86400
           and (r[13] or 0) > 200]
    if old:
        print("\n== 老长会话（started_at 早于窗口末日 且 message_count>200）—— 续用最烧 token")
        for r in old:
            print(f"  {r[0]}  起={ts(r[12])}  msgs={r[13]}  in={r[7]}")


if __name__ == "__main__":
    main()
