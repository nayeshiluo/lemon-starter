---
name: model-usage-attribution
description: "查某模型/中转站额度为何掉得快：按会话、来源、时间、token 归因 Hermes 用量。"
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux]
metadata:
  hermes:
    tags: [hermes, usage, cost, tokens, quota, attribution, provider]
    related_skills: [hermes-custom-providers, hermes-ai-chain-alert-triage, agent-memory-curation]
---

# 模型用量与额度归因

## When to Use

用户说「某模型/某个站用得特别快」「额度没了」「这两天调用哪里最多」「是不是有东西在偷跑」「谁在烧 token」。目标是**回答「哪里」**（会话 / 来源 / 时间 / 任务类型），不是修故障。

如果要排查的是「报错/回退/告警」，走 `hermes-ai-chain-alert-triage`。要改路由或加减端点，走 `hermes-custom-providers`。

## 第 0 步：确认 provider 在账本里的**真实写法**

用户的说法是「周三」这种自定义 provider 别名，但 `session_model_usage.billing_provider` 里可能同时存在多种形态：`周三`、`custom:周三`、`custom:command`、`command`、以及空串。

```bash
# 先看这三天都有哪些 billing_provider 值，各自多少调用
python3 - <<'EOF'
import sqlite3, time
c = sqlite3.connect("/home/ubuntu/.hermes/state.db")
cut = time.time() - 3*86400
for r in c.execute("""select billing_provider, sum(api_call_count) from session_model_usage
                      where last_seen>=? group by 1 order by 2 desc""", (cut,)):
    print(r)
EOF
```

**结论：一律用 `billing_provider LIKE '%别名%'` 过滤，不要 `= '周三'`** —— 等值过滤会漏掉带 `custom:` 前缀的那一半，这正是「用量对不上」最常见的自欺来源。

## 数据源：`/home/ubuntu/.hermes/state.db`

两张表就够，`JOIN` 后每条 = 「某会话用了某 provider/模型/任务」的聚合行：

| 表 | 关键列 |
|---|---|
| `session_model_usage` | `session_id`, `model`, `billing_provider`, `task`, `api_call_count`, `input_tokens`, `output_tokens`, `cache_read_tokens`, `estimated_cost_usd`, `first_seen`, `last_seen` |
| `sessions` | `id`, `source`(cli/tui/telegram/cron), `chat_type`, `chat_id`, `title`, `started_at`, `ended_at`, `message_count`, `api_call_count`, `model` |

`task` 列区分主对话与 `compression`（上下文压缩），两者 token 形态完全不同，**必须分开看**，否则会被「压缩烧了几万输出」误导。

`/home/ubuntu/.hermes/logs/agent.log` 只用来补个别调用的上游错误原文，不用于统计——账本已在 DB 里，别去 grep 日志数次数。

## 统计口径（照这个算，别只看总和）

1. **按天聚合**，定位爆点日。通常结论是「几乎全压在某一天」，而不是均匀分布。
2. **按会话排序，用 `input_tokens` 而不是 `api_call_count`** 排序 —— 调用次数会骗人，一次长上下文调用能顶几十次短调用。
3. 三个 token 口径分开报：`input_tokens`（非缓存输入）、`output_tokens`、`cache_read_tokens`。
4. 算 `input_tokens / api_call_count` = 单次平均输入。**>8k 就说明是长会话在滚雪球**，不是模型变贵。
5. `cache_read_tokens` 可能比 `input_tokens` 大一个数量级——那不是浪费，是缓存命中在兜底。别拿它当「用量暴涨」的论据。

## 归因阶梯（从最可能到最不可能）

1. **老长会话续用**：`sessions.started_at` 比爆点日早好几天、`message_count` 上千、`input_tokens` 最高。这是头号原因——同一个会话跑了几百轮，每轮都把全历史送上去。查了 `started_at` 才能说这句话。
2. **并行任务**：同一时刻开了多个 `tui`/`cli` 子会话（时间戳聚集在几分钟内）。多半是用户下了一条「全链路改造」的指令，被拆成 N 路并行。
3. **定时任务**：`source='cron'`，标题带日期。
4. **迁移导致的备用路由被顶**：某天集中改模型路由后，备用 provider 承接了大部分调用。
5. **真的被外部偷用**：只在账号额度下降与本机账本明显不匹配时才怀疑。见下节。

## 本机账本 ≠ 账号额度

`state.db` 只记 **Hermes 自己** 的调用。同一个 key 往往还被本机/远端的 N 个 Bot 共用（群霸、LemonOps、userbot、smart-group-bot、AdKiller 等，备用路由都可能指向同一站）。

所以：
- 说「Hermes 里这些调用」可以精确到会话；说「整个账号的消耗」只能到「本机账本能解释 X 次，剩余差额在别处」。
- 顺手只读扫一遍共用点：`grep -rl "<中转域名>" /home/ubuntu --include=*.env --include=*.json --include=*.py --include=*.toml`（排除 node_modules），看哪些服务把该站配成备用。
- **`journalctl` 里搜不到 provider 域名/别名不代表没调用** —— Bot 不一定会把端点打进日志。零命中只能说明「日志不记这件事」，不能当「没调用」的证据。别用日志的沉默去否定额度流失。

## 汇报格式

结论先行：一句话说清「爆在哪一天、几次调用、多少 token、主要来自哪两三个会话」，再给：

- 按天小表
- 按输入 token 排序的会话表（会话 ID 简写 / 来源 / 调用数 / 输入 / 输出 / 事由标题）
- 归因判断一句
- 可执行的下一步（归档老会话、换新会话重开），并**问一句再动手**

不要贴原始 SQL 输出、不要报 `estimated_cost_usd` 的绝对值（备用站常为 0，容易被误读成「免费」）。

## Pitfalls

- 本机没有 `sqlite3` CLI 时用 `python3 -c` 的 `sqlite3` 模块，别去装包。
- `billing_provider` 空串的行属于早期无记账，不要硬塞进某个 provider 统计。
- `sessions.title` 可能是 `None`（tui 会话常无标题）——此时靠 `messages` 表第一条 user 内容还原事由，取前 200 字即可。
- 别按 `estimated_cost_usd` 排序找「最贵」：中转站/自建端点普遍记 0，排序结果会全是垃圾。
- 只读查询，不要顺手 `state.db` 的 `VACUUM`/删表；归档会话也不要在这次查询里做。
- 时间统一北京时间（`Asia/Shanghai`），库里是 epoch，格式化时别忘。

## 支持文件

- `scripts/usage_report.py` — 一条命令出全套报告：provider 形态清单、按天聚合、按会话明细、单次平均输入与爆点判定。`--provider 周三 --days 3` 即可，纯只读。
