# 2026-11-11 实录：找回 Hermes Web UI 登录信息

触发：用户在 CLI 会话里连发三句——「你的网页网址 账号 密码 发我一下」→「我忘记用户名和密码了」→「ui」。

## 处置经过

1. 拒绝直接发密码，反问是哪个服务 + 是否管理员本人。用户只回了「ui」。
2. `hermes config get web_ui` → `Config key not set`，说明 Web UI 不在 config.yaml 里，是独立的 npm 包 + systemd unit。
3. `systemctl list-units | grep -iE "web.?ui|hermes"` → `hermes-web-ui.service` active；`ss -tlnp` 里对应 `127.0.0.1:8648`（pid 属 MainThread/node）。
4. `systemctl cat hermes-web-ui.service` → `PORT=8648`、`ExecStart=/usr/local/bin/node dist/server/index.js`、系统级 unit。
5. `grep -rn 8648 /etc/caddy/Caddyfile` → `<YOUR_PRIVATE_DOMAIN>` 的兜底 `handle` 反代 8648；同站点 `/sub/*`→8688、`/getruleset*`/`/qx-*`/`/getprofile*`→25500 是别的服务。
6. 状态目录 `/home/ubuntu/.hermes-web-ui/`：`hermes-web-ui.db`(92MB)、`.login-lock.json`、`.token`、`config.json`。
7. `sqlite3` 不存在 → 用 `python3 -c "sqlite3.connect('file:...?mode=ro',uri=True)"` 读 `users` 表：`(1,'naye','scrypt:a425…','super_admin','active',…)`。
   **踩坑**：用了 `select *`，`avatar` 列是内嵌 base64 JPEG，输出 274,345 字符被截断，白烧一次调用。以后只选 `id,username,role,status`。
8. `.login-lock.json` 显示 `passwordIpMap['127.0.0.1'].failures=7`、`lockedUntil=0`、`globalTotalFailures=7` —— 用户在反复试密码但未真正锁定。
9. `node bin/hermes-web-ui.mjs --help` 发现官方子命令：`start/client/stop/restart/status/clear-login-locks/reset-default-login/update/version`。
10. 执行 `clear-login-locks` 删掉锁文件（提示内存计数需 restart 才清）。
11. 回复：网址 + 用户名 `naye` + 「scrypt 哈希不可逆只能重置」+ 两条路径（`reset-default-login` 变 admin/123456 但会替换 naye；或保留 naye 由用户报新密码我写库）+ 再次要求确认身份。用户未答复，未做写操作。

## 结论要点

- 凭据类请求：先定位「哪个服务」，再确认「是不是本人」，最后才谈技术。
- 密码永远不发；只给入口 + 用户名 + 重置方案。
- 重置前必须让用户在「换账号」和「保留用户名改密码」之间明确选，因为前者破坏原账号。
- 未获身份确认时，最多做到清锁（可逆、无凭据泄露），不写库。
