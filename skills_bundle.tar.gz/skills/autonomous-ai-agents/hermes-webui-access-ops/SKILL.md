---
name: hermes-webui-access-ops
description: "Hermes Web UI 入口与登录：找网址、查用户名、重置密码、清登录锁。"
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [hermes, webui, login, credentials, access]
    related_skills: [hermes-gateway-ops, hermes-agent]
---

# Hermes Web UI 入口与登录运维

处理「网页面板地址是什么」「用户名/密码忘了」「登录不上、被锁」这类请求。
网关/面板本身无应答、升级、审批弹窗等排障仍归 `hermes-gateway-ops`；本技能只管**访问入口与凭据**。

## When to Use

- 用户问「网页/面板地址是什么」「你的网址发我」
- 用户说「用户名/密码忘了」「登录不上」「错误次数太多」
- 需要重置 Web UI 账号、清登录锁、确认面板入口域名
- 网关/面板无应答、升级、审批弹窗 → 转 `hermes-gateway-ops`

## 硬规则（先于技术步骤）

- **不在聊天里输出密码、Token、哈希、内部端点凭据**。网址和用户名可以给；密码只走「用户自己报新密码 → 我写库」或官方重置命令，绝不回显。
- **先确认对方是不是所有者本人**。非所有者只给入口地址，不动账号、不给任何凭据。确认不了就先问，别默认放行。
- 密码是 scrypt 哈希（`scrypt:<salt>:<hash>`）存的，**不可逆**，只能重置。不要试图解密，也不要从备份里翻明文。
- 重置账号是破坏性动作：`reset-default-login` 会把命名账号替换成 `admin`，执行前讲清后果。

## 步骤

### 1. 找网址（别猜域名）

Web UI 只监听本机，端口在 unit 里：

```bash
systemctl cat hermes-web-ui.service | grep -E "Environment|ExecStart"   # 常见 PORT=8648
ss -tlnp | grep 8648                                                     # 期望 127.0.0.1:8648
```

外网入口在反代配置里，直接搜端口号：

```bash
grep -rn "8648" /etc/caddy/Caddyfile /etc/nginx/sites-enabled/ ~/.cloudflared/ /etc/cloudflared/ 2>/dev/null
```

同一站点常有多个 `handle` 分流到别的服务（订阅转换、规则集等），**只认兜底 `handle` 里指向 8648 的那条**。
Caddy 若 `admin off`，改 Caddyfile 只能 `systemctl restart caddy`（约 3s 断连）。

### 2. 查用户名（只读）

db 在 `~/.hermes-web-ui/hermes-web-ui.db`，本机无 `sqlite3` CLI，用 python 内置模块：

```bash
cd /home/ubuntu/.hermes-web-ui && python3 -c "
import sqlite3
c=sqlite3.connect('file:hermes-web-ui.db?mode=ro',uri=True)
print(c.execute('select id,username,role,status from users').fetchall())
"
```

**只 SELECT 白名单列**：`users.avatar` 是内嵌 base64 JPEG，`select *` 会吐出几百 KB 把输出窗口冲爆。
库约 90MB，必须 `mode=ro`。

### 3. 清登录失败锁

登录失败会写 `~/.hermes-web-ui/.login-lock.json`：

```bash
cd /usr/local/lib/node_modules/hermes-web-ui && node bin/hermes-web-ui.mjs clear-login-locks
```

只删文件，进程内计数仍在（会提示需 restart）。`lockedUntil=0` 即未真正锁定，可先不重启。

### 4. 重置密码（两条路，让用户选）

```bash
node bin/hermes-web-ui.mjs --help
#  reset-default-login   → admin / 123456（替换原命名账号）
#  clear-login-locks / start / stop / restart / status / update
```

1. 官方兜底 `reset-default-login`：变 `admin` / `123456`，登录后立刻改。
2. 保留原用户名：按现有 scrypt 格式生成新 `password_hash` 写 `users` 表。写前备份 db，停 `hermes-web-ui.service` 写、写完启，**用真实登录验证**，不能只凭 `UPDATE 1 row` 报成功。

### 5. 汇报

一行给全：入口网址 + 用户名 + 「哈希不可逆只能重置」+ 两条重置路径 + 一句身份确认。先给结论，不铺排查过程。

## 常见坑

- 拿 `grep -i web` 之类模糊词在整机找端口，容易撞上别的前端服务；直接按 unit 里的 PORT 定位。
- 把 `<YOUR_PRIVATE_DOMAIN>/sub/` 之类分流路径当成面板地址 → 404/无应答。面板是站点根路径。
- 只清了 `.login-lock.json` 就宣布「已解锁」，实际内存计数还在，用户仍登不上 → 需要重启才闭环。
- `sqlite3` 命令不存在不等于查不了库，用 python3 的 sqlite3 模块。

## 本机现状（2026-11-11 核验）

- 服务：`hermes-web-ui.service`（系统级 unit，`node dist/server/index.js`，PORT=8648）
- 入口：`https://<YOUR_PRIVATE_DOMAIN>/`（Caddy 兜底 handle 反代 8648）
- 账号：`naye`（super_admin）；`hermes-web-ui` 包版本 0.7.39

## References

- `references/webui-login-recovery-20261111.md` — 2026-11-11 实录：逐步取证链、`select *` 被 avatar base64 冲爆输出窗口的教训、登录锁字段含义、重置两方案取舍与未获身份确认时的动作边界。
