# state.db 膨胀归因、VACUUM 误区与会话归档瘦身陷阱

## 现象与用户质问
- 用户反馈：“之前明明执行过清理/瘦身/VACUUM，或者用脚本重建了数据库，为什么 `state.db` 依然有 140MB~154MB，一点都没缩小？是不是没成功或者骗我？”
- 或者运维提出“把 30 天前的旧消息归档瘦身”，执行完后库大小毫厘未减。

## 根因与底层机制

### 1. `VACUUM` 的真正生效条件：必须先 `DELETE`
- `VACUUM` **只回收被 `DELETE` 清理后留下的空闲碎片页（freelist）**。
- 如果库内的消息记录（如 30,000+ 条）一条都没删，则所有数据库页都在存储真实行。
- 用 `PRAGMA freelist_count;` 检查空闲页：若仅几百页（<3MB），执行 `VACUUM` 只会重写健康页，物理文件大小基本保持原样。

### 2. 双重 FTS5 索引占据半壁江山（写放大与空间膨胀）
Hermes 会为每一条入库的对话消息建立两套全文检索索引：
- `messages` 表本体（原始文本与元数据，~65MB / 3万条）
- `messages_fts` 表（标准分词索引，~18MB）
- `messages_fts_trigram` 表（字符级三元组索引，用于模糊与中文搜索，~53MB）

**结果**：索引体积往往等于甚至超过消息表本体（索引合占 70MB+，纯数据净重 136MB+）。
无论用手写脚本（如 `rescue.py`）把数据全量捞出来插入新库，还是 `.recover` 恢复，只要 Hermes 网关一启动，就会自动补齐这两套 FTS 索引，导致数据库瞬间撑回 150MB 左右。

### 3. “30 天前归档”的时间线盲区陷阱
在提出归档策略前，**必须先查全库消息的时间戳分布**：
```sql
SELECT min(timestamp), max(timestamp) FROM messages;
SELECT strftime('%Y-%m-%d', timestamp, 'unixepoch', 'localtime') as day, count(*) FROM messages GROUP BY day;
```
**实录教训**：在 2026-09-14 排障中，全库 30,558 条消息的最早时间是 2026-08-29，全库实际上仅跨越 16 天。如果拍脑袋提出“按 30 天前归档”，只能匹配到 1 条消息，归档后执行 VACUUM 0 收益，造成方案失真与用户信任崩塌。

### 4. 膨胀真正的元凶：高吞吐大型协作会话
16 天内膨胀至 3 万条消息的原因在于密集开发会话：
- 查出会话消息排行：
  ```sql
  SELECT s.id, s.title, s.source, count(m.id) as cnt, round(sum(length(m.content))/1024.0/1024.0, 2) as mb
  FROM sessions s LEFT JOIN messages m ON s.id = m.session_id
  GROUP BY s.id ORDER BY cnt DESC LIMIT 10;
  ```
- 单个大型开发会话（如多轮工具调用、长历史讨论）即可累积 5,000~7,000 条消息。前 10 个已完结项目往往占据了全库 70%+ 的数据量。

### 5. 致命隐形陷阱：FTS 影子表墓碑膨胀（DELETE 之后 VACUUM 仍有 106MB）
**2026-09-14 核心实测发现**：
- 在对 `messages` 执行 `DELETE FROM messages WHERE session_id IN (...)` 后，虽然触发器会向 FTS 表写入 delete 记录，但 FTS5 的底层影子表（`messages_fts_data`、`messages_fts_trigram_data`）**并不会自动释放已删除段的物理存储（类似墓碑标记）**！
- 实测数据：删除 2.5 万条消息后直接跑 `VACUUM`，数据库体积仅从 148MB 降至 **106.92 MB**（其中 `messages_fts_trigram_data` 仍死锁着 67.7MB，`messages_fts_data` 占 24.55MB）！
- **唯一根治解法**：在 `DELETE` 之后、`VACUUM` 之前，必须显式触发 FTS 全量段合并重建：
  ```sql
  INSERT INTO messages_fts(messages_fts) VALUES('rebuild');
  INSERT INTO messages_fts_trigram(messages_fts_trigram) VALUES('rebuild');
  ```
  执行重建后，两套 FTS 影子表体积从 92MB 骤降至 10.5MB，再跑 `VACUUM` 才能真正压缩至 **25 MB**！

### 6. 外键跨界孤儿陷阱与每日备份门禁阻断
- 保留的活跃会话（如最近 3 天）中，部分会话的 `parent_session_id` 可能指向被归档删除的历史会话；
- 若直接删除历史会话，`PRAGMA foreign_key_check;` 会报外键违规；
- 这会导致每日凌晨 03:00 的 `backup_hermes.sh` 在健康门禁处直接报错退出（`foreign_key_check 有 X 条违规`），使整个系统失去自动每日冷备保护；
- **解法**：在删除会话前，必须先解除跨界指针：
  ```sql
  UPDATE sessions SET parent_session_id = NULL WHERE parent_session_id IN (SELECT id FROM archived_sessions);
  ```

---

## 经 2026-09-14 生产实测验证的完整归档瘦身 SOP

使用 Hermes 虚拟环境 Python（保证 SQLite 3.53.1 一致性）：

```python
import os, time, shutil, sqlite3

db_path = os.path.expanduser('~/.hermes/state.db')
archive_path = os.path.expanduser('~/.hermes/state_archive.db')

conn = sqlite3.connect(db_path, timeout=30.0)
conn.execute("PRAGMA busy_timeout = 30000;")
cur = conn.cursor()

# 1. 预先合并 WAL
cur.execute("PRAGMA wal_checkpoint(PASSIVE);")

# 2. 利用 VACUUM INTO 生成瞬时 100% 完整的冷存快照（耗时仅 0.4s）
if os.path.exists(archive_path):
    os.remove(archive_path)
cur.execute(f"VACUUM INTO '{archive_path}';")

# 校验归档库健康
arch_conn = sqlite3.connect(archive_path)
assert arch_conn.execute("PRAGMA integrity_check;").fetchone()[0] == 'ok'
arch_conn.close()

# 3. 确定截止时间点（保留近 3 天活跃会话，归档更早的完结会话）
sep_ts = cur.execute("SELECT min(started_at) FROM sessions WHERE started_at >= strftime('%s', '2026-09-12 00:00:00', 'utc')").fetchone()[0]
archived_ids = [r[0] for r in cur.execute("SELECT id FROM sessions WHERE started_at < ?", (sep_ts,)).fetchall()]

# 4. 事务内执行安全剔除与 FTS 重建
conn.execute("BEGIN TRANSACTION;")
# 解除跨界外键指针（防破坏每日备份门禁）
cur.execute(f"UPDATE sessions SET parent_session_id = NULL WHERE parent_session_id IN ({','.join(['?']*len(archived_ids))})", archived_ids)
# 清理消息、模型统计与会话
cur.execute(f"DELETE FROM messages WHERE session_id IN ({','.join(['?']*len(archived_ids))})", archived_ids)
cur.execute(f"DELETE FROM session_model_usage WHERE session_id IN ({','.join(['?']*len(archived_ids))})", archived_ids)
cur.execute(f"DELETE FROM sessions WHERE id IN ({','.join(['?']*len(archived_ids))})", archived_ids)
# 清理无引用提示词与历史恢复残余表
cur.execute("DELETE FROM system_prompts WHERE hash NOT IN (SELECT DISTINCT system_prompt_hash FROM sessions WHERE system_prompt_hash IS NOT NULL)")
cur.execute("DROP TABLE IF EXISTS lost_and_found")
# 关键：彻底粉碎 FTS 影子表墓碑
cur.execute("INSERT INTO messages_fts(messages_fts) VALUES('rebuild');")
cur.execute("INSERT INTO messages_fts_trigram(messages_fts_trigram) VALUES('rebuild');")
conn.commit()

# 5. 校验三项关键不变量
assert len(cur.execute("PRAGMA foreign_key_check;").fetchall()) == 0
assert cur.execute("PRAGMA quick_check;").fetchone()[0] == 'ok'
msg_cnt = cur.execute('SELECT count(*) FROM messages').fetchone()[0]
fts_cnt = cur.execute('SELECT count(*) FROM messages_fts').fetchone()[0]
tri_cnt = cur.execute('SELECT count(*) FROM messages_fts_trigram').fetchone()[0]
tri_src = cur.execute('SELECT count(*) FROM messages_fts_trigram_src').fetchone()[0]
assert msg_cnt == fts_cnt
assert tri_cnt == tri_src

# 6. 收尾 VACUUM 释放物理空间
cur.execute("VACUUM;")
assert cur.execute("PRAGMA integrity_check;").fetchone()[0] == 'ok'

# 7. 截断 WAL 释放内存
cur.execute("PRAGMA wal_checkpoint(TRUNCATE);")
conn.close()
```
实测战报：主库体积从 148.8 MB 缩减至 **25.07 MB**（压缩 83.2%），归档库 146.21 MB 完好留存，`backup_hermes.sh` 健康自检 100% 绿灯通过。
