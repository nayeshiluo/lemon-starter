# hermes-web-ui 整包升级：延迟执行 + 自动回滚（2026-10-24 实录）

升级 npm 全局包 `hermes-web-ui` 时，**重启会杀掉正在回复用户的会话**。
本文记录已验证的处置方式。补丁本身的细节见 `webui-approval-popup-request-id.md`。

## 0. 先证明「当前会话是否在重启目标内」——不要假设

本机所有 Hermes 会话都挂在这条链上：

```
bash（工具会话）
  └─ hermes_bridge.py --worker-profile default   （worker，ipc:///tmp/hermes-agent-bridge-workers/*.sock）
      └─ hermes_bridge.py --endpoint ipc:///tmp/hermes-agent-bridge.sock   （主 bridge）
          └─ /usr/local/bin/node dist/server/index.js    （hermes-web-ui.service 的 MainPID）
```

取证方法（从 `$$` 一路走到 pid 1）：

```bash
P=$$; while [ "$P" != "1" ] && [ -n "$P" ]; do
  ps -p $P -o pid,ppid,cmd --no-headers | cut -c1-150
  P=$(ps -p $P -o ppid= | tr -d ' ')
done
```

只要祖先里出现 `node dist/server/index.js`，`systemctl restart hermes-web-ui.service`
就必然掐断当前回复。**这是决定「怎么重启」的唯一依据，不能靠猜。**

## 1. 服务形态（决定用哪种 systemd-run）

```
/etc/systemd/system/hermes-web-ui.service        ← 系统级，不是 --user
  User=ubuntu
  WorkingDirectory=/usr/local/lib/node_modules/hermes-web-ui
  ExecStart=/usr/local/bin/node dist/server/index.js
  Restart=always / RestartSec=5 / KillMode=mixed / TimeoutStopSec=30
  Environment PORT=8648
drop-in 20-private-files.conf: UMask=0077
drop-in 30-loopback.conf:      BIND_HOST=127.0.0.1
```

因为是系统级 unit：

- 重启用 `sudo systemctl restart hermes-web-ui.service`（有免密 sudo 时可直接跑）。
- 延迟触发用 **`sudo systemd-run --on-active`**，**不需要** `XDG_RUNTIME_DIR` /
  `DBUS_SESSION_BUS_ADDRESS`。这两个变量只在 `systemd-run --user` 时才需要
  （`--user` 的坑见 `webui-approval-popup-request-id.md`）。

## 2. 执行顺序（顺序错了会打断自己）

1. 只读核查：版本、进程链、unit 定义、包目录大小、磁盘余量、`engines` 与 node 版本兼容性。
2. 整包备份（tar）并验证可读。
3. 写升级脚本 + `bash -n` 语法检查。
4. **把该提交的东西全部提交/推送完**（脚本进备份仓库等）。
5. **最后**才挂 `systemd-run --on-active` 定时器。
6. 立刻输出最终回复，把「几分钟后断开、断开多久、回来后怎么验收」讲清楚。

第 4 步必须在第 5 步之前：定时器一旦到点就会杀掉会话，没做完的 git 操作会被打断。

延迟取 150 秒左右（够写完回复 + 用户读完）；实际中断时长约 1~1.5 分钟
（停服务 2s + npm 装 36M 包 + 起服务 + 就绪探测）。

```bash
sudo systemd-run --unit=hermes-webui-upgrade \
  --description="hermes-web-ui <old> -> <new> upgrade" \
  --on-active=150 --timer-property=AccuracySec=1s \
  /path/to/upgrade-webui.sh
```

挂完必须确认真的挂上了，否则用户白等：

```bash
systemctl list-timers 'hermes-webui-upgrade*' --all --no-pager   # 看 NEXT / LEFT
```

## 3. 升级脚本的必备结构

完整实现见 `scripts/upgrade-webui.sh`。七个环节缺一不可：

1. **整包备份**：`tar -C /usr/local/lib/node_modules -czf $BK/hermes-web-ui-$OLD-full.tar.gz hermes-web-ui`
   本机 486M 目录压出 144M，约 26 秒。备份后必须 `tar -tzf` 验证可读，
   不可读就中止且**不动服务**。已有备份则复用，不重复打包。
2. **停服务**，并复查 `systemctl is-active` 确认真停下。
3. **`npm install -g hermes-web-ui@<target> --no-fund --no-audit --allow-scripts=agent-browser,node-pty,protobufjs,vue-demi`**
   ——`--allow-scripts` 不能省，原因见第 8 节。
4. **验版本号**：读 `package.json` 的 `version` 必须精确等于目标版本，不等就回滚。
4b. **验原生模块产物**：`node_modules/node-pty/build/Release/pty.node` 必须存在，
   缺了就回滚（版本号对不代表装完整，见第 8 节）。
5. **重打补丁**：调 `repatch-webui-approval.sh`，再跑一次 `--check` 确认退出码 0。
   **判据只用 `--check` 的结果**，不要把补丁脚本自身的退出码当成成败依据（见第 8 节）。
6. **起服务 + 就绪探测**：轮询 `curl -s -o /dev/null -w '%{http_code}' http://127.0.0.1:8648/`
   直到 200，最多 30 次 × 2s。**只看 `is-active` 不够**，Type=simple 起来不等于能服务。
7. **回滚函数**：`systemctl stop` → `rm -rf $PKGDIR` → `tar -xzf` → `systemctl start`
   → `sleep 10` → 复查 `is-active`。任何一步失败都走它，并把结果落到 STATUS 文件。

STATUS 文件（供下一轮会话读取，不必翻日志）：

```
OK:version=<v>:mainpid=<pid>:active=active:bridges=<n>:sha=<前16位>:<ts>
ROLLED_BACK:version=<old>:<ts>
ROLLBACK_FAILED:<ts>
```

## 4. 上线前用「真实目标包」干跑补丁脚本

不要只在本机已修版上验证（那只能证明幂等），要证明**对未修的新版也能修对**：

```bash
T=/tmp/rp_test; W=$T/node_modules/hermes-web-ui
mkdir -p $W/dist/server/agent-bridge/python
npm pack hermes-web-ui@<target>            # 拿 tgz
tar -xzf hermes-web-ui-<target>.tgz        # 得到 package/
cp package/dist/server/agent-bridge/python/bridge_pool.py $W/dist/server/agent-bridge/python/
cp package/package.json $W/
# 用 sed 把脚本里硬编码的线上路径改到临时目录，生成测试副本
sed "s|/usr/local/lib/node_modules/hermes-web-ui|$W|g" repatch-webui-approval.sh > $T/test.sh
chmod +x $T/test.sh && $T/test.sh
```

三条验收断言：

- 干跑前 `sha256sum` == 上游原始哈希（证明拿到的是未修版）。
- 干跑后 `sha256sum` == **线上已修版**的哈希（本机 2026-10-24 为 `a17ea210ac4de3ba…`）。
  逐字节一致才说明补丁结果确定、不存在适配差异。
- 再跑一次 `--check` 必须退出 0（幂等）。

本机实测：0.7.39 原始 `433d053a0e88…` → 补丁后 `a17ea210ac4de…`，与线上完全一致。

## 5. 判断「被移除的 API 是否影响本机」

升级前逐版本 diff `openapi.json` 的 path 集合（0.7.37→0.7.39 是 461→443，
移除 24 个 `/api/devices/*`，新增 6 个 `/api/studio/*`）。判断影响面的方法：

- 在目标版本的 `dist/server/index.js` 里 `grep -o ".\{60\}api/devices.\{60\}"` 看残留用法。
- **要判断某个受保护服务是否依赖 web-ui 的 HTTP API，读它自己 unit 的 `ExecStart`**，
  不要凭功能名字联想。本机实证：`desktop-commander-remote.service` 的
  `ExecStart=/usr/local/bin/desktop-commander remote --disable-no-sleep`，
  是独立二进制走 Remote MCP，不消费 web-ui 的 `/api/devices/*`，因此升级不影响它。

## 6. 版本兼容性预检（省一次回滚）

```bash
node -v; npm -v
npm view hermes-web-ui@<target> engines
python3 -c "import json;print(json.load(open('/usr/local/lib/node_modules/hermes-web-ui/package.json'))['engines'])"
```

本机 node v24.19.0 / npm 11.17.0，两版 `engines` 同为 `{node: '>=23.0.0'}`。
两版 `engines` 不一致或 node 不满足时必须先说明，不要硬升。

## 7. 本次遗留

- 0.7.38/0.7.39 未修审批 bug，升级纯粹为跟进版本；若没有明确功能诉求，不升也完全可用。
- 升级后前端资源带 hash 变化，用户浏览器需刷新页面。
- 每日只读巡检 cron `5c7c83ec8ce4` 已含补丁存活检测（grep `_request_id`），
  被后续升级覆盖会主动告警，不必依赖记忆。

## 8. 首次真实升级踩到的两个坑（2026-10-24 实录，必读）

第一次真升级时，**npm 装 0.7.39 成功、补丁也打成功（AST + 行为校验全 PASS），
却因为下面第 2 条被判定失败而整体回滚**。两个坑都不在「升级逻辑」里，
而在脚本细节里，所以只做纸面推演是发现不了的。

### 坑一：npm 11 默认拦截 install scripts，`node-pty` 会缺产物

日志里会看到：

```
npm warn allow-scripts 5 packages have install scripts not yet covered by allowScripts:
npm warn allow-scripts   agent-browser@0.26.0 (postinstall: ...)
npm warn allow-scripts   node-pty@1.1.0 (install: node scripts/prebuild.js || node-gyp rebuild; ...)
npm warn allow-scripts   protobufjs@7.6.6 / vue-demi@0.14.10
```

**这不是无害警告。** 取证方法：

```bash
# node-pty 自带预编译包只有 darwin/win32，没有 linux-x64
ls /usr/local/lib/node_modules/hermes-web-ui/node_modules/node-pty/prebuilds/
#   darwin-arm64  darwin-x64  win32-arm64  win32-x64      ← 没有 linux-x64

# Linux 上靠 postinstall 现编译，产物时间戳 == 当初安装时间
ls -l .../node-pty/build/Release/pty.node
#   -rwxr-xr-x 75728 Oct 20 03:53    ← 正是上次装 0.7.37 的时刻

# web-ui 确实在用它
grep -c "node-pty" /usr/local/lib/node_modules/hermes-web-ui/dist/server/index.js   # 8
```

即：不放行 scripts，装完没有 `build/Release/pty.node`，**web-ui 的终端功能会坏**，
而 `package.json` 的版本号照样是目标版本，光验版本号根本发现不了。

修法两条一起上：

1. `--allow-scripts=agent-browser,node-pty,protobufjs,vue-demi`
   （npm 自己在警告里给出了这串参数；这些是官方包，放行风险可接受）。
2. 加一道硬校验：`pty.node` 不存在就判失败回滚。

工具链预检（缺了会白跑一趟）：

```bash
for c in gcc g++ make python3; do command -v $c; done   # node-gyp 由 npm 自带，无需单独装
```

### 坑二：`set -u` + 未设置的 `$HOME`，让提示文字杀掉了成功的升级

补丁脚本用了 `set -uo pipefail`，末尾有一行提示：

```bash
say "    $HOME/backups/webui-approval-fix-20261024/restart-bridge.sh"
```

**systemd 的 service 环境默认不设 `HOME`**，于是这行报
`HOME: unbound variable`，脚本以非 0 退出。上层升级脚本看到非 0 就判定
「补丁失败」→ 回滚。日志形态：

```
替换完成 / AST 校验: OK / 模拟 ... -> 'abc123' / 行为校验: PASS / 补丁完成
repatch-after-upgrade.sh: line 100: HOME: unbound variable     ← 就死在这
FATAL: 补丁脚本失败 → !! 触发回滚
```

两条教训，都是通用写法问题：

1. **提示/日志文字绝不允许影响退出码**。脚本里用 `${HOME:-/home/ubuntu}` 之类的
   兜底，末尾显式 `exit 0`；不要靠「最后一条命令的返回值」当退出码。
2. **调用方不要采信这类脚本的退出码**，用它自己的 `--check`（只读判定）当唯一判据。
   本次改成 `bash "$REPATCH" || log "返回非 0，改以 --check 为准"` 后再 `--check`。

验证方式（不用真升级就能复现）：

```bash
env -u HOME bash /path/to/repatch-after-upgrade.sh        # 完整路径必须退出 0
env -u HOME bash /path/to/repatch-after-upgrade.sh --check
```

### 附带收获：回滚机制本身得到了实证

第一次失败触发了真回滚，全程 **10 秒**恢复：

```
04:39:07 回滚解压完成 → 04:39:17 回滚后服务已恢复: 720034
```

即「整包 tar 备份 + stop/rm/tar -x/start」这条路是可靠的，用户面板没有真正长时间挂过。
这也说明**宁可回滚也不要带病启动**：本次回滚成本 10 秒，远低于一次坏升级的排查成本。
