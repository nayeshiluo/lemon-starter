# Session storage corruption reference

## Observed failure pattern

The user-facing warning

```text
No reply: the turn was stopped because session storage could not be written (the transcript would have been lost on restart). This is often a full disk — free some space (or fix state.db permissions), then send your message again.
```

### User misconception vs Root cause
- **User misconception**: The warning explicitly states *"This is often a full disk — free some space"*, leading users to inspect RAM/Swap (`free -h`) or disk space (`df -h`). Even when RAM and disk have gigabytes of free space and 90%+ free inodes, the error can still fire.
- **True root cause**: This is a generic Hermes fail-safe catch-all message when a SQLite write transaction or session transcript commit fails. The actual culprit is almost always **SQLite B-Tree / FTS corruption (`database disk image is malformed` / `file is not a database`)** or **stale deleted inode handles** held by the gateway process.
- ⚠️ **反直觉但真实的例外（2026-09-04 实证）**：内存**确实**可能是上游元凶，但机理不是「磁盘满」而是 **OOM 杀进程 → WAL 写入被腰斩 → B-Tree 损坏**。见下方「OOM 撑爆页缓存」专节。用户抱怨"TG 报错说内存不够"时，`free -h` 当下正常**不能**排除该路径，必须查 `/proc/vmstat` 的 `oom_kill` 历史计数。

The decisive log patterns are:

```text
database disk image is malformed
file is not a database
malformed database schema (<session_key>) - orphan index     ← 恶化终局，见下节
state.db write failed with an FTS-corruption error
state.db FTS indexes remain corrupt
single-entry routing save failed ... falling back to full index rewrite
Persisted transcript lagged live cached history ... possible FTS write corruption
```

When these repeat for Telegram DM and group keys, inbound messages may still be observed and a response may even be sent, while routing/transcript persistence remains unreliable. This explains intermittent recurrence of the warning.

## Safe read-only probe

Use the environment's available interpreter explicitly:

```bash
hermes doctor
python3 - <<'PY'
import sqlite3, os
p = os.path.expanduser('~/.hermes/state.db')
c = sqlite3.connect(f'file:{p}?mode=ro', uri=True, timeout=2)
print('integrity:', c.execute('PRAGMA integrity_check').fetchone())
print('tables:', c.execute("select name from sqlite_master where type='table' order by name").fetchall())
for table in ('messages', 'sessions', 'gateway_routing'):
    try:
        print(table, c.execute(f'select count(*) from "{table}"').fetchone())
    except Exception as e:
        print(table, type(e).__name__, e)
c.close()
PY
```

Important: the canonical routing table is `gateway_routing`; querying `routing` is a false negative. A successful SQLite `integrity_check` is not sufficient to clear Hermes FTS corruption if Hermes logs report malformed FTS indexes.

## Evidence boundaries

- Keep `database disk image is malformed` / FTS corruption separate from `No LLM provider configured`; the latter is provider selection/configuration.
- Keep missing API keys in `hermes doctor` separate from Telegram persistence diagnosis.
- A running gateway process is not proof that session writes work.
- Do not claim a repair succeeded unless the gateway was stopped, backups were made, the repair command completed, integrity and table reads passed, and a short Telegram message was verified afterward.
- Until repaired, avoid repeatedly sending test messages because each turn can create more failed routing writes.

## WAL 强删与非正常退出（`file is not a database` & `FOREIGN KEY constraint failed`）

### 1. 强行删除 WAL/SHM 或直接 `cp` 覆盖主库
在 SQLite WAL 模式下，主库 `state.db`、预写日志 `state.db-wal` 与共享内存 `state.db-shm` 是紧密耦合的。
- ❌ **致命操作**：在网关运行时执行 `rm -f *.db-wal *.db-shm` 或 `cp state.db.bak state.db`。
- **后果**：破坏了 WAL page sequence 对应关系，导致 SQLite 抛出 `DatabaseError: file is not a database`。
- **正确做法**：必须先停止网关进程，再使用 `PRAGMA wal_checkpoint(TRUNCATE);` 清理 WAL，严禁在服务存活时硬删文件。

### 2. 数据库重建后的外键孤儿与死信队列冲突（`FOREIGN KEY constraint failed` & `pending_messages` 积压）
- **现象**：用户发送消息时偶发中断报 `session storage could not be written`，日志提示 `Failed to recover pending message from pending-*.json: FOREIGN KEY constraint failed`。
- **根因**：网关在连接抖动或异常退出时，将未落盘消息写入 `~/.hermes/pending_messages/*.json` 暂存。如果相关会话在 `sessions` 表中已被重置或结束，重启重放这批死信时会强校验外键失败，阻塞正常会话写入。
- **排查与修复**：
  1. 检查并清理死信文件：`rm -f /home/ubuntu/.hermes/pending_messages/*.json`。
  2. 重建 FTS 索引：`sqlite3 ~/.hermes/state.db "INSERT INTO messages_fts(messages_fts) VALUES('rebuild'); INSERT INTO messages_fts_trigram(messages_fts_trigram) VALUES('rebuild');"`。
  3. 在 `db_maintenance.py` 定时维护中增加过期暂存文件自动清理。

## Offline Non-Destructive Recovery (`hermes sessions recover`)

When in-place repair tools (`hermes doctor --fix` or `hermes sessions repair`) fail due to severe SQLite B-Tree page corruption (`database disk image is malformed` / `invalid page number` / `btreeInitPage error code 11`):

### 1. Execute Non-Destructive Rowid Salvage
Hermes provides an offline salvage tool that scans readable rowid ranges, bypasses corrupted pages, and reconstructs the schema and FTS virtual indexes into a new database without modifying the active database:

```bash
# 1. Inspect recoverability first
python3 -m hermes_cli.main sessions recover --source ~/.hermes/state.db --inspect-only

# 2. Extract into a clean database (use --allow-partial if corrupted ranges exist)
# ⚠️ 踩坑警示：若同名报告文件（默认 <output>.recovery.json）已存在，命令会直接报错拒绝覆盖：
# `Error: refusing to overwrite existing report: ...` (exit code 2)。
# 务必使用带时间戳的 output 路径，或显式传入未被占用的 `--report <path>`：
RECOVER_TS=$(date +%Y%m%d_%H%M%S)
python3 -m hermes_cli.main sessions recover \
    --source ~/.hermes/state.db \
    --output ~/.hermes/state_recovered_${RECOVER_TS}.db \
    --allow-partial
```

### 2. Verify Recovered Database Health
Before replacing the active database, verify the output passes integrity checks:
```bash
sqlite3 ~/.hermes/state_clean_recovered.db "PRAGMA integrity_check; SELECT count(*) FROM messages; SELECT count(*) FROM sessions;"
```
Expected output: `ok` with intact message and session counts.

### 3. Safe Swap & Gateway Restart
Because Hermes prevents child processes from restarting the parent gateway from within the conversation loop, prepare a swap script for the user/external shell:
```bash
cat << 'EOF' > ~/.hermes/swap_db.sh
#!/usr/bin/env bash
set -e
cd /home/ubuntu/.hermes
mkdir -p "state_db_backup_$(date +%Y%m%d_%H%M%S)"
cp -a state.db* "state_db_backup_$(date +%Y%m%d_%H%M%S)/" 2>/dev/null || true
cp -f state_clean_recovered.db state.db
rm -f state.db-wal state.db-shm
chmod 644 state.db
sudo systemctl restart hermes-gateway.service
sleep 3
systemctl is-active hermes-gateway.service
EOF
chmod +x ~/.hermes/swap_db.sh
```

### 4. SQLite `.recover` 提取陷阱与免停机 ATTACH 热合并方案（2026-09-04 实证实战）

#### 陷阱：直接管道重放 `.recover` 报错中断
直接执行 `sqlite3 state.db ".recover --ignore-freelist" | sqlite3 recovered.db` 在现代 SQLite（3.40+ / 3.53）下会失败：
- `Parse error near line 157: table sqlite_master may not be modified`
- `Parse error: object name reserved for internal use: sqlite_stat1`
- `Parse error: no such table: sqlite_stat1`
这是因为 `.recover` 输出了修改 `sqlite_master/sqlite_schema` 及内部统计表的语句，且重新定义了 FTS5 虚拟表。

#### 方案：Python 过滤提取 + ATTACH 热合并（零 Inode 残留、网关免重启）
先将 `.recover` 业务数据注入到一份结构纯净的空库（可直接复制网关自愈新建的空库），再通过 SQLite 的 `ATTACH` 机制直接合并进正在运行的 `state.db`：

```python
import sqlite3, shutil, time

# 1. 导出物理恢复 SQL
# terminal: sqlite3 malformed_state.db ".recover --ignore-freelist" > /tmp/recover.sql

# 2. 复制结构完好的干净空库，只注入业务表 INSERT
shutil.copy('/home/ubuntu/.hermes/state.db', '/tmp/clean_recovered.db')
conn = sqlite3.connect('/tmp/clean_recovered.db')
c = conn.cursor()

with open('/tmp/recover.sql', 'r', encoding='utf-8', errors='ignore') as f:
    current = []
    for line in f:
        if any(line.startswith(p) for p in ['PRAGMA', 'CREATE', 'INSERT INTO sqlite_schema', 'INSERT OR IGNORE INTO \'sqlite_stat1\'', 'INSERT OR IGNORE INTO \'messages_fts', 'BEGIN;', 'COMMIT;']):
            continue
        current.append(line)
        if line.strip().endswith(';'):
            stmt = ''.join(current).strip()
            if any(stmt.startswith(f"INSERT OR IGNORE INTO '{tbl}'") for tbl in ('sessions', 'messages', 'system_prompts', 'schema_version')):
                try: c.execute(stmt)
                except Exception: pass
            current = []
conn.commit()
conn.close()

# 3. ATTACH 热合并到正在运行的 live state.db（无需停机，杜绝 (deleted) Inode 句柄残留）
live_conn = sqlite3.connect('/home/ubuntu/.hermes/state.db', timeout=30.0)
lc = live_conn.cursor()
lc.execute("ATTACH '/tmp/clean_recovered.db' AS recovered;")
lc.execute("PRAGMA foreign_keys = OFF; BEGIN TRANSACTION;")
lc.execute("INSERT OR IGNORE INTO sessions SELECT * FROM recovered.sessions;")
lc.execute("INSERT OR IGNORE INTO system_prompts SELECT * FROM recovered.system_prompts;")
lc.execute("INSERT OR IGNORE INTO messages SELECT * FROM recovered.messages;")
live_conn.commit()
lc.execute("PRAGMA foreign_keys = ON;")

# 4. 重建 FTS 索引并检验
lc.execute("INSERT INTO messages_fts(messages_fts) VALUES('rebuild');")
lc.execute("INSERT INTO messages_fts_trigram(messages_fts_trigram) VALUES('rebuild');")
live_conn.commit()
lc.execute("DETACH recovered;")
assert lc.execute("PRAGMA integrity_check;").fetchone()[0] == 'ok'
live_conn.close()
```
此方法优点：
1. **零 Inode 句柄残留**：主库文件 inode 不变，存活的网关进程不会读到 `(deleted)` 旧文件。
2. **无需终止网关**：网关在整个恢复过程中正常收发消息，且当天新产生的增量消息不会丢失。
3. **FTS5 索引即时对齐**：重建后 `session_search` 立刻恢复正常。

## OOM 撑爆页缓存 → WAL 腰斩 → state.db 损坏（2026-09-04 完整案例）

### 症状链（用户视角 → 真实机理）
用户在 TG 只看到一句「**内存/磁盘不够**」，实际是四层因果：

```
database.cache_size = -65536 (每连接 64MB)
        × 网关对 state.db 的 10~19 个并发连接
        ↓
页缓存峰值 0.6~1.2 GB  vs  实例总内存仅 1.9 GB
        ↓
内核 OOM Killer 砍进程（/proc/vmstat: oom_kill 3）
        ↓
WAL 写入在事务中途被腰斩 → B-Tree page / FTS 索引损坏
        ↓
`database disk image is malformed` → 网关每轮触发保护性中断
        ↓
Hermes 抛通用兜底文案「This is often a full disk」→ 用户误判为内存/磁盘不足
```

### 决定性取证命令（只读，按顺序跑）
```bash
# 1. OOM 历史计数 —— 关键！当下 free -h 正常也可能早已被 OOM 过
grep -E "oom_kill|pgmajfault" /proc/vmstat
#    oom_kill > 0  ⇒ 本机发生过 OOM，损坏几乎必然由此而来

# 2. 排除硬件级 I/O 错误（有输出才是硬盘问题）
sudo dmesg -T 2>/dev/null | grep -iE "EXT4-fs error|I/O error|blk_update"
#    注意：非 root 下 dmesg 会报 "read kernel buffer failed: Operation not permitted"，必须 sudo

# 3. 数出网关到底开了多少个 state.db 连接（放大系数）
PID=$(systemctl show --property MainPID --value hermes-gateway.service)
sudo lsof -p $PID | grep -c "state\.db"

# 4. 当前 cache_size 配置
grep -nE "cache_size|wal_autocheckpoint" ~/.hermes/config.yaml
```

### 修复（顺序不可颠倒）
1. **先停全部持有者**：`hermes-gateway` **和** `hermes-web-ui` 都要停，还要 `pkill -f hermes_bridge.py`、`pkill -f hermes-studio-mcp`——web-ui 的 bridge worker 也开 state.db 连接，只停 gateway 会留下活写者把新库再写坏。
2. 离线抢救出干净库（见「Offline Non-Destructive Recovery」节），热替换 + `chmod 644`。
3. **改小 cache_size**：`hermes config set database.cache_size -8192`
   - ⚠️ CLI 会警告 `'database.cache_size' is not a recognized config key — it was saved anyway`。**这条警告是假警报，可以忽略**：`hermes_state.py:1293` 的 `_apply_optional_pragmas()` 确实会读 `database.cache_size`。
   - 但要注意 CLI 会把值写成**字符串** `cache_size: '-8192'`；源码用 `int(str(raw_value).strip())` 解析，字符串同样生效，无需手改回裸数字。
   - 验证已生效：
     ```bash
     python3 -c "
     import sys; sys.path.insert(0,'/home/ubuntu/.hermes/hermes-agent')
     from hermes_cli.config import load_config_readonly, cfg_get
     v = cfg_get(load_config_readonly(),'database','cache_size',default=None)
     print('每连接页缓存:', abs(int(str(v).strip()))/1024, 'MB')"
     ```
4. 重启 gateway + web-ui，验证 `journalctl -u hermes-gateway --since "1 min ago" | grep -icE "malformed|orphan index|file is not a database"` 结果为 **0**。

### 顺带排查：会话绑定的模型是否也挂了
OOM/损坏常与「模型 503」同时出现，两个问题会互相掩盖（压缩回写撞坏库、坏库又让重试无法落盘）。修完库**必须**单独实测该会话绑定的 provider：

```bash
# 读出每个 TG 会话实际绑定的 model_override
python3 -c "
import sqlite3, json
c = sqlite3.connect('file:$HOME/.hermes/state.db?mode=ro', uri=True)
for k, ej in c.execute('SELECT session_key, entry_json FROM gateway_routing'):
    e = json.loads(ej); mo = e.get('model_override') or {}
    print(k, '->', mo.get('provider') or '全局默认', '/', mo.get('model') or '全局默认',
          '| tokens:', f\"{e.get('last_prompt_tokens',0):,}\")"
```
然后对该 base_url 发一发真实 `curl` 探活。若 provider 已挂（如 nofx 持续 503），**在网关停止状态下**直接改 `gateway_routing.entry_json` 的 `model_override` 切到健康节点：

```python
# 必须先 systemctl stop hermes-gateway，否则写入会与网关抢锁
import sqlite3, json, time
c = sqlite3.connect('/home/ubuntu/.hermes/state.db', timeout=15); c.isolation_level = None
KEY = 'agent:main:telegram:dm:<user_id>'
scope, ej = c.execute("SELECT scope, entry_json FROM gateway_routing WHERE session_key=?", (KEY,)).fetchone()
e = json.loads(ej)
e['model_override'] = {"model": "gemini-3.8-flash-high",
                       "provider": "custom:gemini-proxy",
                       "base_url": "http://localhost:8317/v1"}
c.execute("UPDATE gateway_routing SET entry_json=?, updated_at=? WHERE scope=? AND session_key=?",
          (json.dumps(e, ensure_ascii=False), time.time(), scope, KEY))
c.execute("PRAGMA wal_checkpoint(TRUNCATE);")
print('integrity:', c.execute('PRAGMA integrity_check').fetchone()[0])
```
这样改是安全的（`gateway_routing` 是路由索引表，不动 `messages`），历史上下文完整保留。

## 死局：`malformed database schema (<name>) - orphan index`

热替换后若网关启动即报：

```text
ERROR hermes_state: state.db schema is malformed (malformed database schema (agent:main:telegram:dm:<YOUR_TELEGRAM_ID>) - orphan index)
WARNING hermes_state: state.db FTS in-place rebuild pass failed: ... orphan index
WARNING hermes_state: state.db REINDEX pass failed: ... orphan index
ERROR hermes_state: state.db schema repair could not recover ... automatically
```

### 关键认知：这是一条**不可原地修复**的死路
- 索引名是一个 **session_key 字符串**（`agent:main:telegram:dm:<id>`），说明 `sqlite_master` 的 schema 行本身已被写坏 —— 不是普通的 stale index。
- SQLite 在**解析阶段**就拒绝，任何 SQL 都进不去，包括抢救手段本身：
  ```bash
  sqlite3 state.db "SELECT * FROM sqlite_master;"          # ✗ Error: malformed database schema ... (11)
  sqlite3 state.db "PRAGMA writable_schema=ON; DELETE ..." # ✗ Parse error near line 2: ... orphan index (11)
  ```
  → **`writable_schema=ON` 删孤儿索引这条常见偏方在此完全无效**，不要浪费时间试。
- `hermes sessions repair` 也会失败并给出 `✗ Repair failed: database disk image is malformed`。

### 唯一出路
回到**未被网关碰过的原始抢救母本**（`state_recovered_<ts>.db`），重新热替换，且这次务必先停 web-ui / bridge / mcp（见上节第 1 步）。抢救母本一旦被带 orphan index 的进程打开过就会再次被污染，所以：
- **抢救母本必须只用 `cp -f` 复制、绝不 `mv`**，永远保留一份干净原件；
- 每次替换前后都跑 `sqlite3 <db> "PRAGMA integrity_check;"` 双向确认；
- 用隔离副本预演「SessionDB 打开是否自毁」再动真库：
  ```bash
  cp state_recovered_<ts>.db /tmp/test_state.db
  python3 -c "
  import sys, sqlite3, pathlib; sys.path.insert(0,'/home/ubuntu/.hermes/hermes-agent')
  import hermes_state
  p = pathlib.Path('/tmp/test_state.db')
  db = hermes_state.SessionDB(db_path=p); db.close()
  print('open后 integrity:', sqlite3.connect(f'file:{p}?mode=ro', uri=True).execute('PRAGMA integrity_check').fetchone())"
  ```
  正常应打印 `Rebuilt stale state.db FTS indexes ...` + `('ok',)`。
  ⚠️ `/tmp` 在本机是 **tmpfs（仅 953MB）**，53MB 的库副本可以放，但用完 `rm -f /tmp/test_state.db*`，否则挤占本就紧张的内存。

## Stale file handle scenario (inode staleness)

Even when `PRAGMA integrity_check` returns `ok`, the gateway may report `database disk image is malformed` if the running process holds file descriptors to **deleted** old inodes while the on-disk files are healthy replacements.

### Diagnosis

```bash
PID=$(systemctl show --property MainPID --value hermes-gateway.service)
lsof -p $PID | grep 'state.db'
```

Look for `(deleted)` markers — e.g. `state.db (deleted)`, `state.db-wal (deleted)`, `state.db-shm (deleted)`. If present, the process's SQLite connection is reading from stale inodes.

### Root cause (2026-08-14 case study)

```
PID 29145:
  fd 10: state.db (deleted)        — opened 05:58, old inode
  fd 11: state.db-wal (deleted)    — opened 05:58, old inode
  fd 12: state.db-shm (deleted)    — opened 05:58, old inode
  fd 13: state.db                   — opened 06:18, new inode (same path)
  fd 14: state.db-wal               — opened 06:18, new inode
  fd 15: state.db-shm               — opened 06:18, new inode
```

The process opened the old files at 05:58, then at 06:18 opened the same paths again (new inodes, e.g. after a file replacement). SQLite's connection used the old (deleted) inodes, causing WAL/SHM inconsistency even though the on-disk "state.db" was healthy. The gateway logged malformed errors every few seconds (579 consecutive failures).

### Fix

Restart the gateway process (see gateway-ops SKILL.md "重启 gateway" section). After restart, verify:

```bash
PID=$(systemctl show --property MainPID --value hermes-gateway.service)
lsof -p $PID | grep 'state.db'  # no (deleted) markers
```

### Note on protection mechanism

Gateway restart commands (`systemctl restart`, `hermes gateway restart`, `at`, `cronjob` with restart scripts) are all blocked from within the gateway process to prevent SIGTERM-respawn loops. Use the **systemd-run delay** approach (documented in the gateway-ops SKILL.md) or, as a last resort, attach gdb to the running process:

```bash
sudo gdb -p <PID> -batch -ex 'call PyRun_SimpleString("import os,signal; os.kill(os.getpid(), signal.SIGTERM)")'
```

This makes the process self-terminate cleanly, and systemd's `Restart=always` policy automatically starts a fresh instance with clean file handles.

## Long-term Prevention & Hardening against Recurring Cycles (5-6 Day Failures)

When `database disk image is malformed` recurs predictably every 5~6 days (e.g. after ~10,000 messages / 30MB+ bloat), reactive reset/replacement merely resets the countdown. Hardening requires:

### 1. Underlying PRAGMA Configuration (`~/.hermes/config.yaml`)
Ensure SQLite database PRAGMAs are explicitly defined under the `database:` section so Hermes applies them on initialization:
```yaml
database:
  wal_autocheckpoint: 100        # Force checkpoints every 100 pages to prevent huge dirty WAL backlogs
  journal_size_limit: 33554432   # Cap WAL/journal size to 32MB
  temp_store: 2                  # Keep temporary indices/tables in RAM (MEMORY)
  cache_size: -8192              # 8MB page cache PER CONNECTION — see sizing rule below
```

#### ⚠️ `cache_size` 必须按「每连接 × 总内存」定容（2026-09-04 实测教训）
`cache_size` 是 **per-connection（每个 SQLite 连接各自一份）**，不是全库共享一份。`hermes_state.py:1293` 的
`_apply_optional_pragmas()` 会把它无差别下发到**所有**连接类型（writer / read_only / WAL per-thread readers）。

实测网关单进程对 `state.db` 持有 **10~19 个 fd**（`lsof -p $(systemctl show -p MainPID --value hermes-gateway) | grep state.db`）：

| cache_size | 每连接 | 10 连接 | 19 连接 |
|---|---|---|---|
| `-65536` | 64 MB | 0.62 GB | **1.19 GB** |
| `-8192` | 8 MB | 0.08 GB | 0.15 GB |

在 1.9 GB 内存的 AWS 小实例上，`-65536` 会把页缓存吃到 1.2 GB，叠加 gateway 自身 RSS(约 320MB) + web-ui + userbot 直接触发 OOM。
**定容规则：`|cache_size| × 20 ≤ 总内存的 10%`。** 1.9GB 机器用 `-8192`；4GB 用 `-16384`；8GB 以上才考虑 `-65536`。

> 本文件早期版本曾建议 `cache_size: -65536`，那是在未考虑「per-connection × 连接数」放大效应下写的，在小内存机器上是**致命错误配置**，已更正。

### 2. Preventing Torn Writes on Abrupt Process Exit
When an agent session exhausts max_iterations (30 turns) or receives SIGTERM/exit status 1, in-flight transactions must not be abandoned mid-write. Frequent auto-checkpoints (step 1) ensure that the uncheckpointed page window is minimal at any instant.

### 3. Automated Routine Maintenance Cadence
Periodically run `PRAGMA wal_checkpoint(TRUNCATE)` and `PRAGMA quick_check` across `state.db`, `kanban.db`, and `response_store.db` via a maintenance script or cron, preventing unbounded FTS5 segment fragmentation.

## Long-term Prevention & Daily Maintenance

To prevent SQLite B-Tree degradation and FTS desynchronization permanently:
1. **Automated Daily WAL Checkpoint & Optimization**:
   Ensure `daily_cleanup.sh` (or a daily cron maintenance job) runs:
   ```python
   import sqlite3, os
   home = os.path.expanduser("~/.hermes")
   for db in ["state.db", "kanban.db", "response_store.db"]:
       p = os.path.join(home, db)
       if os.path.exists(p):
           conn = sqlite3.connect(p, timeout=10.0)
           conn.execute("PRAGMA wal_checkpoint(PASSIVE);")
           conn.execute("PRAGMA optimize;")
           res = conn.execute("PRAGMA quick_check;").fetchone()
           conn.close()
   ```
2. **Periodic Cleanup of Legacy Malformed Backups**:
   Purge older `state.db.malformed-backup-*` dumps (>2 days) to avoid eating hundreds of megabytes of disk space.
3. **Safe Online Backup Protocol**:
   Never copy `state.db` directly while the gateway is running. Always use SQLite's native online backup API (`sqlite3_backup` / `s.backup(d)`) as implemented in `backup_hermes.sh` and `push_lemon_github.sh`.

Before any destructive or reconstructive operation, stop the sole gateway process cleanly and preserve:

```text
~/.hermes/state.db
~/.hermes/state.db-wal
~/.hermes/state.db-shm
~/.hermes/state.db.malformed-backup-*
```

Then use a Hermes-supported FTS rebuild or restore from a verified backup. If no working repair has been executed and verified, report the database as still unhealthy rather than presenting a speculative command sequence as a fix.
