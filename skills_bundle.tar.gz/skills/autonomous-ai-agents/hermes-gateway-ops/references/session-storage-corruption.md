# Session storage corruption reference

## Observed failure pattern

The user-facing warning

```text
No reply: the turn was stopped because session storage could not be written (the transcript would have been lost on restart). This is often a full disk — free some space (or fix state.db permissions), then send your message again.
```

### User misconception vs Root cause
- **User misconception**: The warning explicitly states *"This is often a full disk — free some space"*, leading users to inspect RAM/Swap (`free -h`) or disk space (`df -h`). Even when RAM and disk have gigabytes of free space and 90%+ free inodes, the error can still fire.
- **True root cause**: This is a generic Hermes fail-safe catch-all message when a SQLite write transaction or session transcript commit fails. The actual culprit is almost always **SQLite B-Tree / FTS corruption (`database disk image is malformed` / `file is not a database`)** or **stale deleted inode handles** held by the gateway process.

The decisive log patterns are:

```text
database disk image is malformed
file is not a database
state.db write failed with an FTS-corruption error
state.db FTS indexes remain corrupt
single-entry routing save failed ... falling back to full index rewrite
Persisted transcript lagged live cached history ... possible FTS write corruption
```

When these repeat for Telegram DM and group keys, inbound messages may still be observed and a response may even be sent, while routing/transcript persistence remains unreliable. This explains intermittent recurrence of the warning.

## Safe read-only probe

Use the environment's available interpreter explicitly:

```bash
hermes doctor
python3 - <<'PY'
import sqlite3, os
p = os.path.expanduser('~/.hermes/state.db')
c = sqlite3.connect(f'file:{p}?mode=ro', uri=True, timeout=2)
print('integrity:', c.execute('PRAGMA integrity_check').fetchone())
print('tables:', c.execute("select name from sqlite_master where type='table' order by name").fetchall())
for table in ('messages', 'sessions', 'gateway_routing'):
    try:
        print(table, c.execute(f'select count(*) from "{table}"').fetchone())
    except Exception as e:
        print(table, type(e).__name__, e)
c.close()
PY
```

Important: the canonical routing table is `gateway_routing`; querying `routing` is a false negative. A successful SQLite `integrity_check` is not sufficient to clear Hermes FTS corruption if Hermes logs report malformed FTS indexes.

## Evidence boundaries

- Keep `database disk image is malformed` / FTS corruption separate from `No LLM provider configured`; the latter is provider selection/configuration.
- Keep missing API keys in `hermes doctor` separate from Telegram persistence diagnosis.
- A running gateway process is not proof that session writes work.
- Do not claim a repair succeeded unless the gateway was stopped, backups were made, the repair command completed, integrity and table reads passed, and a short Telegram message was verified afterward.
- Until repaired, avoid repeatedly sending test messages because each turn can create more failed routing writes.

## WAL 强删与非正常退出（`file is not a database` & `FOREIGN KEY constraint failed`）

### 1. 强行删除 WAL/SHM 或直接 `cp` 覆盖主库
在 SQLite WAL 模式下，主库 `state.db`、预写日志 `state.db-wal` 与共享内存 `state.db-shm` 是紧密耦合的。
- ❌ **致命操作**：在网关运行时执行 `rm -f *.db-wal *.db-shm` 或 `cp state.db.bak state.db`。
- **后果**：破坏了 WAL page sequence 对应关系，导致 SQLite 抛出 `DatabaseError: file is not a database`。
- **正确做法**：必须先停止网关进程，再使用 `PRAGMA wal_checkpoint(TRUNCATE);` 清理 WAL，严禁在服务存活时硬删文件。

### 2. 数据库重建后的外键孤儿与死信队列冲突（`FOREIGN KEY constraint failed` & `pending_messages` 积压）
- **现象**：用户发送消息时偶发中断报 `session storage could not be written`，日志提示 `Failed to recover pending message from pending-*.json: FOREIGN KEY constraint failed`。
- **根因**：网关在连接抖动或异常退出时，将未落盘消息写入 `~/.hermes/pending_messages/*.json` 暂存。如果相关会话在 `sessions` 表中已被重置或结束，重启重放这批死信时会强校验外键失败，阻塞正常会话写入。
- **排查与修复**：
  1. 检查并清理死信文件：`rm -f /home/ubuntu/.hermes/pending_messages/*.json`。
  2. 重建 FTS 索引：`sqlite3 ~/.hermes/state.db "INSERT INTO messages_fts(messages_fts) VALUES('rebuild'); INSERT INTO messages_fts_trigram(messages_fts_trigram) VALUES('rebuild');"`。
  3. 在 `db_maintenance.py` 定时维护中增加过期暂存文件自动清理。

## Offline Non-Destructive Recovery (`hermes sessions recover`)

When in-place repair tools (`hermes doctor --fix` or `hermes sessions repair`) fail due to severe SQLite B-Tree page corruption (`database disk image is malformed` / `invalid page number` / `btreeInitPage error code 11`):

### 1. Execute Non-Destructive Rowid Salvage
Hermes provides an offline salvage tool that scans readable rowid ranges, bypasses corrupted pages, and reconstructs the schema and FTS virtual indexes into a new database without modifying the active database:

```bash
# 1. Inspect recoverability first
python3 -m hermes_cli.main sessions recover --source ~/.hermes/state.db --inspect-only

# 2. Extract into a clean database (use --allow-partial if corrupted ranges exist)
python3 -m hermes_cli.main sessions recover \
    --source ~/.hermes/state.db \
    --output ~/.hermes/state_clean_recovered.db \
    --allow-partial
```

### 2. Verify Recovered Database Health
Before replacing the active database, verify the output passes integrity checks:
```bash
sqlite3 ~/.hermes/state_clean_recovered.db "PRAGMA integrity_check; SELECT count(*) FROM messages; SELECT count(*) FROM sessions;"
```
Expected output: `ok` with intact message and session counts.

### 3. Safe Swap & Gateway Restart
Because Hermes prevents child processes from restarting the parent gateway from within the conversation loop, prepare a swap script for the user/external shell:
```bash
cat << 'EOF' > ~/.hermes/swap_db.sh
#!/usr/bin/env bash
set -e
cd /home/ubuntu/.hermes
mkdir -p "state_db_backup_$(date +%Y%m%d_%H%M%S)"
cp -a state.db* "state_db_backup_$(date +%Y%m%d_%H%M%S)/" 2>/dev/null || true
cp -f state_clean_recovered.db state.db
rm -f state.db-wal state.db-shm
chmod 644 state.db
sudo systemctl restart hermes-gateway.service
sleep 3
systemctl is-active hermes-gateway.service
EOF
chmod +x ~/.hermes/swap_db.sh
```

## Stale file handle scenario (inode staleness)

Even when `PRAGMA integrity_check` returns `ok`, the gateway may report `database disk image is malformed` if the running process holds file descriptors to **deleted** old inodes while the on-disk files are healthy replacements.

### Diagnosis

```bash
PID=$(systemctl show --property MainPID --value hermes-gateway.service)
lsof -p $PID | grep 'state.db'
```

Look for `(deleted)` markers — e.g. `state.db (deleted)`, `state.db-wal (deleted)`, `state.db-shm (deleted)`. If present, the process's SQLite connection is reading from stale inodes.

### Root cause (2026-08-14 case study)

```
PID 29145:
  fd 10: state.db (deleted)        — opened 05:58, old inode
  fd 11: state.db-wal (deleted)    — opened 05:58, old inode
  fd 12: state.db-shm (deleted)    — opened 05:58, old inode
  fd 13: state.db                   — opened 06:18, new inode (same path)
  fd 14: state.db-wal               — opened 06:18, new inode
  fd 15: state.db-shm               — opened 06:18, new inode
```

The process opened the old files at 05:58, then at 06:18 opened the same paths again (new inodes, e.g. after a file replacement). SQLite's connection used the old (deleted) inodes, causing WAL/SHM inconsistency even though the on-disk "state.db" was healthy. The gateway logged malformed errors every few seconds (579 consecutive failures).

### Fix

Restart the gateway process (see gateway-ops SKILL.md "重启 gateway" section). After restart, verify:

```bash
PID=$(systemctl show --property MainPID --value hermes-gateway.service)
lsof -p $PID | grep 'state.db'  # no (deleted) markers
```

### Note on protection mechanism

Gateway restart commands (`systemctl restart`, `hermes gateway restart`, `at`, `cronjob` with restart scripts) are all blocked from within the gateway process to prevent SIGTERM-respawn loops. Use the **systemd-run delay** approach (documented in the gateway-ops SKILL.md) or, as a last resort, attach gdb to the running process:

```bash
sudo gdb -p <PID> -batch -ex 'call PyRun_SimpleString("import os,signal; os.kill(os.getpid(), signal.SIGTERM)")'
```

This makes the process self-terminate cleanly, and systemd's `Restart=always` policy automatically starts a fresh instance with clean file handles.

## Long-term Prevention & Hardening against Recurring Cycles (5-6 Day Failures)

When `database disk image is malformed` recurs predictably every 5~6 days (e.g. after ~10,000 messages / 30MB+ bloat), reactive reset/replacement merely resets the countdown. Hardening requires:

### 1. Underlying PRAGMA Configuration (`~/.hermes/config.yaml`)
Ensure SQLite database PRAGMAs are explicitly defined under the `database:` section so Hermes applies them on initialization:
```yaml
database:
  wal_autocheckpoint: 100        # Force checkpoints every 100 pages to prevent huge dirty WAL backlogs
  journal_size_limit: 33554432   # Cap WAL/journal size to 32MB
  temp_store: 2                  # Keep temporary indices/tables in RAM (MEMORY)
  cache_size: -65536             # 64MB page cache
```

### 2. Preventing Torn Writes on Abrupt Process Exit
When an agent session exhausts max_iterations (30 turns) or receives SIGTERM/exit status 1, in-flight transactions must not be abandoned mid-write. Frequent auto-checkpoints (step 1) ensure that the uncheckpointed page window is minimal at any instant.

### 3. Automated Routine Maintenance Cadence
Periodically run `PRAGMA wal_checkpoint(TRUNCATE)` and `PRAGMA quick_check` across `state.db`, `kanban.db`, and `response_store.db` via a maintenance script or cron, preventing unbounded FTS5 segment fragmentation.

## Long-term Prevention & Daily Maintenance

To prevent SQLite B-Tree degradation and FTS desynchronization permanently:
1. **Automated Daily WAL Checkpoint & Optimization**:
   Ensure `daily_cleanup.sh` (or a daily cron maintenance job) runs:
   ```python
   import sqlite3, os
   home = os.path.expanduser("~/.hermes")
   for db in ["state.db", "kanban.db", "response_store.db"]:
       p = os.path.join(home, db)
       if os.path.exists(p):
           conn = sqlite3.connect(p, timeout=10.0)
           conn.execute("PRAGMA wal_checkpoint(PASSIVE);")
           conn.execute("PRAGMA optimize;")
           res = conn.execute("PRAGMA quick_check;").fetchone()
           conn.close()
   ```
2. **Periodic Cleanup of Legacy Malformed Backups**:
   Purge older `state.db.malformed-backup-*` dumps (>2 days) to avoid eating hundreds of megabytes of disk space.
3. **Safe Online Backup Protocol**:
   Never copy `state.db` directly while the gateway is running. Always use SQLite's native online backup API (`sqlite3_backup` / `s.backup(d)`) as implemented in `backup_hermes.sh` and `push_lemon_github.sh`.

Before any destructive or reconstructive operation, stop the sole gateway process cleanly and preserve:

```text
~/.hermes/state.db
~/.hermes/state.db-wal
~/.hermes/state.db-shm
~/.hermes/state.db.malformed-backup-*
```

Then use a Hermes-supported FTS rebuild or restore from a verified backup. If no working repair has been executed and verified, report the database as still unhealthy rather than presenting a speculative command sequence as a fix.
