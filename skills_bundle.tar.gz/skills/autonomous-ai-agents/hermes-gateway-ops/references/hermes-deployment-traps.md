# Hermes 自动化安装、克隆还原与运维常见陷阱 (2026-09-03 实录)

本参考文档汇总在排查并修复 `lemon-starter`、`lemon-backup` 及 Hermes 部署链路中发现的架构设计、权限控制与自动化运维细节。

---

## 1. Systemd 服务注册与重载时序

在自动化脚本（如 `install.sh`）中生成或还原 systemd 单元文件时，必须严格遵守以下时序：
1. **生成/复制文件**：将 `.service` 文件放置于 `/etc/systemd/system/`。
2. **重载守护进程配置**：`sudo systemctl daemon-reload`。
3. **启用并启动服务**：`sudo systemctl enable --now <service_name>`。

❌ **反模式**：在循环内先执行 `systemctl enable --now`，循环结束后才执行 `daemon-reload`。全新部署环境下 systemd 会因为内存中尚未感知到磁盘上的 unit 文件而报错失败。

---

## 2. Web UI (8648) 进程守护与构建白名单

1. **持久化守护**：
   - Web UI (`hermes-web-ui`) 默认 CLI 启动为前台或受限子进程，服务器重启后无法自启。
   - 生产环境中必须通过标准 systemd 服务（`/etc/systemd/system/hermes-web-ui.service`）接管，指定 `User`、`WorkingDirectory` 以及环境变量（`NODE_ENV=production`, `PORT=8648`）。
2. **npm 10+ / Node.js 22 全局脚本执行白名单**：
   - 全局安装 `hermes-web-ui@latest` 时，`protobufjs` 与 `vue-demi`、`agent-browser`、`node-pty` 会触发 postinstall 脚本安全拦截。
   - 正确的静默安装命令参数：
     ```bash
     sudo npm install -g --allow-scripts=agent-browser,node-pty,protobufjs,vue-demi hermes-web-ui@latest
     ```
3. **异地克隆还原自愈**：
   - 当快照恢复中包含 `hermes-web-ui.service` 时，还原脚本必须前置检测系统是否具备 `node` 与 `hermes-web-ui`。若无，需自动配置 Nodesource 源并安装 Node.js 22.x，避免服务因缺运行环境陷入不断崩溃重试。

---

## 3. Telegram 网关权限字段分流 (DM vs Group)

Hermes 核心权限模块 `gateway/slash_access.py` 对斜杠指令权限实施分作用域控制：
- **私聊（DM）**：校验 `allow_admin_from` 与 `user_allowed_commands`。
- **群聊（Group）**：校验 `group_allow_admin_from` 与 `group_user_allowed_commands`。

⚠️ **关键陷阱**：
- 若仅配置 `allow_admin_from` 而未配置 `group_allow_admin_from`，群聊场景下的斜杠权限门控会被**完全关闭**（`enabled = bool(admin_ids)` 为假），导致非管理员也能在群里执行敏感配置指令！
- 安装套件在初始化 `config.yaml` 时，必须同步写入：
  ```yaml
  telegram:
    enabled: true
    allow_admin_from:
      - <YOUR_TELEGRAM_ID>
    group_allow_admin_from:
      - <YOUR_TELEGRAM_ID>
    user_allowed_commands: help,whoami
    group_user_allowed_commands: help,whoami,clear,model,stop,summary
  ```

---

## 4. 引导脚本 (Bootstrap) 私有凭证展开

通过一键 `curl | bash` 引导从私有 GitHub 仓库克隆代码时：
```bash
git clone "https://${GH_TOKEN}@github.com/$REPO.git" lemon-pkg
```
必须确保 `${GH_TOKEN}` 使用安全变量展开并有兜底校验。提示文档中的使用方法应使用 `<YOUR_TOKEN>` 占位符，严禁在脚本执行行使用可能导致变量失效的特殊字符。
