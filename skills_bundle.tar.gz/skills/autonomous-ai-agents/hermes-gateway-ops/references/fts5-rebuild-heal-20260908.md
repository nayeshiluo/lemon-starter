# FTS5 rebuild 自愈与两类损坏判定（2026-09-08 实测实录）

姊妹篇：`fts5-merge-corruption-20260907.md`（根因链与 merge 失败实验）。
本篇记录 2026-09-08 的根治动作与全部实测数据：**merge 失败 ≠ rebuild 失败**，rebuild 是本环境可用的安全修复手段；以及物理损坏 vs 逻辑不一致的判定与响应。

## 背景时间线（本次会话）

- 爸爸 23:26 发「后面我需要做什么」时撞上熔断：日志 `Turn ended: reason=session_persistence_failed` → 用户看到 `⚠️ No reply: session storage could not be written`。
- 底层：gateway 重启 + 从 `~/backups/hermes-20260907_030035/state.db` 冷恢复（爸爸手动 `mv state.db state.db.bad` + `cp` + restart）。
- 会话恢复后爸爸说「你上次也是这么说的……」——对口头保证零容忍，催生"机制而非承诺"汇报准则（见 SKILL.md 汇报纪律第 7 条）。

## 关键实测数据

### 1. `rebuild` 命令在本环境可用（与 merge 相反）

```sql
-- 在线库全量重建两个 FTS 索引（external-content 表，从 messages 重读，不丢数据）
INSERT INTO messages_fts(messages_fts) VALUES('rebuild');
INSERT INTO messages_fts_trigram(messages_fts_trigram) VALUES('rebuild');
-- 实测：16,298 行 + trigram，耗时 4.1 秒（real 0m4.143s），随后
-- PRAGMA integrity_check = ok；messages = FTS = 16,305 完全对齐（网关持续写入中）
```

- 对比：`merge` 命令 23/23 必失败（SQL logic error，见 09-07 篇）；`rebuild` 从未失败。
- 副本上同样验证：`rebuild OK` → integrity ok → count 一致。
- **结论：FTS 逻辑异常时首选 `rebuild`，不要删库、不要 `.dump` 恢复。**

### 2. FTS5 架构确认（external-content 模式）

```sql
CREATE VIRTUAL TABLE messages_fts USING fts5(content, tool_name, tool_calls,
    content='messages', content_rowid='id');
CREATE VIRTUAL TABLE messages_fts_trigram USING fts5(..., content='messages_fts_trigram_src',
    content_rowid='id', tokenize='trigram');
```

- shadow 表：`_data/_idx/_docsize/_config`（FTS5 无 `segdir`，那是 FTS3/4 的——查错会报 no such table，别误判）。
- 同步靠触发器（`messages_fts_insert/_update/_delete`），由 `state_meta` 的 `fts_rebuild_high_water` / `fts_rebuild_progress` 门控（Hermes 官方 deferred rebuild 编排，`hermes_state_search.py`）。
- **触发器欠账（索引缺行/孤儿行）不触发 integrity-check、查询也不崩溃**——external-content 表查询回源 content 表。这不是 No reply 的成因。

### 3. 两类损坏判定与响应

| 现象 | 判定 | 响应 |
|---|---|---|
| `PRAGMA integrity_check` 报 `btreeInitPage() returns error code 11` / `database disk image is malformed` | b-tree **物理页损坏** | rebuild 也会被事务级拒绝 → 停网关 → 从干净备份冷恢复 → 删旧 wal/shm → 启动 → 真实写入验收 |
| FTS `integrity-check` 命令报错但主库 integrity ok | FTS 内部结构异常 | 备份 → rebuild → 复检；autoheal 脚本自动做 |
| messages 与 FTS count 不一致 | 触发器欠账（多半来自 `.dump` 恢复） | rebuild 补齐；不是 No reply 成因 |

### 4. `.dump` 恢复法对 FTS5 是陷阱（实证）

- `.dump` **不导出虚拟表内容**（FTS 无行存储）→ 恢复后历史消息 FTS 索引全空；触发器随 dump 恢复只同步新行 → 永久欠账。
- 本次 23:22 的 `echo '.dump' | sqlite3 state.db > dump.sql; sqlite3 new_state.db < dump.sql` 正是制造 1.5MB `state.db.bad` 的直接原因。
- 正确恢复路径：`sqlite3 state.db ".backup '恢复目标.db'"`（官方 backup API，在线安全）或 Python `conn.backup(dst)`，或冷拷停服后的干净文件。

### 5. 测试/取证技巧

- **FTS5 shadow 表受保护**：`INSERT INTO messages_fts_data VALUES(...)` 报 `table messages_fts_data may not be modified`。要制造索引异常用虚拟表接口：`INSERT INTO messages_fts(rowid, content, ...) VALUES (999999, 'x', NULL, NULL)`。
- **定位 FTS 索引页**（做损坏注入测试）：`SELECT pageno FROM dbstat WHERE name='messages_fts_idx'`（dbstat 虚拟表本环境可用）。
- **破坏页大小**：本机 SQLite 页大小 4096（`PRAGMA page_size`），破坏要按整页写；freelist 页（`PRAGMA freelist_count`）破坏了不影响 integrity，别浪费测试。
- 健康库破坏实验链路（autoheal 全链路验证通过）：注入孤儿行 → 检测静默（孤儿不触发）→ 破坏 `messages_fts_idx` 页 3545 → integrity-check 报 malformed → autoheal 备份+rebuild+复检+报警完整跑通。

## 部署的防线（2026-09-08 最终态）

1. `db_maintenance.py`：`state.db` 完全跳过（`if db_path.name == "state.db": return True`），gateway 是唯一写者。
2. `state_db_autoheal.py`：每 30 分钟 Hermes cron（job `5b548d3db16d`，no_agent），健康静默 / FTS 逻辑异常自动备份+rebuild+通知 / 物理损坏报警+恢复指引。
3. FTS 索引已在线全量 rebuild 至干净态；废弃文件（`state.db.bad`、`corrupted_backup`、`dump.sql`、`pre_fkfix`、`pre_merge`）已清理（释放 ~263MB）。
4. 安全备份留存：`~/backups/state_pre_fts_rebuild_20260907.db`（82MB，rebuild 前快照）。
