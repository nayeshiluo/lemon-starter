# SQLite .recover 导出导致 FTS5 孤儿影子表与虚拟表缺失排查与修复（2026-09-13）

## 1. 现象与报错特征
- 当 `state.db` 发生 B-Tree 底层损坏（如 `Tree X page Y: btreeInitPage() returns error code 11`）时，若使用 `sqlite3 state.db ".recover" | sqlite3 state_fixed.db` 恢复数据库；
- 换回 `state.db` 后：
  1. `PRAGMA integrity_check` 返回 `ok`（物理表与索引结构完好）；
  2. 但执行 `INSERT INTO messages_fts(messages_fts) VALUES('integrity-check')` 报错：`no such table: messages_fts`；
  3. 网关启动失败或降级，启动日志报错：
     `WARNING gateway.run: SQLite session store not available: fts5: error creating shadow table messages_fts_data: table 'messages_fts_data' already exists`；
  4. 随后网关自动禁用 SQLite 会话存储，消息无法落盘，仅在内存暂存。

## 2. 根因机理
- SQLite 官方的 `.recover` 工具专门用于提取标准 B-Tree 表的行记录（`sessions`, `messages` 完整保留）；
- 但 `.recover` **不会导出虚拟表元定义**（Virtual Table Definition），而是将 FTS5 内部持有的底层影子表（`messages_fts_data`, `messages_fts_idx`, `messages_fts_docsize`, `messages_fts_config` 及 trigram 对应表）导出为普通数据表，同时把触发器也导出了；
- 结果：
  - 触发器指向不存在的虚拟表 `messages_fts`；
  - 启动时 Hermes 执行 `CREATE VIRTUAL TABLE IF NOT EXISTS messages_fts USING fts5(...)`；
  - SQLite FTS5 引擎在建虚拟表时尝试建底层 shadow table，发现同名普通表已存在，抛出 `table 'messages_fts_data' already exists` 致命错误，导致会话持久化引擎初始化彻底中断。

## 3. 经过实测验证的安全修复方案

不要重复尝试 `.recover` 或 `.dump`，利用 Hermes 内置的 `repair_state_db_schema` / `SessionDB` 机制：

### 步骤 1：清空孤儿影子表与失效触发器
```python
import sqlite3

conn = sqlite3.connect('/home/ubuntu/.hermes/state.db', isolation_level=None)
conn.execute("PRAGMA writable_schema=ON")
# 彻底删除 sqlite_master 中残留的 15 个 messages_fts% 影子表、触发器与视图
conn.execute("DELETE FROM sqlite_master WHERE name LIKE 'messages_fts%'")
conn.execute("PRAGMA writable_schema=OFF")
conn.commit()
conn.execute("VACUUM")
conn.close()
```

### 步骤 2：官方核心引擎自动重新挂载与索引回填
直接用 Hermes venv 的 Python 调用 `SessionDB` 打开数据库：
```python
import sys
sys.path.insert(0, '/home/ubuntu/.hermes/hermes-agent')
from pathlib import Path
from hermes_state import SessionDB

db = SessionDB(Path('/home/ubuntu/.hermes/state.db'))
# SessionDB 打开时会自动检测缺失的 FTS 表并按规范 DDL 重新生成虚拟表、视图与触发器，并全量重建索引
```

### 步骤 3：验证三要素
1. `PRAGMA integrity_check` -> `[('ok',)]`
2. `INSERT INTO messages_fts(messages_fts) VALUES('integrity-check')` -> 返回 `[]`（无错误）
3. `INSERT INTO messages_fts_trigram(messages_fts_trigram) VALUES('integrity-check')` -> 返回 `[]`（无错误）
4. `db.search_messages('任意历史关键词', limit=3)` -> 成功秒级检索出历史消息，无损恢复。
