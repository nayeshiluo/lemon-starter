# Hermes Gateway 历史运维参考（按需读取）

> 原始技能章节原文保存。优先遵循 SKILL.md 中的最新安全与权限边界。

## 超长命令载荷被 hardline 拦截（`BLOCKED (hardline)`）

排障时习惯把一堆检查塞进一条 `echo + 多命令 + python3 -c` 的大一行，会撞上：

```
BLOCKED (hardline): command parser limit or malformed executable payload.
This command is on the unconditional blocklist and cannot be executed via the agent —
not even with --yolo, /yolo, approvals.mode=off, or cron approve mode.
RECOVERY: ... saved to /home/ubuntu/.hermes/cache/blocked-scripts/blocked-<ts>-<hash>.sh
```

- **这不是"操作被禁"，是载荷体积/可解析性的问题**。提示里明确写了 `this block fires on oversized/unparseable inline command payloads (heredocs, giant one-liners), not on the operation itself`。
- ❌ 不要原样重试，不要改写措辞硬闯，也不要以为是权限问题去加 sudo/yolo。
- ✅ 正确做法（按优先级）：
  1. **拆成几条短命令**分别跑——多数情况最省事，本次就是这么过的。
  2. 需要 Python 逻辑时改用 `execute_code` 工具，不要把 `python3 -c "..."` 塞进 shell。
  3. 读文件用 `read_file`、搜索用 `search_files`，别用 `cat`/`grep` 拼长管道。
  4. 真需要整段脚本：`write_file` 写到 `/tmp/xxx.sh` 再 `bash /tmp/xxx.sh`（间接执行可过）。
  5. 或直接跑提示里给的那个已保存副本：`bash /home/ubuntu/.hermes/cache/blocked-scripts/blocked-*.sh`。
- 另有一类**超时拦截**长得很像但语义完全不同：`BLOCKED: Command timed out without user response. The user has NOT consented`。这是审批超时（用户没点确认），此时**必须停下等用户**，不要换命令绕、不要用别的写法达成同一效果——与上面的载荷拦截处理方式相反，别搞混。



1. 进程状态：`ps aux | grep -i hermes` — 确认 gateway、web-ui、CLI 实例是否在跑
2. 看日志：`~/.hermes/logs/gateway.log`（网关状态）、`~/.hermes/logs/errors.log`（模型调用错误）
3. 查端口：`ss -tlnp | grep 8642`（api_server）、`grep 8648`（web-ui 面板）
4. 查配置：`grep -n "api_server" ~/.hermes/config.yaml` — 确认 key 是否为空

## 关键陷阱：`hermes config set` 的嵌套路径
- ❌ 错误写法：`hermes config set api_server.key <key>` — 会写到**顶层自定义 key**！
  - 现象：警告 `'api_server.key' is not a recognized config key`，且 config.yaml 末尾出现独立的顶层 `api_server:` 段
- ✅ 正确写法：`hermes config set platforms.api_server.key <key>`（api_server 嵌套在 platforms 下）
- 清理误写残留：`hermes config unset api_server.key`
- 机理：`api_server.key` 为空字符串时，gateway 拒绝启动 API 服务（日志：`Refusing to start: API_SERVER_KEY is required`，loopback 绑定也不例外），面板就连不上 → 表现为"面板里发消息没反应"。
- **Web-UI 401 与 API_SERVER_KEY 双处一致性硬规则**：
  1. `config.yaml` → `platforms.api_server.key`（网关进程启动时读取）。
  2. `~/.hermes/.env` → `API_SERVER_KEY=...`（web-ui BFF 每请求动态正则读取）。
  若两处不一致或 `.env` 缺少此变量，面板报错 `Error: API Error 401: Invalid gateway API key (API_SERVER_KEY)`，哪怕 gateway 本身健康。修复：保持两处一致后仅重启 gateway（web-ui 动态读 .env 无需重启）。受保护端点验证：`curl -s -o /dev/null -w "%{http_code}" -H "Authorization: Bearer <key>" http://127.0.0.1:8642/v1/models` 返回 200 即证明鉴权成功。

## 重启 gateway（配置修改后必须重启才生效）
本机已装 systemd 守护（2026-08-12 起，见下节），一律用 systemctl，不要 kill + 手动后台：
1. `sudo systemctl restart hermes-gateway`
2. 状态确认：`systemctl status hermes-gateway --no-pager | head -15` → active (running)
3. 耐心等启动：Telegram 重连较慢（fallback IP 探测 + 8 次重试，约 1-2 分钟），期间正常

## systemd 守护（2026-08-12 事故后加装）
- 事故：网关被任务内 `kill <gateway自身PID>` 命令自杀式杀死（当时任务在改 commands.py 汉化，重启流程 kill 错 PID 把网关+宿主 shell 一起杀了），且是手动 bash 启动无守护，断了没人拉 → TG/面板全部失联。
- 方案：`/etc/systemd/system/hermes-gateway.service`（系统级，User=ubuntu，ExecStart=/home/ubuntu/.local/bin/hermes gateway，Restart=always + RestartSec=5，WantedBy=multi-user.target）
- 安装：`sudo install -m 644 <unit> /etc/systemd/system/ && sudo systemctl daemon-reload && sudo systemctl enable --now hermes-gateway`
- 效果：被杀/崩溃 5 秒内自动复活，开机自启。验证：`ss -tlnp | grep 8642` LISTEN + `curl -s -o /dev/null -w "%{http_code}" http://127.0.0.1:8642/health` → 200 + gateway.log 出现 `✓ telegram connected`。

## 网关会话重置（/new）与"从网关进程内重启"陷阱
场景：某平台（TG）会话上下文臃肿（gateway_routing 的 entry_json.last_prompt_tokens 达数万）导致模型调用超时、回复极慢；用户要求"重置会话"。

### 关键认知
- /new 的官方实现 = `SessionStore.reset_session(session_key)`：生成新 session_id、保留 origin/display_name、is_fresh_reset=True，但**不继承 model_override**（见 gateway/session.py reset_session）。若 config 默认模型与用户实际用的不同（如默认官方 deepseek、用户用便宜中转），重置后必须立刻 `set_model_override()` 补回，否则会话悄悄落到默认（更贵）模型。
- SessionStore **启动时加载一次路由**（_ensure_loaded_locked），运行中外部改 state.db/sessions.json 不会被感知，必须重启网关才生效。
- **网关进程内禁止 stop/restart**：hermes 会拦截（SIGTERM 传播到子进程=自杀），报错提示 "Run `hermes gateway restart` from a separate shell outside the running gateway"。
- 调用 hermes API 的脚本必须用 venv python：`/home/ubuntu/.hermes/hermes-agent/venv/bin/python`，系统 python3 缺依赖（gateway 模块、yaml 等）。
- `hermes send -t telegram:<chat_id> "..."` 无需网关在跑，适合重启后发完成通知。

### 经授权的独立重启与会话重置

- 优先使用网关支持的会话重置命令，确认当前版本是否保留 model_override。
- 当前会话内的明确安全拒绝必须保留，不通过子代理、临时脚本、cron 或 systemd-run 改道。
- 确有授权且有允许的独立运维 shell 时，从该入口执行正常服务管理；没有入口时说明具体阻塞和所需操作。
- 修改数据库路由前备份并停止持库进程；附带 reset 模板是历史参考，不得未经适配直接运行。
- 子进程中断、调度器接受任务或 PID 改变均不证明功能成功。检查启动时间、错误日志与真实 TG/API 交互；没有发送授权时不自行发测试消息。

### 会话存储异常：区分死信队列外键冲突、锁冲突、数据库/FTS 损坏与进程句柄残留
用户再次看到 `No reply: the turn was stopped because session storage could not be written` 时，不要先假设是上下文过大或 SQLite 锁。按以下只读顺序确认：
- ⚠️ **Data Loss Guard 熔断机制与「未经验证即报搞定」禁令（2026-09-08 实录教训）**：
  - **报错本质**：该提示是 Hermes 网关内置的**数据防丢熔断保护**。当处理入站消息准备持久化（写会话路由或追加对话历史）时，若 SQLite 抛出 `file is not a database` 或 `malformed`，网关会硬性中止当前 turn，防止对话在无持久化状态下进行导致重启后丢失。
  - **惨痛教训**：严禁在在线状态下盲目通过 `.dump` 覆写 `state.db` 并在未执行真实写入交互验证前就向用户宣称“已搞定”。若后台线程（如 curator/review）仍持有旧连接，或 dump 重建过程不完整（生成仅 1.5MB 破损库），用户紧接着发消息就会立即触发熔断，体验极度恶劣。
  - **冷备恢复优先**：对于底层 B-tree 级严重破损，首选方案是停服务后从最近的干净备份（如 `~/backups/hermes-*/state.db`）冷恢复，彻底移除旧 wal/shm 后再启动，并必须以一条真实写入与读出作为验收标准。
- ⚠️ **Schema 损坏与孤儿索引（`malformed database schema (...) - orphan index`）**：
  - **现象**：网关启动失败，日志报 `Warning: SQLite session store unavailable, falling back to JSONL: malformed database schema (agent:main:...) - orphan index`，CLI 报 `SessionDB ... malformed database schema`，服务启动即退出。
  - **根因**：`.recover` 导出重放、非原子覆盖或底层 B-Tree 页面损坏时，`sqlite_master` 记录的索引指向了损坏的根页面或不存在的表对象。此时 SQLite 在执行任何 SQL 甚至 `PRAGMA writable_schema=ON` 时都会在 `sqlite3_prepare` 阶段直接报 Error 11 拒绝执行。
  - **排查与恢复**：
    1. 绝不要在网关或 CLI 运行时使用外部脚本不加校验地直接替换或操作正在被读取的 `state.db`。
    2. 检查是否有历史健康恢复库（如 `~/.hermes/state_recovered_*.db`），用 Python 测试 `PRAGMA integrity_check` 是否为 `[('ok',)]` 并确认包含完整 sessions 和 messages 记录。
    3. **原子覆盖与 WAL 清理（关键）**：停止网关及面板后覆盖 `state.db`，**必须彻底删除**残留的 `state.db-wal` 与 `state.db-shm`（防 SQLite 将旧事务重放导致再次损坏）。
    4. **服务恢复与重置**：执行 `sudo systemctl reset-failed hermes-gateway hermes-web-ui && sudo systemctl start hermes-gateway hermes-web-ui`。
    5. **全链路验证**：核查 `ss -tlnp` 确认 8642 与 8648 监听；`curl -H "Authorization: Bearer <KEY>" http://127.0.0.1:8642/v1/models` 返回 200；网关日志出现 `✓ telegram connected`。
- ⚠️ **死信队列外键冲突与内存冲高（`pending_messages` 积压 + Fallback 叠加，2026-08-28 实录）**：
  - **现象**：网关进程驻留内存瞬间冲高至 1.4GB+（在 2GB 机器上触顶异常退出，`hermes-gateway.service` 报 `code=exited, status=1/FAILURE`，Systemd 记录 `memory peak 1.4G`），日志频繁出现 `Session DB transcript append failed: FOREIGN KEY constraint failed (failure_count=500+)`。
  - **根因**：历史会话/群聊记录事务在写回 `state.db` 时触发外键约束失败，网关不断在 RAM 中缓存重试队列（cap=200 并溢出至 `pending_messages/`）；若此时恰逢并发会话跑满单轮 30 次迭代预算并触发向备用模型的 Fallback 切换，两重压力瞬间击穿小内存宿主机。
  - **应急与自愈**：
    1. Systemd 守护在 5 秒内自动重启拉起干净进程，释放驻留内存。
    2. 验证数据库状态：`~/.hermes/hermes-agent/venv/bin/python -c "import sqlite3; c=sqlite3.connect('file:/home/ubuntu/.hermes/state.db?mode=ro', uri=True); c.execute('PRAGMA query_only=ON'); print(c.execute('PRAGMA integrity_check;').fetchall())"`。
    3. 清理失效外键死信文件：`python3 -c "import os, glob; [os.remove(p) for p in glob.glob('/home/ubuntu/.hermes/pending_messages/*.json')]"`。
    4. 只有获准离线修复且已备份后，才在独立副本检查和重建 FTS；不得在线直接重建。
- **周期复发需证据归因**：结合 OOM、WAL、进程、连接与错误时间线分析。历史数据库参数不代表当前最佳配置，不凭固定周期猜根因，也不外加在线 checkpoint。

#### 会话绑定的 provider 挂了怎么切（免 /model、免用户操作）

`state.db` 修完不代表用户能对话：会话的 `model_override` 可能钉在一个已经挂掉的 provider 上（本次 TG 私聊钉着 `custom:nofx / gpt-5.6-terra`，实测 `HTTP 503`，压缩回写又撞坏库，两个问题互相掩盖）。

**排查 → 切换的完整流程见 `references/session-storage-corruption.md`「顺带排查：会话绑定的模型是否也挂了」节**，要点：
1. 从 `gateway_routing.entry_json` 读出每个会话真实绑定的 `model_override`（`sessions.json` 是 legacy 镜像，可能滞后，以 state.db 为准）。
2. 对该 `base_url` 发真实 `curl` 探活，别凭 config 里"配了就是好的"下结论；顺手把主力和备用一起测，得到"哪个能用"的事实再决定切到哪。
3. **数据库路由修改**：先备份并停止全部持库进程，优先经审查的官方接口和副本验证；不在线改路由或额外 checkpoint。
4. 只动 `gateway_routing`（路由索引表），不碰 `messages`，历史上下文完整保留。

