# Hermes 部署套件与系统级服务自愈排障总结

## 1. Web UI 守护进程化（systemd 标准配置）
在 Ubuntu/Debian 上部署 Hermes Web UI 时，避免仅使用 `hermes-web-ui start`（属于非受控用户进程，服务器重启或 OOM 时不会复活）。推荐写入系统服务：
- 服务路径：`/etc/systemd/system/hermes-web-ui.service`
- 依赖顺序：`After=network-online.target hermes-gateway.service`
- 环境变量：需要绑定 `PORT=8648`、`NODE_ENV=production` 与当前系统用户的 `PATH` / `HOME`
- 启动程序：使用绝对路径 `/usr/local/bin/node dist/server/index.js`（WorkingDirectory 为 npm 全局模块根路径下 `hermes-web-ui` 目录）

## 2. npm install -g 脚本执行白名单坑
Node 22 / npm 11+ 对全局包的 postinstall 脚本有严格的默认限制：
`npm install -g hermes-web-ui@latest` 会报：
`npm warn allow-scripts 5 packages have install scripts not yet covered by allowScripts: protobufjs, agent-browser, node-pty, vue-demi`
正确安装与升级参数必须显式声明：
```bash
sudo npm install -g --allow-scripts=agent-browser,node-pty,protobufjs,vue-demi hermes-web-ui@latest
```

## 3. Telegram 群聊与私聊权限分流 (slash_access.py)
Hermes 网关对 Telegram 斜杠命令的处理严格区分作用域：
- 私聊作用域：校验 `telegram.allow_admin_from` 与 `telegram.user_allowed_commands`
- 群聊作用域：校验 `telegram.group_allow_admin_from` 与 `telegram.group_user_allowed_commands`
- 关键坑：若仅配置了 `allow_admin_from` 而未配置 `group_allow_admin_from`，在群聊场景下管理员策略为 disabled，任何普通群员都可能不受控执行管理级指令；因此一键安装脚本或配置模版中必须双向声明！
