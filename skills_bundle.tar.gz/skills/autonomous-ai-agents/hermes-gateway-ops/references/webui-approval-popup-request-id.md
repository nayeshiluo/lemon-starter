# Web UI 审批弹窗点击无效（提示"已过期"）—— request_id 键名错配

2026-10-24 实录。症状：用户在 Hermes Web UI 点审批按钮，界面提示"已过期"，
命令最终以 `BLOCKED: Command timed out without user response` 结束。
用户原话：「你每次给弹窗我点都显示过期了」。

## 根因

两处代码对同一个请求 ID 用了不同的键名。

Hermes agent 侧 `~/.hermes/hermes-agent/tools/approval.py`：

```python
class _ApprovalEntry:
    def __init__(self, data: dict):
        self.data = dict(data)
        self.data["_request_id"] = uuid.uuid4().hex   # 带下划线前缀
```

`_await_gateway_decision()` 里 `approval_data = entry.data`，所以传给 `notify_cb`
的 dict **只有 `_request_id` 键，没有 `request_id` 键**。

Web UI bridge 侧
`/usr/local/lib/node_modules/hermes-web-ui/dist/server/agent-bridge/python/bridge_pool.py`
`_gateway_approval_notify()` 修复前：

```python
request_id = str(approval_data.get("request_id") or "").strip()   # 永远取到 ""
```

`respond_approval()` 里：

```python
resolved = bool(gateway_request_id) and resolve_gateway_approval(...)
```

`bool("")` 为 False，短路，`resolve_gateway_approval` 从未被调用。
点击结果被丢弃，agent 端继续阻塞到 `approvals.timeout`（默认 300 秒）后 fail-closed。

## 日志实证（只读取证路径）

```bash
# 1. 两次超时都恰好是 300 秒
awk '$0>="2026-10-24 03:20" && $0<="2026-10-24 03:50"' ~/.hermes/logs/agent.log \
  | grep -iE "approval|BLOCKED|consent"
# 03:21:21 发起 → 03:26:21 BLOCKED (300.20s)
# 03:29:17 发起 → 03:34:17 BLOCKED (300.39s)

# 2. 用户点击其实很早、bridge 也收到了
grep approval_respond ~/.hermes-web-ui/logs/bridge.log | tail
# 03:21:40 approval_respond approval_id=39c0e0a5...   <- 只隔 19 秒
```

判据：**点击已送达 + 仍等满 timeout + 日志无 `Approval wait interrupted by user signal`**
= 点击没落到等待线程上，属于 resolve 匹配失败，不是用户点晚、不是网络、不是超时太短。

## 修复

`bridge_pool.py` 一行，向后兼容两种键名：

```python
request_id = str(approval_data.get("request_id") or approval_data.get("_request_id") or "").strip()
```

## 隔离验证（不打扰用户、不依赖重启）

在 `~/.hermes/hermes-agent` 下用 venv 直接构造真实 `_ApprovalEntry` 验证匹配链：

```python
from tools.approval import _ApprovalEntry, _gateway_queues, resolve_gateway_approval, _lock
e = _ApprovalEntry({'command':'rm -rf /tmp/x','description':'test'})
data = e.data
print([k for k in data if 'request' in k])      # ['_request_id']  <- 证明键名
old = str(data.get('request_id') or '').strip()  # ''      -> resolved=False
new = str(data.get('request_id') or data.get('_request_id') or '').strip()
with _lock: _gateway_queues['__selftest__'] = [e]
n = resolve_gateway_approval('__selftest__','once',request_id=new)
print(n, e.result, e.event.is_set())             # 1 once True  -> PASS
```

## ⚠️ 重启前必查：谁在托管当前会话

主 bridge 会 fork worker bridge，worker 里跑着当前这条对话。
盲目 `kill` 主 bridge 会连带杀掉 worker 和正在进行的 run，用户的回复直接消失。

```bash
ps -o pid,ppid,etime,cmd -p <bridge_pid>
ss -xlp | grep hermes-agent-bridge          # 主 socket + bridge-workers socket
ps -o pid,ppid,cmd -p $$                    # 反查自己 shell 的父链
```

本机实测链条：`我的 shell ← worker bridge ← 主 bridge(hermes_bridge.py) ← node server(dist/server/index.js)`。

Web UI server 的 `autoRestartEnabled()` 默认开启（除非
`HERMES_AGENT_BRIDGE_AUTO_RESTART` 为 0/false/no/off），SIGTERM 后会自动 respawn。

## 用独立延迟任务重启，避免掐断当前回复

非登录 shell 里 `systemd-run --user` 会报
`Failed to connect to user scope bus ... $DBUS_SESSION_BUS_ADDRESS and $XDG_RUNTIME_DIR not defined`。
先导出两个变量（这是修复方式，不是缺陷）：

```bash
export XDG_RUNTIME_DIR=/run/user/1000
export DBUS_SESSION_BUS_ADDRESS=unix:path=/run/user/1000/bus
systemd-run --user --collect --unit=<name> /path/to/restart.sh
```

脚本内 `sleep 60` 后再 kill，给自己留出把结论发给用户的时间；重启后轮询 socket
确认 **新 pid ≠ 旧 pid**，再 grep 源码确认新进程加载的确实是修复后的文件。

## 生效与回滚

- Python 进程已加载旧字节码，**必须重启主 bridge 才生效**，改文件本身不生效。
- `bridge_pool.py` 属于 npm 全局包，**升级 hermes-web-ui 会覆盖此修复**，升级后需重新打补丁。
- 回滚：恢复备份的 `bridge_pool.py.pre-request-id-fix` 再重启。

## 未改动但需知道的第二处不一致

`bridge_runtime.py` 的 `APPROVAL_TIMEOUT_SECONDS = 120`，
而 `_gateway_approval_notify` 广播的是 `timeout_ms = 300_000`。
CLI bridge run 实测走 gateway 路径（300s），与 agent 的 `approvals.timeout` 一致，
所以本次未改；若将来出现"120 秒就 deny"，查这条 `_approval_callback` 路径。

## 为什么 Telegram 一直好用

TG 适配器走 `/approve` 命令或 `resolve_all=True`，不依赖 `request_id` 精确匹配
（`resolve_gateway_approval` 在 `request_id is None` 时走 FIFO 分支）。
只有 Web UI 按钮走精确匹配，所以只有它坏——**别因为 TG 能用就排除 agent 侧代码问题**。
