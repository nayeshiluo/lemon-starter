# Web UI 审批弹窗点击无效（提示"已过期"）—— request_id 键名错配

2026-10-24 实录。症状：用户在 Hermes Web UI 点审批按钮，界面提示"已过期"，
命令最终以 `BLOCKED: Command timed out without user response` 结束。
用户原话：「你每次给弹窗我点都显示过期了」。

## 根因

两处代码对同一个请求 ID 用了不同的键名。

Hermes agent 侧 `~/.hermes/hermes-agent/tools/approval.py`：

```python
class _ApprovalEntry:
    def __init__(self, data: dict):
        self.data = dict(data)
        self.data["_request_id"] = uuid.uuid4().hex   # 带下划线前缀
```

`_await_gateway_decision()` 里 `approval_data = entry.data`，所以传给 `notify_cb`
的 dict **只有 `_request_id` 键，没有 `request_id` 键**。

Web UI bridge 侧
`/usr/local/lib/node_modules/hermes-web-ui/dist/server/agent-bridge/python/bridge_pool.py`
`_gateway_approval_notify()` 修复前：

```python
request_id = str(approval_data.get("request_id") or "").strip()   # 永远取到 ""
```

`respond_approval()` 里：

```python
resolved = bool(gateway_request_id) and resolve_gateway_approval(...)
```

`bool("")` 为 False，短路，`resolve_gateway_approval` 从未被调用。
点击结果被丢弃，agent 端继续阻塞到 `approvals.timeout`（默认 300 秒）后 fail-closed。

## 日志实证（只读取证路径）

```bash
# 1. 两次超时都恰好是 300 秒
awk '$0>="2026-10-24 03:20" && $0<="2026-10-24 03:50"' ~/.hermes/logs/agent.log \
  | grep -iE "approval|BLOCKED|consent"
# 03:21:21 发起 → 03:26:21 BLOCKED (300.20s)
# 03:29:17 发起 → 03:34:17 BLOCKED (300.39s)

# 2. 用户点击其实很早、bridge 也收到了
grep approval_respond ~/.hermes-web-ui/logs/bridge.log | tail
# 03:21:40 approval_respond approval_id=39c0e0a5...   <- 只隔 19 秒
```

判据：**点击已送达 + 仍等满 timeout + 日志无 `Approval wait interrupted by user signal`**
= 点击没落到等待线程上，属于 resolve 匹配失败，不是用户点晚、不是网络、不是超时太短。

## 修复

`bridge_pool.py` 一行，向后兼容两种键名：

```python
request_id = str(approval_data.get("request_id") or approval_data.get("_request_id") or "").strip()
```

## 隔离验证（不打扰用户、不依赖重启）

在 `~/.hermes/hermes-agent` 下用 venv 直接构造真实 `_ApprovalEntry` 验证匹配链：

```python
from tools.approval import _ApprovalEntry, _gateway_queues, resolve_gateway_approval, _lock
e = _ApprovalEntry({'command':'rm -rf /tmp/x','description':'test'})
data = e.data
print([k for k in data if 'request' in k])      # ['_request_id']  <- 证明键名
old = str(data.get('request_id') or '').strip()  # ''      -> resolved=False
new = str(data.get('request_id') or data.get('_request_id') or '').strip()
with _lock: _gateway_queues['__selftest__'] = [e]
n = resolve_gateway_approval('__selftest__','once',request_id=new)
print(n, e.result, e.event.is_set())             # 1 once True  -> PASS
```

## ⚠️ 重启前必查：谁在托管当前会话

主 bridge 会 fork worker bridge，worker 里跑着当前这条对话。
盲目 `kill` 主 bridge 会连带杀掉 worker 和正在进行的 run，用户的回复直接消失。

```bash
ps -o pid,ppid,etime,cmd -p <bridge_pid>
ss -xlp | grep hermes-agent-bridge          # 主 socket + bridge-workers socket
ps -o pid,ppid,cmd -p $$                    # 反查自己 shell 的父链
```

本机实测链条：`我的 shell ← worker bridge ← 主 bridge(hermes_bridge.py) ← node server(dist/server/index.js)`。

Web UI server 的 `autoRestartEnabled()` 默认开启（除非
`HERMES_AGENT_BRIDGE_AUTO_RESTART` 为 0/false/no/off），SIGTERM 后会自动 respawn。

## 用独立延迟任务重启，避免掐断当前回复

非登录 shell 里 `systemd-run --user` 会报
`Failed to connect to user scope bus ... $DBUS_SESSION_BUS_ADDRESS and $XDG_RUNTIME_DIR not defined`。
先导出两个变量（这是修复方式，不是缺陷）：

```bash
export XDG_RUNTIME_DIR=/run/user/1000
export DBUS_SESSION_BUS_ADDRESS=unix:path=/run/user/1000/bus
systemd-run --user --collect --unit=<name> /path/to/restart.sh
```

脚本内 `sleep 60` 后再 kill，给自己留出把结论发给用户的时间；重启后轮询 socket
确认 **新 pid ≠ 旧 pid**，再 grep 源码确认新进程加载的确实是修复后的文件。

## 生效与回滚

- Python 进程已加载旧字节码，**必须重启主 bridge 才生效**，改文件本身不生效。
- `bridge_pool.py` 属于 npm 全局包，**升级 hermes-web-ui 会覆盖此修复**，升级后需重新打补丁。
- 回滚：恢复备份的 `bridge_pool.py.pre-request-id-fix` 再重启。

## 升级存活：新版本会不会抹掉补丁

用户问「网页面板是不是最新版 / 要不要升级」时，先比对两个包，别凭版本号猜：

```bash
npm view hermes-web-ui version
npm pack hermes-web-ui@<old> && npm pack hermes-web-ui@<new>
mkdir -p v_old v_new && tar xzf hermes-web-ui-<old>.tgz -C v_old && tar xzf hermes-web-ui-<new>.tgz -C v_new

# 1) 补丁文件本身有没有变
sha256sum v_old/package/dist/server/agent-bridge/python/bridge_pool.py \
          v_new/package/dist/server/agent-bridge/python/bridge_pool.py

# 2) 服务端到底动了什么（前端 dist/client/assets 全是带 hash 的 chunk，diff 噪音 700+ 条）
diff -rq v_old/package/dist/server v_new/package/dist/server

# 3) API 增删，判断功能影响面
python3 -c "import json;a=json.load(open('v_old/package/dist/server/openapi.json'));b=json.load(open('v_new/package/dist/server/openapi.json'));print('新增',sorted(set(b['paths'])-set(a['paths'])));print('移除',sorted(set(a['paths'])-set(b['paths'])))"
```

实测结论（0.7.37 → 0.7.39）：`bridge_pool.py` **逐字节相同**，sha256 都是
`433d053a0e88c461c3dd79ddd6ff083984f3a854885a5d9087bb1349c81e3be1`（即 0.7.37 原版），
说明**上游到 0.7.39 仍未修这个 bug**。服务端只变 `index.js` + `openapi.json`：
新增 `/api/studio/session-tasks/*`、`desktop-browser/request`、`models/cloud-link`，
**移除整个 `/api/devices/*`（24 个路径，含 peer-connections 远程终端）**。

**最容易搞错的点：文件两版逐字节相同 ≠ 补丁还在。** npm 全局包是整目录替换，改过的
那份会被原始文件覆盖，升级后必须重打。反过来，若上游真修了（新包该行已含
`_request_id`），脚本的 `--check` 会直接判「已含修复」，不必再打。

**升级前确认受保护服务是否受影响**：`/api/devices/*` 被移除听着吓人，但
`desktop-commander-remote.service` 是独立进程（`ExecStart=/usr/local/bin/desktop-commander remote`），
走 Remote MCP，与该 API 无关。判据是**读 unit 文件看 ExecStart**，不是猜。
注意 `systemctl --user` 在非登录 shell 里同样需要先导出 `XDG_RUNTIME_DIR` /
`DBUS_SESSION_BUS_ADDRESS`，否则报连不上 bus——直接 `read_file` 那个 .service 更快。

一键重打脚本：`scripts/repatch-webui-approval.sh`（幂等，自带 AST + 行为校验 + 失败回滚）。
升级顺序固定为：**备份 → 升级 → 跑脚本 → 延迟重启 bridge → 触发一次真实审批验证点击立即生效**。

写这类「行为校验」时的坑：正则匹配补丁行不要多要求尾括号。实际行尾是
`... or "").strip()`，`.strip()` 自己就是最后一个 `)`，写成 `\.strip\(\)\)` 会匹配不到，
表现为「替换成功、AST 通过、行为校验却说找不到语句」。

## 完整升级实战（0.7.37 → 0.7.39，2026-10-24）

两次尝试，第一次回滚、第二次成功。两个坑都是真踩出来的，且都不在补丁逻辑本身。

### 坑 1：systemd 下没有 `$HOME`，提示文字把脚本顶成非 0

`repatch` 脚本用了 `set -uo pipefail`，末尾提示写了 `$HOME/backups/...`。
systemd transient service **默认不设 `HOME`**，`set -u` 直接
`line 100: HOME: unbound variable` → 脚本退出 1 → 上层判「补丁失败」→ 回滚。
而补丁其实**早就打上了**（`AST 校验: OK`、`行为校验: PASS` 都印在前面几行）。

修法两条都要：

- `$HOME` → `${HOME:-/home/ubuntu}`
- 末尾显式 `exit 0` —— 提示文字不该决定退出码

上层判据同步改成**只认 `--check` 的退出码**，不认提示脚本自己的退出码
（`bash "$REPATCH" || log "补丁脚本返回非 0，改以 --check 为准"`）。
自测：`env -u HOME bash repatch.sh`，既能复现也能验修复。

### 坑 2：npm 11 拦 install scripts → node-pty 编译产物丢失 → 终端坏

日志里 `npm warn allow-scripts` 会列出被拦的包。其中 **node-pty 在 Linux 上没有预编译包**
（`prebuilds/` 只有 darwin-arm64/x64、win32-arm64/x64），
`build/Release/pty.node` 是 postinstall 现场编出来的。

```bash
find node_modules/node-pty -name "*.node" | grep -c prebuilds/linux   # 0，确认无 Linux 预编译
grep -c "node-pty" dist/server/index.js                                # 8，确认服务真在用
ls -l node_modules/node-pty/build/Release/pty.node                     # 必须存在且时间戳=本次安装
```

装的时候必须放行，否则装完是「版本号对、服务能起、终端功能静默坏」：

```bash
npm install -g hermes-web-ui@<ver> --no-fund --no-audit \
  --allow-scripts=agent-browser,node-pty,protobufjs,vue-demi
```

工具链要齐：gcc / g++ / make（node-gyp 由 npm 自带，不必单独装）。

### 正确执行顺序

所有会话都挂在 `node server → hermes_bridge → worker` 上，重启必断当前对话，
所以升级要由**系统级**延迟单元触发（不是 `--user`，因为要 root 重启 system service）：

```bash
sudo systemd-run --unit=hermes-webui-upgrade --on-active=90 \
  --timer-property=AccuracySec=1s /path/to/upgrade-webui.sh
systemctl list-timers 'hermes-webui-upgrade*'    # 必须确认真的挂上了再回复用户
```

脚本内部顺序：整包 tar 备份（并 `tar -tzf` 校验可读）→ 停服务 → npm 装 + 放行 scripts →
验版本号 → 验 `pty.node` → 重打补丁 + `--check` → 起服务 → 轮询 8648 到 200 → 写 STATUS。
任一步失败整体回滚旧版 tar 并重启，STATUS 记 `ROLLED_BACK:`。

实测耗时：npm 装 44s + 就绪探测 11s，**全程 59 秒**；回滚 10 秒（解压 + 起服务）。

### 事后核对清单

```bash
cat <备份目录>/STATUS      # OK:version=... / ROLLED_BACK: / ROLLBACK_FAILED:
systemctl is-active hermes-web-ui.service
python3 -c "import json;print(json.load(open('/usr/local/lib/node_modules/hermes-web-ui/package.json'))['version'])"
curl -s -o /dev/null -w '%{http_code}\n' http://127.0.0.1:8648/
repatch-after-upgrade.sh --check                                  # 必须退出 0
ls -l .../node_modules/node-pty/build/Release/pty.node
journalctl -u hermes-web-ui.service --since "<升级时刻>" -p warning
```

成品脚本在 `hermes-ops-private` 仓库 `projects/hermes-local-patches/scripts/`
（`repatch-after-upgrade.sh` + `upgrade-webui.sh`），不随 npm 包走，升级前就在仓库里。

## 真机验收：怎么触发一次审批，以及怎么判定成败

上面升级清单里写「触发一次真实审批验证点击立即生效」——这一步比看上去难，2026-10-24 实测踩了两个坑。

### 坑 1：低风险命令不会弹窗（smart approval 自动放行）

想造一个审批，随手用「删个临时文件」是不行的，以下都**不会**弹窗、直接执行：

```bash
rm -f /tmp/approval-e2e-test.txt      # 单文件 rm —— 放行
rm -rf /tmp/approval-e2e               # /tmp 下整目录 rm -rf —— 也放行
```

必须用真正命中危险模式的动作。零风险又确定触发的是「临时仓库 + 未提交改动 + `git reset --hard`」：

```bash
rm -rf /tmp/e2e-approval-repo; mkdir -p /tmp/e2e-approval-repo && cd /tmp/e2e-approval-repo \
  && git init -q && git config user.email t@t.t && git config user.name t \
  && echo v1 > f.txt && git add f.txt && git commit -qm init && echo v2 > f.txt
# 下一步单独发，会弹「git reset --hard (destroys uncommitted changes)」
```

### 坑 2：超时后禁止重试，所以每次只有一次机会

`BLOCKED: Command timed out without user response` 的返回里明确写着
`Do NOT retry this command, do NOT rephrase it`。也就是说**第一次没点成，这条验证路径就废了**，
不能换皮重发。因此顺序只能是：

1. 先发一条消息告诉用户「下一条会弹审批，请立刻点允许」
2. 再发命令

反过来（先发命令、指望用户自己发现弹窗）实测失败：用户在 300 秒超时后 25 秒才点，
审批对象已消失，白等 5 分钟。

### 判定成败：三个时间点对齐

`bridge.log` 的 `time` 字段是**毫秒 epoch**，必须换算北京时间再和 `agent.log` 的 `BLOCKED (300.xx s)` 对齐：

```python
import json, datetime
p='/home/ubuntu/.hermes-web-ui/logs/bridge.log'
for line in open(p, encoding='utf-8', errors='replace'):
    if not line.startswith('{') or 'approval' not in line: continue
    d=json.loads(line); ts=d.get('time')
    if not ts: continue
    t=datetime.datetime.fromtimestamp(ts/1000, datetime.timezone.utc)
    bj=(t+datetime.timedelta(hours=8)).strftime('%m-%d %H:%M:%S')
    print(bj, d.get('msg','')[:50], (d.get('request') or {}).get('approval_id',''))
```

| 现象 | 结论 |
|---|---|
| `agent.log` 有 `BLOCKED (300.xx s)`，`bridge.log` **无**任何 `approval_respond` | 弹窗没推到前端 / 用户根本没看到 → 查前端推送 |
| `approval_respond` 时间戳 **早于**超时时刻，但命令仍 BLOCKED | 点击送达但 resolve 没生效 → 补丁失效或又被升级覆盖，跑 `--check` |
| `approval_respond` 时间戳 **晚于**超时时刻，bridge 返回 `{"ok": true}` | **用户点晚了**，链路本身没坏；补丁有效性仍未验证 |
| 命令真的执行了，`agent.log` 出现 `approved by the user` | 闭环成功 |

注意 `approval_respond` 返回 `{"ok": true}` **只代表 bridge 收到了这次点击请求**，
不代表审批被 resolve —— 对象已超时时它照样返回 ok。

### 已验证到什么程度（2026-10-24 那次）

- **已证实**：Web UI 前端 → bridge 的 `approval_respond` 链路完好，请求带 `approval_id` 正常到达。
- **已证实（单元级）**：补丁逻辑正确 —— 模拟 agent 侧 `{"_request_id":"abc123"}` 能取到 `abc123`，
  `resolve_gateway_approval` 返回 1。
- **未证实**：bridge → agent 的 resolve 在超时前真正解除阻塞（那次用户点晚了 25 秒）。

所以报告时要说清「静态 + 单元已过，真机闭环待下次真实审批自然验证」，
**不要因为 `ok: true` 或 `--check` 退出 0 就宣称端到端已通**。

另：`agent.log` 里 `Telegram button resolved N approval(s)` 全是 **Telegram** 侧的成功记录，
不能拿来证明 Web UI 审批好用；筛 Web UI 证据只认 `bridge.log` 的 `approval_respond`。

## 未改动但需知道的第二处不一致

`bridge_runtime.py` 的 `APPROVAL_TIMEOUT_SECONDS = 120`，
而 `_gateway_approval_notify` 广播的是 `timeout_ms = 300_000`。
CLI bridge run 实测走 gateway 路径（300s），与 agent 的 `approvals.timeout` 一致，
所以本次未改；若将来出现"120 秒就 deny"，查这条 `_approval_callback` 路径。

## 为什么 Telegram 一直好用

TG 适配器走 `/approve` 命令或 `resolve_all=True`，不依赖 `request_id` 精确匹配
（`resolve_gateway_approval` 在 `request_id is None` 时走 FIFO 分支）。
只有 Web UI 按钮走精确匹配，所以只有它坏——**别因为 TG 能用就排除 agent 侧代码问题**。
