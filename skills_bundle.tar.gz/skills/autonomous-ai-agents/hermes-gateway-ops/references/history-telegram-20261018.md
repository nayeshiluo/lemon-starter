# Hermes Gateway 历史运维参考（按需读取）

> 原始技能章节原文保存。优先遵循 SKILL.md 中的最新安全与权限边界。

## 关闭"工具过程推送"（display.tool_progress）
用户诉求："对话框里不要显示 💻 terminal / grep 这类命令过程，只看回复"。
- 合法值只有 `off` / `new` / `all` / `verbose` / `log`（gateway/run.py ~25481：`tool_progress_enabled = progress_mode not in {"off","log"}`）
- ⚠️ **`none` 不是合法值**：`hermes config set display.tool_progress none` 会提示 "Did you mean: display.tool_progress_command" 且无效——进度照常推送。正确关闭：`hermes config set display.tool_progress off`（YAML 落为 `false`，`_normalise` 会把 False→"off"）
- 改完必须重启网关生效；验证 `grep tool_progress ~/.hermes/config.yaml` → `false` 或 `off`

## 关闭"📬 尚未为 Telegram 设置主频道"提示
用户抱怨群/会话里出现"📬 尚未为 Telegram 设置主频道。主频道是 Hermes 用来投递定时任务结果和跨平台消息的地方。输入 /sethome ..."（gateway/run.py ~L18121，仅在新会话首条消息时触发）。
- **触发条件**：该平台无主频道配置——`<PLATFORM>_HOME_CHANNEL` 环境变量 / secret_scope / config.yaml 的 home_channel 全为空（run.py 检查顺序：get_secret → os.getenv → config.get_home_channel）。
- **根治（首选，不是改文案）**：`.env` 加 `TELEGRAM_HOME_CHANNEL=<chat_id>`（私聊用用户 ID，如 <YOUR_TELEGRAM_ID>；群用 `-100...`，如 <PRIVATE_IDENTIFIER>），重启网关后提示永不再弹。副作用：定时任务/跨平台消息默认投递到这个频道——设成用户私聊即可"提示消失且不打扰群"。
- 汉化文案只是治标：改 gateway/run.py 的 notice 字符串后提示仍会出现（见"运行时系统消息汉化"第 2 条）。
- 重启仅使用经授权的允许管理入口，不能通过调度器绕过拒绝。

## Telegram 权限分级：管理员 vs 普通白名单用户
需求："这个 TG 是最高权限，以后添加的白名单只能聊天，不能改设置"。
- 白名单本身：`.env` 加 `TELEGRAM_ALLOWED_USERS=<user_id>`（逗号分隔多 ID；不配 = 默认拒绝所有未知发送者）
- 管理员：`hermes config set telegram.allow_admin_from '<user_id>'`（逗号分隔多 ID）
- 普通用户可用命令：`hermes config set telegram.user_allowed_commands 'help,whoami'`（未设 = 普通用户零斜杠命令；help/whoami 是内置底线，见 slash_access.py `_ALWAYS_ALLOWED_FOR_USERS`）
- ⚠️ 配置值格式：**用纯逗号字符串，不要用 JSON 数组字符串**（`'["id"]'` 会被存成字面量导致匹配失败）
- ⚠️ **群组作用域（group）默认门控关闭**：slash_access.py `policy_from_extra` 里 `enabled = bool(admin_ids)`。只配 `group_user_allowed_commands` 不配 `group_allow_admin_from`，群里被授权的人能跑**所有**命令（含改设置）。要限制群成员，必须同时配 `group_allow_admin_from`（至少一个管理员，如群主 ID）
- 验证：`grep -nA8 "^telegram:" ~/.hermes/config.yaml` 看格式；`hermes send --list telegram` 看已记录频道

## Telegram 菜单指令过度裁切与恢复（command_menu replace 陷阱）
- **现象**：用户反馈在 Telegram 输入 `/` 弹出的命令菜单“删了好多”、大量常用指令（如会话管理、系统排障等）消失不见。
- **根因**：在 `~/.hermes/config.yaml` 的 `platforms.telegram.extra.command_menu` 下配置了 `priority_mode: replace` 且设置了较小的 `max_commands`（例如 10）。
  - `priority_mode: replace` 会**彻底丢弃** Hermes 默认内置的 60+ 条命令，仅上报 `priority` 列表里显式列出的几项；
  - 虽然手动完整敲命令依然可以执行，但客户端的快捷弹窗被完全阉割。
- **修复与推荐实践**：
  1. **完全恢复原汁原味**：从 `config.yaml` 中移除 `platforms.telegram.extra.command_menu` 配置段，重启网关即恢复默认 60 条全量菜单。
  2. **置顶优先但不抹除其余指令（推荐）**：改用 `priority_mode: prepend`，并保持 `max_commands: 60`：
     ```yaml
     platforms:
       telegram:
         extra:
           command_menu:
             max_commands: 60
             priority_mode: prepend
             priority:
               - help
               - new
               - clear
               - stop
               - status
               - model
               - summary
     ```
  3. **群聊防刷屏隔离**：若需求仅仅是精简群聊公开命令，**切勿动全局 command_menu**，而应仅配置 `telegram.group_user_allowed_commands: help,whoami,clear,model,stop,summary` 配合 `telegram.group_allow_admin_from`。私聊即可保留完整生态。

### ⚠️ 血泪教训：不要主动建议用户裁剪私聊菜单（2026-09-04 实录）
本次故障**是 agent 自己造成的**：上一轮排查群菜单时，主动建议"私聊也按极简风格收窄"，用户回了一句"你去"，就写进了 `max_commands: 10` + `priority_mode: replace`，把原厂 60 条砍到 10 条。下一轮用户立刻反馈"菜单栏的指令和之前的区别很大"。
- **`replace` 的破坏力被严重低估**：它丢弃的是 `_TELEGRAM_MENU_PRIORITY` 那 25 条内置优先级 + 全部未列出的注册命令，`/sessions` `/resume` `/context` `/memory` `/retry` `/compress` 这些高频命令全部消失。
- **准则**：群聊菜单精简是安全的（作用域隔离，群友本就不该看到管理命令）；**私聊菜单是用户的主操作面板，除用户明确点名要删，永远不要主动裁**。要突出常用命令就用 `prepend`，它只重排顺序、不删任何条目。
- 用户一句"你去"是对**当次具体动作**的批准，不是对"顺手再优化点别的"的授权。破坏性配置（replace / 缩小上限 / 删条目）即使在批准范围内也要在动手前单独说明后果。

### 关键实现细节（改之前必读）
1. **`clear` 与 `summary` 不在 `COMMAND_REGISTRY` 里**，`telegram_bot_commands()` 不会产出它们：
   - `clear` 是 `/new` 的 alias（`setMyCommands` 只上报 canonical 名）；
   - `summary` 是技能命令（来自 `_collect_gateway_skill_entries`，与内置命令走不同管道）。
   ⇒ 换成 `prepend` 后**必须把这两个显式写进 `priority` 列表**，否则会从菜单消失（`prepend` 只重排、不新增，但 priority 里列出的名字会被排到最前并保住位置）。实测确认两者在最终 60 条内。
2. **群作用域菜单独立于 `command_menu`**：`plugins/platforms/telegram/adapter.py:3648` 对 `BotCommandScopeAllGroupChats` 用的是 `group_commands_list`（由 `group_user_allowed_commands` 派生），改 `command_menu` 不影响群菜单。所以"群里 6 条、私聊 10 条"是两套独立配置，别混着调。
3. **`max_commands` 天花板是 100**（`_TELEGRAM_BOT_API_MAX_COMMANDS`），原厂默认 60。实测 payload 体积：60 条 ≈ 5.3KB / 80 条 ≈ 7.3KB / 100 条 ≈ 9.5KB —— 常说的"4KB 限制"在实践中没触发，60 条是安全且够用的档位。

### 改完必须做的两步验证（不能只看 config.yaml）
```bash
# ① Hermes 侧真实计算（reload config，不要 mock）
cd ~/.hermes/hermes-agent && ./venv/bin/python3 -c "
import sys, importlib; sys.path.insert(0,'.')
import hermes_cli.config as CFG; importlib.reload(CFG)
import hermes_cli.commands as C; importlib.reload(C)
cmds, hidden = C.telegram_menu_commands(C.telegram_menu_max_commands())
names=[n for n,_ in cmds]
print('菜单', len(cmds), '隐藏', hidden)
for k in ('help','new','clear','stop','status','model','summary','whoami','sessions','context','memory'):
    print(f'  {k:10s} 在菜单内={k in names}')"

# ② Telegram 云端实际注册状态（最终事实，四个作用域分别查）
python3 - <<'PY'
import re, json, urllib.request
tok = next(m.group(1).strip('"\'') for m in
           (re.match(r'\s*TELEGRAM_BOT_TOKEN\s*=\s*(.+)', l) for l in open('/home/ubuntu/.hermes/.env')) if m)
def call(method, payload):
    req = urllib.request.Request(f"https://api.telegram.org/bot{tok}/{method}",
            data=json.dumps(payload).encode(), headers={'Content-Type':'application/json'})
    return json.loads(urllib.request.urlopen(req, timeout=20).read().decode())
for scope in ({"type":"default"}, {"type":"all_private_chats"}, {"type":"all_group_chats"}):
    r = call('getMyCommands', {"scope":scope, "language_code":""})
    print(scope['type'], len(r['result']), [c['command'] for c in r['result']])
PY
```
⚠️ 云端菜单是按 BOT_TOKEN 注册的持久状态，**要等 gateway 重启后重新 `setMyCommands` 才会同步**；改完 config 不重启，Telegram 端仍是旧菜单。

## 运行时系统消息汉化（除指令菜单外的英文来源）
用户抱怨"回复里有很多英文"时，除指令菜单（见 references/telegram-command-menu-localization.md）外，还有系统自动生成的英文（2026-08-13 会话实录）：
1. **会话重置信息**（/new 后）：`gateway/run.py` ~L19097-19123——`◆ Model:` / `◆ Provider:` / `◆ Context: ... tokens (detected)`。改 `lines` 列表和 `ctx_source` 三态值（config / default — set model.context_length in config to override / detected）为中文，如 `◆ 模型:` `◆ 服务商:` `◆ 上下文: {n} 个令牌（自动检测）`。
2. **主频道提示**：`gateway/run.py` ~L18121-18127——`📬 No home channel is set for ... Type /sethome ... or ignore to skip.`。改 `notice` 字符串为中文。
3. **随机 tips 提示**（/new 后可能出现）：`hermes_cli/tips.py`——英文条目（如 "8 external memory providers available: ..."）逐条汉化。
改源码后必须重启 gateway 生效（`git diff > ~/.hermes/patches/xxx.patch` 留存，防 git pull 覆盖）。注意 `display.language: zh` 不影响这些硬编码文案，必须改源码。

## 视觉模型不支持图片时的手动识别 fallback
TG 收到图片但 `vision_analyze` 报 `unknown variant 'image_url'` = 当前配置的视觉模型/端点不支持图片输入（如日日新 token.sensenova.cn 只收 text）。换支持视觉的模型直连 OpenAI 兼容接口（2026-08-13 实录：frp3 的 `gemini-3-flash-preview` 可看图）：
```python
# 图片 base64 → data URL 塞进 chat/completions；urllib POST 到 {base}/v1/chat/completions
payload = {"model": "gemini-3-flash-preview",
           "messages": [{"role": "user", "content": [
               {"type": "text", "text": "描述这张图片"},
               {"type": "image_url", "image_url": {"url": f"data:image/jpeg;base64,{b64}"}}]}],
           "max_tokens": 2000}
# headers: {"Content-Type": "application/json", "Authorization": "Bearer $KEY"}
```
TG 收到的图片缓存在 `~/.hermes/cache/images/img_*.jpg`，据此路径读文件。描述/OCR/截图内容识别均可用；也用它探测自定义端点是否支持视觉（报 `unknown variant image_url` 即不支持）。

## 其他要点
- Telegram 连接慢/重试是常态，不是故障；连上后日志有 `✓ telegram connected`
- 模型 429 限流（如腾讯云 TPM 超限）是瞬态错误，重试即恢复，不是配置问题，不要动配置
- **Gemini 400 时序报错与 Fallback 连锁故障**：
  - **现象**：网关日志报 `BadRequestError: Error code: 400 - {'error': {'message': 'Please ensure that function call turn comes immediately after a user turn or after a function response turn.'}}`。
  - **根因**：历史会话中存在异常中断或恢复的悬挂工具调用（`Recovered dangling side-effecting tool call(s)`），导致消息序列中 tool call / tool response 不符合 Gemini API 严格的时序要求。
  - **连锁反应**：网关自动触发 fallback（如日日新），若备用端点额度耗尽（429 `Allocated quota exceeded`），用户端表现为无应答。
  - **解决**：无需重启服务，只需在对应平台（TG / Web UI）发送 `/new` 或 `/reset` 开启新会话即可重置时序恢复正常。
- **长上下文群聊触发 Fallback 导致 TPM 速率超限卡死（429 inference tpm exhausted）**：
  - **现象**：群聊中 Bot 突然停止响应，群友反馈“指令没用/机器死机”，日志报 `API call failed after 3 retries. HTTP 429: inference tpm exhausted | provider=日日新 model=deepseek-v4-flash msgs=... tokens=~45,000`。
  - **根因**：群聊会话此前触发了 Fallback 降级，持久化记录在 `sessions` 表的 `model_config`（`fallback_active: true`）。当群内发起长历史检索（如“查看群里最近50条发言”）时，请求携带 4~5 万 Tokens，直接击穿备用渠道（日日新）的 TPM 上限，3 次重试全部 429 失败。
  - **当前处理边界**：先只读核对会话实际模型、fallback 状态、token 用量和额度错误；使用已授权的官方模型切换/重置接口。不直接 UPDATE 在线 sessions，不把历史模型名称硬写回。若必须修复持久化路由，先备份、停全部持库进程，在独立副本验证后另行实施。
- 日志中 `No env user allowlists configured` 表示需要核对本部署所有者白名单与配对状态；只添加已核实的所有者，不设置 dm_policy: open 或其他全放行。

## python-telegram-bot 长轮询 `Conflict` 虚警（2026-09-07）
运维 Bot 私聊推告警：`🐛 Conflict: terminated by other getUpdates request; make sure that only one bot instance is running`——**先别信"多开"字样**，按此判定：
1. `pgrep -a -f <bot_main.py>` 确认只有**单进程**（systemd 服务只有一个 PID）→ 排除真多开。
2. journalctl 看告警时间点附近是否有 Telegram 网络抖动（`fallback IP ... failed`、`reconnecting`、`Bad Gateway`）→ 有即命中误报模式。
3. 机理：长轮询断线后客户端发起新 `getUpdates`，服务端旧半开连接未超时释放 → 同一 token 重叠轮询 → 单次 409；网络自愈后 Bot 立即恢复正常，**不是故障**。
4. 修复：bot 的全局异常过滤器把单次 `Conflict` 归入 transient（与 NetworkError/TimedOut 同类：静默重试 + 单行 WARN），仅**短时间连续多次冲突**才私聊告警（那才是真多开）。本次 lemon-ops `main.py` 的 `transient` 元组漏了 Conflict，导致每次断线重连都虚警。

## TG 客户端转圈刷新与历史报错锚定分诊（2026-09-08 实录）

当用户在移动端 Telegram 遇到消息收发停滞、聊天列表顶部一直转圈显示「正在刷新...」（Updating...），并且情绪焦虑地把数天前的报错文本（如 `⚠️ No reply: the turn was stopped because session storage could not be written...`）贴出来质问「又爆内存/崩库了」时：

### 1. 心理与排障锚定陷阱
- **锚定效应（Anchoring Bias）**：用户此前因 `state.db` 损坏经历过持久化熔断，一旦 TG 客户端出现任何网络抖动或转圈，会习惯性从剪贴板或记忆中复制旧报错质问。
- **排障铁律**：**先看时间戳**！比对用户日志中的日期（如 `Sep 04` vs 当天 `Sep 08`），避免被历史旧账牵着鼻子走，绝不能在未核查真实状态前认领不存在的“爆内存”。

### 2. 严格的三层只读分诊顺序
1. **第一层：本机硬件与 Hermes 会话库全量核查（只读定心丸）**：
   - 内存与磁盘：`free -m` 确认物理可用内存及 Swap；`df -h` 确认磁盘空间（>5GB 为极充裕）。
   - 数据库健康：内置 sqlite3 跑 `PRAGMA integrity_check`、`PRAGMA foreign_key_check` 以及两套 FTS 的 `integrity-check`（三项必须全部通过）。
   - 文件句柄：`lsof -p <gateway_pid> | grep 'state.db'` 确认无 `(deleted)` 残留句柄。
2. **第二层：Telegram 官方 DC 服务端健康取证**：
   - 检查 `journalctl -u hermes-gateway` 与 `lemon-ops`：是否在早间固定出现 `telegram.error.NetworkError: Bad Gateway`（TG 官方日常抖动）。
   - 检查 Telethon UserBot 日志（`journalctl -u lemon-userbot`）：若出现 `HistoryGetFailedError: Fetching of history failed (caused by GetChannelDifferenceRequest)` 或 `PersistentTimestampOutdatedError`，属于 **Telegram 官方服务器自身会话时间戳异常**，此时所有官方移动客户端均会陷入拉取差量失败的「正在刷新...」死循环。
3. **第三层：客户端代理网络与协议阻断取证**：
   - 查看用户截图右上角是否点亮代理盾牌（🛡️ + ⏻）；
   - 登录代理节点（如香港 NAT VPS）查看代理连接日志（`sing-box` / `dante`）：
     - 若客户端经国内运营商 5G 直连明文高位 SOCKS5 端口，日志中会出现大量 `process connection from ...: invalid argument` 或目标 IP 被畸形解析为 `0.0.0.0:443`、`<YOUR_SERVER_IP>:443`（GFW 对 S5 握手的特征阻断）；
     - 此时必须引导用户切换为 **MTProto Fake-TLS 专线**（伪装苹果域如 `itunes.apple.com`），并完全划掉 Telegram 客户端彻底重启以重置差量同步。

