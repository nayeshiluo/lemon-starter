# Hermes Gateway 历史运维参考（按需读取）

> 原始技能章节原文保存。优先遵循 SKILL.md 中的最新安全与权限边界。

## 数据库损坏复发防护与“心跳守护”原则（2026-09-04 更新）

这类错误先按当前日志、句柄、资源和只读数据库检查分诊。历史本机案例见 `references/session-storage-corruption.md`；原上游多案例引用缺失，不能据此声称上游已确认相同根因。

### 历史复发调查线索（2026-09，根因未确认）

`state.db` 反复损坏、删库重建后数日复发时，**第一嫌疑是自家维护脚本在持续制造损坏**，但**必须先做时间线矛盾检查再下结论**（2026-09-08 教训：上一轮只凭"merge 100% 失败"就断言是元凶，爸爸一句「你确定好是这个问题哈」点破后深挖才发现 merge 失败本身不损坏库、且 8/14 首次事故早于脚本创建）。

已查实的事实链：
- **历史现象记录**：旧维护脚本曾在 2026-09 的特定环境执行 merge 失败；当前生产与技能模板均已移除此行为，不把旧行号和失败率当作当前事实。
- **但副本实验证明：merge 失败后 `PRAGMA integrity_check` 仍 = ok** —— merge 失败本身**不直接损坏库**。上一轮"失败后继续 checkpoint 固化半损坏状态"是推断，未被实验支持，已撤回。
- **时间线矛盾**：8/14 首次损坏（`file is not a database`，整库文件头级损坏）时，`db_maintenance.py`（8/27 创建）与 `daily_cleanup.sh`（8/20 创建）**都不存在** → 脚本不是反复损坏的唯一根因，更深的根因在系统层。

系统层共同根因候选（三起事故 8/14、8/29、9/7 的共同背景，按嫌疑排序）：
1. **SQLite 版本与并发访问是待核实因素**：查询实际解释器与版本，不沿用历史版本号断言兼容故障。外部维护脚本不得写在线 state.db；只读巡检和经审查的一致性备份使用匹配的运行环境。
2. **内存长期极限**：1.9GB 机器，gateway 峰值 1.4G，swap 常驻 547M；SQLite 在内存耗尽时写失败/文件损坏是经典诱因。
3. **系统层不稳定**：9/2 08:30 系统重启过；8/13 gateway 被 SIGTERM；**Telegram 网络每天 UTC 01:10（北京 09:10）固定 Bad Gateway**（8/13、9/1、9/2 连续命中）→ 重连写入风暴。
4. Hermes 官方**自己也执行 `wal_checkpoint(TRUNCATE)`**（`hermes_state_search.py:918`，FTS optimize 后收尾）→ checkpoint 不是外部脚本独有的危险操作，别再当根因报。

完整证据链、复现实验与修正记录见 `references/fts5-merge-corruption-20260907.md`。根治动作（FTS rebuild 实测数据、`.dump` 陷阱、物理 vs 逻辑损坏判定、autoheal 部署）见 `references/fts5-rebuild-heal-20260908.md`。

**排障铁律（对"每次都说解决了"的最直接回应）**：
1. 反复发作 ≠ 删库重建。先做**时间线溯源**：`stat -c %y <脚本>` vs 日志中首次故障时间 vs `grep -c malformed errors.log*` 频率分布。**若首次故障时间早于脚本创建时间 = 时间线矛盾，脚本不是根因制造者**，必须继续查系统层因素（内存压力、系统重启、跨版本 SQLite 并发、网络抖动写入风暴），不许拿单一嫌疑交差。
2. **FTS5 健康必须单独验证**：线上先只读检查文档 ID 覆盖和官方分批回填门控，external-content COUNT 会回源。FTS integrity-check 仅在已验证副本或获准离线环境运行，不能因名字含 check 就默认用读写连接。
3. **假设必须用一致性副本实验验证**：从已验证离线备份或 SQLite backup API 结果制作实验库，不得在线只 cp 主库而遗漏 WAL。副本实验不能代替生产根因证据。
4. 修复后**跨 2 个维护周期**观察错误计数 = 0（本机是 cron 04:00/16:00），再报"搞定"。
5. **FTS5 rebuild 是写操作**：先排除正常官方回填；确需修复时先备份、停全部写者，在独立副本重建并检查，再决定是否替换。不得看到数量告警就自动 rebuild。
6. **区分两类损坏，响应不同**：
   - *b-tree 物理损坏*（`btreeInitPage() returns error code 11` / `PRAGMA integrity_check` 直接失败）：`rebuild` 也会被 SQLite 事务级拒绝（`database disk image is malformed`），**无法自动修复**。正确动作 = 停网关 → 从干净备份（`~/backups/hermes-*/state.db`）冷恢复 → 删除旧 `state.db-wal`/`-shm` → 启动 → 一条真实写入+读出验收。
    - *FTS 逻辑不一致*：external-content 查询可能回源，必须核对实际索引和官方回填门控。是否导致当前 No reply 需当前错误链证据，不能沿用历史案例作肯定或否定归因。
7. **`.dump` 与 `.recover` 恢复法对 FTS5 是陷阱（2026-09-13 实录）**：
   - `.dump` 不导出虚拟表内容，恢复后 FTS 索引全空；
   - `.recover` 会将 FTS5 内部影子表（`messages_fts_data` 等）导出为普通表并保留触发器，但**丢弃虚拟表本体定义**。换回后网关启动直接报 `error creating shadow table messages_fts_data: table 'messages_fts_data' already exists` 并彻底禁用 SQLite 会话持久化！
   - **历史恢复实验**：writable_schema/影子表删除等高风险操作只作副本研究；生产优先采用已验证备份或官方支持流程，不得未经审查改 sqlite_master。
   - **恢复铁律**：恢复首选 `sqlite3 .backup` / Python backup API / 冷拷干净备份，严禁裸跑 `.dump` 或直接将 `.recover` 库替换上线。
8. **FTS5 shadow 表受保护**：直接改 `messages_fts_data` 报 `table messages_fts_data may not be modified`。制造损坏做测试要用 `INSERT INTO messages_fts(rowid, content, ...)`（虚拟表接口）或破坏 dbstat 定位到的页（`SELECT pageno FROM dbstat WHERE name='messages_fts_idx'`）。

### 给本用户的执行规则
1. 用户要求“一步一步/一条一条”时，每回合只做一项只读检查；不得把后续检查、批量修复或后台任务一起执行。
2. 任何恢复/合并/替换前，先做离线快照，并分别验证 `integrity_check`、`quick_check`、`foreign_key_check`、孤立消息、两套 FTS 与触发器；不能只看 `integrity_check`。
3. 不要把 `PRAGMA wal_checkpoint(TRUNCATE)`、自动 FTS rebuild、VACUUM 或自动替换数据库当作“心跳起搏器”：这些写操作在多进程或活跃写入期间可能扩大损坏。守护器应默认只读、发现异常即报警并 fail-closed。
4. 重点监控：WAL/SHM 是否被删除但仍被进程持有、是否存在多个持有者、FTS/canonical 表是否分叉、外键是否出现孤儿；对 `/proc/*/fd` 要直接读取链接，不能仅依赖 `psutil.open_files()`，因为它可能过滤掉 `(deleted)` 句柄。
5. 备份要使用一致性快照并保留多代；恢复必须使用独立输出库，确认逻辑历史、会话血缘、计数器和消息体后才允许替换。

## 恢复备份与数据库热替换排障（句柄残留与 FTS 索引异常）
当从全量备份（如 `lemon-payload.tar.gz`）恢复或直接替换 `state.db` 时：
1. **旧 inode 句柄残留**：在线替换 DB 可能留下 deleted 句柄。先取证、备份并停止全部持库进程，再经授权离线恢复；重启只能走允许的独立管理入口，不绕过安全拒绝。
2. **完整性与双端口验证**：
   - 检查 `state.db` 完整性：`~/.hermes/hermes-agent/venv/bin/python -c "import sqlite3; c=sqlite3.connect('file:/home/ubuntu/.hermes/state.db?mode=ro', uri=True); c.execute('PRAGMA query_only=ON'); print(c.execute('PRAGMA integrity_check;').fetchall())"`。
   - 检查端口监听与 HTTP 状态：`ss -tlnp | grep -E "8648|8642"`，且 `curl http://127.0.0.1:8648/` 与 `curl http://127.0.0.1:8642/health` 均返回 200。

