# 扫描件 PDF → Word（低内存服务器 OCR 工作流）

2026-08-13 会话实录：本服务器（2GB 内存）处理 38 页扫描件 PDF（无文字层，富士施乐打印扫描）转 Word。

## 先问用户要哪种效果（决定技术路线）

扫描件 = 整页都是图片、无文字层。两种需求差别很大，动手前必须问清：

| 需求 | 方案 | 效果 |
|---|---|---|
| "页眉页脚/图表/格式全部一致" | 保真还原：每页渲染高清 PNG 嵌入 Word | 视觉 100% 一致，但文字是图片不可编辑 |
| "能编辑文字，格式尽量接近" | OCR 文字化 | 文字可编辑，页眉页脚/图表/表格线必有偏差 |

不要承诺 OCR 能做到像素级还原。

## 路线对比（按本机实测）

| 工具 | 结果 |
|---|---|
| marker-pdf（PyTorch） | ❌ 2GB 内存直接被 OOM kill（`Killed`，exit -15）。首次还要下载 ~2.5GB 模型。本机不可行 |
| tesseract（chi_sim+eng，psm 6） | ⚠️ 可跑（apt 秒装、轻量），但中文表格/图文混排质量差：表格线错位、文字碎片化（实测第 1 页检测报告识别得一塌糊涂） |
| 视觉模型逐页 OCR（本机可用路线） | ✅ frp3 的 `gemini-3-flash-preview` 逐页识别，质量接近人工阅读 |

## 可用路线：pymupdf 渲染 → 视觉模型 OCR → python-docx

```python
# 依赖（用 hermes venv）：pymupdf + python-docx
# uv pip install pymupdf python-docx  （系统 pip 不存在，必须 venv）

import pymupdf, base64, json, urllib.request

doc = pymupdf.open(pdf_path)
for i in range(doc.page_count):
    pix = doc[i].get_pixmap(matrix=pymupdf.Matrix(200/72, 200/72))  # 200 DPI 平衡质量与体积
    b64 = base64.b64encode(pix.tobytes("png")).decode()
    # POST 到 {frp3_base}/v1/chat/completions，model=gemini-3-flash-preview
    # content = [{"type":"text","text":"完整识别…表格用 Markdown 还原…只输出文字"},
    #            {"type":"image_url","image_url":{"url":f"data:image/png;base64,{b64}"}}]
```

- 每页约 3-5 秒；38 页约 3-4 分钟（单线程）。max_tokens 给 4096 防长页截断。
- 失败重试 3 次（中转站偶发超时），间隔 3 秒。
- 生成 Word：`python-docx`，Markdown 表格行（`|a|b|`）转 `Table Grid` 表格；正文段落；每页后插分页符。

## 坑

1. **后台进程会被网关重启清掉**：`terminal(background=true)` 起的 OCR 进程在网关重启后消失（`process poll` 返回 not_found）。重跑前先 `ps aux | grep python3` 确认上轮是否真的死了，别盲目重启任务。
2. **marker-pdf 装在 2GB 机器上必 OOM**，别浪费时间等模型下载——直接走视觉模型路线。
3. OCR 文本质量依赖视觉模型；批量前先单页试跑，把 prompt 调好再全量（本会话即先测 tesseract 第 1 页、再换 gemini 全量）。
4. 中转站 API key 从 `~/.hermes/.env` 读（`grep '^FRP3_API_KEY=' ~/.hermes/.env | cut -d= -f2`），不要硬编码。