# Hermes Web UI Agent Bridge Socket ENOENT 排障

## 现象
Web UI 面板或日志 (`~/.hermes-web-ui/logs/bridge.log` / `server.log`) 频繁报错：
`Error: connect ENOENT /tmp/hermes-agent-bridge-workers/<hash>.sock`

## 根因
1. **架构**：`hermes-web-ui` (Node.js BFF) 与后台 Python 桥接进程 (`hermes_bridge.py`) 之间采用 Unix Domain Socket 进行 IPC 通信，套接字路径位于 `/tmp/hermes-agent-bridge-workers/<worker-hash>.sock`。
2. **触发场景**：
   - 当 Python bridge broker 发生崩溃、意外退出或被系统清理时，旧 socket 文件丢失。
   - Web UI 的健康检查定时器（ping 探测）在 socket 尚未创建或正在重建时发起连接，抛出 `connect ENOENT` 错误。

## 诊断与排查
1. 检查 Web UI 桥接日志：
   ```bash
   tail -n 50 ~/.hermes-web-ui/logs/bridge.log
   tail -n 50 ~/.hermes-web-ui/logs/server.log
   ```
2. 检查 socket 文件及 bridge 进程是否存在：
   ```bash
   ls -la /tmp/hermes-agent-bridge-workers/
   ps aux | grep hermes_bridge.py
   ```

## 修复方式
若日志中 broker 频繁重启或前端处于断连状态，执行平滑重启 Web UI 重新初始化 IPC 桥接通道：
```bash
hermes-web-ui stop && hermes-web-ui start
```
重启后检查端口与健康状态：
```bash
ss -tlnp | grep 8648
curl -s -o /dev/null -w "%{http_code}" http://127.0.0.1:8648/
```
