# 微信私聊接入与二维码交付

## 能力边界与来源
官方文档：https://hermes-agent.nousresearch.com/docs/user-guide/messaging/weixin 。执行前重查当前文档与 CLI，不能因为旧平台清单没有微信就断言不支持。

iLink 配对的是独立机器人身份，不是接管扫码者的个人账号。普通微信群事件通常不投递，不能把私聊成功宣传成群管理可用。主动推送依赖会话 context token，不能承诺完全替代 Telegram 定时报告。保留现有平台配置。

## 已验证：获取二维码并通过 Telegram 交付
1. 运行 `hermes gateway setup --help` 确认当前入口。
2. 用 terminal 的 `pty=true, background=true, notify_on_complete=true` 启动 `hermes gateway setup`，保留返回的进程句柄。
3. 用 process 的 poll/log 读当前菜单，按名称找到 Weixin / WeChat，再 submit 对应编号；不要硬编码菜单序号。
4. 确认 Start QR login 提示后提交 y，读取 CLI 输出的完整配对 URL。
5. 用 Python qrcode 库将本次 URL 原样编码成 PNG，例如 `qrcode.make(pairing_url).save(output_path)`。这是确定性编码，不可用生成式绘图制作二维码。
6. 通过 `MEDIA:/absolute/path/to/qr.png` 发到用户私聊，请用户扫码并在手机确认。同机可保存图片后尝试微信扫一扫相册识别；若客户端不支持则用另一屏幕展示。
7. 清楚标记“二维码已生成，等待确认”，不是“接入成功”。二维码到期后读取向导最新输出或重新发起配对，别重发旧图片。配对 URL、二维码与 token 不写入技能或公开渠道。

## 扫码后继续向导：已验证的配置与授权流程
扫码成功不代表向导结束。用户说“已连接但没回复”时，先 poll 原 PTY：它可能正在等待 DM 授权选项，而不是网络故障。继续依次选择私聊配对审批、群聊关闭、确认本人的 home channel，最后选择 Done。检查真实提示确认配置已保存；不要用后台进程 exit=0 代替网关上线证据。

配置保存与运行中网关加载是两回事。向导提示需要重启时，告知其他平台短暂重连并遵守当前重启保护；被保护拦截后，不得通过脚本改写、代理或调度器绕过。

用户完成必要重启后，执行 `hermes pairing list`。将待审批请求的微信用户 ID 与扫码时得到的用户 ID 核对，只批准匹配本人这一条：`hermes pairing approve weixin <request-id>`。再 list 验证已批准；无需让用户重复转发已能由 CLI 读取且身份已核对的配对码。批准输出说明下一条消息才按已授权用户处理，因此请用户再发一条测试消息。

上述向导保存、请求出现和 CLI 授权已实测；实际模型回复仍须单独验收。授权成功不能说成双向聊天已验证。

## 停用微信：区分授权、凭据与运行中连接
用户要求断开时，仅操作微信范围，保留 Telegram 和历史会话：
- `hermes pairing revoke weixin <verified-user-id>` 撤销用户授权。
- `hermes config set platforms.weixin.enabled false` 与 `hermes config set platforms.weixin.dm_policy disabled` 禁用入口和私聊。
- 清理实际 Hermes home 下 `.env` 中的微信登录凭据及 `WEIXIN_` 配置（包含 home channel）；不输出密钥，不顺手改其他平台。优先使用当前 CLI 支持的删除方式。
- 用 `hermes pairing list`、config get 和不暴露内容的存在性检查验证撤销、禁用与凭据清理。
- 上述磁盘改动已实测，不等于旧进程的连接已经退出；需要运行时重新加载/重启并核验后，才能报告彻底断开。若尚未完成，明确剩余步骤。

## 配对后验收门槛

- 用户回复扫好后，先查原向导状态；别直接假设成功或再开一套登录流程。
- 确认凭据保存，但不输出 token；只用官方设置流程管理凭据。
- 配置最小访问权限：仅用户本人，群聊关闭。微信用户 ID 必须来自实际微信事件，不能拿 Telegram ID 代替。未知 ID 时使用受控配对，不为方便而永久开放全部用户。
- 如需重启现有网关，先告知 Telegram 短暂重连；遵守当前运行环境的重启安全机制，不绕过保护。
- 让用户在机器人会话发一条唯一测试文本，核实入站事件、实际回复和白名单，再测需要的媒体类型。
- 保证同一 token 只有一个长轮询实例；验收后清理临时二维码。
