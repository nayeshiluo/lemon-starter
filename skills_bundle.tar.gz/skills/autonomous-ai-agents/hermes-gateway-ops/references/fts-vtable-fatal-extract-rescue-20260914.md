# FTS 虚拟表致命坏死与 Python 逐表逐行数据抢救（2026-09-14 实录）

## 1. 现象与多重自愈失效（vtable constructor failed）
当 `state.db` 的 `messages_fts` / `messages_fts_trigram` 底层 B-Tree 发生严重坏页或物理损坏时：
- 错误表现：`sqlite3.DatabaseError: vtable constructor failed: messages_fts` 伴随 `database disk image is malformed`；
- **Strategy 1 (rebuild) 失败**：`INSERT INTO messages_fts(messages_fts) VALUES('rebuild')` 报 disk image is malformed；
- **Strategy 2 (writable_schema 清除影子表) 失败**：即使执行 `PRAGMA writable_schema=ON; DELETE FROM sqlite_master WHERE name LIKE 'messages_fts%';`，SQLite 在预编译任何针对该连接的 SQL（甚至是简单查询）时，都会在解析 `sqlite_master` 虚拟表定义时直接触发 `vtable constructor failed`，导致 DDL/DML 全线拒绝。

## 2. 终极抢救法：Python 过滤影子表并逐行提取（rescue.py 模式）
在不依赖 SQLite 自身虚表解析的前提下，通过外部 Python 脚本连接损坏库与新目标库，只建普通表并逐行搬移数据：

```python
import sqlite3
import os

source_db = '/home/ubuntu/.hermes/state.db'
target_db = '/home/ubuntu/.hermes/state_salvaged.db'

if os.path.exists(target_db):
    os.remove(target_db)

conn_src = sqlite3.connect(source_db)
conn_tgt = sqlite3.connect(target_db)

try:
    tables = conn_src.execute("SELECT name, sql FROM sqlite_master WHERE type='table'").fetchall()
    for table_name, create_sql in tables:
        if not table_name or not create_sql:
            continue
        # 核心：彻底跳过引发 vtable 解析崩溃的 FTS 全文索引表及系统影子表
        if 'fts' in table_name.lower() or table_name.startswith('sqlite_'):
            continue
            
        conn_tgt.execute(create_sql)
        cursor = conn_src.cursor()
        cursor.execute(f"SELECT * FROM {table_name}")
        col_count = len(cursor.description)
        placeholders = ','.join(['?'] * col_count)
        insert_sql = f"INSERT INTO {table_name} VALUES ({placeholders})"
        
        count = 0
        while True:
            try:
                row = cursor.fetchone()
                if row is None:
                    break
                conn_tgt.execute(insert_sql, row)
                count += 1
            except sqlite3.Error as e:
                # 遇到局部坏块时跳过坏页，保住当前已提取的所有正常行
                break
        conn_tgt.commit()
finally:
    conn_src.close()
    conn_tgt.close()
```

数据抢救完成后，交给 Hermes 官方 `SessionDB` 打开一次，即可全自动依据已导入的 `messages` 生成全新的干净 FTS5 虚拟表并完成全量索引构建。

## 3. 替换数据库操作铁律：严禁在线热替换
- **旧 inode 句柄残留**：若 `hermes-gateway.service` 在线，直接 `mv state_salvaged.db state.db` 会使网关进程保持读取旧文件的已删除句柄（`state.db (deleted)`），导致网关持续抛 `malformed`；
- **systemd 强杀重启风暴（“死了两次”）**：
  若在未停服务的情况下使用 `pkill -9` 杀网关，systemd 会在 5 秒内（`RestartSec=5`）自动拉起新网关，导致新进程再次撞上未就绪文件或发生双实例端口冲突，引发连续强杀（SIGKILL）。
- **标准安全替换流程**：
  ```bash
  # 1. 先彻底停止服务
  sudo systemctl stop hermes-gateway hermes-web-ui
  # 2. 清理旧 WAL 与 SHM 缓存并安全替换
  rm -f ~/.hermes/state.db-wal ~/.hermes/state.db-shm
  mv ~/.hermes/state_salvaged.db ~/.hermes/state.db
  # 3. 验证无残留锁与句柄后重新拉起
  sudo systemctl start hermes-gateway hermes-web-ui
  # 4. 验证端口与连接
  journalctl -u hermes-gateway -n 20 --no-pager
  ```

## 4. 跨版本 SQLite 与外键孤儿陷阱（深层诱因）
- **双版本 SQLite 踩踏**：
  Hermes Gateway 运行在 uv 独立 Python 环境（SQLite 3.53.1），而系统环境为 SQLite 3.46.1。
  若定时任务（如 `state_db_autoheal.py`、`backup_hermes.sh`）以 `#!/usr/bin/env python3` 启动，会使用旧版 3.46.1 打开 3.53.1 活跃写入的 WAL 库。底层 WAL 索引与 FTS5 帧格式差异会在并发访问时持续制造 B-Tree 坏页。
  **铁律**：所有维护、巡检、备份脚本头必须硬编码为 `#!/home/ubuntu/.hermes/hermes-agent/venv/bin/python`。
- **外键孤儿阻断冷备门禁**：
  若 turn 中断或 session 创建失败但消息已写入，`messages` 会残留孤儿行导致 `PRAGMA foreign_key_check` 失败。
  `backup_hermes.sh` 门禁失败会直接退出，导致事故发生时失去当日干净冷备。
  **修复**：`SELECT DISTINCT m.session_id, min(m.timestamp), count(m.id) FROM messages m LEFT JOIN sessions s ON m.session_id=s.id WHERE s.id IS NULL GROUP BY m.session_id;` 并自动补齐父级 `sessions` 占位记录。

## 5. 交互盲区教训：用户问「你还好吗」的应答纪律
- **警惕瞬间采样偏差**：当用户在命令行或对话中突然询问「你还好吗」「你活了没」「在吗」时，**绝不要只看当前一秒**的系统空闲（`uptime` 负载低、当前进程活）。
- **强制三步回溯**：
  1. 查 `journalctl -u hermes-gateway -n 30` 确认过去 30 分钟内是否有异常退出、`Restart counter` 增加或 SIGKILL；
  2. 查 `errors.log` 是否发生过持久化熔断或模型连续失败；
  3. 若过去半小时内发生过崩溃、被杀、抢救或重连，必须**首先主动坦承最近的异常事件与当前恢复状态**，严禁盲目回复“一切平稳，爸爸是不是想我了”。
