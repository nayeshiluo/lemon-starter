# Telegram chat_id 发现与配对排障实录

场景：用户（爸爸）要求"在 TG 里回复我试试"，但 bot 已在网关日志显示 `✓ telegram connected`，却没有任何可投递目标。本文件记录诊断顺序、关键证据与结论。

## 关键证据（按排查顺序）

1. `hermes send --help` → Hermes 提供 `hermes send [-t TARGET] [-f PATH] [message]`：
   - 目标格式：`platform`（home channel）、`platform:chat_id`、`platform:chat_id:thread_id`、`platform:#channel-name`
   - bot-token 平台（Telegram/Discord/Slack/Signal）**无需 gateway 在跑**，直接用 ~/.hermes/.env + config.yaml 凭据调 API
   - `--list` 列出可用目标；退出码 0=成功 1=后端错误 2=用法错误

2. `hermes send --list telegram` → `telegram: (no channels discovered yet)` — home channel 未配置、无历史会话。

3. `~/.hermes/config.yaml` 的 telegram 段只有 `require_mention: true`，无 chat_id/白名单配置。

4. `~/.hermes/.env` 只有 `TELEGRAM_BOT_TOKEN=<已配置>`，无 `TELEGRAM_ALLOWED_USERS`。

5. gateway.log 关键行：
   ```
   WARNING gateway.run: No env user allowlists configured. Messaging platforms default
   to pairing/allowlist policies and will deny unknown senders unless you configure
   platform allowlists (e.g., TELEGRAM_ALLOWED_USERS=your_id) or explicitly opt in with
   GATEWAY_ALLOW_ALL_USERS=true plus dm_policy/group_policy: open on the platform.
   ```
   → 默认拒绝策略在生效，未知发送者（包括用户本人，全新环境无配对）的消息会被静默丢弃：不留日志、不建会话。

6. state.db（SQLite，本机无 sqlite3 CLI，用 python3 内置模块）：
   - `sessions` 表含 `source, user_id, chat_id, chat_type, thread_id, display_name` 列
   - 查 `SELECT source, chat_id, title FROM sessions WHERE chat_id IS NOT NULL` 返回空 → 确认从未建立过任何平台会话
   - `gateway_routing` 表（scope/session_key/entry_json）同样为空

7. `~/.hermes/pairing/` 目录存在但为空 → 无已配对用户。

8. gateway.log 无任何 Telegram update/message 记录（排除 `set_my_commands`/连接噪音后）→ 用户从未成功发过消息。

## 结论
"bot 已连接" 只证明 token 有效、polling 在跑，与"用户能否对话"完全无关。判断某平台是否可用，必须看：会话库有无该平台记录 / `hermes send --list` 有无频道 / pairing 目录有无配对。

## 启用路径（写入操作，需用户批准）
1. 用户先在 TG 给机器人发任意消息 → chat_id 进入 gateway.log/state.db
2. `.env` 追加 `TELEGRAM_ALLOWED_USERS=<user_id>`（或 `GATEWAY_ALLOW_ALL_USERS=true`）
3. `hermes config set platforms.telegram.dm_policy open`（群聊另有 group_policy）
4. 重启 gateway
5. 验证主动推送：`hermes send --to telegram:<chat_id> "测试"`

## 注意
- 不要用 Bot API 的 getUpdates 拿 chat_id：会与正在运行的 gateway 长轮询冲突（409）。
- web-ui 的 401 修复与本次 Telegram 排障属于同一网关运维域，但链路不同：前者是 api_server 密钥同步问题（见 hermes-gateway-api-server 技能）。
