# 面板 URL 恢复：服务在跑但用户打不开

## 场景
- `ss -tlnp | grep 8648` → LISTEN ✓
- `curl -s -o /dev/null -w "%{http_code}" http://127.0.0.1:8648/health` → 200 ✓
- 但用户说「面板打不开」

## 最常见的根因
用户手里的面板地址不对（IP 变了 / token 过期了 / 书签是旧地址）。

## 快速恢复步骤
1. 获取当前公网 IP：
   `curl -s http://checkip.amazonaws.com`

2. 从面板日志中提取 token：
   `grep -i "token:" ~/.hermes-web-ui/server.log | head -1 | grep -oP 'token: \K[a-f0-9]+'`

3. 拼出完整面板地址：
   `http://<公网IP>:8648/#/?token=<token>`

4. 发给用户，让用户直接复制到浏览器打开。

## 关于弹性 IP 的注意点
- 这台实例有弹性 IP（<YOUR_SERVER_IP>，<ALLOCATION_ID>），IP 不会因重启改变
- **不要通过 metadata 的 `/association/` 端点判断是否有 EIP**——该路径在某些配置下返回 404 但 EIP 实际上已绑定
- 本机无 IAM 角色 / AWS CLI 凭证，无法用 `aws ec2 describe-addresses` 查询
- 最稳妥的方式：问用户，或直接看当前公网 IP 是否稳定

## 如果公网 curl 不通
- 面板绑定了 `0.0.0.0:8648`（全网卡），公网应可访问
- 如果公网 curl 不通，检查 AWS 安全组是否放行了 8648 入站规则