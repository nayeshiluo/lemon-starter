# 面板 URL 恢复：服务在跑但用户打不开

分两类，先判类型再动手，不要一上来就重启服务。

| 症状 | 类型 | 走哪节 |
|---|---|---|
| 浏览器「找不到服务器」/ 超时 / 转圈 | 地址错或端口不通 | §A |
| 浏览器「无法提供安全连接」「发送的响应无效」`ERR_SSL_PROTOCOL_ERROR` | TLS 被中断 | §B |

---

## §A 地址不对（IP 变了 / token 过期 / 书签是旧地址）

1. 获取当前公网 IP：`curl -s --max-time 8 http://checkip.amazonaws.com`
2. 从面板日志提取 token：
   `grep -i "token:" ~/.hermes-web-ui/server.log | head -1 | grep -oP 'token: \K[a-f0-9]+'`
3. 拼地址：`http://<公网IP>:8648/#/?token=<token>`
4. 直接发给用户复制打开。

服务端自检：`ss -tlnp | grep 8648` 应为 LISTEN，`curl -s -o /dev/null -w "%{http_code}" http://127.0.0.1:8648/health` 应为 200。

**注意**：本机已迁离 AWS（旧 EIP `<YOUR_SERVER_IP>` 仅作历史记录，不要当现状）。公网 curl 不通时查云安全组入站规则，别通过 metadata 的 `/association/` 端点判断 EIP。

---

## §B TLS 握手被中断（`ERR_SSL_PROTOCOL_ERROR`）

**核心判断：服务端 TLS 正常 ≠ 用户能连上。** 先从服务器侧证明证书和协议栈没问题，把问题锁定在链路上。

### B1 服务端取证（只读，全在源站跑）

```bash
# 证书链 + 协议版本
echo | openssl s_client -connect 127.0.0.1:443 -servername <域名> 2>/dev/null \
  | openssl x509 -noout -subject -issuer -dates
echo | openssl s_client -connect 127.0.0.1:443 -servername <域名> 2>&1 \
  | grep -E 'Protocol|Cipher|Verify return code'

# 多 SNI 对照（同一 IP 上不同域名）
for d in a.example.com b.example.com; do
  printf '%-22s ' "$d"
  echo | openssl s_client -connect 127.0.0.1:443 -servername "$d" 2>&1 \
    | grep -oE 'Verify return code: [0-9]+.*' | head -1
done

# 海外多节点探测（证明源站对公网可达）
curl -s "https://check-host.net/check-http?host=https://<域名>&node=at1.node.check-host.net&node=br1.node.check-host.net" \
  -H 'Accept: application/json'
```

`Verify return code: 0 (ok)` + TLS 1.2/1.3 都能握手 + 海外节点全通 = **源站无问题**，问题在用户到源站这段链路。

### B2 区分「IP 段被墙」还是「单个域名被针对」

让用户用手机访问**同一 IP 上的另一个域名**：

- 另一个域名能开 → 只有该 SNI 被针对（域名级阻断），换域名或套 CDN 即可
- 另一个域名也报同样 TLS 错误 → **IP 段被墙**，必须走 CDN

2026-11-04 实录：`<YOUR_PRIVATE_DOMAIN>` 与 `<YOUR_PRIVATE_DOMAIN>` 同 IP（`<YOUR_SERVER_IP>`，Leaseweb 新加坡 AS59253）双域名同时 `ERR_SSL_PROTOCOL_ERROR`，海外 4 节点全通 → 判定 IP 段被 GFW 阻断。

### B3 处置：切 Cloudflare 橙云

先查 zone 里哪些记录还是灰云（`proxied=false` 的直接暴露在被墙 IP 上）：

```bash
T=$(cat ~/.config/lemon-cloudflare/ops.token); Z=<zone_id>
curl -s -H "Authorization: Bearer $T" \
  "https://api.cloudflare.com/client/v4/zones/$Z/dns_records?per_page=100" \
  | python3 -c 'import sys,json
d=json.load(sys.stdin)
for r in d["result"]:
    if r["type"] in ("A","AAAA","CNAME"):
        print(r["type"], r["name"], r["content"], "proxied=", r["proxied"], r["id"])'
```

逐条 PATCH `{"proxied": true}`：

```bash
curl -s -X PATCH "https://api.cloudflare.com/client/v4/zones/$Z/dns_records/<record_id>" \
  -H "Authorization: Bearer $T" -H 'Content-Type: application/json' \
  --data '{"proxied":true}'
```

前提：zone 的 SSL 模式为 `full` 或 `full (strict)`，且源站 443 有有效证书。查模式：
`.../zones/$Z/settings/ssl`。模式为 `flexible` 时橙云会回源到 80 明文，先改成 `full`。

**验证橙云真的生效**（三个视角都要看，缺一不可）：

```bash
for s in 1.1.1.1 8.8.8.8 <YOUR_SERVER_IP>; do
  printf '%-12s ' "$s"; dig +short @$s <域名> A | tr '\n' ' '; echo
done
curl -s -o /dev/null -w 'code=%{http_code} ip=%{remote_ip} tls=%{time_appconnect}s\n' https://<域名>/
```

期望：解析返回 `104.x` / `172.67.x`（CF 边缘），HTTP 200，证书变成 Cloudflare 边缘证书（Google Trust Services `WE1` 之类）。

**本机 curl 自己的域名可能仍解析到源站 IP**——那是本地 resolver 缓存，不代表橙云没生效。用公共 DNS 视角判断，或用 `--resolve 域名:443:<CF_IP>` 强制验证。

### B4 ⚠️ 必查：有没有 DDNS 在把橙云改回灰云

**这是本次故障的真正闭环点，漏了会在 2 分钟后复发。**

实录时间线：
- `08:53:50` 手动把 `aws` 设为 `proxied=true`
- `08:55:38` 记录被改回 `proxied=false`，用户重新打不开
- 查 `systemctl list-timers | grep -i dns` → 发现 `lemon-ddns.timer` 每 2 分钟跑一次

排查：

```bash
systemctl list-timers --all --no-pager | grep -iE 'dns|cf|cloud'
systemctl cat <ddns-unit>.service          # 看 ExecStart 指向哪个脚本
sudo journalctl -u <ddns-unit>.service --since '-30 min' --no-pager -o short-iso
```

`lemon-ddns` 用 **PUT 全量覆盖**记录，config 里 `proxied: false` 会无条件把橙云抹掉。判据是 API 返回的 `modified_on` 时间戳与 ddns 定时器执行时刻对齐。

修法（本机 `/home/ubuntu/lemon-ddns/`）：

```bash
cd /home/ubuntu/lemon-ddns && cp -a config.json config.json.bak-$(date +%Y%m%d)
python3 -c 'import json
p="config.json"; c=json.load(open(p)); c["proxied"]=True
json.dump(c, open(p,"w"), indent=2, ensure_ascii=False)'
sudo systemctl start lemon-ddns.service   # 手动触发一次
```

**闭环验证必须等 ddns 跑过至少一轮**（2 分钟）后再查：

```bash
sleep 130
tail -3 /home/ubuntu/lemon-ddns/ddns.log       # 应出现 "no change needed"
# 再查 API 的 proxied 和 modified_on：modified_on 没刷新 = 没被回滚
curl -s -o /dev/null -w 'code=%{http_code}\n' https://<域名>/
```

日志出现 `IP is up-to-date (...), no change needed` 且 `modified_on` 保持不动，才算真闭环。

---

## 通病清单

1. **别把「服务在跑」当成「用户能访问」**——进程、端口、证书、链路是四层，逐层验。
2. **别只验一个域名**——同 IP 多域名对照是区分 IP 封锁和域名针对的唯一便宜办法。
3. **改完 DNS 必须查有没有自动化在回滚**——DDNS / 同步脚本 / 定时 PUT 是隐形杀手。
4. **验证要等定时器周期过去**——改完立刻看是「暂时正常」，跑过一轮才是「稳定正常」。
5. 修完把「哪些域名还挂在灰云」「哪个服务本身没起」一并列给用户，别只报修好的那个。
