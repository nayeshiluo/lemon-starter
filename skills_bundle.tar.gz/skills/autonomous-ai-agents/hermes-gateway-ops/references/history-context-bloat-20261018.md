# Hermes Gateway 历史运维参考（按需读取）

> 原始技能章节原文保存。优先遵循 SKILL.md 中的最新安全与权限边界。

## 防上下文爆炸：配置 + 根因链（2026-08-14 落地）
症状：群里一直显示 bot「输入中」超长时间（实录单 turn 1514s/25min、18 次 API 调用），群成员吐槽"上下文爆了吧"。
根因链：模型 API 连续失败（日日新 token.sensenova.cn `Connection error`/`Request timed out`，Share `Broken pipe`）→ 3 次重试 + fallback 再重试 → 单 turn 几十个 tool call 空转（还叠加查错数据库 `state_recovered.db` 死循环）→ Telegram 持续「输入中」+ session token 膨胀 → 上下文爆掉。
防爆配置（已生效）：
- `agent.max_turns`: 150 → **30**（限制单轮工具调用次数，防死循环烧上下文）
- `session_reset.mode`: none → **token**，`token_limit`: **24000**（会话超 24K token 自动重置）
- ⚠️ agent 的 patch / write_file 直接改 config.yaml 会被拒（安全限制"Refusing to write to Hermes config file"），用 terminal `sed -i` 或 python3 精准替换可过（smart approval 会标记但自动放行），改完必须重启网关生效。
排查当前会话大小：
```bash
sqlite3 ~/.hermes/state.db "SELECT s.id, s.title, s.source, COUNT(m.id) msgs, ROUND(SUM(LENGTH(m.content))/1024.0,1) kb FROM sessions s LEFT JOIN messages m ON s.id=m.session_id GROUP BY s.id ORDER BY kb DESC;"
```
记忆工具超限（如 memory would be at 2305/2200 chars）也会让行为异常——顺手 `memory` 批量合并/删除（replace 用 `content` 参数不是 new_text）。详见 `references/context-bloat-prevention.md`。

#### 0. 进程文件句柄检查（先于 integrity_check）
当 gateway 数据库文件被替换（日志轮转、手动恢复、迁移覆盖等）而进程未重启时，进程可能持有已删除文件的旧 inode，导致 SQLite 通过旧句柄读到不一致的 WAL/SHM 状态，报 `database disk image is malformed`，但磁盘上的新 DB 文件本身是健康的。

**诊断：**
```bash
lsof -p <gateway_pid> | grep 'state.db'
```
若输出中出现 `(deleted)` 标记（如 `state.db (deleted)`、`state.db-wal (deleted)`），说明进程持有的文件句柄指向已被替换的旧 inode。磁盘上的 `state.db` 文件是新的，但进程的 SQLite 连接仍通过旧句柄读取已删除文件。

**经典表现（2026-08-14 实录）：**
- Gateway PID 29145 有 3 个旧句柄（05:58 打开，已删除）和 3 个新句柄（06:18 打开，未删除）
- SQLite 连接使用旧句柄，导致 WAL/SHM 状态与主 DB 不一致
- `PRAGMA integrity_check` 返回 `ok`（因为检查的是磁盘上健康的新文件）
- 网关日志每隔几秒一条 `database disk image is malformed`，连续失败数百次
- 进程重启后（PID 51601），所有句柄指向新 inode，无 `(deleted)`，问题消失

**修复：** 有授权且允许的独立入口时按正常服务流程重启，并做真实功能验收；当前入口被拒绝就停止该操作，不用 systemd-run 包装或 gdb 注入改道。

按以下只读顺序确认：
1. 先运行 `hermes doctor`，但不要把 doctor 的 `integrity_check: ok` 当作 Hermes 全部索引健康；它可能只验证 SQLite 页面结构。
2. 检查 `~/.hermes/logs/errors.log`、`gateway.log`、`agent.log`，重点搜索 `database disk image is malformed`、`FTS-corruption`、`FTS indexes remain corrupt`、`single-entry routing save failed`、`Persisted transcript lagged live cached history`。
3. 使用 Python 内置 sqlite3（不要依赖 sqlite3 CLI；不要假设有裸 `python`）以只读方式检查：`PRAGMA integrity_check`、表清单、`messages`/`sessions` 数量，以及 `gateway_routing` 是否可读。Hermes 当前表名是 `gateway_routing`，不是 `routing`。
4. 若日志出现 FTS 损坏，结论应明确写成“canonical message rows 可能仍在，但 FTS/路由写入不可靠”；不要把它描述成单纯 database locked，也不要继续用 TG 反复压测。
5. 修复前先完全停止唯一的 gateway，并备份 `state.db`、`state.db-wal`、`state.db-shm` 及 Hermes 自动生成的 malformed backup；然后用 Hermes/SQLite 支持的 FTS 重建或从已验证备份恢复。修复后重新运行 integrity/表查询，再启动 gateway 并做一条短 TG 验证。未实际完成修复前，不要声称数据库已经恢复。
6. 日志中 `No LLM provider configured` 属于 provider 配置问题，应与 session storage/FTS 损坏分开报告；同样，`hermes doctor` 的 API key 警告也不要误报为 Telegram 数据库根因。

详细的只读诊断字段、日志证据模式和安全修复边界见 `references/session-storage-corruption.md`。

- 面板与网关是**两个独立进程**：网关有 systemd 守护，面板没有——机器重启/迁移后网关会自动复活（8642 通），但面板 8648 可能没起来。用户报"面板地址换了/打不开"时，先查 8648 端口再启动面板，别只查网关。
- **防火墙与网络排查**：面板打不开时，除查进程外，必须先检查系统防火墙（`sudo ufw status verbose`）。若 8648 被限制为仅 127.0.0.1，公网会被 DROP；需执行 `sudo ufw allow 8648/tcp` 放行。
- 面板是 npm 全局 daemon：`/usr/bin/hermes-web-ui`（→ /usr/lib/node_modules/hermes-web-ui），数据目录 `~/.hermes-web-ui/`（server.log、server.pid）。
- **版本升级（v0.4.0 → v0.6.x+）**：
  - 升级命令：`sudo npm install -g --allow-scripts=agent-browser,node-pty,vue-demi hermes-web-ui@latest`
  - 重启面板：`hermes-web-ui stop && hermes-web-ui start`
  - **登录认证机制变迁**：
    - 旧版（v0.4.0 及以前）：通过一次性 Token 登录，URL 为 `http://<IP>:8648/#/?token=<hex>`。
    - 新版（v0.6.x+）：采用多用户账号密码认证体系。初始未创建用户时，默认初始管理员为 `admin` / `123456`（首次通过 `/api/auth/login` 登录即自动完成超管初始化注册，登录后可在设置中修改）。
- 启动/停止：`hermes-web-ui start` / `hermes-web-ui stop`。
- **Web UI systemd 守护服务（防崩溃/开机自启）**：
  - 面板默认手动通过 CLI 启动，未配置守护时容易因网络/Socket 异常退出后持续失联（报 400/Connection Refused）。
  - 推荐配置 `/etc/systemd/system/hermes-web-ui.service` 进行持久化守护：
    ```ini
    [Unit]
    Description=Hermes Web UI Service
    After=network-online.target hermes-gateway.service
    Wants=network-online.target

    [Service]
    Type=simple
    User=ubuntu
    Group=ubuntu
    WorkingDirectory=/usr/local/lib/node_modules/hermes-web-ui
    Environment="HOME=/home/ubuntu"
    Environment="USER=ubuntu"
    Environment="NODE_ENV=production"
    Environment="PORT=8648"
    Environment="PATH=/usr/local/bin:/usr/bin:/bin:/home/ubuntu/.local/bin:/home/ubuntu/.hermes/hermes-agent/venv/bin"
    ExecStart=/usr/local/bin/node dist/server/index.js
    Restart=always
    RestartSec=5
    KillMode=mixed
    KillSignal=SIGTERM
    TimeoutStopSec=30
    StandardOutput=journal
    StandardError=journal

    [Install]
    WantedBy=multi-user.target
    ```
  - 启用：`sudo systemctl daemon-reload && sudo systemctl enable --now hermes-web-ui.service`。
- **Web UI 内存占用常态认知**：
  - 机器总内存 2GB 时，未开面板基线约 30%~32%（Gateway ~240MB + CLIProxyAPI ~50MB + 系统服务 ~320MB）。
  - 开启面板后常驻套件包括：Node.js Web 服务端 (~200MB) + Python Agent Bridge Master/Worker 进程 (~136MB)，总共新增占用约 336MB，内存显示升至 ~50% 属于完全符合架构预期的健康状态。
- **NAT VPS / 无公网端口场景下的临时公网面板（Cloudflare Tunnel）**：
  - 当 VPS 无独立公网 IP 或处于 NAT 端口转发环境中、尚未映射 8648 端口时，可用 `cloudflared` 快速建立临时 HTTPS 隧道：
    ```bash
    cloudflared tunnel --url http://127.0.0.1:8648 > /tmp/tunnel.log 2>&1 &
    # 获取生成的临时 trycloudflare.com 链接
    grep -o 'https://.*\.trycloudflare\.com' /tmp/tunnel.log | head -1
    ```
- 完整诊断+修复序列：
  1. `ss -tlnp | grep 8648` — 无输出 = 面板没在跑
  2. `sudo ufw status verbose` — 确认 8648 是否对公网放行
  3. `hermes-web-ui start` — 启动面板
  4. `curl -s -o /dev/null -w "%{http_code}" http://127.0.0.1:8648/health` → 200
  5. 公网验证：`curl -s -o /dev/null -w "%{http_code}" http://<公网IP>:8648/` → 200
- 面板地址 = `http://<当前公网IP>:8648/#/?token=...`。EC2 无弹性 IP 时公网 IP 一变（迁移/重启），地址就要重发（本机 <YOUR_SERVER_IP> → <YOUR_SERVER_IP> 即一例）；公网打不开时先查安全组及主机防火墙（UFW/iptables）是否放行 8648 入站（如 sudo ufw status 是否误将 8648 限制为仅 127.0.0.1）。
- **发面板地址必须带 `#/?token=<hex>` 页面登录 token**：只发裸 `http://IP:8648` 会卡在登录页，用户以为"进不去"（2026-08-14 实录：发了无 token 地址，用户反馈打不开）。token 在 `hermes-web-ui start` 启动输出或服务端日志（`~/.hermes-web-ui/server.log`）。页面 token 与 gateway API key 是两层独立认证，别混。
- **服务侧全通但用户打不开的标准排查**（2026-08-14，结论是服务器侧正常、问题在用户/地址侧）：
  1. `ss -tlnp | grep 8648` → LISTEN 且绑 `0.0.0.0`
  2. 本机 `curl -s -o /dev/null -w "%{http_code}" http://127.0.0.1:8648/` → 200
  3. 服务器自测公网：`curl -s -o /dev/null -w "%{http_code}" --connect-timeout 5 http://<公网IP>:8648/` → 200（安全组已放行该路径）
  4. `/api/health`、`/v1/models` 无 Bearer key 返回 **401 是符合预期的**（受保护端点），不代表面板故障，不要据此说是 key 失配
  5. 以上全通后分诊用户侧：地址是否带 token、http 还是 https、公网 IP 是否已变（无弹性 IP 重启就换）、浏览器缓存、用户网络访问 AWS 亚太（ap-southeast-1）是否被墙/限速。

