# Telegram DC 级故障排查与客户端「正在刷新」差量死锁诊断

## 适用场景
- 用户在 Telegram 客户端看到顶部一直显示「正在刷新...」（Updating... / Connecting...），发不出消息或转圈。
- 用户误将客户端无响应与 Hermes 网关崩溃（如历史「爆内存」「session storage could not be written」）混淆，甚至贴出几日前失效日志。
- 怀疑 Telegram 官方特定数据中心（如亚太 DC5）故障、差量拉取服务崩溃，或代理链路受 GFW 干扰。

## 快速分诊与避坑准则

### 1. 甄别历史日志假象（时间戳核验）
- **现象**：用户常把几天前触发过的数据防丢截屏/日志（如 `Session DB creation failed: database disk image is malformed`）顺手贴出，误以为是当前故障。
- **动作**：不要只看日志内容，先看时间戳！
  ```bash
  date -u
  journalctl -u hermes-gateway --since "1 hour ago" --no-pager | tail -n 30
  ```
  如果当前日志全绿、资源（`free -m`, `df -h`）充足且 `PRAGMA integrity_check` 为 ok，立刻排除网关/SQLite 问题，转向外部通信层排查。

### 2. Telegram DC 级增量同步死锁诊断
Telegram 采用多数据中心架构（DC1/DC3 迈阿密、DC2/DC4 欧洲、DC5 新加坡/亚太）。
- **核心症状**：
  - 客户端打开后顶部死循环停留「正在刷新...」；
  - 欧美地区用户正常，亚太地区（+86、新马港澳台等）大面积瘫痪；
  - 本地常驻客户端（如 Telethon / UserBot）日志抛出协议级错误：
    ```text
    HistoryGetFailedError: Fetching of history failed (caused by GetChannelDifferenceRequest)
    PersistentTimestampOutdatedError: Persistent timestamp outdated
    ```
  - 网关轮询出现：
    ```text
    telegram.error.NetworkError: Bad Gateway (502)
    ```
- **技术根因**：
  客户端每次连接必须调用 `GetChannelDifferenceRequest` 拉取消息差量。当 DC5 数据库时间戳服务紊乱或崩溃时，服务端持续抛出内部错误，客户端无法完成初始握手，永远卡在差量同步（Updating...）死循环中。
- **核验手段**：
  - 检查客户端连接的目标 IP：`91.108.56.0/22`（如 `91.108.56.104:443`）即为 DC5。
  - 检查实时突发新闻 / Downdetector（新加坡、东南亚地区报障曲线短时间飙升至数千例）。

### 3. 区分 Telegram 官方故障 vs SOCKS5 明文代理被 GFW 干扰
- **明文 S5 阻断特征**：
  国内 5G / 宽带直连境外 S5 端口（未加密）时，GFW 会进行协议特征识别并注入 RST 或篡改握手包。小鸡上的 sing-box / sockd 日志会出现：
  - `inbound/socks: process connection ...: invalid argument`
  - `open connection to 0.0.0.0:443: connection refused`
  - `open connection to 3.0.0.0:443: dial timeout`（S5 协议的 0x03 域名类型标记被墙篡改视作 IPv4 头字节）
- **对策**：
  - 切忌用裸连 SOCKS5，必须换用带 Fake-TLS 伪装的 MTProto 专线（如 mtg 监听 80，伪装 `itunes.apple.com`）；
  - 一键链接格式：`https://t.me/proxy?server=<IP>&port=<PORT>&secret=<HEX>`。

### 4. 恢复指导
- **服务端**：等待 Telegram 官方工程师修复并回滚 DC5 增量同步节点。
- **客户端操作**：
  1. 彻底上滑关闭（Force Close）Telegram 客户端后台，避免客户端继续挂在卡死的握手会话中；
  2. 切换到 Fake-TLS MTProto 代理；
  3. 重新打开客户端，发起干净的全新连接。
