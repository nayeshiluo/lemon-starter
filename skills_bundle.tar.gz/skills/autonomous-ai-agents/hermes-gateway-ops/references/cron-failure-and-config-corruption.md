# Cron 任务报错 × config.yaml 瞬时损坏分诊（2026-10-15 实录）

用户看到的告警原文（运维 Bot 推送）：

```
⚠️ Cron 'HostBrr Black Friday deal monitor' failed:
Cron job '...' has no model configured (job.model=None, HERMES_MODEL='',
config.yaml model.default missing or empty). Set a per-job model via
`cronjob action=update job_id=... model=<name>` or set a default with `hermes model <name>`.
```

**别照着告警字面去给任务钉模型。** 这句话只说明「那一瞬间解析不出模型」，真实原因可能是
config.yaml 在同一个分钟里被写坏 + 网关正在重启。

## 本次时间线（全部可从日志坐实，UTC）

| 时刻 | 事实 | 证据来源 |
|---|---|---|
| 09:00:41 | `while parsing a block mapping ... expected <block end>, but found ','`（config.yaml 第 67/73 行），同时落档 `config.yaml.corrupt.20261015-090041.bak` | `logs/errors.log` |
| 09:00:47 | 该 cron 任务触发 → 读不到 `model.default` → 报「no model configured」 | `cron/executions.db` |
| 09:01:03 | `Shutdown context: signal=SIGTERM`、`gateway.exit_nonzero`，随后 `gateway.start` 拉起新 PID | `logs/errors.log`、`logs/gateway-exit-diag.log` |
| 09:00:53 / 09:07 / 09:16 | 故障分钟后其他 no_agent 任务全部 `ok` | `cron/executions.db` |
| 故障前 4 天 | 同一任务每天 `completed` | `hermes cron runs <job_id>` |

结论：**瞬时故障**（配置只坏了几十秒，恰好被这个任务踩中），不是任务配置问题，也不是模型路由问题。

## 只读取证路径（按顺序）

1. `~/.hermes/logs/errors.log` —— 搜 YAML 解析错（`parsing a block mapping` / `expected <block end>`）、
   `Shutdown context: signal=SIGTERM`、`Gateway drain timed out after`。
2. `~/.hermes/logs/gateway-exit-diag.log` —— JSON 行（`ts` / `pid` / `tag`）；
   `gateway.exit_nonzero` 与其后紧跟的 `gateway.start` 就是重启时刻与新 PID。
3. `~/.hermes/gateway-starts.log` —— 纯 epoch 秒列表，换算即得重启历史：
   `python3 -c "import datetime;print(datetime.datetime.fromtimestamp(<YOUR_USER_IDENTIFIER>,datetime.UTC))"`
4. `hermes cron runs <job_id>` —— 每次执行的 status / error（durable execution 记录）。
5. `cron/executions.db`（sqlite）—— 表 `executions`，列
   `id, job_id, source, process_id, pid, process_started_at, status, claimed_at, started_at, finished_at, error`；
   按 `rowid DESC LIMIT 6` 取最近几次，能拿到完整 error 文本与毫秒级时间，用来和日志时间线对齐。
6. no_agent 脚本类任务的失败详情在 `cron/output/<job_id>/<时间戳>.md`（stdout + stderr + 脚本自带 error tag，
   本次据此定位到备份任务断在 `backup_upload_failed`：加密分片/清单上传失败，而本地健康门禁与四个库检查均通过）。
7. 现状核对：
   - `python3 -c "import yaml;print(yaml.safe_load(open('/home/ubuntu/.hermes/config.yaml'))['model'])"`
     —— 解析成功且 `default` 非空即已恢复；
   - `systemctl is-active hermes-gateway`；
   - `pgrep -af "gateway run"` 拿当前 PID，与 diag 日志里的新 PID 对上。

## 命令与工具边界

- `hermes cron` 子命令只有 `list / create(add) / edit / pause / resume / run / remove(rm,delete) / status /
  runs(history) / notepad / tick` —— **没有 `update`**。
- **给任务钉模型只能用 CLI**：`hermes cron edit <job_id> --model <name> --provider <provider>`
  （`--model ""` 清除钉住、回落 `cron.model` / `model.default`）。
  agent 侧的 `cronjob` 工具**不能**设 model —— 告警里那句 `cronjob action=update ... model=...` 在本机不成立。
- ⚠️ **钉模型 = 改模型路由，必须用户明确点头**。诊断出「配置瞬时读不到」时，正确动作是讲清根因 +
  提议钉模型，不要顺手改。
- `config.yaml.corrupt.<ts>.bak` 是自动留档，**不代表内容是垃圾**（本次 10764 字节、YAML 完整可解析），
  排查时可读它对比改坏前的字段。

## 分诊口诀

- 同一分钟**多个 LLM 任务全挂、no_agent 脚本任务正常** → 指向配置/模型解析层，不是脚本层。
- 失败前后都有成功记录 + 恰好撞上 `signal=SIGTERM` 重启 → 判瞬时故障，别动配置。
- 反复在同一时刻失败（如每天 09:00）→ 才去查该任务的 schedule 与常驻写入者。
