# Telegram 指令菜单汉化（源码映射与实施方案）

目标：把 Telegram 输入 `/` 弹出的指令菜单（命令名 + 说明）汉化。
本机源码位置：`~/.hermes/hermes-agent/`（git 安装；`hermes` 二进制 → `~/.hermes/hermes-agent/venv/bin/hermes` 符号链接链，改源码后无需重新安装）。

## 硬性限制（先讲清楚，避免白做）
- **命令名不能汉化**：Telegram Bot API 规定命令名只能是 `a-z0-9_`（`/new` 不能改成 `/新建`）。命令名本身必须保持英文。
- **说明文字可以汉化**：菜单里每条命令的 description 是唯一可改的文本，也是汉化的全部意义所在。

## 菜单生成链路（谁在哪儿定义文字）
1. `hermes_cli/commands.py` → `COMMAND_REGISTRY`（`CommandDef(name, description, ...)` 列表，约 100+ 条内置命令）— **description 全部硬编码英文**，这是汉化的主战场。别名（如 /reset、/exit）不出现在 Telegram 菜单。
2. `telegram_bot_commands()`（~L603）：遍历 COMMAND_REGISTRY 生成 (命令名, 说明) 对；连字符替换为下划线；`_resolve_config_gates()`（~L502）只控制命令**启停**（config gate），与描述文字无关。
3. `telegram_menu_commands(max_commands=100)`（~L986）：优先级 核心命令 → 插件命令 → 技能命令；超过 Telegram 上限（约 100 条）时只裁剪技能层；技能说明截断 40 字符（`desc_limit=40`）→ **技能自身的 description 若是中文，菜单直接显示中文**（顺带汉化途径）。
4. 真正调 Bot API 的地方：`plugins/platforms/telegram/adapter.py` — 启动时 `set_my_commands`（~L3611，多 scope 遍历，含 BotCommandScopeChat），超级群首次消息时懒注册（~L8871 `_ensure_forum_commands`）。改完源码必须重启 gateway 才会重新注册菜单。

## 官方语言配置的作用边界（关键陷阱）
- `display.language`（config_defaults.py ~L1237）支持 en/zh/ja/de/es/fr/tr/uk，设置方式：`hermes config set display.language zh`。
- **源码注释明确：它只影响静态用户可见消息（批准提示、少量网关斜杠命令回复），不影响 slash-command descriptions、agent 回复、日志、工具输出。**
- 结论：光设 `display.language: zh`，Telegram 指令菜单仍是英文。菜单汉化必须改源码，两者配合才"全部中文"。

## 实施方案（写入操作，必须先等用户批准"马上执行"）
1. 备份：`cp hermes_cli/commands.py hermes_cli/commands.py.bak`
2. 汉化 `COMMAND_REGISTRY` 中每条 `CommandDef` 的 description 为中文（命令名保持不变）。
3. 生成可重放补丁（升级 git pull 会被覆盖）：`cd ~/.hermes/hermes-agent && git diff hermes_cli/commands.py > ~/.hermes/patches/tg-menu-zh.patch`，升级后 `git apply` 重新应用。
4. `hermes config set display.language zh`（界面静态文字也中文）。
5. 重启 gateway（kill + 后台启动；Telegram 重连约 1-2 分钟，见主 SKILL 重启节）。
6. 验证：Telegram 里输入 `/` 看菜单说明是否为中文；`/commands` 翻页确认完整列表。

## 分发与迁移套件中的中文菜单全自动化（2026-08 实战提炼）

在制作 Hermes 自动化安装包（如 `lemon-starter` 脱敏套件或 `lemon-backup` 迁移套件）分发给他人或迁移新机时：
1. **源码英文覆盖陷阱**：直接运行官方 `curl .../install.sh` 安装时，源码为官方英文，Gateway 启动会上报英文菜单。
2. **安装套件一键注入标准**：在安装向导获取 `TELEGRAM_BOT_TOKEN` 后，直接在脚本内嵌入轻量 Python 脚本调用 Telegram API `setMyCommands`（设置 `default`、`all_private_chats` 与 `all_group_chats`）。
3. **无服务器终端（仅有 Bot 聊天界面）的两种极简汉化法**：
   - **方案一（Bot 自改）**：在私聊中直接向 Bot 发送：“帮我在后台执行 Python 代码，读取你本地的 TELEGRAM_BOT_TOKEN，把你的 Telegram 菜单命令全部设置并刷新为中文。”（Agent 调用 terminal 工具自推 API 并生效）。
   - **方案二（@BotFather 直改）**：在 Telegram 官方 `@BotFather` 发送 `/setcommands`，选择对应 Bot 并粘贴中文命令列表（纯云端生效，零服务器依赖）。
4. **安装包稳健性加固准则**：
   - 自动检测并软链接 `HERMES_BIN`（兼容 `~/.local/bin/hermes`、`venv/bin/hermes` 及 `/usr/local/bin/hermes`），防止 systemd 启动报 203/EXEC 错误。
   - 自动注入默认中文 `SOUL.md`，确保新部署实例从第 1 轮交互即保持地道中文交流。

## 备注
- 插件命令描述来自插件自身注册（`_iter_plugin_command_entries`）；技能命令描述取技能 frontmatter description。
- 菜单上限约 100 条，被隐藏的命令通过 `/commands` 查看。
- **全局 command_menu 裁切私聊指令陷阱**：
  若在 config.yaml 的 `platforms.telegram.extra` 下配置了 `command_menu: max_commands: N, priority_mode: replace`，该参数会作为 BotCommand 全局截断规则，导致私聊（BotCommandScopeAllPrivateChats）中的菜单也被强制裁切至仅剩 N 个指令。
  - **规避方案**：若诉求仅为精简群聊防刷屏，切勿在 `platforms.telegram.extra` 配置全局 command_menu.max_commands，而应仅设置 `telegram.group_user_allowed_commands: help,whoami,clear,model,stop,summary`（配合 group_allow_admin_from）；这样私聊可保留全量 60+ 指令，群聊仅开放指定的 6 个指令。
- 该需求源于 2026-08 会话：爸爸要求"菜单指令栏和说明全部换成中文"，已确认方案（A 汉化源码 / B 仅 display.language / C 两者全做，默认推荐 C）。
