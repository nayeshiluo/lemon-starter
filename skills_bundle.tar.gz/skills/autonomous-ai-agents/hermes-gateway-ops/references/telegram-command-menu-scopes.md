# TG「输入框旁边那个斜杠 ⧄」排查实录 + 两个致命坑（2026-10-15）

爸爸当时的诉求：「我和你的对话框要自带 `/`，让我能直接输 `/` 指令」→ 截图为**群聊**输入栏里那个
方框+斜杠图标。最终爸爸决定**不搞了，回滚**。

## 一、那个斜杠是什么

Telegram 客户端里跟输入框相关的有两套东西，别混：

1. **Bot 菜单按钮（BotMenuButton）** — 官方协议原文：*"Bots can choose the behavior of the menu
   button shown **next to the text input field**."* 由 `bots.setBotMenuButton` 控制，能对**全部用户**
   或**某一个指定用户**单独设；`botMenuButtonCommands` = 显示斜杠按钮打开指令列表。
   改动时客户端会收到 `updateBotMenuButton` 推送 → **不需要重启客户端**。
2. **指令列表（setMyCommands 作用域）** — 打字 `/` 时弹的补全列表。

作用域：`default` / `all_private_chats` / `all_group_chats` / `all_chat_administrators` /
`chat(chat_id)` / `chat_member`。**getMyCommands 只返回该作用域"显式写过"的条目，不做继承回退**
（实测：某群 chat 作用域读 0，但 all_group_chats 有 6 条，群里菜单照样正常）。

## 二、Hermes 网关启动时会注册什么（`plugins/platforms/telegram/adapter.py` ~3630）

- `BotCommandScopeDefault` → 完整菜单（默认 60 条，`platforms.telegram.extra.command_menu` 可调）
- `BotCommandScopeAllPrivateChats` → 同上 60 条
- `BotCommandScopeAllGroupChats` → **群聊精选 6 条**：`help, model, stop, summary, clear, whoami`
- 不注册任何 `chat(chat_id)` 作用域（forum 群除外，走 `_ensure_forum_commands` 懒注册）

## 三、⚠️ 致命坑 1：urllib 传参写错 → 读到的数字全是假的

**错误写法**（Telegram 会 `ok:true` 但其实没生效 / 读回落到 default 作用域）：

```python
data = urllib.parse.urlencode({"params": json.dumps(params)}).encode()   # ❌ 不要这样
```

后果：`getMyCommands` 无论请求哪个作用域，**都返回 default 作用域的数字**——于是我看到
"两个 Bot 所有作用域完全一致"的假象，据此做了错误判断；`deleteMyCommands` 则**删掉了 default 作用域**
（本该只删 chat 作用域），把机器人全局指令菜单清空。

**正确写法**（实测有效）：curl + `--data-urlencode`，或字典值直接 json.dumps：

```bash
curl -s -X POST "https://api.telegram.org/bot$TOK/setMyCommands" \
  --data-urlencode 'scope={"type":"all_group_chats"}' \
  --data-urlencode 'commands=[{"command":"help","description":"帮助"}]'
curl -s -X POST "https://api.telegram.org/bot$TOK/getMyCommands" --data-urlencode 'scope={"type":"chat","chat_id":123}'
```

**纪律**：改任何作用域前后，都必须逐作用域回读核对；回读值出现"所有作用域数字一模一样"时，
立刻怀疑参数没传进去，而不是相信结论。

## 四、⚠️ 致命坑 2：回滚 deleteMyCommands 会误伤 default

`deleteMyCommands` **不带有效的 `scope`** 时会删 **default 作用域**（=机器人的全局指令菜单全没）。
所以任何"回滚私聊 chat 作用域"的操作，必须在同一个脚本里：先删 chat 作用域 → 立刻回读 default
确认还是 N 条 → 不对就用 `telegram_menu_commands()` 重新注册。

## 五、恢复脚本（已留档，可直接复用）

- `/home/ubuntu/hermes-jobs/scripts/tg_menu_final_fix.py` — 逐作用域真实核对 + 恢复成网关原状
  （default/私聊 = 完整 N 条，群 = 精选 6 条）
- `/home/ubuntu/hermes-jobs/scripts/tg_menu_rollback.py` / `tg_menu_restore.py` — ⚠️ 用了坑 1 的
  错误 urllib 写法，**仅作历史留档，别再用**；要改作用域用 `tg_menu_final_fix.py` 或 curl

## 六、结论（本次）

爸爸截图那个斜杠出在**群聊**里。我们 Bot 侧所有作用域 + 菜单按钮核验都正常
（default 60 / 私聊 60 / 群 6 / menuBtn commands），因此**差异不在 Bot 配置**；
最终判断方向是「客户端私聊界面不渲染该按钮」，爸爸选择不再折腾，已全部回滚为原状。
