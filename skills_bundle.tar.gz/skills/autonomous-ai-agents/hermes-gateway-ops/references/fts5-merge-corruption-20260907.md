# FTS5 merge 与 state.db 反复损坏的根因实录（2026-09-07 初稿，09-08 修正）

## 症状
- `No reply: the turn was stopped because session storage could not be written` 反复出现，删库重建 + 重启网关后数日复发。
- 日志：`database disk image is malformed` 在 `errors.log` / `gateway.log` 累计 **8600+ 条**，最早可追溯 **8月14日**。
- 用户核心不满：**"这个问题出现的次数太多了，每次你都说解决了"** —— 每次抢救只删库重建（治标），没找到反复制造损坏的源头。

## ⚠️ 结论修正记录（2026-09-08，爸爸质疑后深挖）
初稿曾断言"merge 失败后继续 checkpoint 固化半损坏状态 = 反复损坏元凶"。**该结论被本会话实验与时间线矛盾推翻**：
1. **反证实验**：副本上 merge=4 失败后跑 `PRAGMA integrity_check` 仍 = **ok** → merge 失败本身**不直接损坏库**。初稿第 3 条是推断，已撤回。
2. **时间线矛盾**：8/14 首次损坏（`file is not a database`，整库文件头级损坏）时，`db_maintenance.py`（8/27 创建）与 `daily_cleanup.sh`（8/20 创建）**都不存在** → 脚本不是唯一/根本元凶。
3. **教训**：排障下结论前必须先查"首次故障时间 vs 嫌疑脚本创建时间"是否存在矛盾；存在矛盾 = 还有更深系统层根因，不许拿单一嫌疑交差。爸爸的「你确定好是这个问题哈」就是点破这个漏洞。

## 时间线溯源法（反复发作故障的标准侦查姿势）
| 时间 | 事件 |
|---|---|
| 08-14 04:14 | 首次 `file is not a database`（整库文件头级损坏，早于所有自家脚本） |
| 08-20 | `daily_cleanup.sh` 创建（内部用**系统 python3 = SQLite 3.46.1** 对 state.db 做 checkpoint/optimize） |
| 08-27 03:20 | `~/.hermes/scripts/db_maintenance.py` 创建（venv python3 = SQLite 3.53.1） |
| 08-27 03:23 | 脚本第一次运行，FTS merge 立即报 `SQL logic error` |
| 08-26 ~ 09-07 | 每天 04:00 / 16:00 各跑一次，**23 次 merge 23 次失败（100%）** |
| 08-29 / 09-07 | FTS 损坏两次爆发（`database disk image is malformed`）→ No reply |
| 09-02 08:30 | **系统重启**（journal 被 vacuum 清掉，原因不可考） |
| 09-07 22:13 | Telegram 网络抖动（fallback IP 失败）→ 22:31 FTS 损坏爆发 |
| 09-04 | 曾留 `state.db.pre_merge_*` 备份修复 merge 事故，但只删库未除根 |

## 事实链（已实验验证）
1. **该环境 FTS5 `merge` 命令 100% 失败（SQL logic error）**。副本实验：全新最小表 / 有数据表 / external-content 表 / 带触发器表全部 FAIL；CLI 3.46.1 与 Python 3.53.1 均失败；同环境 `optimize` / `integrity-check` 正常。
2. **merge 失败不损坏库**（失败后 integrity_check = ok）→ merge 是"无意义失败"（每天两次报错噪音 + 干扰官方机制），但**不是损坏的直接制造者**。
3. Hermes 官方源码从不手动 merge（FTS5 automerge 自动管理）；官方在 FTS optimize 后**自己也执行 `wal_checkpoint(TRUNCATE)`**（`hermes_state_search.py:918`）→ checkpoint 不是外部脚本独有的危险操作。
4. Hermes 官方有 FTS 损坏自愈机制（`Rebuilt ... FTS index(es) after append corruption`，8/29 曾成功自愈）；9/7 自愈失败才需要人工介入。

## 系统层共同根因候选（三起事故 8/14、8/29、9/7 共同背景）
1. **跨版本 SQLite 并发访问 state.db（最高嫌疑）**：gateway 用 venv（sqlite 3.53.1）24/7 写库；`daily_cleanup.sh` 03:00 内部 `python3 - <<EOF` 用**系统 python3（sqlite 3.46.1）**对同一 WAL 库 checkpoint/optimize。旧版本解析新版本写的 WAL 帧存在写回错误页风险（简单场景未复现，真实并发未排除）。**规则：state.db 只归 Hermes 官方管，外部脚本一律不碰**。
2. **内存长期极限**：1.9GB 机器，gateway 峰值 1.4G，swap 常驻 547M；SQLite 内存耗尽时写失败/文件损坏是经典诱因。
3. **系统层不稳定**：9/2 系统重启；8/13 gateway 被 SIGTERM；**Telegram 网络每天 UTC 01:10（北京 09:10）固定 Bad Gateway**（8/13、9/1、9/2 连续命中）→ 重连写入风暴。
4. 损坏库实测：`messages` 主表与 `messages_fts_data`/`docsize` 均坏，`messages_fts_idx` 完好——损坏会从 FTS 蔓延到主表，说明是页面级破坏而非单表问题。

## 关键认知（会重复用到）
- **`PRAGMA integrity_check` 只验证 B-Tree 页面结构，不验证 FTS5 虚拟表索引**。FTS5 必须单独验证：
  ```sql
  INSERT INTO messages_fts(messages_fts) VALUES('integrity-check');  -- 无输出/exit=0 即健康
  ```
- 损坏库的 FTS 表症状：`Error: in prepare, vtable constructor failed: messages_fts (11)`（错误码 11 = SQLITE_CORRUPT）。
- **FTS5 影子表是 `data / idx / docsize / config`**（`segdir` 是 FTS3/4 的，查 FTS5 别用错表名）。`messages_fts_config` 正常只有 `version|N`（本库另有 `usermerge|2` 属正常配置）。
- 判断跨版本 SQLite：`/usr/bin/python3 -c "import sqlite3; print(sqlite3.sqlite_version)"` vs `venv/bin/python3` 同款——本机 3.46.1 vs 3.53.1。

## 修复方案（治本）
1. 删除 `db_maintenance.py` 的 FTS merge 步骤（merge 在此环境必失败且无意义；FTS5 automerge 已自动管理）。
2. **`daily_cleanup.sh` 不再碰 state.db**（删掉 SQLite 维护段）——消除跨版本并发访问。
3. 外部脚本对 state.db 任何操作失败 → 立即中止后续步骤，fail-closed。
4. 内存减压：小内存机上给 gateway 腾内存（关零调用 MCP 等，见 `references/low-memory-host-tuning.md`）。
5. 每日只读健康监控：`integrity_check` + FTS `integrity-check`，**坏了只报警不自动修**，发现即报用户。
   - **落地实现（2026-09-07 已部署实测）**：`scripts/state_db_watchdog.py` + `scripts/state_db_watchdog.sh`（本技能库内，与线上一致）。用 cronjob 注册：
     `cronjob(action=create, no_agent=true, script="state_db_watchdog.sh", schedule="0 0 * * *", deliver="origin")`
     —— 空 stdout = 静默不打扰；非空 stdout = 告警原样投递。
   - ⚠️ **实测坑：FTS5 integrity-check 在只读连接（`file:...?mode=ro`）上会报 `attempt to write a readonly database` 被拒绝**。必须用普通读写模式连接；该命令是只读语义、无副作用（实测执行前后 integrity_check 均 ok）。
   - ⚠️ **watchdog 必须用 venv python3 包装**（.sh 里 `exec venv/bin/python3`），禁止系统 python3——否则监控脚本自己变成跨版本访问者。
6. 修复后**跨 2 个维护周期**（04:00 / 16:00 cron）观察错误计数 = 0，再报"搞定"——这是对"每次都说解决了"的最直接回应。

## 实际执行状态（2026-09-07 晚，爸爸确认后落地）
- `db_maintenance.py`：FTS merge 步骤已替换为跳过日志（`Skipping FTS merge for state.db`），实测跑通零报错；原文件备份 `~/.hermes/scripts/*.bak_20260907`。
- `daily_cleanup.sh`：SQLite 维护段**保留但 dbs 列表排除 state.db**（仍维护 kanban/response_store 等非关键库），避免跨版本并发访问。
- watchdog cron 已注册（job id `5b548d3db16d`，每天 UTC 00:00 = 北京 08:00），健康静默/损坏报警。
- `lemon-ops-bot/main.py`：全局异常过滤器将单次 `Conflict`（断线重连假冲突）降级为 WARN 静默自愈，连续 3 次才告警；已 `systemctl restart lemon-ops` 验证。

## 复现/验证命令（副本测试，严禁直接对线上库）
```bash
cp ~/.hermes/state.db /tmp/test_merge_repro.db
/home/ubuntu/.hermes/hermes-agent/venv/bin/python3 -c "
import sqlite3
conn = sqlite3.connect('/tmp/test_merge_repro.db')
cur = conn.cursor()
try:
    cur.execute(\"INSERT INTO messages_fts(messages_fts) VALUES('merge=4')\"); conn.commit()
    print('merge=4 -> OK')
except Exception as e:
    print('merge=4 -> FAIL:', e)   # 预期 FAIL: SQL logic error
try:
    cur.execute(\"INSERT INTO messages_fts(messages_fts) VALUES('integrity-check')\"); conn.commit()
    print('integrity-check -> OK')  # 预期 OK
except Exception as e:
    print('integrity-check -> FAIL:', e)
conn.close()
"
# 反证实验（验证 merge 失败不损坏库）：
# 副本上：merge=4(预期FAIL) → PRAGMA integrity_check(预期仍=ok)
```

## 教训总结（对用户的承诺兑现方式）
- 删库重建 = 把时钟拨回第 0 天，不是修复。反复发作的故障必须找到"制造损坏的源头"，并验证根因已从源头移除。
- **下结论前先查时间线矛盾**（脚本创建时间 vs 首次故障时间）；有矛盾就继续查系统层，不拿单一嫌疑交差。
- **假设必须用副本实验验证**，不能只凭日志推断根因链；报"搞定"前确认错误计数在后续维护周期 = 0。
