# 网关会话重置（模板）— 用官方 SessionStore API，必须用 hermes venv python 运行
# 占位符：<HERMES_SRC>（hermes-agent 源码目录）、<SESSION_KEY>（agent:main:<platform>:<chat_type>:<chat_id>）、<OVERRIDE>（原会话的 model_override）
import sys, json
sys.path.insert(0, '<HERMES_SRC>')

from gateway.config import load_gateway_config
from gateway.session import SessionStore

KEY = '<SESSION_KEY>'
# 从 gateway_routing 的 entry_json 抄原 override（重置不继承，必须显式补回）
OVERRIDE = {
    'model': '<MODEL>',
    'provider': '<PROVIDER>',       # 例：custom:token.sensenova.cn
    'base_url': '<BASE_URL>',
}

config = load_gateway_config()
store = SessionStore(config.sessions_dir, config)
store._ensure_loaded()

old = store.get_model_override(KEY)
print('old override:', json.dumps(old, ensure_ascii=False), flush=True)

entry = store.reset_session(KEY, display_name='<原名，可留 None 继承>')
print('new session_id:', entry.session_id if entry else 'NONE', flush=True)

store.set_model_override(KEY, OVERRIDE)
print('new override:', json.dumps(store.get_model_override(KEY), ensure_ascii=False), flush=True)
print('RESET_OK', flush=True)
