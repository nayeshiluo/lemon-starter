# 一次性网关会话重置脚本（模板）— 由 crontab 调度，独立于网关 cgroup
# 用法：替换 <占位符> → chmod +x → 装 crontab（见 SKILL.md"cron 逃逸"节）
# 流程：等当前 turn 回复发出 → 停网关 → 官方 API 重置会话+保留 model_override → 启网关 → TG 通知 → 自清理
LOG=<HOME>/.hermes/scripts/tg_reset.log
MARK=/tmp/tg_reset_done
LOCK=/tmp/tg_reset.lock
export HOME=<HOME>
export PATH=<HOME>/.local/bin:/usr/local/bin:/usr/bin:/bin
PY=<HERMES_SRC>/venv/bin/python   # 例：/home/ubuntu/.hermes/hermes-agent/venv/bin/python

# 已完成则清理 crontab 并退出
if [ -f "$MARK" ]; then
  crontab -l 2>/dev/null | grep -v tg_session_reset.sh | crontab -
  exit 0
fi

exec >>"$LOG" 2>&1
echo "=== $(date '+%F %T') start ==="

# 等待当前会话回复发出（cron 可能立刻触发）
sleep 45

/usr/bin/hermes gateway stop
echo "stop exit: $?"
sleep 3

$PY <HOME>/.hermes/scripts/tg_reset.py
echo "reset exit: $?"

/usr/bin/hermes gateway start
echo "start issued: $?"
sleep 25

echo "--- gateway status ---"
/usr/bin/systemctl is-active hermes-gateway.service
echo "--- routing after reset ---"
$PY - <<'EOF'
import sqlite3, json
db = sqlite3.connect('<HOME>/.hermes/state.db')
cur = db.cursor()
cur.execute("SELECT entry_json FROM gateway_routing WHERE session_key='<SESSION_KEY>'")
row = cur.fetchone()
if row:
    d = json.loads(row[0])
    print('session_id:', d.get('session_id'))
    print('is_fresh_reset:', d.get('is_fresh_reset'))
    print('model_override:', json.dumps(d.get('model_override'), ensure_ascii=False))
    print('last_prompt_tokens:', d.get('last_prompt_tokens'))
else:
    print('NO ROUTING ENTRY')
db.close()
EOF

/usr/bin/hermes send -t telegram:<CHAT_ID> "✅ TG 会话已重置：上下文已清空，模型保持不变。"

echo "=== $(date '+%F %T') done ==="
touch "$MARK"
# 清理 crontab 条目
crontab -l 2>/dev/null | grep -v tg_session_reset.sh | crontab -
