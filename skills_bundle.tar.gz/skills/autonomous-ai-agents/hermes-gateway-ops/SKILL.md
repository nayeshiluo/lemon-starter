---
name: hermes-gateway-ops
description: "Hermes 网关运维与排障：面板/web-ui 无应答、api_server 连接失败、gateway 重启与验证。"
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [hermes, gateway, troubleshooting, api_server, config]
    related_skills: [hermes-agent]
---

# Hermes Gateway 运维与排障

## 当前部署边界（2026-10-16，优先于历史案例）

- 先只读审计。数据库写入、修复、迁移或恢复先备份并确认授权，停止全部持库进程后在副本验证。禁止在线自动 merge、checkpoint、VACUUM、rebuild 或热替换 state.db。
- 当前巡检 job `5b548d3db16d` 只读且异常去重；同一事务检查 FTS 影子表文档 ID，并考虑官方分批回填。external-content 表 COUNT 可能回源，数量相等不证明索引完整，瞬时不等也不能直接判损坏。
- `scripts/db_maintenance.py` 只维护非 state 库。`scripts/state_db_autoheal.py` 名称是兼容保留，实际只读巡检，绝不自动修库；watchdog 两个入口仅兼容转发。
- Telegram 私聊只允许已核实的唯一所有者；群权限、模型切换、危险能力分开验证。不得为排障全放行，不得把所有者专属称呼带给其他用户。
- 不得把脚本包装、子代理、cron、systemd-run 或编码改写当作绕过安全拒绝的方法。独立管理入口也须在现有授权范围内使用。
- 修改技能文本不要求重启网关；改配置或运行时代码时另查重载要求。“已修复”必须有对应功能证据。
- 历史案例仅作调查线索，不据此断言外部脚本、SQLite 版本或 FTS merge 是已确认根因。

## 安全与清理边界（优先于下文历史案例）
- 用户要求彻底清理时，一次确认是否包含控制端对话，明确授权后执行，不反复追问；不得将被要求删除的个人数据另存为技能或记忆。
- 授权撤销、凭据删除、停止运行中连接、本地会话删除与平台云端消息删除须分别验证。CLI 返回 Deleted 不代表所有痕迹清零。
- 明确的网关自重启安全拦截不得通过子代理、脚本包装、cron/systemd 调度或进程注入绕过。下文历史案例中以绕过扫描为目的的建议已废弃；应采用允许的独立管理路径或请用户从独立终端操作。子代理中断不证明重启成功。

## When to Use
- 平台解绑、历史删除、“不留痕迹” → 见 `references/platform-disconnect-and-history-cleanup.md`，含已验证 CLI、分支会话定位、删除后验证与第三方数据边界。
- 用户要求接入微信私聊 / iLink 二维码配对 → 见 `references/weixin-qr-pairing.md`。先查官方当前能力；PTY 向导取得真实 URL 后用二维码库编码 PNG 交付，严禁生成式绘图。扫码由用户确认；二维码生成不等于接入成功，必须验证权限与真实双向消息。保留 Telegram，默认仅本人、群聊关闭；独立机器人不等于接管个人微信号。
- 用户反馈在面板/web-ui/消息平台里"回答不了"、发消息没反应
- gateway 日志出现 `api_server failed to connect` 或 `Refusing to start`
- 修改了 gateway 相关配置（api_server、平台密钥等）需要重启生效
- gateway 崩溃或需要诊断连接状态
- 用户要求汉化 Telegram 指令菜单 / 修改斜杠命令说明（见 references/telegram-command-menu-localization.md）
- **用户反馈 Telegram 菜单指令“删了好多”或常用指令消失** → 检查 `config.yaml` 中 `platforms.telegram.extra.command_menu` 的 `priority_mode: replace` 陷阱（见「Telegram 菜单指令过度裁切」节）
- TG 发图片/语音报 `TimedOut` 或 `Couldn't download your photo`，文字正常（见 references/telegram-media-timeout.md）
- 用户要求"对话框里不要显示命令过程"（display.tool_progress）或抱怨系统消息是英文（汉化 gateway/run.py 文案）
- 用户抱怨出现"📬 尚未为 Telegram 设置主频道"提示，要求在群里不要再出现（见"关闭主频道提示"节）
- Web UI 面板/日志报 `Error: connect ENOENT /tmp/hermes-agent-bridge-workers/*.sock`（见 references/agent-bridge-socket-enoent.md）
- 用户发扫描件 PDF 要求转可编辑 Word（见 references/scanned-pdf-to-word.md）
- **用户反馈 TG/面板报「内存不够」「磁盘不足」「session storage could not be written」** → 别信这句文案，八成是 `state.db` 损坏或 OOM 撑爆页缓存（见 references/session-storage-corruption.md 的「OOM 撑爆页缓存」与「orphan index 死局」两节，含 cache_size 定容规则）
- **用户质问「之前明明清理/VACUUM/重构过，为什么 state.db 依然是 154MB」或提议时间跨度归档却无效** → 见 references/state-db-bloat-vacuum-and-archive-traps.md（VACUUM 生效必须先 DELETE、双重 FTS5 索引净重占半壁江山、全库时间戳跨度盲区与按会话级冷存归档 SOP）
- **用户进场问「你还好吗」「你活了没」「在吗」** → **严禁只看当前这一瞬间**的 uptime/系统负载。必须先回溯前 30 分钟日志（`journalctl -u hermes-gateway -n 30`、`errors.log`），确认有无异常退出、重启计数增加或人工抢救重启，严禁盲目回复“一切平稳”激怒用户（见 references/fts-vtable-fatal-extract-rescue-20260914.md）
- **用户说「TG 好久没反应」「Bot 不回话」「发消息没动静」** → 不要只看进程活没活，要读 `gateway.log` 最后 50 行排查：① 有无超时耗时（`response ready ... time=XXXXX.Xs`，超过 300s 必异常）；② 有无 `Transient agent failure`（session 级失败，用户消息已保存，重发即可恢复，不需重启）；③ TG 主连接是否已切备用 IP（`Primary api.telegram.org connection failed ... trying fallback IPs`，自动恢复，无需重启）；④ 是否卡在 vision_analyze 图分析（日志出现 `Pre-analyzing N image(s) via vision_analyze` 后无后续 = 模型侧卡死，等待超时或用户重发即恢复）。正确指令：`tail -50 ~/.hermes/logs/gateway.log`。进程存活 + 日志正常活跃 = 服务正常，无需重启。
  - **⚠️ `Transient agent failure` 的真正根因很可能是 429 日配额耗尽，不是网络超时**：gateway 会把同一次 API 调用重试耗尽后才标记 failure，导致单条消息卡 20~30 分钟看起来像超时。确认根因必须读 `~/.hermes/sessions/` 下的 `request_dump_<session_id>_*.json`（文件名含对应 session_id），其中 `"reason": "max_retries_exhausted"` + `"error": {"type": "RateLimitError", "status_code": 429}` 即为日配额耗尽铁证，与网络无关，重启无用。
  - **429 耗尽时的处置**：等配额重置（反重力 Gemini 免费 tier 按太平洋午夜，PDT=北京15:00，实测5~24小时才真正恢复）；让用户在 TG 发 `/new` 开新 session 避免带超长 history 继续积压；或切换 Hermes 主模型到其他 provider 临时绕过。
  - **超长 session 是加速耗尽的隐因**：同一 session 消息数达 50+ 时，每次调用均携带完整 history + 工具定义，token 消耗极大，数小时内即可吃完日配额。用户反馈"TG 不回"时先看 `"messages_count"` 字段。
- **`state.db` 报 `vtable constructor failed: messages_fts` 导致 `writable_schema` 与 `rebuild` 全线失效** → 升级为 Python 逐表逐行提取法（`rescue.py` 模式），且替换库时**必须先停 systemd 服务**，严禁热替换导致持有 `(deleted)` 句柄与 5 秒重启强杀风暴（见 references/fts-vtable-fatal-extract-rescue-20260914.md）
- **用户在 Telegram 看到「正在刷新...」转圈圈、无法收发消息，并引用历史报错（如「又爆内存了/session storage」）** → 严禁盲目归咎于 Hermes 爆内存或删库！先核对引用日志的时间戳（警惕历史旧账锚定效应），并做三层只读分诊：① 主机硬件与 state.db 真实健康；② Telegram 官方服务器端异常（502 Bad Gateway、GetChannelDifferenceRequest 报 HistoryGetFailedError / PersistentTimestampOutdatedError）；③ 客户端内置代理（明文 SOCKS5 遭 GFW 干扰篡改 vs MTProto Fake-TLS 专线），详见本文件「TG 客户端转圈刷新与历史报错锚定分诊」节
- **`state.db` 反复损坏/删库重建后数日复发** → 别急着再次删库重建！先做**时间线矛盾检查**：对比脚本创建时间 vs 首次故障时间 vs 日志故障频率分布。本机实证（2026-09-07/08）：`scripts/db_maintenance.py` 的 FTS5 `merge=4` 命令在此环境 100% 失败（23/23）且失败后仍继续 checkpoint，**但实验证明 merge 失败本身不损坏库，且 8/14 首次事故早于脚本创建**——脚本是叠加风险，更深根因在系统层（跨版本 SQLite 并发访问 state.db、内存极限、系统重启、Telegram 每日 01:10 网络故障），详见 references/fts5-merge-corruption-20260907.md
- **⚠️ `PRAGMA integrity_check=ok` 不证明 FTS 词项完整** → 线上只读检查索引覆盖与回填门控；FTS 专项完整性命令仅在一致性副本或获准离线环境使用，不在线用读写连接执行。
- **要做 `state.db` 抢救/热替换这类多步长任务** → 先读本文件的「长时排障的汇报纪律」节。用户在这类任务里最容易反复追问「好了没」，节奏比手速更重要
- **超长命令行/heredoc 被 `BLOCKED (hardline)` 拦下** → 不要原样重试，也不要改写措辞硬闯。这是命令载荷体积/解析限制，不是操作本身被禁：拆成多条短命令，或改用 `execute_code` / `read_file` 等专用工具（见「超长命令载荷被 hardline 拦截」节）
- **用户说「弹窗我点了显示已过期」「点了没反应」「每次都超时」** → 先分清是「点晚」还是「点了但结果被丢弃」。判据：`agent.log` 里超时恰好等于 `approvals.timeout`（默认 300s）+ `bridge.log` 里**确实有** `approval_respond` + 无 `Approval wait interrupted by user signal` = 点击已送达但 resolve 匹配失败。Web UI 侧 2026-10-24 实测根因是 `_request_id` / `request_id` 键名错配，修复与重启注意事项见 `references/webui-approval-popup-request-id.md`。**不要因为 Telegram 审批正常就排除 agent 侧代码问题**——TG 走 `/approve` 不依赖精确匹配。
- **小内存机（≤2GB）上服务反复 `status=1/FAILURE` 重启、用户说「你出问题了我花好久才救活」** → 先做内存归因再动手，头号浪费往往是**零调用的 MCP server**（本机 4 个 hermes-studio 占 518MB / 31.5%，历史调用 0 次）。完整归因脚本、`cache_size` 每连接放大计算、cron UTC↔北京时区换算撞车表见 `references/low-memory-host-tuning.md`
- **用户要求「模型开到最大思考模式」** → 先核实 provider 能力与响应；跨技能加载 `skill_view(name='hermes-custom-providers', file_path='references/reasoning-effort-not-delivered-to-relays.md')`。
- **用户贴出「Cron 'X' failed: ... has no model configured (job.model=None, config.yaml model.default missing or empty)」** → 先怀疑 config.yaml 在那一分钟被写坏 + 网关重启撞车，别照着告警去给任务钉模型（见 references/cron-failure-and-config-corruption.md）
- **用户说「TG 回复太慢」且回复里冒出模型名（「这里是Qwen3:4b模型」「我是Hermes」）** → 这是**模型层**问题，别去查网关/网络。三步定位（2026-10-23 实录，`你好` 耗 95.9s）：
  1. `gateway.log` 的 `response ready ... time=Xs api_calls=N response=N chars` —— **`api_calls=1` 却 time 很大 = 单次模型调用慢**，不是多轮工具调用拖的。
  2. `agent.log` 的 `API call #N: model=X provider=Y in=N out=N latency=Xs` —— 先看 `model=`（用户可能自己在 TG 里 `/model` 切过，配置里查不到），再看 in/out。
  3. **`out` tokens 与回复字符数严重不成比例 = 思考链污染**：实测 `out=942` 只产出 28 字符回复 → 93.5s。qwen3 系思考关不掉（`think:false`、`/no_think`、`/api/chat` 全无效），换非思考模型。
  - 回复里出现模型名/「我是Hermes」= **system prompt 人设没生效**。3b/4b 小模型扛不住 Hermes 约 2050-token 的 system prompt，不是配置错，是能力不够 —— 换大模型，或把该端点改成批处理用途。
  - 排查时别漏掉同时段的 502：`errors.log` 里 `HTTP 502: The sandbox service disconnected` 会让首轮重试再叠 20s，与模型慢叠加。

## ⚠️ 长时排障的汇报纪律（2026-09-04 实录，用户体验教训）

`state.db` 抢救这类修复要跑十几个只读+写入步骤，本次实录中用户在过程里追问了 **5 次**：
「好了没」「咋样了」「我等了好久了」「你活了没」「汇报一下啊」——每一次都说明汇报节奏出了问题。

### 硬规则
1. **绝不以"马上去做"结尾**。本次犯过一次：回了「爸爸别急，柠檬马上搞定，我直接用 writable_schema 暴力清掉那个孤儿索引」然后**结束了回合、没有任何工具调用**，用户只能再 ping 一次（「你还好吗／你好了没」）。宣布下一步的同一个回合里必须带上对应的工具调用。
2. **每个阶段结束就吐一行状态**，不要攒到全部完成再说。阶段边界 = 停服务 / 备份 / 抢救 / 替换 / 重启 / 验证。一行足够：`已停服务→已备份53M→抢救出55会话10793条→integrity=ok，正在重启`。
3. **修复走到死路时立刻说**，不要闷头换招。本次 `writable_schema` 偏方失败、`hermes sessions repair` 失败，这两次都该当场告诉用户"这条路不通，换另一条"，而不是静默继续试第三种。
4. **用户催问时先回状态再继续干活**。回答「活了没」这类问题只需要 3 个事实：服务 active？integrity ok？损坏报错计数=0？先把这三行发出去，再接着做剩下的收尾。
5. 长任务预估超过 2~3 分钟时，开工前先给一句预期：「大概要 3~5 分钟，中间会停一次网关」。用户知道要等多久就不会反复问。
6. **明确要求「一步步排查/一条条回复」时严格单步只读交互**：当用户要求「一条一条回复我」「一步步排查」「不要一次性全在后台处理」时，严禁单回合在后台连续跑多步批处理或擅自越过确认执行写操作。每回合严格执行一条只读检查，汇报该步客观事实并提出下一步建议，等待用户确认后再推进。
7. **报告结论需列真实机制和证据**：列出实际修改的写入口、只读巡检及离线恢复路径；当前没有自动修库功能，不宣称已自愈或保证永不复发。

### 破坏性动作的授权边界
用户一句「你去」「好了没」是对**当次具体动作**的批准，**不是**对"顺手再优化点别的"的授权。改配置上限、删条目、替换数据库这类不可逆动作，即使落在批准范围内，也要在动手前单独说明后果（同「Telegram 菜单指令过度裁切」节的血泪教训）。

## 验证（必须做，不能只看进程）
1. `ss -tlnp | grep 8642` → 应显示 `LISTEN`（pid 为 hermes）
2. `curl -s -o /dev/null -w "%{http_code}" http://127.0.0.1:8642/health` → 200（/health 是公开端点，无密钥也返回 200，属正常，不以此判断认证）
3. `grep "api_server" ~/.hermes/logs/gateway.log | tail` → 应看到 `✓ api_server connected`

## Telegram：已连接 ≠ 可对话（常见误判）
日志出现 `✓ telegram connected` 只代表机器人上线，不代表用户能收发消息。全新环境未配置 pairing/allowlist 时，默认策略**拒绝所有未知发送者**：用户发消息无反应、不留日志、不建会话（state.db 里没有任何 telegram 记录）。

诊断顺序（只读）：
1. `hermes send --list telegram` → 若显示 `(no channels discovered yet)`，说明 gateway 从未记录过任何会话/chat_id
2. 查会话库找 chat_id：`~/.hermes/hermes-agent/venv/bin/python -c "import sqlite3; db=sqlite3.connect('file:/home/ubuntu/.hermes/state.db?mode=ro', uri=True); db.execute('PRAGMA query_only=ON'); print(db.execute(\"SELECT source,chat_id,title FROM sessions WHERE chat_id IS NOT NULL\").fetchall())"`（本机无 sqlite3 CLI，用 python3 内置 sqlite3 模块；sessions 表有 chat_id 列）
3. `ls ~/.hermes/pairing/` 为空 → 无已配对用户
4. gateway.log 搜 `allowlists` 警告 → 确认默认拒绝策略在生效

启用路径（写入操作，必须等用户批准"马上执行"）：
1. 让用户先在 TG 给机器人发一条任意消息 → 拿到 chat_id（日志/state.db）
2. 核实 `TELEGRAM_ALLOWED_USERS` 仅包含已验证的所有者 ID；同时检查 owner-only 与群权限，不设置全放行变量，不增加其他人私聊权限。
3. config.yaml 设 `platforms.telegram.dm_policy: open`
4. 重启 gateway（见上节）
5. 主动推送验证：`hermes send --to telegram:<chat_id> "消息"`（bot-token 平台无需 gateway 在跑；`hermes send --list` 看可用目标）

## 历史排障详情：按需加载（勿一次读取全部）

主技能保留当前安全边界、场景路由与功能验证原则。完整历史章节已按专题转存到参考文件，排障时只读取需要的一类；优先执行主文件当前边界。

- 数据库/FTS/备份：`skill_view(name="hermes-gateway-ops", file_path="references/history-db-safety-20261018.md")`
- 网关重启、会话与 systemd：`skill_view(name="hermes-gateway-ops", file_path="references/history-gateway-core-20261018.md")`
- 上下文超限与压缩：`skill_view(name="hermes-gateway-ops", file_path="references/history-context-bloat-20261018.md")`
- Telegram UI/权限/连接：`skill_view(name="hermes-gateway-ops", file_path="references/history-telegram-20261018.md")`

历史案例不是当前状态，相关安全与回滚要求仍然有效；真实功能测试不可省略。

## References
- `references/fts-vtable-fatal-extract-rescue-20260914.md` — FTS 虚拟表物理坏死（vtable constructor failed）、Python 逐表逐行纯行提取抢救、systemd 停机替换防强杀风暴与「你还好吗」问候语回溯分诊纪律（2026-09-14 实录）。
- `references/state-db-bloat-vacuum-and-archive-traps.md` — state.db 膨胀归因、VACUUM 生效前提误区、双重 FTS 索引写放大、全库时间戳盲区、FTS5 影子表墓碑阻碍 VACUUM（必须 rebuild 否则卡在 106MB）、外键跨界解绑与按会话级冷存归档完整实测 SOP（2026-09-14 实录）。
- `references/sqlite-recover-fts5-shadow-orphan.md` — SQLite .recover 导出导致 FTS5 孤儿影子表与虚拟表缺失排查与自愈（2026-09-13 实录）：修复 `error creating shadow table messages_fts_data: table 'messages_fts_data' already exists` 与会话存储禁用。
- `scripts/db_maintenance.py` — 非 state 库写维护，不能用于只读审计；拒绝 state.db 及符号/硬链接别名。先验证备份再维护；失败或没有现存目标时不清旧备份；清理仅限本轮成功库并保留最新一代。生产入口以 crontab 为准，勿直接覆盖。
- `scripts/state_db_watchdog.py` + `scripts/state_db_watchdog.sh` — 只读监控兼容入口，委托同包 state_db_autoheal.py，不使用旧读写 FTS 检查。
- `scripts/state_db_autoheal.py` — 最新只读监控快照：mode=ro、query_only、单读事务；核对实际 docsize ID 和回填状态；只写库外去重状态，绝不自动备份/rebuild/替换。生产副本更新前须比较最新文件。
- `references/fts5-merge-corruption-20260907.md` — state.db 反复损坏根因实录（09-07 初稿 / 09-08 修正）：merge 100% 失败 + 失败不损坏库的实验反证、时间线矛盾（8/14 首次事故早于脚本）、系统层根因候选（跨版本 SQLite 并发/内存/重启/网络抖动）、FTS5 独立 integrity-check、治本修复方案
- `references/low-memory-host-tuning.md` — 小内存宿主机（≤2GB）内存归因与瘦身（2026-09-04）：`code=exited status=1` ≠ OOM Killer 的证据边界、内存归因脚本、零调用 MCP 取证与禁用、`cache_size` 每连接 ×13 放大计算、cron UTC↔北京撞车表、配置双向完整性校验片段
- `references/agent-bridge-socket-enoent.md` — Hermes Web UI Agent Bridge Socket ENOENT 排障与修复
- `references/webui-approval-popup-request-id.md` — Web UI 审批弹窗点「已过期」根因（`_request_id` vs `request_id` 键名错配）、300s 超时 vs 19s 点击的日志取证判据、隔离验证脚本、**重启前必查当前会话由哪个 bridge 托管**、`systemd-run --user` 需导出 `XDG_RUNTIME_DIR`/`DBUS_SESSION_BUS_ADDRESS` 的延迟重启法、npm 全局包升级会覆盖补丁（2026-10-24 实录）
- `references/context-bloat-prevention.md` — 上下文爆炸实录（2026-08-14）：根因链、防爆配置（max_turns/session_reset）、delegate_task 重启验证、面板排查未闭环项
- `references/scanned-pdf-to-word.md` — 扫描件 PDF → OCR 可编辑 Word 工作流（本机 2GB 内存无法跑 marker-pdf，用视觉模型逐页 OCR 替代）
- `references/telegram-chat-id-discovery.md` — 本次排障实录：hermes send 输出、state.db 查询、日志证据与修复步骤
- `references/telegram-dc-outage-and-sync-hang.md` — Telegram DC 级故障排查与客户端「正在刷新」差量死锁诊断（2026-09-08 实录）：DC5（新加坡/亚太 <YOUR_SERVER_IP>/22）增量同步崩溃、用户锚定历史旧日志误判网关崩盘的只读分诊流程、明文 SOCKS5 被 GFW 篡改特征与 Fake-TLS MTProto 专线恢复
- `references/session-reset-from-inside.md` — 历史会话重置记录；旧调度重启做法已废弃，只参考版本相关的路由语义，不能照抄执行。
- `templates/gateway_session_reset.sh` + `templates/gateway_session_reset.py` — 一次性会话重置脚本模板（cron 调度、自清理、TG 通知）
- `references/cron-failure-and-config-corruption.md` — cron 报「no model configured」的分诊（2026-10-15 实录）：config.yaml 瞬时 YAML 损坏（`config.yaml.corrupt.<ts>.bak`）+ 网关 SIGTERM 重启撞车的时间线取证，`errors.log` / `gateway-exit-diag.log` / `gateway-starts.log` / `hermes cron runs` / `cron/executions.db`（表 `executions` 列清单）/ `cron/output/<job_id>/` 六条只读路径，`hermes cron` 无 `update` 子命令与「钉模型只能用 CLI 且须用户授权」的边界，no_agent 脚本任务失败详情定位法
