#!/usr/bin/env python3
"""Read-only, silent-when-healthy state.db monitor for Hermes cron.

Never mutate SQLite while the gateway is live. Alert once per changed problem;
clear the alert latch after a healthy check so a later recurrence is reported.
"""
import fcntl
import json
import os
import sqlite3

DB = os.environ.get('HERMES_STATE_DB', os.path.expanduser('~/.hermes/state.db'))
STATE = os.environ.get('HERMES_DB_ALERT_STATE', os.path.expanduser('~/.hermes/logs/state_db_alert_state.json'))
problems = []
if not os.path.isfile(DB):
    problems.append('state.db 不存在')
else:
    try:
        # mode=ro also includes committed WAL contents; query_only blocks writes.
        con = sqlite3.connect('file:' + DB + '?mode=ro', uri=True, timeout=10)
        try:
            con.execute('PRAGMA query_only=ON')
            # Hold one WAL read snapshot across every database check.
            con.execute('BEGIN')
            row = con.execute('PRAGMA integrity_check').fetchone()
            if row != ('ok',):
                problems.append('integrity_check: ' + str(row[0] if row else '无结果')[:240])
            else:
                # Plain SELECTs on external-content FTS tables read the source,
                # not index coverage. Check actual indexed document IDs instead.
                meta = dict(con.execute(
                    "SELECT key, value FROM state_meta WHERE key IN "
                    "('fts_rebuild_high_water', 'fts_rebuild_progress')"
                ).fetchall())
                high_water = int(meta.get('fts_rebuild_high_water', -1))
                progress = int(meta.get('fts_rebuild_progress', -1))
                pending = high_water >= 0 and progress < high_water
                for label, source, shadow in (
                    ('FTS', 'messages', 'messages_fts_docsize'),
                    ('trigram', 'messages_fts_trigram_src',
                     'messages_fts_trigram_docsize'),
                ):
                    # Native chunked backfill intentionally leaves this range
                    # unindexed. Already covered and newly added IDs must match.
                    covered = 'AND (s.id > ? OR s.id <= ?)' if pending else ''
                    params = (high_water, progress) if pending else ()
                    missing = con.execute(
                        f'SELECT 1 FROM {source} AS s '
                        f'WHERE NOT EXISTS (SELECT 1 FROM {shadow} AS d '
                        f'WHERE d.id = s.id) {covered} LIMIT 1', params
                    ).fetchone()
                    extra = con.execute(
                        f'SELECT 1 FROM {shadow} AS d '
                        f'WHERE NOT EXISTS (SELECT 1 FROM {source} AS s '
                        'WHERE s.id = d.id) LIMIT 1'
                    ).fetchone()
                    # Stable problem text keeps the same fault deduplicated
                    # even while messages continue to arrive.
                    if missing:
                        problems.append(f'{label} 索引缺少文档记录')
                    if extra:
                        problems.append(f'{label} 索引存在无源文档记录')
                fk = con.execute('PRAGMA foreign_key_check').fetchone()
                if fk:
                    problems.append('foreign_key_check 检测到违规')
        finally:
            con.close()
    except (sqlite3.Error, OSError, ValueError) as exc:
        problems.append('数据库读取失败: ' + type(exc).__name__ + ': ' + str(exc)[:180])
try:
    size = os.path.getsize(DB + '-wal')
    if size > 200 * 1024 * 1024:
        problems.append(f'WAL 超过 200 MiB: {size // 1048576} MiB')
except FileNotFoundError:
    pass

# Serialize cron invocations and update only a small external alert latch.
os.makedirs(os.path.dirname(STATE), exist_ok=True)
with open(STATE + '.lock', 'a+') as lock:
    fcntl.flock(lock, fcntl.LOCK_EX)
    try:
        with open(STATE) as f:
            previous = json.load(f).get('problems', [])
    except (OSError, ValueError, AttributeError):
        previous = []
    if problems != previous:
        tmp = STATE + '.tmp'
        with open(tmp, 'w') as f:
            json.dump({'problems': problems}, f, ensure_ascii=False)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, STATE)
        if problems:
            print('🚨 Hermes state.db 只读巡检发现异常（未执行数据库修改）')
            for issue in problems:
                print('• ' + issue)
            print('请保留现场并人工复核；不要仅凭此提示直接重建或恢复数据库。相同异常恢复前不会重复通知。')
