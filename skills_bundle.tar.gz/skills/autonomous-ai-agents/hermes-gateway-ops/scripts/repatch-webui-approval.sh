#!/usr/bin/env bash
# 升级 hermes-web-ui 后重打「Web UI 审批 request_id」补丁。
#
# 为什么需要：npm 全局包升级是整目录替换，会把 bridge_pool.py 的修复覆盖回上游原版。
# 上游到 0.7.39 仍未修（该文件与 0.7.37 原版逐字节相同），所以每次升级后都要重跑本脚本，
# 否则 Web UI 审批弹窗退回「点了一直显示过期」——agent 侧等满 300 秒超时，点击被静默丢弃。
# 详见 references/webui-approval-popup-request-id.md
#
# 用法：
#   ./repatch-webui-approval.sh          打补丁（幂等，已修则跳过）
#   ./repatch-webui-approval.sh --check  只检查不修改（退出码 0=已修 / 1=未修）
#
# 打完必须重启主 bridge 才生效，且当前会话可能就跑在 bridge 里，要用延迟重启。

set -uo pipefail

BP=/usr/local/lib/node_modules/hermes-web-ui/dist/server/agent-bridge/python/bridge_pool.py
PKG=/usr/local/lib/node_modules/hermes-web-ui/package.json
CHECK_ONLY=0
[ "${1:-}" = "--check" ] && CHECK_ONLY=1

say() { printf '%s\n' "$*"; }
die() { printf 'ERROR: %s\n' "$*" >&2; exit 1; }

[ -f "$BP" ] || die "找不到 bridge_pool.py：$BP"

VER=$(python3 -c "import json;print(json.load(open('$PKG'))['version'])" 2>/dev/null || echo unknown)
say "hermes-web-ui 版本: $VER"
say "bridge_pool.py: $BP"
say "sha256(当前): $(sha256sum "$BP" | cut -d' ' -f1)"

# 幂等判据：修复版必须含 _request_id 兜底
if grep -q 'approval_data.get("_request_id")' "$BP"; then
  say "状态: 已含修复（_request_id 兜底存在），无需重打"
  exit 0
fi

if [ "$CHECK_ONLY" = "1" ]; then
  say "状态: 未修复 —— 审批弹窗会超时。运行本脚本（不加 --check）来打补丁。"
  exit 1
fi

say "状态: 未修复，开始打补丁"

STAMP=$(date -u +%Y%m%d_%H%M%S)
BAK="${BP}.pre-repatch-${VER}-${STAMP}"
cp -p "$BP" "$BAK" || die "备份失败"
say "已备份: $BAK"

# 精确替换：只改 request_id 读取那一行
python3 - "$BP" <<'PY' || die "补丁应用失败"
import sys, pathlib
p = pathlib.Path(sys.argv[1])
src = p.read_text(encoding='utf-8')
old = 'request_id = str(approval_data.get("request_id") or "").strip()'
new = ('request_id = str(approval_data.get("request_id") '
       'or approval_data.get("_request_id") or "").strip()')
if new in src:
    print('已含修复，跳过'); sys.exit(0)
if src.count(old) != 1:
    print(f'未找到唯一目标行（命中 {src.count(old)} 次），上游可能已改结构，需人工核对')
    sys.exit(2)
p.write_text(src.replace(old, new), encoding='utf-8')
print('替换完成')
PY

# AST 校验
python3 -c "import ast;ast.parse(open('$BP',encoding='utf-8').read())" \
  || { cp -p "$BAK" "$BP"; die "补丁后语法错误，已回滚"; }
say "AST 校验: OK"

# 行为校验：模拟 agent 侧真实形态 {"_request_id": ...}
python3 - "$BP" <<'PY' || exit 1
import re, pathlib, sys
src = pathlib.Path(sys.argv[1]).read_text(encoding='utf-8')
# 注意：不要写成 \.strip\(\)\) —— .strip() 自己就是行尾最后一个 )
m = re.search(r'request_id = str\(approval_data\.get\("request_id"\).*?\.strip\(\)', src)
if not m:
    print('找不到 request_id 赋值语句'); sys.exit(1)
expr = m.group(0).split('=', 1)[1].strip()
val = eval(expr, {'approval_data': {'_request_id': 'abc123'}, 'str': str})
print('模拟 agent 侧 {"_request_id":"abc123"} ->', repr(val))
if val != 'abc123':
    print('取值为空，修复无效'); sys.exit(1)
print('行为校验: PASS')
PY
RC=$?
if [ "$RC" != "0" ]; then cp -p "$BAK" "$BP"; die "行为校验失败，已回滚"; fi

say "补丁完成。"
say ""
say "!! 必须重启才生效，且当前会话可能就跑在 bridge 里，不能同步重启："
say "   路径 A（只打了补丁、包版本没变）—— 只重启主 bridge："
say "     export XDG_RUNTIME_DIR=/run/user/1000 DBUS_SESSION_BUS_ADDRESS=unix:path=/run/user/1000/bus"
say "     systemd-run --user --collect --unit=<name> <restart.sh>（脚本内 sleep 60）"
say "     见 references/webui-approval-popup-request-id.md 的「用独立延迟任务重启」节"
say "   路径 B（刚做完整包升级，server 代码也要重载）—— 重启系统级服务："
say "     sudo systemd-run --unit=hermes-webui-upgrade --on-active=150 \\"
say "       --timer-property=AccuracySec=1s <upgrade 脚本或 restart 脚本>"
say "     系统级不需要 XDG/DBUS；见 references/webui-upgrade-deferred-restart.md"
say ""
say "重启后验证：Web UI 触发一次需审批的命令，点击应立即生效，"
say "agent.log 不应再出现 (300.xx s) 超时。"

# 显式成功退出。本脚本在 set -u 下运行，尾部任何一行提示若引用了未设置变量
# （例如从 systemd transient 单元调用时 HOME 未设置），就会让「补丁其实已打成功」
# 变成退出码 1，被上层升级包装器误判为失败而白白回滚一次 —— 2026-10-24 实测踩过。
# 提示文字不该决定退出码；上层判据一律用 --check。
exit 0
