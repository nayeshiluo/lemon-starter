#!/usr/bin/env python3
"""
Hermes state.db 只读健康监控（2026-09-07 部署，实测通过）
=========================================================
背景: state.db 反复出现 FTS 索引损坏 ("database disk image is malformed")
导致 "No reply: session storage could not be written"。外部维护脚本已全部
停止干预 (db_maintenance merge 移除 / daily_cleanup 不再碰 state.db)。

本脚本只做只读检查（FTS5 integrity-check 命令本身是只读语义）:
  1. PRAGMA integrity_check            (b-tree 完整性)
  2. messages_fts integrity-check      (FTS5 标准索引)
  3. messages_fts_trigram integrity-check (FTS5 CJK 索引)
  4. WAL 文件异常膨胀检查 (>200MB)

⚠️ 已知坑（实测 2026-09-07）:
  - FTS5 integrity-check 命令在只读连接 (mode=ro) 上会被拒绝:
    "attempt to write a readonly database" —— 必须用普通读写模式连接,
    但命令本身是只读语义, 不产生持久写入 (实测执行前后 integrity 均 ok)。
  - 必须用 Hermes venv python3 运行 (见 state_db_watchdog.sh 包装),
    禁止用系统 python3 (SQLite 3.46.1) 打开 gateway 维护的 WAL 库,
    否则监控脚本自己就变成"跨版本访问者"。

行为: 健康 -> 零输出(静默); 异常 -> 输出告警文本。
配合 cron no_agent 模式注册: 空 stdout = 静默不打扰, 非空 stdout = 原样投递告警。
注册示例: cronjob(action=create, no_agent=true, script="state_db_watchdog.sh",
          schedule="0 0 * * *", deliver="origin")
"""
import os
import sys
import sqlite3

db = os.path.expanduser("~/.hermes/state.db")
if not os.path.exists(db):
    sys.exit(0)  # 库不存在不报警（可能刚重建）

problems = []

try:
    conn = sqlite3.connect(db, timeout=10)

    # 1. 主库 b-tree 完整性
    try:
        r = conn.execute("PRAGMA integrity_check").fetchone()
        if r is None or r[0] != "ok":
            problems.append(f"integrity_check: {r}")
    except Exception as e:
        problems.append(f"integrity_check 执行失败: {e}")

    # 2. FTS5 标准索引完整性（只读语义命令, 不写库）
    try:
        conn.execute("INSERT INTO messages_fts(messages_fts) VALUES('integrity-check')")
    except Exception as e:
        problems.append(f"messages_fts 索引异常: {e}")

    # 3. FTS5 trigram 索引完整性（CJK 搜索索引）
    try:
        conn.execute("INSERT INTO messages_fts_trigram(messages_fts_trigram) VALUES('integrity-check')")
    except Exception as e:
        problems.append(f"messages_fts_trigram 索引异常: {e}")

    conn.close()
except Exception as e:
    problems.append(f"数据库打开失败: {e}")

# 4. WAL 异常膨胀检查
try:
    wal_size = os.path.getsize(db + "-wal")
    if wal_size > 200 * 1024 * 1024:
        problems.append(f"WAL 文件异常膨胀: {wal_size // 1024 // 1024}MB")
except OSError:
    pass

if problems:
    print("⚠️ Hermes state.db 健康检查发现异常")
    print("━━━━━━━━━━━━━━━━━━━━")
    for p in problems:
        print(f"🔴 {p}")
    print("━━━━━━━━━━━━━━━━━━━━")
    print("提示: 请勿直接删库! 先尝试: hermes sessions repair")
    print("若无法修复再考虑离线处理, 避免丢失会话历史。")
    sys.exit(0)  # no_agent 模式靠 stdout 判断, 退出码无所谓
