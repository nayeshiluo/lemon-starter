#!/usr/bin/env python3
"""Compatibility entrypoint for the read-only monitor; never rebuild indexes."""
from pathlib import Path
import runpy

if __name__ == "__main__":
    runpy.run_path(str(Path(__file__).with_name("state_db_autoheal.py")), run_name="__main__")
