#!/usr/bin/env bash
# hermes-web-ui 整包升级：备份 -> 停服务 -> npm 装新版 -> 重打审批补丁 -> 起服务 -> 就绪探测。
# 任一步不达标整体回滚旧版并重启服务，结果写 STATUS 文件。
#
# 为什么必须延迟执行：本机所有会话都挂在
#   node dist/server/index.js (hermes-web-ui.service) -> hermes_bridge -> worker
# 这条链上，重启必然掐断正在回复的会话。所以由独立 transient 单元触发：
#
#   sudo systemd-run --unit=hermes-webui-upgrade --on-active=150 \
#     --timer-property=AccuracySec=1s /path/to/upgrade-webui.sh
#
# 挂完确认：systemctl list-timers 'hermes-webui-upgrade*' --all --no-pager
# 详见 references/webui-upgrade-deferred-restart.md

set -uo pipefail

BK=/home/ubuntu/backups/webui-upgrade-20261024
LOG=$BK/upgrade.log
STATUS=$BK/STATUS
TARGET=${TARGET:-0.7.39}
SVC=hermes-web-ui.service
PKGDIR=/usr/local/lib/node_modules/hermes-web-ui
BP=$PKGDIR/dist/server/agent-bridge/python/bridge_pool.py
REPATCH=/home/ubuntu/backups/webui-approval-fix-20261024/repatch-after-upgrade.sh

mkdir -p "$BK"
exec >>"$LOG" 2>&1

ts() { date -u '+%Y-%m-%dT%H:%M:%SZ'; }
log() { printf '[%s] %s\n' "$(ts)" "$*"; }

log "=============================================="
log "===== hermes-web-ui 升级开始（目标 $TARGET） ====="

[ -f "$BP" ] || { log "FATAL: 找不到 $BP"; echo "FAIL:no_bridge_pool:$(ts)" >"$STATUS"; exit 1; }
[ -x "$REPATCH" ] || { log "FATAL: 找不到补丁脚本 $REPATCH"; echo "FAIL:no_repatch:$(ts)" >"$STATUS"; exit 1; }

OLD_VER=$(python3 -c "import json;print(json.load(open('$PKGDIR/package.json'))['version'])" 2>/dev/null || echo unknown)
log "升级前版本: $OLD_VER"

# ---------- 1. 整包备份（回滚用） ----------
TARBALL=$BK/hermes-web-ui-$OLD_VER-full.tar.gz
if [ -s "$TARBALL" ]; then
  log "复用已有备份: $TARBALL ($(du -h "$TARBALL" | cut -f1))"
else
  log "备份包目录 -> $TARBALL"
  if ! tar -C /usr/local/lib/node_modules -czf "$TARBALL" hermes-web-ui; then
    log "FATAL: 备份失败，不冒险升级，直接中止（服务未动）"
    echo "FAIL:backup:$(ts)" >"$STATUS"
    exit 1
  fi
  log "备份完成: $(du -h "$TARBALL" | cut -f1)"
fi
tar -tzf "$TARBALL" >/dev/null 2>&1 \
  || { log "FATAL: 备份不可读，中止"; echo "FAIL:backup_corrupt:$(ts)" >"$STATUS"; exit 1; }

rollback() {
  log "!! 触发回滚 -> $OLD_VER"
  systemctl stop "$SVC" 2>/dev/null
  sleep 2
  rm -rf "$PKGDIR"
  if tar -C /usr/local/lib/node_modules -xzf "$TARBALL"; then
    log "回滚解压完成"
  else
    log "!! 回滚解压失败，需人工介入"
  fi
  systemctl start "$SVC"
  sleep 10
  if systemctl is-active --quiet "$SVC"; then
    log "回滚后服务已恢复: $(systemctl show "$SVC" -p MainPID --value)"
    echo "ROLLED_BACK:version=$OLD_VER:$(ts)" >"$STATUS"
  else
    log "!! 回滚后服务仍未起来，需人工介入"
    echo "ROLLBACK_FAILED:$(ts)" >"$STATUS"
  fi
  log "===== 升级中止（已回滚） ====="
  exit 1
}

# ---------- 2. 停服务 ----------
log "停止 $SVC"
systemctl stop "$SVC"
sleep 2
systemctl is-active --quiet "$SVC" && { log "服务未停下"; rollback; }

# ---------- 3. npm 升级 ----------
# 必须放行 install scripts！npm 11 默认拦截，而 node-pty 在 Linux 上没有预编译包
# （prebuilds/ 只有 darwin/win32），build/Release/pty.node 是 postinstall 现编译的。
# 不放行则装完缺 pty.node，web-ui 终端功能直接坏（index.js 内 8 处引用 node-pty）。
log "npm install -g hermes-web-ui@$TARGET"
if ! npm install -g "hermes-web-ui@$TARGET" --no-fund --no-audit \
     --allow-scripts=agent-browser,node-pty,protobufjs,vue-demi; then
  log "FATAL: npm 安装失败"
  rollback
fi

NEW_VER=$(python3 -c "import json;print(json.load(open('$PKGDIR/package.json'))['version'])" 2>/dev/null || echo unknown)
log "升级后版本: $NEW_VER"
if [ "$NEW_VER" != "$TARGET" ]; then
  log "FATAL: 版本不符（期望 $TARGET，实际 $NEW_VER）"
  rollback
fi

# ---------- 3b. 原生模块产物硬校验 ----------
# 版本号对不代表装完整：install script 被拦时 package.json 一样是目标版本。
PTYNODE=$PKGDIR/node_modules/node-pty/build/Release/pty.node
if [ -f "$PTYNODE" ]; then
  log "node-pty 原生模块: OK ($(ls -lh "$PTYNODE" | awk '{print $5}'))"
else
  log "FATAL: 缺 node-pty/build/Release/pty.node（install script 未执行），终端会坏"
  rollback
fi

# ---------- 4. 重打审批补丁 ----------
# 判据只用 --check，不采信补丁脚本自身的退出码：
# 它末尾的提示文字曾在 systemd 下因 $HOME 未设置触发 set -u 报错，
# 导致「补丁其实打成功了」被误判为失败而白白回滚一次。
log "重打 Web UI 审批 request_id 补丁"
bash "$REPATCH" || log "补丁脚本返回非 0，改以 --check 为准"
if ! bash "$REPATCH" --check; then
  log "FATAL: 补丁校验未通过"
  rollback
fi
log "补丁校验: PASS"

# ---------- 5. 起服务 ----------
log "启动 $SVC"
systemctl start "$SVC" || { log "FATAL: 启动失败"; rollback; }

# ---------- 6. 等就绪（is-active 不等于能服务） ----------
READY=0
for i in $(seq 1 30); do
  sleep 2
  CODE=$(curl -s -o /dev/null -w '%{http_code}' --max-time 3 http://127.0.0.1:8648/ 2>/dev/null)
  if [ "$CODE" = "200" ]; then
    log "服务就绪（第 ${i} 次探测，HTTP 200）"
    READY=1
    break
  fi
done
[ "$READY" = "1" ] || { log "FATAL: 端口 8648 未就绪"; rollback; }

# ---------- 7. 最终核验 ----------
sleep 4
ACTIVE=$(systemctl is-active "$SVC")
MAINPID=$(systemctl show "$SVC" -p MainPID --value)
BRIDGES=$(pgrep -fc hermes_bridge.py 2>/dev/null || echo 0)
SHA=$(sha256sum "$BP" | cut -c1-16)
log "最终状态: active=$ACTIVE MainPID=$MAINPID bridge进程数=$BRIDGES 版本=$NEW_VER bridge_pool_sha=$SHA"
log "磁盘: $(df -h / | tail -1 | awk '{print $4" 可用, "$5" 已用"}')"
echo "OK:version=$NEW_VER:mainpid=$MAINPID:active=$ACTIVE:bridges=$BRIDGES:sha=$SHA:$(ts)" >"$STATUS"
log "===== 升级完成 ====="
