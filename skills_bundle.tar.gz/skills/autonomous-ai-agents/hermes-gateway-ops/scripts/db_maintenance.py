#!/usr/bin/env python3
"""
Hermes SQLite Database Health Check, WAL Checkpoint, and Backup Maintenance
Runs periodically (via cron/systemd) to prevent WAL bloat, b-tree page fragmentation,
and ensure zero-data-loss durability.
"""

import os
import sys
import sqlite3
import datetime
import logging
import re
from pathlib import Path

# Setup logging
HERMES_HOME = Path(os.environ.get("HERMES_HOME", Path.home() / ".hermes"))
LOG_DIR = HERMES_HOME / "logs"
LOG_DIR.mkdir(parents=True, exist_ok=True)
LOG_FILE = LOG_DIR / "db_maintenance.log"

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.FileHandler(LOG_FILE),
        logging.StreamHandler(sys.stdout),
    ],
)
logger = logging.getLogger("db_maintenance")

BACKUP_DIR = HERMES_HOME / "backups" / "daily"
BACKUP_DIR.mkdir(parents=True, exist_ok=True)

TARGET_DATABASES = [
    HERMES_HOME / "kanban.db",
    HERMES_HOME / "response_store.db",
    HERMES_HOME / "verification_evidence.db",
    HERMES_HOME / "cron" / "executions.db",
    HERMES_HOME / "cron" / "notepad.db",
]


def maintain_database(db_path: Path):
    state_db = HERMES_HOME / "state.db"
    if (db_path.name == "state.db" or db_path.resolve() == state_db.resolve()
            or (db_path.exists() and state_db.exists() and db_path.samefile(state_db))):
        logger.info("Skipping state.db: exclusively maintained by Hermes gateway")
        return True

    if not db_path.exists():
        logger.debug(f"Skipping non-existent DB: {db_path}")
        return True

    logger.info(f"--- Starting maintenance for {db_path.name} ---")
    conn = None
    backup_conn = None
    temporary_backup = None
    try:
        # 1. Connect with a generous timeout to gracefully wait out active writers
        conn = sqlite3.connect(str(db_path), timeout=15.0)
        conn.isolation_level = None

        # 2. Check integrity
        logger.info(f"Running integrity check on {db_path.name}...")
        cur = conn.cursor()
        cur.execute("PRAGMA integrity_check;")
        res = cur.fetchall()
        if len(res) == 1 and res[0][0] == "ok":
            logger.info(f"✓ Integrity check PASSED for {db_path.name}")
        else:
            logger.error(f"✗ Integrity check FAILED for {db_path.name}: {res}")
            conn.close()
            return False

        # Make and verify a recoverable snapshot before checkpoint/optimize.
        today_str = datetime.datetime.now().strftime("%Y%m%d")
        dest_backup_file = BACKUP_DIR / f"{db_path.stem}_{today_str}.db"
        temporary_backup = dest_backup_file.with_name(dest_backup_file.name + f".tmp.{os.getpid()}")
        backup_conn = sqlite3.connect(str(temporary_backup))
        conn.backup(backup_conn, pages=100)
        if backup_conn.execute("PRAGMA integrity_check").fetchall() != [("ok",)]:
            raise RuntimeError("Backup integrity check failed")
        backup_conn.close()
        backup_conn = None
        os.chmod(temporary_backup, 0o600)
        os.replace(temporary_backup, dest_backup_file)
        temporary_backup = None
        logger.info("Verified backup created: %s", dest_backup_file.name)

        # Only non-state databases may be maintained after a verified backup.
        cur.execute("PRAGMA wal_checkpoint(TRUNCATE)")
        ckpt_res = cur.fetchone()
        if ckpt_res[0] != 0:
            raise RuntimeError("Checkpoint busy; backup retained")
        cur.execute("PRAGMA optimize")

        conn.close()
        return True
    except Exception as e:
        logger.error(f"Error during maintenance of {db_path.name}: {e}", exc_info=True)
        return False
    finally:
        if backup_conn is not None:
            backup_conn.close()
        if conn is not None:
            conn.close()
        if temporary_backup is not None:
            try:
                temporary_backup.unlink(missing_ok=True)
            except OSError:
                logger.warning("Incomplete backup retained for inspection")


def prune_old_backups(days_to_keep=7, db_stems=None):
    if not db_stems:
        logger.info("No successful snapshot scope; skipping pruning")
        return
    cutoff = datetime.datetime.now().timestamp() - days_to_keep * 86400
    for stem in set(db_stems):
        pattern = re.compile(re.escape(stem) + r"_\d{8}\.db")
        files = [p for p in BACKUP_DIR.glob(stem + "_*.db")
                 if pattern.fullmatch(p.name) and not p.is_symlink()]
        if len(files) <= 1:
            continue
        keep = max(files, key=lambda p: (p.stat().st_mtime_ns, p.name))
        for file_path in files:
            if file_path == keep:
                continue
            try:
                if file_path.stat().st_mtime < cutoff:
                    file_path.unlink()
                    logger.info("Pruned expired backup: %s", file_path.name)
            except OSError as exc:
                logger.warning("Failed to prune %s: %s", file_path.name, exc)


def main():
    logger.info("=== Hermes SQLite Maintenance Run Started ===")
    all_ok = True
    existing = [db for db in TARGET_DATABASES if db.exists()]
    if not existing:
        logger.error("No configured databases exist; no snapshots, no pruning")
        return 1
    successful = []
    for db in existing:
        ok = maintain_database(db)
        if ok:
            successful.append(db.stem)
        else:
            all_ok = False
    if all_ok and successful:
        prune_old_backups(days_to_keep=7, db_stems=successful)
    else:
        logger.warning("Skipping backup pruning after maintenance failure")
    logger.info(f"=== Hermes SQLite Maintenance Run Finished (Status: {'SUCCESS' if all_ok else 'WITH WARNINGS'}) ===\n")
    return 0 if all_ok else 1


if __name__ == "__main__":
    sys.exit(main())
