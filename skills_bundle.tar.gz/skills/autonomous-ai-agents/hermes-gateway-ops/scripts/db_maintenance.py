#!/usr/bin/env python3
"""
Hermes SQLite Database Health Check, WAL Checkpoint, and Backup Maintenance
Runs periodically (via cron/systemd) to prevent WAL bloat, b-tree page fragmentation,
and ensure zero-data-loss durability.
"""

import os
import sys
import sqlite3
import datetime
import logging
from pathlib import Path

# Setup logging
LOG_DIR = Path("/home/ubuntu/.hermes/logs")
LOG_DIR.mkdir(parents=True, exist_ok=True)
LOG_FILE = LOG_DIR / "db_maintenance.log"

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.FileHandler(LOG_FILE),
        logging.StreamHandler(sys.stdout),
    ],
)
logger = logging.getLogger("db_maintenance")

HERMES_HOME = Path("/home/ubuntu/.hermes")
BACKUP_DIR = HERMES_HOME / "backups" / "daily"
BACKUP_DIR.mkdir(parents=True, exist_ok=True)

TARGET_DATABASES = [
    HERMES_HOME / "state.db",
    HERMES_HOME / "kanban.db",
    HERMES_HOME / "response_store.db",
    HERMES_HOME / "verification_evidence.db",
    HERMES_HOME / "cron" / "executions.db",
    HERMES_HOME / "cron" / "notepad.db",
]


def maintain_database(db_path: Path):
    if not db_path.exists():
        logger.debug(f"Skipping non-existent DB: {db_path}")
        return True

    logger.info(f"--- Starting maintenance for {db_path.name} ---")
    try:
        # 1. Connect with a generous timeout to gracefully wait out active writers
        conn = sqlite3.connect(str(db_path), timeout=15.0)
        conn.isolation_level = None

        # 2. Check integrity
        logger.info(f"Running integrity check on {db_path.name}...")
        cur = conn.cursor()
        cur.execute("PRAGMA integrity_check;")
        res = cur.fetchall()
        if len(res) == 1 and res[0][0] == "ok":
            logger.info(f"✓ Integrity check PASSED for {db_path.name}")
        else:
            logger.error(f"✗ Integrity check FAILED for {db_path.name}: {res}")
            conn.close()
            return False

        # 3. Safe FTS index maintenance if present (state.db)
        if db_path.name == "state.db":
            try:
                cur.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='messages_fts';")
                if cur.fetchone():
                    logger.info("Executing bounded FTS5 merge...")
                    cur.execute("INSERT INTO messages_fts(messages_fts) VALUES('merge=4');")
            except Exception as e:
                logger.warning(f"FTS merge notice: {e}")

        # 4. Truncate WAL (flush pages back to main DB and zero WAL size)
        logger.info(f"Running wal_checkpoint(TRUNCATE) on {db_path.name}...")
        cur.execute("PRAGMA wal_checkpoint(TRUNCATE);")
        ckpt_res = cur.fetchone()
        logger.info(f"✓ WAL checkpoint complete: busy={ckpt_res[0]}, log={ckpt_res[1]}, checkpointed={ckpt_res[2]}")

        # 5. Optimize query planner statistics
        cur.execute("PRAGMA optimize;")

        # 6. Atomic online backup via SQLite Backup API (never corrupts even if written during backup)
        today_str = datetime.datetime.now().strftime("%Y%m%d")
        dest_backup_file = BACKUP_DIR / f"{db_path.stem}_{today_str}.db"
        logger.info(f"Creating atomic online backup to {dest_backup_file.name}...")
        backup_conn = sqlite3.connect(str(dest_backup_file))
        conn.backup(backup_conn, pages=100)
        backup_conn.close()
        logger.info(f"✓ Backup created successfully: {dest_backup_file.name} ({dest_backup_file.stat().st_size} bytes)")

        conn.close()
        return True
    except Exception as e:
        logger.error(f"Error during maintenance of {db_path.name}: {e}", exc_info=True)
        return False


def prune_old_backups(days_to_keep=7):
    now = datetime.datetime.now().timestamp()
    cutoff = now - (days_to_keep * 86400)
    for f in BACKUP_DIR.glob("*.db"):
        try:
            if f.stat().st_mtime < cutoff:
                logger.info(f"Pruning expired backup: {f.name}")
                f.unlink()
        except Exception as e:
            logger.warning(f"Failed to delete {f.name}: {e}")


def main():
    logger.info("=== Hermes SQLite Maintenance Run Started ===")
    all_ok = True
    for db in TARGET_DATABASES:
        ok = maintain_database(db)
        if not ok:
            all_ok = False

    prune_old_backups(days_to_keep=7)
    logger.info(f"=== Hermes SQLite Maintenance Run Finished (Status: {'SUCCESS' if all_ok else 'WITH WARNINGS'}) ===\n")
    return 0 if all_ok else 1


if __name__ == "__main__":
    sys.exit(main())
