#!/usr/bin/env bash
set -euo pipefail
H="${HERMES_HOME:-$HOME/.hermes}"
SCRIPT_DIR="$(cd -- "$(dirname -- "$0")" && pwd)"
exec "$H/hermes-agent/venv/bin/python" "$SCRIPT_DIR/state_db_autoheal.py"
