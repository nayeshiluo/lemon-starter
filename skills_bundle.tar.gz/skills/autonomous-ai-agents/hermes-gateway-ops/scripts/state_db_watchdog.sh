#!/usr/bin/env bash
# state.db 健康监控包装: 强制使用 Hermes venv python3 (SQLite 3.53.1),
# 与 gateway 同版本, 避免系统 python3 (3.46.1) 跨版本打开 WAL 库——
# 否则监控脚本自己就变成"跨版本访问者", 重蹈 daily_cleanup.sh 覆辙。
# 健康 -> 无输出(静默); 异常 -> 输出告警(由 cron no_agent 原样投递)。
exec /home/ubuntu/.hermes/hermes-agent/venv/bin/python3 /home/ubuntu/.hermes/scripts/state_db_watchdog.py
