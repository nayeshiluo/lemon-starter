---
name: agentscope-qwenpaw-ops
description: 接入/部署 AgentScope·QwenPaw 智能体：托管平台能力边界、自建路线与页面核实。
version: 1.0.0
author: lemon
license: MIT
metadata:
  hermes:
    tags: [agentscope, qwenpaw, qwen, agent-platform, deploy, capability-boundary]
    related_skills: [hermes-custom-providers, computer-use, aws-ec2-ops]
---

# AgentScope / QwenPaw 接入与部署

## When to Use

- 爸爸发来 `platform.agentscope.io/deploy`、`qwenpaw.agentscope.io`、魔搭创空间、
  AgentScope Runtime sandbox 之类链接，问「你能连上/操控这个吗」「帮我部署一个千问 Agent」。
- 需要部署、迁移或排查 QwenPaw（千问个人助理）实例，判断某 Agent 平台是托管还是自建。
- 需要说清「哪些机器我能 SSH、哪些只能走 API、哪些只能在浏览器里点」这类能力边界。

核心是**先判定入口类型，再谈能不能操控**，不要一上来就说"可以"或"不行"。

## 第 0 步：先判定入口类型（决定后续一切）

| 入口形态 | 典型表现 | 我能做什么 |
|---|---|---|
| 托管 SaaS 网页控制台 | 注册登录 → 浏览器里对话/配置，无端口无 root | 只能读公开信息；要动手需登录态或 API 凭据 |
| 自建进程（pip/Docker/ECS） | `qwenpaw app` 监听 `127.0.0.1:8088` | shell 全权：改配置、装 Skill、看日志、定时任务 |
| Runtime 沙箱（API） | 云端沙箱 + SDK/HTTP 调用执行代码 | 按 API 调用，属"API 可控"，不是"机器可控" |

判定依据要来自实际读取（页面、文档、代码仓），不是印象。判定完再给结论。

## 平台事实（2026-10 核对，来源见 references/deploy-routes.md）

- `platform.agentscope.io/deploy` = **一键部署 QwenPaw**：注册即得隔离云端工作空间，
  Memory/Skills 持久化、免费 1GB 存储、重新部署自动恢复上次状态；入口是**浏览器 Web 控制台**，
  支持休眠/停止实例、两个实例合并（保留一个 deploymentId）、Skill 广场与 Plugin 广场一键装。
- 平台**不提供 SSH / root / 公网 shell**：机器在阿里云侧，属托管 SaaS。
- 自建四条主线：`pip install qwenpaw`、`curl -fsSL https://qwenpaw.agentscope.io/install.sh | bash`、
  Docker `agentscope/qwenpaw:latest`、阿里云 ECS 一键部署 / 魔搭创空间。

## 回答"你能操控吗"的标准结构

1. **结论先行**：明确是/不是一台可 SSH 的机器，一句话讲清。
2. **它到底是什么**：平台性质、入口形态、数据落点。
3. **能力边界**：能=SSH/HTTP API/MCP-SSE（且从本机可达、有凭据）；不能=登录第三方账号点网页、
   穿透托管宿主机。凭据只让爸爸私聊给，绝不落群聊/日志。
4. **三条可行路线**（API 直连 / 装到自己机器 / Runtime 沙箱），并给出推荐项及理由
   （要我真能接手运维，就装到自有机器或本机，别受平台休眠与配额限制）。
5. 末尾一句问清选哪条，别自行动手装东西。

## 自建部署要点（真能被我管的路径）

```bash
pip install qwenpaw          # Python >=3.11,<3.14
qwenpaw init --defaults      # 交互式则引导选模型/填 Key
qwenpaw app                  # Web 控制台 http://127.0.0.1:8088/
```

Docker 三卷必须挂，否则升级/重建即丢配置：
`/app/working`（配置/记忆/Skills）、`/app/working.secret`（模型 Key）、`/app/working.backups`（备份）。
控制台默认只绑 `127.0.0.1`；要对外须显式反代 + `QWENPAW_AUTH_ENABLED` 与用户名密码。

## SPA 页面核实技巧（web_extract 只返回标题时）

AgentScope 平台是 Vite SPA，`web_extract` 往往只拿到 `<title>`。不要据此说"页面打不开"，
按下面顺序取真实文案：

```bash
curl -sL https://platform.agentscope.io/deploy | grep -oE 'src="[^"]+"'          # 找前端 bundle
curl -sL <bundle_url> -o /tmp/asp.js
grep -oiE '.{60}(qwenpaw|deploy).{80}' /tmp/asp.js | head -25                     # 读 i18n 中文串
```

bundle 里的 i18n 文案（"一键部署 QwenPaw""注册即获隔离工作空间""免费 1 GB 配额"）就是产品行为的
一手证据，比二手博客可靠。只读、无副作用，随时可用。

## 坑

- 别把"一键部署"说成"给你一台机器"：托管实例没有 shell，说错会让爸爸白等一整套 SSH 方案。
- 别为了"证明能连"去猜平台账号密码；登录墙前停下来要凭据或要授权。
- Plugin 在 QwenPaw 进程内运行，含 monkey-patch 的插件装完要重启实例才生效；安装前先看安全扫描结论。
- 平台侧"休眠/停止"会中断任务，涉及定时任务时先确认实例状态再谈可靠性。
- 回答里区分"已验证事实（读到的原文/代码）"与"推断"，不要用产品宣传语替代能力边界。
