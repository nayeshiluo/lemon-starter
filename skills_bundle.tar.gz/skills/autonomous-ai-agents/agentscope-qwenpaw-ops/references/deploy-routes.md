# 部署路线与核对证据（2026-10-23 采样）

采样方式：`curl` 首页 HTML + 拉取前端 bundle `https://g.alicdn.com/yly287738/agentscope-platform-front/0.2.1/assets/index.js`
（881 KB）后 grep i18n 中文串；QwenPaw 安装细节取自 opendeep.wiki 的 QwenPaw 快速开始页
（该页转述 `pyproject.toml` / `docker-compose.yml` / `README_zh.md`）。
时间口径：北京时间 2026-10-23；平台处于公测，产品形态可能变化，结论以当时读到的原文为准。

## 1. platform.agentscope.io/deploy（托管）

bundle 内 i18n 原文（一手证据）：

- `deployBtn: "一键部署 QwenPaw"`、`deployBtnNotLoggedIn: "免费注册体验"`、`openQwenpaw: "打开 QwenPaw"`
- `quickDeploy.description: "注册即获隔离工作空间，所有配置都会保存，重新部署时自动恢复上次状态。"`
- `feature1: "注册即获隔离工作空间"`，`feature2: "Memory、Skills…"`（Skills/Memory 随实例持久化）
- 存储：`S3 兼容`、`免费 1 GB 配额`
- `mergeSelectQwenpawDesc: "检测到两个 QwenPaw 实例，请选择合并后保留的实例。"`（说明存在 deploymentId 维度、
  可休眠/停止实例、插件安装时提示"请先将 QwenPaw 实例休眠或停止，再重新启动以加载插件"）
- 生态：Skill 广场（一键安装到我的 QwenPaw）、Plugin 广场（进程内运行，装前有安全扫描）
- 平台自述：`"AgentScope Platform 是 AgentScope 生态的云端体验平台"`，统计位 `6K+ 社区 QwenPaw`

结论：**浏览器 Web 控制台形态的托管实例**，无 SSH 入口、无公网 shell；自动化只能走登录态浏览器或平台 API。

## 2. 自建路线（可被 shell 全权接管）

| 方式 | 命令/前提 | 备注 |
|---|---|---|
| pip | `pip install qwenpaw`；Python `>=3.11,<3.14` | `qwenpaw init --defaults` → `qwenpaw app` |
| 脚本 | `curl -fsSL https://qwenpaw.agentscope.io/install.sh \| bash` | 自动装 uv、Node.js；`--version` / `--from-source` |
| Docker | `docker run -p 127.0.0.1:8088:8088 ... agentscope/qwenpaw:latest` | 国内可用 ACR `agentscope-registry.ap-southeast-1.cr.aliyuncs.com/agentscope/qwenpaw` |
| ECS / 创空间 | 阿里云账号；创空间须设为非公开 | 仍是自有机器，可控 |

Docker 卷约定（`docker-compose.yml`）：
`qwenpaw-data → /app/working`（配置/记忆/Skills）、`qwenpaw-secrets → /app/working.secret`（模型 Key）、
`qwenpaw-backups → /app/working.backups`（备份）；`init: true`、`restart: always`；
认证靠 `QWENPAW_AUTH_ENABLED` + `QWENPAW_AUTH_USERNAME/PASSWORD`（compose 里是注释示例，默认不开）。

CLI 入口：`qwenpaw`（历史别名 `copaw`）、`qwenpawmail-mcp`；裸 `qwenpaw` 进 TUI，`qwenpaw .` 进 Coding 模式，
`qwenpaw uninstall [--purge]`（默认保留数据）。

## 3. AgentScope Runtime 沙箱

`runtime.agentscope.io/zh/api/sandbox.html` 记录多种沙箱类型（各自 Docker 镜像，含 redroid 等），
通过 SDK/HTTP 调用执行代码。可控层级是 **API 级**：能跑任务，但不等于能登进那台机器改系统。

## 4. 核实这类链接的通用手法

1. `web_extract` 只回标题 → 说明是 SPA，不是站点挂了。
2. `curl -sL <url> | grep -oE 'src="[^"]+"'` 找 bundle（常挂 CDN，如 `g.alicdn.com`）。
3. 拉 bundle 后 grep 业务词 + 前后各 60~80 字符，i18n 文案即产品行为的原文证据。
4. 需要功能级细节（卷挂载、端口、环境变量）再查官方 docs / 代码仓，别用二手博客下结论。
