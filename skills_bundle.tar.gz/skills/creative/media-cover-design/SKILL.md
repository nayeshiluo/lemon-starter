---
name: media-cover-design
description: "Use when designing media server covers, banners, posters."
version: 1.1.0
author: Lemon
license: MIT
metadata:
  hermes:
    tags: [media, cover-design, emby, plex, jellyfin, typography, pillow, streaming-ui, opencv-inpaint]
    related_skills: [apikey-image-gen, baoyu-infographic]
---

# Media Cover & Banner Design

## When to Use
Use this skill when creating or batch-generating streaming UI cards, media server folder covers (Emby, Jellyfin, Plex, Infuse, AList), or category banners.

## 1. Visual Hierarchy & Classification

To ensure an intuitive UI experience, clearly differentiate content categories by color palette, ambient lighting, and status badges:

### A. 🔞 18+ / Adult / Exclusive Categories
- **Aesthetic**: Deep midnight dark base, vivid neon magenta / hot pink / deep violet glow, luxury penthouse / champagne / night lounge vibes, moody bokeh.
- **Badge**: `🔞 18+ ADULTS ONLY • VIP` (Glowing Hot Rose `#F43F5E`).
- **Typography**: Rose-pink subtitle, crisp white/soft pink serif title.
- **Prompt Safety Guidelines**: AI image generation models reject explicit nudity, sexual actions, or anatomical keywords. Frame prompts using high-end atmospheric and editorial terminology:
  - ✅ **Safe**: "luxury penthouse nightlife", "glowing neon magenta lighting", "stylish elegant evening dress", "glamorous fashion model", "editorial portrait with ring light", "cinematic shallow depth of field".
  - ❌ **Unsafe**: explicit nude, erotic lingerie, seductive boudoir, uncensored anatomy.

### B. 🎬 Mainstream Cinema, Animation & TV Series
- **Aesthetic**: Theatrical sapphire blue, electric cyan, golden lens flares, 35mm film reels, projector light beams, IMAX grandeur, starry sky / fantasy landscapes for anime.
- **Badge**: `🎬 4K ULTRA HD • CINEMA` (Electric Sky Blue `#0EA5E9`).
- **Typography**: Cool slate-blue subtitle, crisp white title.

---

## 2. Text & Typography Post-Processing (Pillow)

Never rely exclusively on AI image generation for Chinese characters or crisp UI typography. Always generate the background illustration first, then apply typographic overlays with Python PIL:

```python
import os
from PIL import Image, ImageDraw, ImageFont

FONT_SANS = '/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc'
FONT_SERIF = '/usr/share/fonts/opentype/noto/NotoSerifCJK-Bold.ttc'

def overlay_cover_typography(raw_img_path, output_path, title_text, sub_text, is_adult=False):
    img = Image.open(raw_img_path).convert('RGBA')
    width, height = img.size

    # 1. Dark gradient vignette on bottom 40-50%
    overlay = Image.new('RGBA', (width, height), (0, 0, 0, 0))
    draw_ol = ImageDraw.Draw(overlay)
    start_y = int(height * 0.42)
    tint_rgb = (18, 5, 20) if is_adult else (8, 12, 22)
    
    for y in range(start_y, height):
        ratio = float(y - start_y) / float(height - start_y)
        alpha = int(220 * (ratio ** 1.5))
        draw_ol.line([(0, y), (width, y)], fill=(*tint_rgb, alpha))
    img = Image.alpha_composite(img, overlay)

    # 2. Typography fonts
    font_title = ImageFont.truetype(FONT_SERIF, 110, index=0)
    font_sub = ImageFont.truetype(FONT_SANS, 34, index=0)
    font_badge = ImageFont.truetype(FONT_SANS, 22, index=0)

    draw = ImageDraw.Draw(img)
    x = 100
    y_title = height - 240
    y_sub = y_title + 125
    y_badge = y_title - 45

    # 3. Badge
    badge_text = '🔞 18+ ADULTS ONLY • VIP' if is_adult else '🎬 4K ULTRA HD • CINEMA'
    badge_color = (244, 63, 94, 230) if is_adult else (14, 165, 233, 220)
    badge_bbox = draw.textbbox((0, 0), badge_text, font=font_badge)
    bw, bh = badge_bbox[2] - badge_bbox[0], badge_bbox[3] - badge_bbox[1]
    draw.rounded_rectangle([x, y_badge, x + bw + 24, y_badge + bh + 10], radius=6, fill=badge_color)
    draw.text((x + 12, y_badge + 4), badge_text, font=font_badge, fill=(255, 255, 255, 255))

    # 4. Title with drop shadow
    for offset in [(3, 3), (2, 2), (1, 1)]:
        draw.text((x + offset[0], y_title + offset[1]), title_text, font=font_title, fill=(0, 0, 0, 180))
    title_fill = (255, 240, 245, 255) if is_adult else (255, 255, 255, 255)
    draw.text((x, y_title), title_text, font=font_title, fill=title_fill)

    # 5. Subtitle
    sub_fill = (251, 182, 206, 240) if is_adult else (224, 231, 255, 230)
    draw.text((x + 2, y_sub + 2), sub_text, font=font_sub, fill=(0, 0, 0, 180))
    draw.text((x, y_sub), sub_text, font=font_sub, fill=sub_fill)

    img.convert('RGB').save(output_path, quality=95)
```

---

## 3. Removing AI Pseudo-Text & Inpainting Artifacts (OpenCV)

AI image models often generate unintended fictional titles, Japanese kanji, watermarks, or broadcast dates directly into anime/movie concept art. To remove these cleanly:

1. **Prompt Defense**: Always add:
   `"Completely textless background, zero text, no words, no letters, no Japanese/Chinese characters, no logos, no watermark."`
2. **OpenCV Inpainting Fallback**:
   When AI still embeds text artifacts, use Telea / Navier-Stokes inpainting on the bright text mask before overlaying typography:

```python
import cv2, numpy as np

def remove_text_artifacts(raw_img_path, cleaned_img_path, roi_boxes=None):
    img = cv2.imread(raw_img_path)
    h, w = img.shape[:2]
    mask = np.zeros((h, w), dtype=np.uint8)
    
    if not roi_boxes:
        roi_boxes = [(0.02, 0.03, 0.07, 0.5), (0.58, 0.48, 0.98, 0.75), (0.30, 0.88, 0.70, 0.99)]
    
    for (x1_pct, y1_pct, x2_pct, y2_pct) in roi_boxes:
        mask[int(h*y1_pct):int(h*y2_pct), int(w*x1_pct):int(w*x2_pct)] = 255
        
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    _, bright_mask = cv2.threshold(gray, 180, 255, cv2.THRESH_BINARY)
    kernel = np.ones((5, 5), np.uint8)
    final_mask = cv2.bitwise_and(mask, cv2.dilate(bright_mask, kernel, iterations=2))
    final_mask = cv2.dilate(final_mask, kernel, iterations=3)
    
    restored = cv2.inpaint(img, final_mask, 7, cv2.INPAINT_TELEA)
    cv2.imwrite(cleaned_img_path, restored)
```

---

## 4. Meme, Notice & Operational Banner Compositing (运维梗图与告示设计)

When creating community notice memes (e.g. storage full alerts, library rules, server maintenance warnings) using sticker pack assets or anime characters:

### A. Clean Asset Extraction vs Background Rebuild
- **Avoid Dirty Inpainting**: When a meme sticker has dense, outlined typography across the background (e.g. "我要入库 不要拦着我！"), simple inpainting/blurring leaves blurry streaks, artifact smears, and text ghosting.
- **Isolate Subjects**: Crop and isolate the character subject (using Chroma Key or alpha cutout).
- Rebuild High-Res Background: Reconstruct clean vector/gradient room or server backgrounds (e.g., beige studio gradient wall, wood plank floor, Emby rack with LED status lights). This guarantees zero artifact collision.
- Preserve Original Expressions & Dynamics (保留原汁原味神态张力): When referencing existing sticker pack characters (e.g. Wanwan Kirby pulling/screaming), strictly preserve the original artist's facial expressions, gritting teeth, sweat drops, and dramatic pulling momentum rather than replacing them with generic geometric shapes.
- Character Identity vs Visual Source: When the user assigns a name (e.g. C4) to a character while requesting another image's appearance (e.g. Shin-chan cutout), keep the visual identity of the source character intact and apply the name/dialogue tag cleanly.
- Natural Contour Masking: When compositing cutouts onto existing figures or backgrounds, avoid harsh horizontal straight-line cuts at the base. Apply soft organic contour masks or opacity gradients along body curves to blend seamlessly.

### B. 3D Anime Meme Typography (立体发光艺术字排版)
For grand comedic/warning impact, construct multi-layer layered typography:
1. **Drop Shadow**: `(0, 0, 0, 160)` offset `+6px` to `+14px` vertically.
2. **Outer Radiant Border**: Circle radius `8-9px` filled with Golden Yellow `(255, 190, 0, 255)` or Flaming Orange.
3. **Inner Contour**: Radius `4-5px` filled with Dark Crimson `(190, 25, 20, 255)`.
4. **Front Face**: Pure White `(255, 255, 255, 255)`.

### C. Speech Bubbles & Unicode Glyphs
- Use clean rounded rectangles with directional triangular pointers (beveled polygon).
- **Glyph Safety**: Never use arbitrary web emoji unicode directly in Pillow without verifying CJK font support; unmapped glyphs produce missing-box artifacts (`🖎 / □ / ☒`). Stick to standard symbols (`⚠️`, `🚫`, `•`, `🎬`) or draw vector badges directly.
- **Role Distinction**: Color-code character dialogs (e.g., Orange/Red outline for aggressive uploader, Cyan/Blue outline for desperate admin).

