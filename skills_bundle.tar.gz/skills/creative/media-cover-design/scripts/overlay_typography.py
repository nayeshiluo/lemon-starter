import os, sys
from PIL import Image, ImageDraw, ImageFont

FONT_SANS = '/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc'
FONT_SERIF = '/usr/share/fonts/opentype/noto/NotoSerifCJK-Bold.ttc'

def overlay_cover_typography(raw_img_path, output_path, title_text, sub_text, is_adult=False):
    img = Image.open(raw_img_path).convert('RGBA')
    width, height = img.size

    # 1. Dark gradient vignette on bottom 40-50%
    overlay = Image.new('RGBA', (width, height), (0, 0, 0, 0))
    draw_ol = ImageDraw.Draw(overlay)
    start_y = int(height * 0.42)
    tint_rgb = (18, 5, 20) if is_adult else (8, 12, 22)
    
    for y in range(start_y, height):
        ratio = float(y - start_y) / float(height - start_y)
        alpha = int(220 * (ratio ** 1.5))
        draw_ol.line([(0, y), (width, y)], fill=(*tint_rgb, alpha))
    img = Image.alpha_composite(img, overlay)

    # 2. Typography fonts
    font_title = ImageFont.truetype(FONT_SERIF, 110, index=0)
    font_sub = ImageFont.truetype(FONT_SANS, 34, index=0)
    font_badge = ImageFont.truetype(FONT_SANS, 22, index=0)

    draw = ImageDraw.Draw(img)
    x = 100
    y_title = height - 240
    y_sub = y_title + 125
    y_badge = y_title - 45

    # 3. Badge
    badge_text = '🔞 18+ ADULTS ONLY • VIP' if is_adult else '🎬 4K ULTRA HD • CINEMA'
    badge_color = (244, 63, 94, 230) if is_adult else (14, 165, 233, 220)
    badge_bbox = draw.textbbox((0, 0), badge_text, font=font_badge)
    bw, bh = badge_bbox[2] - badge_bbox[0], badge_bbox[3] - badge_bbox[1]
    draw.rounded_rectangle([x, y_badge, x + bw + 24, y_badge + bh + 10], radius=6, fill=badge_color)
    draw.text((x + 12, y_badge + 4), badge_text, font=font_badge, fill=(255, 255, 255, 255))

    # 4. Title with drop shadow
    for offset in [(3, 3), (2, 2), (1, 1)]:
        draw.text((x + offset[0], y_title + offset[1]), title_text, font=font_title, fill=(0, 0, 0, 180))
    title_fill = (255, 240, 245, 255) if is_adult else (255, 255, 255, 255)
    draw.text((x, y_title), title_text, font=font_title, fill=title_fill)

    # 5. Subtitle
    sub_fill = (251, 182, 206, 240) if is_adult else (224, 231, 255, 230)
    draw.text((x + 2, y_sub + 2), sub_text, font=font_sub, fill=(0, 0, 0, 180))
    draw.text((x, y_sub), sub_text, font=font_sub, fill=sub_fill)

    os.makedirs(os.path.dirname(os.path.abspath(output_path)), exist_ok=True)
    img.convert('RGB').save(output_path, quality=95)
    print(f"Generated: {output_path}")

if __name__ == '__main__':
    if len(sys.argv) < 5:
        print("Usage: python3 overlay_typography.py <raw_img> <output_path> <title> <subtitle> [--adult]")
        sys.exit(1)
    raw_img = sys.argv[1]
    out_img = sys.argv[2]
    title = sys.argv[3]
    sub = sys.argv[4]
    is_adult = len(sys.argv) > 5 and sys.argv[5] == '--adult'
    overlay_cover_typography(raw_img, out_img, title, sub, is_adult=is_adult)
