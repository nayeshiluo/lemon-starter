---
name: scanned-pdf-to-word
description: "扫描件 PDF→Word：视觉模型 OCR + 表格合并还原 + 页眉页脚。"
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [PDF, OCR, Word, docx, vision, scanned-documents, conversion]
    related_skills: [ocr-and-documents, docx, pdf]
---

# 扫描件 PDF → Word 转换（视觉模型 OCR）

## When to Use

- 用户发来**纯扫描件 PDF**（无文字层，整页是图片，常见于复印机/扫描仪产物如检测报告）要求"转成 Word"、"整理成 Word"。
- 用户要求保留**页眉页脚、表格结构、格式排版**。
- 用户抱怨上一版转换输出"只有文字，表格都没了"——说明需要表格合并还原的重做。

把**纯扫描件 PDF**（无文字层，整页是图片，常见于复印机/扫描仪产物如检测报告）
转换成**可编辑的 Word 文档**，保留页眉页脚、表格结构、段落顺序。

## 为什么不用本地 OCR 工具（实测结论）

| 方案 | 结果 |
|---|---|
| marker-pdf | 2GB 内存的机器上被 OOM 杀掉；首次运行还要下载 ~2.5GB 模型 |
| tesseract | 对密集表格完全不行：列错位、单元格粘连、文字乱序 |
| **视觉模型 API（推荐）** | 每页渲染成图喂给 gemini 等视觉模型，表格用 Markdown 还原，质量最高 |

## 工作流（已在 38 页检测报告上验证）

1. **确认扫描件**：`pymupdf` 打开，`page.get_text()` 为空 + 有整页图片 →
   无文字层。用非白像素采样判断页面是否空白（<1% 非白 = 扫描插页空白页，跳过）。
2. **渲染**：`pix = page.get_pixmap(matrix=pymupdf.Matrix(200/72, 200/72))`
   → PNG → base64。200 DPI 平衡质量与请求体积。
3. **调视觉模型**（OpenAI 兼容接口，如 frp3 的 `gemini-3-flash-preview`）：
   `data:image/png;base64,...` 作为 image_url。`max_tokens` 设 8192。
4. **提示词必须显式要求**：标准 Markdown 表格语法、表格所有行连续输出不得拆开、
   表头下有 `|---|---|` 分隔行、单元格内换行用 `<br>`、不加代码块围栏、不加解释。
   泛泛的"识别所有文字"会得到乱七八糟的输出。
5. **每页原始输出立即落盘** `md/page_NNN.md`——绝不放内存里等全部跑完再处理，
   网关重启/OOM 会清掉进程，30 分钟白跑。
6. **解析表格（最关键）**：行以 `|` **开头**即进入表格块（不要要求以 `|` 结尾，
   视觉模型的输出经常尾格不带 `|`，严格判断会把整行表格丢成普通文字段落）；
   连续 `|` 行**合并为一个表格**（跳过 `|---|` 分隔行），列数取 `max(len(r))`。
   ⚠️ 最大坑：把每个表格行单独建一个 1 行小表 → 输出 364 个碎片表，用户看到
   的就是"为什么只有文字"。必须合并成完整多行多列表格。
7. **组装 Word**（python-docx）：表格用 `Table Grid` 样式、9pt 字体；
   页眉页脚从正文剔除后，用 Word **原生页眉页脚**重建（`w:fldSimple` 的
   `PAGE`/`NUMPAGES` 域实现自动页码），不要嵌整页图片（除非用户明确要图像保真）。
8. **先测 1-2 页再全量**：视觉 OCR 约 40 秒/页，38 页要 25-30 分钟，
   后台跑 + `notify_on_complete`，先小规模验证 md 里表格结构正确再提交全量。

## 常见用户反馈 → 根因

- "为什么只有文字 / 表格呢" → 表格行被拆成独立 1 行小表，或 `|` 结尾判断
  太严把表格行丢进了段落。数据都在，重建解析即可，不需要重新 OCR。
- "页眉页脚都没了" → 页眉页脚行被当普通文字删掉了，需识别特征行
  （如"编号：XXX 第 X 页 共 Y 页"、"CEPREI/研究所"）单独做成 Word 原生页眉页脚。
- "图表呢" → 扫描件没有独立图表对象，图表是嵌在页面图里的；确认用户要的是
  可编辑文字还是图像保真（后者才嵌原图）。

## 交付前验证（必做）

组装完别直接发，先脚本验证再交付：

```bash
/home/ubuntu/.hermes/hermes-agent/venv/bin/python3 -c "
from docx import Document
doc = Document('out.docx')
print('段落:', len([p for p in doc.paragraphs if p.text.strip()]))
print('表格:', len(doc.tables))
for t in doc.tables[:3]:
    print(f'  {len(t.rows)}行x{len(t.columns)}列')
print('页眉:', doc.sections[0].header.paragraphs[0].text)
print('页脚:', doc.sections[0].footer.paragraphs[0].text)
"
```

验收标准：表格应是**少量多行大表**（36 个而非 364 个碎片）；页眉页脚是原生
header/footer 而非正文段落；页眉行已从正文剔除。Telegram 交付用
`MEDIA:/绝对路径/out.docx`。

## 进度汇报（用户中途问进度时）

- 给出已完成页数/百分比 + 已运行时长 + 剩余预估时间（~40s/页 × 剩余页数）
- 说明失败率（零失败要明说"零失败"）
- 用"后台跑着，完成自动通知"收尾，避免用户反复追问

## python-docx 踩坑

- **`run._element.rPr.rFonts` 可能为 None**：只有先设 `run.font.name = 'X'`
  （setter 会创建 rFonts 元素）或调 `get_or_add_rFonts()` 才存在。直接
  `rPr.rFonts.set(...)` 报 `AttributeError: 'NoneType' object has no attribute 'set'`。
  凡是给 run 设 eastAsia 字体，先写 `run.font.name = 'Calibri'` 再 `rFonts.set(...)`。
- 页面空行判断：`pix.samples` 非白采样比例 <1% 视为空白插页，跳过不 OCR。

## 脚本

- `scripts/ocr_vision_to_word.py` — 完整流水线：渲染 → 视觉 OCR → md 落盘 →
  表格合并解析 → Word 组装（含原生页眉页脚/自动页码）。复制后改 PDF 路径、
  API 地址/key/模型、页眉页脚文案即可用。先 `--pages 2,3` 测试再全量。

## 关联

- 文字层 PDF 提取 → `ocr-and-documents`（marker-pdf/pymupdf）
- Word 生成/编辑细节 → `docx` 技能
- PDF 页面导出 PNG → `pdf` 技能 `pdf_page_image.py`
