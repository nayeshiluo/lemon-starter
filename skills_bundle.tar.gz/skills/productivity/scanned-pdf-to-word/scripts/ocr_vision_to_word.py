#!/usr/bin/env python3
"""扫描件 PDF → Word 完整流水线（视觉模型 OCR + 表格合并还原 + 原生页眉页脚）。

实测验证：38 页检测报告扫描件，gemini 视觉模型 ~40s/页，表格完整还原。
用法（先小规模测试再全量）：
  export VISION_API_KEY=xxx
  python ocr_vision_to_word.py 输入.pdf --out out.docx \
      --api-base http://host:port/v1 --model gemini-3-flash-preview \
      --pages 2,3          # 只测指定页(1-based, 逗号分隔)，仅 OCR 不组装
  python ocr_vision_to_word.py 输入.pdf --out out.docx \
      --api-base http://host:port/v1 --model gemini-3-flash-preview \
      --header "编号：MEA233718 第  页 共  页" \
      --footer "CEPREI 工业和信息化部电子第五研究所 元器件检测中心"
依赖：pip install pymupdf python-docx
"""
import argparse, base64, json, os, re, sys, time, urllib.request

import pymupdf
from docx import Document
from docx.shared import Pt
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

OCR_PROMPT = """请完整识别这张扫描件上的所有内容，严格按以下要求输出：
1. 页眉、页脚、标题单独用一行写出（不加特殊标记）。
2. 正文内容按原文顺序输出。
3. 【最重要】表格必须用标准 Markdown 表格完整还原：
   - 每个表格用完整的 | 行表示，表头下面必须有 |---|---| 分隔行
   - 表格的所有行必须连续输出，不得拆开、不得省略任何一行
   - 单元格内容含换行时用 <br> 表示
4. 只输出识别到的内容，不要任何解释、不要代码块围栏。"""


def ocr_page(api_base, api_key, model, image_b64):
    payload = {
        "model": model,
        "messages": [{
            "role": "user",
            "content": [
                {"type": "text", "text": OCR_PROMPT},
                {"type": "image_url", "image_url": {"url": f"data:image/png;base64,{image_b64}"}},
            ],
        }],
        "max_tokens": 8192,
    }
    req = urllib.request.Request(
        api_base.rstrip("/") + "/chat/completions",
        data=json.dumps(payload).encode(),
        headers={"Content-Type": "application/json", "Authorization": f"Bearer {api_key}"},
    )
    for attempt in range(3):
        try:
            with urllib.request.urlopen(req, timeout=180) as resp:
                data = json.loads(resp.read().decode())
            return data["choices"][0]["message"]["content"]
        except Exception as e:
            if attempt < 2:
                time.sleep(5)
                continue
            return f"[识别失败: {e}]"


def is_table_line(line):
    """宽松判断：以 | 开头且后面还有 | 即可（不要求结尾 |，模型常省略尾格）"""
    return line.startswith("|") and "|" in line[1:]


def parse_markdown_table(lines, i):
    """从 lines[i] 开始收集连续 | 行，合并为一个表格。返回 (rows, next_i)"""
    rows = []
    while i < len(lines):
        line = lines[i].strip()
        if not is_table_line(line):
            break
        cells = [c.strip() for c in line.split("|")[1:]]
        if line.endswith("|"):
            cells = cells[:-1]  # 去掉末尾空元素
        # 跳过分隔行 |---|---|
        if cells and all(re.fullmatch(r":?-{2,}:?", c.replace(" ", "")) for c in cells):
            i += 1
            continue
        rows.append(cells)
        i += 1
    return rows, i


def markdown_to_word(md_text, word):
    """解析一页 md：表格合并为完整多行表，其余为段落。"""
    lines = md_text.split("\n")
    i = 0
    while i < len(lines):
        line = lines[i].strip()
        if not line:
            i += 1
            continue
        if is_table_line(line):
            rows, i = parse_markdown_table(lines, i)
            cleaned = [r for r in rows if any(c.strip() for c in r)]
            if not cleaned:
                continue
            ncols = max(len(r) for r in cleaned)
            table = word.add_table(rows=len(cleaned), cols=ncols)
            table.style = "Table Grid"
            for ri, row in enumerate(cleaned):
                for ci in range(min(len(row), ncols)):
                    text = row[ci].replace("<br>", "\n")
                    table.rows[ri].cells[ci].text = text
                    for p in table.rows[ri].cells[ci].paragraphs:
                        for run in p.runs:
                            run.font.size = Pt(9)
                            run.font.name = "Calibri"
                            run._element.rPr.rFonts.set(qn("w:eastAsia"), "宋体")
        else:
            text = re.sub(r"^#+\s*", "", line)  # 去掉 md 标题符号
            p = word.add_paragraph(text)
            p.paragraph_format.space_after = Pt(4)
            for run in p.runs:
                run.font.size = Pt(10.5)
                run.font.name = "Calibri"
                run._element.rPr.rFonts.set(qn("w:eastAsia"), "宋体")
        i += 1


def add_field_run(paragraph, instr, placeholder="1"):
    """插入 Word 域代码（PAGE/NUMPAGES），打开文档时自动计算。"""
    fld = OxmlElement("w:fldSimple")
    fld.set(qn("w:instr"), f" {instr} ")
    r = OxmlElement("w:r")
    rPr = OxmlElement("w:rPr")
    sz = OxmlElement("w:sz"); sz.set(qn("w:val"), "18")
    rPr.append(sz)
    r.append(rPr)
    t = OxmlElement("w:t"); t.text = placeholder
    r.append(t)
    fld.append(r)
    paragraph._p.append(fld)


def setup_header_footer(word, header_text, footer_text):
    """Word 原生页眉页脚；页眉文案中的 {PAGE}/{NUMPAGES} 自动替换为域。"""
    section = word.sections[0]
    if header_text:
        hp = section.header.paragraphs[0]
        hp.alignment = 1  # CENTER
        parts = re.split(r"(\{PAGE\}|\{NUMPAGES\})", header_text)
        for part in parts:
            if part == "{PAGE}":
                add_field_run(hp, "PAGE")
            elif part == "{NUMPAGES}":
                add_field_run(hp, "NUMPAGES", "36")
            elif part:
                r = hp.add_run(part)
                r.font.size = Pt(9)
    if footer_text:
        fp = section.footer.paragraphs[0]
        fp.alignment = 1
        fr = fp.add_run(footer_text)
        fr.font.size = Pt(9)
        # ⚠️ 必须先设 font.name（创建 rFonts 元素），否则 rPr.rFonts 为 None 会 AttributeError
        fr.font.name = "Calibri"
        fr._element.rPr.rFonts.set(qn("w:eastAsia"), "宋体")


def blank_page_ratio(pix):
    """非白像素采样比例，<1% 视为空白插页。"""
    samples = pix.samples
    total = len(samples)
    step = max(1, total // 3000)
    nonwhite = sum(1 for j in range(0, total, step) if samples[j] < 245)
    return nonwhite / (total // step)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("pdf")
    ap.add_argument("--out", default="out.docx")
    ap.add_argument("--api-base", required=True)
    ap.add_argument("--model", default="gemini-3-flash-preview")
    ap.add_argument("--api-key", default=os.environ.get("VISION_API_KEY", ""))
    ap.add_argument("--pages", default="", help="只处理指定页(1-based,逗号分隔)，仅 OCR 落盘")
    ap.add_argument("--md-dir", default="md")
    ap.add_argument("--header", default="")
    ap.add_argument("--footer", default="")
    args = ap.parse_args()

    os.makedirs(args.md_dir, exist_ok=True)
    doc = pymupdf.open(args.pdf)
    total = doc.page_count

    if args.pages:
        pages = [int(p) for p in args.pages.split(",") if p.strip()]
        for p in pages:
            page = doc[p - 1]
            pix = page.get_pixmap(matrix=pymupdf.Matrix(200 / 72, 200 / 72))
            b64 = base64.b64encode(pix.tobytes("png")).decode()
            print(f"第{p}/{total}页 OCR...", end=" ", flush=True)
            text = ocr_page(args.api_base, args.api_key, args.model, b64)
            with open(os.path.join(args.md_dir, f"page_{p:03d}.md"), "w", encoding="utf-8") as f:
                f.write(text)
            print("完成", flush=True)
        print("测试页 OCR 完成，检查 md 目录确认表格结构后全量重跑（不带 --pages）")
        return

    word = Document()
    style = word.styles["Normal"]
    style.font.name = "Calibri"
    style.font.size = Pt(10.5)
    style._element.rPr.rFonts.set(qn("w:eastAsia"), "宋体")
    setup_header_footer(word, args.header, args.footer)

    for i in range(total):
        page = doc[i]
        pix = page.get_pixmap(matrix=pymupdf.Matrix(200 / 72, 200 / 72))
        if blank_page_ratio(pix) < 0.01:
            print(f"第{i+1}页：空白插页，跳过")
            continue
        b64 = base64.b64encode(pix.tobytes("png")).decode()
        print(f"第{i+1}/{total}页 OCR...", end=" ", flush=True)
        text = ocr_page(args.api_base, args.api_key, args.model, b64)
        with open(os.path.join(args.md_dir, f"page_{i+1:03d}.md"), "w", encoding="utf-8") as f:
            f.write(text)
        print("完成", flush=True)
        markdown_to_word(text, word)
        if i < total - 1:
            word.add_page_break()

    word.save(args.out)
    print(f"✅ 已保存: {args.out}  段落{len([p for p in word.paragraphs if p.text.strip()])} 表格{len(word.tables)}")


if __name__ == "__main__":
    main()
