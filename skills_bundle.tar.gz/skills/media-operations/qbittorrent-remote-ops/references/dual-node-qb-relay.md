# 双节点 qB 下载 + 回传接力：实现细节（lemon-ops-bot，2026-10）

本文件记录一次真实落地的细节，供同类改造参考。**通用原则见 SKILL.md，这里只记具体位置和数字。**

## 拓扑

```
[InstaBox 沙箱]                          [vps-la <PRIVATE_IDENTIFIER>]
 qBittorrent 5.1.0  127.0.0.1:8999         qBittorrent 4.6.3  127.0.0.1:8999
   ↓ 下载 /data/downloads                    ↓ 下载 /home/ubuntu/Downloads
   ↓ rsync (qbupload 用户, rrsync 锁目录)     ↑ /srv/qbupload 中继
   └────────────── 4.5 MB/s ────────────────┘
                                            ↓ /root/emos_uploader.py（token 只在 vps-la）
                                            ↓ EMOS / R2

[AWS Bot 主机]
 qb_client.py ─ 隧道 18998 → 沙箱 8999
              └ 隧道 18999 → vps-la 8999
```

关键：**EMOS token 不下发到第三方平台**。沙箱只负责下载，回传后由 vps-la 接力上传。

## 代码落点（lemon-ops-bot）

| 文件 | 改动 |
|---|---|
| `qb_client.py` | `NODES` 元数据表、`normalize_node`/`node_conf`/`node_label`/`is_remote_node`、`SafeSession(node)`、`_load_credentials(path)`、`get_qb_session(node)` 按节点分缓存、`add_paused_param`/`resume_path`/`pause_path` |
| `emos_service.py` | `fetch_from_sandbox()`、`cleanup_relay()`、`run_pipeline(..., node=)`、`emos:node:` 回调、两处 `run_pipeline` 调用带 `node`、种子入口 `USER_PENDING_TORRENTS[t_key]["node"] = DEFAULT_NODE` |
| `emos_module.py` | `get_torrent_main_flow_keyboard(t_key, node="la")` 首行加节点选择按钮 |

`run_pipeline` 体内统一用局部别名，避免漏改：

```python
node = normalize_node(node)
qbs  = lambda: get_qb_session(node)
qapi = node_conf(node)["api"]
node_remote = is_remote_node(node)
```

然后整段把 `get_qb_session()` → `qbs()`、`{QB_API}` → `{qapi}`（本次 11 处）。

## TG 交互设计

回调 `emos:node:<node>:<t_key>`，点了不启动任务，只改 `task["node"]` 并重绘键盘（选中项打 `✅`）。

```
✅ 🇺🇸 洛杉矶 VPS  |  📦 InstaBox 沙箱     ← 第一行，默认 la
🌱 纯做种
🚀 纯上传
🔄 双重模式
❌ 取消任务
```

好处：节点是**流程的前置状态**，不是流程的一个分支，所以不用改 `emos:flow:` 和 `emos:run:` 的回调格式。

## 回传实现要点

```python
relay_name = f"{int(time.time())}_{name}"     # 加时间戳，避免同名覆盖
rsync -a --partial --inplace -e "ssh -i ~/.ssh/id_qbupload -o BatchMode=yes" \
      <sandbox_path> qbupload@<vps>:/srv/qbupload/<relay_name>
```

由 AWS 主机 `ssh <sandbox-alias> "<rsync 命令>"` 发起——文件在沙箱本地，rsync 必须在沙箱侧跑。

上传成功后 `cleanup_relay()` 异步删 vps-la 副本。

## 本次实测数字

| 项 | 值 |
|---|---|
| 沙箱 BT 下载 | 756MB / 40s，峰值 33.6 MB/s，800+ peers |
| 沙箱 → vps-la | 477MB / 106s（4.5 MB/s）；20MB / 5.9s（3.4 MB/s） |
| 全流程 | 477MB，100 秒（下载+回传+上传+清理） |
| 越界防护 | `../../etc/evil.bin` → `rrsync error: do not use .. in arg` |
| 流量归属 | vps-la 24 天 RX 240.19GB / TX 178.24GB；沙箱 1.2 天 RX 28.78GB / TX 0.25GB |

## 踩过的坑

1. **qB 5.1.0 端点改名** → resume 404、paused 参数被丢，任务卡 `stoppedUP` 且无报错。详见 SKILL.md 第二节。
2. **沙箱没有 rsync** → 首次回传测试 `rsync: command not found`，`apt install rsync` 后正常（3.5.0）。
3. **`patch` 工具写 f-string 时 `\n` 变 `\\n`** → 落盘成字面量，Telegram 消息里显示 `\n`。用 `sed -n` 或 `cat -A` 复核，写小脚本按行范围 `replace(r"\\n", r"\n")` 修。
4. **中文文件名** → 用 glob 定位（`glob.glob("/tmp/emos_torrents/*<YOUR_USER_IDENTIFIER>*.torrent")`），不要手抄路径。
5. **Bot 不打日志** → 靠 sshd 日志 + 中继目录 mtime + qb journal 三角定位（见 SKILL.md 第七节）。
6. **`paused=true` 被忽略导致种子立即开下** → 如果按"先暂停再选文件优先级"的假设写逻辑，实际文件已经在下了，进度轮询会瞬间 100%，看起来像"跳过了下载"。

## 幂等语义

`emos_uploader.py` 退出码契约：

- `0` + stdout `SUCCESS!` → 真上传成功
- `3` + stdout `DUPLICATE!` → 一周内已传过，**幂等跳过，不是失败**
- 其他 → 真失败，抛异常保留本地文件

**判断某次是否真入库，不能只看平台搜索结果**：EMOS 的 `/api/video/search?title=` 对未建档/未公开条目返回 0 命中，但上传接口仍会返回 DUPLICATE。以 DUPLICATE/SUCCESS 回执为准，别拿搜索结果反推失败。
