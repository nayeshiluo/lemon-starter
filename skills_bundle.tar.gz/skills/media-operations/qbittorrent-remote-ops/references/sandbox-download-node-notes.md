# 沙箱类下载节点的能力边界（2026-10 实测）

把云沙箱当 qBittorrent 次节点之前，先确认这几条。数据来自 InstaBox 免费档实测，
但同类"托管沙箱"平台大概率同构，可作为排查起点，**结论要用当次实测复核**。

---

## 一、入站端口只有 HTTP(S) 反代，不是裸 TCP

平台 OpenAPI 原文：`Give one HTTP port of a sandbox a public URL`。
沙箱本身在内网（如 `<YOUR_SERVER_IP>/30`），没有公网入站。

| 协议 | 能否穿透 | 说明 |
|---|---|---|
| WebSocket（VLESS/VMess/Trojan over WS） | ✅ | HTTP/1.1 升级返回 `101` |
| 普通 HTTP 服务（含 qb WebUI） | ✅ | 反代到沙箱端口 |
| SOCKS5 / MTProto / Reality / Shadowsocks | ❌ | 裸 TCP 或自有 TLS，反代层无法转发 |

**HTTP/2 会 502**：同一 WS 升级请求走 h2 返回 `502 The sandbox service disconnected or is unavailable`，
必须强制 HTTP/1.1。客户端传输层要显式指定。

推论：**qb WebUI 可以走公开端口**，但公开端口任何人可访问，务必配强密码；
更稳的做法仍是 SSH 隧道（端口只在本机回环）。

## 二、内核能力：BBR 通常开不了

InstaBox 定制内核（`6.18.54-instabox`）实测：

```
tcp_congestion_control           = cubic
tcp_available_congestion_control = reno cubic      # 没有 bbr
```

三步证据链（照抄可复现）：

1. 可用算法列表无 `bbr`
2. `echo bbr > /proc/sys/net/ipv4/tcp_congestion_control` → `I/O error`；
   写同值 `cubic` → 返回 0（**证明 `/proc/sys` 可写，纯粹算法不存在**）
3. 无 `/lib/modules`、无 `modprobe`、无 `/boot/config-*` → 容器环境，加载不了模块

没有 `sysctl` 二进制时直接读 `/proc/sys/...` 文件取值，别卡在 command not found。

**即使能开，对反代型节点收益也有限**：客户端到平台边缘那一跳的 TCP 不归你控，
你只能影响沙箱出向那一段，而那通常不是瓶颈。

## 三、免费档的两道硬限制

| 限制 | 能否绕过 |
|---|---|
| 闲置暂停（约 30 分钟） | ✅ 制造活动即可（lease / SSH 触碰） |
| 连续运行上限（约 8 小时） | ❌ 仅 admin 可改，到点强制暂停 + 冷却约 10 分钟 |

暂停保留内存，所以节点 URL 在暂停期返回 `503`，恢复后自动可用。

## 四、判定"是否被暂停过"——uptime 会骗人

| 信号 | 硬重启 | 暂停/恢复 |
|---|---|---|
| `boot_id` | 变 | 不变 |
| uptime | 归零 | 继续走 |
| 平台 API `runStartedAt` | 刷新 | **刷新**（每次 resume 重置计时） |
| `ps -o lstart` vs systemd `ActiveEnterTimestamp` | 一致 | **出现偏差** |

判据：`runStartedAt` 比 uptime 起点新很多 + `ps lstart` 与 systemd 启动时间对不上
→ 暂停恢复过，不是崩溃。再用 `NRestarts=0` 排除服务级异常重启。
`runStartedAt + maxRunMinutes` 就是下次强制暂停的时刻，可直接预告用户。

## 五、环境自带什么、缺什么

- `sudo` 免密可用（用户在 sudo 组），apt 装包、写 `/data` 都行
- `/data` 根目录归 root，建子目录要 `sudo mkdir` + `chown`
- `/dev/fuse` 存在（FUSE 可用），但 `fuse3` / `sshfs` / `rsync` 默认都没装
- 系统盘通常 16G 左右，数据盘 `/data` 约 20G —— **一部 4K 就吃掉一半，不适合大文件主力**
- 上行带宽常被总带宽限速（实测约 9.5MB/s 量级），适合小文件批量与预处理，不适合整片搬运

## 六、选型结论（写给决策用）

沙箱适合：短剧、单集、小体积资源、临时溢出、预处理（抽帧/探测/转码测试）。
沙箱不适合：常驻主力节点、大文件长期做种、需要 8 小时以上不中断的上传任务。
