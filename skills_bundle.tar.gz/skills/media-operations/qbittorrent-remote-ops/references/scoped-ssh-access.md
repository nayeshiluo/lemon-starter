# 受限 SSH 访问通道（只读浏览 / 只写回传）

给沙箱或第三方机器开放另一台主机上的目录时，用这两种模式替代直接给主账号 sftp。
2026-10-24 在 Debian 13 / OpenSSH 环境下实测通过。

---

## 第一节：只读浏览（chroot + sftp）

目标：对端登录后**只能看到并读取一个目录**，删不了、改不了、碰不到别处。

### 1. 建专用用户与 chroot 根

```bash
SRC=/home/ubuntu/Downloads      # 要暴露的源目录
CHROOT=/srv/qbmount

useradd -r -M -d $CHROOT -s /usr/sbin/nologin qbmount
mkdir -p $CHROOT/downloads
chown root:root $CHROOT
chmod 755 $CHROOT               # chroot 根必须 root 拥有且不可写，否则 sshd 拒绝登录
```

### 2. 只读 bind mount（并持久化）

```bash
mount --bind $SRC $CHROOT/downloads
mount -o remount,ro,bind $CHROOT/downloads
echo "$SRC $CHROOT/downloads none bind,ro 0 0" >> /etc/fstab
systemctl daemon-reload
# 验证 systemd 已识别（应出现 srv-qbmount-downloads.mount / active mounted）
systemctl list-units --type=mount --all --no-legend | grep -i qbmount
```

`mount --bind -o ro` 一条命令不会真的只读，必须 `--bind` 后再 `remount,ro,bind`，或用 fstab 的 `bind,ro`。

### 3. authorized_keys 放 chroot 外部

**不要把 `.ssh` 放进 chroot 内部**——会踩 `StrictModes` 与 `Match` 块冲突。放到 root 拥有的独立路径：

```bash
install -d -m 755 -o root -g root /etc/ssh/keys
printf 'command="internal-sftp",restrict %s\n' "$PUBKEY" > /etc/ssh/keys/qbmount
chown root:root /etc/ssh/keys/qbmount
chmod 644 /etc/ssh/keys/qbmount
```

### 4. sshd Match 块

```bash
cat > /etc/ssh/sshd_config.d/99-qbmount.conf <<'EOF'
Match User qbmount
    ChrootDirectory /srv/qbmount
    ForceCommand internal-sftp
    AuthorizedKeysFile /etc/ssh/keys/qbmount
    AllowTcpForwarding no
    AllowAgentForwarding no
    PermitTunnel no
    X11Forwarding no
    PermitTTY no
EOF
sshd -t && systemctl reload ssh     # 用 reload，不要 restart
```

`restrict` 已含 no-pty/no-forwarding/no-user-rc，再加 Match 里的显式项是双保险。
**`StrictModes no` 写进 Match 块会导致 `sshd -t` 失败**（`Directive 'StrictModes' is not allowed within a Match block`），别试。

### 5. 对端挂载

```bash
sshfs qbmount@HOST:/downloads /data/mnt/qb \
  -o IdentityFile=~/.ssh/id_qbmount \
  -o ro \
  -o reconnect,ServerAliveInterval=15,ServerAliveCountMax=3 \
  -o BatchMode=yes -o StrictHostKeyChecking=accept-new
```

- 单人使用**不要加 `allow_other`**，默认会被拒（需 `/etc/fuse.conf` 里 `user_allow_other`），去掉即可
- 实测单流读取约 `8.3 MB/s`（加密 + 对端上行共同限制），浏览/抽帧够用，整片搬运改用 `rsync`

### 6. 验收

```bash
mountpoint /data/mnt/qb                       # is a mountpoint
ls -la /data/mnt/qb                           # 能看到内容
touch /data/mnt/qb/__write_test               # 必须失败：Read-only file system
```

`touch` 报 `Read-only file system` 才是只读生效。**别写反判断逻辑**——`touch` 失败代表只读成功。

---

## 第二节：只写回传（rrsync）

目标：对端只能往一个目录推文件，不能读别处、不能越界、不能拿 shell。

### 1. 用户与目录

```bash
DIR=/srv/qbupload
useradd -r -m -d /home/qbupload -s /bin/bash qbupload   # rsync 需要 shell，不能 nologin
mkdir -p $DIR
chown qbupload:qbupload $DIR
chmod 750 $DIR
```

`rrsync` 需要能执行命令，所以这里不能用 `internal-sftp` + `nologin` 组合。

### 2. 密钥限定目录

```bash
printf 'command="/usr/bin/rrsync -wo %s",restrict %s\n' "$DIR" "$PUBKEY" > /etc/ssh/keys/qbupload
chown root:root /etc/ssh/keys/qbupload && chmod 644 /etc/ssh/keys/qbupload
```

- `-wo` = write only，锁定写目标到 `$DIR`
- `rrsync` 路径：Ubuntu 在 `/usr/bin/rrsync`（rsync 包自带）

### 3. Match 块

```bash
cat > /etc/ssh/sshd_config.d/99-qbupload.conf <<'EOF'
Match User qbupload
    AuthorizedKeysFile /etc/ssh/keys/qbupload
    AllowTcpForwarding no
    AllowAgentForwarding no
    PermitTunnel no
    X11Forwarding no
    PermitTTY no
    PasswordAuthentication no
EOF
sshd -t && systemctl reload ssh
```

### 4. 对端推送与越界测试

```bash
rsync -avz -e "ssh -i ~/.ssh/id_qbupload -o BatchMode=yes" \
  /data/downloads/x.mkv qbupload@HOST:x.mkv

# 越界必须被拒（期望 rrsync error: do not use .. in arg）
rsync -avz -e "ssh -i ~/.ssh/id_qbupload -o BatchMode=yes" \
  /data/downloads/x.mkv qbupload@HOST:../../etc/evil.bin
```

验收两点：文件确实落在 `$DIR`；`/etc/evil.bin` 不存在。

---

## 第三节：改 sshd 的安全流程

1. `cp /etc/ssh/sshd_config /root/<name>-backup-$(date +%Y%m%d-%H%M%S)/`
2. 写 `sshd_config.d/99-*.conf`（新文件，不动主配置）
3. `sshd -t` 必须通过再 reload
4. `systemctl reload ssh`（**不是 restart**，restart 会掐断当前会话）
5. reload 后复查**既有通道**仍在（例如已存在的只读 bind mount、其他用户的 key）

## 回滚

```bash
rm /etc/ssh/sshd_config.d/99-<name>.conf && systemctl reload ssh
sed -i '/<name>/d' /etc/fstab && umount /srv/<name> 2>/dev/null
userdel <name>; rm -rf /etc/ssh/keys/<name>
```
