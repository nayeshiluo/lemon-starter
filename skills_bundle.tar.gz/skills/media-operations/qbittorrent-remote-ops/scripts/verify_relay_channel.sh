#!/bin/bash
# 回传通道自检：验证受限 rrsync 通道「能写、且只能写指定目录」
#
# 用法（在发起方机器上跑，例如沙箱或跳板机）：
#   bash verify_relay_channel.sh <ssh别名或 user@host> <本地密钥> <远端目标目录>
# 例：
#   bash verify_relay_channel.sh <PRIVATE_IDENTIFIER> ~/.ssh/id_qbupload /srv/qbupload
#
# 退出码：0 全通过；1 有检查失败

set -u
TARGET="${1:?需要目标 user@host 或 IP}"
KEY="${2:?需要私钥路径}"
REMOTE_DIR="${3:-/srv/qbupload}"
SIZE_MB="${SIZE_MB:-20}"

TMP=$(mktemp -d)
trap 'rm -rf "$TMP"' EXIT
SSH="ssh -i $KEY -o BatchMode=yes -o StrictHostKeyChecking=accept-new -o ConnectTimeout=15"
FAIL=0

echo "=== 目标: $TARGET:$REMOTE_DIR | 测试体积: ${SIZE_MB}MB ==="

echo
echo "[1/4] 生成测试文件"
head -c $((SIZE_MB * 1000000)) /dev/urandom > "$TMP/probe.bin"
LOCAL_MD5=$(md5sum "$TMP/probe.bin" | awk '{print $1}')
echo "  本地 md5: $LOCAL_MD5  ($(stat -c %s "$TMP/probe.bin") bytes)"

echo
echo "[2/4] 正向推送（应成功）"
T0=$(date +%s)
if rsync -a --partial --inplace -e "$SSH" "$TMP/probe.bin" "$TARGET:verify_probe.bin" 2>&1 | tail -3; then
  :
fi
T1=$(date +%s)
echo "  耗时 $((T1 - T0))s"

REMOTE_MD5=$($SSH "$TARGET" "md5sum $REMOTE_DIR/verify_probe.bin 2>/dev/null | awk '{print \$1}'" 2>/dev/null)
echo "  远端 md5: ${REMOTE_MD5:-<读取失败>}"
if [ "$LOCAL_MD5" = "$REMOTE_MD5" ]; then
  echo "  ✅ md5 一致"
else
  echo "  ❌ md5 不一致或远端不可读"
  FAIL=1
fi

echo
echo "[3/4] 越界写入（应被拒）"
OUT=$(rsync -a -e "$SSH" "$TMP/probe.bin" "$TARGET:../../etc/verify_evil.bin" 2>&1)
if echo "$OUT" | grep -qiE "do not use \.\..*|denied|Permission denied|failed"; then
  echo "  ✅ 已拒绝: $(echo "$OUT" | head -1)"
else
  echo "  ❌ 未被拒绝，通道不安全！输出: $OUT"
  FAIL=1
fi

echo
echo "[4/4] 清理"
$SSH "$TARGET" "rm -f $REMOTE_DIR/verify_probe.bin" 2>/dev/null && echo "  ✅ 已清理远端测试文件"

echo
if [ $FAIL -eq 0 ]; then
  echo "=== 全部通过 ==="
else
  echo "=== 有失败项，见上 ==="
fi
exit $FAIL
