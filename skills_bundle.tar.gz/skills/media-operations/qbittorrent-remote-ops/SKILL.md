---
name: qbittorrent-remote-ops
description: 远程多节点 qBittorrent 运维与下载编排：SSH 隧道、WebUI 认证、4.x/5.x 端点差异、受限回传通道。
version: 2.0.0
author: 柠檬
license: MIT
metadata:
  hermes:
    tags: [qbittorrent, pt, tunnel, ssh, sshfs, rrsync, multi-node, relay, rsync]
    related_skills: [pt-site-ops, instabox-node-ops, aws-ec2-ops, emby-proxy-ops, socks5-proxy-setup]
---

# 远程多节点 qBittorrent 运维与下载编排

## When to Use / 触发条件

- qBittorrent 跑在另一台机器上，要从本机/Bot 远程控制它
- 要给下载机加第二个节点（分流、溢出备用、减轻主节点磁盘压力）
- 要把「第二台机器」接进已有的下载链路（沙箱、备用 VPS、小鸡），发种子时让人选「在哪台机器下」
- 需要把第三方机器下好的文件安全搬回主 VPS 再上传（上传凭据不能下发）
- 隧道通了但 API 一直 `401 Unauthorized`
- 需要让一台机器只能读/只能写另一台机器的某个目录（受限传输通道）
- 排查「qb 任务到底在哪台机器上处理」、任务卡在 `stoppedUP` 但没有任何报错

## 一、先分清三段流量，再谈方案

这是最容易想错的地方。以「沙箱下载 → 回传主 VPS → 上传云盘/网盘」为例：

| 环节 | 走谁的网络 | 占谁额度 |
|---|---|---|
| BT 下载 + 做种 | **下载节点的网络** | 节点，不占主 VPS |
| 节点 → 主 VPS 回传 | 主 VPS **入站 RX** | 不计出站 |
| 主 VPS → 目标平台上传 | **主 VPS 出站 TX** | 占主 VPS 出站 |

**结论：加下载节点只省「BT 下载与做种」这一块，上传出站省不掉**——因为上传凭据留在主 VPS，不会下发到第三方。

别向用户承诺「加了节点就不走主 VPS 流量了」，要按上表逐段说清。BT 下载量 ≈ 上传量、做种还要再传一份，所以省下的其实是主 VPS 流量里最大的一块；主 VPS 的带宽也不用再被下载和上传互相抢。

想省的对象不同，方案就不同：省 AWS/云端出网 → 让视频数据完全不经过它（只走控制信令）；省主 VPS 出站 → 只能换上传出口，靠加下载节点做不到。

## 二、核心事实：qb WebUI 不在本机时必须伪装 Host 头

这是最容易卡住的一步。SSH 隧道把远端 8999 映射到本地，`curl` 直连返回：

```
version: Unauthorized
torrents/info HTTP 401
```

**即使账号密码完全正确也 401**，因为 qb 配置里有：

```
WebUI\HostHeaderValidation=true
WebUI\ServerDomains=127.0.0.1
WebUI\CSRFProtection=true
```

隧道访问时 Host 是 `127.0.0.1:18998`（映射端口），不是 `127.0.0.1:8999`，被 Host 头校验拒掉。

**解法**：会话里强制覆盖三个头，伪装成本地 WebUI 访问：

```python
ORIGIN = "http://127.0.0.1:8999"          # 远端真实 WebUI origin，不是隧道端口
s = requests.Session(); s.trust_env = False   # 关键：忽略 http_proxy 环境变量
s.headers.update({"Host": "127.0.0.1:8999",
                  "Origin": ORIGIN,
                  "Referer": ORIGIN + "/"})
r = s.post(BASE + "/auth/login", data=cred, timeout=10)
# 期望 200 "Ok."，且 cookies 里出现 SID*
```

`trust_env = False` 不能省：本机若配了代理，requests 会把隧道流量也丢进代理，表现成连接失败。

**`WebUI\LocalHostAuth=false` 救不了这个场景**。qb 5.x 下隧道来源虽然显示 127.0.0.1，仍然要求登录 cookie，实测无效。别在这上面绕。

## 三、设置 qb 5.x 密码（PBKDF2）

qb 5.x 用 PBKDF2-HMAC-SHA512 / 100000 轮，配置格式：

```
WebUI\Password_PBKDF2="@ByteArray(<base64(salt)>:<base64(dk)>)"
```

生成：

```python
import base64, hashlib, os, secrets, string
pw = "".join(secrets.choice(string.ascii_letters + string.digits) for _ in range(24))
salt = os.urandom(16)
dk = hashlib.pbkdf2_hmac("sha512", pw.encode(), salt, 100000)
val = "@ByteArray({}:{})".format(base64.b64encode(salt).decode(),
                                 base64.b64encode(dk).decode())
```

写进 `~/.config/qBittorrent/qBittorrent.conf` 的 `[Preferences]` 段后重启。改前先 `sed -i '/WebUI\\LocalHostAuth/d'` 去重，避免同键多行。

**验证顺序**（逐层，别跳）：
1. 本机 `curl -X POST http://127.0.0.1:8999/api/v2/auth/login -d "username=..&password=.."` → 期望 `Ok.`
2. 带 cookie 取 `/api/v2/app/version` → 期望 `v5.1.0` 这类版本串
3. 走隧道用上面的伪装头再测一遍

第 1 步过、第 3 步 401 = 纯 Host 头问题，按第二节修。

## 四、qBittorrent 4.x / 5.x 端点差异（血坑）

`apt install qbittorrent-nox` 现在装到的是 **5.x**，而绝大多数现成脚本按 4.x 写，**静默失效**：

| 功能 | 4.x | 5.x | 5.x 用旧名 |
|---|---|---|---|
| 添加种子暂停参数 | `paused=true` | `stopped=true` | 被**静默忽略**，种子直接开始下载 |
| 恢复 | `POST /torrents/resume` | `POST /torrents/start` | **404 Not Found** |
| 暂停 | `POST /torrents/pause` | `POST /torrents/stop` | **404 Not Found** |

实测（5.1.0）：

```
/torrents/resume -> 404 'Not Found'
/torrents/pause  -> 404 'Not Found'
/torrents/start  -> 200 ''
/torrents/stop   -> 200 ''
add paused=true  -> state=downloading（参数被丢，没暂停）
add stopped=true -> state=stoppedDL ✅
```

两版通用、实测 5.1.0 全部 200 的端点：`/torrents/info`、`/files`、`/properties`、`/filePrio`、`/delete`、`/add`、`/app/version`、`/app/preferences`。

按版本自适应的写法：

```python
ver = s.get(f"{api}/app/version").text.strip()   # "v5.1.0" / "v4.6.3"
m = re.match(r"v?(\d+)", ver)
major = int(m.group(1)) if m else 4              # 探测失败按 4.x 保守处理

def add_paused_param(paused):
    return {"stopped" if major >= 5 else "paused": "true" if paused else "false"}

resume_path = "/torrents/start" if major >= 5 else "/torrents/resume"
pause_path  = "/torrents/stop"  if major >= 5 else "/torrents/pause"
```

**排障线索**：qbittorrent 日志出现

```
QMetaObject::invokeMethod: No such method TorrentsController::resumeAction()
```

就是这个问题，不是网络、不是权限、不是 CSRF。

**教训（最重要的一条）**：所有 qB 调用都要检查 `resp.status_code`。404 被当成成功时，症状是任务永远卡在 `stoppedUP`、界面毫无报错，排障会往网络/权限方向白跑很久。

## 五、隧道常驻（systemd，不要 nohup）

```ini
[Unit]
Description=<用途> SSH tunnel
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=ubuntu
ExecStart=/usr/bin/ssh -N -F /home/ubuntu/.ssh/config \
  -o BatchMode=yes -o ExitOnForwardFailure=yes \
  -o ServerAliveInterval=15 -o ServerAliveCountMax=3 \
  -L 127.0.0.1:<本地端口>:127.0.0.1:8999 <ssh别名>
Restart=always
RestartSec=15

[Install]
WantedBy=multi-user.target
```

- `ExitOnForwardFailure=yes` 必加：端口被占时立即失败，否则 ssh 静默挂着但没转发，排查极费时间
- `ServerAliveInterval` 让链路半死时自动重连
- 装完 `systemctl is-enabled` 要看到 `enabled`，别只看 `active`
- 验收别只看第一次 start 成功：`systemctl restart` 触发一次真实重连，确认 10 秒内端口回来（`Restart=always` 生效）

### 5.1 手工 `ssh -N` 起的隧道迟早会丢 —— 机器在线 ≠ 隧道在

2026-10 实例：次节点「一直失败」，用户第一反应是「我看机器在线啊」。实测**远端机器完全正常**（uptime 正常、`qbittorrent-nox` 在跑、8999 在听、磁盘 18%），但本机 `127.0.0.1:18998` 根本没有监听——这条隧道当初是手工 `ssh -N` 起的，既没有 systemd 也没有 cron，进程一挂或机器重启就永久失联，Bot 侧只报一句 `QbAuthError: qb_connection_failed`，看不出任何线索。

**排障顺序必须是「先看本地端口，再看远端机器」**：

```bash
ss -tlnp | grep -E "18998|18999"          # 端口在不在？属于哪个进程？
ps aux | grep "ssh .*-L" | grep -v grep   # 是 systemd 管的，还是裸进程？
```

| 现象 | 结论 |
|---|---|
| 端口不存在 | 隧道问题，与远端机器无关，**别再去远端查 qb** |
| 端口在但 API 401 | Host 头问题（见第二节） |
| 端口在、API 200、任务不推进 | 才轮到远端 qb 状态 |

**每台节点的隧道都要各自落一个 systemd unit**（如 `lemon-qb-tunnel-la` / `lemon-qb-tunnel-ib`）。只给一台做保活等于留同一个雷——主力节点哪天裸进程挂掉，故障现象与次节点这次完全一样，而主节点挂掉的代价更大。

## 六、多节点拓扑与双会话设计

一个 Bot 管多个下载节点时，端口和凭据必须成对固定，避免串味：

| 节点 | 隧道端口 | 凭据文件 | 保存路径 |
|---|---|---|---|
| 主节点（大文件主力） | 18999 | `lemon-qb-client.json` | 各自主机路径 |
| 次节点（小文件/溢出） | 18998 | `lemon-qb-client-ib.json` | 各自主机路径 |

凭据文件约定：`{"username":..., "password":...}`，权限 `600`，属主为运行 Bot 的用户，读前校验 owner + mode（见既有 `qb_client` 的 `_load_credentials`）。

同一进程连两台 qB，必须做到「一条链路出问题不影响另一条」：

- **凭据分文件**：`~/.config/<app>-qb-client-<node>.json`，600，每节点一份，不共用
- **session 缓存按节点分 key**：`threading.local().cached` 存成 `{node: (fingerprint, session)}`，不要单值
- **每个 session 记住自己的 base URL**，请求前校验 `url.startswith(self._qb_base + "/")`，防止串台
- **节点元数据集中一张表**：`{node: {api, cred, origin, host, save_path, label, remote}}`
  - `save_path` 必须是**该节点上的真实路径**（沙箱 `/data/downloads` vs VPS `/home/ubuntu/Downloads`），不能拿主 VPS 路径去拼沙箱文件
  - `remote=True` 标记「文件不在主 VPS，需要回传」
- **非法节点值回退默认节点**，不要抛异常打断流程

## 七、受限传输通道：rrsync（关键安全设计）

给沙箱/第三方机器开目录访问时，**不要直接给 root 或主账号的 sftp**——那等于把整机读写权交出去。按需选两种受限模式：

- **只读浏览**（chroot + sftp，只能看一个目录）→ `references/scoped-ssh-access.md` 第一节
- **只写回传**（rrsync，只能往一个目录推文件）→ `references/scoped-ssh-access.md` 第二节

后者常用于「次节点下载完、回传到主节点上传」的分工，好处是**凭据只留在自有主机上**。四层隔离：

1. 专用系统用户，`-s /bin/bash`（rrsync 需要 shell 解析 command）、无 sudo
2. 密钥文件放 `/etc/ssh/keys/<user>`（root:root 644），用 `AuthorizedKeysFile` 指过去，**不放在 chroot 里的 .ssh**
3. 公钥前缀强制命令：`command="/usr/bin/rrsync -wo /srv/<dir>",restrict <pubkey>`
   - `-wo` = write-only 且锁定目录，客户端**无法读**
4. `Match User <user>` 块里禁 `AllowTcpForwarding` / `AllowAgentForwarding` / `PermitTunnel` / `X11Forwarding` / `PermitTTY` / `PasswordAuthentication`

```sshconfig
Match User qbupload
    AuthorizedKeysFile /etc/ssh/keys/qbupload
    AllowTcpForwarding no
    AllowAgentForwarding no
    PermitTunnel no
    X11Forwarding no
    PermitTTY no
    PasswordAuthentication no
```

验收标准（必须实测）：推送成功 **且** 越界路径被拒：

```
rsync ... file qbupload@host:probe.bin                    → 成功落盘
rsync ... file qbupload@host:../../etc/evil.bin           → rrsync error: do not use .. in arg
```

## 八、回传路径的越界防护

即使 rrsync 已锁目录，应用层仍要自己校验，别把路径拼接交给远端：

```python
if not path.startswith(ROOT + "/"):                      raise ...   # 前缀
if os.path.normpath(path) != path or ".." in path.split("/"): raise ...  # 规范化
name = os.path.basename(path)
if not name or name in (".", ".."):                      raise ...
```

只做 `startswith` 不够：`/data/downloads/../etc/x` 能过前缀检查，会一路走到 rsync 才被拒——拒绝点越靠后，可探测面越大。

回传后**必须清理中继副本**，否则每集都在主 VPS 留一份，几次就撑爆磁盘。清理用 `run_in_executor` 异步做，不阻塞主流程。

## 九、下发验证配方（别只看 add 返回 200）

```python
# 1. 拉一个公开 torrent 文件（体积小、合法、稳定）
# 2. add 时按版本传 paused/stopped=true，避免真下载吃带宽
files = {"torrents": ("t.torrent", content, "application/x-bittorrent")}
s.post(BASE + "/torrents/add", files=files,
       data={**add_paused_param(True), "savepath": "/data/downloads", "category": "linktest"})
# 3. 查 /torrents/info，确认 name / state / size / save_path 都符合预期
# 4. 删除测试任务：hashes + deleteFiles=true，再查一次确认归零
```

只看 `add: 200 Ok.` 不够——保存路径错、任务落到别的节点、权限不足都可能仍返回 200。

## 十、实测吞吐基线（2026-10，InstaBox 沙箱 → RackNerd VPS）

| 环节 | 实测 |
|---|---|
| 沙箱 BT 下载 | 756MB / 40s，峰值 **33.6 MB/s**（下行不是瓶颈） |
| 沙箱 → VPS 回传 | 477MB / 106s ≈ **4.5 MB/s**；小文件 20MB ≈ 3.4 MB/s |
| 全流程（下载+回传+上传+清理） | 477MB **100 秒** |

**判断标准**：回传是瓶颈。单集（<1G）放沙箱没问题；几十 G 的合集仍应走主 VPS 本地下载，否则回传比下载还慢。

沙箱还有 8 小时硬暂停 + 20G 盘限制，跨暂停点的长任务会中断，排任务前先算时间。

## 十一、排障三角（无日志时怎么定位）

Bot 代码常常不打日志，出问题要靠外部证据拼时间线：

1. **主 VPS 的 sshd 日志**：`journalctl -u ssh --since ...`，看 `Accepted publickey for <回传用户> from <第三方IP>` → 证明回传真的发生、起止时刻
2. **中继目录 mtime**：`stat -c %y /srv/<dir>` → 最后一次文件进出时刻，与 sshd 时间对齐就能算出传输耗时
3. **下载节点的 qb journal**：`journalctl --user -u qbittorrent.service --since ...` → 端点 404、状态切换

三者对齐后能判断卡在哪一段。补充判据：
- 中继文件被清理 = 上传环节**有返回**（异常路径不会走到 cleanup）
- 任务残留 `stoppedUP` = resume 失败或流程中途退出
- 目标平台返回 DUPLICATE = 该内容已在库里，不是失败

## 十二、验证顺序（改完必须按这个跑）

1. 两节点 session 同时连通：版本 + `save_path` + `listen_port` 都要打印
2. 端点适配：`add_paused_param` 的键、`resume_path` 的值，两节点分别打印
3. 路径防护：正常路径、`../` 路径、根外路径、空串，四种都要拦
4. 回传实测：造 20MB 文件 → rsync → 两端 md5 对比 → cleanup → 确认已删
5. 完整流水线：用真实种子跑一遍，看下载/回传/上传/清理四段全通
6. 收尾状态：下载节点任务数归零、磁盘回落、中继目录空、服务 `NRestarts=0`

**不要只做 1-2 步就报完成**——端点差异这类 bug 只在真实流水线里才暴露。

## 十三、坑

1. **`pkill -f "<长模式串>"` 会杀掉自己**。当模式串出现在当前命令行里（例如整条 bash -c 命令包含了那个 `-L 127.0.0.1:18998:...` 字面量），pkill 匹配到自身 shell，命令以 `exit -15` 静默终止，看起来像「命令超时/被杀」。改用 `ss -tlnp | grep <端口>` 定位 PID，或把模式写窄到不含自身。
2. **`sshfs -o allow_other` 默认被拒**：`option allow_other only allowed if 'user_allow_other' is set in /etc/fuse.conf`。单人使用直接去掉该选项即可，别去改 fuse.conf 扩大权限。
3. **精简 Debian 镜像常缺 rsync**：`rsync: command not found` 是没装，不是通道不通。先 `apt install rsync` 再判通道。
4. **sshd 改动三件套**：①`StrictModes` 不能出现在 `Match` 块里（`sshd -t` 报 `Directive 'StrictModes' is not allowed within a Match block`，reload 失败），正解是 `AuthorizedKeysFile /etc/ssh/keys/<user>` 指向 root 拥有的 644 文件，别把 `.ssh` 塞进 chroot 内部；②Debian/Ubuntu 的单元名是 **`ssh`** 不是 `sshd`，用 `systemctl reload ssh`；③改 sshd 用 `reload` 不用 `restart`（restart 会掐掉当前会话），改前 `sshd -t` 必过，改后复查既有通道（如只读挂载）是否还在。
5. **上传器带凭据时不要部署到第三方沙箱**：token 落在别人能 root 的机器上等于交出去了。正确分工是「沙箱只下载，文件回传到自有主机再上传」，凭据始终不出自有边界。
6. **`rsync -e "ssh ..."` 里的端口要单独写一遍**。回传命令形如 `rsync -e "ssh -i $HOME/.ssh/id_qbupload ..." src qbupload@HOST:name`，端口只存在于 `-e` 那个**嵌套字符串**里；外层 ssh 走 config 别名带着 2222，内层照样默认 22。vps-la 的 22 已封，实测沙箱侧 `<PRIVATE_IDENTIFIER>:22 → Connection refused`、`2222` 通，漏掉 `-p 2222` 整条回传必失败且报错只在 stderr 里。**凡「配置里改过端口」，`grep -rn` 要找所有嵌套 ssh 调用**（`rsync -e`、`scp -o`、脚本 heredoc），只改外层不够。
7. **rrsync 报 `Another instance of rrsync is already accessing this directory` 不是配置错**，是上一次失败/中断的 rsync 留下的单实例锁。先 `ps aux | grep rrsync` 确认没有残留进程再重试，不要动 `authorized_keys` 或 rrsync 参数。另外**判断传输成功看两端字节数**（`stat -c %s`），不要看 rsync 退出码或进度输出——stdout 在管道/heredoc 场景会被吞，看不到进度 ≠ 没传（实测 1.88GB 已完整落地，调用方却只拿到空输出）。

## 十四、改这类生产 Bot 的规矩

- 先备份：`cp a.py b.py c.py /home/<user>/ops-backups/<feature>-$(date +%Y%m%d-%H%M%S)/`
- 行范围替换用脚本（带 `assert` 锚点），不要靠 sed 猜行号
- 改完 `python3 -c "import ast; ast.parse(open(f).read())"` 逐个文件过语法
- **f-string 里的 `\n` 在写入源码时容易被转义成 `\\n`**，落盘后变成字面量 `\n`。写完用 `sed -n 'N,Mp' 文件` 肉眼看一眼，或用 `cat -A` 确认是 `\n` 而不是 `\\n`
- 重启服务后看 `NRestarts`，非 0 说明启动即崩

## 相关

- 沙箱类下载节点的内核/暂停/带宽约束 → `references/sandbox-download-node-notes.md`
- 会话级实现细节（具体回调命名、代码位置、实测流水）→ `references/dual-node-qb-relay.md`
- 回传通道自检脚本 → `scripts/verify_relay_channel.sh`
- 只读/只写受限目录访问全文 → `references/scoped-ssh-access.md`
- PT 站点规则与客户端部署 → `pt-site-ops`
- 沙箱保活与探针 → `instabox-node-ops`
