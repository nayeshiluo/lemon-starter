---
name: oauth-cloud-storage-recovery
description: Use when recovering OAuth cloud storage for media sync.
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [oauth, google-drive, cloud-storage, media-sync, verification]
---

## When to Use

- OAuth-backed Google Drive or other cloud storage has expired credentials, redirect mismatch, or token refresh failures.
- A media pipeline needs decoupled multi-target retry and backlog recovery.

## 适用场景

媒体同步断更、OAuth 失效、双轨上传互相阻塞、积压需要补偿，或需要在用户协助下恢复云存储授权时使用。本技能强调真实验证、最小副作用和可恢复补偿，不把“服务进程 active”当成业务健康。

## 核心原则

1. **先证据、后修改**：核对源消息数量、同步数据库水位、服务日志、缓存和云盘目录；修改前备份 Worker、数据库、session 与旧凭证。
2. **客户端与 Token 成对**：refresh token 必须用生成它的同一 OAuth client_id/client_secret 刷新；禁止只替换 token 而继续使用旧客户端。
3. **Web 回调精确匹配**：OAuth Playground 的 Web application client 必须包含 `https://developers.google.com/oauthplayground`；Desktop client 页面没有该输入框，不能继续寻找。
4. **双轨解耦**：下载、目标 A、目标 B、数据库状态分别记录；次要目标失败不得阻断主目标，也不得让已成功目标重复上传。
5. **真实验收**：至少完成 token exchange、账号身份检查、目标目录权限检查、极小文件上传和删除；之后才启动积压补偿。
6. **用户操作最小化**：用户只确认授权或把凭证安全放到指定路径；不要要求用户手抄长 token，也不要在聊天中回显 secret/token。

## 标准工作流

### 1. 建立恢复基线

记录源频道/中转频道最新消息 ID 与真实视频数量、数据库 `min/max/count`、各目标成功/失败状态、服务 MainPID 与最近日志、临时缓存、0 字节文件和云盘目标目录 ID。备份 Worker 源码、数据库、Telegram session、旧 cloud token 和 OAuth client 配置。

### 2. 引导 OAuth 授权

遇到 `redirect_uri_mismatch`：返回 OAuth client 列表；Desktop client 不能配置 Playground 回调；创建/选择 Web application；添加精确 URI `https://developers.google.com/oauthplayground`；保存等待传播；OAuth Playground 勾选 `Use your own OAuth credentials`；选择最小必要 scope，例如 `https://www.googleapis.com/auth/drive`；完成 `Authorize APIs`；Step 2 点击 `Exchange authorization code for tokens`。

不要把 refresh token、client secret 或完整 token JSON 发到群聊。优先让用户将文件直接保存到服务器，如 `/tmp/gdrive_token_new.json`，权限设 `600`。

### 3. 验证并安装凭证

用新 client 请求 OAuth token endpoint，确认得到 access token；调用云盘账号信息接口确认账号正确。安装前备份旧配置、权限设 `0600`，日志只打印长度/账号/状态。随后上传极小 probe，读取 file ID/name，确认成功后删除并验证删除状态。

### 4. 可恢复状态

单条媒体至少记录：

```text
msg_id, media_type, filename
gdrive_status/gdrive_fid
guangya_status/guangya_fid
retry_count, last_error, source_channel, updated_at
```

主队列和目标补偿队列分开：主目标为 `guangya_status != success`；GDrive 补偿为 `gdrive_status != success`；光鸭已成功时 GDrive 补偿可重新下载源文件，但绝不能再次上传光鸭。

### 5. 媒体安全边界

下载必须有硬超时并清理临时文件；临时路径统一使用 `.msg_<id>.download.<ext>`，不要直接使用云端展示文件名；展示名过滤 URL、Markdown、路径分隔符、控制字符和推广语；最终文件名按 UTF-8 **字节数**限制；添加消息 ID 后缀避免覆盖；分类使用来源和上下文，但混发频道不能仅按频道名全量归类；已成功上传记录不要自动改名。

### 6. 补偿验收

先小批量观察数据库增长、各目标成功数、错误是否隔离、应用层进度日志、缓存清理和目录落点。最终必须核对：源视频总数与成功/失败/待补偿之和一致；云盘 file ID 实际存在于目标目录；数据库与云盘一致；无 0 字节/孤儿半成品；Worker active 且持续产生日志。

## 常见陷阱

- “应用未经验证”不等于 OAuth 失败；自己创建且 scope 正确时可继续。
- 右侧 302 只代表 authorization code；必须完成 Step 2 token exchange。
- 只替换 token 不同步新 client secret 会导致 `invalid_grant`。
- `active (running)`、Telethon 心跳或 `ep_poll` 不代表业务正常。
- 固定扫描最新 N 条会让失败消息占据窗口，应按数据库状态分页/全量回溯。
- 按来源频道一键移动可能误伤混发频道，只移动有来源、标题、现目录三重证据的文件。

## 参考资料

真实 OAuth/双轨故障复现与验收记录：`references/oauth-dual-track-recovery-20260906.md`
