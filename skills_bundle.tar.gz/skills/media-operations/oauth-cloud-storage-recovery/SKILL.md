---
name: oauth-cloud-storage-recovery
description: Use when recovering OAuth cloud storage for media sync.
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [oauth, google-drive, cloud-storage, media-sync, verification]
---

## When to Use

- OAuth-backed Google Drive or other cloud storage has expired credentials, redirect mismatch, or token refresh failures.
- A media pipeline needs decoupled multi-target retry and backlog recovery.

## 适用场景

媒体同步断更、OAuth 失效、双轨上传互相阻塞、积压需要补偿，或需要在用户协助下恢复云存储授权时使用。本技能强调真实验证、最小副作用和可恢复补偿，不把“服务进程 active”当成业务健康。

## 核心原则

1. **先证据、后修改**：核对源消息数量、同步数据库水位、服务日志、缓存和云盘目录；修改前备份 Worker、数据库、session 与旧凭证。
2. **客户端与 Token 成对**：refresh token 必须用生成它的同一 OAuth client_id/client_secret 刷新；禁止只替换 token 而继续使用旧客户端。
3. **Web 回调精确匹配**：OAuth Playground 的 Web application client 必须包含 `https://developers.google.com/oauthplayground`；Desktop client 页面没有该输入框，不能继续寻找。
4. **双轨解耦**：下载、目标 A、目标 B、数据库状态分别记录；次要目标失败不得阻断主目标，也不得让已成功目标重复上传。
5. **真实验收**：至少完成 token exchange、账号身份检查、目标目录权限检查、极小文件上传和删除；之后才启动积压补偿。
6. **用户操作最小化**：用户只确认授权或把凭证安全放到指定路径；不要要求用户手抄长 token，也不要在聊天中回显 secret/token。

## 标准工作流

### 1. 建立恢复基线

记录源频道/中转频道最新消息 ID 与真实视频数量、数据库 `min/max/count`、各目标成功/失败状态、服务 MainPID 与最近日志、临时缓存、0 字节文件和云盘目标目录 ID。备份 Worker 源码、数据库、Telegram session、旧 cloud token 和 OAuth client 配置。

### 2. 引导 OAuth 授权

遇到 `redirect_uri_mismatch`：返回 OAuth client 列表；Desktop client 不能配置 Playground 回调；创建/选择 Web application；添加精确 URI `https://developers.google.com/oauthplayground`；保存等待传播；OAuth Playground 勾选 `Use your own OAuth credentials`；选择最小必要 scope，例如 `https://www.googleapis.com/auth/drive`；完成 `Authorize APIs`；Step 2 点击 `Exchange authorization code for tokens`。

不要把 refresh token、client secret 或完整 token JSON 发到群聊。优先让用户将文件直接保存到服务器，如 `/tmp/gdrive_token_new.json`，权限设 `600`。

### 3. 验证并安装凭证

用新 client 请求 OAuth token endpoint，确认得到 access token；调用云盘账号信息接口确认账号正确。安装前备份旧配置、权限设 `0600`，日志只打印长度/账号/状态。随后上传极小 probe，读取 file ID/name，确认成功后删除并验证删除状态。

### 4. 可恢复状态

单条媒体至少记录：

```text
msg_id, media_type, filename
gdrive_status/gdrive_fid
guangya_status/guangya_fid
retry_count, last_error, source_channel, updated_at
```

主队列和目标补偿队列分开：主目标为 `guangya_status != success`；GDrive 补偿为 `gdrive_status != success`；光鸭已成功时 GDrive 补偿可重新下载源文件，但绝不能再次上传光鸭。

### 5. 媒体安全边界

下载必须有硬超时并清理临时文件；临时路径统一使用 `.msg_<id>.download.<ext>`，不要直接使用云端展示文件名；展示名过滤 URL、Markdown、路径分隔符、控制字符和推广语；最终文件名按 UTF-8 **字节数**限制；添加消息 ID 后缀避免覆盖；分类使用来源和上下文，但混发频道不能仅按频道名全量归类；已成功上传记录不要自动改名。

### 6. 补偿验收

先小批量观察数据库增长、各目标成功数、错误是否隔离、应用层进度日志、缓存清理和目录落点。最终必须核对：源视频总数与成功/失败/待补偿之和一致；云盘 file ID 实际存在于目标目录；数据库与云盘一致；无 0 字节/孤儿半成品；Worker active 且持续产生日志。

## 常见陷阱

- “应用未经验证”不等于 OAuth 失败；自己创建且 scope 正确时可继续。
- 右侧 302 只代表 authorization code；必须完成 Step 2 token exchange。
- 只替换 token 不同步新 client secret 会导致 `invalid_grant`。
- `active (running)`、Telethon 心跳或 `ep_poll` 不代表业务正常。
- 固定扫描最新 N 条会让失败消息占据窗口，应按数据库状态分页/全量回溯。
- 按来源频道一键移动可能误伤混发频道，只移动有来源、标题、现目录三重证据的文件。
- **故障分层先于处置**：`invalid_grant` = token 过期/被撤销（重新授权即可）；`disabled_client` = 整个 OAuth 项目被 Google 禁用（高度关联账号封停，需申诉）；`VALIDATION_REQUIRED` = 账号级安全验证未过（token 有效但被拦，去 Google 安全设置补验证并重新 OAuth 签新 token——重授权本身不能清除）。判定依据 + 永久关闭某轨的操作顺序见 `references/permanent-track-shutdown.md`。
- **三层分离探活（2026-10 实测，一次定位阻塞在哪一层）**：盘在不在、client 活不活、token 活不活是**三件事**，必须分开验，不要用其中一层的结论推断另两层。
  - 层 1 · client 活性（只读，不需要 token）：构造 auth URL 后用**禁止跟随重定向**的 opener 请求。
    `302 → accounts.google.com/v3/signin/identifier` = 正常；命中 `disabled_client` / `deleted_client` / `redirect_uri_mismatch` = 项目级问题，重授权救不回来。
    ```python
    class NR(urllib.request.HTTPRedirectHandler):
        def redirect_request(self, *a, **k): return None
    op = urllib.request.build_opener(NR)
    try:
        op.open(urllib.request.Request(auth_url, headers={"User-Agent": "Mozilla/5.0"}), timeout=20)
    except urllib.error.HTTPError as e:
        loc = e.headers.get("Location", "")      # 看这里，不要 read() body
    ```
  - 层 2 · token 活性：必须用**生成该 token 的同一 client_id + client_secret** 打
    `POST https://oauth2.googleapis.com/token`（`grant_type=refresh_token`）。
    `400 {"error":"invalid_grant","error_description":"Bad Request"}`（description 是空的 `Bad Request`，
    不同于封号那种 `Token has been expired or revoked`）= refresh token 已吊销，
    **重新 OAuth 一次即可，盘和项目都还在**。别据此报「账号被封」。
  - 层 3 · 身份与配额：拿到 access token 后打 `about?fields=user,storageQuota`，
    报 `emailAddress` 与 `limit/usage` 的 GB 数，确认授权到的是**哪个账号、配额多大**。
  - 全程只读探测，不刷新后回写；失败只报「哪一层挂了」，token 原文不进聊天、日志或报告。
- **token 文件与 client 必须配对取用（最高频的误判源）**：落盘的 `gdrive_token*.json` 常常只有
  `access_token` / `refresh_token` / `scope` / `token_type`，**不含 `client_id` 和 `client_secret`**。
  client 在别处：旧 plan 文档、上传器源码里的 `DEFAULT_CLIENT_ID`、`gdrive_oauth_client.json`、历史会话。
  拿 A 的 token 配 B 的 client 必然 `invalid_grant`；先确认两者同源，再判「token 死了」。
  定位 client 时按文件名**定向**找（`gdrive_oauth_client.json` / `client_secret*.json` / `*token*.json`），
  不要全盘递归 grep。漏了这个文件时上传器报的 `invalid_grant`，根因其实是本地配置缺失而非谷歌封号。
- **用户问「我有好几个 5T 盘，能不能开个服」时先分清盘 ≠ remote**：
  同一谷歌账号下的多个共享盘 → rclone 授权**一次**，一个 remote 里看全所有盘；
  多个独立谷歌账号 → 每个号一次 `code`，配 `gdrive1:` `gdrive2:` 多 remote、多挂载点。
  这个没问清就部署，后期要返工加挂载。
- **`rclone authorize` 在多账号场景比自建 client 更省事（2026-10 实测）**：
  用户说「别人只要账号登录一下就行」时，说的是 rclone 自带的公开 client
  `202264815644.apps.googleusercontent.com`（Desktop 类型，回调固定 `http://127.0.0.1:53682/`），
  不需要建项目、不需要 client_secret。关键操作细节：
  - `rclone authorize "drive" --auth-no-open-browser --drive-scope drive` **必须后台启动**，
    前台会一直等 code 直到超时；启动后从日志读 `state=...`。
  - 回调指向**用户本机** 127.0.0.1，所以要么让用户开 `ssh -L 53682:127.0.0.1:53682` 隧道（点一下即完成、零复制），
    要么让用户点完把地址栏整条 URL 贴回来，回收 `code=` 塞回进程 stdin。
  - 多个独立账号就重复 N 次，每个号 `rclone config create gdriveN drive`，一份 `rclone.conf`、多个 remote，
    挂载点 `/mnt/gdriveN` 各配一个 systemd 单元，互不牵连。
  - 目标机无 `unzip` 时装 rclone 用官方 deb：`curl -O .../rclone-current-linux-amd64.deb && sudo dpkg -i`，
    不要绕去编译。
- **账号申诉解封后的状态转换与极速换证（2026-09 实测）**：
  - **状态机转变**：账号解封后，OAuth 授权端点立即恢复正常（从 `401 disabled_client` 变回 `HTTP 200` 正常渲染授权页），证明客户端已重新可用。
  - **Token 联动失效**：封禁前签发的所有 `refresh_token` 会被 Google 安全机制全量吊销（刷新时返回 `400 invalid_grant: Token has been expired or revoked.`），切勿将此误判为客户端仍被封禁。
  - **无头服务器极速换证**：构造带 `client_id`、`redirect_uri=https://developers.google.com/oauthplayground`、`scope=https://www.googleapis.com/auth/drive`、`access_type=offline`、`prompt=consent` 的直达授权 URL；引导用户浏览器授权后回传重定向 URL 中的 `code`；脚本通过 POST `https://oauth2.googleapis.com/token`（`grant_type=authorization_code`）自动置换出全新永久 `refresh_token` 并自动部署到 `rclone.conf` 或工作目录。
  - **交付用户前的“确定没问题”零死角预检闭环（2026-09 实测）**：
    - **授权端点探活**：在发给用户前或用户确认时，必须用 `requests.get(auth_url, allow_redirects=False)`（或携带标准 UA 探活）请求构造的授权 URL，确认返回 **HTTP 302** 重定向至 `accounts.google.com/v3/signin/...`，严格断言排除 `disabled_client`、`deleted_client`、`invalid_request` 与 `redirect_uri_mismatch`。
    - **无头挂载宿主机全链路预检**：远程检查 `rclone version`、`docker compose version`、`crw-rw-rw- /dev/fuse` 与 `fusermount3`，确认 FUSE 驱动支持读写挂载；检查 `ss -tulnp`，若发现 8096 等既有服务占用则提前隔离映射至 8097；验证可用内存、Swap 与磁盘空间。
    - **防范受限宿主机 tmpfs 内存吞噬**：在 2GB 内存小机器上排障时，注意 `/tmp` 通常挂载在 tmpfs（直接占用物理 RAM），测试产生的临时 SQLite db 或镜像切片必须即时清理，严禁滞留 tmpfs 造成隐形内存压力。

## 参考资料

- `references/permanent-track-shutdown.md` — 永久关闭某一上传轨（账号被封场景）的完整操作顺序：调用点全量定位、同 try 块改跳过而非 raise、远端 Worker 同步、凭证禁用归档、故障分层证据链、从 state.db 会话历史挖回 OAuth client_id/secret。
