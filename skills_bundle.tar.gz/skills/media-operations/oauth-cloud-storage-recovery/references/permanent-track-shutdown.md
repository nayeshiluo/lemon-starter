# 永久关闭某一上传轨（账号被封 / 项目停用）

适用：目标云盘账号被封（如 Google 大号封禁），用户要求「永久关闭 GDrive 上传」，
但**另一轨（光鸭等主轨）必须不停摆**。这是双轨解耦的下半场——不只是恢复，而是干净下架。

## 改法顺序（本次 2026-09-09 实测）

1. **先定位所有调用点**：`grep -rn "upload_file_to_gdrive\|upload_file_to_<target>" <项目目录>/*.py`。
   双轨脚本里往往有**相册组分支 + 单集分支两处**（本次 `lifan_channel_sync.py` /
   `ai_short_sync.py` 各 2 处，共 4 处），只改一处会漏单集分支继续上传。

2. **改调用点跳过，而非让上传函数 raise**：双轨上传通常在同一 `try:` 块里
   （`g_res = upload_gdrive(...)` 紧接 `gy_res = upload_guangya(...)`）。若让 GDrive 函数
   抛异常，异常会**连带跳过光鸭上传**——这是最容易踩的坑。正确做法：把 GDrive 那两行
   替换为 `logger.info("⏭️ GDrive 轨已永久关闭，跳过")`，光鸭调用原样保留。

3. **给上传函数加防御性 raise**（防漏网调用）：在 `get_valid_gdrive_token()` 开头加
   `raise RuntimeError("GDrive 轨已永久关闭 (日期 原因)")`。因为所有调用点已改为跳过，
   这个 raise 只兜底，不影响光鸭。

4. **远端 Worker 同步**：Worker 若部署在远端 VPS（如 RackNerd `/opt/<worker>/`），必须
   SSH 过去做同样修改：`cp sync_worker.py sync_worker.py.bak-<日期>` 备份 → Python 字符串
   替换 GDrive 段 → `python3 -m py_compile` 验语法 → `systemctl restart <svc>`。
   **本地目录是部署源副本，也要同步改**，保持一致，避免下次 deploy.sh 把旧代码覆盖回远端。

5. **禁用/归档凭证**：
   - 远端 `gdrive_oauth_client.json` 备份后替换为禁用占位
     `{"web":{"client_id":"DISABLED-...","client_secret":"DISABLED","disabled":true}}`。
   - 本地 token 文件归档到 `backups/<target>-disabled-<日期>/`，权限 600。

6. **状态查询函数改返回已关闭**：`ops_media.py` 里 `get_gdrive_info()` 之类的面板函数
   改为返回 `{"ok": False, "disabled": True, "msg": "已永久关闭"}`，避免每次查询都尝试
   无效 token。

7. **验收**：`grep -rn "upload_file_to_<target>"` 应只剩 `import` 和 `def` 行（无实际调用）；
   全部 py 文件 `py_compile` 通过；另一轨的 cron 下次照常跑（看 cron 日志确认光鸭仍在下发）。

## 排查账号「被封 vs token 过期」的关键证据链

用户报「大号出问题 / 被停用」时，先区分两种病因，别急着让用户申诉：

- **token 过期**：`refresh_token_expires_in` 字段存在（Playground 签发的 7 天受限 token
  特征）→ 时间吻合即可判定为普通过期，重新 OAuth 即可。
- **账号/OAuth 项目被封**：实测刷新 token 返回 `disabled_client`（不是 `invalid_grant`）
  → 谷歌把整个 OAuth 项目（含所有 client）禁用了，高度关联账号级封停，是下游症状。
- **判别账号是否还活着**：重新走一次 OAuth 授权能否成功是硬证据——能走完 `code → token`
  就证明账号当天还活着；配合 `tokeninfo` 端点验证 access_token 有效性。

## 凭证找回：从会话历史挖 OAuth client_id/secret

OAuth client 配置（`client_id` + `client_secret`）常只在历史部署会话里出现过一次，文件
早已丢失。可用 SQLite 全文查 `state.db` 找回来：

```bash
sqlite3 ~/.hermes/state.db \
  "SELECT substr(content,1,400) FROM messages WHERE content LIKE '%GOCSPX-%' ORDER BY id DESC LIMIT 5;"
```

`GOCSPX-` 是 Google OAuth client secret 的特征前缀；`apps.googleusercontent.com` 是
client_id 特征。注意旧 client 的 secret 可能在重构 uploader 时被删掉、改成读一个从未
创建的配置文件——这是「本地刷新必败」的隐藏雷，与账号封禁无关但会让恢复工作雪上加霜。
