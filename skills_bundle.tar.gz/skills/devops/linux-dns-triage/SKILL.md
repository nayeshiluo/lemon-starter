---
name: linux-dns-triage
description: Use when curl/探针偶发 5-10s 超时，排查 DNS 丢包。
version: 1.0.0
author: Hermes Agent (curator)
license: MIT
metadata:
  hermes:
    category: devops
    tags: [dns, resolv.conf, latency, curl, probe, timeout, journalctl]
    related_skills: [monitor-hub-ops, host-operations-evidence, error-digest-triage]
---

# Linux DNS 抖动排查与修复

## When to Use / 触发条件

- 监控探针（Komari/Beszel/哪吒）ping 任务大量超时，但手动 `curl` 一次又是好的
- `curl` 偶发卡 5–10 秒，`time_connect` 整数秒（TCP SYN 不会这么整齐）
- 日报出现大量 `context deadline exceeded`，但其他同期指标正常
- 改了 DNS 配置后验证是否生效

## 一、快速判断是不是 DNS

### 步骤 1：固定 IP 绕开 DNS

```bash
for ip in $(dig +short <host> A); do
  curl -s -o /dev/null -w "$ip connect=%{time_connect}s total=%{time_total}s\n" \
    --max-time 15 --resolve "<host>:443:$ip" https://<host><path>
done
```

`--resolve` 后 connect 掉到 1ms → 网络好，DNS 是瓶颈。

### 步骤 2：测 DNS 速度（20 次采样）

```bash
python3 -c "
import subprocess,time
for i in range(20):
    t0=time.time()
    subprocess.run(['dig','+short','+time=5','+tries=1','<host>','A'],capture_output=True)
    print(f'{i+1:2d} {time.time()-t0:.3f}s')
"
```

出现整齐的 **5.0xx s** = UDP 53 丢包，单次重传超时 5s。

### 步骤 3：逐 DNS 服务器对比

```bash
for ns in 8.8.8.8 1.1.1.1 <YOUR_SERVER_IP>; do
  python3 -c "
import subprocess,time
ns='$ns'; slow=0; ts=[]
for i in range(20):
    t0=time.time()
    subprocess.run(['dig','@'+ns,'+short','+time=5','+tries=1','<host>','A'],capture_output=True)
    dt=time.time()-t0; ts.append(dt)
    if dt>1: slow+=1
print(f'{ns:12s} max={max(ts):.3f}s 慢查询(>1s)={slow}/20')
"
done
```

选 max 最小、慢查询最少的服务器。

## 二、curl 的时间字段含义（重要）

```
time_namelookup = 仅 DNS
time_connect    = DNS + TCP 建连
time_appconnect = DNS + TCP + TLS
```

用这个命令分段查：

```bash
curl -s -o /dev/null \
  -w 'dns=%{time_namelookup}s connect=%{time_connect}s tls=%{time_appconnect}s total=%{time_total}s HTTP=%{http_code}\n' \
  --max-time 15 https://<target>
```

`time_connect=5.1s` 但 `time_appconnect=5.15s` → DNS 占 5s，TCP+TLS 各 50ms，**网络完全正常**。

## 三、常见误判：IPv6 不是慢速原因

无 IPv6 默认路由时，`curl -6` 立即失败（0.007s），不会卡 5 秒。
先 `ip -6 route show default`：无输出 = 无 IPv6 路由，不用纠结。
DNS 返回 AAAA 地址 + 本机无 IPv6 路由 → curl Happy Eyeballs 自动回退 IPv4，不造成延迟。

## 四、修法：resolv.conf

### 4.1 备份

```bash
# /root 权限不够时用 /home/ubuntu
sudo cp -a /etc/resolv.conf /home/ubuntu/resolv.conf.bak-$(date +%Y%m%dT%H%M)
```

### 4.2 新配置

```
# 1.1.1.1 优先，8.8.8.8 备选，<YOUR_SERVER_IP> 兜底（中国大陆节点）
# timeout:1 attempts:2 —— 单次丢包最多等 1s 即回退
nameserver 1.1.1.1
nameserver 8.8.8.8
nameserver <YOUR_SERVER_IP>
options timeout:1 attempts:2
```

### 4.3 检查是否被托管

```bash
ls -la /etc/resolv.conf                              # 软链接？
cat /etc/cloud/templates/resolv.conf.tmpl 2>/dev/null # cloud-init 会重写？
systemctl is-active systemd-resolved                   # active 则改 resolved.conf
```

### 4.4 验收（25 次采样）

```bash
python3 -c "
import subprocess,statistics
ts=[]
for i in range(25):
    r=subprocess.run(['curl','-s','-o','/dev/null',
      '-w','%{http_code} %{time_total} %{time_namelookup}',
      '--max-time','15','https://<target>'],capture_output=True,text=True)
    p=r.stdout.split()
    if len(p)==3:
        ts.append(float(p[1]))
        print(f'{i+1:2d} HTTP={p[0]} total={p[1]}s dns={p[2]}s')
print()
print('median=',round(statistics.median(ts),3),'max=',round(max(ts),3))
print('>2s:',sum(1 for x in ts if x>2))
"
```

本次实测：改前 max=10.69s、>2s 4次/25次；改后 max=0.63s、>2s 0次。
**真正验收看第二天日报**：超时错误条数降到个位数才算修好。

## 五、与 journalctl 版本兼容的关联坑

`journalctl --since @0 -n 1` 在部分版本（Ubuntu 24 / systemd 255+）返回**最新**一条而非最早一条。
用于判断 journal 保留期时会造成永久误报"保留不足 24 小时"。

正确写法：问"窗口起点之前有没有记录"，不依赖 `-n` 的排序行为：

```python
rc, out, _ = run(['journalctl','-q','--no-pager','-o','json',
                  '--since','@0','--until','@'+str(int(start)),'-n','1'])
if rc:
    gaps.append('journal最早留存时间未核实')
elif not out.strip():
    gaps.append('journal保留不足24小时，统计仅含留存部分')
```

验证：`journalctl --since @0 --until @$START -n 1 | wc -l`，`> 0` 即保留足够。

## Pitfalls

- `time_connect` 慢就查 TCP：先看 `time_namelookup`，或 `--resolve` 固定 IP 排除 DNS。
- 改完只测一次报成功：DNS 丢包是概率事件，25 次采样才有意义。
- 只改 `nameserver` 不加 `options timeout:1`：丢包时仍等 5s。
- `sudo cp` 到 `/root` 失败就放弃备份：改用 `/home/ubuntu/`。
