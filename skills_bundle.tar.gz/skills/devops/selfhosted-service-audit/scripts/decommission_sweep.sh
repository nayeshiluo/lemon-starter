#!/usr/bin/env bash
# decommission_sweep.sh — 服务退役前的只读残留扫描
#
# 用途：停用/下线一个常驻服务之前，先把「它还在哪些地方被引用」一次列全。
#       只读，不改任何东西。查完按 SKILL.md 7.3-c 的七类落点逐项清理。
#
# 用法：
#   bash decommission_sweep.sh <服务名关键词> [巡检配置目录] [巡检脚本目录]
# 例：
#   bash decommission_sweep.sh pojai
#   bash decommission_sweep.sh astrbot /etc/naye-protection /usr/local/libexec/naye-protection
#
# 远端跑法（超长 inline 会被拦，先落盘再传）：
#   ssh host 'bash -s' -- <关键词> < <(cat decommission_sweep.sh)

set -uo pipefail
NAME="${1:?用法: $0 <服务名关键词> [巡检配置目录] [巡检脚本目录]}"
CONF_DIR="${2:-/etc/naye-protection}"
SCRIPT_DIR="${3:-/usr/local/libexec/naye-protection}"

hit() { printf '  HIT  %s\n' "$*"; }
sec() { printf '\n=== %s\n' "$*"; }

echo "扫描关键词: $NAME"
echo "时间: $(TZ=Asia/Shanghai date '+%Y-%m-%d %H:%M:%S %Z')"

sec "1. 巡检 JSON 配置（services / critical_files / code_file_minimums）"
if [ -d "$CONF_DIR" ]; then
  for f in "$CONF_DIR"/*.json; do
    [ -f "$f" ] || continue
    if grep -q "$NAME" "$f" 2>/dev/null; then
      hit "$f"
      grep -n "$NAME" "$f" 2>/dev/null | sed 's/^/         /'
    fi
  done
else
  echo "  (目录不存在: $CONF_DIR)"
fi

sec "2. 巡检脚本里硬编码的专属检查（最易漏）"
if [ -d "$SCRIPT_DIR" ]; then
  grep -rn "$NAME" "$SCRIPT_DIR" --include='*.py' --include='*.sh' 2>/dev/null \
    | sed 's/^/  HIT  /' || echo "  (无)"
else
  echo "  (目录不存在: $SCRIPT_DIR)"
fi

sec "3. systemd 单元引用（含 Before=/After=/Wants=/Requires= 排序声明）"
grep -rl "$NAME" /etc/systemd/system/ 2>/dev/null | sed 's/^/  HIT  /' || echo "  (无)"

sec "4. timer / cron"
systemctl list-timers --all --no-pager 2>/dev/null | grep -i "$NAME" | sed 's/^/  HIT  /' || echo "  (无 timer)"
for u in $(id -un) root; do
  crontab -l -u "$u" 2>/dev/null | grep -i "$NAME" | sed "s/^/  HIT  [$u cron] /"
done
grep -rl "$NAME" /etc/cron.d /etc/crontab 2>/dev/null | sed 's/^/  HIT  /' || true

sec "5. 自启残留（@reboot / supervisor / rc.local / profile.d）"
for u in $(id -un) root; do
  crontab -l -u "$u" 2>/dev/null | grep -i '@reboot' | grep -i "$NAME" | sed "s/^/  HIT  [$u] /"
done
ls /etc/supervisor/conf.d/ 2>/dev/null | grep -i "$NAME" | sed 's/^/  HIT  /' || true
grep -l "$NAME" /etc/rc.local /etc/profile.d/* 2>/dev/null | sed 's/^/  HIT  /' || true

sec "6. 运行态残留"
systemctl is-active "$NAME" 2>/dev/null | sed 's/^/  is-active: /'
systemctl is-enabled "$NAME" 2>/dev/null | sed 's/^/  is-enabled: /'
pgrep -f "$NAME" 2>/dev/null | head -5 | sed 's/^/  pid: /' || echo "  无进程"
ss -tlnp 2>/dev/null | grep -i "$NAME" | sed 's/^/  port: /' || true

sec "7. docker"
docker ps -a --format '{{.Names}}\t{{.Status}}' 2>/dev/null | grep -i "$NAME" | sed 's/^/  HIT  /' || echo "  (无)"

printf '\n扫描完成。清理顺序：先删巡检项 → 验巡检跑出 issues:[] → 再停服务 → 最后处理数据目录。\n'
