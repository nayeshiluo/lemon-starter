#!/bin/bash
# 跨机排查：这台机器有没有 InstaCloud / InstaBox 的部署面与凭据。
# 只读；只打印路径、权限、变量名，绝不回显 key 值。
# 用法（本机）: bash fleet_insta_trace_sweep.sh
# 用法（远端）: ssh <host> 'bash -s' < fleet_insta_trace_sweep.sh
echo "### HOST: $(hostname) $(date -u +%FT%TZ)"
echo "-- cli"
for c in insta instabox instacloud; do p=$(command -v "$c" 2>/dev/null); [ -n "$p" ] && echo "  FOUND $c -> $p"; done
echo "-- npm global"
command -v npm >/dev/null 2>&1 && npm ls -g --depth=0 2>/dev/null | grep -iE "insta" | sed 's/^/  /'
echo "-- config dirs"
ls -d /root/.config/insta* /root/.insta* /home/*/.config/insta* /home/*/.insta* /opt/insta* /srv/insta* 2>/dev/null | sed 's/^/  /'
echo "-- binaries"
ls -l /usr/local/bin/ 2>/dev/null | grep -iE "insta" | sed 's/^/  /'
echo "-- systemd units mentioning insta"
grep -rilE "instacloud|api\.insta" /etc/systemd/system /root/.config/systemd /home/*/.config/systemd 2>/dev/null | head -10 | sed 's/^/  /'
echo "-- env files with INSTA vars (names only)"
for f in /etc/environment /root/.bashrc /root/.profile /home/*/.bashrc /home/*/.profile /etc/profile.d/*.sh; do
  [ -f "$f" ] || continue
  grep -hoE "^(export +)?[A-Z0-9_]*(INSTA|INSTACLOUD|INSTABOX)[A-Z0-9_]*" "$f" 2>/dev/null | sed "s|^|  $f: |"
done
echo "-- shell history mentions"
for h in /root/.bash_history /home/*/.bash_history /root/.zsh_history /home/*/.zsh_history; do
  [ -f "$h" ] || continue
  n=$(grep -ciE "instacloud|insta (deploy|service|compute|secrets)|npx -y insta" "$h" 2>/dev/null)
  [ "${n:-0}" -gt 0 ] && echo "  $h: $n hits"
done
echo "-- instabox api key files (path + mode only)"
for f in /etc/instabox/api.key /root/.config/instabox-api.key /root/.ib/api_key* /home/*/.config/instabox-api.key /home/*/.ib/api_key*; do
  [ -f "$f" ] && echo "  $f mode=$(stat -c %a "$f") mtime=$(stat -c %y "$f" | cut -d. -f1)"
done
echo "-- instabox lease units"
systemctl list-units --all --no-pager 2>/dev/null | grep -i instabox | sed 's/^/  /'
echo "### END"
