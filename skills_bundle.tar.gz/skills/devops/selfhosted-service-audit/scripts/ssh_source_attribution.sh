#!/usr/bin/env bash
# ssh_source_attribution.sh <SOURCE_IP> [SINCE] [UNTIL]
#
# 在「收到登录的那台机器」上跑，只读。回答一个问题：
#   这个来源 IP 到底是谁？是我们自己的工具链，还是陌生人？
#
# 判据顺序（便宜 → 决定性）：
#   1. 成功登录用了哪把 key（fingerprint + 用户）
#   2. 该 fingerprint 对应 authorized_keys 里哪一条（注释名常直接写明工具/用途）
#   3. 对应私钥在不在本机（不在 = 外部机器持有）
#   4. 它进来执行了什么（sudo COMMAND + PWD）—— 这一步才是定案证据
#   5. 并发特征（同一秒多条 Accepted = 并行编排器，人手不会这样）
#
# ⚠️ IP 归属地/ASN 只作提示，不作结论。误报就出在拿城市名当证据。
# ⚠️ SINCE/UNTIL 用本机时区写法（如 "2026-11-03 23:30"），不是通告里的 UTC 字符串。
#
# 出口基线要另在每台机上跑：curl -s https://ipinfo.io/ip

set -uo pipefail
IP="${1:?usage: ssh_source_attribution.sh <SOURCE_IP> [SINCE] [UNTIL]}"
SINCE="${2:-7 days ago}"
UNTIL="${3:-now}"

echo "### 来源归属 $IP   窗口: $SINCE → $UNTIL   采样: $(TZ=Asia/Shanghai date '+%F %T %Z')"

echo
echo "-- 1. 成功登录：用户 + 算法 + 指纹前 16 位（按次数排序）"
JQ=(journalctl -u ssh --since "$SINCE" --until "$UNTIL" --no-pager)
sudo -n "${JQ[@]}" 2>/dev/null | grep -F "$IP" | grep "Accepted" \
  | sed -E 's/.*Accepted publickey for ([a-zA-Z0-9_.-]+).*ssh2: ([A-Z]+) SHA256:([A-Za-z0-9+\/=]{16}).*/\1 \2 \3/' \
  | sort | uniq -c | sort -rn

echo
echo "-- 2. 指纹 → authorized_keys 条目名"
for f in "$HOME/.ssh/authorized_keys" /root/.ssh/authorized_keys; do
  [ -r "$f" ] || sudo -n test -r "$f" 2>/dev/null || continue
  echo "   [$f]"
  sudo -n ssh-keygen -lf "$f" 2>/dev/null | nl -ba -s'  ' | sed 's/^/     /'
done

echo
echo "-- 3. 本机是否持有对应私钥（空 = 外部机器持有该 key）"
for k in "$HOME"/.ssh/* "$HOME"/.keys/* /root/.ssh/*; do
  [ -f "$k" ] || continue
  case "$k" in *.pub|*known_hosts*|*config*|*authorized_keys*) continue;; esac
  fp=$(sudo -n ssh-keygen -lf "$k" 2>/dev/null | awk '{print $2}')
  [ -n "$fp" ] && echo "     $fp  $k"
done 2>/dev/null | sort -u

echo
echo "-- 4. 该来源进来执行了什么（sudo COMMAND 去重计数，PWD 一并保留）"
sudo -n journalctl _COMM=sudo --since "$SINCE" --until "$UNTIL" --no-pager 2>/dev/null \
  | grep "COMMAND=" \
  | sed -E 's/.*PWD=([^ ]*) ; USER=([^ ]*) ; COMMAND=/\2 \1 /' \
  | cut -c1-110 | sort | uniq -c | sort -rn | head -15

echo
echo "-- 5. 并发特征（按分钟聚合，单分钟 >=3 条 = 并行编排器）"
sudo -n "${JQ[@]}" 2>/dev/null | grep -F "$IP" | grep "Accepted" \
  | awk '{print $1,$2,$3}' | cut -c1-12 | sort | uniq -c | sort -k2

echo
echo "-- 6. 反面证据（这些为空才算清白）：新增用户 / authorized_keys 改动 / 凭据文件读取"
echo -n "     passwd mtime: "; stat -c '%y' /etc/passwd 2>/dev/null
echo -n "     authorized_keys mtime: "; stat -c '%y' "$HOME/.ssh/authorized_keys" 2>/dev/null
echo "     (另查: 无外联下载、无 eval/exec 注入、无新增 systemd unit —— 见 SKILL.md 第五节)"
echo "### END"
