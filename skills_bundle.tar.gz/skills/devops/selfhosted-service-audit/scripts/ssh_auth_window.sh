#!/bin/bash
# 安全通告的事件窗口：核查这台机器的 SSH 成功/失败登录。
# 只读；输出只有计数、IP、key 指纹，不含任何密钥内容。
#
# 用法:
#   bash ssh_auth_window.sh 2026-11-03T15:30:00Z 2026-11-03T15:35:00Z
#   ssh <host> 'bash -s' -- 2026-11-03T15:30:00Z 2026-11-03T15:35:00Z < ssh_auth_window.sh
#
# 关键点：日志是「本地时间」，通告是 UTC。脚本先用 date -d 把 UTC 窗口换算成本机本地
# 时间字符串再过滤；直接拿 UTC 字符串 grep 会筛到错误时段（实测 +08:00 主机会差 8 小时）。
set -u
SINCE_UTC=${1:-}
UNTIL_UTC=${2:-}
if [ -z "$SINCE_UTC" ] || [ -z "$UNTIL_UTC" ]; then
  echo "usage: $0 <SINCE_UTC> <UNTIL_UTC>  e.g. 2026-11-03T15:30:00Z 2026-11-03T15:35:00Z" >&2
  exit 2
fi

LS=$(date -d "$SINCE_UTC" +%Y-%m-%dT%H:%M 2>/dev/null)
LE=$(date -d "$UNTIL_UTC" +%Y-%m-%dT%H:%M 2>/dev/null)
if [ -z "$LS" ] || [ -z "$LE" ]; then
  echo "date -d failed; this host may lack GNU date (busybox?). Compute local window manually." >&2
  exit 3
fi

echo "### HOST: $(hostname)  tz=$(date +%z)  local_window=${LS}..${LE}  utc_window=${SINCE_UTC}..${UNTIL_UTC}"

LOG=""
for f in /var/log/auth.log /var/log/secure; do [ -r "$f" ] && LOG="$f" && break; done

if [ -n "$LOG" ]; then
  echo "-- $LOG accepted in window (user + source IP)"
  awk -v s="$LS" -v e="$LE" 'substr($0,1,16)>=s && substr($0,1,16)<=e && /Accepted/' "$LOG" \
    | sed -E 's/.*Accepted ([a-z]+) for ([^ ]+) from ([0-9a-fA-F.:]+).*/\2 \3/' \
    | sort | uniq -c | sort -rn | head -20
  echo "-- key fingerprints used in window"
  awk -v s="$LS" -v e="$LE" 'substr($0,1,16)>=s && substr($0,1,16)<=e && /Accepted/' "$LOG" \
    | grep -oE 'SHA256:[A-Za-z0-9+/=]+' | sort | uniq -c | sort -rn | head -10
  echo "-- failed in window (per source IP)"
  awk -v s="$LS" -v e="$LE" 'substr($0,1,16)>=s && substr($0,1,16)<=e && /Failed password|Invalid user/' "$LOG" \
    | grep -oE 'from [0-9a-fA-F.:]+' | sed 's/^from //' | sort | uniq -c | sort -rn | head -5
  echo "-- last 7d accepted sources (top 8)"
  grep Accepted "$LOG" | sed -E 's/.* from ([0-9a-fA-F.:]+) .*/\1/' | sort | uniq -c | sort -rn | head -8
else
  echo "-- no readable auth.log; journalctl fallback"
  journalctl -u ssh -u sshd --since "$SINCE_UTC" --until "$UNTIL_UTC" --no-pager 2>/dev/null \
    | grep -E 'Accepted|Failed' | tail -20
  echo "-- note: classic syslog ('Nov  3 15:30') does not match the ISO prefix filter above;"
  echo "   for such hosts filter by month/day string instead, or use 'last -F'."
fi
echo "### END"
