# 外部暴露面审计（公网视角，不登宿主机）

审计「这个域名安不安全」时，视角与 `SKILL.md` 正文相反：正文是从宿主机往里看（systemd/日志/DB），
这份是从公网往外看（DNS → 边缘 → 应用端点）。两者互补，不能互相替代。

---

## 0. 授权闸门（第一步，不是可选项）

用户说「攻击一下 X 域名 / 打一下这个站」时：

1. **先拒绝攻击本身**，一句话说明违法性，不要长篇说教。
2. **给三条合法替代**：自有资产做只读健康检查 / 评估防护水平 / 已授权测试出计划。
3. 用户回「自有或已授权」后才继续，且只做**低强度只读**：单线程、带 sleep、不爆破、不压测、不提交写请求。
4. 归属仍不明时（例如域名刚注册、套着 CF、无明显自有特征），**继续做被动层并把判断摊给用户**，别默认它真是他的。
   本次实录：域名 8 天前刚注册、全 CF 代理、无 MX —— 这类特征通常是一次性/钓鱼站，
   结果查出来是用户自己的 Emby 反代节点。所以**先问再判，不要用特征给用户扣帽子**。

不要因为用户说了「安全测试」四个字就自动开扫。授权范围和目标要一句话确认。

---

## 1. 被动层（完全不接触目标服务器）

```bash
dig +short <host> A; dig +short <host> AAAA
dig +short <zone> NS; dig +short <zone> MX
whois <zone> | head -40
curl -s --max-time 25 "https://crt.sh/?q=%25.<zone>&output=json" | head -c 3000
```

判读：

| 特征 | 含义 |
|---|---|
| A 记录落在 `104.16-31.x` / `172.64-71.x` | Cloudflare Anycast，源站被隐藏 |
| NS 为 `*.ns.cloudflare.com` | DNS 全托管 CF，无第三方解析线索 |
| `Creation Date` 距今 < 30 天 | 新注册，一次性/临时站或新上线节点 |
| 无 MX | 不收邮件，通常不是正经企业站 |
| `clientTransferProhibited` + 无 DNSSEC | 默认锁定，未做 DNSSEC 加固 |

⚠️ `crt.sh` 的 JSON 端点**可能返回 404 或 HTML**（编码/负载问题）。
**读不到 ≠ 没有子域**，不能当作「无子域」的证据。换 URL 形式或改用其他 CT 源，拿不到就写「未核实」。

---

## 2. 指纹层

```bash
UA="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/<YOUR_SERVER_IP> Safari/537.36"
curl -sS -o /dev/null -D - --max-time 15 -A "$UA" "https://<host>/" | head -40
echo | timeout 15 openssl s_client -connect <host>:443 -servername <host> 2>/dev/null \
  | openssl x509 -noout -subject -issuer -dates -ext subjectAltName
```

要点：

- **证书 `notBefore` ≈ 部署/上线时间**。CF 通用证书 90 天自动续，看到「今天刚签」说明是新建或刚续期的节点，不是异常。
- **`cf-ray` 后缀是边缘机房三字码**（`CDG` 巴黎 / `SIN` 新加坡 / `HKG` 香港），可判断落地位置，但不是源站位置。
- **不带浏览器 UA 会被 CF BIC 拦成 `403 error code: 1010`**，别误判成站点故障。
- 首页 HTML 的 `<html data-appversion="...">` 和 `<meta name="description">` 常常直接写明产品与版本。

---

## 3. 后端类型判别（看 404 的 body，不看状态码）

```bash
curl -sS --max-time 15 -A "$UA" "https://<host>/__nope__"
```

| 404 body | 后端 |
|---|---|
| `{"ResponseStatus":{"ErrorCode":"NotFound","Message":"Resource not found."}}` | Emby / Jellyfin 原生 API 格式 |
| 纯 HTML + `server: cloudflare` | CF 边缘 404（路由不存在），不是应用 404 |
| 短 JSON 且能在代码里搜到 | 自研中间层 |

**Emby 原生格式 + 根路径 200 → 反代是「全量透传」**，没有路径白名单，
意味着所有公开端点和后台入口都直接暴露在公网。这一条决定了后面第 5 节的检查清单。

---

## 4. 安全响应头六查

```bash
curl -sS -o /dev/null -D - --max-time 12 -A "$UA" "https://<host>/" 2>/dev/null \
  | grep -iE "content-security|x-frame|x-content-type|referrer-policy|permissions-policy|strict-transport|server"
```

| 头 | 缺失后果 |
|---|---|
| `Strict-Transport-Security` | 可被 SSL stripping（本次已开，✅） |
| `Referrer-Policy` | **媒体服务器上的头号高危**，见下 |
| `X-Frame-Options` / CSP `frame-ancestors` | 后台可被 iframe 套壳 → 点击劫持管理员 |
| `X-Content-Type-Options: nosniff` | MIME 嗅探 |
| `Permissions-Policy` | 摄像头/麦克风等能力默认放开 |

只有 `server: cloudflare` 一行 = **反代层零安全头**。CF 默认不注入这些，必须自己加 Transform Rule。

### Emby 特化：`Referrer-Policy` 为什么最要命

Emby 支持 `?api_key=<token>` 走 **URL 查询参数**传令牌（不是只用 header）。令牌因此会出现在
地址栏、浏览器历史、以及**发往第三方域名的 `Referer` 头**里。页面只要加载任何外部资源
（CDN 脚本、海报外链、统计像素），令牌就泄给第三方。

`Referrer-Policy: no-referrer` 一条头就能堵死，零功能影响。

---

## 5. Emby / 媒体服务器端点暴露表

```bash
for p in "emby/System/Info/Public" "System/Info/Public" "emby/Users/Public" \
         "Users/Public" "emby/System/Info" "web/index.html"; do
  printf "/%s -> " "$p"
  curl -sS -o /tmp/r -w "%{http_code} %{size_download}b\n" --max-time 12 -A "$UA" "https://<host>/$p"
  head -c 300 /tmp/r; echo; sleep 1
done
```

| 端点 | 期望 | 判读 |
|---|---|---|
| `/System/Info/Public` | 200 | **设计如此，无需认证**。但会报出版本、`OS=linux`、`ServerId` → 给攻击者做版本对号 |
| `/Users/Public` | 200 `[]` | ✅ 已禁用公开用户列表（有加固意识）；**返回非空数组 = 用户列表外泄** |
| `/System/Info` | 401 `Access token is invalid or expired` | ✅ 鉴权正常 |
| `/web/index.html` | 200 | 后台入口公网直达 → 登录爆破面，必须上速率限制 |
| `/Users/AuthenticateByName` | POST | 爆破主入口，WAF 限速重点 |

`ServerId` 是稳定标识：同一实例换域名后 ServerId 不变，可用于跨域名把多个入口归并到同一源站。

---

## 6. 版本真实性核验（本次最大发现，通用手法）

自报版本号可以造假或来自魔改构建。**拿官方发布列表对一遍**：

```bash
curl -sS --max-time 25 -H "Accept: application/vnd.github+json" \
  "https://api.github.com/repos/MediaBrowser/Emby.Releases/releases?per_page=20" \
  | python3 -c "
import json,sys
for r in json.load(sys.stdin):
    print(f\"{r['tag_name']:<18} {'pre' if r['prerelease'] else 'STABLE':<7} {r['published_at']}\")
"
```

同类软件换仓库即可（Jellyfin / *arr / Navidrome 都有 releases API）。

判读（本次实录，2026-10-24）：

- 目标自报 `<YOUR_SERVER_IP>`；
- 官方列表：最新稳定 `<YOUR_SERVER_IP>`（2026-10-20）、最新 beta `<YOUR_SERVER_IP>`（2026-10-23）；
- **`<YOUR_SERVER_IP>` 不在列表里**。

结论口径（严格按事实说话）：

> 该版本号在官方发布记录中不存在，属于未公开发布的构建，**无法用官方发布记录核对补丁状态**。

⚠️ **不要写成「确认是破解版」**。可能性有多种：私发构建、灰发版本、版本号被改过、破解版。
只能报「来源未核实」，并把「换成官方稳定版」作为建议而非命令。

⚠️ **版本不在官方列表时，CVE 版本区间对比同时失效**。搜索到的
`CVE-2025-64113`（影响 `<<YOUR_SERVER_IP>`）、`CVE-2025-64325`（RCE，影响 `<<YOUR_SERVER_IP>`）
按版本号看都在目标之下，但既然版本号本身不可信，这个对比就不能当结论用，只能标为「仅供参考」。

⚠️ **NVD 页面经常只返回标题、正文抓不到**（本次 `web_extract` 只拿到 `NVD - Home`）。
这种情况只能标「仅搜索摘要，未读到原文」，**不能算已核实**，也不要把摘要写进「已验证」段落。

---

## 7. 加固建议（只加头/限速，不动路由）

按性价比排序，全部不碰现有节点、不改路径、不碰凭证：

1. **CF Transform Rule 加响应头**（零风险）
   `Referrer-Policy: no-referrer`、`X-Content-Type-Options: nosniff`、`X-Frame-Options: SAMEORIGIN`
2. **WAF 速率限制登录端点**：`/web/index.html`、`/Users/AuthenticateByName`，10 次/分钟/IP
3. **抹掉版本指纹**：WAF 改写 `/System/Info/Public` 响应里的 `Version` 字段为固定值
4. **核实构建来源**：非官方渠道装的，建议换官方稳定版（魔改版的后门风险远大于缺几个响应头）

改 CF 需要带 Rules/Transform 权限的 API Token，**只读 Token 改不了**；没有就让用户自己在面板点，
我们负责把规则内容写全并事后复验响应头。

---

## 8. 报告格式（本次用户接受的形态）

1. 一句结论：**认证面干净 / 问题在反代层和版本来源**（把"哪里没问题"也说清楚，别只列问题）
2. 采样时间（实测，带时区）
3. 已验证事实表：项 / 结果 / 判定（✅⚠️❌ 三档）
4. 真问题按风险排序，每条说清「为什么」和「修起来多大动静」
5. 加固清单按性价比排序，标明哪些是零风险纯新增
6. 末尾**证据范围**：原文已读 / 仅搜索摘要 / 未核实（含失败原因如 403、正文为空）

---

## 本次实测基线（2026-10-24 22:19–22:30 CST，只读）

| 项 | 值 |
|---|---|
| 目标 | `c1.thxnk.cc`（用户自有 Emby 反代节点） |
| 边缘 | Cloudflare，`cf-ray` 后缀 `CDG`/`SIN` |
| 证书 | GTS `WE1`，`CN=thxnk.cc`，SAN 含 `*.c1.thxnk.cc`，当天签发 |
| 应用 | Emby `<YOUR_SERVER_IP>`，`ServerId=669777fb494d472d`，`OS=linux` |
| 鉴权 | `/System/Info` 401 ✅；`/Users/Public` = `[]` ✅ |
| 安全头 | 仅 `server: cloudflare`，六项全缺 ❌ |
| 版本核验 | `<YOUR_SERVER_IP>` 不在官方 releases 列表（稳定 `<YOUR_SERVER_IP>`）⚠️ |
| 通配子域 | `*.c1.thxnk.cc` 存在（多租户/节点分发特征） |
