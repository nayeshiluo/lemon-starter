# 全量项目下线清理（跨机/含入口与历史残留）

适用：用户要求“彻底删除某项目/站点”，不只是停服务。先只读盘点再分批删除，每批验收。

## 1. 盘点范围（先证据后动作）
- **运行宿主**：容器/compose 项目、镜像残留、systemd unit/timer、监听端口、数据/配置/证书/备份/zip、监控探针与状态文件。
- **本机运维链路**：续签/部署脚本（如 acme `--deploy` scp+reload）、告警桥接（SSH 拉远端状态发通知）、crontab/Hermes jobs、状态日志与 state。
- **入口与外部**：DNS 记录、反代/隧道路由、域名证书存储。
- **引用残留**：其他项目的 provision/rollback/acceptance 脚本、旧部署备份目录、维护快照文本、记忆/技能/文档中的硬编码域名与路径。

命令思路：`find /opt /srv /home -iname '*<key>*'`、`docker ps -a | grep`、`systemctl list-units --all | grep`、`crontab -l`、`ss -ltnp`、`grep -rl '<domain>' /opt /etc /home`（限定范围、排除大目录与敏感输出）。

## 2. 删除顺序与验收
1. **远端服务侧**：停用删除 timer/service → 各 compose `down --remove-orphans --volumes`（含变体 compose）→ 清理残留同名容器 → 删除项目目录/zip/历史备份 → 验证 `docker ps -a`、`ls`、`systemctl`、`ss -ltnp` 无残留。
2. **本机运维侧**：备份 crontab 后移除相关行 → 删除脚本、ACME/证书缓存、告警桥与探针、日志/state/pyc → 验证 crontab 与文件路径。
3. **入口**：删除/核实 DNS 记录（按实际 zone/token 权限操作，记录删了哪条）。
4. **引用与历史**：清理其他项目中指向已删网关/容器的回滚与部署脚本、旧 backup 目录、维护记录中的容器名快照；必要时同步记忆。改脚本时避免留下失效命令（如 `docker exec <已删容器>`）。
5. **终验**：两端 `grep -rn '<key>|<domain>'`（限定业务路径）确认无活跃依赖；告警源/定时器已断。说明仅剩审计/对话历史日志等不可变记录（若未清）。

## 3. 注意
- “删除”与“停服务待巡检清理”不同：彻底删除要含 DNS、续签、告警桥、跨项目硬编码与历史备份痕迹。
- 破坏性命令需当次明确授权；分批执行并保留关键输出作为证据。
- 不要臆造“已无任何痕迹”；无法访问的远端/权限外位置如实标未核实。