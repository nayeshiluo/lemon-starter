# 实例：用户所称「Capy 影厅」身份判定与迁移归属（2026-10-27，只读）

场景：旧 AWS 整机迁新机，旧机所有服务不能停/改。用户口头说"copy 面板 = Capy 影厅"，
要求确认它**实际部署在哪、依赖什么、迁移时归谁**。约束极严：只读、不部署、不迁移、
不读 Env/库/凭据/会话、不发真实媒体或模型请求、不暴露 IP 与内部端口。

## 1. 身份判定链（最有价值的部分）

历史线索给的是 `happy-capy`、`happy-capy-web`、`happy-capy-share-{backend-1,web-1,auth}`、
`happy-capy-guard`、`pansou` —— 但**这些只是候选，不是结论**。真正的判据是运行中容器提供的页面标题：

```bash
# 网关容器：登录页标题
sudo grep -o "<title>[^<]*</title>" \
  /proc/$(docker inspect -f '{{.State.Pid}}' happy-capy-web)/root/usr/share/nginx/html/login.html
# → 「登录 · Capy 影厅」

# 分享前端：首页标题
sudo grep -o "<title>[^<]*</title>" \
  /proc/$(docker inspect -f '{{.State.Pid}}' happy-capy-share-web-1)/root/usr/share/nginx/html/index.html
# → 「Capy 影廳」
```

两个标题是**简/繁两种写法**，来自前后端两套页面 → 同一个产品，不是两个部署。
配合 nginx `server_name`（品牌同名域名）与 6 个容器的 `happy-capy` 命名，判定 `confirmed / high`。

## 2. 与 workbuddy2api（腾白嫖）的区别 —— 五维对照

| 维度 | Capy 影厅 | workbuddy2api |
|---|---|---|
| 运行形态 | Docker / compose | systemd 原生进程 |
| 单元/项目 | `happy-capy`、`happy-capy-share` | `workbuddy2api.service` |
| 运行身份 | 容器 uid 10001 / nginx 101 / root | 专用用户 `workbuddy2api` |
| 工作目录 | 容器挂载 | `/var/lib/workbuddy2api` |
| 共享挂载/镜像 | 无 | 无 |

结论：**不同部署，不可合并**。但 `happy-capy-web` 的 nginx 有一条 upstream 经
`ss -lntp` → `/proc/<pid>/cgroup` 归因到 `workbuddy2api.service` → **存在单向运行时依赖**。
所以正确表述是"身份不同 + 一条依赖边"，而不是"两个无关服务"或"其实是同一个"。

## 3. 只读采集口径（可复用清单）

- `docker ps --format` 只取 `names/image/status`；`inspect` 只取 `mounts / workingdir / compose config_files / project+service labels`。
  **绝不 dump `Config.Env`、`Args`、`Cmd`**（Compose 项目里这些常带密钥）。
- 存储只 `stat` + `du -s -x`（分配字节，非表观大小），**不打开业务库**。
- nginx 只提取 `server_name`、监听端口分类、proxy 目标类别；**内部回环端口号脱敏**。
- `systemctl show -p ...` 取状态，不 `cat` unit 全文（`Environment=` 可能带凭据）。

## 4. 本次实测到的迁移归属结论

| 组件 | 归属 |
|---|---|
| happy-capy / guard / share(backend+web) / web / share-auth | **留 vps-la 原位**，迁移动作=0，只纳入备份 |
| workbuddy2api | 独立归属，不属 Capy；但若迁移须与 Capy 网关同批（先建后拆） |
| pansou | 同机共置，未证实为 Capy 依赖 → 不纳入范围 |
| 旧 AWS crontab：`capy-acme.py`（周一 04:23）、`happy-capy-alert-bridge.py`（每分钟） | **必须新机接管**；先建后拆，禁止双跑 |
| `happy-capy-watch.timer` | 留 vps-la，新机不得重复实现 |
| DNS | 不切（运行时未移动） |

## 5. 风险与缺口（报告里必须显式写）

- `happy-capy-web`、`happy-capy-share-auth` **无 compose 标签** = 手工 `docker run`，编排不可复现 → 最高风险。
- `happy-capy` 镜像**无 tag**（`docker ps` 显示短 ID），只能按 digest 固定。
- `happy-capy-share-auth` 以 **root** 跑 Node 服务。
- **未发现任何自动备份**：`/var/backups`、`/root`、`/opt` 命名路径皆无；无 capy/backup 定时器；
  仅 `*-share.zip`（源码快照）与 `monitor/`（监控状态）。
- 同名 `capy_backend.db` 出现在两个 mount，mtime 差三周 → 权威性未定，快照两处都取。
- 引擎 SQLite（`_sqlite3`/`libsqlite3` 已加载 + `.db`/`.sqlite3` 文件名 + `traffic.sqlite3` 正在写），**未打开库**。

## 6. 交付形态

`<audit_dir>/capy-theater-readonly-20261027.{json,md}`，均 `600`。
JSON 保留原始证据 + `final_report` 汇总段（身份/宿主/容器/存储/依赖/备份/控制链/归属/未确定/证据边界）；
MD 是给人读的 195 行版本。交付前跑泄露扫描（IP 字面量、secret 样式、非公网端口号），
并回读权限位证明。

## 7. 本次踩到的两个工具坑

1. `yaml.safe_load(compose)` → `ConstructorError`（`!reset` / `!override`）。改 `yaml.BaseLoader`。
2. 用"猜键名"的模板从 JSON 生成 MD → `KeyError: 'path'`，因为 `files_stat_only` 是嵌套结构。
   先 `json.dumps(..., indent=1)[:1200]` 看形状再写模板。
