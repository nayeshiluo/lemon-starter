# restic + rest-server 配额链：`507 Insufficient Storage` 全链排查

2026-11-06 实测。适用形态：源机用 restic 备份，经 `rest://` 推到一台 rest-server（常经 SSH 隧道），
`--append-only` + `--max-size` 配额 + 无 prune。

## 症状

用户收到两条 Telegram 告警（间隔 4 分钟，两个不同来源）：

```
❌【数据保护巡检】 - 异地备份超过 75 分钟没有成功更新     09:16:25
❌【异地数据保护】 naye 异地仓库超过 75 分钟没有收到新快照   09:20:06
```

`systemctl status` 看着都正常，业务 bot 日志里一条相关记录都没有 —— **因为告警不是 bot 发的**。

## 第一步：定位发送方（不要先翻 bot 日志）

```bash
grep -rl "数据保护巡检" /home/ubuntu --include="*.py" --include="*.sh"   # 空 = 不在脚本目录
systemctl list-timers --all | grep -iE 'protect|backup'
```

命中：

```
naye-protection-health.timer   每分钟
naye-protection-backup.timer   每小时
naye-protection-restore.timer  每周日
```

阈值写死在脚本里：

```bash
systemctl show naye-protection-health -p FragmentPath -p ExecStart
sudo grep -nE "75|age>|forget|prune" /usr/local/libexec/naye-protection/health.py
# 24:    if age>4500:issues.append('异地备份超过 75 分钟没有成功更新')
```

`4500 s = 75 min`。**health 只负责报，根因在配套的 backup 单元。**

## 第二步：读 backup 单元的真实退出码

```bash
systemctl show naye-protection-backup -p Result -p ExecMainStatus -p ExecStart
```

关键陷阱：

```
Result=success          ← oneshot 正常结束，看着没问题
ExecMainStatus=1        ← 真实退出码是 1（失败）
```

**`Result=success` + `ExecMainStatus=1` 同时成立**，因为 unit 没设 `SuccessExitStatus`，
systemd 认为「单元正常结束」，而 `ExecMainStatus` 才是脚本退出码。**只看 `Result` 会漏掉真实失败。**

`journalctl -u naye-protection-backup` → `-- No entries --`（脚本自己写文件日志，不走 stdout）。
真实日志在：

```
/var/lib/naye-protection/last-backup.log
```

尾部：

```
Save(<data/c410522ade>) returned error, retrying after 4.755863245s:
    server response unexpected: 507 Insufficient Storage (507)
...
Fatal: unable to save snapshot: server response unexpected: 507 Insufficient Storage (507)
```

## 第三步：507 是服务端配额，不是本地磁盘

```bash
# repo 指向（只打印路径，不打印密码）
sudo python3 -c "
import re
for line in open('/etc/naye-protection/backup.env'):
    if line.startswith('RESTIC_REPOSITORY'):
        print('repo path:', re.sub(r'^rest:https?://[^/]+', '', line.split('=',1)[1].strip()))
"
# → repo path: /naye/core/

# 端口是隧道还是本地服务
sudo ss -ltnp | grep 27184
# → users:(("ssh",pid=280502,fd=4))          ← ssh -L，服务端在远端

sudo ps -p 280502 -o args= | sed -E 's/[A-Za-z0-9+/=]{30,}/<redacted>/g'
# → ssh -NT ... -L 127.0.0.1:27184:127.0.0.1:27184 naye-ingest@<host>

# 服务端单元里的配额
ssh <host> 'systemctl cat naye-rest-server.service | grep -oE "max-size [0-9]+"'
# → max-size <YOUR_USER_IDENTIFIER>                     ← 5 GiB

ssh <host> 'du -sh /var/lib/naye-restic/repositories/*; df -h /; df -i /'
# → 3.3G  naye
# → /dev/vda2 34G 25G 7.3G 78% /            ← 磁盘还剩 7.3G
# → inode 16%                                ← inode 也不是问题
```

rest-server **v0.14.0**，`--max-size int  the maximum size of the repository in bytes`。

## 关键矛盾与处理方式

`du` 显示 repo 3.41 GiB，配额 5 GiB，理论上不该触发；但 `--max-size` 提到 6 GiB 后**同一份数据立刻写成功**。

**结论：闸门确实在配额上，rest-server 的计数口径与 `du` 不一致（可能含索引/临时写入），未能定位到确切口径。**

处理原则：**不要花时间读源码算准它**。做一次可控改动验证假设即可：

```bash
# 1) 备份 unit
ssh <host> 'sudo cp -a /etc/systemd/system/naye-rest-server.service \
    /etc/systemd/system/naye-rest-server.service.bak-maxsize-$(date +%Y%m%dT%H%M%S)'
# 2) 改配额（5 GiB → 6 GiB），注意 grep 时 -oE 的 pattern 别被 shell 吃掉
ssh <host> 'sudo sed -i "s/--max-size <YOUR_USER_IDENTIFIER>/--max-size <YOUR_USER_IDENTIFIER>/" \
    /etc/systemd/system/naye-rest-server.service'
ssh <host> 'grep -oE "max-size [0-9]+" /etc/systemd/system/naye-rest-server.service'
# 3) 重载并重启
ssh <host> 'sudo systemctl daemon-reload && sudo systemctl restart naye-rest-server'
# 4) 立刻重跑一次备份
sudo /usr/bin/python3 /usr/local/libexec/naye-protection/backup.py
```

成功输出：

```json
{"finished_at":"2026-11-06T01:40:11Z","sqlite_sources":42,"postgres_dump_validated":true,
 "restic_summary":{"files_new":246,"files_changed":123,"files_unmodified":26052,
 "data_added":<YOUR_USER_IDENTIFIER>,"total_bytes_processed":<YOUR_USER_IDENTIFIER>,"total_duration":21.1,
 "snapshot_id":"9997dc51"},"tag":"hourly"}
```

## 第四步：验证 health 真的转绿（不看服务 active）

```bash
sudo systemctl start naye-protection-health.service
sudo cat /var/lib/naye-protection/health.json
```

```json
{"backup_age_seconds": 77, "repository_pack_bytes": <YOUR_USER_IDENTIFIER>,
 "issues": [], "external_notices": [], "sampled_at": "2026-11-06T01:41:31Z"}
```

同时看告警文件是否变成恢复文案：

```bash
sudo cat /var/lib/naye-protection/alerts/current.txt
# → ✅【数据保护巡检】此前报告的保护链路异常已恢复。
```

**验收三件套**：`backup_age_seconds` 很小 + `issues: []` + `alerts/current.txt` 是恢复文案。
只看服务 `active` 或收到一条「已恢复」都不够。

## 结构性缺口（必须一起报给用户）

```bash
grep -rn 'forget\|prune' /usr/local/libexec/naye-protection/   # 空
head -1 /usr/local/libexec/naye-protection/backup.py            # "no production repair/prune"
systemctl list-units --all | grep -iE 'prune|forget'            # 空
```

**每小时备份 + `--append-only` + 固定配额 + 无 prune = 周期性撑爆**，提配额只是止血。

按实测数据折算：29 个 hourly 快照涨到 3.6 G，平均 ~124 MB/h；6 GiB 只能再撑约 20 小时。

三个选项（都要用户点头，删快照不可逆）：

| 方案 | 性质 | 代价 |
|---|---|---|
| 服务端 `restic forget --keep-hourly 24 --keep-daily 7 --keep-weekly 4 --prune` | 根治 | `--append-only` 下只能在服务端以 root 直接操作 repo；删快照不可逆 |
| hourly 降频到每 3 小时 | 治标 | 减半增速，RPO 变差 |
| 再提配额 | 治标 | 宿主仅剩 7.3 G，最多 ~7 G，只多撑一天 |

## 顺带记下的环境事实

- 密钥材质：`/etc/naye-protection/backup.env` 里 `RESTIC_REPOSITORY` 含明文口令，
  **打印时必须脱敏**（只输出 path 或 host）。
- `RESTIC_PASSWORD_FILE` / `RESTIC_CACHE_DIR` 也在同一 env 文件；prune 需要 root 读它。
- 源机侧有本地 rollback 副本 `/home/ubuntu/backups/restic-before-staging-maintenance-<date>/`，
  内含 `repository/`（3.6 G，维护前完整副本）+ `restore-check/` + `verification.json`
  （`state: ALL_DATA_VERIFIED`）。**这个目录不能当缓存删** —— 它是回滚路径。
  判断方法：先读同目录的 `maintenance-result.json` / `verification.json`，再决定动不动。
