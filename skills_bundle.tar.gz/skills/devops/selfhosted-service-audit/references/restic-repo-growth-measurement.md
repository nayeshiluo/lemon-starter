# restic 仓库增长的正确测量法

## 触发

用户问「备份会不会越来越臃肿 / 配额够不够 / 要不要改备份脚本」，
或你打算给出「需要改 `backup.py` / 需要改备份范围」这类结论之前。
**先按本文测一遍，再下结论。**

## 三个坑（2026-11-06 同一次会话里全踩了，两次结论都错）

1. **用单次 `data_added` 推稳态。** 错。手动跑的那次、以及紧跟 `prune` 之后的那次，
   `data_added` 会异常偏高（实测 258 MB、420 MB），而正常定时那次只有 2 MiB 量级。
   拿 258 MB × 24 去推「每天 6 GB」，会得出完全错误的结论，进而误判「必须改备份逻辑」。
2. **用 `restic ls` 只比文件大小。** 错。会漏掉「大小相同但内容变了」的文件，
   于是出现「staging 只变 30 MiB，却报 258 MB 新增」的假矛盾，误判有未知增长源。
   **必须比 `content` 字段。**
3. **用跨越大段人工操作的快照对当样本。** 改代码、建 `.bak-*`、跑 prune 都会污染数据。
   要选两个**纯定时、无人工介入**的相邻快照。

## 正确做法：比 content hash，不比 size

`restic ls --json <snap>` 每个 node 带 `size` 和 `content`（内容块的 sha256 列表）：

```python
def ls(snap):
    p = subprocess.run(['/usr/bin/restic', 'ls', '--json', snap],
                       capture_output=True, text=True, env=e, timeout=1200)
    out = {}
    for line in p.stdout.splitlines():
        if not line.startswith('{'):
            continue
        r = json.loads(line)
        if r.get('struct_type') != 'node' or r.get('type') != 'file':
            continue
        out[r['path']] = (r.get('size') or 0, tuple(r.get('content') or ()))
    return out

a, b = ls(snap_a), ls(snap_b)
added   = {k: v for k, v in b.items() if k not in a}
resized = {k: b[k][0] - a[k][0] for k in a if k in b and a[k][0] != b[k][0]}
# 关键一项：大小没变但内容变了（只有它能解释「数据在涨、文件没变大」）
rewrite = [(a[k][0], k) for k in a
           if k in b and a[k][0] == b[k][0] and a[k][1] != b[k][1]]
```

实测（naye，2026-11-06）：

| 区间 | 内容变化 | 新增文件 | 说明 |
|---|---|---|---|
| 07:00→08:00（纯定时） | 2.1 MiB | 0.0 MiB | **稳态 ≈ 2.2 MiB/小时** |
| 09:39→10:12（33 分钟，手工） | 2.4 MiB | 0.3 MiB | 同量级 |
| 19 小时（含大量改码 / `.bak` / prune） | 32.7 MiB | 55.3 MiB | 合计 88 MiB |
| `rewrite`（大小同、内容变） | **0 个文件** | — | 证明不存在「隐性全量重传」 |

稳态 ≈ 53 MiB/天，6 GiB 配额够 60 天以上。**不要因为一次 258 MB 就宣布要改 `backup.py`。**

## 顺带验证：staging 全量重写本身不产生重复上传

`sqlite3.backup()` 对**未变化**的源库是确定性的 —— 连续两次 backup 到不同文件，
sha256 完全相同（实测 `ai_usage.db` / `music_cache.db` / `cron/executions.db` 三个全对）。
所以「每轮把几十个库全量复制到 `staging/`」这件事本身不制造重复 blob，增长来自源库真实变化。
**怀疑 staging 之前先跑这个 5 行实验，能省掉一次错误改造。**

```python
def snap(src, dst):
    s = sqlite3.connect('file:' + src + '?mode=ro', uri=True, timeout=20)
    d = sqlite3.connect(dst)
    s.execute('BEGIN'); s.execute('SELECT name FROM sqlite_schema LIMIT 1').fetchone()
    s.backup(d, pages=512); d.close(); s.close()
    return hashlib.sha256(open(dst, 'rb').read()).hexdigest()
# snap(src, a) == snap(src, b)  →  确定性成立
```

## 长耗时 prune 的跑法

`restic prune` 在几 GB 的库上会超过前台命令超时。不要在前台硬等，也不要反复重试超时命令：

```bash
ssh host 'setsid nohup bash /tmp/prune.sh >/dev/null 2>&1 </dev/null & echo STARTED'
ssh host 'tail -3 /tmp/prune.log; pgrep -c restic || echo 0'    # 轮询
```

脚本末尾追加 `echo "PRUNE_RC=$?" >> /tmp/prune.log`，轮询到 `PRUNE_RC=` 出现即完成。
这种方式不受前台超时限制，也不占交互会话。

`restic check` 同理；只需抽检时用 `--read-data-subset=10%` 把耗时压到几十秒。

## 汇报口径：两件事必须分开说

- **快照数量** —— 由保留策略（`forget --keep-*`）控制
- **数据体积** —— 由 `backup_paths` 里「每次全量复制」的东西决定；
  prune 只能回收**未被任何保留快照引用**的 pack

实测反例：31→25 个快照，repo 只从 3.6 G 降到 3.43 G（增量快照数据高度重叠，
删掉的 6 个没有独有数据）。**说「prune 已根治」是错的**，只能说「快照数量已受控」。

真正的体积改善只有三条路，且都要用户点头：降频、缩小 `backup_paths`、提配额。
改 `backup.py` 属于核心备份逻辑，风险与收益必须一起摆出来，不要自行决定。

## 一个常见误判：把「单次大 `data_added`」当成新增长源

看到 `data_added` 几百 MB、而 `ls` 只显示几十 MB 变化时，第一反应常是
「有隐藏的全量重传」。先做三件事再下结论：
① 换成 `content` 比对（本文主表）；② 选一个纯定时的相邻快照重测；
③ 确认那次备份前后有没有跑过 `prune` 或大量文件操作。
三项都排除后，才可以说「存在未解释的增长」。
