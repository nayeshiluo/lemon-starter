# CPU 跑飞与孤儿进程取证

适用：机器 load 偏高、卡顿、用户问「CPU 为什么占用这么高」，或内存排查中发现
`kcompactd`/`kswapd` 累计时间异常。目标是定位到**具体 PID + 根因**，不是给一句「负载较高」。

## 一、定位顺序：累计 CPU 时间 > 瞬时 %CPU

`ps` 的 `%CPU` 是**进程整个生命周期的平均值**，不是当前值。一个刚启动的进程瞬时打满也只显示几个百分点，
一个跑了 30 天的进程即使现在满载也可能被平均稀释。所以**先按累计 CPU 时间排序**：

```bash
# times = 累计 CPU 秒数，这是找长期跑飞进程的唯一可靠排序键
ps -eo times,pcpu,pid,user,etimes,comm --sort=-times | head -12
```

判据：拿第一名的 `times` 和 `etimes`（存活秒数）对比。
`times/etimes` 接近 1.0 = 单核一直满载；接近核数 = 多核满载。

实证（2026-10-30，2 vCPU 机）：第一名 `times=214625`、`etimes=219252` → 比值 0.98，
一个进程独占整整一核；第二名 `mtproto-proxy` 跑了 29 天才累计 63477 秒。
**差一个数量级就是它**，不用再看别的。

瞬时值用 `top` 取两轮（第一轮是启动以来均值，必须丢弃）：

```bash
top -b -n2 -d3 | grep -A8 '^%Cpu'
vmstat 5 3        # 第一行是开机以来均值，只看后两行；r 列=运行队列
```

`vmstat` 的 `r` 列比 load average 直观：`r` 持续 > 核数就是 CPU 排队。

⚠️ **load average 是 1/5/15 分钟指数衰减值**。杀掉进程后 1 分钟值要几分钟才落下来，
15 分钟值还会拖十几分钟旧账。**别用 load 当即时验收指标**，用 `vmstat` 的 `r` 和 `id`。
验收要么等 5~6 分钟再采样，要么同时给出两个口径并说明衰减特性。

## 二、孤儿进程判定（终端早断了还在烧 CPU）

三条证据齐了才能叫孤儿：

```bash
# 1) cgroup 落在用户会话 scope，而不是任何 *.service
tail -1 /proc/<pid>/cgroup        # 0::/user.slice/user-0.slice/session-<N>.scope
# 2) 那个会话已经断开
loginctl show-session <N> | grep -iE 'state|active|remote|leader|timestamp'
#    State=closing + Active=yes 的组合 = 终端走了、scope 里还有进程赖着
# 3) 父进程链走到 PID 1（原 shell 已死，被 systemd 收养）
ps -o pid,ppid,user,lstart,args -p <pid> --no-headers
```

`loginctl list-sessions` 里一堆 `closing` 状态的 root 会话是常态；要紧的是
**里面还有没有活进程**。没有活进程的 closing scope 无害，不用处理。

补充取证：`ls -l /proc/<pid>/fd` 看它当前卡在哪个文件上——这一条往往直接给出根因。

## 三、本类事故的头号根因：全盘 grep 递归进 /proc

**这是 agent 自己最容易造的事故，必须记住。**

```bash
# ❌ 会卡死整核，永不退出
grep -rn 'keyword' / 2>/dev/null | grep -vE '^/(proc|sys|var/lib/docker)'
```

错在哪：管道后面那个 `grep -v` **只过滤输出，拦不住遍历**。`grep -r` 照样会走进
`/proc/<pid>/task/<tid>/pagemap`、`/proc/kcore` 这类内核伪文件。`pagemap` 是按进程地址空间
动态生成的、长度近乎无限，`grep` 会在内核里无限刷页，CPU 100% 且永远读不完。

实证：一次 2096 端口排查里的 `grep -rn rules-admin /` 卡在 `/proc/<pid>/task/<tid>/pagemap`
（`/proc/<pid>/fd/3` 正指在那里），SSH 会话当天就断了，进程成孤儿连烧 **2 天 12 小时 54 分 /
累计 59.6 小时 CPU**，才被下一次巡检发现。

```bash
# ✅ 正确写法二选一
grep -rn 'keyword' / --exclude-dir={proc,sys,dev,run} 2>/dev/null | head -20
grep -rn 'keyword' /etc /opt /home /usr/local 2>/dev/null | head -20   # 更优：限定目录
```

铁律：**排除必须写在 `grep` 自己的参数里，不能靠下游管道。** 同理适用于
`find /`（用 `-xdev` 或 `-path /proc -prune`）、`du -sh /`、`tar -C /`。
一次性只读巡检也要加 `timeout`：`timeout 120 grep -rn ... --exclude-dir={proc,sys,dev}`。

## 四、清理：先复核身份，再 SIGTERM

```bash
# 杀之前重新确认一遍每个 PID 的 cmdline + cgroup（PID 会复用，取证与动手之间可能隔了几分钟）
for p in <pids>; do
  printf '%s :: ' $p
  tr '\0' ' ' < /proc/$p/cmdline 2>/dev/null | cut -c1-110
  printf ' | cg='; tail -1 /proc/$p/cgroup 2>/dev/null
done
```

- **先 `kill -TERM`，不要直接 `-9`**。本例 6 个进程（跑飞的 grep 管道 3 个 + 同期零 CPU 的
  `bash -c` 空壳 3 个）全部 SIGTERM 正常退出，`-9` 完全没用上。
- 杀完 `sleep 3` 逐个 `[ -d /proc/$p ]` 验证真的没了，不要只看命令退出码。
- **只杀 `user.slice/...session-*.scope` 里的孤儿**。落在 `*.service` 里的一律不动——
  那是 systemd 托管的服务，走 `systemctl` 和授权流程。
- 累计 CPU 为 0 的残留 `bash -c` 壳子无害，可以顺手清，但要在报告里和真正的元凶分开写。

## 五、授权与 deny 规则的坑

本次实录：把 `kill` 和受保护控制入口的服务名**写进同一条命令**（只是想顺手确认它没受影响），
直接被 `approvals.deny` 拦下，整条命令作废。

**教训：取证命令和清理命令分开发。** 不要在带 `kill` 的命令里拼受保护服务的名字做"顺手核对"，
deny 规则匹配的是整条命令文本，不管你的意图是只读。

清理孤儿进程属于影响面可控的动作，但**仍要先把根因和影响范围讲清楚、拿到用户一句确认**再动手
（本例用户回「修复他」即为明确授权）。

## 六、和内存结论的交叉影响

一核长期满载会把内存侧指标也带歪，别倒因为果：

- `kcompactd` 累计 44 分钟、`kswapd0` 8 分钟 → 看着像内存压力，实际是 CPU 满载加剧了回收路径。
- 杀掉跑飞进程后 `free` 从 105 MiB 升到 391 MiB、`available` 833 → 934 MiB，**但 Swap 已用量
  1.53 GiB 不变**——冷页不会自己换回来，这是正常现象，不是"没修好"。
- `si/so` 接近 0 就不能说"在频繁换页"，哪怕 Swap 已用 1.5 GiB。

## 七、报告口径

1. 一句话给根因 + 具体 PID + 累计消耗（`214625 秒 ≈ 59.6 小时`，两个口径都给）。
2. 采样时间实测并标时区；远端机常是 `Etc/UTC`，报北京时间要换算并写明两个口径。
3. 是自己造成的就直接说"是我留下的"，不绕。本例根因就是 agent 三天前的巡检命令。
4. 修复前后各给一组同口径数据（`us/id`、`r`、load 三元组），load 要注明衰减特性。
5. 结尾写清**没动什么**：业务进程、容器数量、受保护控制入口均未变更。
