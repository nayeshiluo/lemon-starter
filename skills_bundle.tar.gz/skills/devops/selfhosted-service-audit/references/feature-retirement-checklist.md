# 功能下线 / 退役一个模块（不是停服务，是拆掉一块能力）

用户说「这个功能可以关掉了 / 检测那部分删了吧 / 额度播报不用了」时走这份清单。
**与「停一个服务」不同**：服务还在跑，只是其中一块能力要消失。删不干净的代价比停服务更高 ——
服务照常 active、日志干净，但菜单里还挂着入口、按钮点了没反应、定时任务继续发消息。

实测案例（2026-11）：退役 LemonOps 的「反重力 Gemini 额度播报 + 账号恢复探测」。

## 八个可见落点（漏一处就等于没删）

| # | 落点 | 漏掉的后果 |
|---|---|---|
| 1 | `import`（`from quota_module import get_xxx_text`） | 启动即 `ImportError`，整个 bot 起不来 |
| 2 | 函数本体（`async def xxx_command` / `def get_xxx_text`） | 死代码，下轮审计误判「仍在线」 |
| 3 | `CommandHandler` 注册行 | 命令仍然响应 |
| 4 | `BotCommand("xxx", ...)` 云端菜单 | **客户端斜杠列表里还显示**，用户以为没删 |
| 5 | `callback_data` 分支（`elif data == "m:xxx":`） | 按钮变死键，点了静默无反应 |
| 6 | 键盘按钮定义（主菜单 / 子面板 `InlineKeyboardMarkup`） | 入口还在，点进去报错或空白 |
| 7 | 面板文本拼接（`+ get_xxx_text() +`）与帮助/引导文案 | 面板仍渲染旧模块，帮助仍教用户去用 |
| 8 | systemd unit / timer / 独立脚本 / 模块文件 | 定时任务继续跑、继续发消息、继续烧额度 |

第 4 和第 7 是最容易漏的两处：它们不在 `main.py` 的主逻辑里，一个在 `post_init` 的
`set_my_commands`，一个在 f-string 拼接串中间。

## 执行顺序

代码面优先，调度面其次，最后才动文件：

1. 删 / 改 1–7 → `python3 -m py_compile main.py`
2. `systemctl disable --now <feat>.timer`（两个都停：日报 + 探测）
3. `systemctl stop <feat>.service`（oneshot 可能仍 pending）
4. `mv` unit、`*.service.d/` drop-in、独立脚本、模块文件到归档目录
5. `systemctl daemon-reload` + `reset-failed`
6. 重启主服务，确认 `InvocationID` 变了、日志零 `traceback`

## 归档而非删除

```bash
ARCH="<项目>/backups/retired-<功能名>-$(date +%Y%m%d%H%M%S)"
mkdir -p "$ARCH"
# unit / drop-in / 脚本 / 模块一起搬
sudo mv /etc/systemd/system/<feat>.{service,timer} "$ARCH"/
sudo mv /etc/systemd/system/<feat>.service.d "$ARCH"/ 2>/dev/null
mv <项目>/<feat>_module.py "$ARCH"/
chown -R <owner>:<owner> "$ARCH"
```

汇报里**必须给出这个路径** —— 用户随时能捞回来，比 `rm` 安全，也让「删了什么」可审计。

## 离线验收：不开 Telegram、不靠用户点按钮

```python
import os, sys
os.chdir("<项目>"); sys.path.insert(0, ".")
os.environ["<该 bot 的必需启动变量>"] = "<值>"     # 见下「import 前置」
import main

# ① 函数与模块引用清零
assert not hasattr(main, "xxx_command")
assert not hasattr(main, "get_xxx_text")

# ② 主菜单 / 子面板键盘里没有残留按钮
labels = [b.text for row in main.get_main_keyboard().inline_keyboard for b in row]
assert not any("Gemini" in t or "额度" in t for t in labels), labels

# ③ 面板仍能正常渲染，且不再含旧段落
txt = main.get_system_status_text()
assert len(txt) > 100 and "Gemini" not in txt

# ④ 源码级：回调与命令名彻底消失
src = open("main.py", encoding="utf-8").read()
for dead in ('"m:quota"', "m:gemini_probe", "quota_command"):
    assert dead not in src, dead
```

再补两条系统级确认（离线脚本管不到）：

```bash
systemctl list-units --all --plain | grep -iE '<功能关键字>'   # 期望：无
systemctl list-timers --all --no-pager | grep -iE '<功能关键字>' # 期望：无
crontab -l | grep -iE '<功能关键字>'                            # 期望：无
```

## `import main` 的三个前置（否则验收脚本自己就崩）

1. **项目内没有 `.venv` 时不要猜解释器** —— 读 `systemctl cat <unit> | grep ExecStart`，
   用 unit 里那个 venv 的 python（本环境是 `~/.hermes/hermes-agent/venv/bin/python3`）。
2. **模块级校验变量必须补**：很多 bot 在 import 期检查公网域名/密钥，缺了直接
   `RuntimeError`（如 `sub_module.py` 要求 `SUB_PUBLIC_BASE_URL` 是显式 https origin）。
   从 unit 的 `Environment=` 抄一份，在脚本里 `os.environ[...] = ...`。
3. **不要 `cd /tmp` 跑**：`/tmp` 里的杂项 `.py` 会遮蔽标准库（`inspect.py` 之类），
   一律 `cd <项目>` 再跑。

## 菜单生效与客户端缓存

重启后日志出现 `Telegram bot commands set successfully` 即云端菜单已覆写。
客户端可能仍显示旧条目（本地缓存），提示用户「重进对话即可」——
**不要为此再改一次代码或反复重启**，那不是 bug。

## 汇报口径

三段，缺一段用户就会怀疑你砍多了：

1. **移除了哪 N 处**（列落点名，不要只说「已关闭」）
2. **归档路径**（可恢复）
3. **哪些能力是保留的** —— 例如退役 Gemini 额度播报时，`/check` 通用端点自检、
   模型热切换都保留，只是删掉了 Gemini 那一项。

用户最怕的从来不是「没删掉」，而是「顺手把别的功能一起砍了」。
