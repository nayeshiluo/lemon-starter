# 第三方平台安全通告核查（vendor breach triage）

适用：收到云/SaaS 供应商“凭据可能泄露”的通告，需要判断我们是否中招、要不要轮换。
首次实战：2026-11-03 InstaCloud（InsForge）事故，2026-11-04 核查。

## 1. 先分清产品线（最容易错的一步）

| 产品 | API | 形态 | “环境变量”指什么 |
|---|---|---|---|
| InstaCloud | `api.instacloud.com` | Serverless compute service / 托管数据库 | 每个 service 的 Variables（含自动生成的 `DATABASE_URL`、`REDIS_URL`、`MYSQL_PRIVATE_URL` 等） |
| InstaBox | `api.instabox.sh` | Firecracker 微 VM 沙箱 | 机器级 `secrets` / `envSecrets` / `directSecrets` / org Secrets / Vault |

两家同属 InsForge，但控制面、凭据、事故面都分开。**不要因为都叫“计算”就套用同一个结论。**

## 2. 平台侧只读核查（InstaBox API key 可做）

```python
# 读取 key 文件，不把 key 放命令行
import json, urllib.request
key = open("/home/ubuntu/.config/instabox-api.key").read().strip()
def get(path):
    req = urllib.request.Request("https://api.instabox.sh" + path,
                                 headers={"X-API-Key": key})
    return json.load(urllib.request.urlopen(req, timeout=30))
```

| 端点 | 看什么 | 判读 |
|---|---|---|
| `GET /v1/machines` | id/name/state/runStartedAt/updatedAt/cooldownUntil | 事件窗口内是否有状态变化 |
| `GET /v1/machines/{id}/secrets` | `secrets`、`envSecrets`、`directSecrets`、`items`、`version` | 全 `[]` = 平台侧没有环境变量可泄露 |
| `GET /v1/machines/{id}/vault` | `enabled`、`items`、`applied.env`、`applied.files` | `applied` 全空 = Vault 没投递任何东西 |
| `GET /v1/orgs/{orgId}/secrets` | `items` | 0 条 = org Secrets 为空 |
| `GET /v1/machines/{id}/ssh-tokens` | 每个 token 的 `id/name/createdAt/expiresAt` | 只应出现本人创建的；新 token 才是异常 |
| `GET /v1/snapshots` | `snapshots` | 0 个 = 没有额外导出磁盘的动作 |
| `GET /v1/machines/{id}/logs?tail=5000` | `console` 文本 | 事件窗口应只有 `/balloon/statistics` |
| `GET /v1/machines/{id}/ports` | `access`（public/private）、url | 确认公网暴露面 |

**API key 不能访问的登录态路由**（一律 `403 permission_denied`，不要循环重试）：

- `/v1/keys`（API key 管理）
- `/v1/sessions`（登录会话）
- `/v1/vault`（用户级 Vault）

需要这些时向用户要控制台会话或只读 token。

## 3. 控制台日志判读

`GET /v1/machines/{id}/logs?tail=5000` 返回 Firecracker 客户机 console，通常覆盖最近 2–3 天。

- 例行：`Get /balloon/statistics` 每分钟一条。
- 平台例行：`Put /snapshot/create`、`Put /snapshot/load`、`Patch /vm {"state":"Paused"}`、`Patch /network-interfaces/eth0`（限速），一般每 6–8 小时一轮。
- **控制面 API 的读取（列机器、读 secrets）不会出现在这个 console 里**。所以“console 没有 exec”只能证明客户机侧没被操作，不能证明控制面没被读；必须和“secrets 全空 + 无新 token/快照”合起来判断。
- `runStartedAt`/`updatedAt` 每 480 分钟（`maxRunMinutes`）刷新一次，是免费档例行重启，不是攻击或平台补救。

## 4. 客户机内取证（只读）

```bash
# 平台投递的 secrets：只有 4 行 CA 路径 = 没有真实凭据
cat /run/instabox/secrets/env
# 期望（无 Secrets 时）：
#   export SSL_CERT_FILE=/run/instabox/...
#   export REQUESTS_CA_BUNDLE=...
#   export CURL_CA_BUNDLE=...
#   export NODE_EXTRA_CA_CERTS=...

# 关键文件时间：atime 是否落在事件窗口
stat -c '%n mtime=%y atime=%x' \
  ~/monitor-agent/agent.env ~/ib-panel/tokens.json \
  ~/.qb_autoresume.json ~/sb/config.json ~/.ssh/id_*

# 面板审计（JSON lines）
grep '<YYYY-MM-DD>' ~/ib-panel/audit.log

# 用户级服务 / 监听端口 / 登录会话
systemctl --user list-units --type=service --all --no-pager
ss -ltn
who; last -a 2>/dev/null | head
```

注意：
- atime 会被后续正常读取覆盖（服务启动、定时脚本、你自己的取证），**只能作辅助证据**。
- 无 root 时 `/var/log/auth.log` 通常不可读；`journalctl --user` 往往没有持久化记录。拿不到就写“未核实”，不要写“无异常”。

## 5. 2026-11-03 InstaCloud 通告实查记录（基线）

通告内容：2026-11-03 15:30–15:35 UTC，第三方用部署管道泄露的凭据访问 InstaCloud compute API，计算服务环境变量可能被读；要求轮换 DB 密码、第三方 API key、Webhook secret。

核查结果（两台 InstaBox，主 `agent-browser-xoel` / lab `agent-browser-zqwq`）：

| 项 | 结果 |
|---|---|
| 机器 `secrets` / `envSecrets` / `directSecrets` / `items` | 全 `[]` |
| Vault `applied.env` / `applied.files` | 全 `[]` |
| org Secrets（两个 org） | 0 条 |
| SSH token | 仅本人 3 个（10-23、10-29 创建），无新增 |
| 用户快照 | 0 个 |
| 事件窗口 console | 只有 `/balloon/statistics`；快照/网卡操作都在 11-01/11-02 例行时段 |
| `ib-panel` 审计 | 11-03 零请求（最后一条 10-29） |
| `/run/instabox/secrets/env` | lab 上 4 行，全是 CA 路径 |
| 文件 atime | 无 15:30 记录（`.qb_autoresume.json` 12:00 是例行读取） |

结论：按“环境变量被访问”这一向量，我们没有可泄露对象；InstaCloud 与 InstaBox 是两条产品线，本机也没有 `insta` CLI/配置。仍需用户确认是否在 InstaCloud 网页控制台建过项目（本机无 CLI ≠ 无账号）。

沙箱文件里真实存在、但不在平台环境变量里的凭据（仅在有 exec/登录证据时才按泄露处理）：
monitor token、ib-panel token、qB WebUI 密码、`id_qbmount`/`id_qbupload` 到 vps-la 的私钥、sing-box UUID、dsh lab 的 provider keys（`/data/workspace/.dsh/lab-providers.env`）。

## 6. 输出纪律

- 只打印变量名、长度、前缀；绝不打印值。
- 结论先行：先回答“我们是否在暴露面内”，再列证据，最后只留一个需要用户确认的问题。
- 不要把“没有某产品 CLI”写成“没有该产品账号/项目”；也不要把平台例行重启写成事故迹象。

## 7. 多机排查（fleet sweep）与登录窗口关联

用户问“其他几台机器呢”时，问题从“沙箱是否被读”升级为“整个机器群有没有该产品的部署面和异常登录”。分两步，都是只读。

### 7.1 先扫「有没有这个产品」

对每台可达机器跑 `scripts/fleet_insta_trace_sweep.sh`（`ssh host 'bash -s' < script.sh`）：

| 检查项 | 命中意味着 |
|---|---|
| `command -v insta` / `instabox` | 装过对应 CLI，需进一步看配置与历史 |
| `~/.config/insta*`、`~/.insta*`、`/opt/insta*` | 有客户端配置，可能存 token |
| systemd unit / `/etc/profile.d/*.sh` / `.bashrc` 里的 `instacloud\|api\.insta` | 有常驻消费者或注入的 key |
| shell history 里 `insta deploy/service/compute` 命中数 | 实际用过该产品 |
| InstaBox key 文件路径 + 权限 + mtime | 该机能否控制沙箱（这是真正的横向面） |

全部为空 = 该产品在机器群上没有部署面。这条结论优先于逐台分析登录窗口。

### 7.2 登录窗口关联

用 `scripts/ssh_auth_window.sh <SINCE_UTC> <UNTIL_UTC>`，它做三件事：

1. 把 UTC 窗口换算成**目标机本地时间字符串**（`date -d`），再过滤日志——远端 auth.log 常写本地时间，实测 diaomao 是 `+08:00`，直接拿 UTC 字符串 grep 会筛到完全错误的时段；
2. 成功登录按 `用户 + 源 IP` 与 `key fingerprint` 分组计数；
3. 失败登录单独按源 IP 计数，不与成功混算。

归属判据：

- 与本机/自动化出口一致（如 naye <YOUR_SERVER_IP>）→ 自有；
- 机场/代理 ASN（IKUUU `AS134972`、Nearoute `AS51847` 等）→ 多半是用户自己的出口，但要看 key 是否在 `authorized_keys` 里；
- 有授权 key 但出口不认识 → **待用户确认**，不要写成入侵；
- 无授权 key 的成功登录 → 才是真异常。

### 7.3 2026-11-03 InstaCloud 通告的多机实查结果

| 机器 | InstaCloud 痕迹 | InstaBox 凭据 | 窗口 15:30–15:35 UTC 成功登录 |
|---|---|---|---|
| naye（本机） | 无 `insta` CLI/配置/历史 | `~/.config/instabox-api.key`、`~/.ib/api_key_lab`（600） | **0 次**（<YOUR_SERVER_IP> 的登录在 15:24–15:28，窗口之前；见 7.4 更正） |
| vps-la | 无 | `/etc/instabox/api.key`（600 root）+ 两个 lease 守护 | 成功登录全部来自 <YOUR_SERVER_IP>（naye 自动化），窗口内无异常 |
| vps-hk | 无 | 无 | 仅 <YOUR_SERVER_IP> |
| diaomao | 无 | 无 | **0 次**（当天 10 次成功登录全来自 naye <YOUR_SERVER_IP>；窗口内仅 2 次 `debian` 爆破，七天 2318 次爆破零成功） |

结论：InstaCloud 通告在机器群上没有暴露面；InstaBox 的控制凭据只在 naye 与 vps-la 两处。

### 7.4 未知来源归属法：key 指纹 + 命令行为，不是 IP 归属地

**IP 地理位置只能提示，不能定性。** 本次实录：先把 `<YOUR_SERVER_IP>` 和 `<YOUR_SERVER_IP>` 报成可疑来源，
下一轮查完必须当场更正——前者在窗口**之前**，后者是用户自己的代理出口。误报根因就是拿 ASN/城市下结论。

五步归属链，从便宜到决定性：

```bash
# ① 指纹 → authorized_keys 条目名（注释常直接写明工具/用途）
ssh-keygen -lf ~/.ssh/authorized_keys | nl        # 与 auth.log 里的 SHA256:xxxx 对照
sudo ssh-keygen -lf /root/.ssh/authorized_keys     # root 侧单独看
# ② 私钥在不在本机（不在 = 外部机器持有该 key）
for k in ~/.ssh/* ~/.keys/*; do ssh-keygen -lf "$k" 2>/dev/null; done | grep <指纹前8位>
# ③ 出口基线：每台机自己的公网出口
for h in vps-la vps-hk diaomao; do echo -n "$h "; ssh $h 'curl -s --max-time 8 https://ipinfo.io/ip'; done
# ④ 决定性证据：它进来干了什么（PWD + 完整命令行）
sudo journalctl _COMM=sudo --since "<窗口前>" --until "<窗口后>" --no-pager \
  | grep "COMMAND=" | sed -E 's/.*COMMAND=//' | cut -c1-90 | sort | uniq -c | sort -rn | head
# ⑤ 并发特征：同一秒多条 Accepted = 并行编排器，人手不会这样
```

判读要点：

- **key 注释名就是证据**。`codex-naye-20261027` 直接说明是 Codex CLI 在用；`beszel-hub-*`、`github-actions-*` 同理。
  命名规范的自建 key 群让归属变成查字典，这也是当初坚持给每把 key 写用途的价值。
- **出口基线全不匹配 ⇒ 经代理入站**，不是「外部陌生机器」。用户在国内走代理时，所有出站（Codex 的 SSH、
  手机终端）会共用同一个代理落地 IP，看起来像同一台机器在操作。
- **命令行为 > 一切元数据**。跑 `hermes-admin read/status/logs`、`automation-observations.py`、
  `docker compose exec -T bot`、查自己项目的 sqlite、`cp /tmp/*.conf /etc/systemd/` —— 这是运维，不是入侵。
  入侵者不会去调你的服务管理脚本。
- 反面证据也要点明：零新增用户、零 `authorized_keys` 改动、零凭据文件读取、无外联下载。

### 7.5 结案记录：<YOUR_SERVER_IP>（2026-11-04）

| 项 | 结论 |
|---|---|
| 身份 | 用户自己的代理出口，`AS153371 BACK WAVES LIMITED`（洛杉矶） |
| 27 次成功登录构成 | 25 次 ubuntu + ECDSA `codex-naye-20261027`（Codex CLI 批量巡检）；2 次 RSA（`naye1` + root 无注释） |
| 25 次干了什么 | `hermes-admin read` 116 / `status` 58 / `logs` 58、`automation-observations.py` 58、`docker compose exec -T bot` 6、查 komari/smart-group sqlite |
| 2 次干了什么 | 11-03 15:16:59 登录，35 秒后 `cp /tmp/cliproxyapi-proxy.conf /etc/systemd/...`（PWD `/home/ubuntu/lemon-group-bot`）= 部署 CLIProxyAPI |
| 并发特征 | 每次 5 个并发连接、间隔 2–3 分钟，典型并行编排 |
| 四台机出口实测 | naye <YOUR_SERVER_IP> / vps-la <PRIVATE_IDENTIFIER> / vps-hk <PRIVATE_IDENTIFIER> / diaomao <YOUR_SERVER_IP>，均非该 IP ⇒ 代理入站 |
| 判定 | 自有操作，非入侵。上一轮的「待确认」与 naye 窗口内有登录两条结论均已更正 |

给用户的自我验证法（30 秒，不需要他记 IP）：开代理访问 `https://ipinfo.io`，看返回 IP 是否等于被问的那个。

### 7.6 用户说「不想换」时：给风险模型，不给复述

安全通告后用户回「我不想换哎，有其他办法吗」是常见且合理的反应。此时不要重复「建议轮换」，
按下面四点讲清楚，结论可以是「保持现状」：

1. **算可达路径，不算文件位置**。key 被读的前提是拿下持有它的机器的 root。若那些机器在事件窗口内
   0 次成功登录、爆破全失败，风险并没有因这条通告上升。文件在哪不构成独立风险。
2. **同一 key 的副本不叠加风险**。naye 与 vps-la 都是日常 root 登录的机器，删掉 naye 那份只减少文件数，
   不降低「攻破任一台即得手」的概率，反而让手动运维绕路——这是伪安全，该直接说。
3. **先查平台能力再谈替代方案**。InstaBox API key 无 IP 白名单、无过期时间、scope 固定五档，
   `keys create/rm` 只能在登录态操作 ⇒「限来源」根本做不到，所谓替代仍是「建新 key」换个说法。
   承诺平台没有的能力比不给方案更糟。
4. **已有守护能显形就别加巡检**。lease 守护每轮打印 `state`/`maxrun`/`expires`，机器被停、被改、被删会立刻暴露；
   此时明确答「不用加巡检」。

只有两种情形必须轮换：key 出现在不属于用户的机器上，或事件窗口内出现 exec/配置改动。

同理，主机 22 端口对公网开放、长期被爆破（diaomao 七天 2318 次失败）属于独立的加固项，
与本次通告分开报，不要混进「是否泄露」的结论。
