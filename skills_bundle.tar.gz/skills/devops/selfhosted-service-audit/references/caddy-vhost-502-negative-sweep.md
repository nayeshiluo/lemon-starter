# Caddy vhost 全站负向扫描（用户只给一张 502 截图时怎么定位）

2026-11-17 实录：用户只发来一张弹窗截图「服务器返回了异常状态码：502」，没给域名、没给操作。
本机是 naye，对外入口由 **Caddy** 承担（不是 6.3 节的 nginx 容器形态）。
需要一条能在「不知道是哪个站」时把本机整体排除掉的扫描法。

## 一、无目标时的正确顺序

1. **先做负向证明**：把本机所有对外 vhost 逐个打一遍，证明「本机没有 502」。
2. **再索取目标**：明确要「哪个 App / 哪个网址、点了哪个动作」。
3. 报告里写清「已排除的范围」，不要写成「应该不是我们的问题」。

不要在没有目标时反复猜服务名、翻一堆不相关日志 —— 那是白烧 token。

## 二、一条命令扫全 Caddy vhost

```bash
sites=$(grep -oE '^[a-z0-9.-]+\.[a-z]{2,} \{' /etc/caddy/Caddyfile | awk '{print $1}')
for s in $sites; do
  code=$(curl -sk -o /dev/null -w '%{http_code}' -m 8 \
    --resolve $s:443:127.0.0.1 https://$s/)
  echo "$code $s"
done
```

- **必须用 `--resolve` 指回 `127.0.0.1`**：强制走本机 Caddy，绕开 DNS / Cloudflare 边缘。
  这样命中 502 = 本机反代到上游那段断了；命中 200 = 本机这一跳没问题。
  （配合 `-k` 忽略证书，因为回环时 SNI 对得上但证书链可能不校验。）
- 实测输出：`200 aws / 302 beszel / 200 komari / 404 sgb / 410 dsh` —— 全站无 5xx，
  立刻可以判定「502 不在这台机器的反代链路里」。
- 404/410/302 **不是故障**：vhost 存在但该路径本就无内容（SPA 兜底、已退役站点）。
  别把 404 当断点，判据只看 5xx。

## 三、Caddy 侧两个必查坑

### 1）`journalctl -u caddy` 常常是空的 —— 不是没日志，是 Caddy 不写 journal

```
journalctl -u caddy --since '-6h' | grep -c ' 502 '   # 0
journalctl -u caddy --since '-6h' | tail               # -- No entries --
grep -n 'log' /etc/caddy/Caddyfile                    # 空 = 没有 log 指令
```

Caddy 的 access log 只有在 Caddyfile 里显式写了 `log` 或全局 `log` 块才会落文件/标准输出。
**没有 log 指令 ⇒ 根本没有访问日志可 grep**，不要因为 journal 干净就断言「没有 502」，
也不要花时间去翻 `/var/log/caddy/`（多数没建这个目录）。

要区分「日志为空」与「无故障」，只能靠主动探针（上面第二节）。

### 2）同一份 Caddyfile 可能存在两个进程

```bash
pgrep -a caddy
#   77637  caddy run --config /etc/caddy/Caddyfile --adapter caddyfile      ← 手工起的
#  524236  /usr/bin/caddy run --environ --config /etc/caddy/Caddyfile       ← systemd
ss -ltnp | grep -E ':443 |:80 '
```

systemd 那个（带 `--environ`）持有 80/443，手工那个没拿到端口但**也没退出**。
影响与处置：

- `systemctl restart caddy` 只影响 systemd 实例；手工实例可能在下一次端口释放时抢绑，
  出现「改完配置行为不对」的诡异现象。
- 报告里把它列为「待决策项」（清掉手工实例），不要在同一次只读巡检里顺手 kill —— 需要授权。
- 更隐蔽的变体：手工实例占着端口、systemd 实例反复失败。判据是
  `systemctl show caddy -p NRestarts -p ExecMainStatus` + `ss -ltnp` 里的 PID 是否属于该 unit。

## 四、顺手一起查的外围（都是 1 条命令）

```bash
systemctl --failed                        # 有没有 unit 直接 failed
docker ps -a --format '{{.Names}}\t{{.Status}}'   # 容器级（代理节点常是容器）
ss -ltn | grep -E ':<port> '              # 关键后端端口是否 LISTEN
```

本次实测：`lemon-node`(xray 8388/8443)、`lemon-tgmt`(2083)、`lemon-tgs5`(1080) 三个容器
Up 12 天，xray 日志持续打 `accepted tcp:...` 真实流量 —— 这类「容器 Up + 日志有真实转发」
才是代理组件健康的证据，光看 `Up` 不算。

## 五、定时同步类模块（IPv6 地址同步等）的健康三件套

用户问「某模块有没有出问题」时，别只看 `systemctl is-active`：

```bash
tail -30 <sync-ipv6.log>                       # 最近几轮是否都是 up to date
grep -iE 'error|fail|exception|timeout' <log> | tail -15
grep -c 'up to date' <log>                     # 成功轮次计数
cat <project>/status/*.state.json              # status / mismatch_count
```

判读（2026-11-17 实测）：

- 每轮 `naye/汤姆/admin: up to date (<addr>)` + `done, 0 user(s) updated` = 正常，
  `0 user(s) updated` 是「地址没变」而不是失败。
- 状态文件 `status: ok` / `mismatch_count: 0` 是更强的业务证据。
- 历史 `skip, resolve failed: expected one global AAAA, got []` / `HTTP 503` /
  `Network is unreachable` 这类**单点、且下一轮自动恢复**的错误，如实写「瞬时跳过、未写入错误数据」，
  不要报成待修项；但要把最近一次的时间点给出来（本次是 11-14 与 11-16 各一次）。