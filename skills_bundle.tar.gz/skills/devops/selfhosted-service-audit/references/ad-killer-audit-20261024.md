# Ad Killer 审计实例（2026-10-24）

用户原话："杀手机器人 你也审计一下"。对象 = Ad Killer（独立 Telegram 广告治理 bot），
不是运维 Bot（`lemon-ops.service`，上一轮已审）。

## 拓扑（审计前必须先搞清）

| 角色 | 位置 | 说明 |
|---|---|---|
| Ad Killer 主体 | **vps-la**（racknerd，<PRIVATE_IDENTIFIER>） | 2026-10-16 从 diaomao 迁来，`/opt/ad-killer` |
| 旧实例 | diaomao（<YOUR_SERVER_IP>） | `disabled` + `inactive`，文件仍在 `/opt/ad-killer` |
| AI 供给 | vps-la `127.0.0.1:18317`（`cpa-manager-plus`） | 模型 `gemini-3.5-flash-lite` |
| AWS 本机残留 | `ad-killer-ai-tunnel.service` | 反向 ssh 把本机 CPA 映射到 **diaomao** 的 18317，已无消费者 |

关键误判点：本机有 `ad-killer-ai-tunnel` 在跑，容易以为主体在 AWS。实际 `ExecStart` 指向 diaomao，
而 diaomao 的实例早就停了 → 这条隧道是迁移遗留的空转资源。

## 三个单元

- `ad-killer.service` — 主 bot（`python3 -B /opt/ad-killer/bot.py`）
- `ad-killer-cleanup-worker.service` — 删号账号清理 worker
- `ad-killer-profile-daily.timer` — 每日北京 05:30（UTC 21:30）画像复查，`profile_limit=50`、`avatar_limit=10`

## 实测数值（采样 2026-10-24 12:28:57 CST）

| 项 | 值 |
|---|---|
| Active | running，3h45m（北京 08:43 起） |
| Memory | 34.7M（systemd 口径 ≈ MiB）/ high 96M / max 160M，peak 35.8M |
| Tasks | 5 / 32 |
| CPU | 30% quota，累计 2m35s |
| 磁盘 | `/` 71%，剩 9.3G |
| state.db | 3.0 MB，`/var/lib/ad-killer/` |
| AI 探针 | HTTP 200 / 1.8s / model 回显 `gemini-3.5-flash-lite` |

## 稳定性结论

7 天启动 41 次，但真崩溃只有 **1 次**：10-21 03:41:57 UTC（北京 11:41）`status=1/FAILURE`
→ `Scheduled restart counter 1` → 03:42:10 再失败 → 03:42:20 起恢复，之后稳定。
其余全部是 `Stopping → Stopped → Starting` 成对的部署重启。

## 业务活性（从 events 表取证）

`events` 表列：`id, ts, chat_id, message_id, user_id, level, reason, action`
（**没有 `kind` 列**，用 `kind` 查会 `no such column`，白跑一轮）。

- 近 24h：`case_quarantined` 2、`admin_ad_deleted` 1、`case_banned` 1
- 近 7d：`case_quarantined` 5、`case_banned` 3、`admin_ad_deleted` 1、`admin_ad_delete_failed_or_uncertain` 1
- `cases.state` 枚举：`banned` 67、`protected` 7、`admin_rejected` 4、`simulated_ban` 5（**无 pending**）
- `quarantines` 状态：`converted` / `released`，当前 2 条生效中
- `snowflake_scan_members` 18,784

两个群策略不同：`<PRIVATE_IDENTIFIER>` = `observe`（只观察），`<YOUR_TELEGRAM_GROUP_ID>` = `review`（审核流）。

## 安全审计结论：干净

- 硬编码凭据扫描零命中；Telegram token 形态扫描零命中
- 凭据 `/etc/ad-killer/{bot-token,ai-key,config.json}` 全 600 root；unit 用
  `LoadCredential=bot-token:/etc/ad-killer/bot-token` + `Environment=AD_CONFIG=%d/config.json`
- `subprocess` 全 list 传参（`admission_release.py`、`health_snapshot.py`、`snowflake_cleanup_worker.py`），
  无 `shell=True`；唯一 `ast.literal_eval` 只解析会话文件字面量
- 鉴权：`getChatMember` 状态 ∈ {creator, administrator} + `delegated_admins.authorized()`
- 加固齐全：`CapabilityBoundingSet=`（空）、`ProtectSystem=strict`、`ProtectHome=yes`、`PrivateTmp`、
  `NoNewPrivileges`、`RestrictNamespaces`、`RestrictSUIDSGID`、`UMask=0077`
- 小瑕疵：`/opt/ad-killer/config.json` 644 world-readable（仅 owner_id/用户名/群 ID/base_url）；
  `/opt/ad-killer/state.db` 0 字节 root 644 空残留（真实库在 `/var/lib/`）

## 三条待决策项（按风险排序）

1. **无存活监控**：`grep -rl "ad-killer" /opt/monitor /usr/local/bin ~/hermes-jobs ~/lemon-ops-bot` 零命中。
   实证后果：diaomao 旧实例从 10-16 19:30 停到 10-24，7 天 17 小时无人发现。
   建议每 10 分钟查 `is-active` + `/var/lib/ad-killer/ai-worker-heartbeat.json` 新鲜度。
2. **无定时备份**：最后备份 10-21 部署时手工打的；AWS 离线加密备份只打包 `$HOME`，不含 vps-la `/opt`。
   `state.db` 3 MB 且持续增长（18,784 成员名册）。
3. **AWS 空转隧道**：diaomao 上 18317 零连接，引用只命中已停用实例的 config 与 test 脚本；
   隧道进程 21h 累计 `rchar 338865`（几乎全是 ssh 心跳）。
   背景：10-16 退役审计 `retirement_approved: false`，阻塞原因是"外部消费者未核实 + diaomao SSH 不通"。
   **该阻塞原因现已消除，但退役仍需用户明确点头。**

## 未验证 / 未深挖（报告里必须如实写）

- 未往群里发测试消息（避免打扰），"Telegram 端实时响应"是由事件表时间戳推断，非端到端实测。
- `ad-killer-profile-daily` 自报 `status: partial`、`coverage_complete: false`，但同一份输出
  `remaining_unchecked: 0`、`unavailable: 0`、`profile_attempts 19 / readable 19`，口径自相矛盾。
  疑似 `avatar_limit=10` 触发的标记，**未读代码确认，不下定论**。

## 环境备注

- vps-la 无 `sqlite3` CLI → 一律用 `python3` 的 `sqlite3` 模块
- vps-la 的 Monitor DB 表名是 `node`（单数），不是 `nodes`；`select ... from nodes` 会报 `no such table`
- `/opt/ad-killer` 不是 git 仓库（只有 `.github` 目录），版本管理靠 `/root/ad-killer-deploy-backups/*`
  手工目录，这也是一条隐性风险
