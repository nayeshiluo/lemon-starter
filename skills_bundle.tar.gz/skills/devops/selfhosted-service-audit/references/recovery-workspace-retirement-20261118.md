# 备份链审计补充：哈希复验退役细节与异地目标变更取证（2026-11-18 naye 实例）

> `backup-chain-audit` 已被 pin，后台无法写入；本文件挂在 selfhosted-service-audit 下，
> 其 SKILL.md 已加指针。若 curator 解除 backup-chain-audit 的 pin，应把这两节并入该技能。

## 一、恢复工作区退役：哈希复验后的分层删除时间表

补充 SKILL.md 指针之外的实操细节（2026-11-18 实测）：

1. **形态识别**：迁移/事故恢复目录里同一批数据以多重形态并存——原始加密档（`.hermesenc`）、
   认证后 tar、解密明文 tar（`.tar.zst`）、解包目录树、当时校验 JSON
   （`decryption-report.json` / `transfer-verified.json` / `extraction-verified.json`）。
   哈希复验通过 ⇒ 原始材料可靠 ⇒ 只有**派生副本**（解密 tar、解包树、认证 tar）可删。
2. **硬链接陷阱**：`.tar.zst` 与 `.tar.zst.part` 是同一 inode 的两个硬链接
   （`stat -c '%i %h'`：inode 相同、links=2）。du 只计一次，但删一个名字**不释放空间**。
3. **引用与占用四查**：`rg -l <路径>` 扫 systemd/hermes-jobs/cron；`fuser -m <目录>`；
   `find <目录> -type f -mmin -1440`（24h 内无写入）；`find / -name '*.hermesenc' -newermt ...`。
4. **证据清单先行**：待删项的 path/size/inode/mtime 落 JSON（工作区），再执行删除。
   tirith 批量删除拦截属预期，经用户批准即可。
5. **实测结果**：naye 磁盘 80G(71%) → 74G(65%)，释放 6.8G；保留 `.hermesenc` 原始加密包、
   事故取证目录、变更前数据库副本。

**向用户汇报的分层删除时间表**：

| 层 | 删除条件 |
|---|---|
| 被后续快照覆盖的单日加密包 | 随时可删，仅时间点价值 |
| 变更前数据库保底副本 | 连续两周异地发布成功 + ≥1 次恢复演练通过 |
| 事故取证/恢复暂存 | 逐子目录核唯一性，不按时间一刀切；删前确认替代副本可独立取回 |

## 二、异地发布 FAILED：先查配置变更，别假设链路坏

现象：`offsite_backup.py` 报 `RuntimeError: Remote backup operation failed (exit 1)`，
job.log 只有 traceback、无远端 stderr（`remote_python` 故意吞掉任意 stderr，
只识别「LA storage reserve gate」和「Ciphertext digest mismatch」两条已知消息）。

### 取证顺序

1. **本机 `/var/log/auth.log` 的 `COMMAND=` 流**：定位备份脚本被谁何时改过。
   特征：脚本目录里有 `offsite_backup.py.bak-<描述>-<时间戳>`（如
   `bak-vpsla-aliyun-20261118T073816`）；`diff` 当前文件与 `.bak` 即得改动内容。
   实例：改动仅 SSH host `vps-la` → `aliyun` 三处，**known_hosts 未同步**导致次日定时跑
   的远端预检 ssh 直接失败。
2. **远端核实**：`ssh <host> 'ls -la <REMOTE目录>/*.hermesenc'`——远端已有当天文件 ⇒
   失败后有人/进程补跑成功。status 文件仍 FAILED **不会自动翻绿**，须人工确认。
   远端 `auth.log` 的 `Accepted publickey` 记录可佐证实际落盘机器。
3. **收尾**：当天定时任务确认成功后，清掉失败遗留 workspace（`hermes-jobs/tmp/offsite-*`）。

### 汇报要点

- 根因是「配置变更 + known_hosts 未同步」，不是备份链本身损坏。
- 异地目标变更（如跨国的 vps-la → 同国的 aliyun）会削弱"异地"属性，必须向用户指出并确认是否有意。
- 发现未经授权的自动化变更（大量 root 命令、不在已知 cron/jobs 里）必须如实上报，不能静默。
- `transfer.log` 这类进度日志可能只有 rsync 百分比行没有结论，取证时看同目录的
  `transfer-verified.json`（含 `remote_sha256_matched` 字段）而非日志正文。
