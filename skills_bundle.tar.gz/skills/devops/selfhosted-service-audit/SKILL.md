---
name: selfhosted-service-audit
description: "自建服务只读审计：systemd 健康/加固/凭据、崩溃vs部署重启、业务活性、依赖链路探针、监控与备份缺口、孤儿资源。"
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux]
metadata:
  hermes:
    tags: [audit, systemd, ops, security, liveness, monitoring, backup]
    related_skills: [backup-chain-audit, telegram-ops-bot, hermes-ai-chain-alert-triage, aws-ec2-ops]
---

# 自建服务只读审计

## When to Use

用户说"你也审计一下 / 看看有没有问题 / 体检一下"，对象是**任何自建常驻服务**：Telegram bot、运维面板、隧道、爬虫、Worker、代理。

适用场景举例：
- "运维机器人那边你也审计一次" → 查 `lemon-ops.service`
- "杀手机器人你也审计一下" → 查 Ad Killer（迁移后在 vps-la）
- 迁移后复检、事故后复盘、给用户交一份"能不能放心放着不管"的结论

不适用：只改一个配置、只查一条报错（那是排障，不是审计）。

## 铁律

1. **全程只读**。审计不等于维护：不 restart、不 disable、不删文件、不改 unit。发现该动的，列成"待决策项"交用户点头。
2. **"进程 active" 不算健康**。必须拿到业务侧证据（数据库事件、日志时间戳、端到端探针）才算"在干活"。
3. **区分事实与推断**，报告里分开写。没测的就写"未验证"，不要用"应该没问题"收尾。
4. **采样时间必须实测**（`TZ=Asia/Shanghai date`），与指标一起报，不猜、不补。
5. **不要打印凭据**：config 只输出键名，值按 `token/key/secret/password/id/username/channel/url/base` 关键字掩码成 `<N字符隐藏>`。

## 一、定位（先确认审的是哪台机器上的哪个东西）

```bash
systemctl list-units --type=service --no-pager | grep -iE "bot|ops|tunnel|proxy|spider"
ls -d /home/ubuntu/*/ /opt/*/ | head -60          # 找同名目录
ps -eo pid,etime,rss,cmd --sort=-rss | grep -i <关键字> | grep -v grep
```

**别名陷阱**：用户口中的名字常与进程名不同（"杀手机器人"= Ad Killer，"运维机器人"= lemon-ops）。先在服务列表里做**中英/意译双向匹配**（killer/ad/kill/slay、ops/运维、bot/机器人），匹配不上再问，不要直接说"找不到"。

**迁移陷阱**：服务可能早搬走了。本机残留一个 `*-tunnel.service` 不代表主体还在这台机器——先看 unit 的 `ExecStart` 指向哪，再 SSH 到真实宿主机确认。

## 二、健康与资源

```bash
systemctl status <unit> --no-pager -l | head -20
systemctl cat <unit> | grep -E "^(User|Group|ExecStart|MemoryHigh|MemoryMax|CPUQuota|TasksMax|Restart|LoadCredential|Environment)"
```

| 看什么 | 判据 |
|---|---|
| `Active: active (running) since` | 连续运行时长，与"最近重启"对照 |
| `Memory:` | **systemd 口径，显示 `M` 实为 MiB**，写报告要注明"systemd 口径"；`peak` 比当前值更能说明压力 |
| `MemoryHigh/Max` | 有 cgroup 限额说明做过加固，逼近 Max 才是风险 |
| `Tasks: n (limit: N)` | 线程泄漏看这里 |
| `Restart=on-failure` | 有它才需要查崩溃循环；`always` 要另判 |

## 三、稳定性：崩溃 vs 部署重启（最常被误读）

41 次启动不等于崩了 41 次。判据：

```bash
# 真崩溃：这两行成对出现
journalctl -u <unit> --since "7 days ago" --no-pager | grep -E "Failed with result|Scheduled restart|Main process exited"
# 部署重启：Stopping → Stopped → Starting 成对出现，无 Failed
journalctl -u <unit> --since "7 days ago" --no-pager | grep -E "Stopping|Started" | tail -12
```

- `Main process exited, code=exited, status=1/FAILURE` + `Scheduled restart job, restart counter is at N` = **真崩溃**。
- 只有 `Deactivated successfully` = 主动停（部署/手工 restart）。
- 定位到崩溃时刻要读**那一段**日志（`--since/--until` 精确到 10 分钟），看是启动即退（配置错）还是运行中崩。
- 日志"最近 24h 无 error"不等于健康——**可能只是没人调用**，见第四节。

## 四、业务活性：从数据层取证

只读数据库，不看进程：

```bash
sudo python3 - <<'EOF'
import sqlite3, datetime
db=sqlite3.connect("/var/lib/<svc>/state.db")
tabs=[r[0] for r in db.execute("select name from sqlite_master where type='table'")]
for t in tabs:
    n=db.execute(f'select count(*) from "{t}"').fetchone()[0]
    print(f"{t:30} {n}")
# 每张表的时间列取 MAX，判断"最后一条记录是几小时前"
EOF
```

要点：
- **先 `pragma table_info` 看真实列名**，不要猜 `kind`/`status`——本项目 `events` 表用的是 `action`/`level`，猜列名会直接 `no such column` 白跑一轮。
- 时间戳是 Unix 秒 → 换算北京时间再报，并且和采样时间比，得出"最后活动 = 几小时前"。
- 报"近 24h / 近 7d 动作分布"比报总行数有用得多；总行数只说明历史积累。
- 找积压要看**状态列的真实枚举值**（`select state,count(*) group by state`），不要假设有 `pending`。

## 五、安全：四项固定检查

```bash
# 1. 硬编码凭据
grep -rnE "(token|api_key|password|secret)\s*=\s*['\"][A-Za-z0-9_\-:]{16,}" *.py | head
grep -rnE "[0-9]{8,10}:[A-Za-z0-9_-]{30,}" *.py | head        # Telegram token 形态
# 2. 凭据文件权限与注入方式
ls -l /etc/<svc>/
# 3. 危险调用
grep -rnE "subprocess|os\.system|eval\(|exec\(|shell=True" *.py | grep -v test_
# 4. 鉴权入口
grep -nE "owner_id|is_owner|ADMIN|authorized|getChatMember" bot.py | head
```

通过标准（本类项目已验证的良性形态）：
- 凭据在 `/etc/<svc>/`（600 root），unit 用 `LoadCredential=` + `Environment=AD_CONFIG=%d/...` 注入，进程不读明文文件；
- `subprocess` 全用 list 传参、无 `shell=True`、无 `eval/exec`；
- 鉴权走平台原生（Telegram `getChatMember` + 委派表），不自造绕过路径；
- unit 有 `CapabilityBoundingSet=`（空）、`ProtectSystem=strict`、`ProtectHome=yes`、`PrivateTmp`、`NoNewPrivileges`、`TasksMax`。

小瑕疵也要报但不夸大：`/opt/<svc>/config.json` 644 world-readable（若只含群 ID/用户名，不是泄露）、0 字节 `state.db` 空残留（真实数据在 `/var/lib/`）。

## 六、依赖链路：端到端探针，不看端口在听

端口在 listen 只证明进程绑定了 socket。要发真实请求：

```bash
sudo python3 - <<'EOF'
import json,urllib.request,time
cfg=json.load(open("/etc/<svc>/config.json"))
base=cfg["ai"]["base_url"].rstrip("/")
key=open("/etc/<svc>/ai-key").read().strip()
payload=json.dumps({"model":cfg["ai"]["model"],"messages":[{"role":"user","content":"ping"}],"max_tokens":5}).encode()
req=urllib.request.Request(base+"/chat/completions",data=payload,
    headers={"Authorization":"Bearer "+key,"Content-Type":"application/json"},method="POST")
t=time.time()
try:
    with urllib.request.urlopen(req,timeout=30) as r:
        print("OK", r.status, f"{time.time()-t:.1f}s", json.loads(r.read(4000)).get("model"))
except urllib.error.HTTPError as e:
    print("FAIL HTTP", e.code, e.read(300).decode(errors="replace")[:200])
EOF
```

报"HTTP 200 / 1.8s"这种实测值，不报"链路应该是通的"。

## 七、运维缺口三查（审计的真正价值所在）

### 7.1 监控覆盖
```bash
grep -rl "<svc>" /opt/monitor /usr/local/bin ~/hermes-jobs ~/lemon-ops-bot 2>/dev/null | head
```
零命中 = **服务挂了没人知道**。这条必须作为第一优先项报给用户，而不是埋在末尾。历史实证：某 bot 迁移后旧实例停了 7 天 17 小时无人发现。

### 7.2 备份覆盖
```bash
ls -lt /root/<svc>-backups /root/<svc>-deploy-backups 2>/dev/null | head
find /root -name "state.db" -newermt "<近3天>" | head
```
- 部署时的手工备份 ≠ 定时备份。**看最新一份的日期，不数目录个数。**
- 别忘跨机核对：AWS 的离线加密备份只打包 `$HOME`，不含另一台机器的 `/opt/<svc>`。这类"以为有、实际没有"的覆盖缺口是最容易漏报的。

### 7.3 孤儿资源（迁移遗留）
```bash
# 隧道还有没有消费者
ss -tnp | grep <port>
grep -rl "<port>" /opt /root --include=*.py --include=*.json --include=*.conf 2>/dev/null | grep -v node_modules
# 空转证明：累计 IO 只有 ssh 心跳量
grep -E "^(rchar|wchar)" /proc/<pid>/io
```

**退役判据（缺一不可）**：① 目标端无进程引用该端口；② 无连接；③ 历史退役审计的阻塞原因已消除（例如当初 `retirement_approved=false` 是因为"外部消费者未核实 + SSH 不通"，现在 SSH 通了就要重跑消费者核查，不能沿用旧结论）。判据齐了也只是"建议退役"，**要用户点头才动手**。

### 7.4 补上监控缺口后，必须做的四步验收（别只写脚本就报完成）

审计发现「服务挂了没人知道」→ 写巡检脚本 → **到这里只完成了一半**。漏掉下面任何一步，
交上去的都是「看起来有监控、实际不会响」的假保障。

**① 三态测试**（全部用临时路径，不碰真实文件、不给用户发测试消息）

```bash
# 目标路径/状态文件/通知器都用环境变量覆盖，在 mktemp -d 里造场景
export PATCH_GUARD_TARGET="$TMPD/target.py" PATCH_GUARD_STATE="$TMPD/state.json"
export PATCH_GUARD_NOTIFY="$TMPD/notify.py"
```

必测四场景，缺一不可：

| 场景 | 期望 |
|---|---|
| 正常态 | 静默，退出 0，**不发任何消息** |
| 异常态 | 发出告警，内容含可执行的修复/重放命令 |
| 同状态重复跑 | 去重跳过，不刷屏 |
| 恢复态 | 发一条恢复通知，状态回 `ok` |

**② 通知链路必须验证「真的收到」，不能只看脚本打印了内容**

⚠️ **最容易踩的坑：假通知器写成 bash 脚本 → 静默失败 → 误判「通知没发出」**。
`lemon-ops-bot/notify.py` 是被 **venv 里的 python3 拉起**的，所以测试用的假通知器**也必须是 `.py`**；
用 `.sh` 时 `python3 xxx.sh` 直接报错，而调用处 `stderr=DEVNULL` 把错误吞了，表象就是「通知一条没发」。
（本次实测踩到，换 Python 假通知器后立刻收到两条。）

假通知器模板：

```python
# notify.py（放在 $TMPD 里，只记录不发送）
import sys
with open(__file__.replace("notify.py", "sent.log"), "a", encoding="utf-8") as f:
    f.write("=== 通知被调用 ===\n" + (sys.argv[1] if len(sys.argv) > 1 else "") + "\n\n")
```

验收标准是 `cat $TMPD/sent.log` **能看到内容**，不是「脚本自己 print 了告警文案」。

**③ 挂调度四查**（脚本存在 ≠ 已在跑，这条已在 Pitfalls 强调，这里给全清单）

```bash
crontab -l | grep <脚本名>                     # 当前用户
sudo -n crontab -l | grep <脚本名>             # root
sudo -n grep -rl <脚本名> /etc/cron.d /etc/crontab
systemctl list-timers --all | grep -i <关键词>  # systemd
# Hermes 自己的：cronjob list（脚本型 job 的 script 字段）
```

统一走 `cron-status.py <job> -- <真实命令>` 包装，这样每次执行会落
`~/.local/state/automation-cron/<job>.json`（`status`/`started_at`/`exit_code`/`last_success_at`），
事后能证明「它真的按点跑过、成功过」，而不是只有进程 active。

**④ 改在 Hermes 安装目录里的补丁，必须配守卫**

`~/.hermes/hermes-agent/` 下的改动会被 `hermes update` 覆盖。除了留 `.patch` + `.bak`、
`git apply --reverse --check` 验证回滚路径，还要挂一个每日守卫检查源码标记是否还在，
丢了就告警并给出重放命令。现成脚本见 `hermes-ai-chain-alert-triage` 的 `scripts/patch_guard.py`。

## 八、报告结构（用户认可的形态）

1. **一句结论**：健康 / 有隐患 / 有问题，以及最要紧的那一条。
2. **采样时间**：实测的北京时间。
3. 分节表格：现役状态 → 功能验证（业务数据）→ 安全审计 → 待决策项。
4. **待决策项按风险排序**，每条给"为什么"和"修起来多大动静"。
5. **末尾"如实说明"**：未验证项、没深挖的疑点（例：某日报自报 `partial` 但 `remaining_unchecked: 0`，口径矛盾——写"未读代码确认，不下定论"，不要替它圆）。
6. 结尾给动作顺序建议（先纯新增的低风险项，最后才是停用/删除）。

## Pitfalls

- **`systemctl status` 的 `Memory: 34.7M` 是 MiB**，写"34.7 MB"会被抓错；`systemctl show -p MemoryCurrent` 才是字节。两者不可混。
- **不要用 `journalctl | grep -c error` 当健康证据**：日志只在出错/事件时写，24h 干净可能意味着零调用。必须配业务数据一起看。
- **`sqlite3` CLI 常常没装**，用 `python3 -c "import sqlite3"`；查表前先 `pragma table_info` 拿真实列名。
- **`du -sh /var/lib/<svc>` 不加 `sudo` 会显示 0**，别当成空目录。
- **在远端机器上用端口号做关键词检索，会命中一堆历史 staging 副本**（`/opt/<svc>-*-stage-*`、`backup/source/`）。本地检索用 `search_files`，远端才用 shell grep；两种都要过滤掉 staging/backup 目录，否则永远"有引用"。
- **迁移过的服务，旧机器上 `disabled` + 旧 unit 文件还在**是常态，不是故障；但旧机器上那条为它服务的隧道会继续空转，属于要报的孤儿资源。
- **本机 `ss` 里一堆 ESTAB 到 22 端口是正常 SSH 会话**，别把它们当成服务流量证据。
- **别在群里/生产上发测试消息验证 bot 活着**，会打扰用户；用事件表时间戳推断，并在报告里标注"非端到端实测"。
- 报告要区分"服务端改动"与"界面验收"；没实际点过按钮就不要写"已生效"。
- **审计监控覆盖时，先看探针本身对不对**：证书/HTTPS 探针写死 443 会误报——443 常被 xray 代理占用并回落大站证书，业务 TLS 可能在 2087/8443。判定与修法见 `proxy-node-connectivity` 的 `references/tls-cert-probe-false-positive.md`。同理，监控脚本存在 ≠ 已挂调度，要核对 crontab / `/etc/cron.d` / Hermes `cronjob list`。

## References

- `references/ad-killer-audit-20261024.md` — Ad Killer 全量审计实例：迁移前后拓扑、命令原文、实测数值、三条待决策项。
