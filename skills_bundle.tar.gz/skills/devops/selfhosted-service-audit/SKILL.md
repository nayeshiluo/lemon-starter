---
name: selfhosted-service-audit
description: "自建服务只读审计：systemd 健康/加固/凭据、崩溃vs部署重启、业务活性、依赖链路探针、监控与备份缺口、孤儿资源。"
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux]
metadata:
  hermes:
    tags: [audit, systemd, ops, security, liveness, monitoring, backup]
    related_skills: [backup-chain-audit, telegram-ops-bot, hermes-ai-chain-alert-triage, aws-ec2-ops]
---

# 自建服务只读审计

## When to Use

用户说"你也审计一下 / 看看有没有问题 / 体检一下"，对象是**任何自建常驻服务**：Telegram bot、运维面板、隧道、爬虫、Worker、代理。

适用场景举例：
- "运维机器人那边你也审计一次" → 查 `lemon-ops.service`
- "杀手机器人你也审计一下" → 查 Ad Killer（迁移后在 vps-la）
- "攻击一下 / 测一下这个域名" → **先过授权闸门**，再做公网侧暴露面审计（见第七-c节）
- "这个 XX 到底是什么 / 在哪台机器 / 是不是那个服务" → 先做**部署身份判定**（见第一节-b），再谈健康
- 整机迁移前的"哪些留下、哪些搬走" → 迁移归属判定（见第七-d节）
- 迁移后复检、事故后复盘、给用户交一份"能不能放心放着不管"的结论

不适用：只改一个配置、只查一条报错（那是排障，不是审计）。

## 铁律

1. **全程只读**。审计不等于维护：不 restart、不 disable、不删文件、不改 unit。发现该动的，列成"待决策项"交用户点头。
2. **"进程 active" 不算健康**。必须拿到业务侧证据（数据库事件、日志时间戳、端到端探针）才算"在干活"。
3. **区分事实与推断**，报告里分开写。没测的就写"未验证"，不要用"应该没问题"收尾。
4. **采样时间必须实测**（`TZ=Asia/Shanghai date`），与指标一起报，不猜、不补。⚠️ **但 `date` 的时区会漂**：
   同一会话里两次 `date +%Y%m%d_%H%M%S` 可能一次给 UTC、一次给 UTC+8（取决于当次 shell 继承的 `TZ`）。
   本次实录：备份文件名写成 `crontab-..._134030.bak`，而 `TZ=UTC stat` 显示真实 mtime 是 `05:40:30 UTC`。
   **结论：文件名/证据里的时间戳一律不能当采样时间用**，文件时间以 `TZ=UTC stat -c '%y %n'` 为准，
   报告里写明「采样时间 X（UTC）/ X+8（北京）」两个口径，别只写一个。
5. **不要打印凭据**：config 只输出键名，值按 `token/key/secret/password/id/username/channel/url/base` 关键字掩码成 `<N字符隐藏>`。

## 一、定位（先确认审的是哪台机器上的哪个东西）

```bash
systemctl list-units --type=service --no-pager | grep -iE "bot|ops|tunnel|proxy|spider"
ls -d /home/ubuntu/*/ /opt/*/ | head -60          # 找同名目录
ps -eo pid,etime,rss,cmd --sort=-rss | grep -i <关键字> | grep -v grep
```

**别名陷阱**：用户口中的名字常与进程名不同（"杀手机器人"= Ad Killer，"运维机器人"= lemon-ops）。先在服务列表里做**中英/意译双向匹配**（killer/ad/kill/slay、ops/运维、bot/机器人），匹配不上再问，不要直接说"找不到"。

**迁移陷阱**：服务可能早搬走了。本机残留一个 `*-tunnel.service` 不代表主体还在这台机器——先看 unit 的 `ExecStart` 指向哪，再 SSH 到真实宿主机确认。

## 一-b、部署身份判定：用户口中的名字 ≠ 部署身份

用户常给一个**产品名/口头名**（"copy 面板"、"XX 影厅"、"白嫖站"），要确认它到底是什么、部署在哪。
不要从名字直接映射到工程名，也不要把同机的另一个服务顺手合并进来。五步取证：

1. **读运行中容器实际提供的页面标题**，不是磁盘上的静态副本：

```bash
# 镜像没 shell 时用进程根视图，比 docker exec 稳
sudo grep -o "<title>[^<]*</title>" \
  /proc/$(docker inspect -f '{{.State.Pid}}' <ctr>)/root/usr/share/nginx/html/index.html
```

标题里出现用户说的品牌词，就是**最强的身份证据**（读的是正在服务的字节，不是旧文件）。

2. **同一品牌的简/繁两套页面 = 一个部署**。网关登录页「登录 · Capy 影厅」+ 分享前端「Capy 影廳」，
   是前后端两套页面，**不要报成两个部署**；报告里写清映射关系。

3. **工程名与品牌名分列**：`happy-capy`（compose 项目/镜像名）≠ 用户说的品牌名。
   两个都给，并注明"依据是运行中页面标题 + server_name"，别让读者自己猜。

4. **同机不同服务用"五维对照"证伪，不靠名字像不像**：运行形态（compose vs systemd）、单元/项目名、
   运行用户、工作目录、共享挂载/镜像。任一维不同即不同部署。
   实证：`workbuddy2api` = systemd + 专用用户 + `/var/lib/workbuddy2api` + 无共享挂载/镜像 → 与 Capy 容器**确为不同部署**；
   **但**网关 nginx 有一条 upstream 指向它（见 6.2）→ **不同部署 ≠ 无依赖**，两条结论都要写。

5. **判不出来就写"未确定"**：只有名字像、缺标题/API/端口证据时，明确写"缺少 X 证据，身份未确定"，
   禁止用工程名反推用户的产品名，也禁止把"可能相关"写成"就是它"。

## 二、健康与资源

```bash
systemctl status <unit> --no-pager -l | head -20
systemctl cat <unit> | grep -E "^(User|Group|ExecStart|MemoryHigh|MemoryMax|CPUQuota|TasksMax|Restart|LoadCredential|Environment)"
```

| 看什么 | 判据 |
|---|---|
| `Active: active (running) since` | 连续运行时长，与"最近重启"对照 |
| `Memory:` | **systemd 口径，显示 `M` 实为 MiB**，写报告要注明"systemd 口径"；`peak` 比当前值更能说明压力 |
| `MemoryHigh/Max` | 有 cgroup 限额说明做过加固，逼近 Max 才是风险 |
| `Tasks: n (limit: N)` | 线程泄漏看这里 |
| `Restart=on-failure` | 有它才需要查崩溃循环；`always` 要另判 |

## 三、稳定性：崩溃 vs 部署重启（最常被误读）

41 次启动不等于崩了 41 次。判据：

```bash
# 真崩溃：这两行成对出现
journalctl -u <unit> --since "7 days ago" --no-pager | grep -E "Failed with result|Scheduled restart|Main process exited"
# 部署重启：Stopping → Stopped → Starting 成对出现，无 Failed
journalctl -u <unit> --since "7 days ago" --no-pager | grep -E "Stopping|Started" | tail -12
```

- `Main process exited, code=exited, status=1/FAILURE` + `Scheduled restart job, restart counter is at N` = **真崩溃**。
- 只有 `Deactivated successfully` = 主动停（部署/手工 restart）。
- 定位到崩溃时刻要读**那一段**日志（`--since/--until` 精确到 10 分钟），看是启动即退（配置错）还是运行中崩。
- 日志"最近 24h 无 error"不等于健康——**可能只是没人调用**，见第四节。

**配套单元被 restart 带走 = 最隐蔽的一类「部署重启后遗症」**（2026-10-28 实录）：

一个 worker 停了 22 小时，journal 里既无 `Failed` 也无 `Scheduled restart`，只有 `Deactivated successfully`；对照主服务日志发现停止时刻与 `systemctl restart <主服务>` **同一秒**（同一秒还有一条 sshd 接受外部 key 的记录 → 是远程部署动作，不是崩溃）。

根因在依赖声明：worker 上写了 `Requires=<主服务>.service` + `After=`，这只表达「主服务停我也停」，**不表达「主服务起我也起」**；`WantedBy=multi-user.target` 只在开机时生效。所以远程 restart 主服务会把 worker 永久留在 dead。

审计判据与修法：

```bash
systemctl cat <worker> | grep -E "^(Requires|After|PartOf|WantedBy)"
# 主服务侧缺 Wants 就是缺口
grep -rn "Requires=" /etc/systemd/system/*.service.d/*.conf
```

在**主服务**侧加 drop-in（最小改动，不动 worker）：

```ini
# /etc/systemd/system/<主服务>.service.d/10-<worker>.conf
[Unit]
Wants=<worker>.service
```

⚠️ 只给 worker 加 `PartOf=<主服务>` **不够**：主服务 restart 时若 worker 已 inactive，PartOf 不会把它启动。改完必须实测一次 `systemctl restart <主服务> && sleep 5 && systemctl is-active <worker>`。

## 四、业务活性：从数据层取证

只读数据库，不看进程：

```bash
sudo python3 - <<'EOF'
import sqlite3, datetime
db=sqlite3.connect("/var/lib/<svc>/state.db")
tabs=[r[0] for r in db.execute("select name from sqlite_master where type='table'")]
for t in tabs:
    n=db.execute(f'select count(*) from "{t}"').fetchone()[0]
    print(f"{t:30} {n}")
# 每张表的时间列取 MAX，判断"最后一条记录是几小时前"
EOF
```

要点：
- **先 `pragma table_info` 看真实列名**，不要猜 `kind`/`status`——本项目 `events` 表用的是 `action`/`level`，猜列名会直接 `no such column` 白跑一轮。
- 时间戳是 Unix 秒 → 换算北京时间再报，并且和采样时间比，得出"最后活动 = 几小时前"。
- 报"近 24h / 近 7d 动作分布"比报总行数有用得多；总行数只说明历史积累。
- 找积压要看**状态列的真实枚举值**（`select state,count(*) group by state`），不要假设有 `pending`。

## 五、安全：五项固定检查

```bash
# 1. 硬编码凭据
grep -rnE "(token|api_key|password|secret)\s*=\s*['\"][A-Za-z0-9_\-:]{16,}" *.py | head
grep -rnE "[0-9]{8,10}:[A-Za-z0-9_-]{30,}" *.py | head        # Telegram token 形态
# 2. 凭据文件权限与注入方式
ls -l /etc/<svc>/
# 3. 危险调用
grep -rnE "subprocess|os\.system|eval\(|exec\(|shell=True" *.py | grep -v test_
# 4. 鉴权入口
grep -nE "owner_id|is_owner|ADMIN|authorized|getChatMember" bot.py | head
```

通过标准（本类项目已验证的良性形态）：
- 凭据在 `/etc/<svc>/`（600 root），unit 用 `LoadCredential=` + `Environment=AD_CONFIG=%d/...` 注入，进程不读明文文件；
- `subprocess` 全用 list 传参、无 `shell=True`、无 `eval/exec`；
- 鉴权走平台原生（Telegram `getChatMember` + 委派表），不自造绕过路径；
- unit 有 `CapabilityBoundingSet=`（空）、`ProtectSystem=strict`、`ProtectHome=yes`、`PrivateTmp`、`NoNewPrivileges`、`TasksMax`。

**5. 凭证/状态文件对「运行用户」可读性（最隐蔽的一项，必查）**

服务以非 root 用户运行时，只要有别的进程（root 的 cron、另一个 agent、手工 sudo）
用「临时文件 + `os.replace`」的方式重写过凭证/状态文件，属主就会变成 root，
服务读不到 → 静默回退到旧文件或空值 → 表现为**周期性 401 / 鉴权失败 / 空数据**，
而用同一份凭证手工调 API 却是 200。

```bash
# unit 跑在哪个用户下
systemctl show <unit> -p User -p Group
# 该用户能不能读关键文件（这一条才是判据）
sudo -u <svcuser> test -r /var/lib/<svc>/credentials.json && echo READABLE || echo NOT_READABLE
ls -l /var/lib/<svc>/ | head
# 复发证据：失败是否按固定周期刷（说明是每轮读取失败，不是偶发网络问题）
journalctl -u <unit> --since "-30min" --no-pager | grep -cE "401|鉴权|auth"
```

修复分两层，只做第一层会复发：现场 `chown <svcuser>:<svcuser>` + 重启；
代码层在原子写盘的 `os.replace` **之前** `os.chown(tmp, 原uid, 原gid)`，沿用原属主。

**先查「是谁把它改成 root 的」**：常见是另一台机器 ssh 过来以 root 跑「校验 + 刷新」脚本，
校验失败就顺手调 refresh，refresh 用「临时文件 + `os.replace`」写盘 → 属主变 root。
所以只改现场不修 refresh 的写盘逻辑，下一轮过期必然复发。

```bash
grep -n "def validate.*auth" -A 25 <svc>/client.py   # 校验失败时是否顺手 refresh
grep -n "def _atomic_save" -A 20 <svc>/refresh_token.py  # 写盘是否 chown 回原属主
journalctl -u <unit> --since "-1h" --no-pager | grep -E "validate|refresh|401" | tail
```

实证（2026-10-24）：某 sync worker 因这个原因 401，从属主被 root 改写那一刻（`11:30:37`）
持续到人工修复（`11:43`），约 13 分钟；日志里只有鉴权失败，看不出属主问题。

⚠️ **别把 `ps` 的 `ELAPSED` 当故障持续时长**：同一进程 `ELAPSED 1-12:25:04` 只说明它连续跑了
一天半，不代表空转了这么久。真实停摆区间要用「业务成功记录的 `MAX(时间戳)`」与「故障开始时刻」
两头夹出来：本例最后一条 success 是 `10:53:52`，`11:30` 才被锁。
（这条我当场误判成「空转 1 天 12 小时」并向用户更正过，写进技能避免复发。）

小瑕疵也要报但不夸大：`/opt/<svc>/config.json` 644 world-readable（若只含群 ID/用户名，不是泄露）、0 字节 `state.db` 空残留（真实数据在 `/var/lib/`）。

## 五-b、长任务：凭证寿命与调度锁（维护/修复时必查）

「净化/同步/巡检一直失败」常常不是业务逻辑错，而是**长任务 × 短凭证 × 独占锁**三件事撞在一起。
四项固定检查：

### 1. 凭证寿命 < 任务时长 → 必然中途 401

2 小时 JWT + 60~75 分钟全量递归扫描，只要任务起跑时 token 已消耗过半，就一定死在半路。
实测：`05:26` 签发，`06:19` 起跑，`07:26` 报 401，白跑 67 分钟，日志只有一行 401 看不出原因。

- 错误修法：等 401 再刷新（此时已浪费整轮）。
- **正确修法：每次请求前按 JWT `exp` 主动续期**，留 10 分钟余量。

```python
def token_seconds_left(token=None):          # 本地解析，不发请求
    token = token or get_access_token()
    if not token or token.count(".") != 2:
        return None
    p = token.split(".")[1]; p += "=" * (-len(p) % 4)
    try:
        return int(json.loads(base64.urlsafe_b64decode(p))["exp"] - time.time())
    except Exception:
        return None
```

在 `api_request` 开头：`if (left := token_seconds_left()) is not None and left < 600: 拉新凭证`。
验收标志：长扫描日志里出现「剩余 Ns，已续期」且**全程无 401**。

### 2. 401 兜底会死循环

刷新源与消费方共用同一份凭证时，「拉取最新凭证」拿回的就是刚失败那一个，
同步函数还会打印 `ALREADY_CURRENT` 然后原样重试 → 整轮报废。

判定必须看**凭证是否真的变了**：

```python
fresh = get_access_token()
if not fresh or fresh == failed_token:
    force_refresh()          # 让刷新源（唯一 owner）强制轮换
    fresh = get_access_token()
# 只重试一次；仍失败就显式抛错，不要静默重试
```

### 3. 独占锁饥饿：调度有、日志有、当天零成功

主任务持锁 60+ 分钟，后面每 30 分钟一轮的补偿任务全部 `Lock is busy` 退出。

```bash
grep -c "Lock is busy" <log>            # 补偿轮次是否全被挡
ps -eo pid,etime,cmd | grep <sweep>     # 谁在长期持锁
```

修法不是加锁等待，而是**拆职责**：
- 主流水线只做下发/主流程，把清理目标 `enqueue` 后立即释放锁（`defer_cleanup=True` 这类开关）；
- 长扫描交给专职轮转任务，**一轮一个分区**，每轮独立进程、独立取 token。

### 4. cron 时区：注释写 BJ 不算数

`timedatectl` 为 `Etc/UTC` 时，`*/30 6-23` 是 UTC 06–23 = 北京 14:00–次日 07:30。
排程一律按 `BJ 时刻 - 8h` 换算，**改完必须 `crontab -l` 回读逐行核对**（本次就把 BJ 06:00
误写成 UTC 06:00，返工一次）。

## 六、依赖链路：端到端探针，不看端口在听

端口在 listen 只证明进程绑定了 socket。要发真实请求：

```bash
sudo python3 - <<'EOF'
import json,urllib.request,time
cfg=json.load(open("/etc/<svc>/config.json"))
base=cfg["ai"]["base_url"].rstrip("/")
key=open("/etc/<svc>/ai-key").read().strip()
payload=json.dumps({"model":cfg["ai"]["model"],"messages":[{"role":"user","content":"ping"}],"max_tokens":5}).encode()
req=urllib.request.Request(base+"/chat/completions",data=payload,
    headers={"Authorization":"Bearer "+key,"Content-Type":"application/json"},method="POST")
t=time.time()
try:
    with urllib.request.urlopen(req,timeout=30) as r:
        print("OK", r.status, f"{time.time()-t:.1f}s", json.loads(r.read(4000)).get("model"))
except urllib.error.HTTPError as e:
    print("FAIL HTTP", e.code, e.read(300).decode(errors="replace")[:200])
EOF
```

报"HTTP 200 / 1.8s"这种实测值，不报"链路应该是通的"。

### 6.2 不许发请求时的归因：nginx upstream → 监听进程 → cgroup

只读审计常被要求"不 curl 真实业务"，此时仍能确定"谁在给这条 upstream 提供服务"，靠的是三层元数据对撞：

```bash
# 1) 容器内 nginx 的 proxy 目标（只取目标形态，不打印整份配置）
docker exec <ctr> grep -hoE "proxy_pass +https?://[^;]+" /etc/nginx/nginx.conf
# 2) 该端口谁在听（拿 PID）
sudo ss -lntp | grep ":<port> "
# 3) PID 属于哪个容器 / 哪个 systemd 单元
sudo head -3 /proc/<pid>/cgroup        # docker-<id>.scope → 容器；<unit>.service → systemd
docker inspect -f '{{.Name}}' <id>     # 反查容器名
```

归因结果分三类落表：`同 compose 服务` / `同机容器` / `独立 systemd 服务`。

- **第三方独立服务出现在 upstream 里 = 迁移耦合点**：身份不同、不可合并，但必须同批或"先建后拆"，单独列一条依赖边。
- 这条方法只能回答"哪条 upstream 指向谁"。**具体 location / 路径用途仍是未确定**，不要据此推断业务语义（是登录？面板？数据接口？），除非另读配置——那就超出只读脱敏范围了。
- 找不到监听者就写"1 条 upstream 未归因"，不要猜。

## 七、运维缺口三查（审计的真正价值所在）

### 7.1 监控覆盖
```bash
grep -rl "<svc>" /opt/monitor /usr/local/bin ~/hermes-jobs ~/lemon-ops-bot 2>/dev/null | head
```
零命中 = **服务挂了没人知道**。这条必须作为第一优先项报给用户，而不是埋在末尾。历史实证：某 bot 迁移后旧实例停了 7 天 17 小时无人发现。

### 7.2 备份覆盖
```bash
ls -lt /root/<svc>-backups /root/<svc>-deploy-backups 2>/dev/null | head
find /root -name "state.db" -newermt "<近3天>" | head
```
- 部署时的手工备份 ≠ 定时备份。**看最新一份的日期，不数目录个数。**
- 别忘跨机核对：AWS 的离线加密备份只打包 `$HOME`，不含另一台机器的 `/opt/<svc>`。这类"以为有、实际没有"的覆盖缺口是最容易漏报的。

### 7.3 孤儿资源（迁移遗留）
```bash
# 隧道还有没有消费者
ss -tnp | grep <port>
grep -rl "<port>" /opt /root --include=*.py --include=*.json --include=*.conf 2>/dev/null | grep -v node_modules
# 空转证明：累计 IO 只有 ssh 心跳量
grep -E "^(rchar|wchar)" /proc/<pid>/io
```

**退役判据（缺一不可）**：① 目标端无进程引用该端口；② 无连接；③ 历史退役审计的阻塞原因已消除（例如当初 `retirement_approved=false` 是因为"外部消费者未核实 + SSH 不通"，现在 SSH 通了就要重跑消费者核查，不能沿用旧结论）。判据齐了也只是"建议退役"，**要用户点头才动手**。

### 7.4 补上监控缺口后，必须做的四步验收（别只写脚本就报完成）

审计发现「服务挂了没人知道」→ 写巡检脚本 → **到这里只完成了一半**。漏掉下面任何一步，
交上去的都是「看起来有监控、实际不会响」的假保障。

**① 三态测试**（全部用临时路径，不碰真实文件、不给用户发测试消息）

```bash
# 目标路径/状态文件/通知器都用环境变量覆盖，在 mktemp -d 里造场景
export PATCH_GUARD_TARGET="$TMPD/target.py" PATCH_GUARD_STATE="$TMPD/state.json"
export PATCH_GUARD_NOTIFY="$TMPD/notify.py"
```

必测四场景，缺一不可：

| 场景 | 期望 |
|---|---|
| 正常态 | 静默，退出 0，**不发任何消息** |
| 异常态 | 发出告警，内容含可执行的修复/重放命令 |
| 同状态重复跑 | 去重跳过，不刷屏 |
| 恢复态 | 发一条恢复通知，状态回 `ok` |

**② 通知链路必须验证「真的收到」，不能只看脚本打印了内容**

⚠️ **最容易踩的坑：假通知器写成 bash 脚本 → 静默失败 → 误判「通知没发出」**。
`lemon-ops-bot/notify.py` 是被 **venv 里的 python3 拉起**的，所以测试用的假通知器**也必须是 `.py`**；
用 `.sh` 时 `python3 xxx.sh` 直接报错，而调用处 `stderr=DEVNULL` 把错误吞了，表象就是「通知一条没发」。
（本次实测踩到，换 Python 假通知器后立刻收到两条。）

假通知器模板：

```python
# notify.py（放在 $TMPD 里，只记录不发送）
import sys
with open(__file__.replace("notify.py", "sent.log"), "a", encoding="utf-8") as f:
    f.write("=== 通知被调用 ===\n" + (sys.argv[1] if len(sys.argv) > 1 else "") + "\n\n")
```

验收标准是 `cat $TMPD/sent.log` **能看到内容**，不是「脚本自己 print 了告警文案」。

**③ 挂调度四查**（脚本存在 ≠ 已在跑，这条已在 Pitfalls 强调，这里给全清单）

```bash
crontab -l | grep <脚本名>                     # 当前用户
sudo -n crontab -l | grep <脚本名>             # root
sudo -n grep -rl <脚本名> /etc/cron.d /etc/crontab
systemctl list-timers --all | grep -i <关键词>  # systemd
# Hermes 自己的：cronjob list（脚本型 job 的 script 字段）
```

统一走 `cron-status.py <job> -- <真实命令>` 包装，这样每次执行会落
`~/.local/state/automation-cron/<job>.json`（`status`/`started_at`/`exit_code`/`last_success_at`），
事后能证明「它真的按点跑过、成功过」，而不是只有进程 active。

**③-b 调度表是会变的：挂完必须复查，并处理重复（2026-10-24 实录）**

本次踩到的真实顺序：查遍 crontab / `/etc/cron.d` / `systemctl list-timers` → **确认没有任何调度** →
挂上 crontab → 10 分钟后发现 `/etc/systemd/system/hermes-cert-check.timer` 出现了，跑的是**同一个脚本**。

原因不是查漏，而是**调度状态被别人改了**：当时有另一个 agent 正在把 `~/hermes-jobs/*` 陆续迁成
systemd timer（unit 文件 mtime 呈阶梯状：`05:18 / 05:37 / 05:53 / 06:25`，风格统一
`oneshot` + `Nice=` + `IOSchedulingClass=idle`）。看到这种阶梯 mtime 就该意识到「有并发改造在进行」，
先核对再动手，别和它抢同一份调度表。

判定重复的**唯一可靠方法**是比「跑什么」而不是比「名字」：

```bash
sudo -n cat /etc/systemd/system/<unit>.service | grep ExecStart    # 看真实脚本路径
sudo -n cat /etc/systemd/system/<unit>.timer   | grep OnCalendar   # 看真实时刻
```

去重操作（**先备份、只删重复那一条、用 diff 证明只删了一条**）：

```bash
crontab -l > <backup>/crontab-before-dedup-$(TZ=UTC date +%Y%m%d).bak
crontab -l | grep -v "<脚本名>" | grep -v "^# <该条的注释标记>" > /tmp/crontab.new
crontab /tmp/crontab.new
# 证据：只应显示被删的那一行
diff <(grep -vE "^#|^$" <backup>) <(crontab -l | grep -vE "^#|^$")
```

**两边都有时保留哪个**：优先 systemd timer —— 它有 `Persistent=true`（宕机错过会补跑）、
`RandomizedDelaySec`（避免整点撞车）、`Nice=` / `IOSchedulingClass=idle`（不抢业务 CPU/IO），
这些都是裸 crontab 给不了的。撤 crontab 前**先手动 `systemctl start <unit>.service` 验证它能跑通**
（`systemctl show -p Result -p ExecMainStatus` → `success` / `0`），确认可靠再撤，别先拆后建。

**④ 改在 Hermes 安装目录里的补丁，必须配守卫**

`~/.hermes/hermes-agent/` 下的改动会被 `hermes update` 覆盖。除了留 `.patch` + `.bak`、
`git apply --reverse --check` 验证回滚路径，还要挂一个每日守卫检查源码标记是否还在，
丢了就告警并给出重放命令。现成脚本见 `hermes-ai-chain-alert-triage` 的 `scripts/patch_guard.py`。

**部署形态选 systemd timer，不要 crontab**：脚本本体留在技能目录、部署侧只放一份 JSON 配置
（`target`/`patch`/`repo`/`state`/`markers`），service 用 `--config` 指过去 —— 单一来源，
技能改进自动生效，避免「技能模板 vs 线上副本」两份代码分叉。本次实录：先写成固定路径脚本挂 crontab，
随后发现技能里已有通用模板，遂统一为「技能脚本 + JSON 配置 + timer」，旧副本移入
`backup/superseded-<date>/` 留证（**别直接 rm，留归档**）。迁移时同样遵守「先建后拆」：
先 `systemctl start <unit>.service` 验证 `Result=success` / `ExecMainStatus=0`，再撤 crontab 那条。

## 七-c、外部暴露面审计（从公网看，不登宿主机）

用户问「这个域名安不安全 / 帮我测一下这个站 / 攻击一下 X」时，视角反过来：不登机器，
从 DNS → 边缘 → 应用端点往外看。完整命令、端点表、报告格式见
`references/external-exposure-audit.md`，这里只留必须记住的几条。

**授权闸门（第一步，不是可选项）**：
- 「攻击一下 X」→ 先拒绝攻击本身（一句话，不说教），给三条合法替代：自有资产只读体检 / 评估防护水平 / 已授权测试。
- 用户回「自有或已授权」后才动，且只做**低强度只读**：单线程、带 sleep、不爆破、不压测、不发写请求。
- 域名特征可疑（刚注册、全 CF 代理、无 MX）时**先问再判**，不要用特征给用户扣帽子 ——
  本次实录：这类特征看着像钓鱼站，查出来是用户自己的 Emby 反代节点。

**五项固定检查**：
1. 被动层：`dig` A/AAAA/NS/MX + `whois` + CT 日志。CF 网段 = 源站隐藏。
2. 指纹层：响应头 + `openssl x509`（证书 `notBefore` ≈ 上线时间，`cf-ray` 后缀是边缘机房不是源站）。
3. 后端判别：看 **404 的 body** 不看状态码 —— Emby 是 `{"ResponseStatus":{"ErrorCode":"NotFound"}}`，
   空 body + `server: cloudflare` 是 CF 边缘 404。原生格式 + 根路径 200 ⇒ **反代全量透传，无路径白名单**。
4. 安全头六查：HSTS / CSP / `X-Frame-Options` / `X-Content-Type-Options` / `Referrer-Policy` / `Permissions-Policy`。
   只有 `server: cloudflare` 一行 = 反代层零安全头（CF 默认不注入，必须自己加 Transform Rule）。
5. **版本真实性核验**：拿自报版本对官方 releases API（`api.github.com/repos/<org>/<repo>/releases`）。
   不在官方列表 ⇒ 口径写「**无法用官方发布记录核对补丁状态**」，**不要断言「是破解版」**；
   且此时 CVE 版本区间对比**同时失效**，只能标「仅供参考」。

**媒体服务器特有**：`?api_key=` 走 URL 传令牌 + 缺 `Referrer-Policy` = 令牌经 `Referer` 外泄给第三方，
一条 `Referrer-Policy: no-referrer` 就能堵死，零功能影响。`/System/Info/Public` 无认证报出版本/ServerId
是产品设计不是漏洞，但必须靠 WAF 改写 `Version` 字段掐掉指纹。

⚠️ `crt.sh` 的 JSON 端点可能返回 404/HTML，**读不到 ≠ 没有子域**，拿不到就写「未核实」。
⚠️ NVD 页面常常只返回标题、正文抓不到，这种只能标「仅搜索摘要」，不能算已核实。

## 七-d、整机迁移中的"留下 / 搬走"归属判定

整机迁移 ≠ 所有服务都搬。先把对象拆成三层，逐层定归属：

| 层 | 判据 | 归属 |
|---|---|---|
| 运行时 | 容器 / 进程 / 卷在本机 | 用户要求不动 → **留在原位**，迁移动作=0，只纳入备份 |
| 控制链 | `crontab -l`、systemd timer、证书续期、告警桥接 | **必须搬**：旧机停机后这些静默失效 |
| 入口 | DNS、反代 `server_name` | 运行时没动就别切，切了必断 |

四条铁律：

1. **控制链最容易漏**：只盘容器不盘 `crontab -l`，迁完的表现是"站点还在，但证书到期 / 告警不响"。
   报告里把控制链条目按 `schedule + 涉及文件路径` 列表，**不打印命令正文**（常含凭据）。
2. **分钟级任务禁止双跑**：`* * * * *` 的告警桥接两边同时跑 = 重复告警 + 抢写状态。一律先建后拆，旧机在新链路验证通过前不停。
3. **无 compose 标签的容器是最高风险项**：`docker inspect` 里 `com.docker.compose.project` 为空 = 手工 `docker run`，
   **没有编排可复现**。单独列一条，迁移前先反推 run 参数（镜像 digest + 全部 mount + workingdir + 端口）。
4. **镜像无 tag 只认 digest**：`docker ps` 的 IMAGE 列显示成 12 位短 ID 就是没 tag；重建必须写 `repo@sha256:...`，否则 `latest` 漂移。

同机共置但未证实有依赖的服务（如 `pansou`），单独列"不纳入本次迁移范围"，**不要顺手打包**。

## 八、报告结构（用户认可的形态）

1. **一句结论**：健康 / 有隐患 / 有问题，以及最要紧的那一条。
2. **采样时间**：实测的北京时间。
3. 分节表格：现役状态 → 功能验证（业务数据）→ 安全审计 → 待决策项。
4. **待决策项按风险排序**，每条给"为什么"和"修起来多大动静"。
5. **末尾"如实说明"**：未验证项、没深挖的疑点（例：某日报自报 `partial` 但 `remaining_unchecked: 0`，口径矛盾——写"未读代码确认，不下定论"，不要替它圆）。
6. 结尾给动作顺序建议（先纯新增的低风险项，最后才是停用/删除）。

## Pitfalls

- **`systemctl status` 的 `Memory: 34.7M` 是 MiB**，写"34.7 MB"会被抓错；`systemctl show -p MemoryCurrent` 才是字节。两者不可混。
- **不要用 `journalctl | grep -c error` 当健康证据**：日志只在出错/事件时写，24h 干净可能意味着零调用。必须配业务数据一起看。
- **`sqlite3` CLI 常常没装**，用 `python3 -c "import sqlite3"`；查表前先 `pragma table_info` 拿真实列名。
- **`du -sh /var/lib/<svc>` 不加 `sudo` 会显示 0**，别当成空目录。
- **在远端机器上用端口号做关键词检索，会命中一堆历史 staging 副本**（`/opt/<svc>-*-stage-*`、`backup/source/`）。本地检索用 `search_files`，远端才用 shell grep；两种都要过滤掉 staging/backup 目录，否则永远"有引用"。
- **迁移过的服务，旧机器上 `disabled` + 旧 unit 文件还在**是常态，不是故障；但旧机器上那条为它服务的隧道会继续空转，属于要报的孤儿资源。
- **本机 `ss` 里一堆 ESTAB 到 22 端口是正常 SSH 会话**，别把它们当成服务流量证据。
- **别在群里/生产上发测试消息验证 bot 活着**，会打扰用户；用事件表时间戳推断，并在报告里标注"非端到端实测"。
- **验收长任务不要用前台命令跑**：单轮扫描/同步常需 10~45 分钟，前台执行会被默认超时（约 180s）连进程一起杀掉，日志只留一行「开始」，很容易误判成「任务卡住/无效」。长任务一律 `background=true` + `notify_on_complete=true`，或直接复用它的 cron + flock 命令。
- **「跑完了」不等于「做了事」：先确认关键开关不是 dry-run / preview**。清理、同步、迁移类脚本常把
  `dry_run=True` 硬编码在调用处，日志连续多轮「预览完成，未删除文件」看着像正常运行，实际零副作用。
  审这类功能第一件事是 `grep -n "dry_run\|preview\|apply" *.py` 看**调用点**，而不是看它有没有报错。
- **长任务进行中被问「结束了吗 / 跑完没」**：不要回「还在跑」。给三件事——已跑时长、最后一行日志、
  还差什么/预计还要多久。本次只读探针跑了 96 分钟、中途被问两次，给进度比给结论更能稳住用户。
- **判断「还在失败」的时间窗要从重启时刻算起**：`journalctl --since` 若跨过重启点，会把旧 PID 的历史报错算进当前状态；核对 PID 是否已换再下结论。
- 报告要区分"服务端改动"与"界面验收"；没实际点过按钮就不要写"已生效"。
- **审计监控覆盖时，先看探针本身对不对**：证书/HTTPS 探针写死 443 会误报——443 常被 xray 代理占用并回落大站证书，业务 TLS 可能在 2087/8443。判定与修法见 `proxy-node-connectivity` 的 `references/tls-cert-probe-false-positive.md`。同理，监控脚本存在 ≠ 已挂调度，要核对 crontab / `/etc/cron.d` / Hermes `cronjob list`。
- **compose 文件不能直接 `yaml.safe_load`**：Compose 规范允许 `!reset` / `!override` 自定义标签，PyYAML 会抛
  `ConstructorError`（本次就撞上，白跑一轮）。只需要 service 名/镜像/卷/依赖键时用
  `yaml.load(f, Loader=yaml.BaseLoader)`，或注册 multi-constructor 忽略未知标签。
- **从 JSON 汇总生成 Markdown 前先 dump 结构**：同类证据块常不同形（`files_stat_only` 是
  `[{mount_root, database_name_matches:[...]}]` 而不是扁平的 `[{path,...}]`），照猜键名必然 `KeyError`。
  先 `json.dumps(x, indent=1)[:1200]` 看一眼，再写模板。
- **交付审计文件前做泄露扫描**（报告本身是用户可见物）：`re.findall(r'(?<![\d.])(?:\d{1,3}\.){3}\d{1,3}(?![\d.])')`
  查 IP 字面量，`(password|token|secret|api[_-]?key)\s*[=:]` 查秘密；内部回环端口一律脱敏成
  "内部端口已脱敏"，只保留公网入口端口号（否则 `ss`/`server_name` 一带就是内网拓扑）。
  审计报告一律 `chmod 600`，并回读 `oct(stat.S_IMODE(...))` 证明，不靠"我设过了"。
- **不许打开数据库时怎么判引擎**：读 `/proc/<pid>/maps | grep -i sqlite`（或进程加载的 `.so`）
  + 数据目录里 `.db`/`.sqlite3` 文件名 + mtime 是否在动。三条齐了写"SQLite（间接证据，未打开库）"，
  **不要**写成"已核验 schema"。
- **"备份"要先分清是源码包还是数据**：`*-share.zip`（200KB 级、跟部署同一天）= 源码快照，不是数据备份；
  同名 `.db` 出现在两处 mount 且 mtime 差三周 ⇒ "哪份权威"未知，快照必须两处都取，报告里标未确定。
- **Node.js/二进制运行时就地更新的解压陷阱（.tar.xz vs .tar.gz 与 getcwd 丢失）**：
  在精简 Linux 环境更新 Node 时，`tar -xJf` 依赖 `xz` 二进制，缺包时会报错 `tar (child): xz: Cannot exec`；官方通常提供同版本 `.tar.gz`，优先拉取 `.tar.gz` 用 `tar -xzf` 更通用。
  此外，在临时目录解压并清理时，避免在已删除的目录（cwd）下直接执行 `node`/`npm`；Node 启动或 `npm` 初始化时调用的 `process.cwd()` 会因当前工作目录不存在直接崩溃抛出 `ENOENT: uv_cwd`。应显式切回有效目录（如用户主目录）再做验收。
- **非标端口（如 2096/2083/8443）在手机/移动网络下的劫持与退化陷阱（Akamai `errors.edgesuite.net` 与 `[No Host]`）**：
  在排查用户反馈「移动端打不开/白屏/报错」时，如果客户端返回形如 `http://[No Host]/...` 或 Akamai 错误页 `errors.edgesuite.net`：
  1. **不要过早归因到客户端软件（如代理软件）本身**，先核实是否是因为使用了非标 HTTPS 端口（如 Cloudflare 允许的 2096/2083）。
  2. 手机浏览器（尤其是 Safari）在用户手动输入或历史补全时，极易优先发起明文 HTTP 请求（或省略了 `https://`）。中间网络、本地运营商或透明代理对非标端口截获后，会丢失 `Host` 请求头或被透明 CDN（如 Akamai 边缘）拦截报错。
  3. 验证方法：先用带有完整 `https://` 的规范 URI + 标准移动端 User-Agent 做严格 curl 验证；若 curl 200 且证书合法，则服务端存活，故障点在入口协议退化或中间链路劫持。
  4. 根治思路：业务管理端尽量统一收敛到标准 HTTPS 443 端口，利用边缘域名路由/反代避免在公网暴露非标端口给移动端直接访问。

## References

- `references/ad-killer-audit-20261024.md` — Ad Killer 全量审计实例：迁移前后拓扑、命令原文、实测数值、三条待决策项。
- `references/external-exposure-audit.md` — 外部暴露面审计（公网视角）：授权闸门、被动层/指纹层命令、Emby 端点暴露表、
  版本真实性核验（官方 releases API 比对）、安全响应头六查与加固清单、报告格式、2026-10-24 实测基线。
- `references/capy-theater-identity-audit-20261027.md` — 实例：用户口头名「Capy 影厅」如何用运行中页面标题确认为
  `happy-capy` 容器栈、与 `workbuddy2api` 的五维对照 + upstream 依赖边、只读采集口径、迁移归属表、脱敏交付形态。
