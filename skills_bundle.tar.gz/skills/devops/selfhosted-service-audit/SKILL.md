---
name: selfhosted-service-audit
description: "自建服务只读审计：systemd 健康/加固/凭据、崩溃vs部署重启、业务活性、依赖链路探针、监控与备份缺口、孤儿资源。"
version: 1.2.0
author: Hermes Agent
license: MIT
platforms: [linux]
metadata:
  hermes:
    tags: [audit, systemd, ops, security, liveness, monitoring, backup]
    related_skills: [backup-chain-audit, telegram-ops-bot, hermes-ai-chain-alert-triage, aws-ec2-ops]
---

# 自建服务只读审计

## When to Use

用户说"你也审计一下 / 看看有没有问题 / 体检一下"，对象是**任何自建常驻服务**：Telegram bot、运维面板、隧道、爬虫、Worker、代理。

适用场景举例：
- "运维机器人那边你也审计一次" → 查 `lemon-ops.service`
- "杀手机器人你也审计一下" → 查 Ad Killer（迁移后在 vps-la）
- "攻击一下 / 测一下这个域名" → **先过授权闸门**，再做公网侧暴露面审计（见第七-c节）
- "这个 XX 到底是什么 / 在哪台机器 / 是不是那个服务" → 先做**部署身份判定**（见第一节-b），再谈健康
- 整机迁移前的"哪些留下、哪些搬走" → 迁移归属判定（见第七-d节）
- "我之前弄的 XX 网站/订阅打不开了" → 先做**归属判定**（哪台机、哪一层），再按第六节 6.3 从外到内分层验链路；多段链路里后端 active 不代表门户健康
- "CPU/内存为什么占用这么高 / 机器怎么这么卡" → 跑飞进程与孤儿进程取证（见第七-f节）
- "我现在这条件能不能再起一个小 X 服 / 这台还塞得下吗" → **新增服务容量评估**（见第七-g节），
  先出「能不能 / 在哪台 / 唯一阻塞是什么」，不要一上来给部署方案
- 用户问「备份会不会越来越臃肿 / 配额还够不够 / 要不要改备份脚本」→ **先按
  `references/restic-repo-growth-measurement.md` 实测**，别用单次 `data_added` 推稳态（会得出完全错误的结论）
- 迁移后复检、事故后复盘、给用户交一份"能不能放心放着不管"的结论

不适用：只改一个配置、只查一条报错（那是排障，不是审计）。

## 铁律

1. **全程只读**。审计不等于维护：不 restart、不 disable、不删文件、不改 unit。发现该动的，列成"待决策项"交用户点头。
2. **"进程 active" 不算健康**。必须拿到业务侧证据（数据库事件、日志时间戳、端到端探针）才算"在干活"。
3. **区分事实与推断**，报告里分开写。没测的就写"未验证"，不要用"应该没问题"收尾。
4. **采样时间必须实测**（`TZ=Asia/Shanghai date`），与指标一起报，不猜、不补。⚠️ **但 `date` 的时区会漂**：
   同一会话里两次 `date +%Y%m%d_%H%M%S` 可能一次给 UTC、一次给 UTC+8（取决于当次 shell 继承的 `TZ`）。
   本次实录：备份文件名写成 `crontab-..._134030.bak`，而 `TZ=UTC stat` 显示真实 mtime 是 `05:40:30 UTC`。
   **结论：文件名/证据里的时间戳一律不能当采样时间用**，文件时间以 `TZ=UTC stat -c '%y %n'` 为准，
   报告里写明「采样时间 X（UTC）/ X+8（北京）」两个口径，别只写一个。
5. **不要打印凭据**：config 只输出键名，值按 `token/key/secret/password/id/username/channel/url/base` 关键字掩码成 `<N字符隐藏>`。

## 一、定位（先确认审的是哪台机器上的哪个东西）

```bash
systemctl list-units --type=service --no-pager | grep -iE "bot|ops|tunnel|proxy|spider"
ls -d /home/ubuntu/*/ /opt/*/ | head -60          # 找同名目录
ps -eo pid,etime,rss,cmd --sort=-rss | grep -i <关键字> | grep -v grep
```

**别名陷阱**：用户口中的名字常与进程名不同（"杀手机器人"= Ad Killer，"运维机器人"= lemon-ops）。先在服务列表里做**中英/意译双向匹配**（killer/ad/kill/slay、ops/运维、bot/机器人），匹配不上再问，不要直接说"找不到"。

**迁移陷阱**：服务可能早搬走了。本机残留一个 `*-tunnel.service` 不代表主体还在这台机器——先看 unit 的 `ExecStart` 指向哪，再 SSH 到真实宿主机确认。

## 一-b、部署身份判定：用户口中的名字 ≠ 部署身份

用户常给一个**产品名/口头名**（"copy 面板"、"XX 影厅"、"白嫖站"），要确认它到底是什么、部署在哪。
不要从名字直接映射到工程名，也不要把同机的另一个服务顺手合并进来。五步取证：

1. **读运行中容器实际提供的页面标题**，不是磁盘上的静态副本：

```bash
# 镜像没 shell 时用进程根视图，比 docker exec 稳
sudo grep -o "<title>[^<]*</title>" \
  /proc/$(docker inspect -f '{{.State.Pid}}' <ctr>)/root/usr/share/nginx/html/index.html
```

标题里出现用户说的品牌词，就是**最强的身份证据**（读的是正在服务的字节，不是旧文件）。

2. **同一品牌的简/繁两套页面 = 一个部署**。网关登录页「登录 · Capy 影厅」+ 分享前端「Capy 影廳」，
   是前后端两套页面，**不要报成两个部署**；报告里写清映射关系。

3. **工程名与品牌名分列**：`happy-capy`（compose 项目/镜像名）≠ 用户说的品牌名。
   两个都给，并注明"依据是运行中页面标题 + server_name"，别让读者自己猜。

4. **同机不同服务用"五维对照"证伪，不靠名字像不像**：运行形态（compose vs systemd）、单元/项目名、
   运行用户、工作目录、共享挂载/镜像。任一维不同即不同部署。
   实证：`workbuddy2api` = systemd + 专用用户 + `/var/lib/workbuddy2api` + 无共享挂载/镜像 → 与 Capy 容器**确为不同部署**；
   **但**网关 nginx 有一条 upstream 指向它（见 6.2）→ **不同部署 ≠ 无依赖**，两条结论都要写。

5. **判不出来就写"未确定"**：只有名字像、缺标题/API/端口证据时，明确写"缺少 X 证据，身份未确定"，
   禁止用工程名反推用户的产品名，也禁止把"可能相关"写成"就是它"。

## 二、健康与资源

```bash
systemctl status <unit> --no-pager -l | head -20
systemctl cat <unit> | grep -E "^(User|Group|ExecStart|MemoryHigh|MemoryMax|CPUQuota|TasksMax|Restart|LoadCredential|Environment)"
```

| 看什么 | 判据 |
|---|---|
| `Active: active (running) since` | 连续运行时长，与"最近重启"对照 |
| `Memory:` | **systemd 口径，显示 `M` 实为 MiB**，写报告要注明「systemd 口径」；`peak` 比当前值更能说明压力 |
| `MemoryHigh/Max` | 有 cgroup 限额说明做过加固，逼近 Max 才是风险 |
| `Tasks: n (limit: N)` | 线程泄漏看这里 |
| `Restart=on-failure` | 有它才需要查崩溃循环；`always` 要另判 |

### 内存报告口径（2026-11-01 实测，必须说清楚的三点）

**一、RSS 与 cgroup 不能混加**：`ps` 的 RSS 含共享库页（多进程共用的 `.so`），同一台机上多个进程的 RSS 之和 > 真实占用。cgroup 的 `MemoryCurrent` 按首次触碰归属计一次，是更准确的「该服务实际占用」口径。两个数都报，说明各自含义：

```bash
# 精确 RSS 分项（KiB，不含共享库重复计）
for p in <PID1> <PID2>; do
  echo "PID $p"
  awk '/^Rss/{print "   "$0}' /proc/$p/status
done
# cgroup 实际归属（字节）
for u in <svc1> <svc2>; do
  printf "%s MemoryCurrent=" "$u"
  systemctl show $u.service -p MemoryCurrent --value
done
# memory.stat 关键项（字节，需 /sys/fs/cgroup 可读）
grep -E "^(anon|file|kernel|shmem|swap) " /sys/fs/cgroup/system.slice/<svc>.service/memory.stat
```

**二、单位换算铁律**：Linux `/proc` 中标 `kB` 的字段实为 **KiB**（1024字节）；systemd `show -p MemoryCurrent` 返回字节；`ps` RSS 列单位 KiB。换算：
- `RSS 80392 KiB` = 80392 / 1024 = **78.51 MiB**（不能写成 "80.4 MB"）
- `MemoryCurrent <YOUR_USER_IDENTIFIER> B` = <YOUR_USER_IDENTIFIER> / 1024 / 1024 = **55.06 MiB**
- 报告中同时写 MiB 和 MB 时需注明口径（`1 MiB = 1.049 MB`）

**三、单点快照的局限**：一次 `MemoryCurrent` 只说明那一刻的值。必须明确说明：
- `MemoryPeak` 为空（内核未开启峰值统计）时**无法断言历史峰值**
- `MemorySwapCurrent` 为空不等于未换页；Swap 已用量 ≠ 正在频繁换页
- 判断内存泄漏或持续压力**必须有时间序列**，单次快照只能支持「此刻」的结论

实测对比示例（2026-11-01，两服务运行 3h 09m 后）：
| | bot1 @<PRIVATE_IDENTIFIER>_bot | bot2 @<PRIVATE_IDENTIFIER>_bot |
|---|---|---|
| ps RSS | 80392 KiB = 78.51 MiB | 141216 KiB = 137.91 MiB |
| cgroup MemoryCurrent | 55.06 MiB | 114.71 MiB |
| RSS-cgroup 差 | ~23 MiB（共享库） | ~23 MiB（共享库） |
| anon（私有页） | 54472 KiB | 113352 KiB |

bot2 比 bot1 多 ~60 MiB，正比于授权群数量（11 vs 3），内存主要是消息缓存和 per-chat 状态，属预期差异。

## 三、稳定性：崩溃 vs 部署重启（最常被误读）

41 次启动不等于崩了 41 次。判据：

```bash
# 真崩溃：这两行成对出现
journalctl -u <unit> --since "7 days ago" --no-pager | grep -E "Failed with result|Scheduled restart|Main process exited"
# 部署重启：Stopping → Stopped → Starting 成对出现，无 Failed
journalctl -u <unit> --since "7 days ago" --no-pager | grep -E "Stopping|Started" | tail -12
```

- `Main process exited, code=exited, status=1/FAILURE` + `Scheduled restart job, restart counter is at N` = **真崩溃**。
- 只有 `Deactivated successfully` = 主动停（部署/手工 restart）。
- 定位到崩溃时刻要读**那一段**日志（`--since/--until` 精确到 10 分钟），看是启动即退（配置错）还是运行中崩。
- 日志"最近 24h 无 error"不等于健康——**可能只是没人调用**，见第四节。

**配套单元被 restart 带走 = 最隐蔽的一类「部署重启后遗症」**（2026-10-28 实录）：

一个 worker 停了 22 小时，journal 里既无 `Failed` 也无 `Scheduled restart`，只有 `Deactivated successfully`；对照主服务日志发现停止时刻与 `systemctl restart <主服务>` **同一秒**（同一秒还有一条 sshd 接受外部 key 的记录 → 是远程部署动作，不是崩溃）。

根因在依赖声明：worker 上写了 `Requires=<主服务>.service` + `After=`，这只表达「主服务停我也停」，**不表达「主服务起我也起」**；`WantedBy=multi-user.target` 只在开机时生效。所以远程 restart 主服务会把 worker 永久留在 dead。

审计判据与修法：

```bash
systemctl cat <worker> | grep -E "^(Requires|After|PartOf|WantedBy)"
# 主服务侧缺 Wants 就是缺口
grep -rn "Requires=" /etc/systemd/system/*.service.d/*.conf
```

在**主服务**侧加 drop-in（最小改动，不动 worker）：

```ini
# /etc/systemd/system/<主服务>.service.d/10-<worker>.conf
[Unit]
Wants=<worker>.service
```

⚠️ 只给 worker 加 `PartOf=<主服务>` **不够**：主服务 restart 时若 worker 已 inactive，PartOf 不会把它启动。改完必须实测一次 `systemctl restart <主服务> && sleep 5 && systemctl is-active <worker>`。

### 3-b、`NRestarts` 是判崩溃最快的一条，比翻日志快一个数量级

```bash
systemctl show <unit> -p Id -p NRestarts -p ActiveEnterTimestamp -p MainPID
```

| `NRestarts` | 含义 |
|---|---|
| `0` + 有 `Application is stopping` / `Deactivated successfully` | 主动 restart，不是崩溃 |
| `0` + 进程没了且无优雅停止记录 | 被 OOM kill / 段错误，查 `dmesg -T` |
| 几十 | 有过崩溃，看最近是否还在涨 |
| **上千** | **无限重启循环**，业务早已不可用，先修启动条件 |

实测（2026-11-05）：某 unit `NRestarts=1193`，日志里全是 `Failed to locate executable ...: No such file or directory` —— 路径写错 → 每 5 秒崩一次 → 连续 3 小时约 1200 次。**这类循环在 `journalctl -u <unit>` 的业务日志里一条业务报错都没有**，只有 systemd 的 `Failed at step EXEC spawning`，按业务关键字 grep 会完全漏掉。看到 `NRestarts` 上千就直接去看 systemd 层日志，别在业务代码里找。

### 3-c、真实停机空窗必须自己算，别用监控"已恢复"代替

巡检/告警按分钟取样，**只能证明取样那一刻**。实测抓到过一次巡检全程未报的空窗：

```
18:57:03  stopping  →  21:41:04  starting     # 空转 2 小时 44 分
```

因为同期巡检恰好都落在服务已恢复的时点，`❌ 未运行` 和 `✅ 已恢复` 都没出现。核算方法：

```bash
journalctl -u <unit> --since "-7 days" --no-pager \
  | grep -E "Starting |Application is stopping|Stopped " | tail -30
```

逐对算 `stop → 下一次 start` 的间隔，**超过 1 分钟的都单独列进报告**。判读告警里 `❌/✅` 成对出现时，先对齐秒级时间（`ActiveEnterTimestamp` 是否落在两次告警之间），那通常是一次重启的上下半段，不是两次故障 —— 详见 `error-digest-triage` 的 `references/service-restart-window-triage.md`。

### 3-d、重启窗口内的下游报错不是独立故障

服务停止/启动前后几分钟，同一台机上其他服务常会集中报 `unable to open database file`、连接拒绝这类错误。这是**停机窗口的伴生噪音**，不是第二起事故。

判据：报错时间全部落在 `stop → start` 的空窗内、`PRAGMA integrity_check` 全部 `ok`、恢复后不再出现。分开计数，不要和主故障相加。

## 四、业务活性：从数据层取证

只读数据库，不看进程：

```bash
sudo python3 - <<'EOF'
import sqlite3, datetime
db=sqlite3.connect("/var/lib/<svc>/state.db")
tabs=[r[0] for r in db.execute("select name from sqlite_master where type='table'")]
for t in tabs:
    n=db.execute(f'select count(*) from "{t}"').fetchone()[0]
    print(f"{t:30} {n}")
# 每张表的时间列取 MAX，判断"最后一条记录是几小时前"
EOF
```

要点：
- **先 `pragma table_info` 看真实列名**，不要猜 `kind`/`status`——本项目 `events` 表用的是 `action`/`level`，猜列名会直接 `no such column` 白跑一轮。
- 时间戳是 Unix 秒 → 换算北京时间再报，并且和采样时间比，得出"最后活动 = 几小时前"。
- 报"近 24h / 近 7d 动作分布"比报总行数有用得多；总行数只说明历史积累。
- 找积压要看**状态列的真实枚举值**（`select state,count(*) group by state`），不要假设有 `pending`。

### 4-b、状态文件真实路径：`/opt/<svc>/state.db` 是 0 字节 ≠ 服务没数据

**这是最容易把人带偏的一条，2026-11-04 实录**：`/opt/ad-killer/state.db` 是 **0 字节**、
mtime 停在 12 天前，`journalctl -u ad-killer` 近 24h 只有 1 行 systemd 记录 ——
三件事拼起来看着就是「服务在空转」。实际它跑了 2 天没重启、正在 polling、
库里有 402 次入群验证和 69 次真实封禁。

原因是 unit 用了 systemd 的 `StateDirectory=` / `LogsDirectory=`（配合 `ProtectSystem=strict`、
`PrivateTmp` 一类加固），真实路径被搬到私有挂载：

| 你以为的 | 实际路径 |
|---|---|
| `/opt/<svc>/state.db` | `/var/lib/private/<svc>/state.db` |
| `/opt/<svc>/*.log` | `/var/log/private/<svc>/bot.log` |

**唯一可靠的判据是问内核「这个进程到底打开了哪些文件」**，不要靠猜路径、也不要靠 `find`：

```bash
PID=$(systemctl show <unit> -p MainPID --value)
ls -l /proc/$PID/fd | grep -vE 'socket|/dev/(null|urandom)'   # 真实 db / 日志 / 凭据路径
cat /proc/$PID/wchan; echo                                    # do_poll = 正在轮询，不是卡死
grep -E 'State|Threads' /proc/$PID/status
systemctl show <unit> -p ActiveState -p SubState -p NRestarts -p ExecMainStartTimestamp
```

- `wchan` 为 `do_poll.constprop.0` / `ep_poll` / `futex` 且 `State: S` = 正常阻塞等待，**不是挂死**。
- `NRestarts=0` + `ExecMainStartTimestamp` 距今数天 = 一次没崩。
- `/opt` 下那个 0 字节同名文件是**旧版本或旧 unit 的残留**，报审计时作为「小瑕疵」单列即可，
  绝不能据此写「数据库为空 / 服务未工作」。

**判完路径再看日志**：加固过的 unit 日志可能不在 journal 里（`StandardOutput=append:` 指向私有目录），
`journalctl` 只有 systemd 自己的启停行。此时 `tail /var/log/private/<svc>/*.log` 才能看到业务动作
（`deleteMessage`、`restrictChatMember` 这类真实 API 调用和 `update_processed` 计数）。

### 4-c、模式开关 ≠ 整体停摆：`observe` / `dry-run` 只关一类动作

同一个服务常有**分目标、分动作**的开关（每群 `mode: observe`、每类 `enabled: false`、
`dry_run=True`）。看到 `observe` 就写「这个服务什么都没干」是硬错——它可能同时在跑入群验证、
成员名册、外部 bot 拦截、定时扫描。

判据不看 config，看**库里的动作结果分布**：

```python
# 同一类案件的处置结果，执行模式与模拟模式会分成两个 state
for r in c.execute("select state, count(*) from cases group by state order by 2 desc"):
    print(r)   # 例：banned=69 / simulated_ban=5 / protected=8 / cancelled_ban=2
```

- `banned` 有量 = **在别的目标上已经真实执行过**，系统是验证过的，不是纸面逻辑。
- `simulated_ban` 有量而 `banned` 为 0 = 该目标处于观察期。
- 报告里把「在 A 群执行 / 在 B 群观察」分开写，并给出各自计数，不要用一个 mode 概括整个服务。

## 五、安全：五项固定检查

```bash
# 1. 硬编码凭据
grep -rnE "(token|api_key|password|secret)\s*=\s*['\"][A-Za-z0-9_\-:]{16,}" *.py | head
grep -rnE "[0-9]{8,10}:[A-Za-z0-9_-]{30,}" *.py | head        # Telegram token 形态
# 2. 凭据文件权限与注入方式
ls -l /etc/<svc>/
# 3. 危险调用
grep -rnE "subprocess|os\.system|eval\(|exec\(|shell=True" *.py | grep -v test_
# 4. 鉴权入口
grep -nE "owner_id|is_owner|ADMIN|authorized|getChatMember" bot.py | head
```

通过标准（本类项目已验证的良性形态）：
- 凭据在 `/etc/<svc>/`（600 root），unit 用 `LoadCredential=` + `Environment=AD_CONFIG=%d/...` 注入，进程不读明文文件；
- `subprocess` 全用 list 传参、无 `shell=True`、无 `eval/exec`；
- 鉴权走平台原生（Telegram `getChatMember` + 委派表），不自造绕过路径；
- unit 有 `CapabilityBoundingSet=`（空）、`ProtectSystem=strict`、`ProtectHome=yes`、`PrivateTmp`、`NoNewPrivileges`、`TasksMax`。

**5. 凭证/状态文件对「运行用户」可读性（最隐蔽的一项，必查）**

服务以非 root 用户运行时，只要有别的进程（root 的 cron、另一个 agent、手工 sudo）
用「临时文件 + `os.replace`」的方式重写过凭证/状态文件，属主就会变成 root，
服务读不到 → 静默回退到旧文件或空值 → 表现为**周期性 401 / 鉴权失败 / 空数据**，
而用同一份凭证手工调 API 却是 200。

```bash
# unit 跑在哪个用户下
systemctl show <unit> -p User -p Group
# 该用户能不能读关键文件（这一条才是判据）
sudo -u <svcuser> test -r /var/lib/<svc>/credentials.json && echo READABLE || echo NOT_READABLE
ls -l /var/lib/<svc>/ | head
# 复发证据：失败是否按固定周期刷（说明是每轮读取失败，不是偶发网络问题）
journalctl -u <unit> --since "-30min" --no-pager | grep -cE "401|鉴权|auth"
```

修复分两层，只做第一层会复发：现场 `chown <svcuser>:<svcuser>` + 重启；
代码层在原子写盘的 `os.replace` **之前** `os.chown(tmp, 原uid, 原gid)`，沿用原属主。

**先查「是谁把它改成 root 的」**：常见是另一台机器 ssh 过来以 root 跑「校验 + 刷新」脚本，
校验失败就顺手调 refresh，refresh 用「临时文件 + `os.replace`」写盘 → 属主变 root。
所以只改现场不修 refresh 的写盘逻辑，下一轮过期必然复发。

```bash
grep -n "def validate.*auth" -A 25 <svc>/client.py   # 校验失败时是否顺手 refresh
grep -n "def _atomic_save" -A 20 <svc>/refresh_token.py  # 写盘是否 chown 回原属主
journalctl -u <unit> --since "-1h" --no-pager | grep -E "validate|refresh|401" | tail
```

实证（2026-10-24）：某 sync worker 因这个原因 401，从属主被 root 改写那一刻（`11:30:37`）
持续到人工修复（`11:43`），约 13 分钟；日志里只有鉴权失败，看不出属主问题。

**5-b. 同一个 Bot Token 在多台机器各存一份 → 只改一处，另一处继续 401**

现象：某台机上的采集/推送服务每轮都报 `Telegram getMe 失败: HTTP=401 Unauthorized`，
**而同一个 Bot 在另一台机上完全正常**。此时最容易被误判成「token 被 revoke / 泄露被封」，
然后去 BotFather 重签——完全没必要，且会连带废掉正常那台。

判据是**先比对两端的 token 指纹，不打印明文**：

```bash
# 有效端（服务正常那台）
grep -oE '^TELEGRAM_BOT_TOKEN=.*' .env | cut -d= -f2- | tr -d "\"'" | sha256sum | cut -c1-16
# 失效端（报 401 那台）
ssh <host> 'grep -oE "LEMON_BOT_TOKEN=.*" /root/.<envfile> | sed "s/^LEMON_BOT_TOKEN=.//; s/.$//" | sha256sum | cut -c1-16'
```

**前缀不同 = 副本漂移，不是 token 失效。** 再看两端配置文件 mtime：本例有效端 `.env` 是当天
`14:38` 更新（当日 14:35 首次出现 `InvalidToken`，14:38 换新 token 恢复），失效端 `/root/.lemon_music_env`
还是 **37 天前** 的副本 —— 当天换 token 时只改了本机，远端没人同步。

修复：从有效端把值同步过去，**走 stdin 传值，不要让 token 出现在命令行参数里**（`ps` 全机可见）：

```bash
# 远端放一个只读 stdin 的替换脚本，不 echo token
printf '%s' "$TOKEN" | ssh <host> 'python3 /tmp/sync_token.py'   # 内部只打印 len 和 sha 前缀
```

配套动作：`cp -a` 备份原 env 文件、`chmod 600`、改完先跑**服务自己的 preflight**（本例
`bash run_crawl.sh` 会先 `getMe` + `getChat` 再干活），通过后再触发一次真实业务轮次，
日志出现「本轮完成，新增入库 N 首」才算闭环。

**审计清单**：多机共享同一 Bot Token 时，轮换前先 `grep -rl <变量名>` 把所有消费者列全
（env 文件、`EnvironmentFile=`、写死在脚本里的默认值、容器 env）。只改主控机是这类
「一台好一台坏」的标准成因。查完再报「哪些机器受影响」，不要笼统说「token 过期了」。

⚠️ **别把 `ps` 的 `ELAPSED` 当故障持续时长**：同一进程 `ELAPSED 1-12:25:04` 只说明它连续跑了
一天半，不代表空转了这么久。真实停摆区间要用「业务成功记录的 `MAX(时间戳)`」与「故障开始时刻」
两头夹出来：本例最后一条 success 是 `10:53:52`，`11:30` 才被锁。
（这条我当场误判成「空转 1 天 12 小时」并向用户更正过，写进技能避免复发。）

小瑕疵也要报但不夸大：`/opt/<svc>/config.json` 644 world-readable（若只含群 ID/用户名，不是泄露）、0 字节 `state.db` 空残留（真实数据在 `/var/lib/`）。

## 五-a、模型对话与工具历史中的凭据暴露审计

用户曾向模型发送密钥、忘记发送范围或担心第三方中转留存时，按 `references/credential-exposure-audit.md` 做本机只读、零秘密回显的审计。

- 在本地进程中解析和比对原值，只输出类别、去重计数、消息角色及覆盖范围；不要把原始聊天、命中行、请求正文或密钥片段交给模型再次分析。
- 区分四层证据：格式候选、结构可解析、当前配置值与历史精确重合、已核实外部滥用。历史命中不证明中转站接收，更不证明盗用；配置存在不代表运行时仍使用或凭据仍有效。
- 先声明扫描范围与只读边界。没有命中只能说本次规则未命中，不能声称从未泄露。配置项未设置不等于保护已关闭，须另查实现默认值和运行时加载。
- 审计授权不等于轮换授权。用户随后明确要求“逐一处理”时，可在已授权范围按依赖逐项推进，不重复索取同一授权；但仍须核实独立恢复入口、备份及消费者，按新建、更新、验收、撤旧执行，不擅自断开控制入口。
- **计数先排除不可复用值**：`secret_fingerprint`、凭据哈希和 bcrypt 密码校验值不等于可用凭据，不纳入“待轮换密钥”计数；配置中的密钥数组、非标准凭据文件和实际 `IdentityFile` 也不能漏查。报告明确区分候选、原值重合、认证仍有效和外部滥用。
- **轮换验收要正反两测**：新凭据能用且旧凭据被拒，才算撤旧闭环。SSH 的 `-i` 可能叠加别名里的其他 `IdentityFile`；负向验证须隔离配置、agent 和连接复用，不能把其他钥匙或旧连接的成功误判成暴露私钥仍有效。
- **用户交给代理验收时主动查业务证据**：先查已有收发事件与数据库，不把可核实工作退给用户重复发命令。按当前 systemd `InvocationID` 隔离新进程日志；JSON `MESSAGE` 先做字符串类型检查，空筛选和验收脚本失败不等于服务失败。对聊天 Bot 分开验证接收、模型生成、发送 API 与对应自动回复送达；`completed` 请求、非零输出及独立测试发送成功不能拼成自动回复已送达。AstrBot 的 `provider_stats`/`conversations` schema、隐藏录入与两类部署的切换顺序见 `references/credential-handoff-and-runtime-verification.md`。
- **继续用中转的边界**：工具输出脱敏、日志脱敏、用户粘贴、历史工具参数和实际外发请求是不同保护面；仅看开关或单测通过不能宣布安全。插件已编写、已启用、运行进程已加载、请求实测已脱敏必须分别验收；同用户可读凭据或免密码管理员权限不是隔离。
- 具体核验、无秘密回显的 SSH 轮换及防泄密验收清单见 `references/credential-rotation-and-egress-verification.md`；不把未完成的网关轮换或未上线插件当作已验证方案。
- **交互按阶段，不按点击拆碎**：用户要求“一步一步”通常指一次处理一个对象。默认一次给完同页可连续完成的设置、摘要核对和保存步骤，仅在目标、权限、不可逆撤销或异常处分叉；不要每点一个下拉框就索要截图。用户指出“太慢”后立即合并连续步骤，不把旧的逐点击流程固化为偏好。
- **“给足权限”先查已有凭据，不靠重复索取解决**：区分业务权限、元数据读取和令牌管理写入；持久保存凭据引用与已验证用途，凭据原文不进记忆/技能。后台名称、权限策略和本地值必须精确映射；不得为了好操作擅自降权或扩成全局管理。
- **换密钥的用户交接也是验收**：先准备并测试隐藏输入暂存入口、备份和切换路径，再让用户执行会立即废旧的操作。每次明确目标机器与机器人，告知中断窗口；确认新值落盘后由代理完成切换，不要求用户把新值贴聊天。已跑通的安全录入、两类轮换顺序和按 systemd invocation 验收见 `references/credential-handoff-and-runtime-verification.md`。
- **跨机消费者不能漏掉实验框架**：用户说“破甲里也用了吧”等提醒时，立即暂停删除、撤销与默认路由修改，承认此前覆盖不足。凭据依赖清单应包含远端沙箱、实验框架的 web/headless 两类 profile、独立 env 与 EnvironmentFile，以及动态读取模型池的其他 Bot；不能因本机主模型和备用链未引用就判闲置。先在本地进程中精确比对是否同一原值，再登记默认 provider/model、配置消费者与运行态证据。**配置存在、服务 active、真实推理可用是三层结论**；本机 403 或空模型列表不能代表远端应用不可用。已验证的配置核对方法与未完成的调用验收边界见 `references/cross-host-model-credential-dependencies.md`。
- **撤旧是最后门禁，不是下一步口号**：可并存的新旧 API Key，必须先验新值、切消费者、核验长驻 worker 实际继承的新值，再让用户删旧；不能先说“现在可删”，下一轮才补发现缓存。`/proc/PID/environ` 缺某变量不证明未加载或仍用旧值；结合当前工具继承环境的本地精确比对、进程祖先与全新真实请求分层取证。**在独立进程复现网关 loader/resolver 只算配置解析证据，不是既有网关内存或实际调用证据；重载前一次列清 Web UI、gateway 及其他消费者，别让用户重启一遍后再补第二遍。** 官方重签即废旧的 Bot Token 则先准备恢复路径并明确中断，再重签切换。用户确认收到了对应自动回复后，把该确认记入本地验收台账，不再重复要求发送同一测试。

## 五-b、长任务：凭证寿命与调度锁（维护/修复时必查）

「净化/同步/巡检一直失败」常常不是业务逻辑错，而是**长任务 × 短凭证 × 独占锁**三件事撞在一起。
四项固定检查：

### 1. 凭证寿命 < 任务时长 → 必然中途 401

2 小时 JWT + 60~75 分钟全量递归扫描，只要任务起跑时 token 已消耗过半，就一定死在半路。
实测：`05:26` 签发，`06:19` 起跑，`07:26` 报 401，白跑 67 分钟，日志只有一行 401 看不出原因。

- 错误修法：等 401 再刷新（此时已浪费整轮）。
- **正确修法：每次请求前按 JWT `exp` 主动续期**，留 10 分钟余量。

```python
def token_seconds_left(token=None):          # 本地解析，不发请求
    token = token or get_access_token()
    if not token or token.count(".") != 2:
        return None
    p = token.split(".")[1]; p += "=" * (-len(p) % 4)
    try:
        return int(json.loads(base64.urlsafe_b64decode(p))["exp"] - time.time())
    except Exception:
        return None
```

在 `api_request` 开头：`if (left := token_seconds_left()) is not None and left < 600: 拉新凭证`。
验收标志：长扫描日志里出现「剩余 Ns，已续期」且**全程无 401**。

### 2. 401 兜底会死循环

刷新源与消费方共用同一份凭证时，「拉取最新凭证」拿回的就是刚失败那一个，
同步函数还会打印 `ALREADY_CURRENT` 然后原样重试 → 整轮报废。

判定必须看**凭证是否真的变了**：

```python
fresh = get_access_token()
if not fresh or fresh == failed_token:
    force_refresh()          # 让刷新源（唯一 owner）强制轮换
    fresh = get_access_token()
# 只重试一次；仍失败就显式抛错，不要静默重试
```

### 3. 独占锁饥饿：调度有、日志有、当天零成功

主任务持锁 60+ 分钟，后面每 30 分钟一轮的补偿任务全部 `Lock is busy` 退出。

```bash
grep -c "Lock is busy" <log>            # 补偿轮次是否全被挡
ps -eo pid,etime,cmd | grep <sweep>     # 谁在长期持锁
```

修法不是加锁等待，而是**拆职责**：
- 主流水线只做下发/主流程，把清理目标 `enqueue` 后立即释放锁（`defer_cleanup=True` 这类开关）；
- 长扫描交给专职轮转任务，**一轮一个分区**，每轮独立进程、独立取 token。

### 4. cron 时区：注释写 BJ 不算数

`timedatectl` 为 `Etc/UTC` 时，`*/30 6-23` 是 UTC 06–23 = 北京 14:00–次日 07:30。
排程一律按 `BJ 时刻 - 8h` 换算，**改完必须 `crontab -l` 回读逐行核对**（本次就把 BJ 06:00
误写成 UTC 06:00，返工一次）。

## 六、依赖链路：端到端探针，不看端口在听

端口在 listen 只证明进程绑定了 socket。要发真实请求：

```bash
sudo python3 - <<'EOF'
import json,urllib.request,time
cfg=json.load(open("/etc/<svc>/config.json"))
base=cfg["ai"]["base_url"].rstrip("/")
key=open("/etc/<svc>/ai-key").read().strip()
payload=json.dumps({"model":cfg["ai"]["model"],"messages":[{"role":"user","content":"ping"}],"max_tokens":5}).encode()
req=urllib.request.Request(base+"/chat/completions",data=payload,
    headers={"Authorization":"Bearer "+key,"Content-Type":"application/json"},method="POST")
t=time.time()
try:
    with urllib.request.urlopen(req,timeout=30) as r:
        print("OK", r.status, f"{time.time()-t:.1f}s", json.loads(r.read(4000)).get("model"))
except urllib.error.HTTPError as e:
    print("FAIL HTTP", e.code, e.read(300).decode(errors="replace")[:200])
EOF
```

报"HTTP 200 / 1.8s"这种实测值，不报"链路应该是通的"。

### 6.2 不许发请求时的归因：nginx upstream → 监听进程 → cgroup

只读审计常被要求"不 curl 真实业务"，此时仍能确定"谁在给这条 upstream 提供服务"，靠的是三层元数据对撞：

```bash
# 1) 容器内 nginx 的 proxy 目标（只取目标形态，不打印整份配置）
docker exec <ctr> grep -hoE "proxy_pass +https?://[^;]+" /etc/nginx/nginx.conf
# 2) 该端口谁在听（拿 PID）
sudo ss -lntp | grep ":<port> "
# 3) PID 属于哪个容器 / 哪个 systemd 单元
sudo head -3 /proc/<pid>/cgroup        # docker-<id>.scope → 容器；<unit>.service → systemd
docker inspect -f '{{.Name}}' <id>     # 反查容器名
```

归因结果分三类落表：`同 compose 服务` / `同机容器` / `独立 systemd 服务`。

- **第三方独立服务出现在 upstream 里 = 迁移耦合点**：身份不同、不可合并，但必须同批或"先建后拆"，单独列一条依赖边。
- 这条方法只能回答"哪条 upstream 指向谁"。**具体 location / 路径用途仍是未确定**，不要据此推断业务语义（是登录？面板？数据接口？），除非另读配置——那就超出只读脱敏范围了。
- 找不到监听者就写"1 条 upstream 未归因"，不要猜。

### 6.3 全线 502 的分层归因：后端 active ≠ 链路健康

一个对外服务常是**多段链路**：`CF Tunnel → 容器 nginx:非标端口 → systemd 后端:高位端口 → 数据文件`。
任一段断掉，对外都表现为**同一个 502**，而 `systemctl is-active` 后端往往还是 `active`。
**只看后端 systemd 状态就下结论，会把「前置代理停了」误判成「服务挂了」或「规则坏了」。**

按链路从外到内逐段验，一次定位到断点：

```bash
# ① 边缘/隧道层：日志会直接点名回源失败
journalctl -u <tunnel-unit> -n 50 --no-pager | grep -E 'ERR|connection refused|Unable to reach'
#   典型输出：dial tcp 127.0.0.1:2096: connect: connection refused  ← 断点在前置 nginx
# ② 前置代理层：端口在不在听 + 容器活没活
docker ps -a --format '{{.Names}}\t{{.Status}}' | grep <proxy-ctr>
ss -ltnp | grep <front-port> || echo 'FRONT PORT NOT LISTENING'
# ③ 后端层
ss -ltnp | grep -E ':<backend-port>'
curl -s -o /dev/null -w '%{http_code}\n' http://127.0.0.1:<backend-port>/healthz
```

判读：② 端口消失但 ③ 正常 ⇒ 故障在**前置代理容器**，与业务代码无关，`docker start` 即恢复。

#### 🔴 配套铁律：`restart policy = no` 的容器是静默停服源

```bash
docker inspect <ctr> --format 'restart={{.HostConfig.RestartPolicy.Name}} exit={{.State.ExitCode}} oom={{.State.OOMKilled}} finished={{.State.FinishedAt}}'
```

实测（2026-10-30）：某前置 nginx 容器 `ExitCode=0`（**优雅停止，不是崩溃、不是 OOM**）、
`RestartPolicy=no`，静默停了 **6 小时**无人发现，期间该入口下所有订阅/管理页全部 502。
`docker ps` 默认不显示已退出容器，`systemctl` 也管不到它 —— 这类停服**没有任何自动告警会响**。

修法（**不需要 `docker rm` 重建**，因此不会重置 DOCKER-USER 防火墙链，比重建安全）：

```bash
docker start <ctr>
docker update --restart unless-stopped <ctr>      # 防复发
```

审计时的固定检查项：对每个承载对外入口的容器核一次 `RestartPolicy`，
`no` 即列入待决策项（尤其 host network 的 nginx/反代容器）。

#### ⚠️ 恢复后必须逐条复验，别只看容器 Up

```bash
for u in <关键URL列表>; do echo -n "$u "; curl -s -m 20 -o /dev/null -w '%{http_code}\n' "$u"; done
```
并核对业务计数一致（多格式输出应对同一 `count`），确认不是「容器起来了但内容被截断」。

#### 区分「既有 502」与「本次故障」

同一入口的**根路径**可能长期 502（反代指向一个本来就没启动的内部面板），
而业务路径走独立 location、完全正常。**不要把根路径 502 当成故障根因** ——
先确认故障 URL 与正常 URL 是否落在同一 location。

但主故障修完后，这个根路径 502 仍是**真实残留缺陷**（用户看到的就是「站点还是坏的」），
按下面两步定性再决定动不动：

**① 定位 502 的起始时刻**（区分「长期如此」与「最近才坏」）：
```bash
docker logs <proxy-ctr> 2>&1 | grep -E '"GET / HTTP.* 502' | head -3   # 首条 502 的时间戳
docker logs <proxy-ctr> 2>&1 | grep -E '"GET / HTTP.* 200 ' | tail -3  # 最后一次正常的体积
```
若首条 502 与某次已知停机/迁移时刻吻合，说明是那次动作留下的死配置，不是新故障。

**② 反查「死上游」到底是什么**（上游已无监听时，6.2 的 PID/cgroup 法失效，改用日志路径指纹）：
```bash
docker logs <proxy-ctr> 2>&1 | grep -E '"GET |"POST |"HEAD ' \
  | grep -vE '<已知业务路径 1>|<已知业务路径 2>|/v0/management' \
  | awk '{print $7}' | sed 's/?.*//' | sort | uniq -c | sort -rn | head -20
```
实测（2026-10-30）：某入口 `location / → 127.0.0.1:28080` 的上游已不存在，
路径分布打出 `POST /api/agent/ws` 1186 次、`/api/nodes` 299、`/api/me` 255、`/admin/nodes` 108
⇒ 一眼认出是 **Beszel Hub**（监控面板），与某次「只留 Komari」的监控迁移正好对应。
**只看端口号永远猜不出来，路径指纹一次就定身份。**

**③ 改之前先证明根路径没有真实用户**（否则会把还在用的东西 404 掉）：
```bash
docker logs <proxy-ctr> 2>&1 | grep -E '"GET / HTTP' | grep ' 200 ' \
  | grep -viE 'censys|palo alto|infrawatch|modat|keyscanner|forestengine|internetmeasurement|zgrab|nmap|masscan|curl/|python|go-http|aiohttp'
```
过滤后为空 ⇒ 全是扫描器，可安全处理。

**④ 处置决策**：兜底 `location /` 改为 `access_log off; return 404;`（带注释写明退役原因），
**不要直接删 location**（兜底块删掉后未知路径会落到别处或暴露默认页）。备份 → `nginx -t`（必须 `2>&1`）→ `reload` → 复验根路径 404 且业务路径仍 200。

**nginx 跑在容器里时，三条命令必须都在容器内执行**（2026-10-30 实录）：

```bash
docker exec <ctr> nginx -t              # 宿主机上的 nginx -t 测的是宿主自己的配置，与本容器无关
docker exec <ctr> nginx -s reload       # 不要用 docker restart：会短暂断所有 server block
docker ps --format '{{.Names}}\t{{.Status}}' | grep <ctr>   # 确认 Up 时长未重置
```

配置是 bind mount 时 `-s reload` 即生效，**不需要**重启容器；用 `docker restart` 反而把同一入口上的
其他站点一起打断（本次该容器同一份配置里还挂着 CPA 的 2083/2096 server block）。

**同端口多 server block 时，验收必须覆盖「不属于本次改动」的那一侧**：`listen 2096` 上同时有
`server_name la.<PRIVATE_IDENTIFIER>`（规则站）和 `cpa.<PRIVATE_IDENTIFIER>`（API 网关），改前者的 `location /`
必须复验后者仍 200，否则等于用一个 404 换掉了另一个站。

#### 🔴 先找「上一次退役的取证包」，再宣布服务坏了

自建服务被有意下线时，负责任的清理会留一份 `*.before.json`。这类目录常在 `/root/<任务名>-<YYYYMMDD>/`：

```bash
sudo ls -la /root/ | grep -iE '<服务名>|only|retire|migrat'
sudo ls -la /root/<命中目录>/
#   beszel-agent.before.json / lemon-monitor-proxy.before.json / monitor.before.db / services.before.txt
```

**它的价值在于给出「原配置是什么」**：本次 `lemon-monitor-proxy.before.json` 显示
`RestartPolicy = unless-stopped`，而线上是 `no` ⇒ 直接证明「是那次清理改的，不是本来就该这样」，
于是 `docker update --restart unless-stopped` 是**恢复原状**而非新增行为，可以放心做。

> 铁律：**看到 5xx 先别改代码**。先问三个问题 ——
> ① 最近有没有一次「只留 X / 下线 Y」的清理？② 它有没有留下 before 快照？③ 线上配置和 before 快照差在哪？
> 三问答完，根因基本就自己浮出来了。

## 七、运维缺口三查（审计的真正价值所在）

### 7.1 监控覆盖
```bash
grep -rl "<svc>" /opt/monitor /usr/local/bin ~/hermes-jobs ~/lemon-ops-bot 2>/dev/null | head
```
零命中 = **服务挂了没人知道**。这条必须作为第一优先项报给用户，而不是埋在末尾。历史实证：某 bot 迁移后旧实例停了 7 天 17 小时无人发现。

#### 7.1-b 有监控脚本 ≠ 监控有效：硬编码的主机特征会静默失明

**这是「监控覆盖」最隐蔽的假阳性**：脚本存在、挂在 timer 上、退出码 0、从来不报错 —— 但**一条数据都没采到**，因为它读的是迁移前那台机器的特征。

实测（2026-11-06）：`lemon-ops-bot/main.py` 里 `TRAFFIC_IFACE = "ens5"`，那是 AWS EC2 的网卡名；机器迁到 Leaseweb 后网卡叫 `eth0`。于是 `_traffic_read_counters()` 遍历 `/proc/net/dev` 永远匹配不到 `ens5`，返回 `None`，`traffic_sample()` 直接 return，**整条流量监控连同 70%/85%/100% 三档告警一起静默失效**，而 state 文件里还留着迁移前带过来的旧数据，看起来「有记录」。

固定检查（任何按主机特征采集的监控都要过一遍）：

```bash
# 1) 代码里写死的主机特征
grep -nE '"(eth[0-9]|ens[0-9]+|enp[0-9a-z]+|wlan[0-9]|/dev/(sd|nvme)[a-z0-9]+)"' <脚本>
# 2) 该特征在本机是否真的存在
ls /sys/class/net/            # 网卡真实名字
grep -oE "^[ ]*[a-z0-9]+:" /proc/net/dev | tr -d " :"
# 3) 状态文件是不是「停更」而不是「零值」
stat -c '%y %n' <state.json>; TZ=Asia/Shanghai date   # mtime 是否停在迁移那天
```

**判据**：状态文件 mtime 停在很久以前 + 里面只有一个旧月份条目 = 采集早就断了，不是这段时间用量为零。

**修法用自动探测，别再换一个写死的名字**（换机器还会再错一次）：

```python
def _detect_traffic_iface():
    """默认路由所在网卡。原值写死 ens5，迁到 Leaseweb 后变 eth0，监控整体静默失效。"""
    try:
        with open("/proc/net/route", "r", encoding="utf-8") as f:
            for line in f.readlines()[1:]:
                cols = line.split()
                if len(cols) > 1 and cols[1] == "<YOUR_USER_IDENTIFIER>":   # Destination=<YOUR_USER_IDENTIFIER> = 默认路由
                    return cols[0]
    except Exception:
        pass
    return "eth0"
```

**验收必须看新数据落盘，不看服务 active**：改完重启，等一个采集周期，确认 state 文件里出现了**当月**条目且 `seeded_from_boot: true`（表示用开机累计校准了漏算的部分）。同类坑还有写死的磁盘设备名、`/dev/dri` 路径、旧 IP、旧端口 —— 迁移审计时一律按上面三步过一遍。

⚠️ 顺带一条采样纪律：`seeded_from_boot` 的首次数值是**开机以来的累计**，不能直接当「本月用量」。要报月增必须再采一次算增量（`60s 增量 × 43200` 折算），并把「历史漏算区间」写进报告。


### 7.2 备份覆盖
```bash
ls -lt /root/<svc>-backups /root/<svc>-deploy-backups 2>/dev/null | head
find /root -name "state.db" -newermt "<近3天>" | head
```
- 部署时的手工备份 ≠ 定时备份。**看最新一份的日期，不数目录个数。**
- 别忘跨机核对：AWS 的离线加密备份只打包 `$HOME`，不含另一台机器的 `/opt/<svc>`。这类"以为有、实际没有"的覆盖缺口是最容易漏报的。

#### 7.2-b 备份链可能不止一条，而且断的是最安静的那条

**本环境实测三条互不相干的链，任一条成功都不代表另两条。** 前一天刚修好第一条并报告"备份已恢复"，第二天用户照样收到异地备份告警 —— 断的是第三条。

```bash
systemctl list-timers --all | grep -iE 'protect|backup|restic'
crontab -l | grep -iE 'backup|unified'
grep -c backup ~/.hermes/cron/jobs.json
```

| 链 | 触发 | 健康判据（缺一个都不算好） |
|---|---|---|
| unified / `hermes-*` 加密异地 | cron `30 11 * * *` + Hermes job | `jobs/<name>/status` 的 `SUCCESS rc=`、`job.log` 尾部 |
| `naye-protection` restic | `naye-protection-backup.timer`（每小时） | `systemctl show -p ExecMainStatus`（`1` = 失败） |
| Telegram CMS 分片 | `backup_hermes.sh` 每日 | `UPLOAD_MANIFEST.json` |

**`systemctl is-active` 对这条链完全无效**：备份 unit 是 `oneshot`，跑完就是 `inactive dead`，看着像没在跑；`Result=success` 也可能伴 `ExecMainStatus=1`（没设 `SuccessExitStatus` 时 systemd 只记「单元正常结束」）。**只看 `Result` 会漏掉真实失败，必须看 `ExecMainStatus`。**

#### 7.2-c 服务端存储配额：`507 Insufficient Storage` 与本地 `df` 无关

restic 用 `rest:` 后端时，`507` 由**服务端 rest-server 的 `--max-size`** 返回。本地磁盘再空也照样 507（实测：`df` 有 7.3 G 可用、inode 16%、repo 只 3.41 GiB、配额 5 GiB，仍被拒）。

```bash
# 1) repo 指向哪（只打印路径，不打印密码）
grep ^RESTIC_REPOSITORY /etc/<chain>/backup.env | sed -E 's#(://[^/]*).*#\1#'
# 2) 本机监听的是隧道还是本地服务
ss -ltnp | grep <port>;  ps -p <pid> -o args= | sed -E 's/[A-Za-z0-9+/=]{30,}/<redacted>/g'
# 3) 服务端单元里的配额
ssh <host> 'systemctl cat <rest-server>.service | grep -oE "max-size [0-9]+"'
# 4) 服务端真实占用
ssh <host> 'du -sh <repo-path>; df -h /; df -i /'
```

**rest-server 的计数口径与 `du` 对不上**（提到 6 GiB 后同一份数据立刻写成功，`du` 仍只显示 3.41 GiB）。不要耗时间读源码算准它 —— **做一次可控改动（备份 unit → 改配额 → `daemon-reload` → 重启 → 立刻重跑一次备份）就能确认闸门位置**，报告里如实写"口径未定位"。

**四件事凑齐 = 必然周期性撑爆**：每小时备份 + `--append-only`（禁止客户端 `forget`）+ 固定配额 + 服务端无 prune。确认：

```bash
grep -rn 'forget\|prune' /usr/local/libexec/<chain>/   # 空 = 整条链没有保留策略
head -1 /usr/local/libexec/<chain>/backup.py           # 常自述 "no production repair/prune"
```

提配额只是止血：**剩余时长必须用稳态增量折算，不能用单次 `data_added` 估**（本文早期曾按「~124 MB/h」推算"约 20 小时撑爆"，事后实测稳态只有 ~2.2 MiB/h，那个数字是错的，见 `references/restic-repo-growth-measurement.md`）。**必须同时给保留策略方案**，并说明 `--append-only` 下 prune 只能在服务端以 root 直接操作 repo，删快照不可逆、须当次授权。

#### 7.2-d 定位告警源：先问「谁在发」，别先翻业务 bot 日志

用户截图的告警文案就是索引。本地脚本目录搜不到（`grep -rl "<引号原句>" /home/ubuntu --include=*.py --include=*.sh` 为空）时，发送方在 systemd 单元或远端：

```bash
systemctl list-timers --all | grep -iE 'protect|backup'   # 周期=角色：每分钟多半是新鲜度巡检
systemctl show <unit> -p FragmentPath -p ExecStart
```

实测形态：`naye-protection-health.timer` 每分钟跑，阈值写死在脚本里（`if age>4500` → 75 分钟），配套的 `-backup.timer` 每小时跑。**告警文案是「备份没更新」，根因必然在配套的 backup 单元，不在 health 脚本。**

判据顺序：`ExecMainStatus` → `journalctl -u <backup>`（**常常是空的**，脚本自己写文件日志）→ 读 `<state-dir>/last-backup.log` 真实尾部。**journal 为空不代表没跑。**


### 7.3 孤儿资源（迁移遗留）
```bash
# 隧道还有没有消费者
ss -tnp | grep <port>
grep -rl "<port>" /opt /root --include=*.py --include=*.json --include=*.conf 2>/dev/null | grep -v node_modules
# 空转证明：累计 IO 只有 ssh 心跳量
grep -E "^(rchar|wchar)" /proc/<pid>/io
```

**退役判据（缺一不可）**：① 目标端无进程引用该端口；② 无连接；③ 历史退役审计的阻塞原因已消除（例如当初 `retirement_approved=false` 是因为"外部消费者未核实 + SSH 不通"，现在 SSH 通了就要重跑消费者核查，不能沿用旧结论）。判据齐了也只是"建议退役"，**要用户点头才动手**。

### 7.3-b 退役「一块功能」而不是「一个服务」

用户说「额度播报可以关掉了 / 账号检测那部分删了吧」时，服务本身还在跑，只是要拆掉其中一块能力 ——
这类改动删不干净的代价比停服务更高：服务照常 `active`、日志干净，但**菜单里还挂着入口、按钮点了没反应、
定时任务继续发消息**。完整八点清单、归档脚本、离线验收断言与汇报口径见
`references/feature-retirement-checklist.md`，必须记住的三条：

1. **一个功能在 bot 里至少有 8 个落点**：import / 函数本体 / `CommandHandler` / `BotCommand` 云端菜单 /
   `callback_data` 分支 / 键盘按钮定义 / 面板文本拼接与帮助文案 / systemd unit·timer·独立脚本·模块文件。
   最容易漏的是 **`BotCommand` 菜单项**和 **f-string 面板拼接串**，这两个都不在主逻辑里。
2. **归档而非删除**：unit + drop-in + 脚本 + 模块统一 `mv` 到 `<项目>/backups/retired-<功能>-<时间戳>/`，
   汇报里给出这个路径。删文件不可逆，移动可随时捞回。
3. **离线验收要断言五个面同时清零**（函数不存在 / 键盘无残留按钮 / 面板仍能渲染且不含旧段落 /
   源码无死回调名 / `systemctl list-units` 与 `crontab` 双查无残留），别只做 `py_compile`。
   `import main` 的三个前置（用 unit 里的 venv python、补模块级必需环境变量、不要在 `/tmp` 里跑）见该文档。

### 7.3-c 退役「整个服务」：停服务只是第一步，巡检清单必须同批清理

用户说「这个项目我不要了，把服务停掉」时，**`systemctl stop && disable` 只完成了三分之一**。
剩下没清的部分会在下一次巡检周期把告警打回用户手机，用户的第一句话就是
「运维机器人给我发这个，你是不是收尾没做好」。本次实录连续踩了两次（破甲 bot、大肥鱼）。

**为什么必然复发**：巡检脚本的判据是 `ActiveState != active → issues.append('服务未运行：'+unit)`。
服务被有意停掉，巡检并不知道这是「计划内退役」，它只看到「该活的没活」。

退役一个服务必须同批扫完下面七类落点，缺一类就会留一条告警或一个空转任务：

| 类别 | 查法 | 本次命中 |
|---|---|---|
| 巡检服务清单 | 巡检配置里的 `services` / `units` 数组 | `pojai-chat-bot`、`naye-pojai-config-sync.timer` |
| 巡检关键文件 | `critical_files`（路径→最小字节数） | 3 条 pojai 路径 |
| 巡检代码量下限 | `code_file_minimums`（目录→最少 .py 数） | 2 条 pojai 目录 |
| **脚本里硬编码的专属检查** | `grep -n '<服务名>' <巡检脚本>.py` | 「破甲模型配置超 15 分钟未同步」整段 |
| 配套 timer / cron | `systemctl list-timers --all`、`crontab -l`、`/etc/cron.d` | `naye-pojai-config-sync.timer` 每 4 分钟空转 |
| 其他 unit 的排序/依赖声明 | `grep -rl <服务名> /etc/systemd/system/` | `vps-memory-zswap.service` 的 `Before=astrbot.service` |
| 自启残留 | `@reboot` cron、supervisor、`rc.local`、`profile.d` | 无（仍须查） |

**最容易漏的是第四类**：巡检配置往往是「JSON 清单 + Python 脚本里的专属断言」两套。
只删 JSON 里的条目，脚本里那段 `if not provider_sync.exists() or age>900: issues.append(...)`
照样每轮报错。**改完 JSON 必须再 `grep` 一遍脚本本体。**

```bash
# 一次扫全（对每台承载该服务的机器都跑）
NAME='<服务名>'
grep -n "$NAME" /etc/<inspection>/health.json
grep -n "$NAME" /usr/local/libexec/<inspection>/*.py
grep -rl "$NAME" /etc/systemd/system/
systemctl list-timers --all | grep -i "$NAME"
crontab -l 2>/dev/null | grep -i "$NAME"; sudo -n crontab -l 2>/dev/null | grep -i "$NAME"
```

**改法：备份 → 结构化删（用 python 读 JSON、过滤、回写，不要手改缩进）→ 脚本段替换成一行注释 → `daemon-reload` → 立刻手动跑一次巡检**

```python
d = json.load(open(p))
for k in list(d['critical_files']):
    if '<服务名>' in k: del d['critical_files'][k]
d['services'] = [s for s in d['services'] if '<服务名>' not in s]
json.dump(d, open(p, 'w'), ensure_ascii=False, indent=2)
print('before', before, 'after', after)   # 打印数量前后，作为「只删了该删的」证据
```

脚本段删掉后**必须 `python3 -c "compile(open(p).read(),'h','exec')"` 验语法**，
再 `systemctl start <inspection>.service` 实跑，验收标志是日志里出现
`{"issues": [], "external_notices": []}` 且 `alerts/current.txt` 变成恢复态。
**不要只看 `systemctl is-active`** —— oneshot 跑完就是 inactive。

**排障式反向确认**：巡检干净了但用户仍收到告警时，`grep -rln '<告警原句>'` 全盘搜一遍，
定位真正的发送方；`/var/lib/<inspection>/alerts/current.txt` 的 mtime 能证明是哪个周期写的。

**交付话术**：承认漏项（「是我收尾没收干净」），给清理前后计数表和备份路径，
不要解释成「巡检误报」——它不是误报，是退役没做完整。

只读扫描脚本：`scripts/decommission_sweep.sh <服务名> [巡检配置目录] [巡检脚本目录]`，
一次列出七类落点，改之前先跑它。

### 7.4 补上监控缺口后，必须做的四步验收（别只写脚本就报完成）

审计发现「服务挂了没人知道」→ 写巡检脚本 → **到这里只完成了一半**。漏掉下面任何一步，
交上去的都是「看起来有监控、实际不会响」的假保障。

**① 三态测试**（全部用临时路径，不碰真实文件、不给用户发测试消息）

```bash
# 目标路径/状态文件/通知器都用环境变量覆盖，在 mktemp -d 里造场景
export PATCH_GUARD_TARGET="$TMPD/target.py" PATCH_GUARD_STATE="$TMPD/state.json"
export PATCH_GUARD_NOTIFY="$TMPD/notify.py"
```

必测四场景，缺一不可：

| 场景 | 期望 |
|---|---|
| 正常态 | 静默，退出 0，**不发任何消息** |
| 异常态 | 发出告警，内容含可执行的修复/重放命令 |
| 同状态重复跑 | 去重跳过，不刷屏 |
| 恢复态 | 发一条恢复通知，状态回 `ok` |

**② 通知链路必须验证「真的收到」，不能只看脚本打印了内容**

⚠️ **最容易踩的坑：假通知器写成 bash 脚本 → 静默失败 → 误判「通知没发出」**。
`lemon-ops-bot/notify.py` 是被 **venv 里的 python3 拉起**的，所以测试用的假通知器**也必须是 `.py`**；
用 `.sh` 时 `python3 xxx.sh` 直接报错，而调用处 `stderr=DEVNULL` 把错误吞了，表象就是「通知一条没发」。
（本次实测踩到，换 Python 假通知器后立刻收到两条。）

假通知器模板：

```python
# notify.py（放在 $TMPD 里，只记录不发送）
import sys
with open(__file__.replace("notify.py", "sent.log"), "a", encoding="utf-8") as f:
    f.write("=== 通知被调用 ===\n" + (sys.argv[1] if len(sys.argv) > 1 else "") + "\n\n")
```

验收标准是 `cat $TMPD/sent.log` **能看到内容**，不是「脚本自己 print 了告警文案」。

**②-b 告警文案必须自解释，不能只报现象**

用户原话：「给我发的通知需要备注一下到底发生了什么，不然我每次都得问你。」
只写「备份超过 75 分钟没有成功更新」是**不合格告警** —— 它把诊断工作推回给用户。合格告警五要素：

```
❌【数据保护巡检】
- 异地备份已 4.2 小时未成功（阈值 3.5 小时）；最近成功 11-06 10:12；
  最近错误：507 Insufficient Storage；自查：journalctl -u <unit> -n 50
```

| 要素 | 作用 |
|---|---|
| 已持续多久 + 阈值 | 判断严重性，而不是只知道「异常」 |
| 最近成功时间 | 区分「一直没好过」与「刚断」 |
| 具体错误行（截到 ~150 字符） | 直接指向根因类别，省一次往返 |
| 当前值 / 容量占比 | 容量类必须给 `已用/上限 (百分比)`，否则无法决策 |
| 一条可复制的自查命令 | 想深挖时不用回来问 |

**实现上的硬约束**：unprivileged 通知进程读不到 root-only 的失败日志（`LoadCredential=message`
只给一个文件）。所以诊断必须在**有权限的巡检脚本**里拼好整句写进 `alerts/current.txt`，
通知进程只负责转发。给巡检脚本加一个从失败日志尾部抓关键行的辅助函数：

```python
def _last_backup_error():
    for line in reversed(log_lines):
        m = re.search(r'Fatal:\s*(.+)', line)
        if m: return m.group(1).strip()[:150]
```

⚠️ **写死一句话的失败通知也要补上下文**：`notify.py` 里 `kind=='backup'/'restore'/'retention'`
这类固定文案，必须加「常见原因 + 自查命令 + 真实单元名」。实测有个 retention 文案让用户去查
`naye-offsite-retention`，而**实际单元叫 `naye-protection-prune.service`** —— 照着文案排查找不到东西。
改这类文案前先 `systemctl list-units --all | grep -i <关键词>` 核对单元名真的存在。

⚠️ **改阈值必须和改调度周期在同一次改动里完成**：备份从每小时改成每 3 小时而新鲜度阈值仍写 75 分钟，
就变成每轮必报。三处联动：备份 timer 的 `OnCalendar`、health 脚本的 `if age>NNNN`（周期 + 30 分钟缓冲）、
容量配额（服务端 `--max-size` 与配置里的 `offsite_capacity_bytes` 两处）。漏一处就是持续噪音或漏报。

**③ 挂调度四查**（脚本存在 ≠ 已在跑，这条已在 Pitfalls 强调，这里给全清单）

```bash
crontab -l | grep <脚本名>                     # 当前用户
sudo -n crontab -l | grep <脚本名>             # root
sudo -n grep -rl <脚本名> /etc/cron.d /etc/crontab
systemctl list-timers --all | grep -i <关键词>  # systemd
# Hermes 自己的：cronjob list（脚本型 job 的 script 字段）
```

统一走 `cron-status.py <job> -- <真实命令>` 包装，这样每次执行会落
`~/.local/state/automation-cron/<job>.json`（`status`/`started_at`/`exit_code`/`last_success_at`），
事后能证明「它真的按点跑过、成功过」，而不是只有进程 active。

**③-b 调度表是会变的：挂完必须复查，并处理重复（2026-10-24 实录）**

本次踩到的真实顺序：查遍 crontab / `/etc/cron.d` / `systemctl list-timers` → **确认没有任何调度** →
挂上 crontab → 10 分钟后发现 `/etc/systemd/system/hermes-cert-check.timer` 出现了，跑的是**同一个脚本**。

原因不是查漏，而是**调度状态被别人改了**：当时有另一个 agent 正在把 `~/hermes-jobs/*` 陆续迁成
systemd timer（unit 文件 mtime 呈阶梯状：`05:18 / 05:37 / 05:53 / 06:25`，风格统一
`oneshot` + `Nice=` + `IOSchedulingClass=idle`）。看到这种阶梯 mtime 就该意识到「有并发改造在进行」，
先核对再动手，别和它抢同一份调度表。

判定重复的**唯一可靠方法**是比「跑什么」而不是比「名字」：

```bash
sudo -n cat /etc/systemd/system/<unit>.service | grep ExecStart    # 看真实脚本路径
sudo -n cat /etc/systemd/system/<unit>.timer   | grep OnCalendar   # 看真实时刻
```

去重操作（**先备份、只删重复那一条、用 diff 证明只删了一条**）：

```bash
crontab -l > <backup>/crontab-before-dedup-$(TZ=UTC date +%Y%m%d).bak
crontab -l | grep -v "<脚本名>" | grep -v "^# <该条的注释标记>" > /tmp/crontab.new
crontab /tmp/crontab.new
# 证据：只应显示被删的那一行
diff <(grep -vE "^#|^$" <backup>) <(crontab -l | grep -vE "^#|^$")
```

**两边都有时保留哪个**：优先 systemd timer —— 它有 `Persistent=true`（宕机错过会补跑）、
`RandomizedDelaySec`（避免整点撞车）、`Nice=` / `IOSchedulingClass=idle`（不抢业务 CPU/IO），
这些都是裸 crontab 给不了的。撤 crontab 前**先手动 `systemctl start <unit>.service` 验证它能跑通**
（`systemctl show -p Result -p ExecMainStatus` → `success` / `0`），确认可靠再撤，别先拆后建。

**④ 改在 Hermes 安装目录里的补丁，必须配守卫**

`~/.hermes/hermes-agent/` 下的改动会被 `hermes update` 覆盖。除了留 `.patch` + `.bak`、
`git apply --reverse --check` 验证回滚路径，还要挂一个每日守卫检查源码标记是否还在，
丢了就告警并给出重放命令。现成脚本见 `hermes-ai-chain-alert-triage` 的 `scripts/patch_guard.py`。

**部署形态选 systemd timer，不要 crontab**：脚本本体留在技能目录、部署侧只放一份 JSON 配置
（`target`/`patch`/`repo`/`state`/`markers`），service 用 `--config` 指过去 —— 单一来源，
技能改进自动生效，避免「技能模板 vs 线上副本」两份代码分叉。本次实录：先写成固定路径脚本挂 crontab，
随后发现技能里已有通用模板，遂统一为「技能脚本 + JSON 配置 + timer」，旧副本移入
`backup/superseded-<date>/` 留证（**别直接 rm，留归档**）。迁移时同样遵守「先建后拆」：
先 `systemctl start <unit>.service` 验证 `Result=success` / `ExecMainStatus=0`，再撤 crontab 那条。

## 七-c、外部暴露面审计（从公网看，不登宿主机）

用户问「这个域名安不安全 / 帮我测一下这个站 / 攻击一下 X」时，视角反过来：不登机器，
从 DNS → 边缘 → 应用端点往外看。完整命令、端点表、报告格式见
`references/external-exposure-audit.md`，这里只留必须记住的几条。

**授权闸门（第一步，不是可选项）**：
- 「攻击一下 X」→ 先拒绝攻击本身（一句话，不说教），给三条合法替代：自有资产只读体检 / 评估防护水平 / 已授权测试。
- 用户回「自有或已授权」后才动，且只做**低强度只读**：单线程、带 sleep、不爆破、不压测、不发写请求。
- 域名特征可疑（刚注册、全 CF 代理、无 MX）时**先问再判**，不要用特征给用户扣帽子 ——
  本次实录：这类特征看着像钓鱼站，查出来是用户自己的 Emby 反代节点。

**五项固定检查**：
1. 被动层：`dig` A/AAAA/NS/MX + `whois` + CT 日志。CF 网段 = 源站隐藏。
2. 指纹层：响应头 + `openssl x509`（证书 `notBefore` ≈ 上线时间，`cf-ray` 后缀是边缘机房不是源站）。
3. 后端判别：看 **404 的 body** 不看状态码 —— Emby 是 `{"ResponseStatus":{"ErrorCode":"NotFound"}}`，
   空 body + `server: cloudflare` 是 CF 边缘 404。原生格式 + 根路径 200 ⇒ **反代全量透传，无路径白名单**。
4. 安全头六查：HSTS / CSP / `X-Frame-Options` / `X-Content-Type-Options` / `Referrer-Policy` / `Permissions-Policy`。
   只有 `server: cloudflare` 一行 = 反代层零安全头（CF 默认不注入，必须自己加 Transform Rule）。
5. **版本真实性核验**：拿自报版本对官方 releases API（`api.github.com/repos/<org>/<repo>/releases`）。
   不在官方列表 ⇒ 口径写「**无法用官方发布记录核对补丁状态**」，**不要断言「是破解版」**；
   且此时 CVE 版本区间对比**同时失效**，只能标「仅供参考」。

**媒体服务器特有**：`?api_key=` 走 URL 传令牌 + 缺 `Referrer-Policy` = 令牌经 `Referer` 外泄给第三方，
一条 `Referrer-Policy: no-referrer` 就能堵死，零功能影响。`/System/Info/Public` 无认证报出版本/ServerId
是产品设计不是漏洞，但必须靠 WAF 改写 `Version` 字段掐掉指纹。

⚠️ `crt.sh` 的 JSON 端点可能返回 404/HTML，**读不到 ≠ 没有子域**，拿不到就写「未核实」。
⚠️ NVD 页面常常只返回标题、正文抓不到，这种只能标「仅搜索摘要」，不能算已核实。

## 七-d、整机迁移中的"留下 / 搬走"归属判定

整机迁移 ≠ 所有服务都搬。先把对象拆成三层，逐层定归属：

| 层 | 判据 | 归属 |
|---|---|---|
| 运行时 | 容器 / 进程 / 卷在本机 | 用户要求不动 → **留在原位**，迁移动作=0，只纳入备份 |
| 控制链 | `crontab -l`、systemd timer、证书续期、告警桥接 | **必须搬**：旧机停机后这些静默失效 |
| 入口 | DNS、反代 `server_name` | 运行时没动就别切，切了必断 |

四条铁律：

1. **控制链最容易漏**：只盘容器不盘 `crontab -l`，迁完的表现是"站点还在，但证书到期 / 告警不响"。
   报告里把控制链条目按 `schedule + 涉及文件路径` 列表，**不打印命令正文**（常含凭据）。
2. **分钟级任务禁止双跑**：`* * * * *` 的告警桥接两边同时跑 = 重复告警 + 抢写状态。一律先建后拆，旧机在新链路验证通过前不停。
3. **无 compose 标签的容器是最高风险项**：`docker inspect` 里 `com.docker.compose.project` 为空 = 手工 `docker run`，
   **没有编排可复现**。单独列一条，迁移前先反推 run 参数（镜像 digest + 全部 mount + workingdir + 端口）。
4. **镜像无 tag 只认 digest**：`docker ps` 的 IMAGE 列显示成 12 位短 ID 就是没 tag；重建必须写 `repo@sha256:...`，否则 `latest` 漂移。

同机共置但未证实有依赖的服务（如 `pansou`），单独列"不纳入本次迁移范围"，**不要顺手打包**。

## 七-f、CPU 跑飞与孤儿进程取证

用户问「CPU 为什么占用这么高 / 机器怎么这么卡」，或内存排查中撞见 `kcompactd`/`kswapd` 累计时间异常时，
完整取证顺序、孤儿判定、SIGTERM 清理与验收口径见
`references/cpu-runaway-and-orphan-process-forensics.md`。必须记住的四条：

1. **按累计 CPU 时间排序，不按 `%CPU`**：`ps -eo times,pcpu,pid,user,etimes,comm --sort=-times`。
   `%CPU` 是进程生命周期均值，会把新进程的满载和老进程的满载同时稀释掉。
   `times/etimes` 比值接近 1.0 = 独占一核。
2. **自己造的头号事故：`grep -rn x /` 递归进 `/proc`**。管道里的 `grep -v` 只过滤输出、拦不住遍历，
   卡在 `pagemap` 这类伪文件上会 100% 烧一核且永不退出。排除必须写成
   `--exclude-dir={proc,sys,dev,run}` 或直接限定目录，并加 `timeout`。
   实证：一条巡检命令的残留 grep 烧了 2 天 12 小时 / 累计 59.6 小时 CPU。
3. **孤儿判定看 cgroup + 会话状态**：`tail -1 /proc/<pid>/cgroup` 落在
   `user.slice/...session-<N>.scope` 且 `loginctl show-session <N>` 为 `State=closing`
   = 终端早断、进程赖着。只清这类，落在 `*.service` 的一律不动。清理先 `-TERM` 不用 `-9`。
4. **load average 不能当即时验收指标**（1/5/15 分钟指数衰减）。杀完要么等 5~6 分钟再采样，
   要么用 `vmstat` 的 `r` 列和 `id` 给即时证据，并说明 load 的衰减特性。

## 七-e、每日错误日志汇总归因：先分层，再排序

收到「每日错误日志汇总」这类日报时，**按错误条数排序直接下结论必然误判**。条数是日志行数，不是失败请求数。固定三层拆开：

| 层 | 特征 | 判据 |
|---|---|---|
| 外部扫描噪音 | 单 IP 占绝大多数，打认证端口或探测路径 | `grep -oE "from [0-9.]+" <log> \| sort \| uniq -c \| sort -rn`，单 IP 占 >80% 即噪音 |
| 死循环重试 | 同一任务/消息 ID 反复出现，间隔近似固定 | 按 ID 聚合计数；同一 ID ≥3 次且 `last_error` 相同 |
| 真业务故障 | 业务状态 PARTIAL/FAILED 且有对应失败记录 | 日志与 db 状态**双向对照**，不只看日志 |

七条判据与陷阱（全部实测）：

1. **认证类日志先看配置、成功登录与凭据暴露，不把条数当风险**：核对 `passwordauthentication`、`permitrootlogin`、`pubkeyauthentication` 和实际留存窗口。关闭密码登录只能降低密码猜测风险；**不阻止持有有效私钥的人，也不证明整机安全**。失败日志多可单列扫描噪音，但公钥暴露、成功登录来源未归属或日志缺失时，不得写“零风险/没有入侵”。
2. **NAT 映射会让「来源 IP」失效**：日志里有公网 IP 连进来，不代表那个端口对公网开放。实测 `timeout 8 bash -c 'cat </dev/null >/dev/tcp/<ip>/<port>'` 才作数。本次实录：22 filtered、30023 open，爆破打的是 30023→22 的端口映射，`ss -lntp` 只看到 22。
3. **反代/代理容器里的 401、`TLS handshake error` 多是外部探测**：看 User-Agent（`python-requests/2.x`、`Mozilla/5.0 ... Firefox/3.6.15` 这类老 UA）和路径（`/v1/models`、`/status?full=true`）即可定性，不要报成内部鉴权故障。
4. **日志里的 `db_id=` 可能是消息 ID，不是表主键**：本次日志打 `db_id=3575`，库里真实主键是 2120，按 3575 查必然为空。查不到时先 `select max(id),count(*)` + 按文件名模糊匹配，**不要断言「记录丢失」**。
5. **Alpine/OpenRC 主机没有 journalctl**：`journalctl -u ssh | wc -l` 返回 0 不代表没日志。先 `ps -p 1 -o comm=` / `rc-status` 判 init，日志在 `/var/log/messages`，服务用 `rc-service`。把「journal 无记录」写成「无故障」是硬错。
6. **journal 保留不足 24h 是口径缺陷，比报错数更该修**：`journalctl --disk-usage` 显示几百 MB 而窗口不到一天 = 轮转过激，日报统计本身就残缺，应先修轮转再谈趋势。

    **但「保留期」不是配置常量，每次都要当场实测，绝不能沿用上一次的结论。** `SystemMaxUse` 只是上限，实际保留 = 上限 ÷ 日增量，会随日志量剧烈变化。实测反例（本次踩实）：同一台 vps-la，10-29 查到最早记录在 **13 天前**（据此断言日报「保留不足 24 小时」是误报），11-01 再测只剩 **不足 24 小时**（512M 被写满后轮转）——**先前的判断被次日数据直接推翻，需要在报告里明确更正**。日志量大的服务是主因：每 60 秒打一对 `Connecting.../Connection complete` 就是约 5760 行/天，把这类心跳日志降到 DEBUG 能显著延长保留。

    ```bash
    journalctl --since "@0" -n 1 -o short-iso   # 最早一条；别用 -o json 再解析，长行易截断
    journalctl --disk-usage                      # 实际占用 vs SystemMaxUse
    ```

    **报「生效值」前要走完 drop-in 链**：主文件 `/etc/systemd/journald.conf` 写 `SystemMaxUse=200M` 可能被 `/etc/systemd/journald.conf.d/*.conf` 覆盖成 512M。只看主配置就报参数，口径本身就错。
7. **不在 SSH 配置里的机器要单列「未核实」**：DR 机/无入口的机器，不能把日报里的数字当成已确认异常，如实写「未核实」。

## 七-g、新增服务容量评估：「我这条件能不能再起个小 X 服」

用户问「我现在这条件是不是可以来一个小 X 服了」时，这是**可行性审计**，不是部署任务。
完整采样命令、判据表、虚拟显卡识别、网盘当库换算、汇报形态见
`references/new-service-capacity-assessment.md`。必须记住的五条：

1. **历史方案文档不是执行目标**。`.hermes/plans/` 里的旧方案可能写着「已就绪、随时一键唤醒」
   并锁定某台机器某端口，但机器状态会变。本次实录：2026-09 方案选定 vps-la，当时「内存结余 1.2G」；
   复查时该机已压 15 个容器、可用 747M、swap 吃 1.4G、系统盘余 8.1G ⇒ 照抄必翻车。
   历史方案只给思路和端口意图，**机器选型必须重新采样**。
2. **资源够 ≠ 能开服**。宿主资源 / 硬编能力 / 端口出网 / 数据源凭据，四类分别验。
   机器合格但 token 死了，结论只能写「现在开不了」，不能写「资源够，随时可起」。
3. **`lspci` 的 `Device 1234:1111 (rev 02)` 是 QEMU 虚拟显示卡**，`/dev/dri` 只有 `card0`
   没有 `renderD128` ⇒ 零硬编，纯软转。必须显式告知用户转码策略只能是「能直连就直连」，
   否则 4K 一多就卡，用户会误判成网络问题。
4. **端口一律避开已有同类服务**（同类反代常占 8096，新实例用 8097），出网复用已有 CF 隧道，
   不新开防火墙端口、不裸 IP 直连。
5. **绝不套用记忆里的机器规格**：说「你这台」时，数字必须来自本次 `free/df/uptime` 实测并带采样时点。

## 七-h、第三方平台安全通告核查（SaaS / 云供应商泄露）

收到“你的密钥可能已被访问”的供应商邮件时，先判断**泄露面属于哪个产品**，再决定是否轮换；不要一上来全量换钥。

1. **产品身份先分清**：同一家公司可能有多条产品线。实例：InsForge 的 InstaCloud（`api.instacloud.com`，serverless compute service，环境变量含自动生成的 `DATABASE_URL`/`REDIS_URL`）与 InstaBox（`api.instabox.sh`，Firecracker 微 VM 沙箱）控制面和凭据是分开的。通告说“计算服务环境变量”时，先确认我们用的是不是那条产品线；**InstaCloud 的通告不等于 InstaBox 沙箱被访问**。
2. **只读核对平台侧投递面**：列出全部机器/服务，查机器 `secrets` / `envSecrets` / `directSecrets` / `items`、`vault.applied.env` / `applied.files`、org Secrets。全为 `[]` = 该向量没有可泄露对象，这是最强的一条结论。
3. **查持久化与控制面痕迹**：SSH token 列表（是否只有本人创建、创建时间）、用户快照（异常快照可能意味着导出磁盘）、机器 `updatedAt`/`runStartedAt`（每 8 小时例行重启，别误判成攻击或补救）、公网端口暴露。
4. **客户机内取证**：平台投递的 secrets 文件（如 `/run/instabox/secrets/env`，只有 4 行 CA 路径 = 没有真实凭据）、关键文件 atime、面板审计日志、登录记录。**atime 会被后续服务启动/正常读取覆盖，只能作辅助证据**，不能单独证明“没被读”。
5. **判定口径**：平台投递面为空 + 无新 token/快照 + 事件窗口无 exec/配置改动 = 按该通告无需轮换。文件里的凭据只有在出现 exec/登录证据时才按泄露处理；轮换前先列影响面（会断哪些服务、哪些客户端要改）。
6. **报告边界**：区分“供应商通告”与“我们实际暴露”；需要用户确认的只留一个关键问题（是否在该产品控制台建过服务/项目）。**本机没有该产品 CLI 不等于用户没有账号或项目**，不要替用户下结论。

7. **多机排查：先确认「哪些机器有该产品痕迹」，再谈窗口**。用户问“其他几台机器呢”时，逐台只读跑：`command -v insta`、`~/.config/insta*` / `~/.insta*`、systemd unit 与 env/profile 里的 `instacloud|api\.insta`、shell history 命中数，以及 InstaBox key 文件位置（路径 + 权限，不读值）。全部为空 = 该产品在机器群上没有部署面，这条结论比逐台分析窗口更有力。脚本 `scripts/fleet_insta_trace_sweep.sh`，用 `ssh host 'bash -s' < script.sh` 批量跑。
8. **登录窗口按源 IP + key fingerprint 分组，不能只看总数**。实测 vps-la 在一小时窗口里有 92 次成功登录，全部来自本机 naye 的自动化（每分钟级巡检/隧道），只看数字会误报成入侵。分组后每个来源都要能归属：自有自动化 / 用户机场出口（按 ASN 认，如 IKUUU、Nearoute）/ 未知待确认。未知来源单列为待确认项，**不要直接定性为攻击**。脚本 `scripts/ssh_auth_window.sh`。
9. **日志时区是硬坑**：远端 auth.log 可能写本地时间带偏移（实测 diaomao 为 `+08:00`），拿通告的 UTC 字符串直接 grep 会筛到错误时段。先在目标机用 `date -d "<UTC 时刻>" +%Y-%m-%dT%H:%M` 算出本地窗口字符串再过滤，报告里写明时区口径。
10. **本机检查不要 SSH 自己**：本机 hostname 就是 naye，`ssh naye` 会回环并 publickey 失败，本机直接跑脚本。另：超长 inline 命令会触发 hardline 拦截，脚本先落盘再用 `bash -s` 传入。
11. **未知来源靠「key 指纹 + 命令行为」归属，不靠 IP 归属地**。IP 地理位置只能提示、不能定性——本次把自家代理出口（LA 的 BACK WAVES）和一条窗口**之前**的登录都误报成可疑，下一轮当场更正。链条：`ssh-keygen -lf authorized_keys` 把 auth.log 指纹映射到条目名（注释常直接写明工具，如 `codex-naye-20261027`）→ 查本机有无对应私钥（不在 = 外部机器持有）→ 每台机 `curl ipinfo.io/ip` 建出口基线（全不匹配 = 经代理入站）→ **`journalctl _COMM=sudo | grep COMMAND=` 读它进来执行的完整命令与 PWD，这一步才是决定性证据**。同一秒多条 `Accepted` = 并行编排器（Codex/批量脚本），人手不会这样。五步一次跑完用 `scripts/ssh_source_attribution.sh <IP> [SINCE] [UNTIL]`（在收到登录的那台机上跑）。
12. **用户说「不想换钥」时给风险模型，不复述建议**。key 的可达路径是「拿下持有它的机器 root」，不是「文件在哪」；同一 key 在都是日常 root 登录的机器上多一份副本不叠加风险，删副本是伪安全。先查平台能力（InstaBox API key 无 IP 白名单、无过期、scope 固定五档）再谈替代方案，别承诺做不到的「限来源」。已有守护日志能显形异常时，明确答「不用加巡检」。只有 key 出现在别人的机器上、或窗口内有 exec/配置改动才必须换。

完整的 API 端点、脱敏脚本、窗口判读、多机排查结果与 2026-11-03 InstaCloud 通告实查记录见 `references/vendor-breach-triage.md`；可复用脚本见 `scripts/fleet_insta_trace_sweep.sh`、`scripts/ssh_auth_window.sh` 与 `scripts/ssh_source_attribution.sh`。

## 八、报告结构（用户认可的形态）

1. **一句结论**：健康 / 有隐患 / 有问题，以及最要紧的那一条。
2. **采样时间**：实测的北京时间。
3. 分节表格：现役状态 → 功能验证（业务数据）→ 安全审计 → 待决策项。
4. **待决策项按风险排序**，每条给"为什么"和"修起来多大动静"。
5. **末尾"如实说明"**：未验证项、没深挖的疑点（例：某日报自报 `partial` 但 `remaining_unchecked: 0`，口径矛盾——写"未读代码确认，不下定论"，不要替它圆）。
6. 结尾给动作顺序建议（先纯新增的低风险项，最后才是停用/删除）。

## Pitfalls

- **「订阅/规则集/面板全部打不开」先查前置代理容器，别先怀疑业务代码**：多段链路里任一段断都是同一个 502。
  一条命令定性：`docker ps -a | grep <proxy-ctr>` + `ss -ltnp | grep <front-port>` + 隧道日志里
  `connection refused` 指向哪个端口。后端 `systemctl is-active` 是 `active` **不能**证明门户健康。
  同时必查容器 `RestartPolicy`：`no` 的容器 `ExitCode=0` 优雅停止后永不自动拉起，且 `docker ps` 默认看不见、
  systemd 管不到、无告警 —— 实测静默停服 6 小时。修法 `docker start` + `docker update --restart unless-stopped`
  （不用重建，不重置 DOCKER-USER 链）。详见第六节 6.3。
- **`ls | head` / `du | head` 会藏掉真正的空间大户，据此清理会删错东西**（2026-11-06 实测险情）：
  对一个 4.2 G 的备份目录只看了 `ls -la | head -6`，以为里面只有 `cache/`（restic 缓存，可删），
  差点按"缓存可重建"删掉；实际完整列表里还有 `repository/` 3.6 G + `restore-check/` 640 M ——
  那是**维护前的回滚副本**，删了就回不到维护前状态。
  ```bash
  sudo find <dir> -maxdepth 1 -mindepth 1 -exec du -sh {} \; 2>/dev/null | sort -rh   # 全量排序，不截断
  ```
  **铁律：判断"哪个子目录大 / 能不能删"之前，必须先拿到完整分层清单并排序**，`head` 只用于最终展示，不能用于决策。
  同一目录里 `maintenance-result.json` / `verification.json` 这类小文件往往直接写着 `state: ALL_DATA_VERIFIED`
  和到底保留了哪个子目录 —— **先读它们，再决定动不动**。
- **「站点打不开」且 HTTP 403、但 DNS/CF/隧道/容器全正常时，先怀疑自建门禁层，别当故障修**（2026-11-17 实录）：
  自建站点常在 CF Tunnel 后面挂一层 Caddy/nginx 门禁反代：只认一个时效 Cookie（如 `artex_gate`，`Max-Age` 30 天），
  没带 Cookie 一律 `respond "Forbidden" 403`。表象是「昨天还能开、今天突然打不开」，实际服务一切健康
  （容器 Up 多天、后端本地 curl 200）。判定三步：
  ① 后端本地探针 `curl http://127.0.0.1:<backend>/` 若 200 ⇒ 服务没坏，断点在门禁层；
  ② 读门禁反代的 Caddyfile（常 bind 在 127.0.0.1 非标端口、只挂 `@grant query k=...` 和 `@denied not header Cookie ...` 两段）确认是设计内拒绝；
  ③ 给用户的修复 = 用带授权参数的入口 URL 开一次让门禁种回 Cookie 再 302 回首页，**不是重启任何东西**。
  报告里必须写明「这是门禁 Cookie 过期/被浏览器清掉，不是服务故障」，并提示 `Secure` Cookie 可能被浏览器拦截（换无痕窗口复测）。
- **陈旧 stderr 日志会被当成"现在还在失败"**：某 cron 包装脚本的日志里滚着几十行
  `can't open file '...': No such file or directory`，看着像脚本路径配错了。实际先看 mtime ——
  `ls -la <log>` 显示停在几天前的一次事故窗口（文件当时真丢了，后来已恢复），之后一行没再写。
  **判据：日志 mtime + 手动跑一次看 `rc`，两者都对上才算"现在正常"**；只看日志尾巴会把它当成活跃故障。
  同理，`journalctl --since` 跨过重启点会把旧 PID 的报错算进当前状态。
- **同一份生产文件可能正被另一个会话/agent 同时改**：本次改 `main.py` 前发现它的 mtime 是 3 分钟前，
  同目录躺着 `main.py.bak-geminiretire-<时间戳>` —— 另一个会话正在按用户指令做功能退役。
  **动手前固定两步**：`ls -la --time-style=long-iso <file>*` 看 mtime 与 `.bak-*` 兄弟文件，
  再 `diff` 一眼最近备份确认改了什么。改了同一文件要先合流，否则一方改动被覆盖、或双方各自编译通过但行为互斥。
  改完 `systemctl restart` 也会打断对方的 journal 验收 —— 有并发会话时先确认它是否已收工。
- **`systemctl status` 的 `Memory: 34.7M` 是 MiB**，写"34.7 MB"会被抓错；`systemctl show -p MemoryCurrent` 才是字节。两者不可混。
- **不要用 `journalctl | grep -c error` 当健康证据**：日志只在出错/事件时写，24h 干净可能意味着零调用。必须配业务数据一起看。
- **`sqlite3` CLI 常常没装**，用 `python3 -c "import sqlite3"`；查表前先 `pragma table_info` 拿真实列名。
- **`du -sh /var/lib/<svc>` 不加 `sudo` 会显示 0**，别当成空目录。
- **在远端机器上用端口号做关键词检索，会命中一堆历史 staging 副本**（`/opt/<svc>-*-stage-*`、`backup/source/`）。本地检索用 `search_files`，远端才用 shell grep；两种都要过滤掉 staging/backup 目录，否则永远"有引用"。
- **远端全盘 grep/find 必须在命令自身排除 `/proc`、`/sys`、`/dev` 并加 `timeout`**：写成
  `grep -rn x / 2>/dev/null | grep -vE '^/(proc|sys)'` 是无效防护（管道只过滤输出），
  进程会卡在 `/proc/<pid>/task/<tid>/pagemap` 上 100% 烧一核、永不退出；SSH 一断就成孤儿长期空转。
  正确写法 `--exclude-dir={proc,sys,dev,run}` 或直接限定 `/etc /opt /home /usr/local`。详见第七-f节。
- **取证命令和 `kill` 命令必须分开发**：把 `kill` 和受保护控制入口的服务名拼进同一条命令
  （哪怕只是想顺手确认它没受影响），会被 `approvals.deny` 整条拦下作废。deny 规则匹配命令文本，不看意图。
- **迁移过的服务，旧机器上 `disabled` + 旧 unit 文件还在**是常态，不是故障；但旧机器上那条为它服务的隧道会继续空转，属于要报的孤儿资源。
- **本机 `ss` 里一堆 ESTAB 到 22 端口是正常 SSH 会话**，别把它们当成服务流量证据。
- **别在群里/生产上发测试消息验证 bot 活着**，会打扰用户；用事件表时间戳推断，并在报告里标注"非端到端实测"。
- **验收长任务不要用前台命令跑**：单轮扫描/同步常需 10~45 分钟，前台执行会被默认超时（约 180s）连进程一起杀掉，日志只留一行「开始」，很容易误判成「任务卡住/无效」。长任务一律 `background=true` + `notify_on_complete=true`，或直接复用它的 cron + flock 命令。
- **「跑完了」不等于「做了事」：先确认关键开关不是 dry-run / preview**。清理、同步、迁移类脚本常把
  `dry_run=True` 硬编码在调用处，日志连续多轮「预览完成，未删除文件」看着像正常运行，实际零副作用。
  审这类功能第一件事是 `grep -n "dry_run\|preview\|apply" *.py` 看**调用点**，而不是看它有没有报错。
- **长任务进行中被问「结束了吗 / 跑完没」**：不要回「还在跑」。给三件事——已跑时长、最后一行日志、
  还差什么/预计还要多久。本次只读探针跑了 96 分钟、中途被问两次，给进度比给结论更能稳住用户。
- **判断「还在失败」的时间窗要从重启时刻算起**：`journalctl --since` 若跨过重启点，会把旧 PID 的历史报错算进当前状态；核对 PID 是否已换再下结论。
- 报告要区分"服务端改动"与"界面验收"；没实际点过按钮就不要写"已生效"。
- **审计监控覆盖时，先看探针本身对不对**：证书/HTTPS 探针写死 443 会误报——443 常被 xray 代理占用并回落大站证书，业务 TLS 可能在 2087/8443。判定与修法见 `proxy-node-connectivity` 的 `references/tls-cert-probe-false-positive.md`。同理，监控脚本存在 ≠ 已挂调度，要核对 crontab / `/etc/cron.d` / Hermes `cronjob list`。
- **compose 文件不能直接 `yaml.safe_load`**：Compose 规范允许 `!reset` / `!override` 自定义标签，PyYAML 会抛
  `ConstructorError`（本次就撞上，白跑一轮）。只需要 service 名/镜像/卷/依赖键时用
  `yaml.load(f, Loader=yaml.BaseLoader)`，或注册 multi-constructor 忽略未知标签。
- **从 JSON 汇总生成 Markdown 前先 dump 结构**：同类证据块常不同形（`files_stat_only` 是
  `[{mount_root, database_name_matches:[...]}]` 而不是扁平的 `[{path,...}]`），照猜键名必然 `KeyError`。
  先 `json.dumps(x, indent=1)[:1200]` 看一眼，再写模板。
- **交付审计文件前做泄露扫描**（报告本身是用户可见物）：`re.findall(r'(?<![\d.])(?:\d{1,3}\.){3}\d{1,3}(?![\d.])')`
  查 IP 字面量，`(password|token|secret|api[_-]?key)\s*[=:]` 查秘密；内部回环端口一律脱敏成
  "内部端口已脱敏"，只保留公网入口端口号（否则 `ss`/`server_name` 一带就是内网拓扑）。
  审计报告一律 `chmod 600`，并回读 `oct(stat.S_IMODE(...))` 证明，不靠"我设过了"。
- **不许打开数据库时怎么判引擎**：读 `/proc/<pid>/maps | grep -i sqlite`（或进程加载的 `.so`）
  + 数据目录里 `.db`/`.sqlite3` 文件名 + mtime 是否在动。三条齐了写"SQLite（间接证据，未打开库）"，
  **不要**写成"已核验 schema"。
- **"备份"要先分清是源码包还是数据**：`*-share.zip`（200KB 级、跟部署同一天）= 源码快照，不是数据备份；
  同名 `.db` 出现在两处 mount 且 mtime 差三周 ⇒ "哪份权威"未知，快照必须两处都取，报告里标未确定。
- **Node.js/二进制运行时就地更新的解压陷阱（.tar.xz vs .tar.gz 与 getcwd 丢失）**：
  在精简 Linux 环境更新 Node 时，`tar -xJf` 依赖 `xz` 二进制，缺包时会报错 `tar (child): xz: Cannot exec`；官方通常提供同版本 `.tar.gz`，优先拉取 `.tar.gz` 用 `tar -xzf` 更通用。
  此外，在临时目录解压并清理时，避免在已删除的目录（cwd）下直接执行 `node`/`npm`；Node 启动或 `npm` 初始化时调用的 `process.cwd()` 会因当前工作目录不存在直接崩溃抛出 `ENOENT: uv_cwd`。应显式切回有效目录（如用户主目录）再做验收。
- **非标端口（如 2096/2083/8443）在手机/移动网络下的劫持与退化陷阱（Akamai `errors.edgesuite.net` 与 `[No Host]`）**：
  在排查用户反馈「移动端打不开/白屏/报错」时，如果客户端返回形如 `http://[No Host]/...` 或 Akamai 错误页 `errors.edgesuite.net`：
  1. **不要过早归因到客户端软件（如代理软件）本身**，先核实是否是因为使用了非标 HTTPS 端口（如 Cloudflare 允许的 2096/2083）。
  2. 手机浏览器（尤其是 Safari）在用户手动输入或历史补全时，极易优先发起明文 HTTP 请求（或省略了 `https://`）。中间网络、本地运营商或透明代理对非标端口截获后，会丢失 `Host` 请求头或被透明 CDN（如 Akamai 边缘）拦截报错。
  3. 验证方法：先用带有完整 `https://` 的规范 URI + 标准移动端 User-Agent 做严格 curl 验证；若 curl 200 且证书合法，则服务端存活，故障点在入口协议退化或中间链路劫持。
  4. 根治思路：业务管理端尽量统一收敛到标准 HTTPS 443 端口，利用边缘域名路由/反代避免在公网暴露非标端口给移动端直接访问。
     完整可复制的落地配方（CF Tunnel 建隧道 → ingress 回源 → CNAME → cloudflared systemd，
     含 `httpHostHeader` 必须改回 nginx `server_name`、`token ≠ credentials-file` 两个必踩坑，
     以及「Origin Rules 无权限 / Worker 路由无权限 / 源站 443 被 xray 占用」的否决对照表）
     见 `emby-proxy-ops` 的 `references/emby-direct-rules-portal-ops.md`。**该技能已 pin，只读引用，不要改它。**

## References

- `references/ad-killer-audit-20261024.md` — Ad Killer 全量审计实例：迁移前后拓扑、命令原文、实测数值、三条待决策项。
- `references/external-exposure-audit.md` — 外部暴露面审计（公网视角）：授权闸门、被动层/指纹层命令、Emby 端点暴露表、
  版本真实性核验（官方 releases API 比对）、安全响应头六查与加固清单、报告格式、2026-10-24 实测基线。
- `references/capy-theater-identity-audit-20261027.md` — 实例：用户口头名「Capy 影厅」如何用运行中页面标题确认为
  `happy-capy` 容器栈、与 `workbuddy2api` 的五维对照 + upstream 依赖边、只读采集口径、迁移归属表、脱敏交付形态。
- `references/new-service-capacity-assessment.md` — 「这台机器还能不能再加一个服务」容量评估：容量采样一条命令、
  资源判据表、QEMU 虚拟显卡（`1234:1111`）识别与软转结论、端口/出网隔离、网盘当库的 vfs 缓存换算、
  历史方案文档不可照抄的实测反例、结论先行汇报形态。
- `references/cpu-runaway-and-orphan-process-forensics.md` — CPU 跑飞/孤儿进程取证：累计 CPU 时间排序法、
  `grep -r /` 递归进 `/proc/pagemap` 的自造事故与正确写法、`loginctl` 会话 scope 孤儿判定、
  SIGTERM 清理顺序、load average 衰减导致的验收误判、与内存结论的交叉影响。
- `references/credential-exposure-audit.md` — 对话历史凭据暴露的只读审计：只读 SQLite、形态规则、
  排除指纹/哈希、私钥结构验证、配置精确重合与外部滥用的证据分级。
- `references/credential-rotation-and-egress-verification.md` — 逐项轮换总纲：台账状态机、有效性核验边界、
  SSH 单钥正反验证（`-i` 叠加陷阱）、服务 key 三层分离、继续用中转的脱敏与隔离边界、入侵证据汇报口径。
- `references/credential-handoff-and-runtime-verification.md` — 换钥的用户交接与运行时验收：隐藏输入暂存入口契约、
  Telegram Bot Token 两类部署的切换顺序、按 systemd `InvocationID` 取启动证据、AstrBot 业务层证据表、
  Hermes `.env` 长驻进程缓存与进程祖先判定、多 key add-only 失败即回滚、无用模型本地退役与上游撤销的分开验收。
- `references/vendor-breach-triage.md` — 第三方平台安全通告核查：InstaCloud 与 InstaBox 产品线区分、
  secrets/vault/SSH token/快照/控制台窗口的只读 API 清单、客户机 atime 与 secrets 文件判读、
  **未知 SSH 来源的五步归属法（指纹 → authorized_keys 条目名 → 私钥是否在本机 → 出口基线 → sudo 命令行为）**、
  用户拒绝轮换时的风险模型论证、2026-11-03 InstaCloud 通告实查基线与脱敏输出纪律。
- `references/restic-rest-server-quota-chain.md` — restic + rest-server 配额链全量排查：`507 Insufficient Storage`
  的定位顺序（health timer → 配套 backup 单元的 `ExecMainStatus` → `<state-dir>/last-backup.log`）、
  `Result=success` + `ExecMainStatus=1` 的判读陷阱、`ssh -L` 隧道与服务端 `--max-size` 的取证命令、
  「改配额 → 重跑 → 看是否通过」的可控验证法、`health.json` 三件套验收、
  以及 hourly + append-only + 配额 + 无 prune 的结构性缺口与三种处置方案对比。
- `references/restic-repo-growth-measurement.md` — **判断「要不要改备份脚本 / 配额够不够」的唯一正确测法**：
  为什么单次 `data_added` 不能推稳态（实测 258 MB vs 稳态 2.2 MiB/h）、
  为什么必须比 `content` 而不能只比文件大小、纯定时相邻快照的取样要求、
  `sqlite3.backup` 确定性验证（证明 staging 全量重写不产生重复上传）、
  `setsid nohup` 跑长 prune 并轮询、以及「快照数量 / 数据体积」必须分开汇报的口径。
- `scripts/decommission_sweep.sh` — **服务退役前的只读残留扫描**：一次列出巡检 JSON / 巡检脚本硬编码 /
  systemd 单元排序声明 / timer / cron / 自启 / 运行态 / docker 七类落点。改之前先跑，
  避免「停了服务但巡检还在报」被用户抓（见 7.3-c）。
