---
name: cloudflare-cloud-mail-ops
description: Use when 自建/运维 Cloudflare Cloud Mail 邮箱。
version: 1.0.0
author: 柠檬
license: MIT
metadata:
  hermes:
    tags: [cloudflare, email, workers, d1, resend, telegram]
    related_skills: [cloudflare-tunnel-ops, hermes-custom-providers]
---

# Cloud Mail 自建邮箱运维（Cloudflare Workers）

用 `maillab/cloud-mail` 在 Cloudflare Workers 上跑一套完整邮箱：Email Routing 收信（免费无限量）、Resend 发信（免费 100 封/天）、Telegram 推送新邮件。

## When to Use

- 要在自有域名上开一套能收能发的邮箱，不想买服务器
- Cloud Mail 部署报错、收不到信、发不出信、TG 不推送
- 把已有 Telegram bot 改造成收信通知入口

## 架构与成本

| 组件 | 用途 | 成本 |
|---|---|---|
| Workers + Assets | 后端 + Vue3 前端 | 免费 |
| D1 | 用户/账号/邮件/设置 | 免费 |
| KV | 登录态、设置缓存 | 免费 |
| Email Routing | 收信，catch-all 全收 | 免费不限量 |
| Resend | 发信到站外 | 免费 100 封/天 |
| R2（可选） | 附件 | 需开通，不开则附件不可用 |

CF 原生 Email Sending 需 Workers Paid（$5/月，3000 封），一般选 Resend 更划算。

## 部署步骤

### 1. 准备权限

日常 DNS 用的 token 通常**没有** D1/KV/Workers 权限。需新建专用 token，权限组：

- Workers Scripts Write `e086da7e2179491d91ee5f35b3ca210a`
- Workers KV Storage Write `f7f0eda5697f475c90846e879bab8666`
- D1 Write `09b2857d1c31407795e75e3fed8617a1`
- Workers AI Read `a92d2450e05d4e7bb7d0a64968f83d11`
- Account Settings Read `c1fde68c7bcc44588cbb6ddbc16d6480`
- DNS Write `4755a26eedb94da69e1066d98aa820be`
- Zone Read `c8fed203ed3043cba015a93ad1616f1f`
- Email Routing Rules Write `79b3ec0d10ce4148a8f8bdc0cc5f97f2`
- Workers Routes Write `28f4b596e7d643029c524985477ae49a`

存 `~/.config/lemon-cloudflare/cloud-mail.token`（600）。

**关键坑**：该 token 调 `/zones/{Z}/email/routing`（GET/PATCH/enable）仍报 `Authentication error`，只有 `/email/routing/rules` 可用。启用 Email Routing 必须用带 Zone Settings 权限的 `ops.token`：

```bash
curl -X POST -H "Authorization: Bearer $(cat ops.token)" \
  "https://api.cloudflare.com/client/v4/zones/$Z/email/routing/enable"
```

### 2. 建资源

```bash
# D1
curl -X POST -H "Authorization: Bearer $TOK" -H "Content-Type: application/json" \
  -d '{"name":"cloud-mail","primary_location_hint":"apac"}' \
  "https://api.cloudflare.com/client/v4/accounts/$A/d1/database"
# KV
curl -X POST -H "Authorization: Bearer $TOK" -H "Content-Type: application/json" \
  -d '{"title":"cloud-mail-kv"}' \
  "https://api.cloudflare.com/client/v4/accounts/$A/storage/kv/namespaces"
```

### 3. 构建与部署

```bash
git clone https://github.com/maillab/cloud-mail ~/apps/cloud-mail
cd ~/apps/cloud-mail/mail-vue && pnpm install && pnpm run build   # 产物输出到 ../mail-worker/dist
cd ../mail-worker && pnpm install                                  # 必须！否则 deploy 报 Could not resolve dayjs/linkedom/ua-parser-js
CLOUDFLARE_API_TOKEN=$(cat ~/.config/lemon-cloudflare/cloud-mail.token) npx wrangler deploy
```

`wrangler.toml` 要点：

```toml
name = "cloud-mail"
main = "src/index.js"
compatibility_date = "2025-06-04"
keep_vars = true
account_id = "<ACCOUNT_ID>"

[observability]
enabled = true

[[d1_databases]]
binding = "db"
database_name = "cloud-mail"
database_id = "<D1_UUID>"

[[kv_namespaces]]
binding = "kv"
id = "<KV_ID>"

[ai]
binding = "ai"

[assets]
binding = "assets"
directory = "./dist"
not_found_handling = "single-page-application"
run_worker_first = true

[[routes]]
pattern = "mail.example.com"
custom_domain = true

[triggers]
crons = ["0 * * * *"]

[vars]
domain = ["example.com"]
admin = "admin@example.com"
jwt_secret = "<随机32字节hex>"
project_link = "https://github.com/maillab/cloud-mail"
```

非交互环境必须显式传 `CLOUDFLARE_API_TOKEN`，否则 wrangler 报错。

### 4. 初始化数据库与管理员

```bash
# 注意 /api 前缀，少了会命中 SPA 兜底返回 HTML
curl "https://mail.example.com/api/init/<jwt_secret>"     # → success

curl -X POST -H "Content-Type: application/json" \
  -d '{"email":"admin@example.com","password":"..."}' \
  "https://mail.example.com/api/register"

curl -X POST -H "Content-Type: application/json" \
  -d '{"email":"admin@example.com","password":"..."}' \
  "https://mail.example.com/api/login"    # → data.token (JWT)
```

**坑**：直接用 `terminal` 打印长 JWT 会被截断（表现为 token 只有十几个字符），必须 `curl -o /tmp/l.json` 落文件再读。JWT 放 header 时**不带** `Bearer ` 前缀，直接 `-H "Authorization: $JWT"`。

### 5. 收信

启用 Email Routing 后自动生成 3 条 MX + SPF + DKIM。把 catch-all 指向 worker：

```bash
curl -X PUT -H "Authorization: Bearer $TOK" -H "Content-Type: application/json" \
  -d '{"matchers":[{"type":"all"}],"actions":[{"type":"worker","value":["cloud-mail"]}],"enabled":true,"name":""}' \
  "https://api.cloudflare.com/client/v4/zones/$Z/email/routing/rules/catch_all"
```

验证收信只能让用户用真实邮箱发。**本机脚本直连 MX 发信会被拒**：`544 5.7.1 Email was rejected because it was likely unsolicited email`（源 IP 无 PTR/SPF）。

### 6. Resend 发信

1. Resend 后台加域名，只加 TXT（DKIM）和它给的 CNAME，**不要加它给的 MX**（会与 CF Email Routing 冲突）
2. 建 API Key 时选 `Sending access`（最小权限）
3. 写入 D1：

```sql
UPDATE setting SET resend_tokens='{"example.com":"re_xxx"}', send=0;
```

`resend_tokens` 是 `{"域名": "key"}` 的 JSON 映射，发信时按发件账号域名取 key。

**注意**：`Sending access` 受限 key 读不了 `/domains`、`/webhooks`，建 webhook 必须用面板或 full access key。

## 数据库要点

- `user` 主键是 `user_id`（不是 `id`），管理员判定为 `user.email === env.admin` → 权限 `['*']`
- `account` 表：一个账号 = 一个邮箱地址，字段 `account_id/email/user_id/name/all_receive`
- `email` 表：发件人字段叫 `send_email`（不是 sender_email），状态见下
- `setting` 表：单行配置表

邮件状态枚举（`const/entity-const.js`）：`RECEIVE=0, SENT=1, DELIVERED=2, BOUNCED=3, COMPLAINED=4, DELAYED=5, SAVING=6, NOONE=7, FAILED=8`

开关枚举（**0=OPEN，1=CLOSE**，容易记反）：

- `register`：0 开放注册 / 1 关闭
- `receive`、`send`：0 开 / 1 关
- `reg_key`：0 必须邀请码 / 1 关闭 / 2 可选
- `tg_bot_status`、`forward_status`、`webhook_status`：0 开 / 1 关

**改完 setting 表必须刷新缓存**，否则不生效：

```bash
curl "https://mail.example.com/api/init/<jwt_secret>"
```

## 写 D1（REST）

`wrangler d1 execute` 参数解析经常出错，直接用 REST：

```bash
curl -X POST -H "Authorization: Bearer $TOK" -H "Content-Type: application/json" \
  -d '{"sql":"UPDATE setting SET send=0","params":[]}' \
  "https://api.cloudflare.com/client/v4/accounts/$A/d1/database/$D/query"
```

**必须用 `params` 传值**，把 token/key 拼进 SQL 字符串会静默失败（`changes:0`）。

## Telegram 推送

`setting` 表三列：`tg_bot_token`、`tg_chat_id`（逗号分隔多个）、`tg_bot_status=0`。另需 `custom_domain='https://mail.example.com'`，否则推送卡片里的 View 按钮指向 404。

推送内容是 HTML 消息 + inline keyboard（`View` web_app 按钮 + 验证码复制按钮）。

**把旧 bot 改造成收信 bot 的完整动作**：

1. 取 bot token，`getMe` 确认用户名
2. 写入 `setting` 三列 + `custom_domain`
3. `curl /api/init/<jwt_secret>` 刷缓存
4. 清空旧命令菜单——**所有 scope 都要清**，否则客户端仍显示旧菜单：
   ```bash
   deleteMyCommands                                  # default
   deleteMyCommands {"scope":{"type":"chat","chat_id":<id>}}
   deleteMyCommands {"scope":{"type":"all_private_chats"}}
   deleteMyCommands {"scope":{"type":"all_group_chats"}}
   deleteMyCommands {"scope":{"type":"all_chat_administrators"}}
   ```
5. 改 bot 资料：`setMyName` / `setMyDescription` / `setMyShortDescription`
6. **清持久键盘**：`sendMessage` 带 `reply_markup:{"remove_keyboard":True}`。客户端缓存的底部按钮只能靠这条消息清掉，服务端删不掉
7. `systemctl stop && disable` 旧 bot 服务

## Webhook 状态回写（可选）

`POST /api/webhooks` 接收 Resend 事件，更新 `email.status`。

**原版端点完全无鉴权**——任何人知道 URL 就能伪造 bounce/complaint 改邮件状态。加固方案：按 Svix 规范校验

- 签名内容 `${svix-id}.${svix-timestamp}.${rawBody}`，HMAC-SHA256，secret 去掉 `whsec_` 前缀后 base64 解码
- `svix-signature` 形如 `v1,<b64sig> v1,<b64sig2>`，任一匹配即通过
- 时间戳偏差 > 300 秒拒绝

未配置 `RESEND_WEBHOOK_SECRET` 时**直接返回 401 关闭端点**（而不是放行），避免裸奔。

## 排障速查

| 现象 | 原因 |
|---|---|
| `Could not resolve "dayjs/plugin/timezone"` | `mail-worker` 没装依赖，`pnpm install` |
| `/init/<secret>` 返回 HTML | 漏了 `/api` 前缀 |
| 改了设置不生效 | 没调 `/api/init/<jwt_secret>` |
| `no such column: id` | `user` 表主键是 `user_id` |
| D1 UPDATE `changes:0` | 值拼进 SQL 字符串了，改用 `params` |
| `10042 Please enable R2` | R2 未开通，附件功能不可用 |
| `9109 Unauthorized` | token 缺对应权限组 |
| 收不到信 | catch-all 没指向 worker（默认是 `drop`） |
| TG 不推送 | `tg_bot_status` 不是 0，或 `custom_domain` 为空 |
| TG 底部按钮不消失 | 没发带 `remove_keyboard` 的消息 |

## 安全清单

- 部署完立刻 `UPDATE setting SET register=1` 关闭开放注册，否则任何人能注册你的域名当一次性收码邮箱
- 管理员密码用强密码，不要与面板其它服务复用
- Resend key 用 `Sending access` 受限权限，不要给 full access
- 凭据文件统一 `chmod 600`，不写进 git、不发聊天窗口
- 临时 bootstrap 用的 Global API Key 建完 token 立刻删除
