---
name: restricted-sftp-share
description: "跨机只读共享目录：受限 sftp 账号 + chroot + 只读 bind mount + sshfs 挂载。"
version: 1.0.0
author: 柠檬
license: MIT
platforms: [linux]
metadata:
  hermes:
    tags: [sftp, sshfs, chroot, bind-mount, least-privilege, file-share, sshd]
    related_skills: [cloud-sandbox-vm-ops, socks5-proxy-setup, instabox-node-ops]
---

# 跨机只读共享目录（受限 sftp + sshfs）

## When to Use

- "把这台机器的某个目录挂到那台机器上"、"让沙箱能访问 VPS 上的下载目录"、"挂载 qb 视频"；
- 需要让一台（可能是不可信/临时的）机器读取另一台机器的数据，但**绝不能给它 root 或整机读写**；
- 共享方向是**只读**、单目录、长期可用。

不适合：需要双向写、需要低延迟大吞吐（sshfs 走 SSH，读大文件会受对端上行限制）、或两端同一局域网且有 NFS/SMB 条件时。

## 设计原则：默认最小权限

给临时机器开 root 的 sftp 等于把整机交给它。正确姿势是四层收敛：

1. **专用系统用户**（`nologin`，无 home）；
2. **chroot** 锁定，登录后只看得见一个目录；
3. **只读 bind mount**，物理上删不了改不了；
4. **密钥条目加 `restrict` + `command="internal-sftp"`**，禁 pty、禁端口转发、禁隧道。

## 服务端步骤（已实测）

### 1. 建用户与 chroot 骨架

```bash
useradd -r -M -d /srv/qbmount -s /usr/sbin/nologin qbmount
mkdir -p /srv/qbmount/downloads
chown root:root /srv/qbmount     # ChrootDirectory 必须 root 拥有且组/其他不可写
chmod 755 /srv/qbmount
```

`/srv` 及其上级默认就是 `root:root 755`，不要改。chroot 目录**不能** chown 给受限用户，否则 sshd 拒绝。

### 2. 只读 bind mount（两步，不能一步到位）

```bash
mount --bind /home/ubuntu/Downloads /srv/qbmount/downloads
mount -o remount,ro,bind /srv/qbmount/downloads      # 单写 -o ro 不生效
```

持久化：

```bash
echo "/home/ubuntu/Downloads /srv/qbmount/downloads none bind,ro 0 0" >> /etc/fstab
```

注意 fstab 里这一行在开机时由 systemd 处理，源目录必须先存在。

### 3. 密钥走绝对路径（关键，绕开 StrictModes）

```bash
install -d -m 755 -o root -g root /etc/ssh/keys
printf 'command="internal-sftp",restrict %s\n' "$PUBKEY" > /etc/ssh/keys/qbmount
chown root:root /etc/ssh/keys/qbmount
chmod 644 /etc/ssh/keys/qbmount
```

### 4. sshd Match 块

```bash
cat > /etc/ssh/sshd_config.d/99-qbmount.conf <<'EOF'
Match User qbmount
    ChrootDirectory /srv/qbmount
    ForceCommand internal-sftp
    AuthorizedKeysFile /etc/ssh/keys/qbmount
    AllowTcpForwarding no
    AllowAgentForwarding no
    PermitTunnel no
    X11Forwarding no
    PermitTTY no
EOF
```

### 5. 校验与 reload

```bash
sshd -t && systemctl reload ssh
```

**用 `reload` 不用 `restart`**，避免掐断自己和其他人的现有 SSH 会话。改前先备份 `/etc/ssh/sshd_config` 到 `/root/qbmount-backup-<时间戳>/`。

## 客户端步骤（sshfs）

```bash
sudo apt-get install -y sshfs
mkdir -p /data/mnt/qb
sshfs qbmount@<对端IP>:/downloads /data/mnt/qb -o ro,reconnect,ServerAliveInterval=15
```

chroot 之后路径是 `/downloads`，**不是**宿主机上的 `/home/ubuntu/Downloads`——这是最容易填错的一项。

卸载用 `fusermount3 -u /data/mnt/qb`（不要 `umount`，普通用户会被拒）。

> 状态说明：本次会话服务端全部步骤已实测通过（`sshd -t` OK、reload 后 `active`、bind mount 确认 `ro`）；客户端 sshfs 挂载这一步因审批弹窗超时被中止，**未完成端到端验证**。首次落地时按下面的验收清单走完再报成功。

## 验收清单（缺一条都不算完成）

| 层 | 命令 | 期望 |
|---|---|---|
| 用户存在 | `id qbmount` | 有 uid，shell 为 nologin |
| chroot 骨架 | `ls -ld /srv/qbmount` | `root:root 755` |
| 只读挂载 | `mount \| grep qbmount/downloads` | 含 `ro` |
| 语法 | `sshd -t` | 无输出 |
| 服务 | `systemctl is-active ssh` | `active` |
| 密钥可用 | 客户端 `sftp -i <key> qbmount@host` + `ls /downloads` | 列出文件 |
| 只读生效 | sftp 里 `rm /downloads/<某文件>` | 失败（Permission denied） |
| 越权被挡 | sftp 里 `ls /` | 只有 `downloads` |
| 转发被禁 | `ssh -i <key> qbmount@host` | 拒绝（无 pty / ForceCommand） |

"能列目录"只是第一层，**必须补测「删不掉」和「看不到别处」**，否则只证明了连通，没证明权限收敛。

## 坑（全部来自真实报错）

1. **`StrictModes` 不允许出现在 Match 块内**：`Directive 'StrictModes' is not allowed within a Match block`。想在 Match 里关 StrictModes 走不通。
2. **正确解法是 `AuthorizedKeysFile` 指绝对路径**：把 `authorized_keys` 放到 `/etc/ssh/keys/<user>`（`root:root 644`），StrictModes 检查的是用户 home 的权限，绝对路径文件由 root 拥有即合规，不需要关 StrictModes。别去全局关 StrictModes，那会削弱所有用户。
3. **Ubuntu 的 sshd 服务单元叫 `ssh` 不叫 `sshd`**：`systemctl reload sshd` 报 `Unit sshd.service not found`。用 `systemctl reload ssh`（`sshd -t` 仍是二进制名，两者不冲突）。
4. **`mount --bind -o ro` 单步不生效**：必须先 bind 再 `remount,ro,bind`，否则挂上去仍是可写。
5. **chroot 后路径变了**：客户端看到的根是 chroot 目录，填 `/downloads` 而不是源目录全路径。
6. **先确认自己登录用的是哪个用户**：`ssh` 到对端 `whoami` / `echo $HOME` 一下再决定 authorized_keys 落点。本次就踩到"以为登录是 `ubuntu`，实际是 `root`，`/home/ubuntu/.ssh/authorized_keys` 根本不存在"。
7. **审批弹窗会拦出站 ssh/sftp**：`ssh-keyscan`、`sftp ...` 这类对外连接也可能触发人工审批，超时即整条作废。把这类命令单独发、不要和 `sudo mkdir` 混在一条里，被拦时才能判断到底哪步没执行。

## 回滚

```bash
rm -f /etc/ssh/sshd_config.d/99-qbmount.conf
umount /srv/qbmount/downloads 2>/dev/null
sed -i '\#qbmount/downloads#d' /etc/fstab
userdel qbmount
rm -rf /srv/qbmount /etc/ssh/keys/qbmount
sshd -t && systemctl reload ssh
```

## 相关

- 沙箱/远程 VM 的 SSH 接入与 sudo 审批摩擦 → `cloud-sandbox-vm-ops`
- 只想测通不通、不搭共享 → 直接 `sftp`/`ssh` 单命令验证即可，不必建用户
