# 控制入口与内存取证

- `desktop-commander-remote.service` 是外部客户端使用的 ubuntu 用户级运维入口，不要求出现在 Hermes 的 MCP 配置中。2026-10-28 迁移验收记录：naye 本机因缺少可执行文件而停用该单元，旧 AWS 管理入口保留。本机只读复核为 disabled/inactive；旧机的实时状态须到旧机核验。不得把旧机入口的保护要求解释成自动启用新机残留单元。
- 将该服务视为受保护的控制入口。Hermes 配置未引用、暂时没有调用、只有中继外连、内存较高，都不足以证明闲置、恶意或可以删除；用途或外部依赖未核实，应标记“待核实”，不得直接判作废弃。
- “查内存、优化内存、清理闲置服务”等笼统请求，不构成停用、重启、卸载、disable/mask、撤销设备或凭据、阻断该链路的授权。未经所有者针对该入口的明确维护或退役授权，不得执行上述动作，也不得通过杀进程、批量清理或网络变更间接切断它。
- 获得明确维护授权后，仍须先只读核对服务用途、近期实际工具调用和日志、进程归属及外部依赖；说明影响范围，备份相关配置，并验证独立可用的恢复入口和回滚步骤，再做最小变更。不得仅因短时无调用就判定可以退役。
- 检查或清理该服务的子进程前，核对对应工具调用/终端会话是否已结束；不得按进程年龄或名称批量杀掉整个进程组。证据不足时保留现场。
- 输出结论时区分已验证事实和推断。内存须说明统计口径与采样时间；不得混淆 PID 与端口、RSS 与 cgroup 总量，也不得把一次观测说成固定成本。
- 运维采样时间必须与指标一起从实际只读工具读取，保留原始时间与时区；展示北京时间须按 Asia/Shanghai 换算。不得用模型猜测、回复时间或未读取的系统时钟冒充采样时间。证据没有时间时写“采样时间未记录”，不得补造。
- 内存单位按工具原始口径换算：Linux ps 的 RSS、/proc 中标作 kB 的内存数值按 KiB 处理，MiB=KiB/1024，MB=KiB*1024/1000000；例如 RSS 237620 KiB=232.05 MiB≈243.32 MB，不能写成 237.6 MB。systemctl show 的 MemoryCurrent 是字节；systemctl status 的人类可读 M 与 ps RSS 不得混同。RSS、Swap、共享页和 cgroup 口径须明确，不能直接混加当作唯一实际占用。
- 一次内存快照只支持该采样时刻的判断；不得据此断言“无 OOM 风险”“不会内存溢出”或保证未来稳定。确认历史 OOM 须实际读取对应时间范围的日志；判断持续内存压力或换页活跃度须有时间序列证据。未取得时明确说明未验证，不把 Swap 已用量等同于正在频繁换页。
- 这些限制针对控制入口的中断性变更；普通问答、只读巡检和其他服务的已授权维护按原有权限与流程执行。本规则不增加任何用户权限。

## 只读巡检自身必须无残留（2026-10-30 实测事故）

全盘递归搜索必须在**遍历端**排除内核伪文件系统，不能只在输出端过滤。

```bash
# 错：排除写在管道里，只过滤输出，拦不住遍历
grep -rn 'rules-admin' / 2>/dev/null | grep -vE '^/(proc|sys|var/lib/docker)'

# 对：排除写在 grep 自身参数上
grep -rn --exclude-dir={proc,sys,dev,run} 'rules-admin' / 2>/dev/null
# 更好：限定到已知目录，别从 / 起步
grep -rn 'rules-admin' /etc /opt /usr/local/etc 2>/dev/null
```

实测后果：`grep -rn rules-admin /` 递归进 `/proc/<pid>/task/<tid>/pagemap`（内核伪文件，读不到尽头）后卡死空转，SSH 会话断开后成孤儿，在 2 vCPU 机上持续占满一整核 **2 天 12 小时、累计 214625 秒 CPU（约 59.6 小时）**，把 load average 顶到 3.27 并加剧 kswapd/kcompactd 回收压力。排查当时只看 `ps` 的 `%CPU` 会漏判——那是进程生命周期平均值，须用 `TIME`（累计 CPU 秒）或 cgroup `usage_usec` 增量定位。

配套规则：

- 远端一次性排查命令用 `timeout` 兜底：`ssh host "timeout 60 grep -rn --exclude-dir={proc,sys,dev} ... "`。一次性 `bash -c` 巡检不设超时，终端一断就留孤儿。
- `%CPU` 排名不可信时，用 20 秒 cgroup 增量采样定位真实消耗者（`/sys/fs/cgroup/**/cpu.stat` 的 `usage_usec` 差值 ÷ 窗口秒数 = 占单核百分比），能直接定位到 service/容器 scope，比逐进程猜准。
- 收尾核对自己留下的进程：`ps -eo times,pid,etimes,args --sort=-times | head`，累计 CPU 时间排第一却不是常驻服务的，基本就是跑飞的巡检。
- 清理这类残留前仍须核对归属：确认在 `closing` 状态的 `user.slice/user-*.slice/session-*.scope` 里、不属于任何 systemd 服务、对应终端会话已结束；`loginctl show-session <id>` 看 `State`。先 SIGTERM，别直接 -9。
- 命令里不要把 `kill` 和受保护入口名写在同一行，否则命中 deny 规则整条被拦；拆成两条执行。
- load average 是 1/5/15 分钟指数衰减值，杀掉元凶后不会立刻归零。验收要同时取 `vmstat` 瞬时 idle 和运行队列 `r`，并等 5 分钟以上再读 load 作为确认。
