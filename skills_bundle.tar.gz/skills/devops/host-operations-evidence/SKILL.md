---
name: host-operations-evidence
description: 核验控制入口依赖、内存口径与服务变更证据.
metadata:
  hermes:
    category: devops
    tags: [operations, evidence, memory]
---

# Host Operations Evidence Skill

处理控制入口保护、服务退役判断及 Linux 内存取证。普通问答无需加载；本技能不授予生产变更权限。

## When to Use

- 用户要求查内存、清理进程、优化服务，且可能影响运维入口。
- 需要判断进程是否闲置、核对 RSS/cgroup/Swap，或说明 OOM 证据。

## Prerequisites

可用的 `terminal`、`read_file` 等本机只读工具；执行写操作前须有对应范围的授权。

## How to Run

用 `read_file` 完整读取 `references/control-entry-and-memory.md`，再按本次问题采样。

## Quick Reference

- 部署角色与配置以当前主机和实际配置为准；迁移历史不能冒充实时状态。
- 控制入口是否在 Hermes MCP 列表内，不是能否停用的判据。
- 内存结论必须附实际采样时间、时区和统计口径。

## Procedure

1. 用 `terminal` 核对当前主机、systemd 单元层级和用途；区别 naye 主力机、旧 AWS 灾备和远端 VPS。
2. 涉及入口或其子进程时，先核对外部依赖、对应工具调用和终端会话是否结束。
3. 内存问题按参考文档采样；历史 OOM 与持续压力另查日志和时间序列。
4. 在已授权范围内实施最小修改，保留配置副本、独立恢复入口及回滚方式。

## Pitfalls

- 仅凭服务名、进程年龄、短时无调用或内存较高就判定可停用。
- 用 `ps` 的 `%CPU` 找高负载元凶（那是生命周期平均值，会漏掉跑飞进程）；应看累计 `TIME` 或 cgroup `usage_usec` 增量。
- 自己的只读巡检留下孤儿进程：全盘 `grep -r /` 未在遍历端排除 `/proc`，或一次性远端命令未加 `timeout`。详见参考文档末节。
- 把本机已停用的残留单元自动启用，或把旧机入口当作本机服务。
- 混淆 PID/端口、RSS/cgroup、KiB/MB，或凭一次快照保证未来没有 OOM。

## Verification

区分实际读到的事实、推断和未验证项；服务变更验证真实功能及独立恢复路径，不能只看 active。
