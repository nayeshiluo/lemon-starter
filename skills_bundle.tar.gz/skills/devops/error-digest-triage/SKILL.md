---
name: error-digest-triage
description: 判读每日错误日志汇总：分清真故障、设计内语义与采集误报。
version: 1.1.0
author: 柠檬
license: MIT
metadata:
  hermes:
    category: devops
    tags: [error-digest, journalctl, triage, daily-report, observability]
    related_skills: [host-operations-evidence, selfhosted-service-audit, lemon-vps-sync-ops]
---

# 每日错误日志汇总判读

## When to Use / 触发条件

- 收到「每日错误日志汇总」，需要给结论而不是复述数字
- 某来源错误条数突然翻倍或骤降，要判断是不是真出事
- 业务状态显示 PARTIAL / FAILED，需要归因到具体环节
- 采集缺口里反复出现同一条，怀疑是采集器 bug 而不是环境问题
- 某 LLM 节点/上游失败率偏高，要判断是上游限流、网络还是配置 → 见 `references/llm-node-failure-isolation.md`

## 核心原则

**日志错误条数 ≠ 失败请求数。** 日报自己的口径说明写了这句，判读时必须当真。

每次都要把结论分进三类，不要混着说：

| 类别 | 特征 | 处理 |
|---|---|---|
| 真故障 | 持续、有业务影响、能复现 | 修 |
| 设计内语义 | 非零退出码 / 非成功业务状态是故意设计的 | 解释，不改 |
| 采集误报 | 采集器判定逻辑有 bug，事实相反 | 修采集器 |

## 一、先读判定代码，别猜

业务状态字段几乎都不是"健康检查"，而是某个脚本自己 `finish()` 出来的。归因前先定位那几行：

```bash
grep -rn "def finish\|return finish\|_RESULT {\|_RESULT=" --include=*.py <项目目录>
```

典型陷阱：状态由**单一计数器**驱动。比如 `failed` 为 1 就让整轮 PARTIAL，而 `blocked` / `permanent_rejected` 几十条却仍是 SUCCESS —— 因为后者是设计内的内容过滤。

**归因顺序**：先看这个字段是哪个脚本产的，再查那个脚本；不要因为某个服务名字最眼熟就先查它。

### 已确认的一例：媒体=PARTIAL

「媒体」不是 `lemon-vps-sync` 的健康检查，由 `automation-observations.py` 汇总三个子项。PARTIAL 来自 `scheduled_sync_and_clean.py` 的 `finish()`，**只由 `stats['failed']` 和 `cleanup_error` 决定**：

```python
if stats['failed'] or stats.get('cleanup_error'):
    return finish('PARTIAL' if pushed_count else 'FAILED')
```

所以单条 `urlopen error _ssl.c:999: The handshake operation timed out` 就足以让整轮 PARTIAL。worker 细节见 `lemon-vps-sync-ops`。

## 二、退出码语义表

| 退出码 | 常见来源 | 真实含义 |
|---|---|---|
| 0 | 全部 | 成功 |
| 2 | media-pipeline / delayed-clean | **业务语义**：PARTIAL 或 ACTION_REQUIRED（有待人工决定的候选），不是崩溃 |
| 75 | 带 ProcessLock 的 job | SKIPPED_LOCK，锁被常驻任务占着 |
| 21 | 带 preflight 的 oneshot | 每轮 preflight 失败，不是崩溃循环 |

判定 "failed" 先看 `Result: exit-code` 和第一条错误行，别只看 `systemctl status` 的 active/failed 字样。

## 三、采集缺口先证伪，再采信

缺口列表里每一条都是采集器的一个判断，判断本身可能是错的：

1. 缺口说"保留不足 24 小时" → 上机实测最早记录时间
2. 缺口说"窗口无日志" → 确认该 unit 是否真在这个窗口有活动
3. 缺口说"日志截断" → 看是不是采集端 `-n` 行数上限，不是源端丢日志

实测与缺口矛盾时，**修采集器，不要改结论去迁就缺口**。`journalctl` 保留期判断有一个版本相关的坑，见 `references/journalctl-retention-check.md`。

## 四、改采集器后必须重跑对比

不能只 `py_compile` 就报成功。改完立刻跑一次，把改前/改后的缺口列表逐条对照：

```bash
python3 digest.py            # 不带 --send，只出报告不推送
sed -n '/采集缺口/,/重复日志/p' latest/error-digest.txt
```

验收标准两条：

1. 目标缺口消失
2. **其他缺口没有跟着消失** —— 防止把判断改成恒真/恒假。若某主机确实保留不足，改完它必须仍然报

## 五、已知噪音源

速查（每条都实测确认过"看着像故障、实际不是"，判据见 `references/known-noise-catalog.md`）：

- 探针超时但端点实测 200 → 阈值过紧 + 链路抖动
- 云沙箱 `platform=suspended` + ssh 被远端断开 → 休眠重连，设计内
- 容器短窗口内集中报同一上游错误 → 上游抖动，看时间分布别只看总数
- 常驻任务持锁导致 final job 长期 SKIPPED_LOCK → 看常驻任务本身是否正常，别追 final
- `aws/Hermes 业务失败` 含 `no_healthy_account 503` → CPA/腾白嫖账号池短暂耗尽，Hermes 自动重试后回退到下一 provider；看时间分布，几分钟窗口集中 = 一过性，无持续影响
- `aws/Hermes 业务失败` 含 `Refusing background curator patch for pinned skill / not curator-managed` → 后台 curator 被工具安全层拦截，不是代码错误；目标技能无法自动维护（可手动 `hermes curator adopt <name>` 转让）
- `vps-la/lemon-xray 业务失败` 138 条稳定在基线 → scanner TLS garbage + 固定 IP 探测 `/v1/models`，设计内；按周对比确认条数未显著增长即可
- Komari `Ping task failed: context deadline exceeded` → **持续型噪音，不是一过性**。改 DNS 只能压掉一部分；残余每期稳定 40 条上下，集中在固定低峰时段（UTC 19–23 / BJ 03:00–07:00），是国际链路抖动 + 探针 client 默认超时偏紧。判据：从本机 `curl` 该 target 得 200 + 亚秒 → 服务健康，噪音在探针侧。Komari `ping_tasks` 表无 timeout 字段，改不了阈值，调频率（60s→120s）是唯一手段，收益不值，**建议不动**。
- 上游 LLM 节点失败率 37–40% 但 fallback 全兜住（`antigravity_gemini`）→ 用户无感，但要在结论里给出失败率数字和节点名，让用户自己判断要不要降位；不要一句「已有兜底，无需处理」带过。**归因前必须做并发对照实验**，见 `references/llm-node-failure-isolation.md` 与 `scripts/llm_concurrency_probe.py`：实测该节点并发 >2 即挂起不响应（**不是** 429/503，所以网关日志里看不到），而同一 CPA、同一时刻的 `cpa_gpt6_luna` 并发 8 全过 → 上游并发限流。~~早期写成「TLS handshake timeout / EOF」是错的~~，那 4 条是 CPA journal 里另一批记录，与群霸的失败无关。

## 六、Python 库版本兼容 bug 归因（certificate-deploy 类故障）

`certificate-deploy` 长期 FAILED (exit 1) 实例：脚本调 `x509.not_valid_after_utc`，系统 `cryptography` 是 38.0.4（该属性 42+ 才引入），报 `AttributeError: 'builtins.Certificate' object has no attribute 'not_valid_after_utc'. Did you mean: 'not_valid_after'?`。

归因步骤：
1. 看 `capy-acme.log` 最后几行（traceback 会明说哪行哪属性）
2. `python3 -c "import cryptography; print(cryptography.__version__)"` 确认库版本
3. 对比错误属性的引入版本（`not_valid_after_utc` 是 cryptography 42 引入的）
4. 修法：`getattr(obj, 'not_valid_after_utc', None) or obj.not_valid_after.replace(tzinfo=utc)` 向下兼容

**证书是否真的需要续期独立验证**：`python3 -c "from cryptography import x509; import pathlib; c=x509.load_pem_x509_certificate(pathlib.Path('/path/to/fullchain.pem').read_bytes()); print(c.not_valid_after)"` 直接读，绕开脚本。到期前 30 天才需要续期，脚本 crash 不等于证书失效。

### 这类故障怎么被发现：扫状态文件的 last_success_at 缺口

它几乎不会出现在错误条数排名里——脚本抛异常直接退出，日志只有一次 Traceback，条数为 0。必须主动扫：

```bash
python3 -c "
import json,glob,os
for f in sorted(glob.glob('/home/ubuntu/.local/state/automation-cron/*.json')):
    n=os.path.basename(f).replace('.json','')
    d=json.load(open(f))
    print(f'{n:22} {d.get(\"status\"):8} exit={d.get(\"exit_code\")} last_ok={str(d.get(\"last_success_at\"))[:19]}')
"
```

判据：`status=FAILED` **且** `last_success_at` 是几天前 → 持续故障，必须修；`last_success_at` 是上一轮 → 单次失败，看下轮是否自愈。

修完复验要跑 crontab 里的**完整命令**（含 `cron-status.py <job> --` 包装层），不是只跑内层脚本。验收标准是 `exit=0` **且** 状态文件 `last_success_at` 被刷新，两条都满足才算修好。

跨机部署验收、端口握手陷阱、业务层分类问题详见 `references/certificate-automation-failures.md`。

## Pitfalls

- **拿总条数排名当故障排名。** 要按时间分布看：10 秒内 20 条是一次抖动，均匀铺满 24 小时才是持续问题。
- **把"窗口无日志"当零故障。** 日报自己写了不能据此判断正常，尤其跨机中转、后台任务终态这类只在有请求时才出日志的链路。
- **看到 PARTIAL 就去查最眼熟的服务。** 先看状态字段是哪个脚本产的，再定位。
- **只降应用日志级别来治 journal 保留问题。** 要同时看容量上限和其他来源 —— `sshd` / `systemd-logind` / `sudo` 往往才是大头，应用日志可能只占一小部分。先按 ident 统计占比再决定改哪。
- **改采集器只验证"目标缺口消失"。** 不验证"该报的还报"，会造出沉默的监控。
- **在业务层放宽判定条件来让日报变绿。** 失败就该报；降噪在日报层做，不在业务层掩盖。
- **同一事件被两个计数器重复计入。** 典型：`provider_353`（内容审核拒绝）同时 `stats['failed'] += 1` 和 `stats['provider_353_pending'] += 1`，于是每天都因一条审核拒绝而 PARTIAL。判断标准是「这条计数有没有独立的语义桶」——有，就不该再进 `failed`。修完必须同步改单测里 `assertEqual(first['failed'], 1)` 这类断言，否则测试会替旧语义站台。改前先跑 `python3 -m unittest <module>` 确认只有目标断言失败、其余全过，避免掩盖真实回归。
- **把脚本打印的成功当部署成功。** 跨机部署（签发 → scp → 容器 reload）任一跳静默失败仍可能打印 `deployed and reloaded`。必须验远端文件 mtime + 到期时间 + 容器内是否同步，三步都要。
- **TLS 握手成功就以为站点存在。** `openssl s_client` 握手成功、能拿到证书，`curl` 却返回 `HTTP=000` —— 那是反代完成了握手但**没有该域名的 site block**。先 `grep` 反代配置，别先怀疑证书或防火墙。
- **只看 FAILED 条数，不看 `last_success_at`。** 一个 cron 连续 FAILED 好几天，日志条数可能接近 0；持续故障的判据是 `last_success_at` 停在几天前，不是当日错误条数。
- **把「服务端判定文件违规」当网络失败重试。** 上游内容审核拒绝重试必然过不了，应归终态拒绝；但改分类属业务判定层，须用户明确同意，不能在日报层掩盖。
- **把 A 日志流的条数安到 B 来源的失败上。** 日报说「群霸 54 条」，你去某服务 journal 查到几条 TLS 超时，就当成同一批事件归因 —— 实测是两回事：群霸记的是 `http_status=400`（0.8s 快速拒绝）和 `http_status=None`（33s 预算耗尽），与 CPA journal 那 4 条 TLS 超时**毫无关系**。核对方法：**① 时间戳对齐；② 比状态码 / `error_category` 字段构成**。两批记录的状态码构成不同，就是两个独立故障，必须分开归因、分开计数。同名上游 ≠ 同一条日志流；日报来源名与本地 unit 也不是一对一（如 `aws/群霸1` → `lemon-group-bot.service`），映射见 `references/llm-node-failure-isolation.md`。
- **用 `-p warning..err` 查不到就断定没错误。** 日报统计的常常是 INFO 级结构化字段（`outcome=failed` / `outcome=timed_out`），不是 journal priority。要按字段 grep，别按优先级过滤。
- **把「日志里没错误」当成「没发生故障」。** 上游并发限流的表现是**挂起不响应**，不是 429/503，所以网关侧一行错误都不会有。反向判据：客户端 `timed_out` 的 `node_elapsed_s` 整齐等于 `node_budget_s` → 上游挂起，不是客户端逻辑问题。
- **修完一个疑似根因就宣布解决。** 探针超时曾归因 DNS 丢包，改 `resolv.conf` 后条数确实降了一部分，下一期同源仍有 40+ 条。判定方法：①服务端从本机实测健康（200 + 亚秒）；②失败集中在固定时段而非均匀铺满全天 → 链路问题，不是本机配置。**改完必须等下一期同源条数对比才能结案**，不能凭「改完当场实测正常」就报解决。归因不完整要直接认，不要把错判断留在技能或结论里。
- **改完 DNS/网络配置不复验延迟。** 给服务加 CF 代理、换 DNS、加反代这类变更，除了看通不通，还要量延迟有没有劣化（同一接口连测 8 次取中位数，和直连源站对比）。通了但慢了同样是事故。

## Verification

给出结论时必须区分：实测确认的事实 / 代码推断 / 未能核实项。每条"不是故障"的判断都要附实测证据（HTTP 码、时间分布、上机时间戳），不能只凭"看起来像"。

## 汇报形状

用户要的是判断，不是复述日报。按这个顺序写：

1. **先给结论表**：每项一行，附实测证据（命令输出、时间戳、HTTP 码）。已修好的写清 exit 码和状态文件刷新时间。
2. **再分两栏**：
   - 「**你要做的**」—— 只有需要用户拍板的事，每条说清选项与代价。业务判定层改动、隐私/IP 暴露、不可逆删除都必须放这里。
   - 「**不用你管的**」—— 已处理完的、判定为设计内的、判断为不需要动的（附理由）。
3. **不要**把已修好的事混进"需要你决定"，也不要为了凑数把设计内语义列成待办。

用户多次追问「核验一下」「复验一遍」时，说明上一轮汇报缺实测证据。补救方式是重新上机跑，不是把结论换个说法再讲一遍。
