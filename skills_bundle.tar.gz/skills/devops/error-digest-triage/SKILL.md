---
name: error-digest-triage
description: 判读每日错误日志汇总：分清真故障、设计内语义与采集误报。
version: 1.0.0
author: 柠檬
license: MIT
metadata:
  hermes:
    category: devops
    tags: [error-digest, journalctl, triage, daily-report, observability]
    related_skills: [host-operations-evidence, selfhosted-service-audit, lemon-vps-sync-ops]
---

# 每日错误日志汇总判读

## When to Use / 触发条件

- 收到「每日错误日志汇总」，需要给结论而不是复述数字
- 某来源错误条数突然翻倍或骤降，要判断是不是真出事
- 业务状态显示 PARTIAL / FAILED，需要归因到具体环节
- 采集缺口里反复出现同一条，怀疑是采集器 bug 而不是环境问题

## 核心原则

**日志错误条数 ≠ 失败请求数。** 日报自己的口径说明写了这句，判读时必须当真。

每次都要把结论分进三类，不要混着说：

| 类别 | 特征 | 处理 |
|---|---|---|
| 真故障 | 持续、有业务影响、能复现 | 修 |
| 设计内语义 | 非零退出码 / 非成功业务状态是故意设计的 | 解释，不改 |
| 采集误报 | 采集器判定逻辑有 bug，事实相反 | 修采集器 |

## 一、先读判定代码，别猜

业务状态字段几乎都不是"健康检查"，而是某个脚本自己 `finish()` 出来的。归因前先定位那几行：

```bash
grep -rn "def finish\|return finish\|_RESULT {\|_RESULT=" --include=*.py <项目目录>
```

典型陷阱：状态由**单一计数器**驱动。比如 `failed` 为 1 就让整轮 PARTIAL，而 `blocked` / `permanent_rejected` 几十条却仍是 SUCCESS —— 因为后者是设计内的内容过滤。

**归因顺序**：先看这个字段是哪个脚本产的，再查那个脚本；不要因为某个服务名字最眼熟就先查它。

### 已确认的一例：媒体=PARTIAL

「媒体」不是 `lemon-vps-sync` 的健康检查，由 `automation-observations.py` 汇总三个子项。PARTIAL 来自 `scheduled_sync_and_clean.py` 的 `finish()`，**只由 `stats['failed']` 和 `cleanup_error` 决定**：

```python
if stats['failed'] or stats.get('cleanup_error'):
    return finish('PARTIAL' if pushed_count else 'FAILED')
```

所以单条 `urlopen error _ssl.c:999: The handshake operation timed out` 就足以让整轮 PARTIAL。worker 细节见 `lemon-vps-sync-ops`。

## 二、退出码语义表

| 退出码 | 常见来源 | 真实含义 |
|---|---|---|
| 0 | 全部 | 成功 |
| 2 | media-pipeline / delayed-clean | **业务语义**：PARTIAL 或 ACTION_REQUIRED（有待人工决定的候选），不是崩溃 |
| 75 | 带 ProcessLock 的 job | SKIPPED_LOCK，锁被常驻任务占着 |
| 21 | 带 preflight 的 oneshot | 每轮 preflight 失败，不是崩溃循环 |

判定 "failed" 先看 `Result: exit-code` 和第一条错误行，别只看 `systemctl status` 的 active/failed 字样。

## 三、采集缺口先证伪，再采信

缺口列表里每一条都是采集器的一个判断，判断本身可能是错的：

1. 缺口说"保留不足 24 小时" → 上机实测最早记录时间
2. 缺口说"窗口无日志" → 确认该 unit 是否真在这个窗口有活动
3. 缺口说"日志截断" → 看是不是采集端 `-n` 行数上限，不是源端丢日志

实测与缺口矛盾时，**修采集器，不要改结论去迁就缺口**。`journalctl` 保留期判断有一个版本相关的坑，见 `references/journalctl-retention-check.md`。

## 四、改采集器后必须重跑对比

不能只 `py_compile` 就报成功。改完立刻跑一次，把改前/改后的缺口列表逐条对照：

```bash
python3 digest.py            # 不带 --send，只出报告不推送
sed -n '/采集缺口/,/重复日志/p' latest/error-digest.txt
```

验收标准两条：

1. 目标缺口消失
2. **其他缺口没有跟着消失** —— 防止把判断改成恒真/恒假。若某主机确实保留不足，改完它必须仍然报

## 五、已知噪音源

速查（每条都实测确认过"看着像故障、实际不是"，判据见 `references/known-noise-catalog.md`）：

- 探针超时但端点实测 200 → 阈值过紧 + 链路抖动
- 云沙箱 `platform=suspended` + ssh 被远端断开 → 休眠重连，设计内
- 容器短窗口内集中报同一上游错误 → 上游抖动，看时间分布别只看总数
- 常驻任务持锁导致 final job 长期 SKIPPED_LOCK → 看常驻任务本身是否正常，别追 final

## Pitfalls

- **拿总条数排名当故障排名。** 要按时间分布看：10 秒内 20 条是一次抖动，均匀铺满 24 小时才是持续问题。
- **把"窗口无日志"当零故障。** 日报自己写了不能据此判断正常，尤其跨机中转、后台任务终态这类只在有请求时才出日志的链路。
- **看到 PARTIAL 就去查最眼熟的服务。** 先看状态字段是哪个脚本产的，再定位。
- **只降应用日志级别来治 journal 保留问题。** 要同时看容量上限和其他来源 —— `sshd` / `systemd-logind` / `sudo` 往往才是大头，应用日志可能只占一小部分。先按 ident 统计占比再决定改哪。
- **改采集器只验证"目标缺口消失"。** 不验证"该报的还报"，会造出沉默的监控。
- **在业务层放宽判定条件来让日报变绿。** 失败就该报；降噪在日报层做，不在业务层掩盖。

## Verification

给出结论时必须区分：实测确认的事实 / 代码推断 / 未能核实项。每条"不是故障"的判断都要附实测证据（HTTP 码、时间分布、上机时间戳），不能只凭"看起来像"。
