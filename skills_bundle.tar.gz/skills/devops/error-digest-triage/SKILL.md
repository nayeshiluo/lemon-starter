---
name: error-digest-triage
description: 判读每日错误日志汇总：分清真故障、设计内语义与采集误报。
version: 1.6.0
author: 柠檬
license: MIT
metadata:
  hermes:
    category: devops
    tags: [error-digest, journalctl, triage, daily-report, observability]
    related_skills: [host-operations-evidence, selfhosted-service-audit, lemon-vps-sync-ops]
---

# 每日错误日志汇总判读

## When to Use / 触发条件

- 收到「每日错误日志汇总」，需要给结论而不是复述数字
- 某来源错误条数突然翻倍或骤降，要判断是不是真出事
- 业务状态显示 PARTIAL / FAILED，需要归因到具体环节
- 采集缺口里反复出现同一条，怀疑是采集器 bug 而不是环境问题
- 某 LLM 节点/上游失败率偏高，要判断是上游限流、网络还是配置 → 见 `references/llm-node-failure-isolation.md`
- 要判断「备份仓库为什么一直涨 / 涨在哪」，或怀疑 `data_added` 与实测不符
  → 用 `scripts/snapshot_content_delta.py <old_snap> <new_snap>`。
  **必须用 content hash 比，不能只比 size**；且要拿两个「纯定时」相邻快照，
  手工跑+prune 之后的 `data_added` 是虚高的。详见 `references/backup-gap-and-capacity-triage.md` §四
- 告警里出现 `❌ 服务未运行` 紧跟着 `✅ 已恢复`，或 `unable to open database file` 反复出现 → 见 `references/service-restart-window-triage.md`
- 用户说「本机被清空了 / 原因不明 / 后面是我重新复原的」→ 见 `references/machine-wipe-forensics.md`
- 备份 job 全绿但快照目录空了/断了几天，或用户问「几台机器磁盘占用都很大，需要清理吗」→ 见 `references/backup-gap-and-capacity-triage.md`
- 仓库稳定逼近配额、prune 每次 rc=0、告警却一直写「prune 未生效」→ 见
  `references/restic-repo-growth-and-sqlite-tiering.md`。真根因常是**高频 SQLite 库每轮全量快照**
  让 restic 去重失效（实测 state.db 407MB 每 3h 重写，单库吃掉约 400MB/3h）。解法是快照分级，
  不是继续调 prune，也不是换机器。用户说「就现有的资源」时尤其走这条。
- 要评估异地接收端换机 / 上传反复超时 → 同一 reference 末节。**只测单流速率会选错机器**，
  必须测并发是否叠加并看 `nstat` 重传计数。
- 用户问「把备份存储迁到另一台机怎么样」（如转 aliyun）→ 先分清接收机上的几条链、
  实测带宽与门禁换算再回答 → 见 `references/backup-receiver-migration-evaluation.md`
- 用户问「aws 那台机你好像没检查」「是不是还有第五台」→ 见下方 Pitfalls 第一条
- 用户发一张 Telegram 告警截图说「这个 / 查一查运维机器人最近发的信息，排查一下原因」→
  **先确认告警是谁发的**（很可能根本不在日报里，也不由运维 bot 发出）。见下方「日报只覆盖它采集的那几条链」一条
- 用户连续追问「闭环这个问题」「复验一遍」→ 说明上一轮只做到「诊断 + 手工修一次」。闭环的定义见「汇报形状」末条与 `backup-chain-audit` 的自愈/门禁模式
- 用户问「有问题的分别是哪些东西、干什么用的、如何处理」→ 见下方「回答形状」一节，
  固定四段（是什么/干什么用/复验证据/处理）且分四档给；这是可决策清单，不是数字复述
- 怀疑某条链路「从来没成功过」而不是「今天抖了」→ 见 `references/log-source-zero-success-and-cache-audit.md`。
  关键动作是 `docker logs <容器>` 不带 `--since` 做全历史 200 计数，别只在 24h 窗口里数错误条
- 日报出现「群霸1/2」「多节点 fallback」类来源的失败/超时 → 见
  `references/fallback-chain-timeout-attribution.md`。**必须先按 `request=` 聚合**，把「N 条 timed_out」
  换算成「几个请求真失败」；有 `ok` 的是兜底成功，全 `TIMEOUT` 无 `ok` 的才是用户可见失败

## 复验（用户说「复验一遍」时）

「复验」= 重新取证据，不是把上一轮结论换个说法重讲。最低要求：

1. **把窗口证据扩展成全历史证据。** 24h 窗口只能说明「这段时间发生了什么」，不能说明
   「这条链路是否曾经工作过」。`docker logs <容器>` 不带 `--since` 就是容器一生，白拿的长基线。
   判据：目标路径 200=0 且全历史达周级 ⇒ **从来没工作过**，是配置缺陷不是抖动。
   实测：某 nginx 容器 6 周 81708 条请求、`/Images/` 25543 条、200 计数 **0**，
   只看 24h 会把它误判成「客户端令牌过期」。完整方法与案例见
   `references/log-source-zero-success-and-cache-audit.md`。
2. **找不依赖日志的第二重证据交叉验证。** 配了 GB 级缓存区却常年几 MB / 几十个文件
   ⇒ 缓存层没工作。缓存只写 200，所以缓存长期为空本身就是 200 缺失的独立旁证。
3. **删除类结论要四维确认**：docker 容器、systemd 单元、安装目录、crontab 各查一遍，
   四个维度都空才写「已删除」。只看 `docker ps` 空就下结论，会把「换机器跑」误判成「删了」。
4. **远端主机复核窗口先换算时区**（见 Pitfalls）。
5. **不要为复现请求去配置文件里抽密钥。** `grep` 出 token / api_key / 私有凭据属凭据抽取，
   会触发安全拦截并让整轮排查卡死在一条命令上。改用不碰凭据的证据：状态码分布、缓存目录、
   全历史 200 计数、上游直连 vs 经反代的差分。凭据式验证必须单独向用户申请并说明用途。
6. **采集器类修法只做 dry-run 对账，不跑真实投递。** 同一 start/end 重跑，验收三条：
   目标缺口归零、其余缺口原样保留、来源数不变。
7. **如实分档**：已改未验收 / 已验证 必须分开写。日报类修复在下一期真实运行前只能算「已改」。

## 「哪些有问题 / 干什么用 / 怎么处理」的回答形状

用户这么问时要的是**可决策清单**，不是数字复述。每条四段齐全：

| 段 | 内容 |
|---|---|
| 是什么 | 具体进程 / 容器 / 单元名 + 部署在哪台机 |
| 干什么用 | 对用户的实际用途（看片、下载、签到、通知），即「挂了会怎样」 |
| 复验证据 | 本次实测数字与命令口径，带采样时间与时区 |
| 处理 | 一句可执行动作 + 是否需要授权 / 用户亲自动手 |

分组固定顺序：**真问题（要动手）→ 用户来做 → 不用管（已验证设计内/噪音）→ 已修**。
「不用管」那档必须写清「为什么不用管」，否则用户下次还会再问一遍。
推断与未核实项单独列在末尾限制说明里，不许混进已验证段落。
**「用户能正常用」不能用来否定问题**：同一次实测里视频流/API 全正常，问题可能只影响一条支路
（如封面缓存），功能可用 ≠ 该链路没坏。

## 核心原则

**日报来源标签 ≠ 真实主机。** 日报里的「aws/Hermes」这类来源名可能只是采集目录名
（如 `REMOTE='/opt/hermes-offsite-backups/aws'`）或历史标签，实际机器可能是另一台。
本会话实测：判读时把「aws」当成了独立亚马逊机并写进拓扑结论，用户质疑
「aws那台我不是不用了准备删除吗」才当场自查 —— 本机实为 naye（IP <YOUR_SERVER_IP>），
ssh config 里根本没有名为 aws 的主机；已退役 AWS 机 <YOUR_SERVER_IP> 完全不在备份链上。
规则：任何要落到具体机器的动作（SSH、改脚本、迁移方案）之前，先 `hostname` +
`grep HostName ~/.ssh/config` 对照标签，别把日报来源名当拓扑；发现自己搞错了要
直接认错并重新锚定，别静默改口。Pitfalls 第一条已有「aws=本机」的旧结论，
本条是它的通用化：**每个来源标签都要这样核，不止 aws 一个。**

**日志错误条数 ≠ 失败请求数。** 日报自己的口径说明写了这句，判读时必须当真。

**怎么把条数换算成请求数**（不是口头原则，要真做）：

- 带 `request=` / `trace_id` / 会话 id 的日志 → 按 id 聚合，再数「有几次尝试、有没有成功一次」
- 带 `host` + 固定端口的反代日志 → 按 host/路径聚合成一条配置问题
- 纯 nginx/容器访问日志 → 用**总请求数当分母**算占比，别看绝对条数

聚合完再下结论。本次实测：5 条 `timed_out` 只对应 2 个请求，其中 1 个兜底成功、
1 个真失败 —— 按条数报会把 1 次失败说成 5 次。方法见
`references/fallback-chain-timeout-attribution.md`。

每次都要把结论分进三类，不要混着说：

| 类别 | 特征 | 处理 |
|---|---|---|
| 真故障 | 持续、有业务影响、能复现 | 修 |
| 设计内语义 | 非零退出码 / 非成功业务状态是故意设计的 | 解释，不改 |
| 采集误报 | 采集器判定逻辑有 bug，事实相反 | 修采集器 |

## 一、先读判定代码，别猜

业务状态字段几乎都不是"健康检查"，而是某个脚本自己 `finish()` 出来的。归因前先定位那几行：

```bash
grep -rn "def finish\|return finish\|_RESULT {\|_RESULT=" --include=*.py <项目目录>
```

典型陷阱：状态由**单一计数器**驱动。比如 `failed` 为 1 就让整轮 PARTIAL，而 `blocked` / `permanent_rejected` 几十条却仍是 SUCCESS —— 因为后者是设计内的内容过滤。

**归因顺序**：先看这个字段是哪个脚本产的，再查那个脚本；不要因为某个服务名字最眼熟就先查它。

### 已确认的一例：媒体=PARTIAL

「媒体」不是 `lemon-vps-sync` 的健康检查，由 `automation-observations.py` 汇总三个子项。PARTIAL 来自 `scheduled_sync_and_clean.py` 的 `finish()`，**只由 `stats['failed']` 和 `cleanup_error` 决定**：

```python
if stats['failed'] or stats.get('cleanup_error'):
    return finish('PARTIAL' if pushed_count else 'FAILED')
```

所以单条 `urlopen error _ssl.c:999: The handshake operation timed out` 就足以让整轮 PARTIAL。worker 细节见 `lemon-vps-sync-ops`。

**归因到具体那一条**：读 `cron.log` 里的 `MEDIA_SYNC_RESULT` 分桶行，只有 `failed` 算真失败；
`blocked` / `permanent_rejected` / `provider_353_pending` 是内容审核，设计内。实测 2026-11-08 那轮
`failed=1` 来自单条 magnet 解析失败（`Magnet intake rejected: torrent_resolution_failed`），
`provider_353_pending=1` 是另一部片的违规重试 —— 两者编号不同，不是双计数。
`media-pipeline` 的 `exit=2` 就是 PARTIAL 的业务退出码。判据细节见 `references/known-noise-catalog.md`。

## 二、退出码语义表

| 退出码 | 常见来源 | 真实含义 |
|---|---|---|
| 0 | 全部 | 成功 |
| 2 | media-pipeline / delayed-clean | **业务语义**：PARTIAL 或 ACTION_REQUIRED（有待人工决定的候选），不是崩溃 |
| 2 | 带 `set -euo pipefail` 的 bash 备份脚本 | **静默失败**：多半是 `ls`/`grep` 找不到匹配（`ls` 无匹配回 2），`set -e` 让脚本一个字不输出就退出。日志只有一行 `FAILED rc=2` 时优先怀疑这个 |
| 75 | 带 ProcessLock 的 job | SKIPPED_LOCK，锁被常驻任务占着 |
| 21 | 带 preflight 的 oneshot | 每轮 preflight 失败，不是崩溃循环 |

判定 "failed" 先看 `Result: exit-code` 和第一条错误行，别只看 `systemctl status` 的 active/failed 字样。

### 静默 rc 的取证套路（实测于 unified-backup 2026-11-07）

`job.log` 里只有 `FAILED rc=2`、前后都没有错误行时，别去猜磁盘/权限：

1. 从同一份备份归档里取出**当时的脚本版本**做对比，而不是看现在的文件
   （`tar xzf backups/unified/<成功快照>/configs.tar.gz -C /tmp/x hermes-jobs/<script>.sh`）
2. `diff` 出失败后追加的那段——修复者的注释往往已经写明根因
3. 本机复现那一行，确认退出码一致：
   `bash -c 'set -euo pipefail; ls -d /path/that/matches/nothing; echo unreached'` → 输出为空、rc=2，即坐实

对策：给 `set -e` 脚本加 `trap 'rc=$?; echo "FAILED: rc=$rc at line $LINENO" >&2' ERR`，
之后同类错误能自证行号。验证方式是把脚本复制到临时目录、把某一环换成 `false &&`，
确认 stderr 出现带行号的 FAILED 行（别在生产脚本上注入故障）。

## 三、采集缺口先证伪，再采信

缺口列表里每一条都是采集器的一个判断，判断本身可能是错的：

1. 缺口说"保留不足 24 小时" → 上机实测最早记录时间
2. 缺口说"窗口无日志" → 确认该 unit 是否真在这个窗口有活动
3. 缺口说"日志截断" → 看是不是采集端 `-n` 行数上限，不是源端丢日志

实测与缺口矛盾时，**修采集器，不要改结论去迁就缺口**。`journalctl` 保留期判断有一个版本相关的坑，见 `references/journalctl-retention-check.md`。

## 四、改采集器后必须重跑对比

不能只 `py_compile` 就报成功。改完立刻用**上一期完全相同的窗口**在临时目录重跑，与当期报告逐条对照：

```bash
# ⚠️ 别读 latest/ —— 见本节末尾的坑
D=/home/ubuntu/hermes-jobs/jobs/error-digest-$(date -d yesterday +%F)
S=$(python3 -c "import json;print(json.load(open('$D/error-digest.json'))['start'])")
E=$(python3 -c "import json;print(json.load(open('$D/error-digest.json'))['end'])")

HERMES_JOB_DIR=/tmp/dg-dry python3 digest.py --start "$S" --end "$E"   # 不出报告外发
diff <(sed -n '/采集缺口/,/重复日志/p' /tmp/dg-dry/error-digest.txt) \
     <(sed -n '/采集缺口/,/重复日志/p' "$D/error-digest.txt")
```

验收标准四条：

1. 目标缺口消失
2. **其他缺口没有跟着消失** —— 防止把判断改成恒真/恒假。若某主机确实保留不足，改完它必须仍然报
3. `未匹配到错误的采集项` / `有错误来源` 两个计数不变
4. 连跑两轮结果一致，才算稳定

- **`error-digest/latest/` 可能是陈的，别拿它判当期。** `latest/` 只在 `HERMES_JOB_DIR` 未设置时才被写；
  cron 走 `run-daily.sh` 时结果落在 `/home/ubuntu/hermes-jobs/jobs/error-digest-YYYY-MM-DD/`。
  实测 `latest/` 停在 11-02，直接读会把半个月前的窗口当今天分析（本次真实踩中）。
  **永远先 `ls -1t jobs/ | head -1` 找当期目录，再用 `error-digest.json` 的 `start`/`end` 换算成北京
  窗口自证**（`datetime.fromtimestamp(..., tz=+8)`），确认窗口确实是 06:30→06:30 再开口。

## 五、已知噪音源

速查（每条都实测确认过"看着像故障、实际不是"，判据见 `references/known-noise-catalog.md`）：

- 探针超时但端点实测 200 → 阈值过紧 + 链路抖动
- 业务状态写 `SUCCESS` 但当天定时那次是 `FAILED` → 手工补跑覆盖了状态文件。`jobs/<name>/status` 是**单值**，
  每次运行覆盖，`automation-observations.py` 只读最终值，所以日报天然看不到定时失败。
  判据：`grep -E '\] (START|SUCCESS|FAILED|INTERRUPTED) ' jobs/<name>/job.log | tail -10` 看轮次配对，
  再核脚本 mtime 是否正好夹在失败与成功之间（「失败→改脚本→人工重跑」指纹）。详见 `references/known-noise-catalog.md`。
- 云沙箱 `platform=suspended` + ssh 被远端断开 → 休眠重连，设计内
- 容器短窗口内集中报同一上游错误 → 上游抖动，看时间分布别只看总数
- 常驻任务持锁导致 final job 长期 SKIPPED_LOCK → 看常驻任务本身是否正常，别追 final
- `aws/Hermes 业务失败` 含 `no_healthy_account 503` → CPA/腾白嫖账号池短暂耗尽，Hermes 自动重试后回退到下一 provider；看时间分布，几分钟窗口集中 = 一过性，无持续影响
- `aws/Hermes 业务失败` 含 `Refusing background curator patch for pinned skill / not curator-managed` → 后台 curator 被工具安全层拦截，不是代码错误；目标技能无法自动维护（可手动 `hermes curator adopt <name>` 转让）
- `媒体转存及EMOS 超时 95` 这类大数字，先 `grep` 实际行数再判定。实测该来源 95 条「超时」全库只匹配到 **8 行**，且全是 `[INFO] 下载/续传 msg=N cached=… timeout=Ns reserve=NGiB` 与 `[INFO] 上传预算 msg=N timeout=Ns` —— **`timeout=` 是预算字段名，不是错误**。判据：`grep -ciE 'timeout|超时'` 得行数，再看命中行的 `[INFO]/[ERROR]` 级别；INFO 级带 `timeout=Ns` 的一律是设计内预算日志。同类陷阱：采集器用关键词 `timeout` 做匹配，就会把「参数名叫 timeout」的日志全算成超时。
- `vps-la/容器/lemon-emos-proxy` 两百多条 `业务失败`/`鉴权或权限` → 实测 24h 共 1302 个请求，其中 **206 个 404 全是 `/emby/Items/{vl,ve}-N/Images/Primary`**（客户端要库内不存在的海报/Logo），**31 个 403 全是 `vb-*` 条目**（`upstream_status=403 request_time=0.2`，上游自己拒的成人库内容），另 2 个 429。错误率 3% 量级、时间均匀铺开 → 客户端与内容侧，不是代理故障。判据：`docker logs --since 24h <c> | grep -oE '" (2|3|4|5)[0-9][0-9] ' | sort | uniq -c | sort -rn` 算状态码分布，再用**总请求数当分母**；只有某个码段占比异常高才继续查。别看见 404/403 数量大就当服务坏了 —— 4xx 是客户端语义，5xx 才是服务端。详见 `references/known-noise-catalog.md`。
- `aws/代理入口与监控` 里几十条（本次 74/76）`dial tcp 127.0.0.1:<port>: connect: connection refused`，且 `"host"` 字段全指向同一个域名 → **反代配置里留着已退役后端的 site block**。判据三步：`ss -ltnp | grep <port>` 无监听 → `curl` 该域返回 502 → `grep -n <port> /etc/caddy/Caddyfile` 命中一条 `reverse_proxy`。处置是删 site block（生产配置变更，先给结论再问）。**别把这些条数当 caddy 的故障去查 caddy 日志格式。**
- `vps-la/容器/happy-capy-web` 几十条 → 实测 31 条 `[error]` **全是 nginx `limiting connections by zone "client"`**，
  同一 IP 一秒内连打 6 个 `POST /v1/chat/completions`，同窗口 0 条 upstream 5xx → **限流按设计工作**。
  要问用户的是「这个 IP 是不是你自己的客户端」，不是「服务是不是坏了」。详见 `references/known-noise-catalog.md`。
- `aws/Hermes错误文件` 一百多条 → 该来源是 `~/.hermes/logs/errors.log`，**大头是自噪**：
  `agent.tool_executor` / `tools.registry` 的工具报错（agent 自己排查时产生的）、
  `Refusing background curator patch`（pinned skill 拦截）、Telegram `sticky fallback IP` 重连。
  先按模块名分桶剔除自噪，再看剩下什么；它与 `aws/Hermes`（journal）会重复计同一批事件。详见 `references/known-noise-catalog.md`。
- `vps-la/lemon-xray` 的 `业务失败`（本次 120 条：78 `error` + 22 `rejected`）多为**外部扫描器敲 443**：`http: TLS handshake error from <ip>: tls: client offered only unsupported versions: [302 301]`、`no key exchanges supported by both client and server`、`client sent an HTTP request to an HTTPS server`。判据：尾部 `accepted tcp:... [socks-... >> direct]` 持续正常转发 → 服务健康，噪音在扫描器侧。
- `unified-backup-daily FAILED` 且 traceback 是 `ValueError: Snapshot file missing or symlinked` / `Matching Hermes snapshot is missing` → **根因在同日 `hermes-<YYYYMMDD>_*` 快照，不在 unified 本身**。统一备份第 6 步要拼接当天 hermes 快照，该目录残缺（常见：tar 因 root 属主文件失败，只写出数据文件、缺 manifest/policy/model_proxy）就整轮失败。第二坑：手动重跑若发生在当天 11:00 的 hermes 备份之前，会报 `Matching Hermes snapshot is missing` —— 那是时序依赖，先补跑上游再重跑下游。完整机制见 `backup-chain-audit` §10.8–10.11（该技能已 pin，只读参考）。
- `⚠️ Hermes任务最新状态失败：<job_id>` 可能是**历史失败尚未被下一轮覆盖**。实测该 job 每日 11:00 跑，修复发生在 14:00 之后，报告仍显示前一天的 `failed`。判据：`executions.db` 里该 `job_id` 最新一条的 `started_at` 是否早于修复时间；是则等下一轮，别重复修。手动补跑成功不等于状态文件已刷新。
  两段查询（只读，实测可用）：
  ```bash
  python3 -c "
  import sqlite3
  c=sqlite3.connect('/home/ubuntu/.hermes/cron/executions.db')
  for r in c.execute(\"select job_id,source,status,started_at,substr(error,1,200) from executions where job_id like '9b12946%' order by rowid desc limit 5\"): print(r)"
  python3 -c "
  import json;d=json.load(open('/home/ubuntu/.hermes/cron/jobs.json'))
  for j in (d if isinstance(d,list) else d.get('jobs',[])):
      if j.get('id')=='9b12946da1d3': print(j['name'],'|',j.get('script'),'|',j.get('schedule_display'),'|',j.get('last_error'))"
  ```
  `id` 是 executions 表主键，`job_id` 才是 job 标识；先按 `job_id` 查历史，再用 `jobs.json` 换出人话名字与脚本路径。
  **真正的原因行通常不在 `last_error`（只有一句 `FAILED: ...`），在脚本自己的 `<job-dir>/error.log` 或 `status`。**
- Komari `Ping task failed: context deadline exceeded` → **持续型噪音，不是一过性**。改 DNS 只能压掉一部分；残余每期稳定 40 条上下，集中在固定低峰时段（UTC 19–23 / BJ 03:00–07:00），是国际链路抖动 + 探针 client 默认超时偏紧。判据：从本机 `curl` 该 target 得 200 + 亚秒 → 服务健康，噪音在探针侧。Komari `ping_tasks` 表无 timeout 字段，改不了阈值，调频率（60s→120s）是唯一手段，收益不值，**建议不动**。
- 上游 LLM 节点失败率 37–40% 但 fallback 全兜住（`antigravity_gemini`）→ 用户无感，但要在结论里给出失败率数字和节点名，让用户自己判断要不要降位；不要一句「已有兜底，无需处理」带过。**归因前必须做并发对照实验**，见 `references/llm-node-failure-isolation.md` 与 `scripts/llm_concurrency_probe.py`：实测该节点并发 >2 即挂起不响应（**不是** 429/503，所以网关日志里看不到），而同一 CPA、同一时刻的 `cpa_gpt6_luna` 并发 8 全过 → 上游并发限流。~~早期写成「TLS handshake timeout / EOF」是错的~~，那 4 条是 CPA journal 里另一批记录，与群霸的失败无关。
- 巡检 `❌ 服务未运行: <svc>` 后 1–2 分钟跟一条 `✅ 保护链路异常已恢复` → **同一次重启的上下半段，不是两次故障**。判据：`ActiveEnterTimestamp` 与 ❌ 时间差 <3 秒、`NRestarts=0`、journal 有 `Application is stopping` → 主动 `systemctl restart`，不是崩溃。同时要单独核算真实停机时长（stop→start 的间隔），巡检 2 分钟取样窗口会漏掉小时级空转。详见 `references/service-restart-window-triage.md`。
- `unable to open database file` 报在 `PRAGMA journal_mode=WAL`、多 PID 同时报、集中在重启前后 → SQLite WAL 短连接 unlink 竞态，**数据无损**，是日志噪音。先跑 `PRAGMA integrity_check` 确认全部 ok，再决定要不要压。audit 里 `DELETE -wal/-shm` 的 `pid` 若等于服务自己的 MainPID，那是正常关闭，不是外部破坏。详见 `references/service-restart-window-triage.md`。

## 六、Python 库版本兼容 bug 归因（certificate-deploy 类故障）

`certificate-deploy` 长期 FAILED (exit 1) 实例：脚本调 `x509.not_valid_after_utc`，系统 `cryptography` 是 38.0.4（该属性 42+ 才引入），报 `AttributeError: 'builtins.Certificate' object has no attribute 'not_valid_after_utc'. Did you mean: 'not_valid_after'?`。

归因步骤：
1. 看 `capy-acme.log` 最后几行（traceback 会明说哪行哪属性）
2. `python3 -c "import cryptography; print(cryptography.__version__)"` 确认库版本
3. 对比错误属性的引入版本（`not_valid_after_utc` 是 cryptography 42 引入的）
4. 修法：`getattr(obj, 'not_valid_after_utc', None) or obj.not_valid_after.replace(tzinfo=utc)` 向下兼容

**证书是否真的需要续期独立验证**：`python3 -c "from cryptography import x509; import pathlib; c=x509.load_pem_x509_certificate(pathlib.Path('/path/to/fullchain.pem').read_bytes()); print(c.not_valid_after)"` 直接读，绕开脚本。到期前 30 天才需要续期，脚本 crash 不等于证书失效。

### 这类故障怎么被发现：扫状态文件的 last_success_at 缺口

它几乎不会出现在错误条数排名里——脚本抛异常直接退出，日志只有一次 Traceback，条数为 0。必须主动扫：

```bash
python3 -c "
import json,glob,os
for f in sorted(glob.glob('/home/ubuntu/.local/state/automation-cron/*.json')):
    n=os.path.basename(f).replace('.json','')
    d=json.load(open(f))
    print(f'{n:22} {d.get(\"status\"):8} exit={d.get(\"exit_code\")} last_ok={str(d.get(\"last_success_at\"))[:19]}')
"
```

判据：`status=FAILED` **且** `last_success_at` 是几天前 → 持续故障，必须修；`last_success_at` 是上一轮 → 单次失败，看下轮是否自愈。

修完复验要跑 crontab 里的**完整命令**（含 `cron-status.py <job> --` 包装层），不是只跑内层脚本。验收标准是 `exit=0` **且** 状态文件 `last_success_at` 被刷新，两条都满足才算修好。

跨机部署验收、端口握手陷阱、业务层分类问题详见 `references/certificate-automation-failures.md`。

## Pitfalls

- **把日报里的 `aws/` 当成一台独立的 AWS 机器。** 它**就是本机**（naye），没有第五台。
  证据链：`digest.py` 里 `data['hosts'].append(collect('aws', start, end))` 是**本地调用、不带 SSH**；
  `SOURCES['aws']` 列的单元全是本机的（`hermes-gateway`、`hermes-web-ui`、`cliproxyapi`、
  `lemon-group-bot(2)`、`lemon-userbot`、`subinfo-bot`、`caddy`、`komari-agent`、`redis-server`）；
  `vps-healthcheck.sh` 的 `check_local()` 打的标签也是 `[aws]`；域名 `aws.` / `<YOUR_PRIVATE_DOMAIN>`
  指向本机公网 IP。名字纯属历史遗留 —— 实测本机 IP 归属 **Leaseweb 新加坡 AS59253，不在 AWS 网段**。
  被问「有没有第五台」时别凭印象答：拉 CF 区全部 A 记录，比对已知 IP 集合即可定论。
  顺带：`ec2.` 域名指向本机却无对应服务（历史返回 525），是死记录。
- **拿总条数排名当故障排名。** 要按时间分布看：10 秒内 20 条是一次抖动，均匀铺满 24 小时才是持续问题。
- **把"窗口无日志"当零故障。** 日报自己写了不能据此判断正常，尤其跨机中转、后台任务终态这类只在有请求时才出日志的链路。
- **看到 PARTIAL 就去查最眼熟的服务。** 先看状态字段是哪个脚本产的，再定位。
- **只降应用日志级别来治 journal 保留问题。** 要同时看容量上限和其他来源 —— `sshd` / `systemd-logind` / `sudo` 往往才是大头，应用日志可能只占一小部分。先按 ident 统计占比再决定改哪。
  **头号隐形大户是内核审计**：`auditd` / `audit` 两小时可达 55 万行、占 journal 99%，把 512M 上限瞬间填满，业务日志只剩几小时。判据是 `_TRANSPORT` 为 `audit` 或 `syslog`、ident 为 `audit` / `audispd`。治理路径（三处开关 + 四个坑）见 `linux-log-retention-ops`。
- **把「日志里没有」当成「事情没发生」。** 下否定结论前先量保留窗口：`journalctl --no-pager | head -1` 看最早记录、`journalctl --disk-usage` 看占用。窗口只有几小时时只能说「窗口外无证据」。窗口异常短几乎总是有来源在刷屏，不是正常现象。
- **改采集器只验证"目标缺口消失"。** 不验证"该报的还报"，会造出沉默的监控。
- **在业务层放宽判定条件来让日报变绿。** 失败就该报；降噪在日报层做，不在业务层掩盖。
- **同一事件被两个计数器重复计入。** 典型：`provider_353`（内容审核拒绝）同时 `stats['failed'] += 1` 和 `stats['provider_353_pending'] += 1`，于是每天都因一条审核拒绝而 PARTIAL。判断标准是「这条计数有没有独立的语义桶」——有，就不该再进 `failed`。修完必须同步改单测里 `assertEqual(first['failed'], 1)` 这类断言，否则测试会替旧语义站台。改前先跑 `python3 -m unittest <module>` 确认只有目标断言失败、其余全过，避免掩盖真实回归。
- **把脚本打印的成功当部署成功。** 跨机部署（签发 → scp → 容器 reload）任一跳静默失败仍可能打印 `deployed and reloaded`。必须验远端文件 mtime + 到期时间 + 容器内是否同步，三步都要。
- **「备份目录有数据文件」不等于这份备份能用。** 实测 `tar czf` 在打包中途因**一个 root 属主文件**返回 1，脚本 `|| error` 直接中止，于是 manifest / policy / model_proxy / recovery_support 全都没生成，只剩早先写好的 `state.db` 等 5 个文件 —— 目录看着有 440 MB，**实际不是恢复点**。判据按脚本版本分层，别把历史结论当常量：① 先对齐当前脚本 —— `grep -n 'MANIFEST\|POLICY' <备份脚本>`，脚本里不写这两个名字就别去找。实测 2026-11-08 新版 `unified-backup` 快照目录布局就是 `configs.tar.gz` / `host-support.tar.gz` / `SHA256SUMS` / `state.db` / `tar-warnings.log` 五项，**本来就没有** `SNAPSHOT_MANIFEST.json` / `BACKUP_POLICY.json`（旧版才有），拿旧判据去查会把健康备份判成「残废」——本条旧结论已被实测推翻。② 真正的完整性证据在 `job.log` 末尾那行自校验 JSON：`files_verified` / `databases_verified` / `nested_archives_verified`（含 `gzip_integrity: ok`、`members`、`online_databases_restored`）/ `ciphertext_sha256` / `retention.files`。这些都在且 `6/6 SUCCESS rc=0` = 这一轮真验过，可以报 SUCCESS；`tar-warnings.log` 为空是正面证据。
  ```bash
  find ~/.hermes ~/.config -not -user "$USER" -not -path '*/node_modules/*'
  ```
  修 `<`一次不算闭环：必须把 `chown` 写成备份脚本里的自愈函数（保持在 tar 之前、修不动仍要报错退出），再加下游前置门禁，并做**故障注入验证**（造 root 0600 探针 → 不带补丁的 tar 复现 `rc=2` → 补丁版断言自愈生效）。见 `references/closure-and-alert-legibility.md`。
- **校验器报错「一句话、无细节」时，先怀疑兜底 `except` 把所有原因吞了。** 实测校验脚本用 `except (OSError, ValueError, ...): append('元数据无效')` 包住整段，把 `missing_critical_files` / `incomplete_snapshot_manifest` 等具体判断全吞掉，用户只能反问「到底怎么了」。修法：把内部 `raise ValueError(...)` 改成**就地写具体 problem 并 `return`**，兜底只留真无法分类的异常；文案要带「缺哪个文件、目录里实际有什么、去哪儿看日志」。
- **TLS 握手成功就以为站点存在。** `openssl s_client` 握手成功、能拿到证书，`curl` 却返回 `HTTP=000` —— 那是反代完成了握手但**没有该域名的 site block**。先 `grep` 反代配置，别先怀疑证书或防火墙。
- **只看 FAILED 条数，不看 `last_success_at`。** 一个 cron 连续 FAILED 好几天，日志条数可能接近 0；持续故障的判据是 `last_success_at` 停在几天前，不是当日错误条数。
- **把「服务端判定文件违规」当网络失败重试。** 上游内容审核拒绝重试必然过不了，应归终态拒绝；但改分类属业务判定层，须用户明确同意，不能在日报层掩盖。
- **把 A 日志流的条数安到 B 来源的失败上。** 日报说「群霸 54 条」，你去某服务 journal 查到几条 TLS 超时，就当成同一批事件归因 —— 实测是两回事：群霸记的是 `http_status=400`（0.8s 快速拒绝）和 `http_status=None`（33s 预算耗尽），与 CPA journal 那 4 条 TLS 超时**毫无关系**。核对方法：**① 时间戳对齐；② 比状态码 / `error_category` 字段构成**。两批记录的状态码构成不同，就是两个独立故障，必须分开归因、分开计数。同名上游 ≠ 同一条日志流；日报来源名与本地 unit 也不是一对一（如 `aws/群霸1` → `lemon-group-bot.service`），映射见 `references/llm-node-failure-isolation.md`。
  **unit 名有坑**：`群霸2` 是 `lemon-group-bot2.service`（**没有**第二个连字符），写 `lemon-group-bot-2` 会查不到任何东西，
  然后被误判成「这个 Bot 没日志 = 没故障」。查不到时先 `systemctl list-units --all | grep -i <关键词>` 确认真名。
- **用 `-p warning..err` 查不到就断定没错误。** 日报统计的常常是 INFO 级结构化字段（`outcome=failed` / `outcome=timed_out`），不是 journal priority。要按字段 grep，别按优先级过滤。
- **把「日志里没错误」当成「没发生故障」。** 上游并发限流的表现是**挂起不响应**，不是 429/503，所以网关侧一行错误都不会有。反向判据：客户端 `timed_out` 的 `node_elapsed_s` 整齐等于 `node_budget_s` → 上游挂起，不是客户端逻辑问题。
- **采信日报顶部的「统一备份=SUCCESS」。** 这个字段来自 job 状态文件，而 **job 退出 0 不等于产物还在**。
  本次实测：Hermes 自身 backup job 从 10-30 到 11-05 **每天 `completed`**，而
  `~/.hermes/backups/hermes-[0-9]*` 目录数为 **0**；统一备份 `unified/` 中间 **7 天零快照**。
  真因埋在 `job.log` 末尾一行 `LA storage reserve gate: upload would leave less than 5 GiB free`
  —— 远端磁盘预留门禁拒收，`set -euo pipefail` 让整链 FAILED、prune 不执行，**全程零告警**。
  判据：`status` 文件只作线索，必须 `ls` 产物 + 核对最新快照时间落在 N 小时内。同理
  `recovered_by=verified-repair-*` 是事后手工改写，不代表自动链路跑通。
  **门禁公式**：`free > N GiB + encrypted_size`（实测 N=5），差 0.04 GiB 也拒收；修法顺序
  ①调阈值 → ②清远端占用 → ③删旧异地包（放最后，脚本自带 retention 会自己删）。
  改阈值必须**同步改远端 `assert` 的数值和本地匹配用的错误字符串**，只改一处会退化成
  `Remote backup operation failed` 的模糊报错。验收看阶段号走完（`6/6 SUCCESS rc=0`），
  不是 `rc=0`。另见 `references/backup-gap-and-capacity-triage.md`。
- **只核对"备份是否新鲜"，不核对"多久能发现它不新鲜"。** 检测能力本身有窗口：
  **最坏发现时间 = 检查间隔 + 过期阈值**。实测 `backup-verify` 每天 1 次 + `MAX_AGE_HOURS=30`
  → 事故 18:57 发生，次日 12:21 检查时 age 才 17 小时，**照样 PASS**，最坏 54 小时才发现。
  日备场景应满足 `threshold < 2 × interval`；修法是缩短间隔 + 收紧阈值（已改 6 小时一查 + 26h）。
  巡检"绿"只证明取样那一刻，不证明两次取样之间没断。
- **日报只覆盖它采集的那几条链，第 N 条链坏了根本不会出现在日报里。** 实测本机同时有**三条**互不相干的备份链：  ① `unified-backup-daily`（日报有源：`aws/系统统一备份`）；② `backup_hermes.sh` 每日 CMS 分片；
  ③ `naye-protection-backup.timer` 每小时推 restic 到远端 rest-server（**日报里没有任何源**）。
  第 ③ 条断掉时用户是**直接在 Telegram 收到独立告警**的，而日报照旧全绿 —— 前一天刚按日报结论说"备份已恢复"，
  第二天用户就拿截图来问。所以：
  - 用户拿告警截图来问时，**别再翻日报**，直接 `grep -rl "<截图里的原句>" /home/ubuntu --include=*.py --include=*.sh`；
    本地搜不到就 `systemctl list-timers --all | grep -iE 'protect|backup'` —— 发送方在 systemd 单元或远端，不在采集范围里。
  - 周期性备份的新鲜度告警，阈值通常写死在配套脚本里（实测 `if age>4500` → 75 分钟），
    **根因在配套的 backup 单元而不是 health 脚本**：`systemctl show <backup> -p ExecMainStatus`（`1` = 失败），
    再读 `<state-dir>/last-backup.log`（journal 常常是空的，脚本自己写文件日志）。
  - restic 报 `507 Insufficient Storage` 是**服务端 rest-server 的 `--max-size` 配额**，与本地 `df` 无关；
    完整排查链与"提配额只止血、必须有 prune"的结构性缺口见 `selfhosted-service-audit` §7.2-b/7.2-c。
  - 回答"备份正常吗"之前，把三条链都列出来逐条看退出码。**结论由最弱的那条链决定。**
- **修完一个疑似根因就宣布解决。** 探针超时曾归因 DNS 丢包，改 `resolv.conf` 后条数确实降了一部分，下一期同源仍有 40+ 条。判定方法：①服务端从本机实测健康（200 + 亚秒）；②失败集中在固定时段而非均匀铺满全天 → 链路问题，不是本机配置。**改完必须等下一期同源条数对比才能结案**，不能凭「改完当场实测正常」就报解决。归因不完整要直接认，不要把错判断留在技能或结论里。
- **改完 DNS/网络配置不复验延迟。** 给服务加 CF 代理、换 DNS、加反代这类变更，除了看通不通，还要量延迟有没有劣化（同一接口连测 8 次取中位数，和直连源站对比）。通了但慢了同样是事故。
- **把 `❌ 未运行` 和随后的 `✅ 已恢复` 写成两次故障。** 先对齐秒级时间：`ActiveEnterTimestamp` 落在两次告警之间、`NRestarts=0`、有优雅 stopping → 一次重启的上下半段。报成两次会虚增故障数，也会让人去查不存在的"自愈机制"。
- **看到 audit 里 DELETE `-wal`/`-shm` 就断定有人在破坏数据库。** 必须先核对 `pid`：等于服务自己的 MainPID（`ppid=1`）就是 SQLite 正常关闭行为，不是外部清理脚本。只看 `key="..._data_delete"` 或 `comm="python3"` 不够，DB 所有者本身也是 python。误判的代价是把正常行为写成"自伤"，结论方向完全反了。
- **用巡检"已恢复"代替停机时长核算。** 巡检按分钟取样，只能证明取样那一刻。`stop` 到下一次 `start` 的间隔要自己从 journal 算，实测抓到过巡检全程未报的 2 小时 44 分空转。
- **用 `uptime` / `last reboot` 或 syslog 断定重启次数。** 三者在事故后都可能失真，唯一权威判据是
  `journalctl --list-boots`。本次实测：`uptime` 与 `last reboot` 都说 11-04 18:57 启动，但 syslog 里
  有一条 `2026-11-05T07:01:07 ... [ 0.000000] Linux version 6.1.0-54` 的内核启动行，看起来像"又重启
  了一次"。**`[ 0.000000]` 不能证明重启** —— rsyslog 服务重启时会把 kernel ring buffer 重新 dump 一遍，
  时间戳是当时、内容是历史。`--list-boots` 显示全程只有 2 个 boot，前一个 16 分钟、后一个连续至今。
  同理 `wtmp` 可能被复原操作覆盖，`uptime` 会跟着撒谎。
- **把 job 状态文件里的 UTC 时间戳当北京时间算。** `~/.local/state/automation-cron/*.json` 的
  `started_at` / `ended_at` / `last_success_at` 带 `+00:00`，直接读会差 8 小时。实测把
  `delayed-clean` 的 `started_at=2026-11-07T21:00:01+00:00` 读成「从 11-07 21:00 跑到现在已 11 小时」，
  实际是 BJ 11-08 05:00，才 3 小时，判据整个反了。**先看有没有 `+00:00`，有就换算再下结论**；
  更稳的是拿 `date '+%F %T %Z'` 取当前时间，用代码算差，别心算。
- **job.log 里同一天既有 FAILED 又有 SUCCESS 时，按最后一次 `START` 分段读，别拿早先那轮的 FAILED 当现状。**
  实测 `unified-backup` 11-07 有两轮：11:30 那轮 `FAILED rc=2`（脚本自身 bug：`ls -dt "$ROOT"/hermes-*`
  写成 unified 目录而非父目录，配 `set -euo pipefail` 静默退出 2），脚本 **11:33:02 被修正**，
  11:33:21 重跑走完 6/6、`SUCCESS rc=0`、异地包校验通过 —— 此时状态文件 `SUCCESS` 是真的。
  判据：`grep -n "START\|FAILED\|SUCCESS rc" job.log | tail -6` 看清轮次边界，再看脚本 mtime 是否夹在两轮之间；
  脚本改过 + 后一轮成功 → 结论是「已修复」，不是「状态文件撒谎」。**这条是「别采信 SUCCESS」的反面，
  两条都要用：既不能只信状态文件，也不能因为历史 FAILED 就否定当前 SUCCESS。**

- **把"日志从这里开始"当成"系统从这里开始"。** 日志起点往往是**日志被清的时间**，不是机器启动时间。
  判定顺序：`--list-boots` 取真实 boot 边界 → `/var/log/installer` mtime 与 `/etc/machine-id` mtime
  判断是否重装（installer 停在旧年份 = 没重装，只是日志没了）→ 备份/配置目录的 mtime 聚集时刻 =
  人工复原动作时间。完整取证路径见 `references/machine-wipe-forensics.md`。

- **脚本里 `set -euo pipefail` 遇上命令替换失败 = 无消息的 `rc=2`，日志里一行错误都没有。**
  实测 `HERMES_SNAP="$(ls -dt "$ROOT"/hermes-* 2>/dev/null | head -1)"` 里 `$ROOT` 多了一层目录：
  `ls` 返回 2 → `pipefail` 传播 2 → `set -e` 直接退出。job.log 特征：`5/6` 之后**既没有 `6/6`
  也没有任何 `FAILED:` 文本**，直接 `FAILED rc=2`。
  **复原方法：从同期备份包里的旧版脚本 diff 当前版本**，差异就是那次的补丁——比读日志推断可靠：
  ```bash
  tar xzf <old-snap>/configs.tar.gz -C /tmp/cmp path/to/script.sh
  diff /tmp/cmp/path/to/script.sh <current>
  ```
  修法两条同时上：`|| true` 兜住命令替换，**再给脚本加一行
  `trap 'echo "FAILED: line $LINENO rc=$?" >&2' ERR`**，下次同类错误自证。
  没有这行，任何新的静默退出都得靠 diff 考古。详见 `backup-chain-audit` §10.11。

- **改生产配置前先采基线，否则「没影响别的」这句话无据。** 改反代之前把该配置里**所有**
  upstream 探一遍存下来（`grep -oE 'reverse_proxy [0-9a-zA-Z._:]+'` 提取后逐个 `curl -o /dev/null -w '%{http_code}'`），
  再记几个不相关站点的当前状态码。改完逐条对比才能说「其它站未受影响」；
  否则只是改完随手 curl 一次，等于没核。
  顺带：配置里 `0644` 却塞着会话 cookie / 凭据的，本身就是额外暴露面，改这块时一并收紧或删掉退役段。

- **`admin off` 的反代只能 `restart` 不能 `reload`**（约 3 秒全站中断）。改之前备份成
  带时间戳的 `<cfg>.bak-<用途>-<ts>`（目录里已有历史备份就沿用命名习惯），并在同一批操作里写清回滚文件名。

- **`grep -icE 'ERROR'` 会把 INFO 级的 `error_category=None` 算成错误，计数直接虚高。** 实测群霸
  journal 里每条成功日志都带 `error_category=None`，`grep -icE 'ERROR'` 得 31 条，真实失败只有 3 条。
  正确统计只按字段值：`grep -oE 'outcome=(failed|timed_out|succeeded)' | sort | uniq -c`。
  同一坑的变体：`grep -i error` 命中 `error_category`、`error_rate`、`on_error` 这类字段名。
  **统计前先看一条正常日志长什么样，确认你的模式不会命中正常行。**
- **`aws/Hermes错误文件` 不是故障清单，它大头是自噪。** 该来源 = `~/.hermes/logs/errors.log`，
  实测 148 条里 138 是 WARNING：34 条是 agent 自己的诊断命令报错（`agent.tool_executor` /
  `tools.registry: Tool … returned error`）、14 条 `Refusing background curator patch`、
  37 条 Telegram 出网抖动（`sticky fallback IP <YOUR_SERVER_IP>`、`Bad Gateway` 重连）。
  判据：按模块名先分桶再判性质 ——
  ```bash
  grep -oE '[a-z_]+(\.[a-z_]+)+: ' ~/.hermes/logs/errors.log | sort | uniq -c | sort -rn | head
  ```
  `agent.tool_executor` / `tools.registry` / `tools.approval` 全是 agent 自身噪音，剔除后再看剩下什么。
  **别把「我查东西时命令返回非零」写成 Hermes 故障。**
- **在远端主机手工复核「窗口」时忘了那台机器的时区。** `vps-la` / `diaomao` 系统时区是 UTC，
  `ssh vps-la 'journalctl --since "2026-11-15 06:30"'` 实际取的是 **UTC 06:30 = 北京 14:30**，
  整段证据会偏 8 小时、命中完全不同的日志。手工复核必须写成 `--since "2026-11-14 22:30:00" --until "2026-11-15 22:30:00"`
  （= 北京 11-15 06:30 ~ 11-16 06:30），或直接 `TZ=Asia/Shanghai journalctl …`。naye 本机是 CST，别把 UTC 习惯带过去。
- **服务被彻底删除后，采集器里的硬编码清单会天天产假缺口。** 实测 `happy-capy` 六容器 11-13 已按用户要求
  `docker compose down --volumes` + 删目录 + 删 timer，而 `digest.py` 的 `CONTAINERS` 仍列着它们、`SOURCES` 仍列
  `卡皮监控:['happy-capy-watch.service']` → 之后每期固定 6 条「容器状态读取失败」+ 1 条「窗口无日志」。
  判据：`docker ps -a` 全无 + `systemctl list-units --all | grep <关键词>` 全无 + 目录不存在 = 已删除，不是读取故障。
  处置：从 `CONTAINERS` 与 `SOURCES` 移除，然后**用同一窗口 dry-run 对比缺口**：
  `HERMES_JOB_DIR=/tmp/dry python3 digest.py --start <旧start> --end <旧end>`，
  验收三条：目标缺口 0 条、其余缺口仍在、错误来源清单不变。
- **`aws/Hermes`（journal）与 `aws/Hermes错误文件`（errors.log）是两个来源，会重复计同一批事件。**
  映射在 `digest.py` 的 `SOURCES`：`'aws':{'Hermes':['hermes-gateway.service','hermes-web-ui.service']}`
  + 单列的 errors.log。同一条 Telegram 抖动会两边各算一次，报数时必须说明「重复计入」。
- **nginx `limiting connections by zone "client"` 是限流按设计工作，不是服务故障。**
  实测 `happy-capy-web` 24h 31 条全是这个，来源 IP 在同一秒连打 6 个 `POST /v1/chat/completions`，
  同时段 **0 条 upstream 5xx**。判据：`grep -oE 'limiting connections by zone "[a-z]+"|upstream timed out|connect\(\) failed|no live upstreams' | sort | uniq -c`
  —— 只有 `limiting` 一种且无 upstream 错误 → 限流正常。**下一步是自证这个 IP 是谁，不是直接问用户**：
  ```bash
  curl -s https://ipinfo.io/<IP>/json          # 归属 ASN / 城市
  curl -s https://api.ipify.org                # 本机出口
  ssh <其他主机> 'curl -s https://api.ipify.org'  # 各机出口
  ```
  实测该 IP 就是**本机 `aws` 出口**（Leaseweb SG AS59253），24h 仅 31 条、集中在 3 个时刻的批量探测，
  撞的是 `limit_conn client 4` → 自己打自己，非外部攻击、非业务流量，配置不该放宽。
  只有自证后仍属外来 IP，才去问用户「这是不是你的客户端/中转」。别把能自己查清的事推给用户。
- **journal 里 grep 出的「503/404/429」可能是 traceback 行号或时间戳毫秒，不是状态码。** 实测
  `grep -i '503'` 命中 10 条全是 `File "...telegram/_bot.py", line 5032, in delete_webhook`（行号含 503），
  同窗口真实 `no_healthy_account` 为 0。判据：命中行带 `File "..."` / `line N` 一律剔除；
  报数前抽 3 条肉眼确认。详见 `references/known-noise-catalog.md`。
- **高频短周期 job 的「进程退出」要看失败占比，不看绝对条数。** 实测 `ib-keepalive`
  （**user unit**，`systemctl status` 会报 not found，要 `--user` + 对应 `XDG_RUNTIME_DIR`，或直接按
  日期从系统 journal grep）窗口内 428 次 Finished / 仅 4 次 FAILURE，错误全是 DNS 临时
  `No address associated with hostname`，几分钟后自愈 → 一过性，不是崩溃循环。
  判据：`grep -c Finished` 与 `grep -ciE FAILURE` 求比值。详见 `references/known-noise-catalog.md`。
- **服务连续 `Main process exited, code=exited, status=1/FAILURE` 但 `NRestarts` 很小、之后有 200 响应 = 一次重启序列，不是崩溃循环。**
  实测 `workbuddy2api` 一个窗口内 3 次退出（`NRestarts=3`），`ActiveEnterTimestamp` 之后立刻正常出 200。
  判据：`systemctl show <svc> -p NRestarts -p ActiveEnterTimestamp -p ExecMainStatus` +
  看重启后是否有成功业务行。崩溃循环的特征是 `NRestarts` 持续增长且始终没有成功响应。
- **`last_success_at=null` 不必然是持续故障 —— 先确认这个 job 还有没有调度。**
  实测 `media-quota-retry` 的 `last_success_at` 为 `null`、停在 10-21，看着像长期失败；
  实际是那次一次性配额恢复任务的残留状态文件，该 job 已无调度（`crontab`/`jobs.json` 里没有）。
  判据顺序：① `jobs.json` / `crontab -l` 里有没有这个 job；② 状态文件 `ended_at` 是否停在很久以前
  且之后没有新的 `started_at`。无调度 + 状态陈旧 = 历史残留，不是当前故障。
- **「门禁在阈值线上抖动一次」要换算成「明天会不会再失败」，别只报当天。** 实测
  2026-11-17 unified-backup 6/6 阶段 `publish()` 前置门禁被拒：远端 `assert
  shutil.disk_usage(p).free > 4*1024**3 + 包体积`，当时包 960M → 需 5.256 GiB，远端 free
  5.03 GiB。三个关键点：① **报错文案 ≠ 实际阈值**：脚本匹配的错误串写 `less than 5 GiB`，
  断言却是 4 GiB+包体积（与上一条「改阈值须同步改错误字符串」是同一处漂移的旧账，当时是
  5 GiB，后来有人只改了 assert 没改文案），别按文案心算；直接 `sed -n` 读 `publish()` 里的
  assert 原式再复算。② **算一下「传完后剩多少」**：传完 960M 后 free 掉到 ~4.1G，下一天
  门禁仍要 5.26G → 结构性必失败，结论要写「不修则明日持续 FAILED、断档每天 +1」，
  不是「一次性抖动」。③ 失败时 1-5/6 阶段全过、失败包按设计保留在
  `hermes-jobs/tmp/offsite-*/`（含 `.hermesenc` 与 `input-check/`）——**备份本体没坏，
  只是传不出去**，处置方向是清远端磁盘，不是重跑本地备份。
- **面板/服务中心卡片显示「备份一直失败」时，那不是本次点击的结果。** 卡片读的是
  `jobs/<job>/status` 里上一次落盘的状态（昨天异地段 FAILED → 卡片红到下一次成功）。
  排查顺序：①`cat jobs/<job>/status` 看 `ended=` 判断新旧；②`grep -E '\] (START|SUCCESS|FAILED)' job.log | tail -5`
  看本轮有没有真跑过；③锁文件 **mtime 不能当点击证据** —— 探测型脚本（实测 `storage-maintenance.sh`）
  每轮都用 `exec 7>/exec 6>` 短暂打开 `backups/.hermes-backup.lock` 与 `backups/unified/.backup.lock`，
  mtime 跟着它的 cron 点（如 10:46）走；找真实持有者要扫 fd：
  `for p in /proc/[0-9]*; do ls -l $p/fd 2>/dev/null | grep -q '<锁名>' && echo $p; done`；
  ④最快证伪是直接跑 `bash ~/.hermes/scripts/backup_hermes.sh --local-only`，看 `健康门禁通过` +
  四项 `ok` + `LOCAL_BACKUP=` + `RC=0`；⑤顺手给「嫌疑进程」的 RSS/CPU 与不持锁的事实，
  别用口头保证（实测跨境 scp 只占 2.4MB / 0.2%）。**找不到用户那次点击的日志痕迹就如实说
  「没找到对应记录，请给报错原文」，不要编一个原因凑闭环。**
- **job 目录名是 `unified-backup-daily`，不是 `unified-backup`。** 文档其他段落的历史
  记载用短名，但 jobs/ 下真名带 `-daily`；直接猜短名会 `No such file or directory`。
  查不到先 `ls -1t hermes-jobs/jobs/ | head` 看真名，再读 job.log/status。
- **异地备份接收端换机（如 vps-la→aliyun）的既定流程已跑通一次（2026-11-18），复用时按此顺序：**
  ①先读源脚本把拓扑锚死（`REMOTE`/`SSH`/调用方 `phase5-backup-build.sh:119`），确认要改几处；
  ②新接收端 `mkdir -p -m700` 建目录；③旧包迁移**逐段核 sha256**（vps-la→aliyun 直连被
  工具安全拦截时，走「vps-la→naye 拉取→naye→aliyun 推送」两段中转，两段都用已验证密钥，
  每段完成后立刻对两端校验和）；④改脚本所有 `vps-la` 引用（本次 3 处：SSH 常量、scp 上传、
  scp 取回），改前留 `.bak-<用途>-<ts>`，改后 `grep -c vps-la` 归零 + lint；
  ⑤验收**用最近失败留存的真实包**直接调 `publish()` + `prune_remote()`（发布→sha256 校验→
  保留策略生效），不要等下一个调度点才算验收；⑥清理中转目录与失败留存包。
  陷阱两枚：a) 失败留存包在 `hermes-jobs/tmp/offsite-*/` 不在 `/tmp/`；b) `StrictHostKeyChecking=yes`
  要求新 host key 已在 known_hosts（scp 手动传一次即写入）。
  已知事实（**2026-11-18 更新，早期「0.89 MB/s、scp_timeout 够用」的结论已作废**）：
  同一线路速率会在数小时内从 1 MB/s 塌到 **0.25 MB/s**，裸 `scp` 单流（RTT 312ms）在这种
  状态下只有 40–250 KB/s，960M 包两次撞上 1334s 超时（只到 72–97 MB）。**判定方法**：同一时刻
  对两个目的地各传 8 MB 对比 —— 实测 `naye→vps-la` 仍 1 MB/s、`naye→aliyun` 0.25 MB/s
  ⇒ 源机出网正常，是那条国际路径塌了，查源机无收益。
  修法是上传改 `rsync --partial --append-verify`（远端先 `apt-get install -y rsync`），
  超时公式按最慢实测值定 `min(7200, max(1200, size/(0.25MB/s)+300))`，远端 sha256 断言保留兜底。
  另：`kill -STOP` 暂停迁移**不释放带宽**（实测暂停后备份侧仍 43–84 KB/s），必须 `kill -TERM`。
  完整命令与实测数字见 `restic-offsite-repo-ops` → `references/offsite-receiver-migration.md` §5.3。

- **别把「我稍后会暂停迁移」当成已排好的动作。** 实测事故：口头说了在调度点前暂停大文件迁移，
  实际没设任何机制，11:30 定时备份因带宽被占而 scp 超时失败、当天异地包没落地。
  规则：跨调度点的大任务，要么真正落成 `flock`/定时暂停，要么先把它做成**可续传**，
  让「随时被终止」成为安全状态；口头计划不算防护。汇报时也要如实写「这是我上一步没执行到位」，
  不要把失败全推给链路。

## Verification

给出结论时必须区分：实测确认的事实 / 代码推断 / 未能核实项。每条"不是故障"的判断都要附实测证据（HTTP 码、时间分布、上机时间戳），不能只凭"看起来像"。

## 汇报形状

用户要的是判断，不是复述日报。按这个顺序写：

1. **先给结论表**：每项一行，附实测证据（命令输出、时间戳、HTTP 码）。已修好的写清 exit 码和状态文件刷新时间。
2. **再分两栏**：
   - 「**你要做的**」—— 只有需要用户拍板的事，每条说清选项与代价。业务判定层改动、隐私/IP 暴露、不可逆删除都必须放这里。
   - 「**不用你管的**」—— 已处理完的、判定为设计内的、判断为不需要动的（附理由）。
3. **不要**把已修好的事混进"需要你决定"，也不要为了凑数把设计内语义列成待办。

用户多次追问「核验一下」「复验一遍」时，说明上一轮汇报缺实测证据。补救方式是重新上机跑，不是把结论换个说法再讲一遍。

4. **「闭环」有明确定义，不是「修好了一次」。** 用户说「闭环这个问题」时，交付物必须是
   「自愈内嵌进主流程 + 前置门禁防同类失败 + 故障注入验证过」，而不是一条手工命令 + 一次成功运行。
   告警文案必须自带「实际值/阈值 + 最近成功时点 + 真实错误行 + 自查命令」四要素，
   否则用户会反复问「到底发生了什么」——他明确说过「不然我每次都得问你」。
   完整判据、落地代码片段、以及「别在测量方法没验证前就宣布要改核心逻辑」的教训见
   `references/closure-and-alert-legibility.md`。

5. **用户说「给我一个合理的方案」时，方案要可直接执行，不是选项清单。** 每条必须带：
   要改哪个文件的哪几行（贴出当前内容定位）、改完怎么验收（具体命令 + 期望输出）、
   **回滚路径**（`cp` 备份文件名或 git 路径）、以及**改动前的基线采样值**。
   基线要在动手之前采：改反代先存所有 upstream 的当前状态码与其它站点 200/410 结果，
   否则改完「其它站还好的」这句话没有任何依据。
   生产配置改动（Caddyfile / crontab / systemd / 发布闸门）本身仍要用户点头，
   但**取证、复现、基线采样、脚本 diff 复原都可以先做完**——「复验一遍」要的是实证，
   不是把上一轮结论换个说法重讲。
   区分「已修但未验收」和「已验证」：脚本改完但下一个调度点还没到时，只能报前者。
