#!/usr/bin/env python3
"""比较两个 restic 快照之间真实变化的文件（用 content hash，不是 size）。

为什么需要这个：
    `restic ls --json` 的 `size` 字段相同 ≠ 内容相同。只比 size 会漏掉
    「大小不变但内容全变」的文件，从而低估真实增量，进而误判「去重失效」。
    必须比 `content` 字段（内容 blob 的 sha256 列表）。

还有一个坑：`data_added` 在「手工跑 + 紧接 prune」之后不是稳态值
（prune 重打包 pack / 重建索引会让它虚高）。测增长率请用两个
**纯定时**产生的相邻快照。

用法：
    # 需要 restic 环境变量（RESTIC_REPOSITORY / RESTIC_PASSWORD_FILE 等）
    set -a; . /etc/<svc>/backup.env; set +a
    python3 snapshot_content_delta.py <old_snap> <new_snap> [--top 15]

    # 以 root 执行时若 repo 属主是别的用户，用 sudo -u <owner>
    sudo -u <repo-owner> python3 snapshot_content_delta.py <old> <new>

输出：
    新增文件数/体积、真实内容变化文件数/体积、净增合计、Top N 明细
"""
import argparse
import collections
import json
import os
import subprocess
import sys


def ls_snapshot(snap, restic='restic', timeout=1200):
    """返回 {path: (size, content_hash_tuple)}。"""
    p = subprocess.run([restic, 'ls', '--json', snap],
                       capture_output=True, text=True, timeout=timeout)
    if p.returncode != 0:
        sys.exit(f'restic ls 失败 rc={p.returncode}: {p.stderr.strip()[:400]}')
    out = {}
    skipped = 0
    for line in p.stdout.splitlines():
        line = line.strip()
        if not line.startswith('{'):
            continue
        try:
            r = json.loads(line)
        except ValueError:
            skipped += 1
            continue
        if r.get('struct_type') != 'node' or r.get('type') != 'file':
            continue
        out[r['path']] = (r.get('size') or 0, tuple(r.get('content') or ()))
    if skipped:
        print(f'  (跳过 {skipped} 行非 JSON)', file=sys.stderr)
    return out


def bucket(path, depth=4):
    parts = path.split('/')
    return '/'.join(parts[:depth]) if len(parts) > depth else '/'.join(parts[:3])


def human(n):
    for unit in ('B', 'KiB', 'MiB', 'GiB'):
        if abs(n) < 1024 or unit == 'GiB':
            return f'{n:.1f} {unit}' if unit != 'B' else f'{n} B'
        n /= 1024


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('old')
    ap.add_argument('new')
    ap.add_argument('--top', type=int, default=15)
    ap.add_argument('--restic', default='restic')
    args = ap.parse_args()

    print(f'读取 {args.old} ...', file=sys.stderr)
    a = ls_snapshot(args.old, args.restic)
    print(f'读取 {args.new} ...', file=sys.stderr)
    b = ls_snapshot(args.new, args.restic)

    print(f'A: {len(a)} files   B: {len(b)} files')

    added = {k: v[0] for k, v in b.items() if k not in a}
    removed = {k: v[0] for k, v in a.items() if k not in b}
    # 关键：内容判据用 content 元组，不用 size
    changed = {k: (a[k][0], b[k][0])
               for k in a if k in b and a[k][1] != b[k][1]}
    same_size_diff = {k: (a[k][0], b[k][0])
                      for k in a if k in b and a[k][0] == b[k][0] and a[k][1] != b[k][1]}

    def total(d, idx=None):
        return sum(v if idx is None else v[idx] for v in d.values())

    print()
    print(f'新增文件 : {len(added):6d}  {human(total(added))}')
    print(f'删除文件 : {len(removed):6d}  {human(total(removed))}')
    print(f'内容变化 : {len(changed):6d}  '
          f'净 {human(sum(sb - sa for sa, sb in changed.values()))}')
    if same_size_diff:
        print(f'  其中「大小不变但内容变了」: {len(same_size_diff)} 个  '
              f'{human(sum(v[0] for v in same_size_diff.values()))}'
              f'  ← 只比 size 会完全漏掉')

    net = total(added) + sum(sb - sa for sa, sb in changed.values()) - total(removed)
    print(f'\n净增合计 : {human(net)}')
    print('  ↑ 若这两个快照之间做过 prune 或大量人工操作，此值不是稳态增长率；')
    print('    测增长率请换两个「纯定时」产生的相邻快照。')

    agg = collections.Counter()
    for k, v in added.items():
        agg[bucket(k)] += v
    for k, (sa, sb) in changed.items():
        agg[bucket(k)] += sb - sa
    if agg:
        print(f'\n=== 净增最大的目录 (Top {args.top}) ===')
        for k, v in agg.most_common(args.top):
            print(f'{human(v):>12}  {k}')

    if added:
        print(f'\n=== 新增的最大文件 (Top {args.top}) ===')
        for k, v in sorted(added.items(), key=lambda x: -x[1])[:args.top]:
            print(f'{human(v):>12}  {k}')


if __name__ == '__main__':
    main()
