#!/usr/bin/env python3
"""LLM 节点并发探针：判定高失败率是上游并发限流，还是网络/配置问题。

核心是**对照组**：同一时刻、同一网关打两个不同上游。
若目标节点在低并发就挂、而对照节点高并发全过 → 上游并发限流。

用法:
  python3 llm_concurrency_probe.py \
      --config /home/ubuntu/lemon-group-bot/data/ai_endpoints.json \
      --node antigravity_gemini \
      --control cpa_gpt6_luna \
      --levels 1,2,4,8

配置文件格式（OpenAI 兼容端点）:
  {
    "antigravity_gemini": {
      "url": "http://127.0.0.1:8317/v1/chat/completions",
      "key": "sk-...",
      "default_model": "gemini-3.8-flash-high"
    },
    ...
  }

退出码: 0 = 目标节点在最低并发也全部成功；1 = 存在挂起/失败（可据此判定限流）。
"""
import argparse
import json
import statistics
import sys
import time
import urllib.error
import urllib.request
from concurrent.futures import ThreadPoolExecutor


def one_call(ep, idx, timeout):
    """单次请求。返回 (status_str, elapsed, is_hang)。"""
    payload = json.dumps({
        "model": ep["default_model"],
        "messages": [{"role": "user", "content": f"用一句话回答：{idx}+{idx}等于几？"}],
        "max_tokens": 150,
        "temperature": 0.4,
    }).encode("utf-8")
    req = urllib.request.Request(
        ep["url"], data=payload, method="POST",
        headers={
            "Content-Type": "application/json",
            "Authorization": f"Bearer {ep['key']}",
        },
    )
    t0 = time.time()
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            r.read()
            return "200", time.time() - t0, False
    except urllib.error.HTTPError as e:
        try:
            e.read()
        except Exception:
            pass
        return str(e.code), time.time() - t0, False
    except Exception as e:  # socket timeout / URLError / reset
        elapsed = time.time() - t0
        # 耗时逼近超时上限 = 上游挂起，不是快速拒绝
        hang = elapsed >= timeout * 0.9
        return f"HANG({type(e).__name__})" if hang else f"ERR({type(e).__name__})", elapsed, hang


def bench(ep, node_id, level, timeout):
    with ThreadPoolExecutor(max_workers=level) as ex:
        results = list(ex.map(lambda i: one_call(ep, i, timeout), range(level)))
    ok = sum(1 for s, _, _ in results if s == "200")
    hangs = sum(1 for _, _, h in results if h)
    lats = [e for s, e, _ in results if s == "200"]
    med = statistics.median(lats) if lats else 0.0
    detail = "  ".join(f"{s}:{e:.1f}s" for s, e, _ in results)
    print(f"  {node_id:22s} 并发{level:<3d} 成功 {ok}/{level}"
          f"  挂起 {hangs}  中位 {med:.2f}s")
    print(f"    {detail}")
    return ok, level, hangs


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True, help="端点配置 JSON")
    ap.add_argument("--node", required=True, help="待测节点 id")
    ap.add_argument("--control", help="对照节点 id（强烈建议指定）")
    ap.add_argument("--levels", default="1,2,4,8", help="并发阶梯，逗号分隔")
    ap.add_argument("--timeout", type=float, default=40.0, help="单请求超时秒数")
    args = ap.parse_args()

    cfg = json.load(open(args.config, encoding="utf-8"))
    levels = [int(x) for x in args.levels.split(",") if x.strip()]

    if args.node not in cfg:
        sys.exit(f"配置里没有节点 {args.node}；可用: {', '.join(sorted(cfg))[:300]}")
    if args.control and args.control not in cfg:
        sys.exit(f"配置里没有对照节点 {args.control}")

    print(f"目标节点: {args.node}  模型: {cfg[args.node]['default_model']}")
    print(f"超时: {args.timeout}s  阶梯: {levels}\n")

    print("=== 目标节点 ===")
    target_fail = 0
    for lv in levels:
        ok, total, hangs = bench(cfg[args.node], args.node, lv, args.timeout)
        target_fail += (total - ok)
        time.sleep(1)  # 让上游配额缓一下，避免阶梯之间互相污染

    if args.control:
        print(f"\n=== 对照组: {args.control}（同机同网关，不同上游）===")
        for lv in [levels[-1]]:  # 对照只跑最高并发即可
            bench(cfg[args.control], args.control, lv, args.timeout)

    print("\n判读:")
    print("  · 目标节点低并发就挂、对照节点同并发全过 → 上游并发限流")
    print("  · 两边同并发都挂 → 网关/本机/网络问题，查 CPA 与链路")
    print("  · 挂起（HANG）而非 429/503 → 限流表现为不响应，网关日志不会有错误")
    sys.exit(1 if target_fail else 0)


if __name__ == "__main__":
    main()
