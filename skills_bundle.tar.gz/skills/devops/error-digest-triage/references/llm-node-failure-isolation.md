# LLM 节点高失败率的隔离方法

## 症状

日报里某 AI 节点失败率高（实测 35–40%），但 fallback 全兜住，用户无感。
或者：客户端报 `outcome=timed_out` / `HTTP 000`，但上游网关日志里几乎看不到对应错误。

## 三步隔离阶梯

每步都要**实测**，不能靠推断。顺序不能跳——跳步就会把上游限流误判成网络问题。

### 第 1 步：网络层（最容易被误判成根因）

```bash
# TLS 握手 + 分阶段耗时，连测 6 次
for i in $(seq 6); do
  curl -s -o /dev/null -w '%{http_code} dns=%{time_namelookup} tcp=%{time_connect} tls=%{time_appconnect} total=%{time_total}\n' \
    --max-time 20 "https://<upstream-host>/"
done

# 是否只有 AAAA 记录（glibc 会 IPv6 优先）
dig +short A    <upstream-host> @1.1.1.1
dig +short AAAA <upstream-host> @1.1.1.1

# 分别强制 IPv4 / IPv6，对比
curl -4 -s -o /dev/null -w 'v4 %{http_code} tls=%{time_appconnect}\n' --max-time 15 "https://<upstream-host>/"
curl -6 -s -o /dev/null -w 'v6 %{http_code} tls=%{time_appconnect}\n' --max-time 15 "https://<upstream-host>/"
```

**判据**：TLS 握手稳定在几十毫秒、`-4` 与 `-6` 都不挂 → 网络层干净，**不是根因**。
注意：`getent hosts` 只显示 IPv6 不代表 IPv6 可用；本机 `ip -6 route show default` 为空就是没有 IPv6 出口，那种情况下 IPv6 会立刻 `ENETUNREACH` 而不是超时，不构成 10 秒挂死。

### 第 2 步：配置层

逐个排除请求参数，不要一次改多个变量：

```python
# max_tokens 阶梯：1500 / 2500 / 4000 / 8000
# prompt 长度阶梯：1 千 / 3 万 / 4 万字
```

实测结论：这两项在 `antigravity` 通道上**都不是**原因（4 万字 prompt 也能 200）。
模型名不匹配（`upstream served model "X-n" for requested "X-high"`）只是路由标签漂移，warn 级别，不影响成功。

### 第 3 步：并发层（决定性）

**关键动作：必须带对照组。** 同一台机器、同一个网关、同一时刻，打两个不同上游。

```bash
python3 scripts/llm_concurrency_probe.py \
  --config /home/ubuntu/lemon-group-bot/data/ai_endpoints.json \
  --node antigravity_gemini --control cpa_gpt6_luna --levels 1,2,4,8
```

2026-11-03 实测（naye，CPA `127.0.0.1:8317`）：

| 并发 | antigravity_gemini | cpa_gpt6_luna（对照） |
|---|---|---|
| 2 | 2/2，4.3s / 5.5s | — |
| 4 | **3/4**，1 个卡死 35s | — |
| 8 | **6/8**，2 个卡死 60s | **8/8，全在 1.2s 内** |

对照组是决定性的：同机、同网关、同时刻，GPT-6 通道 8 并发全过，antigravity 就挂 → **上游并发限流，不是 CPA、不是网络、不是磁盘**。
`antigravity` 安全并发线 ≈ **2**。

## 关键认知：并发限流的表现是「挂起」，不是 429

这是最容易误判的地方：

- 超限的请求**不会**返回 429/503，而是**挂住不响应**，直到客户端自己超时
- 所以上游网关日志里**看不到**对应错误 —— 「日志没错误」不等于「没发生」
- 客户端侧看到的是 `http_status=None` + `error_category=timeout` + `node_elapsed_s` 等于预算值

反推：若某节点 `timed_out` 的 `node_elapsed_s` 整齐等于 `node_budget_s`，几乎必然是上游挂起，而不是客户端逻辑问题。

## 日志字段怎么读（群霸 / lemon-group-bot）

日报来源名与本地 unit 的映射：

| 日报来源 | 本地 unit |
|---|---|
| `aws/群霸1` | `lemon-group-bot.service` |
| `aws/群霸2` | `lemon-group-bot2.service` |

**`-p warning..err` 查不到不代表没有**。日报统计的是 INFO 级的 `outcome=failed` / `outcome=timed_out` 结构化字段，不是 journal priority：

```bash
journalctl -u lemon-group-bot --since "<start>" --until "<end>" --no-pager \
 | grep -oP "outcome=\w+" | sort | uniq -c

# 失败明细：状态码 + 类别 + 预算/实际耗时
journalctl -u lemon-group-bot --since "<start>" --until "<end>" --no-pager \
 | grep "node=<node_id>" | grep -E "outcome=(failed|timed_out)" \
 | grep -oP "outcome=\w+ http_status=\S+ error_category=\w+" | sort | uniq -c
```

一次实测的失败构成（17 次 antigravity 失败）：

- **8 次** `http_status=None` `error_category=timeout`，`node_elapsed_s=33.39` ≈ `node_budget_s=33.166` → 上游挂起，客户端预算耗尽
- **9 次** `http_status=400` `error_category=http_error`，`node_elapsed_s=0.856` → 0.8 秒快速拒绝，**另一种原因，别混为一谈**

同一节点同一个「失败」标签下，状态码构成不同就是**不同故障**，必须分开归因。

## 已排除的错误归因（别再重复）

- ❌ 「TLS handshake timeout / EOF」——那是 CPA journal 里**另一批 4 条**记录，与群霸的 17 次无关。同名上游、不同日志流，不能合并计数。
- ❌ 「网络抖动」—— 实测 TLS 40ms、6/6 成功。
- ❌ 「IPv6 黑洞」—— 本机无 IPv6 出口，`-6` 立刻 unreachable，不产生 10 秒挂死。
- ❌ 「max_tokens 过大 / prompt 过长」—— 4 万字 + 8000 tokens 均 200。

## 处置方向

1. **给节点加并发闸门**（per-node 信号量，`antigravity` 限 2），拿不到信号量**立刻 fallback 到下一节点**，而不是排队挂死 —— 总耗时从 33s 降到 2s 内。
2. 不要试图给 CPA 加上游超时：`config.yaml` 无该配置项，`remote-management` 接口在无正确 header 时返回 401，改不动。
3. `400` 类失败需开 CPA `request-log: true` 才能拿到 body，**要重启 CPA**，属生产变更，须先取得用户同意。

## 未解决

- 9 次 `400`（0.8s 快速拒绝）根因未定位。CPA 收到后未打任何上游日志，说明是 CPA 内部生成而非 Google 透传。待抓 body。
