# 「本机被清空，原因不明」的取证路径

用户只说「昨晚那段时间本机被清空了，原因不明，后面是我重新复原的」时，**不要去猜原因**。
日志多半已被清掉，编一个原因比说"查不到"伤害大得多。正确做法是把**能确定的事实**钉死，
然后回答那个真正重要的问题：**出事那一刻，有没有可用备份。**

2026-11-05 实战产出，全部为实测证据。

## 一、先定 boot 边界，别信 uptime

```bash
sudo journalctl --list-boots --no-pager
```

本次输出只有 2 个 boot：

```
 -1  7176a289...  Wed 2026-11-04 18:40:46 CST  Wed 2026-11-04 18:57:06 CST
  0  20f4a7fb...  Wed 2026-11-04 18:57:31 CST  Thu 2026-11-05 15:25:43 CST
```

判读：
- 前一个 boot **只有 16 分钟** → 它的起点（18:40:46）不是开机时间，而是**日志被清的时间**。
- 后一个 boot 连续至今 → 全程只重启过 1 次。

**三个会撒谎的信号：**

| 信号 | 为什么会错 |
|---|---|
| `uptime` / `last reboot` | 读 `wtmp`，复原操作可能把它一起覆盖回旧版本 |
| syslog 里 `[ 0.000000] Linux version` | rsyslog 服务重启会重新 dump kernel ring buffer，时间戳是当时、内容是历史。**不能证明重启** |
| journal 最早一条的时间 | 那是日志起点，不是机器起点 |

## 二、判断是"重装"还是"只是文件没了"

```bash
ls -la --time-style=long-iso /var/log/installer/          # 重装会刷新到事故时间
ls -la --time-style=long-iso /etc/machine-id /etc/hostname
ls -la --time-style=long-iso /var/log/journal/            # 有几个 machine-id 子目录
```

本次结论：
- `/var/log/installer` 停在 **2023-06-11**，`/etc/machine-id` mtime 是 **10-26 15:19** → **没有重装**。
- `/var/log/journal/` 下有两个 machine-id 目录：`1cb0572d...`（2023-06-11，8 MB 孤儿）和
  `c0c9e67e...`（当前，最早文件 11-04 18:44）。**别把旧 machine-id 目录当成"身份被重置"** ——
  那是这台 VM 更早一次装机的残留，`journalctl` 根本不会读它。

## 三、定位"人工复原"动作的时间

找一批**本来应该更早**的文件，看它们的 mtime 聚在哪个时刻：

```bash
ls -la --time-style=long-iso /home/ubuntu/.hermes/backups/ | head -20
```

本次实测：10 月创建的所有备份子目录 mtime 全是 **11-04 21:03** —— 名字里的日期是 10 月，
mtime 却是 21:03，那就是 `cp -a`/恢复操作落盘的瞬间。配合 `systemctl show <svc> -p ActiveEnterTimestamp`
（21:41:04 / 21:41:26）就得到完整的"事故 → 复原"窗口。

## 四、核对删除动作的归属，别急着说"自伤"

`/var/log/audit/` 里能看 `key=` 区分来源：

| key | 含义 |
|---|---|
| `naye_data_delete` | 数据目录删除，**可能**是服务自己 |
| `naye_agent_exec` | Hermes agent 执行的命令 |

**必须再核 `pid` / `ppid`：**

```bash
sudo journalctl --since "..." --until "..." --no-pager | grep "type=SYSCALL" | grep "music_cache.db-wal"
```

本次实测删 `-wal`/`-shm` 的 `pid=293597 ppid=1`，正是群霸自己的 MainPID → SQLite 正常关闭，
**不是外部破坏**。只看 `comm="python3"` 或 key 名会判反。

## 五、真正要回答的问题：当时有没有可用备份

这一步比追原因有价值得多。

```bash
ls -d --time-style=long-iso -l /home/ubuntu/backups/unified/*/   # 统一备份份数
ls -d /home/ubuntu/.hermes/backups/hermes-[0-9]*                 # Hermes 自身快照
```

本次发现：
- unified 只有 **10-26、10-27，然后直接跳到 11-05** → 中间 **7 天零快照**。
- Hermes 自身 `hermes-*` 目录 **0 份**（被清空一起带走）。

**同时必须核对 job 台账**，但**不要采信它**：

```bash
cat /home/ubuntu/hermes-jobs/jobs/unified-backup-daily/status
tail -c 2500 /home/ubuntu/hermes-jobs/jobs/unified-backup-daily/job.log
```

本次 job 从 10-30 到 11-05 **每天 `completed`**，而产物一份都不在 ——
`completed` 只证明脚本退出 0。`recovered_by=verified-repair-20261105` 是事后手工改写的标记。
真因在 job.log 末尾：`LA storage reserve gate: upload would leave less than 5 GiB free`。

→ 断链根因与修法属于备份域，见 `hermes-backup` / `backup-chain-audit`。

### 五.1 证明异地加密包真的能恢复（`.hermesenc`）

「异地有文件」不等于「能恢复」。删任何一份异地包之前必须先跑完这三步。

**先纠正一个高频误判：`.backup_key` 不是这把钥匙。** 它是 65 字节（64 hex + 换行）的
本地 AES 密钥，与 `.hermesenc` 无关。两条备份链的加密方式也不同：

| 链路 | 后缀 | 加密 | 解密材料 |
|---|---|---|---|
| Telegram 分片 | `.cms` (CMS DER) | 公钥证书 | `~/.config/hermes-backup/recovery-cert.pem` |
| 洛杉矶离站 | `.hermesenc` | RSA-4096 OAEP + AES-256-GCM | `~/.config/hermes-backup/recovery_private.pem` |

私钥**从不上传到存储主机**（脚本头注释明写），所以验证必须在持有私钥的本机做。

**文件格式**（`offsite_backup.py`，`MAGIC = b"HERMES01"`）：

```
[8B "HERMES01"][4B BE header_len][header_len B JSON][ciphertext...][16B GCM tag]
header = {"v":1, "key": base64(RSA-OAEP-SHA256(aes_key)), "nonce": base64(12B)}
AAD = MAGIC + struct.pack(">I", len(header)) + header
```

**三步，从便宜到贵：**

1. **私钥配对**（读 20 KB，秒级）：`ssh <host> head -c 20000 <pkg>` 取包头，解析 header，
   用私钥 RSA-OAEP 解出 32 字节 AES key。解得出来 = 私钥与这份包配对。
   **MAGIC 是 `HERMES01`，不是 `HRMENC01`** —— 猜错会得到 `magic_ok: False`，但长度字段位置对，
   header 仍能解析；不要因此误判包损坏。
2. **整包解密**（GCM tag 在流尾，必须读完全文）：
   ```python
   import sys; sys.path.insert(0, '/home/ubuntu/hermes-jobs/releases/offsite-20261004')
   import offsite_backup as ob
   ob.decrypt(Path(pkg), Path(out),
              Path('/home/ubuntu/.config/hermes-backup/recovery_private.pem').read_bytes())
   ```
   GCM 认证失败会抛异常，**能跑完就证明整包未被截断/篡改**。860 MB 解密约 1.4 s。
3. **成员清单**：`tar tzf` 期望 11 项 —— `unified/{state.db,configs.tar.gz,host-support.tar.gz}`、
   `hermes/{state.db,kanban.db,response_store.db,data.tar.gz,model_proxy.tar.gz,verification_evidence.db,recovery_support.tar.gz}`、
   `manifest.json`。缺 `model_proxy.tar.gz` 或 `recovery_support.tar.gz` 是典型残缺包。

**传输基线**：vps-la → naye scp 860 MB ≈ **2 分 08 秒**。规划窗口按 2 分钟算，别用本地拷贝速度估。

## 六、汇报形状

1. **时间线表**：每行「时间 / 事件 / 证据」，证据必须是命令输出而不是推断。
2. **明确说"原因查不到"**：如果日志已被清，直接写"没有留下任何证据，无法还原原因"，
   不要用"可能是 X"填空。
3. **把"有没有备份"单独成节**：这是用户真正的风险敞口，比原因重要。
4. **区分已复原项与仍缺失项**（本次：8 个 bot 库 `integrity_check` 全 ok，但 `hermes-*` 快照 0 份）。
