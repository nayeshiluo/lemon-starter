# 停机/重启窗口类噪音与告警判读

两类东西看着像故障、实际都指向"服务正在重启"，判读方法在这里。

---

## 一、巡检 `❌ 服务未运行` + `✅ 已恢复` 是同一件事

实测（2026-11-05，群霸）：

```
14:59:45  进程优雅关闭数据库连接
14:59:58  Application is stopping（SIGTERM）
14:59:59  巡检取样 → ❌ 服务未运行
14:59:59  新进程启动
15:00:00  Application started
15:01:44  巡检复检 → ✅ 此前报告的保护链路异常已恢复
```

**两次告警是同一次重启的上下半段，不是两次故障。** 报故障时不要写成"昨晚挂了一次、又恢复了一次"。

### 秒级判据（三条同时看）

| 判据 | 读法 |
|---|---|
| `systemctl show <svc> -p ActiveEnterTimestamp` | 与 ❌ 告警时间差 **< 3 秒** → 告警取样落在重启窗口 |
| `systemctl show <svc> -p NRestarts` | `0` → systemd 没因崩溃重启过，是 `systemctl restart`；`>0` → 真崩溃循环 |
| journal 里有没有 `Application is stopping` / `Stopped <svc>` | 有 = 优雅停止；没有而进程没了 = 被 OOM kill 或段错误，另查 `dmesg` |

```bash
systemctl show <svc> -p Id -p ActiveEnterTimestamp -p NRestarts -p MainPID
journalctl -u <svc> --since "<告警时间 - 5min>" --no-pager | grep -E "stopping|Stopping|Started|Failed"
```

`NRestarts=0` **且** 有优雅 stopping 记录 → 有人/某任务主动重启，去查谁触发（audit 的 `SERVICE_START`，或该时段是否有 Hermes/部署任务在跑）。`NRestarts` 很大 → 无限重启循环，先修启动条件，别看业务日志。

### 别被 2 分钟巡检窗口骗过

巡检通常隔一两分钟取一次样，**只能证明"取样那一刻"**。真实停机时长要自己算：

```bash
# 每次停止到下次启动的间隔
journalctl -u <svc> --since "-3 days" --no-pager \
  | grep -E "Starting |stopping|Stopped " | tail -20
```

实测抓到过一次巡检完全没报的：`18:57:03` 停止 → `21:41:04` 启动，**空转 2 小时 44 分**，因为同期巡检恰好都在服务已恢复的时点取样。结论里必须把这种窗口单独列出来，不能因为"告警显示已恢复"就说没事。

---

## 二、SQLite `unable to open database file` 是 WAL 短连接竞态

### 症状

```
File "storage.py", line 19, in transaction
  conn = connect(path)
File "storage.py", line 10, in connect
  conn.execute('PRAGMA journal_mode=WAL')
sqlite3.OperationalError: unable to open database file
```

特征组合（缺一条就别往这个结论上靠）：

- 报在 **`PRAGMA journal_mode=WAL`** 这一行，不是 `connect()` 本身
- **多个不同 PID 同时报**（同一进程的 bug 不会跨 PID）
- 集中在**服务启动/停止前后几分钟**，不是均匀铺满全天
- `PRAGMA integrity_check` 全部 `ok`，数据没坏
- 业务能自愈，下一轮连接成功

### 根因

`storage.py` 每次操作都 `sqlite3.connect()` → 用完 `close()`。WAL 模式下**最后一个连接关闭时会 unlink `-wal` 和 `-shm`**。多进程/多线程共享同一个 DB 文件时存在竞态：A 进程关闭并删掉 `-shm`，B 进程正在打开 → B 拿不到共享内存文件 → `unable to open database file`。

### 关键误判：audit 里看到 DELETE `-wal`/`-shm` 不等于有人破坏

实测踩过这个坑：audit 日志显示 `nametype=DELETE` 删掉 `music_cache.db-wal`，第一反应是"有清理脚本在删 SQLite 文件"。核对 pid 后结论反转：

```
type=SYSCALL syscall=87 (unlink) ... ppid=1 pid=293597 comm="python3" key="naye_data_delete"
```

`pid=293597` **就是 DB 所有者服务自己的主进程**，`ppid=1` 是 systemd。这是 **SQLite 正常关闭行为**，不是外部破坏。

**核对顺序（必做）：**

1. 取 audit 事件里的 `pid`
2. 和 `systemctl show <svc> -p MainPID` 或该时段进程对比
3. pid 相同 → 自己人正常关闭；pid 不同/找不到 → 才考虑外部进程

只看 `key="naye_data_delete"` 或 `comm="python3"` 就下结论会误判，因为 DB 所有者本身也是 python。

### 处置

日志噪音，**不影响数据**，可以不修。要压掉的话按代价从小到大：

1. `connect()` 加退避重试（最省事，`OperationalError` 时 sleep 50–200ms 重试 2–3 次）
2. 连接复用（连接池），减少 open/close 次数
3. 每个 DB 文件只让一个进程写，其余进程走 IPC

**不要**为了消日志把 `journal_mode` 改成 `DELETE` —— 会牺牲并发读写能力，且这本来就是设计内的 WAL 行为。

### 验收

```bash
# 8 个库全部 ok 才算数据无损
python3 -c "
import sqlite3, glob, os
for f in sorted(glob.glob('data/*.db')):
    c = sqlite3.connect(f, timeout=5)
    print(os.path.basename(f), c.execute('PRAGMA integrity_check').fetchone()[0])
    c.close()
"
```
