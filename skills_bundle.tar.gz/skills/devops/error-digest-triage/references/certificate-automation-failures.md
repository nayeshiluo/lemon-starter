# 证书自动化的静默失败与验收

日报里「业务失败」条数不多，但某个 cron 已经连续 FAILED 好几天——这类问题几乎不会出现在错误条数排名里，因为脚本抛异常后直接退出，日志只有一次 Traceback。

## 一、先看 last_success_at 的缺口，不看条数

```bash
python3 -c "
import json,glob,os
for f in sorted(glob.glob('/home/ubuntu/.local/state/automation-cron/*.json')):
    n=os.path.basename(f).replace('.json','')
    d=json.load(open(f))
    print(f'{n:22} {d.get(\"status\"):8} exit={d.get(\"exit_code\")} last_ok={str(d.get(\"last_success_at\"))[:19]}')
"
```

判据：`status=FAILED` 且 `last_success_at` 是几天前 → 这是持续故障，不是抖动。
`status=FAILED` 但 `last_success_at` 是上一轮 → 单次失败，看下一轮是否自愈。

## 二、复现用 crontab 里的完整命令，不要只跑脚本

cron 里的命令通常带一层状态包装（`cron-status.py <job> -- <真实命令>`）。只跑内层脚本会漏掉包装层的环境差异，也拿不到状态文件更新。

```bash
/usr/bin/python3 /home/ubuntu/hermes-jobs/cron-status.py certificate-deploy -- \
  /usr/bin/python3 /home/ubuntu/capy-acme.py --deploy
echo "EXIT=$?"
```

验收标准：`EXIT=0` **且** 状态文件 `last_success_at` 被刷新。两个都满足才算修好。

## 三、已确认案例：cryptography 版本导致的证书脚本崩溃

### 症状

`capy-acme.py` 每周一 `exit 1`，连续 7 天 `last_success_at` 不动。日志尾部：

```
AttributeError: 'builtins.Certificate' object has no attribute 'not_valid_after_utc'.
Did you mean: 'not_valid_after'?
```

### 根因

`cryptography >= 42` 才有 `not_valid_after_utc`（timezone-aware）；`< 42` 只有 `not_valid_after`（naive datetime）。本机是 `38.0.4`。

### 修法（向后兼容两个版本）

```python
_cert_obj = x509.load_pem_x509_certificate(cert.read_bytes())
# cryptography <42 has not_valid_after (naive); >=42 has not_valid_after_utc (aware)
expires = getattr(_cert_obj, 'not_valid_after_utc', None) or \
          _cert_obj.not_valid_after.replace(tzinfo=timezone.utc)
renewal = (expires - datetime.now(timezone.utc)).days < 30
```

不要选「升级 cryptography」当第一方案：系统包管理器的版本和其他脚本共享，升级的爆炸半径远大于三行兼容代码。

### 同类症状速查

见到 `not_valid_after_utc` / `not_valid_before_utc` / 任何 `*_utc` 属性缺失，先查版本再动手：

```bash
python3 -c "import cryptography; print(cryptography.__version__)"
```

## 四、证书部署必须验到「线上实际文件」

脚本打印 `Certificate deployed and Nginx reloaded` 不等于证书真的换了。这条链路跨三台机，任何一跳静默失败都可能仍然打印成功。

本仓库的 capy 证书链：

1. naye 上 ACME 签发 → `~/.local/share/capy-acme/production/fullchain.pem`
2. `scp` 到 `vps-la:/opt/happy-capy-web/certs/`
3. `ssh vps-la 'docker exec happy-capy-web nginx -t && nginx -s reload'`

验收三步，缺一不可：

```bash
# 1. 源端证书到期时间
python3 -c "
from cryptography import x509
import pathlib
c=x509.load_pem_x509_certificate(pathlib.Path('/home/ubuntu/.local/share/capy-acme/production/fullchain.pem').read_bytes())
print('expires:', c.not_valid_after)"

# 2. 远端落盘时间 + 到期时间（文件 mtime 应等于本次部署时间）
ssh vps-la 'ls -la /opt/happy-capy-web/certs/; openssl x509 -in /opt/happy-capy-web/certs/fullchain.pem -noout -enddate -subject'

# 3. 容器内是否同步（bind mount 也可能没挂对）
ssh vps-la 'docker exec happy-capy-web ls -la /etc/nginx/certs/'
```

## 五、端口陷阱：握手成功 ≠ 站点存在

`capy.<PRIVATE_IDENTIFIER>` 的 443 端口 `openssl s_client` 握手完全成功、能拿到证书，但 `curl` 返回 `HTTP=000`。

原因：该域名是 **DNS 直连源站**（解析到 vps-la 真实 IP，不走 CF 代理），而 `Caddyfile` 里根本没有 `capy.<PRIVATE_IDENTIFIER>` 的 site block —— Caddy 完成了 TLS 握手却无路由可走。

真实入口是 `:2087`（happy-capy-web 容器 nginx），实测 `HTTP=302` 正常。

排查顺序：

```bash
grep -n "capy" /home/ubuntu/Caddyfile          # 有无 site block
dig +short capy.<PRIVATE_IDENTIFIER> @1.1.1.1            # 是否 CF 代理还是直连源站
docker port happy-capy-web                      # 真实映射端口
```

判定规则：**TLS 握手成功但无 HTTP 响应，先查 Caddy site block，不要先怀疑证书或防火墙。**

## 六、业务层分类问题：别为了日报变绿去放宽判定

`media-pipeline` 连续 4 天 `PARTIAL`，根因是同一个资源被光鸭服务端内容审核拒绝：

```
《...76.3G》服务端判定文件违规（第 1/2 次），保留重试
```

重试必然过不了，但代码把它计入 `failed` 而非 `permanent_rejected`，于是 `failed>0` → 每天 PARTIAL。

这是**分类错误**，不是网络故障，也不是该放宽判定。正确做法是把它归入终态拒绝、不再重试；但这属于业务判定层，**必须取得用户明确同意后才能改**，不能在日报层掩盖。
