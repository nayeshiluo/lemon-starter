# restic 仓库异常增长：根因定位与 SQLite 快照分级

实测于 2026-11-18（naye → vps-la rest-server，配额 8GiB 逼近）。

## 一、症状形态

- 仓库稳定逼近配额（实测 7.4G / 8G = 88%），告警文案写「prune 未生效，自查 prune timer」
- 但 prune 每 3h 都跑、**rc=0**、快照数正常、`restic check` 无错
- 每天新增 2–4 GB，按此速率 1–2 天撞硬配额

**告警文案是错的。** 别顺着它去查 prune。

## 二、先算真实增量，别信 `restic stats`

`restic stats --json` 的 `data_added` / `data_added_packed` 在部分版本返回 `None`，
用它算日增量会直接崩或得 0。直接数 pack 文件字节：

```bash
REPO=/var/lib/naye-restic/repositories/naye/core

# 近 7 天按天聚合
find $REPO/data -type f -newermt '-7 days' -printf '%TY-%Tm-%Td %s\n' \
  | awk '{a[$1]+=$2} END {for (d in a) printf "%s  %10.1f MB\n", d, a[d]/1048576}' | sort

# 今天按小时
find $REPO/data -type f -newermt 'today 00:00' -printf '%TH %s\n' \
  | awk '{a[$1]+=$2} END {for (h in a) printf "%s时 %8.1f MB\n", h, a[h]/1048576}' | sort
```

实测输出形态（每小时 00/03/06/…/21 轮次）：

```
2026-11-15        258.4 MB
2026-11-16        307.0 MB
2026-11-17       2043.5 MB
2026-11-18        793.0 MB     # 当天只到 14 点
```

每 3 小时约 460 MB，与「一天 3.7 GB」对得上。

## 三、找根因：staging 里哪个快照最大

备份 runner 的典型结构是「SQLite online backup → staging → `restic backup staging`」。
所以 restic 每次处理的不是活库，而是 staging 里的快照副本。

```bash
ls -lS <staging>/*.sqlite | head -10          # 谁最大
du -sb <staging>                              # 总量
```

再拆单个库的内部构成：

```bash
python3 -c "
import sqlite3
c=sqlite3.connect('file:<db>?mode=ro',uri=True)
print('page_size',c.execute('PRAGMA page_size').fetchone()[0],
      'page_count',c.execute('PRAGMA page_count').fetchone()[0])
for n,mb in c.execute('SELECT name,SUM(pgsize)/1048576.0 FROM dbstat GROUP BY name ORDER BY 2 DESC LIMIT 10'):
    print('%8.1f MB  %s'%(mb,n))
"
```

实测形态（`~/.hermes/state.db` 407.7 MB）：

| 构成 | 大小 |
|---|---|
| `messages` | 202.2 MB |
| `messages_fts_trigram_data`（中文全文索引） | 131.2 MB |
| `messages_fts_data` | 45.7 MB |
| system_prompts + 各类索引 | 28.6 MB |

79,978 条消息的正文只有 **94 MB**，索引却是正文的两倍。中文 trigram 索引膨胀是**固有成本**，
不是碎片、不是 bug。

## 四、先排除两条「看起来对」的官方路

```bash
hermes sessions stats                  # 看总消息数、库大小、来源分布
hermes sessions optimize-storage --yes # 迁 v23 紧凑 external-content 布局
hermes sessions optimize               # 合并 FTS 段 + VACUUM
```

实测结果：
- `optimize-storage` → `Search index is already on the compact layout — nothing to do.`
- `optimize` → `407.7 MB -> 402.0 MB (reclaimed 5.7 MB)`

**两条都跑完还是 402 MB，就说明是数据量问题，别再折腾索引。** 这一步的价值是排除法：
不先跑，就会花时间在错误的优化方向上。

## 五、解法：SQLite 快照分级（`sqlite_daily_only`）

思路：高频写入的大库不必每轮全量快照。让它们只在 daily 轮次刷新，其余轮次复用 staging
上一份文件 —— restic 因内容未变而不产生新增，**不删任何数据、不改业务库**。

`backup.py` 三处改动：

**1. sqlite 循环前**（算 is_daily + 加载上一轮 catalog）：

```python
local_hour=datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=8))).hour
is_daily='--daily'in sys.argv or local_hour==3
DAILY_ONLY=set(config.get('sqlite_daily_only')or[])
prev_catalog={}
_catalog=STAGE/'RESTORE_CATALOG.json'
if _catalog.exists():
    try:
        prev_catalog={row['source']:row for row in json.loads(_catalog.read_text()).get('sqlite')or[]}
    except (ValueError,KeyError,TypeError):
        prev_catalog={}
```

**2. 循环体内**（skip 分支，紧跟 `target=` 赋值之后）：

```python
if source in DAILY_ONLY and not is_daily and target.exists() and source in prev_catalog:
    manifest['sqlite'].append(prev_catalog[source]);continue
```

**3. 复用 is_daily**（删掉后面重复的 local_hour 计算）：

```python
tag='daily'if is_daily else 'hourly'
```

### 关键约束

- **必须沿用 `prev_catalog` 的条目**。跳过时不 append，`RESTORE_CATALOG.json` 就会缺条目，
  恢复侧会当成「源缺失」而失败。
- 三个条件缺一不可：`source in DAILY_ONLY`（配置命中）、`not is_daily`（非 daily 轮次）、
  `target.exists()`（staging 已有上一份）——最后一个防的是首次运行或 staging 被清空的情况，
  此时必须真做快照，不能凭空沿用。
- `sqlite_daily_only` 里的路径必须在 `sqlite_sources` 里真实存在，否则 skip 逻辑永不命中。
  加配置时用断言校验，别手写。

### 选哪些库进 daily_only

**只选「丢了不影响业务一致性」的**：

| 可以进 | 不要进 |
|---|---|
| 会话历史（`state.db`） | 群管 `bot.db`（禁言/权限/用户状态） |
| Web UI 会话与缓存 | 业务队列 / 调度状态库 |
| 监控时间序列（`metrics.db`） | 计费、账本、审计日志 |

业务状态库丢 24h 会导致状态不一致，宁可每小时全量。

### 实测收益（每 3 小时一轮）

| 阶段 | `data_added` | 降幅 |
|---|---|---|
| 基线 | 460 MB | — |
| 只跳 `state.db` | 311 MB | -32% |
| 跳 `state.db` + `hermes-web-ui.db` + `metrics.db` | **98.1 MB** | **-79%** |

按 98 MB/3h 计算，12 GiB 配额下从「4–5 天告警」变成「5–6 个月」，
每日上行带宽也从 3.7 GB 降到 0.8 GB。

## 六、三项验证（缺一不可）

**1. 非 daily 轮次跑完，staging 状态符合预期**

```bash
# daily_only 的库 mtime 必须不变
stat -c '%y %s' <staging>/db-<hash>.sqlite
# 其余库应已刷新
find <staging> -name 'db-*.sqlite' -printf '%TH:%TM\n' | sort | uniq -c
# catalog 条目数必须不变
python3 -c "import json;print(len(json.load(open('<staging>/RESTORE_CATALOG.json'))['sqlite']))"
```

实测：`state.db` 快照停在 12:00（未刷新），其余 41 个库 14:37 刷新，catalog 仍 42 条。

**2. `last-backup.log` 的 summary `data_added` 显著下降**

```bash
python3 -c "
import json
for line in open('/var/lib/naye-protection/last-backup.log'):
    try: row=json.loads(line)
    except ValueError: continue
    if row.get('message_type')=='summary':
        for k,v in row.items():
            if isinstance(v,int) and v>100000: print('%-26s %.1f MB'%(k,v/1048576))
            else: print('%-26s %s'%(k,v))
"
```

**3. prune 跑通、快照数符合保留策略**

```bash
systemctl start <prune>.service; systemctl show <prune>.service -p Result
```

## 七、坑：别随手触发全量恢复演练

`naye-protection-restore.service` 这类全量恢复会从异地拉**全部**数据。
实测 14 GB @ 1 MB/s = 数小时，既占满上行，又吃掉定时备份的带宽窗口（会把当天的备份拖成超时失败）。

轻量验证改用**单文件探针**：只从最新快照取目标库文件。

```bash
restic restore --no-lock <snapshot_id> --target <tmpdir> --include <单个 staging 文件路径>
```

取出后验证三条即可：`PRAGMA integrity_check` = ok、关键表行数、表数量。
完整演练要单独排在低峰、并确认与备份链时间窗不重叠。

## 八、异地接收端选型：必须测并发是否叠加

**只测单流速率会选错机器。** 实测同一时刻三条链路：

| 链路 | 单流 2–4 MB | 4 流并发 |
|---|---|---|
| → 阿里云 | 195 KB/s | 178 KB/s（**不叠加，等于硬顶**） |
| → 洛杉矶 | 332 KB/s | 1422 KB/s |
| → 香港 | **3772 KB/s** | — |

判据：

```bash
# 并发叠加性
for i in 1 2 3 4; do dd if=/dev/zero bs=1M count=2 2>/dev/null | ssh <host> 'cat > /dev/null' & done; wait
# 丢包与重传
nstat -az | grep -Ei 'TcpRetransSegs|TCPLostRetransmit|TCPTimeouts'
```

**并发不叠加 + 重传计数暴涨 ⇒ 丢包把单流压死**，重试和调超时都救不了，只能换接收端。
实测阿里云 `TcpRetransSegs` 从 8.2 万涨到 122 万、`TCPLostRetransmit` 16 万，
而同期对洛杉矶仍是 1 MB/s ⇒ 源机出网正常，是那条国际路径塌了，查源机无收益。

配套的上传改法：`rsync -a --no-owner --no-group --partial --append-verify`，
超时按**最差实测速率**估（不是最好速率），远端 sha256 断言保留兜底。
`--no-owner --no-group` 是必需的：目标端用户 ID 不同时 `-a` 会保留源端属主，
导致文件归属错误（实测写成 `1000:1000` 而非 `root:root`）。

## 九、汇报口径

用户问「怎么办」时，先给**根因一句话**（是哪个文件、多大、为什么去重失效），
再给**实测收益表**（改前 / 改后 `data_added`），最后才是改动清单。
不要一上来列方案 —— 没定位到具体文件前，任何方案都像在猜。
用户说「就现有的资源」时，方案必须落在现有磁盘/配额/带宽内，不提换机扩容。
