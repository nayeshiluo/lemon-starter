# 备份断档取证与多机磁盘占用判读

2026-11-05 实测。两件事常同时出现：**磁盘满了 → 备份传不上去 → 断档**，但日报两处都显示正常。

---

## 一、备份断档：三层证据必须分开核

| 层 | 看什么 | 能证明什么 |
|---|---|---|
| ① 脚本 | `jobs/<job>/status` 的 `exit=` / `last_success_at` | 脚本有没有跑完 |
| ② 产物 | `ls` 快照目录、`du -sh`、mtime | 东西还在不在 |
| ③ 新鲜度 | 最新快照年龄 vs 备份周期 | 有没有断档 |

**任一不符就是故障。** 本次 ① 全绿（10-30→11-05 每天 `completed`），② ③ 全断（`unified/` 7 天零快照、`hermes-[0-9]*` 为 0 份）。

`status` 里的 `recovered_by=verified-repair-<date>` 是事后手工补记，**不是**自动链路跑通的证据。

### 根因：远端预留门禁

```
RuntimeError: LA storage reserve gate: upload would leave less than 5 GiB free
FAILED rc=1
```

代码形状（`offsite_backup.py` publish 段）：

```python
"assert shutil.disk_usage(p).free > " + str(5 * 1024 ** 3 + encrypted.stat().st_size) + ...
```

语义是「**传完之后远端仍要留 N GiB**」。远端盘 82%、剩 5.8 G，加密包 0.86 G，需要 5.84 G → **差 0.04 G 被拒**。`set -euo pipefail` 让整链 `FAILED`，prune 不执行，全程零告警。

同脚本里另有 `RETENTION_MAX_BYTES = 4 * 1024**3`、单包上限 `2 GiB`、`max_files: 2`。**这些是当前值，下次先读代码，别套历史公式。**

### 修的顺序（安全 → 激进）

1. **调门禁阈值**（5 GiB → 4 GiB）。34 G 盘留 4 G 足够，零数据损失、一行改动。
2. 清远端无关占用（容器镜像、旧归档）。
3. 删旧异地包 —— **放最后**。脚本自带 retention，下次成功会自动删最旧包；手工删反而破坏保留策略。

改阈值必须**同步两处**：

```python
# 远端 assert
str(4 * 1024 ** 3 + encrypted.stat().st_size)
# 本地匹配远端 stderr 的字符串（只改数值不改这里 → 退化成 Remote backup operation failed）
if 'LA would have less than 4 GiB free after this upload' in result.stderr:
```

改完：`cp -a` 备份 → `compile()` 验证 → 重跑整链 → 验收看**阶段号走完**（`6/6 SUCCESS rc=0`），不是 `rc=0`。

### 失败现场会自我放大

```
FAILED: preserved private workspace /home/ubuntu/hermes-jobs/tmp/offsite-XXXXXXXX
```

内含 `snapshot.tar`(1.2G) + `input-check/`(652M 解开的库副本) + `<stamp>.hermesenc`(1.2G) ≈ **3.0 G/次**，无自动清理。两次就是 6 G。磁盘告警时先 `du -sh <tmp>/offsite-*`。

### `.hermesenc` 异地包验证配方

```bash
# 1) 只取 20000 字节 header，验私钥配对，不用拉整包
ssh <store> 'head -c 20000 /path/<stamp>.hermesenc' > /tmp/hdr.bin
# magic = b'HERMES01'（不是 HRMENC01）；header = magic + >I len + JSON{v,key,nonce}
# RSA-OAEP(SHA256) 解出 32B AES key 即配对成功；nonce 12B；v=1

# 2) 整包解密（AES-256-GCM，tag 校验不过会抛异常）
python3 -c "import sys; sys.path.insert(0,'<releases>/offsite-20261004'); \
import offsite_backup as ob; ob.decrypt(src, dst, key)"

# 3) 列成员
tar tzf /tmp/dec.tar.gz
```

- `~/.backup_key`（65 字节 hex）**不是**解密私钥，只是旧的本地对称密钥。私钥在 `~/.config/hermes-backup/recovery_private.pem`，公钥证书 `recovery-cert.pem`。私钥不在存储主机上 → **验证必须在本机做**。
- 实测基线：860 MB 包 → 拉回 2m09s → 解密成功 → `tar tzf` 11 个成员，含 `unified/state.db`、`hermes/model_proxy.tar.gz`。

### 检测窗口公式

**最坏发现时间 = 检查间隔 + 过期阈值。**

`backup-verify.py` 原为每天 1 次 + `MAX_AGE_HOURS = 30` → 事故 18:57 发生，次日 12:21 检查时 age 才 17h，**照样 PASS**，最坏 54 小时才发现。

日备场景应满足 `threshold < 2 × interval`。已改：`OnCalendar=*-*-* 00,06,12,18:20:00 UTC` + `MAX_AGE_HOURS = 26` → 最坏 32h。改完 `daemon-reload` + `restart` + 手动 `systemctl start` 跑一次确认不误报。

---

## 二、多机磁盘占用判读

### 先分类，别先删

| 类别 | 例子 | 处理 |
|---|---|---|
| 业务成本 | 备份目录、容器镜像、restic 仓库 | 保留，靠保留策略控 |
| 真垃圾 | 失败残留工作区、build cache、`/tmp` 验证产物 | 直接清 |
| 需判断 | 维护前回滚副本、停止容器的镜像 | 查验证状态再定 |

实测「磁盘都好大」的三台，大头全是前两类 —— **不是垃圾多，是业务成本**。真垃圾只有一处（6 G 失败工作区）。

### Docker 的坑

- **`docker system df` 的 RECLAIMABLE 不可信**：报 4.4 GB 可回收，实际只释放 1.22 GB。共享层被重复计入。
- **要按每镜像的 `CONTAINERS` 列判断**：`docker system df -v` → 看 `Images space usage` 段，`CONTAINERS = 0` 才是候选。
- **必须查停止容器**：`docker ps -a --filter ancestor=<image_id> -q`。一个 `Exited` 的回滚容器就能把镜像钉住，删了回不去。
- **`:<something>-before-*` / `before-memory-*` / `before-<feature>-*` tag = 回滚备份**，默认保留。
- `<none>:<none>` 不等于可删 —— 实测有个现役容器就跑在 `<none>` 镜像上。

### 目录大小清点

```bash
# 对
du -sh dir/* | sort -rh
find dir -maxdepth 1 -mindepth 1 -exec du -sh {} \; | sort -rh

# 错 —— head 会把大头截在视野外
ls -la dir | head -6
```

实测踩过：`ls | head -6` 只看到几 KB 的 `cache/`，真正的 4.2 G `repository/` 排在其后被截掉，差点删错对象。

**`sudo -n du -sh dir/*` 在 root-only（mode 700）目录上会直接报 `du: cannot access '...'/*`** —— glob 由非 root 的 shell 展开，列不出目录就退化成字面量传进去。这类目录必须走 `sudo -n find dir -maxdepth 1 -mindepth 1 -exec du -sh {} \; | sort -rh`。

### restic 维护前副本目录

`backups/restic-before-staging-maintenance-<date>/` 结构：

```
repository/            ← 维护前完整仓库，回滚用，最大
restore-check/         ← 恢复演练解出的内容
verification.json      ← state: ALL_DATA_VERIFIED + 每个快照 id/时间/original
maintenance-result.json← before/kept/removed 快照 id
preservation.log       ← "no errors were found"
cache/                 ← restic 本地缓存，可删，会自动重建
```

判断：`verification.json` 是 `ALL_DATA_VERIFIED` + 主仓库健康 → `cache/` 可删，`repository/` 是唯一回滚副本，**留给用户决定**。

### 判断某目录能不能删

```bash
grep -rl "<目录名>" /home/ubuntu/hermes-jobs /home/ubuntu/.hermes/scripts /etc/systemd/system /etc/cron* 2>/dev/null
```

只命中 `~/.hermes/state.db`（历史会话记录）说明没有脚本依赖，可删。命中脚本/timer 就要读那个脚本再定。

### 迁移归档：先读 manifest 再删

`migration-to-<target>-<date>/` 这类跨机迁移快照，删前必读 `manifest.json`：

```json
{ "included": ["/etc", "/opt", "/root", ...],
  "note": "Private archive includes credentials; mode 0600" }
```

`included` 里有 `/etc`、`/root`，且 `note` 提到 credentials → **这是含凭据的归档**。迁移完成、目标机已稳定运行后，长期留在盘上本身就是暴露面，删掉比留着安全；但结论里要写明「含凭据」这个理由，不能只说省空间。实测 395 M 的归档，删前确认目标端对应服务（如 `ad-killer`）已在跑。

### 判断机器归属：查 IP 归属，别探 IMDS

要确认某台机是不是云厂商实例（例如怀疑日报标签 `aws` 指向一台独立 EC2）：

```bash
curl -s "http://ip-api.com/json/<public_ip>?fields=as,org,isp"
```

实测本机 → `AS59253 LEASEWEB SINGAPORE`，与标签 `aws` 无关。

**别用 `curl http://169.254.169.254/latest/meta-data/...` 做这个判断** —— 非云环境下该地址不响应，本次实测连续两次把整个调用卡满 300 s 预算。要枚举「有没有第五台」，可靠判据是拉 DNS 区里全部 A 记录，看有没有指向已知 IP 集合之外的目标；比逐个探活更快也更确定。
