# 已知噪音源目录

每条都实测确认过"看着像故障、实际不是"。新增条目必须带判据和实测证据，别凭印象写。

## Emby 反代大量 404/403（`lemon-emos-proxy`）

**现象**：日报单来源 239 条（`业务失败:206、鉴权或权限:31、限流:2`），看着像反代崩了。

**判据**：拿总请求数当分母，按状态码分解。

```bash
docker logs --since 24h lemon-emos-proxy 2>&1 | grep -cE '" (2|3|4|5)[0-9][0-9] '   # 分母
docker logs --since 24h lemon-emos-proxy 2>&1 | grep -oE '" (40[0-9]|42[0-9]|50[0-9]) ' | sort | uniq -c
docker logs --since 24h lemon-emos-proxy 2>&1 | grep " 404 " | grep -oE '"(GET|POST) [^ ]+' \
  | sed -E 's/[0-9]+/N/g' | sort | uniq -c | sort -rn | head
```

实测 1302 个请求 / 206 个 404 / 31 个 403 / 2 个 429：
- 404 全是 `/emby/Items/{vl,ve}-N/Images/Primary`、`/Images/Logo` —— 客户端请求库里不存在的海报，`upstream_status=- request_time=0.000`（连上游都没走到）
- 403 全是 `vb-*` 条目，`upstream_status=403 request_time=0.2` —— 上游自己拒的成人库内容
- 时间均匀铺开全天，没有集中爆发

**结论**：4xx 是客户端/内容语义，错误率 3% 量级，反代健康。**5xx 才算服务端故障。**
别把 404 数量当故障量；也别去查代理配置。

## 反代里留着已退役后端的 site block

**现象**：`aws/代理入口与监控` 76 条，其中 74 条是
`dial tcp 127.0.0.1:8099: connect: connection refused`，`"host":"<某域名>"` 全部相同。

**判据**：三步，缺一不可。

```bash
ss -ltnp | grep 8099                                   # ① 本机有没有监听（实测无）
curl -s -o /dev/null -w '%{http_code}\n' https://<域名>/  # ② 502
grep -n 8099 /etc/caddy/Caddyfile                       # ③ 命中一条 reverse_proxy
```

同时 `systemctl list-units --all | grep -i <后端名>` 为空、`ls -d /opt/<后端>*` 不存在 →
后端**早已退役**，配置里的 `reverse_proxy` 是死记录。

**处置**：删该 site block（Caddyfile 变更 = 生产变更，先报结论再问，别自己动手 caddy reload）。

**反面教训**：看到条数集中在"代理入口与监控"就去查 caddy 日志格式/证书/上游，都是浪费——
`host` 字段单一 + `127.0.0.1:<固定端口>` refused 这个组合本身就指向"配置里有个不存在的后端"。
顺手记一条时间序列辅助判断：`for d in 01 02 03; do journalctl --since "...-$d 00:00" --until "...-$d 23:59" -u caddy -o cat | grep -c '<域名>'; done`
—— 实测 11-05 之前为 0、11-06 起 4→85，说明是**某次改动把死记录带出来了**，不是长期噪音。

## 业务状态字段里的 `timeout=` 大多是预算参数，不是超时错误

**现象**：`vps-la/媒体转存及 EMOS：138 条（超时:113、业务失败:25）`，看着像转存链路大面积超时。

**判据**：先把命中 `timeout` 关键字的行按日志级别切开，再数 ERROR。

```bash
journalctl -u <sync-unit> --since <start> --until <end> -o cat \
  | grep -icE 'timeout|timed out|超时'                    # 总命中
journalctl -u <sync-unit> --since <start> --until <end> -o cat \
  | grep -iE 'timeout|timed out|超时' | grep -c '\[INFO\]'   # 其中 INFO
journalctl -u <sync-unit> --since <start> --until <end> -o cat \
  | grep -iE 'timeout|timed out|超时' | grep -v '\[INFO\]' | tail -5
```

实测 44 条命中里 **34 条是 `[INFO]` 级预算日志**：

```
[INFO] 上传预算 msg=23911 timeout=9834s
[INFO] 下载/续传 msg=23910 cached=0.0MB expected=284.1MB timeout=1800s reserve=3GiB
```

这些是**每轮主动打印的自适应超时预算**，不是错误。真正 ERROR 只有 3 条，其中 1 条
`光鸭失败 … Read timed out (read timeout=60)`，下一轮重试成功，业务状态仍是 SUCCESS。

**结论**：正则 `timeout` 命中率高的来源，先看级别再报数。`[INFO] … timeout=Ns` 一律不计入故障。
同理 `retry_after=`, `cooldown=` 这类参数日志都属同一类。

## xray 的 rejected / unsupported versions 多是扫描器

**现象**：`vps-la/容器/lemon-xray：75 条（业务失败:42、网络连接:30、超时:3）`。

**判据**：先证明代理本身在工作，再分类错误。

```bash
docker logs --since 24h lemon-xray 2>&1 | grep "accepted tcp" | tail -2   # 有活跃转发即正常
docker logs --since 24h lemon-xray 2>&1 | grep -icE 'unsupported versions|no key exchanges|HTTP request to an HTTPS'
```

实测 91 条错误里 14 条是 `unsupported versions` / `no key exchanges`（互联网主动探测 TLS 握手），
其余是连接的正常 rejected；同时段 `accepted tcp … >> direct` 持续出现。
**代理健康判据是「有没有成功转发」，不是「有多少 rejected」。**

## 业务状态写 SUCCESS 但定时那次失败（手工补跑覆盖）

**现象**：日报写 `当前业务状态：统一备份=SUCCESS`，但 `last_success_at` 停在两天前，
或者 job.log 里同一天既有 `FAILED rc=N` 又有 `SUCCESS rc=0`。

**判据**：`jobs/<name>/status` 是**单值文件，每次运行覆盖**；手工补跑成功会把定时失败抹掉。
`automation-observations.py` 只读这个最终值，所以日报永远看不到定时那次失败。

```bash
# ① 当天有几轮、各自结局（这是唯一能看出「定时挂了 + 手工救回」的地方）
grep -E '\] (START|SUCCESS|FAILED|INTERRUPTED) ' jobs/<name>/job.log | tail -10
# ② 脚本 mtime 是否正好落在失败与补跑之间 —— 典型「失败→改脚本→人工重跑」指纹
ls -la --time-style=full-iso <脚本>
```

实测 11-07 11:30 定时失败 `FAILED rc=2`，11:33:02 脚本被改，11:33:21 手工补跑 `SUCCESS rc=0`；
日报只报后者。**报「备份正常」之前必须看 job.log 的 START/结局配对，不能只读 status 文件。**

详细根因分型（含 `set -e` 静默 rc=2）见 `backup-chain-audit` §10.11–§10.12。

## 探针超时但服务正常

**现象**：`aws/代理入口与监控` 一天 130+ 条超时。

```
Ping task 1 failed: Get "https://sub.<PRIVATE_IDENTIFIER>/api/health/ready":
context deadline exceeded (Client.Timeout exceeded while awaiting headers)
```

**判据**：直接实测端点，别信探针。

```bash
for i in 1 2 3; do curl -s -o /dev/null -w "HTTP=%{http_code} time=%{time_total}s\n" \
  --max-time 20 https://<host>/<path>; done
# 顺手探相邻路径，看是不是整体链路抖动
for p in /health /healthz /api/health; do printf "%-14s " "$p"; \
  curl -s -o /dev/null -w "HTTP=%{http_code} t=%{time_total}s\n" --max-time 12 "https://<host>$p"; done
```

实测 200 / 0.2–1.6s，但相邻路径波动到 5.6s → 探测阈值过紧 + CF 隧道抖动，不是服务故障。

**处置**：放宽探针 timeout，或接受噪音。别去"修服务"。

## 云沙箱休眠重连

**现象**：`aws/下载隧道` 几十条 `进程退出`。

```
IB_GATE waiting: platform=suspended, next_check=60s
Connection to ssh.instabox.sh closed by remote host.
IB_GATE running; opening SSH
```

**判据**：出现 `platform=suspended` 且紧跟自动重连日志 = 沙箱按设计休眠。看守护有没有自己接上；接上了就不是故障。

**别做的事**：别因为看到 `closed by remote host` 就去查网络或换 key —— 那是沙箱被挂起，不是认证问题。

## 上游短窗口抖动

**现象**：某容器一天几十上百条同一错误。

```
hongguo_core.utils.HongguoPluginError: 上游响应不是 JSON
```

**判据**：看时间分布，不看总数。

```bash
docker logs <container> --since 24h -t 2>&1 | grep "<错误串>" \
  | awk '{print $1}' | cut -dT -f1-2 | sort | uniq -c
```

20 条全挤在 10 秒内 = 一次上游抖动（上游返了 HTML 错误页而不是 JSON）。均匀铺开才要深查。

## 常驻任务持锁饿死 final job

**现象**：某 `-final` 清理 job 连续多天 `SKIPPED_LOCK` / `exit 75`，`last_success_at` 停在很久以前。

**判据**：先确认常驻任务本身是否正常工作，而不是去救 final。看常驻任务日志里的业务结果，例如 `junk_files=0` / `候选=0` / `剥名完成 20/20`。

**处置**：final 若只是兜底且实际影响为零，可以删掉或错开调度窗口 —— 但这是配置变更，先问，别自己动。

## 瞬时网络失败触发整轮 PARTIAL

**现象**：业务状态 PARTIAL，但绝大部分资源都处理成功。

**判据**：翻当轮明细，通常只有 1–3 条：

```
下发失败: <urlopen error _ssl.c:999: The handshake operation timed out>
```

状态判定只看 `failed` 计数，一条就够把整轮拉成 PARTIAL。

**处置**：瞬时抖动，下一轮自动重试。不要为了让它显示 SUCCESS 去改判定条件 —— 失败就该报。要降噪就在日报层区分"已重试恢复"，不在业务层掩盖。

## SSH 扫描噪音

**现象**：某 VPS 一天数千条 sshd 认证拒绝。

**判据**：确认是公网端口被扫还是真被攻击。

```bash
# 公网端口是否真的暴露
ss -lntp | grep -E ':22|:30023'
# 从外部探一次（结果 closed/filtered = 没暴露）
```

若公网 22 filtered、只有 NAT 高位端口可达，且 `PasswordAuthentication no` —— 纯噪音，不是入侵。

**处置**：低配机（内存 < 100M 可用、无 nft/iptables）装不了 fail2ban，用 sshd 内置限流即可：

```ini
# /etc/ssh/sshd_config.d/01-ratelimit.conf
MaxStartups 10:30:60
LoginGraceTime 20
MaxAuthTries 4
```

`sshd -t` 验证语法后再 `rc-service sshd reload`（Alpine）或 `systemctl reload sshd`。

## DNS 修好之后仍有残余探针超时

**现象**：`sub.<PRIVATE_IDENTIFIER>` 的 `Ping task failed` 已从 136/天 降到个位数，但某个固定时段（如 UTC 22:00–23:00）仍连续出现 40+ 条。

**判据**：三步排除「服务真的挂了」，全部实测：

```bash
# 1. 后端容器有没有重启（有 restart 就是真事件）
docker events --since "<ISO>" --until "<ISO>" --filter "name=<container>"

# 2. CF 隧道有没有重连
journalctl -u <tunnel-unit> --since "<ISO>" --until "<ISO>" | grep -i "reconnect\|disconnect\|error"

# 3. 从报错的那个探针所在主机实测当前延迟
ssh <probe-host> 'for i in 1 2 3; do curl -s -o /dev/null -w "t=%{time_total}s\n" --max-time 8 https://<host>/<path>; done'
```

三项都干净（无重启事件、无重连、当前 0.2–0.3s）→ 该时段是 CF 节点瞬时拥塞，不是服务故障。

**处置**：不改服务。若下期同一时段仍密集出现，再考虑给探针加显式 timeout —— 注意 Komari 的 `ping_tasks` 表**没有 timeout 列**（实测列：`id, weight, name, clients, all_clients, type, target, interval`），要加超时得升级面板版本。

## 模型标签漂移告警

**现象**：`automation-observations.py` 的 alerts 里有 `upstream_model_identity_diff`：

```
{"requested": "gemini-3.8-flash-high", "served": "gemini-3.8-flash-n", "warning_records": 7}
```

**判据**：这是**路由标签与上游实际返回的模型名不一致**，不是错误、不是限流、不影响可用性。配置里的 model ID 只是路由标签，不证明上游真实身份。

**处置**：不改。除非用户主动问模型真实性，否则不在日报里当故障报；要报就明说是标签漂移而非失败。
