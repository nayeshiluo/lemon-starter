# 已知噪音源目录

每条都实测确认过"看着像故障、实际不是"。新增条目必须带判据和实测证据，别凭印象写。

## 探针超时但服务正常

**现象**：`aws/代理入口与监控` 一天 130+ 条超时。

```
Ping task 1 failed: Get "https://sub.<PRIVATE_IDENTIFIER>/api/health/ready":
context deadline exceeded (Client.Timeout exceeded while awaiting headers)
```

**判据**：直接实测端点，别信探针。

```bash
for i in 1 2 3; do curl -s -o /dev/null -w "HTTP=%{http_code} time=%{time_total}s\n" \
  --max-time 20 https://<host>/<path>; done
# 顺手探相邻路径，看是不是整体链路抖动
for p in /health /healthz /api/health; do printf "%-14s " "$p"; \
  curl -s -o /dev/null -w "HTTP=%{http_code} t=%{time_total}s\n" --max-time 12 "https://<host>$p"; done
```

实测 200 / 0.2–1.6s，但相邻路径波动到 5.6s → 探测阈值过紧 + CF 隧道抖动，不是服务故障。

**处置**：放宽探针 timeout，或接受噪音。别去"修服务"。

## 云沙箱休眠重连

**现象**：`aws/下载隧道` 几十条 `进程退出`。

```
IB_GATE waiting: platform=suspended, next_check=60s
Connection to ssh.instabox.sh closed by remote host.
IB_GATE running; opening SSH
```

**判据**：出现 `platform=suspended` 且紧跟自动重连日志 = 沙箱按设计休眠。看守护有没有自己接上；接上了就不是故障。

**别做的事**：别因为看到 `closed by remote host` 就去查网络或换 key —— 那是沙箱被挂起，不是认证问题。

## 上游短窗口抖动

**现象**：某容器一天几十上百条同一错误。

```
hongguo_core.utils.HongguoPluginError: 上游响应不是 JSON
```

**判据**：看时间分布，不看总数。

```bash
docker logs <container> --since 24h -t 2>&1 | grep "<错误串>" \
  | awk '{print $1}' | cut -dT -f1-2 | sort | uniq -c
```

20 条全挤在 10 秒内 = 一次上游抖动（上游返了 HTML 错误页而不是 JSON）。均匀铺开才要深查。

## 常驻任务持锁饿死 final job

**现象**：某 `-final` 清理 job 连续多天 `SKIPPED_LOCK` / `exit 75`，`last_success_at` 停在很久以前。

**判据**：先确认常驻任务本身是否正常工作，而不是去救 final。看常驻任务日志里的业务结果，例如 `junk_files=0` / `候选=0` / `剥名完成 20/20`。

**处置**：final 若只是兜底且实际影响为零，可以删掉或错开调度窗口 —— 但这是配置变更，先问，别自己动。

## 瞬时网络失败触发整轮 PARTIAL

**现象**：业务状态 PARTIAL，但绝大部分资源都处理成功。

**判据**：翻当轮明细，通常只有 1–3 条：

```
下发失败: <urlopen error _ssl.c:999: The handshake operation timed out>
```

状态判定只看 `failed` 计数，一条就够把整轮拉成 PARTIAL。

**处置**：瞬时抖动，下一轮自动重试。不要为了让它显示 SUCCESS 去改判定条件 —— 失败就该报。要降噪就在日报层区分"已重试恢复"，不在业务层掩盖。

## SSH 扫描噪音

**现象**：某 VPS 一天数千条 sshd 认证拒绝。

**判据**：确认是公网端口被扫还是真被攻击。

```bash
# 公网端口是否真的暴露
ss -lntp | grep -E ':22|:30023'
# 从外部探一次（结果 closed/filtered = 没暴露）
```

若公网 22 filtered、只有 NAT 高位端口可达，且 `PasswordAuthentication no` —— 纯噪音，不是入侵。

**处置**：低配机（内存 < 100M 可用、无 nft/iptables）装不了 fail2ban，用 sshd 内置限流即可：

```ini
# /etc/ssh/sshd_config.d/01-ratelimit.conf
MaxStartups 10:30:60
LoginGraceTime 20
MaxAuthTries 4
```

`sshd -t` 验证语法后再 `rc-service sshd reload`（Alpine）或 `systemctl reload sshd`。

## DNS 修好之后仍有残余探针超时

**现象**：`sub.<PRIVATE_IDENTIFIER>` 的 `Ping task failed` 已从 136/天 降到个位数，但某个固定时段（如 UTC 22:00–23:00）仍连续出现 40+ 条。

**判据**：三步排除「服务真的挂了」，全部实测：

```bash
# 1. 后端容器有没有重启（有 restart 就是真事件）
docker events --since "<ISO>" --until "<ISO>" --filter "name=<container>"

# 2. CF 隧道有没有重连
journalctl -u <tunnel-unit> --since "<ISO>" --until "<ISO>" | grep -i "reconnect\|disconnect\|error"

# 3. 从报错的那个探针所在主机实测当前延迟
ssh <probe-host> 'for i in 1 2 3; do curl -s -o /dev/null -w "t=%{time_total}s\n" --max-time 8 https://<host>/<path>; done'
```

三项都干净（无重启事件、无重连、当前 0.2–0.3s）→ 该时段是 CF 节点瞬时拥塞，不是服务故障。

**处置**：不改服务。若下期同一时段仍密集出现，再考虑给探针加显式 timeout —— 注意 Komari 的 `ping_tasks` 表**没有 timeout 列**（实测列：`id, weight, name, clients, all_clients, type, target, interval`），要加超时得升级面板版本。

## 模型标签漂移告警

**现象**：`automation-observations.py` 的 alerts 里有 `upstream_model_identity_diff`：

```
{"requested": "gemini-3.8-flash-high", "served": "gemini-3.8-flash-n", "warning_records": 7}
```

**判据**：这是**路由标签与上游实际返回的模型名不一致**，不是错误、不是限流、不影响可用性。配置里的 model ID 只是路由标签，不证明上游真实身份。

**处置**：不改。除非用户主动问模型真实性，否则不在日报里当故障报；要报就明说是标签漂移而非失败。
