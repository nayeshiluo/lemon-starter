# 多节点 fallback 链超时归因

适用：日报出现「群霸1/2 业务失败 + 超时」这类条目，或任何带 `node=` / `fallback_index=` /
`outcome=` 字段的 LLM 网关日志。**核心是把「N 条 timed_out」换算成「几个请求真的失败了」。**

## 一、先按 request 聚合，别按条数报

一条用户消息会打多个节点，每个节点失败都单独记一行 `LLM attempt finished`。
所以「5 条 timed_out」可能只是 **2 个请求**，其中 1 个后来成功了。

```bash
journalctl -u <bot-unit> --since '<start>' --no-pager \
  | grep -E 'LLM attempt finished' \
  | awk '{for(i=1;i<=NF;i++) if($i ~ /^request=/) r=$i;
          print r, ($0 ~ /outcome=timed_out/?"TIMEOUT":"ok")}' \
  | sort | uniq -c
```

判读规则：

| 同一 request 的行 | 含义 |
|---|---|
| 若干 `TIMEOUT` + 至少 1 个 `ok` | **兜底成功，用户无感**。不是故障 |
| 全部 `TIMEOUT`、无 `ok` | **真实用户可见失败**（那条消息静默无回复）→ 才进「你要做的」 |
| 只有 1 个 `ok` | 正常 |

实测 2026-11-08 群霸2：`timed_out` 5 条 → 只对应 2 个请求。
`064e25eb…` 是 2 TIMEOUT + 1 ok（无感）；`c2e592e5…` 是 3 TIMEOUT 无 ok（真失败）。
**按条数报会把 1 次失败说成 5 次。**

## 二、看失败请求的完整链路字段

```bash
journalctl -u <bot-unit> --since '<hh:mm>' --until '<hh:mm>' --no-pager \
  | grep '<request-id>' | cut -c1-260
```

关注四个字段：`node_budget_s`（分到多少）、`node_elapsed_s`（实际用掉）、
`chain_elapsed_s`（链上累计）、`error_category`。

实测：

```
node=command    fallback_index=0  timed_out  node_budget_s=15.000  node_elapsed_s=15.821  chain_elapsed_s=15.823
node=command_ds fallback_index=1  timed_out  node_budget_s=6.837   node_elapsed_s=6.997   chain_elapsed_s=22.824
node=zhousan    fallback_index=2  timed_out  node_budget_s=6.666   node_elapsed_s=6.990   chain_elapsed_s=29.825
```

## 三、区分「节点坏」和「预算被首跳吃掉」

`node_budget_s` 逐跳递减且后跳只剩个位数 → 不是节点故障，是**首跳超时把总预算吃了一半**，
后跳的预算在物理上不够模型响应。

必须用节点自身的耗时分布做对照，不能凭感觉：

```bash
journalctl -u <bot-unit> --since '<start>' --no-pager \
  | grep 'node=<首跳> ' | grep -oE 'node_elapsed_s=[0-9.]+' | cut -d= -f2 | sort -n \
  | awk '{a[NR]=$1} END{print "n="NR,"min="a[1],"p50="a[int(NR/2)],"p90="a[int(NR*0.9)],"max="a[NR]}'
```

实测 command 节点当日 20 次：`p50=4.116 p90=14.186 max=15.821`，而预算给的是 `15s`。
→ p90 已经贴着预算，长尾必然超时；后跳只剩 6.8s 而 p50 就要 4s+长尾到 14s，**注定失败**。

判据：
- `p90 < node_budget_s * 0.7` 且后跳预算充足 → 节点/上游问题，查节点
- `p90 ≈ node_budget_s` 或后跳预算 < 该节点 `p50` → **预算切分问题**，不是节点坏

## 四、预算切分代码在哪（群霸）

`/home/ubuntu/lemon-group-bot/services/ai_service.py`：

- `_llm_request_budget()` — 小请求 `LLM_SMALL_REQUEST_BUDGET=45.0`，大请求 `100.0`
- `get_node_timeout(node_id, large_request)` — 单节点上限，有 override 文件可覆盖
- fallback 循环里 `if large_request or 0 < used_attempts < max_attempts:` 才做 `remaining / slots`
  切分 —— **小请求的首跳拿 `min(node_timeout, remaining)`，可以吃满自己配置的上限**，
  这就是「首跳 15s + 后两跳各 7s」的来源

要改就改这一处：让小请求的首跳也参与切分（或封顶 `remaining * 0.5`）。
**这是行为变更，改前备份、改后等下一轮真实请求验收；先报结论和代价再问，别自己上。**

## 五、别踩的坑

- 别把 `exit=2` 当崩溃：媒体/清理类 job 的 2 是 PARTIAL/ACTION_REQUIRED 业务码
- 别用 `systemctl is-active` 判健康：`active` 只说明进程在，超时链在 active 状态下照样失败
- 别只报「失败率 21%」：要给「N 次尝试里几个请求真失败、是否兜底」，
  否则用户会以为 21% 的用户消息都没回复
- 节点超时且 `http_status=None` = 撞预算挂起（上游不返 429 而是挂住），不是 4xx/5xx
