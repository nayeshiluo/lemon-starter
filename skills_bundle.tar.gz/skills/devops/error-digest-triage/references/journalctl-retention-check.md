# journal 保留期核验：`-n` 语义随版本变

## 症状

日报长期报 `<host>：journal保留不足24小时，统计仅含留存部分`，但上机看明明保留了十几天。

实测过两台机器同时误报：一台实际保留 14 天，一台 39 天。

## 根因

采集器想取"最早一条"：

```python
run(['journalctl','-q','--no-pager','-o','json','--since','@0','-n','1'])
oldest = 该条时间戳
if oldest > window_start:
    报"保留不足"
```

`--since @0 -n 1` 在**不同 journalctl 版本上返回不同的记录**：

| 主机 | 返回 | 结果 |
|---|---|---|
| naye（Debian） | 最早一条 | 判断正确 |
| vps-la | **最新一条** | `oldest` 恒等于现在 → 永远 > 窗口起点 → 永久误报 |

复现命令（同一时刻两台机器结果不同）：

```bash
journalctl -q --no-pager -o json --since @0 -n 1 \
  | python3 -c "import json,sys,datetime;d=json.loads(sys.stdin.readline());print(datetime.datetime.fromtimestamp(int(d['__REALTIME_TIMESTAMP'])/1e6))"
```

naye → `2026-10-27 12:57:25`（= 真正最早）
vps-la → `2026-11-01 22:55:31`（= 真正最新）

对照 `journalctl -q --no-pager -o short-iso | head -1` 才是真正最早。

## 正确写法：不问"最早是哪条"，只问"窗口起点之前有没有记录"

```python
start = <窗口起点 epoch>
rc, out, _ = run(['journalctl','-q','--no-pager','-o','json',
                  '--since','@0','--until','@'+str(int(start)),'-n','1'])
if rc:
    gaps.append('journal最早留存时间未核实')
elif not out.strip():
    gaps.append('journal保留不足24小时，统计仅含留存部分')
```

语义：窗口起点**之前**一条都没有 → 最早记录晚于起点 → 保留不足。有记录 → 保留足够。不依赖 `-n` 的排序行为，跨版本一致。

## 验证

```bash
# 目标主机实测（S = 窗口起点）
S=$(date -d "-24 hours" +%s)
journalctl -q --no-pager -o json --since @0 --until @$S -n 1 | wc -l   # >0 = 保留足够
```

改完重跑日报：该缺口应消失，同时确认其他主机的缺口**没有**被一起抹掉。

## 保留期的真实决定因素

- 保留期由 `SystemMaxUse` 与**日产量**共同决定，`MaxRetentionSec` 单独说了不算
- `MaxRetentionSec=14day` 在日产量撑满容量时形同虚设：512M 上限 + 400M/天 → 实际只留 < 24 小时
- 想延长保留有两条路，通常要一起用：**扩容上限** + **降日志产量**
- 扩容前先 `df -h /`，至少留 5G 以上余量再往上加

```ini
# /etc/systemd/journald.conf.d/xx-disk-budget.conf
[Journal]
SystemMaxUse=1536M
MaxRetentionSec=14day
```

改完 `systemctl restart systemd-journald`，用 journald 自己的日志确认生效：

```bash
journalctl -u systemd-journald --since "-10min" | grep -o "max [0-9.]*[GM]"
# → System Journal (...) is 438.7M, max 1.5G, 1.0G free
```

`systemctl show systemd-journald -p SystemMaxUse` 可能返回空，别拿它当判据。

## 降产量前先量占比

别默认应用日志是主因。按 ident 统计再决定改哪：

```bash
journalctl --since "-24h" --no-pager -o json | python3 -c "
import json,sys,collections
c=collections.Counter()
for line in sys.stdin:
    try: d=json.loads(line)
    except Exception: continue
    c[d.get('SYSLOG_IDENTIFIER') or d.get('UNIT') or '?']+=1
for k,v in c.most_common(8): print(v,k)"
```

实测某机器结果是 `sshd 11478 / systemd 10323 / systemd-logind 6838 / python 3889` —— 应用只占约 10%，大头是 SSH 会话日志。只降应用日志级别对保留期几乎无帮助。
