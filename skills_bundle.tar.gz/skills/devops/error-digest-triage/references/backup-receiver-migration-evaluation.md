# 备份接收端迁移评估（「把这两份存储转到阿里云」类问题）

用户问「把 X 机的备份存储迁到 Y 机怎么样」时的评估流程。2026-11-18 实测案例：
vps-la 根盘 85% 满卡住 offsite 门禁，评估迁 aliyun。

## 一、先分链，别当成一份「存储」

同一台接收机上往往同时跑多条互不相干的备份链，迁法完全不同：

| 链 | 形态 | 迁移动作 |
|---|---|---|
| `.hermesenc` 统一备份（naye→vps-la scp） | 脚本直传+远端校验，接收端无守护进程 | 数据 rsync 到新机 + 改 `offsite_backup.py` 的 `REMOTE`/`SSH`，改完即生效 |
| restic 异地仓库（naye→vps-la rest-server） | SSH 隧道 + `--append-only` rest-server | 新机部署 rest-server（配额/属主/append-only）+ naye 侧隧道 systemd 单元重指 + 接收端巡检（receiver-health）必须跟迁，否则天天误报 |

判链的实证：`pgrep -af "ssh -NT -L"` 看隧道进程、`grep -E "^SSH|^REMOTE" offsite_backup.py`
看脚本目标、`systemctl list-timers | grep -iE 'prune|restic'` 看接收端运维单元。

## 二、容量与门禁换算

- 目标机 `df -h` 只是第一道；真正要算的是写入方脚本里的门禁公式。
  本例：`free > 4 GiB + 包体积`（960M 包 → 需 5.26 GiB）。目标机余量要按
  「传完之后还剩多少」倒推，不是只看当前 free。
- 迁走不等于断档：旧机上的历史包/仓库要先 rsync 到新机再停写；restic 仓库迁移
  要保留属主与权限（root 建仓库会污染属主 → rest-server 5xx，详见
  `restic-offsite-repo-ops` §四，owner 规则必须照搬）。

## 三、带宽实测

- 跨境链路容量决定可行性。方法：源机上 `dd if=/dev/urandom of=/tmp/bwtest.bin bs=1M count=8`
  → `scp -o Compression=no` 到目标机 → 用 `date +%s` 差算 MB/s，测完两端 `rm`。
- 判据与脚本对齐：`offsite_backup.py` 的 `scp_timeout()` 按 0.8 MB/s 下限、上限 1800s；
  实测 naye→aliyun 0.89 MB/s ⇒ 960M 包约 18 分钟，可用。低于 0.55 MB/s 会超时。
- 测速前先确认自己在哪台机上跑。本例曾把 naye 上测的数误记成「aws 测的」——
  日报来源标签不等于真实主机（`hostname` + `~/.ssh/config` 先对照）。源机搞错，
  测出的数对不上链路。
- 源机直连目标机需要交互确认（root 密钥/known_hosts）会被工具安全层拦：用
  clarify 向用户要一次授权口径；超时未答就如实报「该方向带宽未测」，不能拿
  同量级机房的直觉替它背书。

## 四、汇报形状

给用户的结论要含：每条链的源/协议/迁法差异、已实测的数字（带宽、磁盘、门禁需值）、
唯一未测项明说、建议的分步（低风险链先迁+真实备份验收，再决定高链）。
