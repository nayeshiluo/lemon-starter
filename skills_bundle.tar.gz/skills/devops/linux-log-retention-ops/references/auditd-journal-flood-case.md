# 案例：auditd 双写把 journal 淹到只剩几小时（2026-11-06 实测）

一台生产机（systemd 252 / Debian 12，磁盘 53% 占用）。症状不是用户直接报的，
而是排障时发现的副作用：**某 Telegram Bot 三天只有 106 行日志，journal 最早记录只到几小时前。**

## 现场数据

```
群霸 3 天日志总量:      106 行（101 INFO + 5 WARNING，0 ERROR）
journal 总占用:         494.8M
journal 最早记录:       当天 19:37（当时是 22:40 左右）
/etc/systemd/journald.conf:  只有 [Journal]，无任何配置

两小时日志来源排名:
  301,533  auditd.service
  255,534  audit          ← 内核审计，占 99%
    1,138  cron.service
    1,087  lemon-userbot.service
      702  sgb-embed.service
       79  lemon-group-bot2.service
```

**判读要点**：`auditd.service` 和 `audit` 是同一个东西的两条通道（单位名 + 内核标识），
加起来占 99%。业务服务本身日志量极小（个位数到千位数），所以**不是上限太小，是源头刷屏**。

## 审计规则（判定能不能动的前提）

```bash
sudo auditctl -l
-a always,exit -F arch=b64 -S rename,rmdir,unlink,... -F dir=/home/ubuntu  -F key=naye_data_delete
-a always,exit -F arch=b64 -S rename,rmdir,unlink,... -F dir=/opt          -F key=naye_data_delete
-a always,exit -F arch=b64 -S rename,rmdir,unlink,... -F dir=/var/lib/docker/volumes -F key=naye_volume_delete
-a always,exit -F arch=b64 -S execve,execveat -F euid=0   -F key=naye_privileged_exec
-a always,exit -F arch=b64 -S execve,execveat -F euid=1000 -F key=naye_agent_exec
-w /etc/audit  -p wa -k naye_audit_config
-w /etc/sudoers -p wa -k naye_privilege_config
```

这是**数据保护审计**（防误删、追踪特权执行），必须保留。
爆量来源是 `-S execve -F euid=0`：agent 每次 `sudo` 执行一条命令就产生一组审计事件。
规则不动，只关转发。

## 通道拆分（关键：两条独立来源）

```bash
sudo journalctl --since '2 min ago' -o json | python3 -c "
import sys, json
from collections import Counter
c = Counter()
for l in sys.stdin:
    try: d = json.loads(l)
    except: continue
    c[(d.get('_TRANSPORT'), d.get('SYSLOG_IDENTIFIER'))] += 1
for k,n in c.most_common(): print(n, k)
"
```

输出：

```
  107  transport=syslog  ident=audispd     ← auditd 的 syslog 插件转发
   93  transport=audit   ident=audit       ← journald 直接读内核 netlink
```

两条通道要分别关，这就是为什么单一开关总是不彻底。

## 四个坑的踩坑顺序（真实过程）

### 坑 1：drop-in 被同目录更高编号覆盖

先建 `/etc/systemd/journald.conf.d/10-no-audit.conf`（`Audit=no`），重启后无效。
`cat-config` 显示实际顺序：

```
# /etc/systemd/journald.conf
[Journal]
# /etc/systemd/journald.conf.d/10-no-audit.conf
Audit=no
# /etc/systemd/journald.conf.d/60-disk-budget.conf
[Journal]
# /etc/systemd/journald.conf.d/90-audit.conf
Audit=yes          ← 这个盖掉了前面的 no
```

**教训**：`cat-config` 里最后一个同名键才是生效值；排查前先列全部 drop-in 及其数字前缀。

### 坑 2：改配置漏了 daemon-reload

只做 `systemctl restart systemd-journald`，配置不重读。必须
`systemctl daemon-reload && systemctl restart systemd-journald`。

### 坑 3：audispd 的 syslog 插件独立于 `Audit=`

`transport=syslog ident=audispd` 这部分不受 journald 配置控制，走
`/etc/audit/plugins.d/syslog.conf` 的 `active = yes`。
改成 `active = no` 并重启 auditd 后，这条通道从 6920 条/40s 降到 226 条/40s。

注意：这个文件非 root 读不到（`Permission denied`），确认改动要加 `sudo`。

### 坑 4：真开关是 socket，不是配置项

关掉前两项后，`transport=audit` 仍有 2827 条/40 秒。查证：

```bash
systemctl list-units 'systemd-journald*'
# systemd-journald-audit.socket  active running
systemctl status systemd-journald-audit.socket
#   Loaded: static
#   Listen: audit 1 (Netlink)
sudo auditctl -s
#   pid 1613385        ← 内核审计订阅者是 auditd，不是 journald
```

`Audit=no` 已生效（cat-config 两处都是 no），但 journald 仍读 audit netlink。

**必须两步**：

```bash
sudo systemctl stop systemd-journald-audit.socket
sudo systemctl mask systemd-journald-audit.socket   # static 单元，mask 才防重启恢复
sudo systemctl restart systemd-journald             # 重启才释放已打开的 fd
```

只 stop 不 restart 无效（进程仍持有旧 fd），这一步做完从 3813 条/90 秒直接归零。

## 验证输出（修复后）

```bash
START=$(systemctl show systemd-journald -p ActiveEnterTimestamp --value)
# journald 启动: Fri 2026-11-06 22:56:11 CST
```

```
总行 76 / audit 相关 0
     33  transport=syslog  ident=sudo
     17  transport=stdout  ident=uvicorn
     11  transport=stdout  ident=python
      5  transport=kernel  ident=systemd
      3  transport=syslog  ident=CRON
```

四项验收全部通过：

| 项 | 结果 |
|---|---|
| audit 进 journal | 0 |
| `audit.log` 增量 | 12 秒 +211,279 bytes（审计仍在记录） |
| 规则条数 | 12 条不变 |
| 业务日志 | 824 行 / 2 分钟正常 |

## 回滚

```bash
sudo systemctl unmask systemd-journald-audit.socket
sudo systemctl restart systemd-journald
sudo cp <备份>/90-audit.conf.orig /etc/systemd/journald.conf.d/90-audit.conf
sudo cp <备份>/audit-syslog.conf.orig /etc/audit/plugins.d/syslog.conf
sudo systemctl daemon-reload && sudo systemctl restart systemd-journald auditd
```

## 附带的容量事实

同一台机还有 `/etc/systemd/journald.conf.d/60-disk-budget.conf`：

```ini
SystemMaxUse=512M
SystemKeepFree=2G
MaxRetentionSec=14day
```

512M 上限遇上 25 万行/小时，就是「保留几小时」。压掉源头后同样 512M 够用两周。
**结论：这个案例不需要改容量参数，只需要断掉刷屏源。**
如果一开始就去调 `SystemMaxUse`，会把 512M 变 2G、几小时变一天，问题依然存在。
