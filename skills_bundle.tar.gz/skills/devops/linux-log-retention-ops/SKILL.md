---
name: linux-log-retention-ops
description: "Use when 日志只留几小时/查不到历史/journal 暴涨被抓凶。"
version: 1.0.0
author: 柠檬
license: MIT
platforms: [linux]
metadata:
  hermes:
    category: devops
    tags: [logging, journald, auditd, retention, disk, triage]
    related_skills: [host-operations-evidence, error-digest-triage, selfhosted-service-audit]
---

# Linux 日志保留与容量治理

处理「排障时发现历史日志没了」「journal 占用异常」「某个服务把日志刷爆」这类问题。
核心判断：**是写得太多，还是上限太小**——这两条路的修法完全相反。

## When to Use

- 用户说「查不到几天前的日志」「日志怎么只有几个小时」「journal 太大/涨得太快」
- 服务排障时发现 journal 保留窗口远短于预期（明明配了 14 天，实际只有几小时）
- 需要在不动业务服务的前提下把日志保留从几小时提到几天/几周
- 怀疑某个服务/内核子系统在刷日志

## 铁律：先归因，再调容量

**不要第一步就改 `SystemMaxUse`。** 容量调大只是把「几小时」变成「几十小时」，
真凶还在按 99% 的占比刷。先量出「谁在写」，再决定是压源头还是扩上限。

## 第一步 来源归因（只读，一条命令）

按 unit/标识符统计一段时间内的行数占比：

```bash
sudo journalctl --no-pager --since '2 hours ago' -o json 2>/dev/null | python3 -c "
import sys, json
from collections import Counter
c = Counter()
for line in sys.stdin:
    try: d = json.loads(line)
    except: continue
    c[d.get('_SYSTEMD_UNIT') or d.get('SYSLOG_IDENTIFIER') or d.get('_COMM') or '?'] += 1
for u, n in c.most_common(12): print(f'{n:>8}  {u}')
print('总计:', sum(c.values()))
"
```

判读：
- 单一来源 > 50% → 就是它，去查它的写入路径（本节以下的 auditd 是典型）
- 均匀分布且总量不大 → 是**上限太小**，直接看第二步的保留参数
- 业务服务自己刷屏 → 去改该服务的日志级别，不要动 journald

## 第二步 容量与保留策略（三处，别只看一处）

```bash
sudo systemd-analyze cat-config systemd/journald.conf | grep -E '^#\s*/|^\[Journal\]|^[A-Z]'
sudo journalctl --disk-usage
```

关键参数与典型误配：

| 参数 | 作用 | 误配后果 |
|---|---|---|
| `SystemMaxUse` | 磁盘占用上限 | 设成 512M 而有大户刷屏 → 保留只剩几小时 |
| `SystemKeepFree` | 至少保留的空闲空间 | 与上者冲突时以先触发者为准 |
| `MaxRetentionSec` | 按时间的硬上限 | 设了 14day 但被容量先挤掉，等于没设 |

**drop-in 优先级**：`/etc/systemd/journald.conf.d/` 下**文件名数字大的后加载、覆盖小的**。
排查「我明明配了 no 为什么还是 yes」时，`cat-config` 输出里**最后一个同名键才是实际生效值**。

```bash
# 看完整加载顺序（谁覆盖谁一目了然）
sudo systemd-analyze cat-config systemd/journald.conf | grep -E '^# /|^Audit=|^SystemMaxUse'
```

## 第三步 判断两条路

| 现象 | 结论 | 动作 |
|---|---|---|
| 单一来源占绝大多数 | 源头刷屏 | 压源头（见第四步），不要扩容量 |
| 日志量正常但保留仍短 | 上限太小 | 调 `SystemMaxUse`，并确认 `MaxRetentionSec` 不是瓶颈 |
| 两者都有 | 先压源头再扩容量 | 顺序反了会白调 |

## 第四步 压源头：auditd 双写（最常见的隐形大户）

内核审计默认**双写**：`/var/log/audit/audit.log` + 转发一份进 journal。
规则里只要有 `-S execve -F euid=0`（记录每个 root 执行），量就是十万级/小时。

**先确认规则是正经业务**（别为了省日志削掉安全审计）：

```bash
sudo auditctl -l              # 看规则内容与 key
sudo auditctl -s              # 看 pid / enabled，pid 指向当前内核审计订阅者
```

规则看起来是数据保护（删文件/特权执行/sudoers 变更）就**保留规则、只关转发**。
三处独立开关，缺一个都停不干净：

| 层 | 位置 | 作用 | 关闭方式 |
|---|---|---|---|
| 应用转发 | `/etc/audit/plugins.d/syslog.conf` | audispd 把每个事件再发一份 syslog | `active = no` |
| 内核通道 | journald `Audit=` | journald 是否读内核 audit netlink | `Audit=no` |
| socket 激活 | `systemd-journald-audit.socket` | **static 单元，`Audit=` 管不到它** | `mask` + 重启 journald |

第四步完整操作（含备份）：

```bash
B=~/.hermes/backups/journald-$(date +%Y%m%dT%H%M%S); mkdir -p "$B"
sudo cp /etc/systemd/journald.conf.d/*.conf /etc/audit/plugins.d/syslog.conf "$B"/

# 1) 停 audispd 转发
sudo sed -i 's/^active = yes/active = no/' /etc/audit/plugins.d/syslog.conf

# 2) 关内核通道（注意别被同名 drop-in 覆盖）
sudo sh -c 'printf "[Journal]\nAudit=no\n" > /etc/systemd/journald.conf.d/90-audit.conf'
sudo systemctl daemon-reload          # 漏了这步配置不生效

# 3) 关 socket 并重启 journald（重启才释放已打开的 netlink fd）
sudo systemctl stop systemd-journald-audit.socket
sudo systemctl mask systemd-journald-audit.socket
sudo systemctl restart systemd-journald
sudo systemctl restart auditd
```

## 验证（必须按 journald 启动时间切片）

`--since '2 min ago'` 会把重启**之前**的消息算进来，得出「没修好」的错误结论。
用 unit 的实际启动时间做切点：

```bash
START=$(systemctl show systemd-journald -p ActiveEnterTimestamp --value)
sudo journalctl --no-pager --since "$START" -o json | python3 -c "
import sys, json
from collections import Counter
c = Counter()
for l in sys.stdin:
    try: d = json.loads(l)
    except: continue
    c[(d.get('_TRANSPORT'), d.get('SYSLOG_IDENTIFIER'))] += 1
audit_n = sum(n for (tr,i),n in c.items() if tr=='audit' or i in ('audit','audispd'))
print('总行', sum(c.values()), '| audit 相关', audit_n)
"
```

**四项都要验，缺一不可：**

1. `audit 相关 = 0`（源头已断）
2. `/var/log/audit/audit.log` 仍在增长 —— `stat -c %s` 隔 10 秒对比，**增量 > 0 才证明审计没被误伤**
3. `sudo auditctl -l | wc -l` 规则条数不变
4. 业务服务日志仍正常落入：`journalctl --since "$START" | grep -cE '<你的服务名>'`

## 回滚

```bash
sudo systemctl unmask systemd-journald-audit.socket
sudo systemctl restart systemd-journald
# 配置文件从备份目录拷回后 daemon-reload + restart
```

## Pitfalls

- **只看 `SystemMaxUse` 不看实际写入速率**：512M 上限配 25 万行/小时的来源 = 几小时就滚完
- **`Audit=no` 以为就够了**：它管不到 `systemd-journald-audit.socket`（static 单元），也管不到 audispd 的 syslog 插件
- **改了 systemd 配置不 `daemon-reload`**：`restart` 不重读 drop-in，配置白改
- **停 socket 后不重启 journald**：进程仍持有已打开的 netlink fd，消息照进
- **用 `--since '2 min ago'` 验证**：窗口包含修复前的消息，会导致误判失败
- **为了降噪删审计规则**：先看规则 key 是不是数据保护；只关转发不动规则
- **把 `MaxRetentionSec` 当保证**：容量先满时它不生效，两个参数要一起看
- `ausearch` 通常在 `/sbin`（不在普通用户 PATH），关掉 journal 转发后它是主要查询手段：
  `sudo /sbin/ausearch -k <key> -ts today`

## 实测数据（2026-11-06，一台 53% 占用的生产机）

| 指标 | 治理前 | 治理后 |
|---|---|---|
| audit 进 journal | 23,870 行 / 5 分钟（占 80%） | **0** |
| journal 保留窗口 | 几小时 | **14 天**（受 `MaxRetentionSec`） |
| 磁盘占用 | 535M 且持续增长 | 481M 稳定 |
| 审计规则 | 12 条 | 12 条不变 |
| `audit.log` 写入 | 正常 | 正常（12 秒 +211KB） |

完整案例（含每一步的真实输出、四个坑的踩坑顺序）见
`references/auditd-journal-flood-case.md`。
