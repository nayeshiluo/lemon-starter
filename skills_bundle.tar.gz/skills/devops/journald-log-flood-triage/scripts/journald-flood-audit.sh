#!/bin/bash
# journald 日志洪水诊断（只读）
# 用法: bash journald-flood-audit.sh [业务关键字，可选]
set -uo pipefail

KW="${1:-}"
echo "==================== 1. 容量与保留窗口"
sudo journalctl --disk-usage 2>/dev/null
START=$(systemctl show systemd-journald -p ActiveEnterTimestamp --value 2>/dev/null)
echo "journald 启动于: $START"
echo "最早一条: $(sudo journalctl --no-pager 2>/dev/null | head -1 | cut -c1-60)"

echo
echo "==================== 2. 配置（⚠ 注意 drop-in 顺序，后面的覆盖前面的）"
sudo systemd-analyze cat-config systemd/journald.conf 2>/dev/null \
  | grep -E '^#\s*/|^\[Journal\]|SystemMaxUse|SystemKeepFree|MaxRetentionSec|^Audit='

echo
echo "==================== 3. 谁在刷（按单位/标识聚合，近 2 小时）"
sudo journalctl --no-pager --since '2 hours ago' -o json 2>/dev/null | python3 -c "
import sys, json
from collections import Counter
c = Counter()
for line in sys.stdin:
    try: d = json.loads(line)
    except: continue
    c[d.get('_SYSTEMD_UNIT') or d.get('SYSLOG_IDENTIFIER') or d.get('_COMM') or '?'] += 1
tot = sum(c.values())
for u, n in c.most_common(12):
    print(f'{n:>8}  {n*100.0/max(tot,1):5.1f}%  {u}')
print(f'--- 总计 {tot}')
"

echo
echo "==================== 4. 按 transport 细分（决定用哪个开关）"
echo "-- 窗口 A：近 10 分钟（含修复前的历史，可能误导）"
sudo journalctl --no-pager --since '10 min ago' -o json 2>/dev/null | python3 -c "
import sys, json
from collections import Counter
c = Counter()
for line in sys.stdin:
    try: d = json.loads(line)
    except: continue
    c[(d.get('_TRANSPORT') or '-', d.get('SYSLOG_IDENTIFIER') or '-')] += 1
for (tr, ident), n in c.most_common(8):
    hint = ''
    if tr == 'audit': hint = '  <- mask systemd-journald-audit.socket'
    elif ident == 'audispd': hint = '  <- plugins.d/syslog.conf active=no'
    print(f'{n:>7}  transport={tr:<10} ident={ident:<16}{hint}')
"

echo
echo "-- 窗口 B：journald 本次启动之后（这才是「当前是否已修」的判据）"
sudo journalctl --no-pager --since "$START" -o json 2>/dev/null | python3 -c "
import sys, json
from collections import Counter
c = Counter(); tot = 0
for line in sys.stdin:
    try: d = json.loads(line)
    except: continue
    tot += 1
    c[(d.get('_TRANSPORT') or '-', d.get('SYSLOG_IDENTIFIER') or '-')] += 1
audit_n = sum(n for (tr, i), n in c.items() if tr == 'audit' or i in ('audit', 'audispd'))
print(f'总行 {tot} / audit 相关 {audit_n}   <- 应为 0')
for (tr, ident), n in c.most_common(8):
    print(f'{n:>7}  transport={tr:<10} ident={ident}')
"

echo
echo "==================== 5. audit 规则（判断能否保留审计、只关 journal 副本）"
echo "规则数: $(sudo auditctl -l 2>/dev/null | wc -l)"
sudo auditctl -l 2>/dev/null | head -12

echo
echo "==================== 6. 审计日志文件是否独立存在"
sudo stat -c '  %s bytes  %y  %n' /var/log/audit/audit.log 2>/dev/null || echo "  无 /var/log/audit/audit.log"
echo "  ausearch: $(command -v ausearch || echo /sbin/ausearch) $([ -x /sbin/ausearch ] && echo 可用)"

echo
echo "==================== 7. 各开关当前状态"
printf '  %-42s %s\n' 'systemd-journald-audit.socket' "$(systemctl is-enabled systemd-journald-audit.socket 2>/dev/null)/$(systemctl is-active systemd-journald-audit.socket 2>/dev/null)"
printf '  %-42s %s\n' 'auditd plugins.d/syslog.conf' "$(sudo grep -E '^active' /etc/audit/plugins.d/syslog.conf 2>/dev/null | tr -d ' ' || echo 读不到)"
printf '  %-42s %s\n' 'auditd' "$(systemctl is-active auditd 2>/dev/null)"
printf '  %-42s %s\n' 'systemd-journald' "$(systemctl is-active systemd-journald 2>/dev/null)"

if [ -n "$KW" ]; then
  echo
  echo "==================== 8. 业务日志存活检查（关键字: $KW）"
  echo "  近 2 分钟: $(sudo journalctl --no-pager --since '2 min ago' 2>/dev/null | grep -c "$KW") 行"
  echo "  近 24 小时: $(sudo journalctl --no-pager --since '24 hours ago' 2>/dev/null | grep -c "$KW") 行"
fi

echo
echo "提示：判定结论看第 3/4 节占比；修复顺序必须是"
echo "  4.1 改最后加载的 drop-in  →  4.2 daemon-reload + restart journald"
echo "  →  4.3 audispd syslog active=no + restart auditd"
echo "  →  4.4 mask systemd-journald-audit.socket + restart journald（这步才归零）"
