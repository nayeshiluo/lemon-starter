---
name: journald-log-flood-triage
description: "Use when journal 日志只留几小时或某一类日志占满 journal。"
version: 1.0.0
author: 柠檬
license: MIT
platforms: [linux]
metadata:
  hermes:
    tags: [journald, auditd, logging, retention, systemd, triage]
    related_skills: [host-operations-evidence, selfhosted-service-audit, error-digest-triage]
---

# journald 日志被淹没的排障

业务日志只保留几小时、翻不到历史、`journalctl --since '3 days ago'` 只有几十行 ——
多数不是「服务没打日志」，而是**别的进程把 journal 刷爆了**。

## When to Use

- 「日志怎么只有几小时」「查不到昨天的错误」
- `journalctl` 总量很小但磁盘占用不小，或反过来：占用大却只覆盖几小时
- 某类日志（审计/内核/容器）疑似占满 journald 配额
- 排障时发现服务日志稀疏，怀疑日志被覆盖而非未产生

**先确认不是这两个假象**：服务本身就没打日志（打点太少）、或 `--since` 语法写错。
用 `journalctl -u <svc> --no-pager | wc -l` 看该服务全量行数，个位数就是真的没打。

## 第 1 步：量化现状（三个数字）

```bash
# ① 总量与保留策略
sudo journalctl --disk-usage
sudo systemctl show systemd-journald -p ActiveEnterTimestamp --value   # 本次启动时间
sudo journalctl -u <svc> --no-pager | head -1                          # 最早一条 = 实际保留窗口

# ② 配置里的配额
sudo systemd-analyze cat-config systemd/journald.conf | grep -E '^#\s*/|SystemMaxUse|MaxRetentionSec|^Audit='
```

判读：

| 现象 | 含义 |
|---|---|
| `SystemMaxUse` 小（如 512M）+ 占用已达上限 | 容量到顶，按时间滚动，保留窗口 = 容量 / 写入速率 |
| 占用远小于 `SystemMaxUse` 但窗口很短 | 被别的服务刷爆过，旧日志已被 vacuum |
| `MaxRetentionSec` 设了但没生效 | 容量先到顶，时间策略来不及生效 |

## 第 2 步：归因（谁在刷）

按来源聚合，**不要按服务名猜**：

```bash
sudo journalctl --no-pager --since '2 hours ago' -o json | python3 -c "
import sys, json
from collections import Counter
c = Counter()
for line in sys.stdin:
    try: d = json.loads(line)
    except: continue
    c[d.get('_SYSTEMD_UNIT') or d.get('SYSLOG_IDENTIFIER') or d.get('_COMM') or '?'] += 1
for u, n in c.most_common(10): print(f'{n:>7}  {u}')
print('total:', sum(c.values()))
"
```

实测案例（2026-11-06）：两小时 56 万行，**`auditd.service` + `audit` 占 99%**，
`SystemMaxUse=512M` 被瞬间填满，业务日志只剩几小时。

再按 transport 细分，这决定后面用哪个开关：

```bash
sudo journalctl --no-pager --since '5 min ago' -o json | python3 -c "
import sys, json
from collections import Counter
c = Counter()
for line in sys.stdin:
    try: d = json.loads(line)
    except: continue
    c[(d.get('_TRANSPORT'), d.get('SYSLOG_IDENTIFIER'))] += 1
for k, n in c.most_common(8): print(f'{n:>6}  transport={k[0]} ident={k[1]}')
"
```

| transport | 来源 | 关它要动哪里 |
|---|---|---|
| `audit` | journald 自己监听的内核 audit netlink | **mask `systemd-journald-audit.socket`** |
| `syslog` + `ident=audispd` | auditd 的 syslog 插件转发 | `/etc/audit/plugins.d/syslog.conf` |
| `journal` / `stdout` / `kernel` | 正常业务与内核 | 不要关 |

## 第 3 步：确认审计规则值不值得保留

**不要看到 `audit` 多就直接关。** 先看规则在监控什么：

```bash
sudo auditctl -l
```

数据保护类规则（删除/重命名监控、`execve` 特权执行、`/etc/sudoers` 变更）属于**必须保留**，
尤其防止 agent 误删生产数据的那类。要关的只是「复制进 journal 这一份」，
不是审计本身 —— 审计事件继续写 `/var/log/audit/audit.log`。

## 第 4 步：四层关闸（缺一层就不生效）

实测从 3800 条/90 秒降到 0，需要**四层全做**。任何一层漏掉都还会继续灌。

### 4.1 配置层：`Audit=no`（管内核 netlink 的配置语义）

```bash
# 现状：可能已有别的 drop-in 在覆盖你
sudo systemd-analyze cat-config systemd/journald.conf | grep -E '^#\s*/|^Audit='
```

**坑：drop-in 按文件名字典序加载，后面的覆盖前面的。**
实测存在 `90-audit.conf` 写着 `Audit=yes`，把先建的 `10-no-audit.conf` 完全覆盖。
改的时候要改**最后加载的那个**（数字最大的），或者直接改它而不是新增。

### 4.2 重载层：`daemon-reload`

```bash
sudo systemctl daemon-reload          # 漏了这步，改配置等于没改
sudo systemctl restart systemd-journald
```

**坑：只 `restart` 不 `daemon-reload`，systemd 用旧缓存，配置看起来改了但行为没变。**

### 4.3 插件层：auditd 的 syslog 转发

```bash
sudo sed -i 's/^active = yes/active = no/' /etc/audit/plugins.d/syslog.conf
sudo systemctl restart auditd
```

**坑：这部分完全不受 `Audit=` 控制。** `audisp-syslog` 插件会把每个 audit 事件
再以 syslog 形式写一份进 journal，`_TRANSPORT=syslog`、`ident=audispd`。
只管 `Audit=` 时这部分占了绝大多数（实测 6920 条/40 秒 → 226 条）。

重启 auditd **不会丢规则**（规则持久化在 `/etc/audit/rules.d/`），但会重新加载：

```bash
ls /etc/audit/rules.d/ ; sudo auditctl -l | wc -l   # 重启后核对条数
```

### 4.4 Socket 层（真正的开关）

```bash
systemctl status systemd-journald-audit.socket      # Listen: audit 1 (Netlink)
sudo systemctl stop systemd-journald-audit.socket
sudo systemctl mask systemd-journald-audit.socket
sudo systemctl restart systemd-journald             # 关键：不重启 fd 不释放
```

**两个坑叠加在这里：**

1. 这个 socket 是 **static** 的，`Audit=no` 配置**管不到它**。它是内核 audit netlink 的持有者。
2. 光 `stop` 没效果 —— journald 进程启动时已经打开了 netlink fd，`stop` 只阻止新的激活。
   **必须 `mask` 之后 `restart systemd-journald`**，让新进程在 socket 不存在的情况下初始化。

这一步做完才真正归零。前面三层只能把量降一个数量级。

## 第 5 步：验收（四项，缺一不可）

```bash
# ① audit 是否真的停了：以 journald 本次启动时间为界，别看自然时间窗口
START=$(systemctl show systemd-journald -p ActiveEnterTimestamp --value)
sudo journalctl --no-pager --since "$START" -o json | python3 -c "
import sys, json
from collections import Counter
c = Counter(); tot = 0
for line in sys.stdin:
    try: d = json.loads(line)
    except: continue
    tot += 1
    c[(d.get('_TRANSPORT') or '-', d.get('SYSLOG_IDENTIFIER') or '?')] += 1
audit_n = sum(n for (tr, i), n in c.items() if tr == 'audit' or i in ('audit', 'audispd'))
print(f'总行 {tot} / audit 相关 {audit_n}')      # audit 相关必须是 0
"

# ② 审计能力仍在：audit.log 还在增长
a=$(sudo stat -c '%s' /var/log/audit/audit.log); sleep 12
b=$(sudo stat -c '%s' /var/log/audit/audit.log); echo "增量 $((b-a)) bytes"   # 必须 > 0

# ③ 规则条数与查询工具
sudo auditctl -l | wc -l
sudo /sbin/ausearch --version

# ④ 业务日志没被吞
sudo journalctl --no-pager --since '2 min ago' | grep -cE '<业务关键字>'
```

**验收坑：用 `--since '2 min ago'` 会把 journald 重启前的消息算进来**，
看起来「audit 还有 2700 条」。必须用 journald 的 `ActiveEnterTimestamp` 切片。

## 保留策略怎么配

**容量优先于时间。** `MaxRetentionSec=14day` 在容量先到顶时不会生效。

```ini
# /etc/systemd/journald.conf.d/60-disk-budget.conf
[Journal]
SystemMaxUse=512M      # 按磁盘与业务量定，别占满根分区
SystemKeepFree=2G      # 保底留给系统
MaxRetentionSec=14day  # 容量够用时才起作用
```

修复后估算保留窗口：`SystemMaxUse ÷ (业务日志行数/分钟 × 平均行长)`。
实测业务量约 25 行/分钟时，512M 可撑 14 天以上（受限的是 `MaxRetentionSec`）。

**不要靠调大 `SystemMaxUse` 解决被淹没的问题** —— 那是给洪水腾地方，
涨 4 倍也只能从几小时撑到十几小时。

## 回滚

```bash
sudo systemctl unmask systemd-journald-audit.socket
sudo systemctl restart systemd-journald
# 需要恢复 syslog 转发时
sudo sed -i 's/^active = no/active = yes/' /etc/audit/plugins.d/syslog.conf
sudo systemctl restart auditd
```

改前必备份：`90-audit.conf`（或实际生效的那个 drop-in）、`plugins.d/syslog.conf`、
`60-disk-budget.conf`、`journalctl --disk-usage` 输出。

## 汇报口径

- **审计能力没削弱**要单独说明：规则条数、`audit.log` 增长、`ausearch` 可用，三项给数据
- 说清「关的是复制进 journal 的那一份，不是审计本身」
- 给出回滚命令，别只给「已修复」
- 保留窗口的改变要量化（改前几小时 → 改后几天），不要只说「变好了」

## 相关

同类「日志/容量异常」先看 `error-digest-triage`（判读每日错误汇总）；
判断是否该动服务时走 `host-operations-evidence`（控制入口与内存口径）。
