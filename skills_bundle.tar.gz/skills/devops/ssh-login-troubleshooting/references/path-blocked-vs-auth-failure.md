# 路径阻断 vs 认证失败：多台同时连不上的取证流程

案例时间：2026-11-04（北京时间 11:06–11:13 采样）。用户报告"三台 VPS 全连不上，Codex 里洛杉矶也连不上"，但另一台主机正常。

## 结论形状

服务端三台**全部健康**，失败发生在客户端到服务器的路径上，连接根本没到达 sshd。判断依据只有一条，但它是决定性的：

> 服务端日志里该客户端 IP **一条记录都没有**。

TCP 没建立 → key、算法、`authorized_keys`、fail2ban 全部无关 → 改服务端只会制造新变量。

## 取证顺序（全部只读）

### 1. 先确认"哪台能连、哪台不能"，按网段分组

```bash
# 本地别名清单
grep -E '^\s*Host ' ~/.ssh/config

# 逐个别名测通道，同时取远端时间用于时区对齐
for h in <别名...>; do
  printf '%s ' "$h"
  timeout 15 ssh -o BatchMode=yes -o ConnectTimeout=8 "$h" 'echo OK; date "+%F %T %Z"' 2>&1 | tr '\n' ' '
  echo
done
```

实测结果：AWS 那台 `OK`；RackNerd / HostPapa / Hytron 三台全失败。共同点是 **IP 归属不在 AWS 段**，不是端口号——失败集合里同时有 22 和 2222/30023。

### 2. 服务端授权与封禁（证明不是 key 问题）

```bash
for f in /root/.ssh/authorized_keys /home/*/.ssh/authorized_keys; do
  [ -f "$f" ] || continue
  echo "--$f ($(stat -c %a:%U "$f"))"
  ssh-keygen -lf "$f" 2>/dev/null
done

sshd -T 2>/dev/null | grep -iE '^(permitrootlogin|pubkeyauthentication|passwordauthentication|port|maxauthtries)'
ss -lntp | grep -i ssh

fail2ban-client status sshd | grep -Ei 'currently banned|total banned'
iptables -S f2b-sshd | grep -c REJECT
```

实测：手机两把 key 都在授权列表里；三台 `Currently banned: 0`、f2b 链 0 条 REJECT；无 `not in PubkeyAcceptedAlgorithms`。

> Alpine 机没有 journal，用 `tail -n 2000 /var/log/messages`；`journalctl` 返回 0 行是正常的。

### 3. 从第三方主机验证端口映射活着（不泄露 IP 给扫描网站）

```python
import socket, subprocess, re
for alias in ['<别名...>']:
    g = subprocess.run(['ssh','-G',alias], capture_output=True, text=True).stdout
    host = re.search(r'^hostname (.+)$', g, re.M).group(1)
    port = int(re.search(r'^port (\d+)$', g, re.M).group(1))
    try:
        s = socket.create_connection((host, port), timeout=8)
        print(alias, port, s.recv(60)[:20].decode(errors='replace')); s.close()
    except Exception as e:
        print(alias, port, 'FAIL', type(e).__name__)
```

三台都拿到 `SSH-2.0-OpenSSH_*` → NAT 映射、sshd、防火墙放行全都没问题。

**替代方案不要用**：在线端口检测站（check-host 之类）。它会记录目标 IP，和"隐匿源站"的要求冲突。

### 4. 用日志反证"客户端没来过"

```bash
(journalctl -u ssh -u sshd --since "7 days ago" --no-pager || tail -n 2000 /var/log/messages) \
  | grep -Ei 'Failed publickey|Connection closed by authenticating|maximum auth|not in PubkeyAccepted' \
  | grep -v '<本机出口 IP>' | tail -8
```

命中的全是互联网爆破流量（`Invalid user supervisor`、`root` 试错），**没有一条来自用户手机 IP**。这同时排除了"被封"和"key 被拒"。

## 判据汇总

| 观察 | 排除掉什么 |
|---|---|
| 服务端零记录 | 认证失败、算法拒绝、fail2ban 封禁、sshd 配置 |
| 第三方主机能读到 banner | NAT 映射、端口未放行、服务未启动 |
| 第三方主机能完整登录 | 授权文件、key 权限、属主 |
| 失败项横跨 22 / 2222 / 30023 | "某个端口被封" |
| 两个不同 App 同时失败同一台 | 单一 App 的配置或实现问题 |

剩下唯一解释：**客户端所在网络到这些境外 IP 的直连被阻断或干扰**。

## 处置

1. **立即可用**：`ProxyJump` 经一台能连的主机跳转。手机端在 ServerCat 条目里填跳板；本机端
   ```
   Host <目标别名>
       HostName <目标IP>
       Port <端口>
       User root
       ProxyJump <能连的别名>
   ```
   前提：能连的那台到目标也通（本例已用 `ssh -o BatchMode=yes` 验证）。
2. **长期**：把入口挪到 Cloudflare 隧道/橙云域名，或换到线路可达的节点。跳板是止血，不是终态。
3. **不要做的事**：不动 sshd、不追加公钥、不重启服务、不把端口换一遍试运气。

## 复现时的坑

- `ss -lntup | head -14` 截断了监听列表，导致一度误判"某台代理服务没在跑"（实际 OpenRC 里 `started`）。
  判断服务是否监听要 `grep -E ':(端口)\b'`，不要 `head`。
- OpenRC 机器用 `rc-status --all` / `rc-update show`，`systemctl list-units` 返回空不代表服务没起。
- 用户先前成功连接过，**不能**当作当前网络可用的证据；Wi-Fi / 蜂窝 / 代理切换后表现会完全不同。
