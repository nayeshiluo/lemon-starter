# 按 key 指纹归因 + 客户端静默断开（2026-11-05 实录）

场景：用户报「洛杉矶 VPS 的 codex 的 SSH 连接好像断了」。服务端是 RackNerd 洛杉矶（`vps-la`，非标端口 2222），手机端是 Codex App。

结论：**服务端全程健康，是手机端那条连接在 17:13（北京）之后静默消失，且客户端再没发起过任何连接。** 全程只读，没有改 sshd、没有重启任何服务。

## 1. 先证通道本身通（避免一上来就查认证）

```bash
grep -n -A6 -E "vps-la|<IP>" ~/.ssh/config          # 别名解析出的端口/用户/key
timeout 8 bash -c 'cat < /dev/null > /dev/tcp/<IP>/2222' && echo OPEN || echo CLOSED
timeout 25 ssh -o ConnectTimeout=10 -o BatchMode=yes <别名> 'echo OK; hostname; uptime; who'
```

实测：2222 `OPEN`，`echo OK` 正常，主机名与预期一致。**注意 22 端口 `Connection refused` 是设计内行为**（端口早已迁到 2222），不要当故障报。

## 2. 指纹 → 设备台账（本次的关键动作）

```bash
ssh-keygen -lf /root/.ssh/authorized_keys
```

输出形如：

```
256 SHA256:F0k2...UB0 lemon-aws-racknerd-admin-20260917 (ED25519)
256 SHA256:JyXS...GSQ chatgpt-la-vps (ED25519)
256 SHA256:ogcI...i3g servercat-la-iphone-20261025 (ED25519)
256 SHA256:0umi...peI codex-app-iphone-20261025 (ECDSA)
256 SHA256:Uvqu...NWo beszel-hub-20261027 (ED25519)
```

注释命名规范（`<用途>-<机器>-<设备>-<日期>`）本身就是设备台账，这是最省事的一步——所以新增 key 时务必写注释，别留空。

```bash
# 每把 key 近 7 天登录次数
journalctl -u ssh --since "7 days ago" --no-pager \
  | grep "Accepted publickey" | grep -o "SHA256:[A-Za-z0-9+/=]*" | sort | uniq -c | sort -rn
```

实测结果：`codex-app-iphone` 833 次、`servercat-la-iphone` 30 次、`chatgpt-la-vps` 2 次、`beszel-hub` 1 次。

```bash
# 该 key 最后 5 次成功登录
journalctl -u ssh --since "7 days ago" --no-pager \
  | grep "Accepted publickey" | grep "0umim1eu" | tail -5 | cut -c1-140
```

```
Nov 05 09:13:03 ... Accepted publickey for root from <YOUR_SERVER_IP> port 50732 ... ECDSA SHA256:0umim1eu...
Nov 05 09:13:17 ... (×3 并发)
Nov 05 09:13:20 ...  ← 最后一条
```

## 3. 频率基线：为什么"1 小时 45 分没连接"才算异常

```bash
journalctl -u ssh --since "3 days ago" --no-pager | grep "Accepted publickey" \
  | grep "0umim1eu" | awk '{print $1,$2,substr($3,1,2)}' | uniq -c | tail -20
```

```
28 Nov 04 10     46 Nov 04 11     72 Nov 04 12     12 Nov 04 13
37 Nov 04 14     28 Nov 04 16     18 Nov 04 22     31 Nov 04 23
...
 5 Nov 05 09     ← 到 09:13:20 戛然而止
```

关键：Nov 04 `17:00–21:59` 也有 5 小时空档（用户没用 App），所以**空档本身不是证据**。真正的异常是 09:13 之后不仅没有成功记录，连**失败记录也没有** —— 请求根本没到 sshd。

## 4. 排除服务端所有"看不见的层"

| 检查 | 实测 | 结论 |
|---|---|---|
| `fail2ban-client status sshd` | Currently banned: 0，Total banned 16 | 没封手机 IP |
| `iptables -S \| grep 103.151` | 空 | 无 DROP/REJECT |
| `nft list ruleset \| grep 103.151` | 空 | 同上 |
| `ss -tn state established '( sport = :2222 )'` | 8 条，7 条来自运维机，**0 条来自手机** | 连接已消失 |
| `nf_conntrack_count / max` | 1097 / 65536 | 表没满 |
| `dmesg -T \| grep -iE 'conntrack\|nf_\|drop'` | 无相关记录 | 无内核丢包证据 |
| `journalctl --since 09:00 --until 09:20 \| grep -iE 'link\|eth0\|network\|oom'` | 空 | 无网络/OOM 事件 |
| `MaxStartups / LoginGraceTime` | 默认 10:30:100 / 60s | 未触发 |

补充判据：sshd listener 进程 uptime 只有 4h18m，但子会话 uptime 21h —— 这是 `systemctl reload ssh`（exec 新主进程、保留子会话）的特征，时间点（06:39 UTC）远早于 09:13 的断点，**不是掉线原因**。

## 5. 顺带发现的隐患（未证实，只作为下次的检查项）

远端 codex app-server 版本 `0.157.0-alpha.10`（已跑 36 天），运维机客户端 `0.163.0`。远端 app-server 在断点前后一直健康（每 4.5 分钟拉一次 models，`200 OK`，日志到 10:52 仍在写），所以**本次断连与版本无关**。但 app-server 协议跨 6 个版本是否兼容没有验证；若客户端重连时报协议错，先比两端 `codex --version` 再谈升级。

## 6. 工具坑：不要递归 grep Codex session 日志

排查中执行 `grep -rn "<PRIVATE_IDENTIFIER>" ~/.codex/` 直接吐出 **452K 字符**（session rollout `.jsonl` 里嵌了整段工具输出），把上下文冲掉。正确做法：

```bash
# 按 mtime 缩小范围
find ~/.codex/sessions -name "*.jsonl" -newermt "-2 days" | head -5

# 需要读对话内容时用 python 解析 role/content，只取尾部
python3 - <<'PY'
import json,glob
f=sorted(glob.glob('/home/ubuntu/.codex/sessions/2026/11/05/*.jsonl'))[-1]
msgs=[]
for line in open(f):
    try: d=json.loads(line)
    except: continue
    p=d.get('payload',{})
    if d.get('type')=='response_item' and p.get('type')=='message':
        txt=''.join(c.get('text','') for c in p.get('content',[]) if isinstance(c,dict))
        if txt.strip(): msgs.append((p.get('role'),txt.strip()))
for r,t in msgs[-6:]: print('===',r,'===\n',t[:1200])
PY
```

同类：`~/.codex/logs_2.sqlite` 用只读方式查（`file:...?mode=ro`），先看 `pragma table_info` 再取最近 N 条，别 `select *`。

## 7. 汇报模板（实测有效）

> vps-la 服务器侧完全正常，是手机端那条连接静默消失了。
> - 2222 通、5 个 key 全在、fail2ban 封禁 0、手机 IP 无 DROP
> - codex app-server 跑 36 天，10:52 仍 `200 OK`
> - 手机 key 最后成功 `09:13:20 UTC`（北京 17:13），之后 1h45m 零连接、零失败、零断开
> - 判断：不是认证失败、不是封禁、不是服务端踢人，客户端没再发起连接
> - 下一步：手机上完全退出 App 重开，重连时我盯日志

要点：把"最后成功时刻 + 零记录 + 已排除项"三件套摆出来，用户不会追问"你确定不是服务器的问题吗"。
