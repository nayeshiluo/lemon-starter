# 案例：一台手机经代理连三台 VPS 全部失败（2026-11-05）

## 报障演进

1. 「洛杉矶 vps 的 codex 的 ssh 连接好像断了」——单台、单客户端。
2. 按铁律五归因：服务端零记录，结论「客户端静默消失」，给设备侧动作。
3. 用户执行后回：「codex 的 ssh 连接显示离线，手机的 ssh 设备显示洛杉矶 vps、屌毛 vps、香港 nat 全部连接失败」——**升级为单客户端 vs 三台主机**，转铁律六。

## 三台目标（不同机房，全部非标端口）

| 别名 | 机房 | SSH 端口 |
|---|---|---|
| `vps-la` | RackNerd 洛杉矶 | 2222 |
| `vps-hk` | 香港 NAT | 30023 |
| `diaomao` | HostPapa | 2222 |

## 取证结果

### ① 服务端健康（独立视角真登录，不是只测端口）

```
vps-la     OK racknerd-fe424f4 13:20:09Z
vps-hk     OK u2112-7gvo21xl   13:20:10Z
diaomao    OK ubuntu           13:20:16Z
```

三台 `/dev/tcp` 全部 `PORT OPEN`。

### ② 跨主机 key 指纹一致

三台 `authorized_keys` 里手机那把 ECDSA key 指纹完全相同（`SHA256:0umim1eu…`），
vps-hk 上注释名不同（`phone-codex-ecdsa`）但指纹一致——**注释名不是身份，指纹才是**。
结论：不是授权丢失、不是 key 被换、不是某台漏配。

### ③ 按主机统计客户端出口网段（决定性证据）

```bash
for h in vps-la vps-hk diaomao; do
  printf "\n== %s ==\n" "$h"
  ssh -o ConnectTimeout=10 "$h" "journalctl -u ssh --since '90 min ago' --no-pager \
    | grep -E '103\.151\.|103\.172\.|154\.88\.|83\.147\.' | tail -5 | cut -c1-145; \
    echo \"[matches=\$(journalctl -u ssh --since '90 min ago' --no-pager | grep -cE '103\.151\.|103\.172\.|154\.88\.|83\.147\.')]\""
done
```

结果：

```
== vps-la ==  [matches=5]   ← 全部集中在同一分钟内
== vps-hk ==  [matches=0]
== diaomao == [matches=0]
```

### ④ 断点前那次连接是成功的

```
12:49:40 Accepted publickey ... from <YOUR_SERVER_IP>  ECDSA SHA256:0umim1eu…
12:49:42 Accepted publickey ... from <YOUR_SERVER_IP>
12:49:43 Accepted publickey ... from <YOUR_SERVER_IP>
12:49:45 Accepted publickey ... from <YOUR_SERVER_IP>
12:49:46 Accepted publickey ... from <YOUR_SERVER_IP>
```

客户端侧（Codex App）同一时间窗：

```
12:49:48 WARN failed to upgrade control socket websocket connection:
          WebSocket protocol error: Handshake not finished
12:49:50 TRACE app-server request: initialize connection_id=4
         （随后 thread/list、threadSection/list、skills/list、plugin/installed 全部正常返回）
12:50:21 WARN WebSocket protocol error: Connection reset without closing handshake
```

**之后到采样时刻（约 25 分钟）三台全部零记录，客户端也没再重试。**

## 根因

手机走代理出网（出口 `<YOUR_SERVER_IP>` / `<YOUR_SERVER_IP>`，同一云厂商段，且短时间内在多个地址间跳）。
代理节点在 `12:50:21` 把长连接 RST 掉，之后手机对三台服务器**一个包都没再发**。

- 不是服务器踢人：sshd 侧那次会话是正常 `Accepted`、无 `Received disconnect`、无 `error`。
- 不是被封：三台 `fail2ban` 当前封禁 0，手机 IP 不在任何 REJECT 规则里。
- 不是 conntrack / 内核丢包：`1097/65536`，`dmesg` 无相关记录。
- 不是单台被墙：三个不同机房同时归零，物理上不可能。

## 本次踩的两个取证坑

### 坑 1：引号写坏 → 假的「零记录」

第一次取数写成外层单引号 + 内层双引号含竖线正则：

```bash
ssh "$h" 'journalctl ... | grep -E "103\.151\.|154\.88\." ...'   # 坏
```

远端报 `bash: 154.88.: command not found`，grep 整体失效、返回空。
**空结果恰好就是本技能最核心的证据形态**——差一点把"命令写坏"当成"包没到服务器"。
修法：外层双引号 + 内层单引号，并且**先在已知有记录的主机上验 `matches>0`**，再解释其他主机的 0。

### 坑 2：远端日志时区不一致

`diaomao` 上 `date -u` 报 `13:20 UTC`，但它的 `journalctl` 打印的是 `21:20`（本地 CST）。
拿它和 vps-la 的 UTC 日志直接对比，会凭空多出 8 小时偏移，把断点错配到别的事件上。
取数时 `date` 与 `date -u` 一起打，汇报里标明日志时间是哪种。

## 给用户的结论口径

> 三台服务端均已实测登录成功、key 指纹一致、无封禁；手机在 20:49 之后对三台零发包。
> 问题在手机到代理节点这一段，不在服务器。

动作只给客户端侧：浏览器开网页区分"断网 / 代理坏" → 查订阅、节点、规则 → 代理 App 杀掉重开或临时直连。
另提示：三台都是非标端口（`2222`/`30023`），代理规则常只放行 `80/443`，规则刚更新过时这是首要嫌疑。

## 反面清单

- ❌ 因为"三台全挂"就去改任何一台 `sshd` / 追加公钥 / 放宽算法
- ❌ 因为客户端连不上就回滚刚做完的升级（升级与本次故障无关，`daemon version` 三字段已对齐、`codex exec` 实跑通过）
- ❌ 把 grep 写坏后的空输出当成"服务端零记录"直接下结论
- ❌ 跨主机比对日志不先对齐时区
