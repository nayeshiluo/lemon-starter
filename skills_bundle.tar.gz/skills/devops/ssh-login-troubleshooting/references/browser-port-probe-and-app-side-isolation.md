# 浏览器端口探针与 App 侧隔离（2026-11-05 实测）

一次"三台全连不上"的排障，最后被一个 10 秒的浏览器测试推翻结论。
价值不在案例本身，在于**它证明"零记录"有两种截然相反的成因，而 sshd 日志无法区分**。

## 场景

- 客户端：iPhone，Codex App + ServerCat，经代理出网
- 目标：洛杉矶 RackNerd `:2222`、香港 NAT `:30023`、HostPapa `:2222`（三个不同机房）
- 用户原话：「洛杉矶 vps 的 codex 的 ssh 连接好像断了」→ 后续升级为「手机 ssh 设备显示洛杉矶 vps、屌毛 vps、香港 nat 全部连接失败」

## 按顺序拿到的证据

### 1. 服务端健康（逐台真登录，不是只测端口）

```bash
for h in vps-la vps-hk diaomao; do
  printf "%-10s " "$h"
  timeout 15 ssh -o ConnectTimeout=8 -o BatchMode=yes "$h" 'echo OK $(hostname) $(date -u +%H:%M:%SZ)' 2>&1 | tail -1
done
```

三台全部 `OK`。再两两反向互测（diaomao→vps-la、vps-hk→diaomao 等），七条路径全 OPEN。
**三个不同机房同时被墙在物理上不成立**，这一步就把"服务器/线路"排掉了。

### 2. 跨主机同 key 指纹比对

```bash
ssh-keygen -lf ~/.ssh/authorized_keys
```

三台里手机那把 ECDSA key 指纹一致（`SHA256:0umim1eu...`），注释分别是 `codex-app-iphone-20261025` / `phone-codex-ecdsa`。
→ 不是授权丢失、不是 key 换了。

### 3. 按主机统计客户端出口网段（铁律六的标准动作）

```bash
for h in vps-la vps-hk diaomao; do
  printf "\n===== %s =====\n" "$h"
  ssh -o ConnectTimeout=10 "$h" "journalctl -u ssh --since '90 min ago' --no-pager 2>/dev/null \
    | grep -E '103\.151\.|103\.172\.|154\.88\.|83\.147\.' | tail -5 | cut -c1-145; \
    echo \"[matches=\$(journalctl -u ssh --since '90 min ago' --no-pager 2>/dev/null | grep -cE '103\.151\.|103\.172\.|154\.88\.|83\.147\.')]\""
done
```

结果：vps-la `matches=5`（全在断点那一刻），vps-hk `0`，diaomao `0`。
**到这里，"客户端出网通道断了"看起来已经成立。**

### 4. 反证：App 侧日志显示曾经连上过

```bash
python3 - <<'EOF'
import sqlite3, datetime
c = sqlite3.connect("file:/root/.codex/logs_2.sqlite?mode=ro", uri=True)
for ts, lv, tg, body in c.execute(
    "select ts,level,target,substr(feedback_log_body,1,230) from logs where ts > ? order by id asc", (<YOUR_USER_IDENTIFIER>,)):
    t = datetime.datetime.fromtimestamp(ts).strftime("%H:%M:%S")
    b = (body or "").replace("\n", " ")
    if any(k in b.lower() for k in ("connect","initializ","error","warn","auth","handshake")):
        print(f"{t} {lv}: {b}")
EOF
```

关键几行：

```
12:49:48 WARN  failed to upgrade control socket websocket connection: WebSocket protocol error: Handshake not finished
12:49:50 TRACE app-server request: initialize connection_id=ConnectionId(4)
12:50:21 WARN  ... Connection reset without closing handshake
```

→ 升级后的服务端**确实被 App 连上过并跑通了 `initialize`**，31 秒后被 RST。升级本身没问题。

### 5. 决定性探针：浏览器打开 SSH 端口

让用户在手机 Safari 打开 `http://<IP>:2222`。用户回报「无法解析响应」。

服务端同时刻日志：

```
13:32:12 banner exchange: Connection from <YOUR_SERVER_IP> port 5616: invalid format
13:32:13 banner exchange: Connection from <YOUR_SERVER_IP> port 5626: invalid format
13:32:13 banner exchange: Connection from <YOUR_SERVER_IP> port 5640: invalid format
13:32:13 banner exchange: Connection from <YOUR_SERVER_IP> port 5644: invalid format
```

**这四条把第 3 步的结论彻底推翻**：`<YOUR_SERVER_IP>` 是同一台手机的新出口，包一直能到 `:2222`。
所以"三台全零"的真实含义是 **App 从未发起 SSH 连接**，不是出网断了。

## 两个必须记住的判读

### `无法解析响应` 是阳性信号

浏览器打开 SSH 端口必然报这个（或"无法解析服务器响应"/乱码）。它意味着：

1. TCP 三次握手完成
2. 服务器回了 SSH banner
3. 浏览器按 HTTP 解析失败

**"无法连接 / 超时 / 服务器无响应"才是阴性。** 这两个错在用户嘴里很容易混，要追问原话。

### `banner exchange: ... invalid format` 不是异常

它是 sshd 记录"有人在非 SSH 客户端上连了 SSH 端口"的正常行为。不要当攻击、不要当配置问题、不要去查 `sshd_config`。

## App 侧隔离（探针证明可达之后）

- App 把一次失败缓存成"离线"后**不再自动重试**：断连后 1 小时 45 分零连接尝试，用户手动点重连也没有包发出
- 最有效动作是**删除该环境/主机条目重新添加**，不是原地编辑（已保存的私钥/主机字段是只读展示态）
- 追问一句可区分方向：**点重连是"立刻弹离线"还是"转圈几秒才失败"**——立刻弹 = 本地状态；转圈 = 服务端应当同时看到包
- 用户操作期间保持 `journalctl -f` 实时盯，避免"我点了"和"日志没有"之间各说各话

## 顺带记下的两个坑

### 出口 IP 会轮换，别拿旧 IP 当身份

同一台手机在不同时间的出口：`<YOUR_SERVER_IP>`（美国云厂商）→ `<YOUR_SERVER_IP>` → `<YOUR_SERVER_IP>`（加拿大 Bell）。
按"我记得的那个 IP"去 grep 全量日志，会稳定报零记录并得出错误结论。
**先取时间窗内全部非爆破记录，再从里面认领新 IP。**

### 远端 grep 正则的引号

`ssh host '... grep -E "103\.151\.|154\.88\."'` 会被拆词，实测输出 `bash: 154.88.: command not found`，
grep 静默失效返回空 —— **而空结果正好是"服务端零记录"这个核心证据**，会把结论带偏到完全相反的方向。
外层双引号 + 内层单引号；写完先在已知有记录的主机上跑同一个正则，看到 `matches>0` 才相信其他主机上的 `0`。

### 远端 journalctl 时区不一致

同一批机器里，某台 `date -u` 报 `13:20 UTC`，`journalctl` 却打 `21:20`（本地 CST）。
跨主机比对前先各打一次 `date` 和 `date -u`，否则会把 8 小时偏移当成"断连发生在几点"，错配到错误的事件。

## 最终根因：VPN 按 App 分流（本节是上面探针之后才拿到的）

探针只证到「端口可达、App 零尝试」。**再往下还有一层：为什么 App 零尝试？**

### 第 6 步：同 App 换目标（不是换客户端）

用户主动给了关键信息：「我链接本机的 ssh 是接通状态」，追问后确认本机是 naye（国内，装 Hermes 那台）。

| 同 App（ServerCat）连 | 结果 |
|---|---|
| naye（国内） | 接通 |
| 洛杉矶 `:2222` / 香港 `:30023` / HostPapa `:2222` | 全 `Failed to connect` |

**App 本身工作正常**，坏的只是"到海外非标端口"这条路。

### 第 7 步：tcpdump 抓 SYN，钉死"包没出手机"

```bash
tcpdump -i any -n -l 'tcp port 2222 and not host <本机IP>' > /tmp/tcpdump-2222.log 2>&1 &
sleep 10; pgrep -a tcpdump; head -3 /tmp/tcpdump-2222.log   # 必须看到 listening on
```

用户点重连后：**零 SYN**，抓包进程稳定跑了 4 分钟且 `listening on` 正常。
同一次会话里，浏览器开同一端口立刻留下 `banner exchange`。

→ 同一台手机、同一个端口：**浏览器有包、App 零包**。包在手机本地就被分流规则决定了走向。

### 结论

代理软件开了**按 App 分流**：浏览器在代理列表里，ServerCat / Codex 不在，走直连。
国内直连洛杉矶 / 香港的非标端口必被墙。用户原话「我用的 vpn 跟这个有关系吗」——
**他自己早就摸到边了，是我绕了半轮才回到这条线上。**

### 三层证据的合并读法

| 证据 | 单独看会得出 | 合起来才是 |
|---|---|---|
| 三台 `matches=0` | 出网断了 | 只是"没有 SSH 连接" |
| 浏览器探针有 `banner exchange` | 端口可达，App 有问题 | 端口可达，但只是浏览器可达 |
| 同 App 连国内通 | App 没问题 | App 没问题，是到海外的路径 |
| tcpdump 零 SYN（App 点击时） | 包没出手机 | 分流把 App 的流量送去了直连 |

四步缺任何一步都会得出片面结论。**顺序不能省：探针 → 同 App 换目标 → tcpdump。**

### 处置（全在客户端）

1. 代理切**全局模式**，立刻重试
2. 或把 SSH App 加入代理列表；或给目标 IP 逐条加规则
3. 长期把 SSH 入口挪到 `443`（穿透性最好，规则集和网络环境都不拦）

