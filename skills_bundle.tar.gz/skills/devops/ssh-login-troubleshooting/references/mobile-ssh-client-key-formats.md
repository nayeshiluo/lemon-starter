# 移动端 SSH 客户端私钥格式兼容实录（2026-10-25）

iOS SSH 客户端对私钥格式的支持差异实测记录。服务端为 Ubuntu 24.04 / OpenSSH 9.6p1。

## 症状演进（同一台机器，两个不同 App）

| 阶段 | 客户端表现 | 服务端日志 |
|---|---|---|
| A | `No available authentication methods`（ServerCat，用老 RSA key） | 有 `ssh-rsa not in PubkeyAcceptedAlgorithms` |
| B | `尚不支持 OpenSSH 私钥。请将 Ed25519 或 ECDSA 密钥导出为 PKCS#8 或 SEC1 PEM 格式` | **零记录** |
| C | `无法通过 SSH 与 <主机> 建立连接。请检查主机名、端口、网络、凭据及 SSH 服务是否正确。` | **零记录** |

关键判读：**服务端零记录 = 请求没到 sshd**。A 是服务端拒绝（有日志），B/C 是客户端本地拦截或 TCP 没通（无日志）。三者根因完全不同，不能混着修。

## 已验证的工具事实

| 操作 | 实际结果 |
|---|---|
| `ssh-keygen -p -m PKCS8 -f ed25519_key -N ""` | 命令报成功（`Your identification has been saved`），但**首行仍是 `<YOUR_PRIVATE_KEY>`**。OpenSSH 不支持 ED25519 导出 PKCS#8 |
| `ssh-keygen -t ecdsa -b 256 -f k -N "" -m PEM` | 输出 `<YOUR_PRIVATE_KEY>`（SEC1，227 字节 / 5 行） |
| 对 ECDSA 再跑 `ssh-keygen -p -m PKCS8` | 输出 `<YOUR_PRIVATE_KEY>`（PKCS#8，241 字节 / 5 行） |
| `openssl pkey -in pkcs8 -noout -text` | `Private-Key: (256 bit)` —— 格式合法 |
| `openssl ec -in sec1 -noout -text` | `read EC key` + `Private-Key: (256 bit)` —— 格式合法 |
| 两种格式 `ssh -i` 实连 | 均返回成功，服务端日志出现 `Accepted publickey ... ECDSA SHA256:<fp>` |

结论：**要喂只吃 PEM 的 App，直接生成 ECDSA，不要在 ED25519 上做格式转换。**

## 生成与验证

```bash
D=~/.hermes/workspace/ssh-keys

# SEC1 (BEGIN EC PRIVATE KEY)
ssh-keygen -t ecdsa -b 256 -f "$D/key" -N "" -m PEM -C "<用途>-$(date +%Y%m%d)"

# PKCS#8 (BEGIN PRIVATE KEY)
cp "$D/key" "$D/key_pkcs8"
ssh-keygen -p -m PKCS8 -f "$D/key_pkcs8" -N ""

# 结构验证
openssl pkey -in "$D/key_pkcs8" -noout -text | head -3
openssl ec   -in "$D/key"       -noout -text | head -3

# 无 BOM / 无 CRLF
head -c 3 "$D/key" | od -An -tx1     # 期望 2d2d2d
grep -c $'\r' "$D/key"               # 期望 0

# 交付前实连（各自独立测）
ssh -i "$D/key"       -o IdentitiesOnly=yes root@<host> 'echo OK'
ssh -i "$D/key_pkcs8" -o IdentitiesOnly=yes root@<host> 'echo OK'
```

交付：聊天正文贴私钥会被脱敏成 `[REDACTED PRIVATE KEY]`，只能走文件路径；额外给 `.pem` 后缀副本供"导入文件"路径使用。

## 踩过的坑

1. **同一个用户的多个 App 不能共用同一格式假设**。ServerCat 吃 OpenSSH 格式的 ED25519，另一个 App 拒绝同一把 key。按 App 分别适配。
2. **`-m PKCS8` 对 ED25519 静默无效**。命令回显成功会让人误以为转换完成，实际首行没变。转换后必须 `head -1` 核对首行。
3. **"私钥已保存"是只读态**。原地编辑粘贴不会覆盖旧内容，用户会反复报"还是同一个错"。必须删除主机条目重建。
4. **格式错误与网络错误被同一个 App 报成不同文案，但服务端都零日志**。区分靠用户描述的具体报错文案 + 报错是否在点击连接后立刻出现（立刻 = 本地校验；转圈几秒 = 网络）。
5. **不要拿几小时前的成功记录当当前网络可用**。用户网络（Wi-Fi / 蜂窝 / 代理出口）会变，早先连得上不代表现在连得上。

## 对照实验（本次会话的下一步，尚未拿到结果）

服务端零日志时，最快的分层方法是让用户用**已经能连通的 App** 连同一台机器：

- 能连 → 网络 OK，问题在被排查的那个 App
- 不能连 → 网络层问题（代理/蜂窝封锁 22 端口）

同时核对 App 内端口是否为 22 —— 端口填错的表现与网络不通完全一致（服务端零日志）。

> 本会话在此步结束，未取得对照结果，故未形成"该 App 可用配置"的结论。
