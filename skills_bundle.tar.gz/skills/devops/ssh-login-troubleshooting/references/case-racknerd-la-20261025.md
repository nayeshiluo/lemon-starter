# 案例：洛杉矶 RackNerd 的 ServerCat 登录失败（2026-10-25）

## 用户现象

iPhone 上 ServerCat 连 `<PRIVATE_IDENTIFIER>:22`，报错：

```
Connecting to <PRIVATE_IDENTIFIER> port 22...
TCP connection established...
Server version: SSH-2.0-OpenSSH_9.6p1 Ubuntu-3ubuntu13.20
Probing authentication methods... OK
Authenticating using key naye1.pem...
Error: No available authentication methods
```

关键判读：`Probing authentication methods ... OK` 说明 **TCP + 版本协商 + 算法协商全部成功**，问题只在认证阶段。这一行是区分"网络不通"和"认证被拒"的分水岭。

## 目标对象核对（用户中途质疑"没弄错吧"）

| 核对项 | 结果 |
|---|---|
| 截图里的目标 IP | `<PRIVATE_IDENTIFIER>` |
| 本地 `~/.ssh/config` 的 `Host vps-la` | `HostName <PRIVATE_IDENTIFIER>`，User root，IdentityFile `lemon_racknerd_admin` |
| IP 归属（ipinfo.io） | Los Angeles / California / US，AS36352 HostPapa（RackNerd） |
| 服务端自述公网 IP | `<PRIVATE_IDENTIFIER>` |
| 主机名 | `racknerd-fe424f4` |

同一台，无歧义。把这张表直接给用户，质疑一次解决。

## 服务端证据

采样时间：`2026-10-25 02:07 UTC`（= 北京 10:07，与用户截图时间吻合）。服务端时区 `Etc/UTC`。

```
Oct 25 02:07:07 sshd[982995]: userauth_pubkey: signature algorithm ssh-rsa not in PubkeyAcceptedAlgorithms [preauth]
Oct 25 02:07:07 sshd[982995]: Connection closed by authenticating user root <YOUR_SERVER_IP> port 39068 [preauth]
Oct 25 02:07:09 sshd[982997]: userauth_pubkey: signature algorithm ssh-rsa not in PubkeyAcceptedAlgorithms [preauth]
Oct 25 02:07:10 sshd[982997]: userauth_pubkey: signature algorithm ssh-rsa not in PubkeyAcceptedAlgorithms [preauth]
Oct 25 02:07:10 sshd[982997]: error: maximum authentication attempts exceeded for root from <YOUR_SERVER_IP> port 39074 ssh2 [preauth]
```

生效配置：

```
port 22
permitrootlogin without-password
pubkeyauthentication yes
passwordauthentication no          ← 密码通道已关闭，没有退路
kbdinteractiveauthentication no
maxauthtries 6
pubkeyacceptedalgorithms ... rsa-sha2-512,rsa-sha2-256   ← 没有 ssh-rsa
```

`authorized_keys` 原有 2 把：`lemon-aws-racknerd-admin-20260917`、`chatgpt-la-vps`（均 ED25519）。

fail2ban：active，`maxretry=4`、`bantime=12h`，当前封 5 个 IP，经逐个核对全是爆破者（试 `usuario`/`admin`/`deploy`/`user`/`shutdown`）。失败来源 `<YOUR_SERVER_IP>`（AWS 香港段）**未被封**，7 天内零成功记录。

## 根因

`naye1.pem` 是老式 RSA 私钥，客户端用 SHA-1 的 `ssh-rsa` 签名；Ubuntu 24.04 / OpenSSH 9.6 的 `PubkeyAcceptedAlgorithms` 已剔除 `ssh-rsa`。服务端在签名环节直接拒 → 客户端判定该 key 不可用 → 密码通道已关、无路可退 → 报 `No available authentication methods`。

## 我犯的误判（重要教训）

第一次看到 3 条 `ssh-rsa not in PubkeyAcceptedAlgorithms`，判断成"客户端在轮询多把 key，`MaxAuthTries=6` 用完导致新 key 轮不到"，于是建议用户**删掉 `naye1.pem`**。

用户回复"那把密钥是我其他机器的 不能删"。

回看日志才发现：那 3 条全部属于**同一个 sshd PID**（`987069` / `982997`），是**同一把 RSA key 试了多个签名算法变体**，不是多把 key。真正的问题是 ServerCat 里这条服务器仍绑着旧 key，新 key 一次都没被提交。

→ 固化为规则：**先看 PID，同一 PID = 同一把 key 的多算法尝试；不同 PID 才可能是多把 key 轮询。**

→ 固化为规则：**移动端密钥库是全局共享的，不要建议删 key，只改服务器条目里的绑定。**

## 处置

1. 生成 ED25519 新 key（无 passphrase，指纹 `SHA256:ogcInfmeWbnT+PdZ9+R4ItpP3C2F3NthClUYcf+Yi3g`）；
2. 备份 `authorized_keys` → `authorized_keys.bak.20261025-021331`，追加公钥，原有 2 把未动；
3. 本机用新私钥实连验证：`Accepted publickey ... SHA256:ogcInfme...`，返回 `root@racknerd-fe424f4`；
4. 因用户不能删旧 key，服务端兜底：新建 `/etc/ssh/sshd_config.d/00-maxauthtries.conf` 写 `MaxAuthTries 10`，`sshd -t` 通过后 `systemctl reload ssh`，`sshd -T` 确认生效 10，服务仍 active，22 端口 IPv4+IPv6 均监听；
5. 备份 `/etc/ssh/sshd_config.bak.20261025-022252`，回滚路径 = 删该 conf + reload。

私钥通过文件路径交付（`servercat_la.txt`），未贴正文。

## 待确认

用户最后一次重试结果未在本会话内确认。判定依据：若日志出现新指纹 `ogcInfme` 的 `Accepted` 即成功；若仍是 `ssh-rsa not in PubkeyAcceptedAlgorithms`，说明客户端绑定未改，需回到 ServerCat 服务器条目改选密钥。
