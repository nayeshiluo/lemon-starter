---
name: ssh-login-troubleshooting
description: "Use when SSH 登录失败/被拒/卡住：双侧日志对照定位根因。"
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux, darwin]
metadata:
  hermes:
    tags: [ssh, auth, openssh, fail2ban, troubleshooting, servercat, sshd]
    related_skills: [cloud-sandbox-vm-ops, aws-ec2-ops, selfhosted-service-audit, proxy-node-connectivity]
---

# SSH 登录失败排障（双侧证据对照）

## When to Use

- 用户说"SSH 连不上/登录失败/进不去/一直转圈"；
- 客户端报 `Permission denied (publickey)`、`No available authentication methods`、`Connection closed by remote host`、`Connection reset by peer`、`Operation timed out`；
- 换设备（手机 ServerCat/Termius、新电脑）后连同一台 VPS 失败；
- 服务端刚做过加固/升级后，老的连接方式突然失效。

**不适用**：SSH 通道本身正常、只是远端命令执行出错——那不是本技能的范围。

## 铁律一：先对齐"到底是哪台机器"

用户会质疑"你没弄错吧，我是 XX 的 VPS"。所以在给结论前，**必须把三个 IP 并排核对并展示给用户**：

1. 用户客户端截图/描述里的目标 IP；
2. 你本地 `~/.ssh/config` 里该别名的 `HostName`；
3. 服务端自述：`curl -s --max-time 8 ifconfig.me`（从服务端跑）。

再加一条归属地核对（本机只读，流量极小）：

```bash
curl -s "https://ipinfo.io/<IP>/json" | grep -E '"(ip|city|region|country|org|timezone)"'
```

把结果做成表格贴给用户（目标 IP / 你检查的 IP / 归属地 / 服务端自述 IP / 主机名）。这一张表能一次性消掉"你是不是查错了"的质疑，比反复解释有效。

## 铁律二：客户端报错只是症状，服务端日志才是证据

**永远不要只看客户端报错就下结论。** 客户端（尤其手机 App）会把各种服务端拒绝笼统报成同一句话。

固定取数（服务端只读）：

```bash
journalctl -u ssh -u sshd --since "30 min ago" --no-pager | tail -40
journalctl -u ssh -u sshd --since "24 hours ago" --no-pager \
  | grep -Ei "Accepted|Failed|Invalid|closed by authenticating|not in PubkeyAcceptedAlgorithms|maximum auth" | tail -20
```

**时间对齐是硬要求**：客户端截图上的本地时间要换算成服务端时区再比对。服务端常是 UTC，用户是 UTC+8。采样时间和时区必须一起写出来，不要凭回复时间猜。

## 错误对照表（客户端 ↔ 服务端）

| 客户端报错 | 服务端日志特征 | 真实原因 |
|---|---|---|
| `Permission denied (publickey)` | `Connection closed by authenticating user root <IP>` | key 不在 `authorized_keys`，或签名算法被拒 |
| `No available authentication methods` | 同上，或 `maximum authentication attempts exceeded` | key 被拒 **且** 没有别的认证方式（密码已关） |
| `Connection closed by remote host`（很快断） | `userauth_pubkey: signature algorithm ssh-rsa not in PubkeyAcceptedAlgorithms` | 老 RSA key 用 SHA-1 签名，被 OpenSSH 9.x 拒 |
| `Connection reset by peer` | `fail2ban` 有该 IP 的 `Ban` 记录 | IP 被 fail2ban 封禁 |
| `Connection refused` | 无任何日志 | 服务没起 / 端口不对 / 中间有防火墙 DROP |
| 一直挂起至超时 | 无日志或 `kex_exchange_identification` 异常 | 线路干扰、出口封锁 22 端口 |
| `Too many authentication failures` | `Disconnecting authenticating user ... Too many authentication failures` | 客户端一次连接试了太多把 key，撞满 `MaxAuthTries` |

## 三大高频根因

### 1. `ssh-rsa`(SHA-1) 被 OpenSSH 9.x 弃用（最常见）

Ubuntu 24.04 / OpenSSH 9.6 起，`PubkeyAcceptedAlgorithms` 默认只留 `rsa-sha2-256`、`rsa-sha2-512`，**不再包含 `ssh-rsa`**。老式 RSA 私钥 + 老客户端会用 SHA-1 签名，服务端在签名这一步就拒，表现为"握手成功但立刻被踢"。

先核实实际生效值（不要看配置文件猜）：

```bash
sshd -T | grep -i pubkeyacceptedalgorithms
```

两条修法：

- **推荐：换 ED25519 key**。不改任何 sshd 配置，不降安全等级：
  ```bash
  ssh-keygen -t ed25519 -f <path>/newkey -N "" -C "<用途>-<日期>"
  # 追加前先备份
  ssh -i <path>/newkey -o IdentitiesOnly=yes root@<host> 'echo ok'   # 部署后立即实测
  ```
- **应急：放开算法**（SHA-1 降级，仅在无法换 key 时用）：
  ```bash
  printf 'PubkeyAcceptedAlgorithms +ssh-rsa\n' > /etc/ssh/sshd_config.d/00-ssh-rsa-compat.conf
  sshd -t && systemctl reload ssh
  ```

### 2. 客户端在用错的 key —— 用 PID 判别，别靠猜（重要纠正）

**关键鉴别法**：看服务端日志里的 `sshd[PID]`。

- **同一个 PID** 出现多条 `ssh-rsa not in PubkeyAcceptedAlgorithms` → 这是**同一把 RSA key 试了多个签名算法变体**（`ssh-rsa`、`rsa-sha2-256`、`rsa-sha2-512` 各试一遍）。说明客户端**根本没换 key**，问题在客户端配置。
- **多个不同 PID**、各自报不同 key 指纹 → 客户端在轮询多把 key，可能是 `MaxAuthTries` 耗尽导致后面的 key 排不上队。

踩过的真实误判：看到 3 条 `ssh-rsa not in PubkeyAcceptedAlgorithms` 就判定"客户端在轮询多把 key、`MaxAuthTries=6` 用完导致新 key 轮不到"，进而建议用户删除旧 key——**这是错的**。三条日志同属 PID `987069`，是同一把 key 的多算法尝试。修正后的结论是"客户端仍指着旧 key，只需在该服务器条目里改选新 key"。

所以：**先看 PID，再下结论。** 判别完再决定是改客户端配置，还是调服务端 `MaxAuthTries`。

### 3. fail2ban 封禁

```bash
fail2ban-client status sshd          # 看 Currently banned / Banned IP list
fail2ban-client get sshd bantime     # 封多久
fail2ban-client get sshd maxretry    # 几次触发
fail2ban-client get sshd ignoreip    # 白名单
grep -Ei "Ban |Unban " /var/log/fail2ban.log | tail -25   # 时间线
```

排查要点：

- 当前封禁列表里的 IP **逐个核对行为**再判断是不是用户本人。爆破者会试 `admin`/`deploy`/`oracle`/`usuario`/`shutdown` 这类用户名，一眼可辨。
- 自己/受信机器的出口 IP 应在 `ignoreip` 里，否则正常重试也可能被封。
- `maximum authentication attempts exceeded` **不一定**触发 fail2ban 的 ban（取决于 filter 正则），所以"没被封"不等于"没失败"。
  - **但反过来必须警惕**：2026-10-25 实测中，`<YOUR_SERVER_IP>` 在 `02:16:19 maximum authentication attempts exceeded` 之后**确实被封了**。所以不要假设它不会触发，一律以 `iptables -S f2b-sshd` 的实际规则为准。

### 3.1 `fail2ban-client status` 与 iptables 不同步（高频误判点）

**踩过的坑**：先查 `fail2ban-client status sshd | grep <IP>` 返回 0，据此判定"没被封"，继续往算法方向查；几分钟后 `iptables -S f2b-sshd` 里赫然出现该 IP 的 `REJECT`——它是刚被封的，两处状态有滞后。

**固定做法：两处都看，以 iptables 为准。**

```bash
fail2ban-client status sshd | grep "Banned IP"
iptables -S f2b-sshd                    # 真正生效的规则
nft list ruleset | grep -A20 "f2b-sshd" # nft 后端时用这个
```

解封后也要复查两处都清零：

```bash
fail2ban-client set sshd unbanip <IP>
iptables -S f2b-sshd | grep -c <IP>     # 必须为 0
```

### 3.2 "没反应"= 被封，不是密钥问题

用户描述"一直转圈/没反应"时，先查封禁再查别的。被封的特征：

- 服务端 `journalctl -u ssh -u sshd --since "HH:MM"` 里**该来源 IP 完全空白**（REJECT 发生在防火墙，sshd 收不到连接）；
- 但更早的时间点有该 IP 的失败记录；
- `iptables -S f2b-sshd` 有 `-s <IP> -j REJECT --reject-with icmp-port-unreachable`。

判据一句话：**日志里没有你的 IP = 请求没到 sshd = 第2层被封或线路断，绝不是密钥问题。**

### 3.3 `MaxAuthTries` 与 fail2ban 是耦合的

放宽 `MaxAuthTries` 会让单次连接产生更多失败尝试，**反而更快触发 fail2ban 的 `maxretry`**。两者必须一起调，只改一个会制造新问题。

兜底配置建议（`/etc/fail2ban/jail.d/zz-<name>.local`）：

```ini
[sshd]
maxretry = 10
findtime = 10m
bantime  = 12h
```

配合 `sshd_config.d/00-maxauthtries.conf` 的 `MaxAuthTries 10`。改完 `fail2ban-client -t` 校验再 `fail2ban-client reload`。

## 服务端最小变更：改 sshd 参数

**永远走 `sshd_config.d/` 目录，不直接改主文件**，理由：单文件可秒级回滚。

```bash
# 1. 备份主文件
cp -a /etc/ssh/sshd_config /etc/ssh/sshd_config.bak.$(date +%Y%m%d-%H%M%S)
# 2. 写独立片段（00- 前缀，因为 MaxAuthTries 等选项是「先出现者优先」）
printf 'MaxAuthTries 10\n' > /etc/ssh/sshd_config.d/00-maxauthtries.conf
chmod 644 /etc/ssh/sshd_config.d/00-maxauthtries.conf
# 3. 语法校验，失败立即回滚
sshd -t || { rm -f /etc/ssh/sshd_config.d/00-maxauthtries.conf; exit 1; }
# 4. reload（Debian/Ubuntu 单元名是 ssh，不是 sshd）
systemctl reload ssh
# 5. 验收
sshd -T | grep -i '^maxauthtries'
systemctl is-active ssh
```

要点：

- `sshd -t` 通过才 reload，写错配置会把 SSH 彻底锁死。
- 改完**必须用现有 key 实连一次**证明没把自己关在门外。
- 回滚：删掉片段文件 + `systemctl reload ssh`，并在回复里明确写出这条回滚路径。
- 顺序陷阱：`sshd_config.d/*.conf` 按字典序加载，且多数选项「首次取值生效」。想让自己的设置赢，用 `00-` 前缀；用 `99-` 可能被前面的 `50-cloud-init.conf` 盖掉。改完一定用 `sshd -T` 看**实际生效值**，不要看文件内容就报成功。

## 移动端客户端陷阱（ServerCat / Termius 类）

1. **密钥库是全局共享的**。用户手机里那把老 key 可能同时供多台服务器使用，**不能建议删除**——会打断其他机器。正确做法是在**目标服务器条目里改选密钥**，不动密钥库。
2. 若 App 没有"按服务器指定密钥"的选项、只能全局轮询，则服务端 `MaxAuthTries` 要留够（10 起），否则排在后面的 key 永远轮不到。
3. 导入密钥的常见失败：只支持 PEM（`BEGIN RSA PRIVATE KEY`）而不认 OpenSSH 格式（`BEGIN OPENSSH PRIVATE KEY`）；或粘贴时丢了换行。用户说"导入成功但仍连不上"时，先看服务端有没有尝试过新 key 的指纹——没有就是导入/绑定没生效，别去改服务端。
4. 验证某把 key 到底有没有被尝试过：直接 grep 指纹前缀
   ```bash
   journalctl -u ssh -u sshd --since "30 min ago" | grep -i "<指纹前8位>"
   ```

## 在远端执行多行脚本

远端排障脚本容易写长。**不要用超长内联 heredoc**（会触发命令解析上限而被整条拦掉，重试同样的写法仍然失败）。正确做法：

```bash
# 1. 本地写文件
write_file -> /home/<u>/.hermes/workspace/<task>.sh
# 2. scp 过去再执行
scp -q -o BatchMode=yes <local>.sh <host>:/tmp/<task>.sh
ssh -o BatchMode=yes <host> 'bash /tmp/<task>.sh; rm -f /tmp/<task>.sh'
```

好处：脚本可复用、可复核、失败后改文件重跑，不用重写整条命令。写操作类脚本内部自带备份 + `sshd -t` 校验 + 失败回滚。

## 汇报口径

- **区分已验证事实与推断**。例：服务端日志里出现某来源 IP 的失败，是事实；"这个 IP 是你手机走代理出来的"是推断，必须标注。
- 不要用"服务端没问题"这种笼统话——用户会理解成"你说没坏但我就是连不上"。要说清楚：**机器没宕、端口通、握手成功，但认证规则拒了你的 key**。一句话版本："不是连不上，是连上了但进不去。"
- 私钥绝不贴在聊天正文里；用文件路径交付，并提醒用户用完删除、建议加 passphrase。
- 输出结论前自检：目标 IP 对了吗？PID 判过了吗？`sshd -T` 的实际值读了吗？改完自己实连验证了吗？

## 案例档案

- `references/case-racknerd-la-20261025.md` — 洛杉矶 RackNerd（<PRIVATE_IDENTIFIER>）ServerCat 登录失败完整排查记录：截图日志、服务端证据、PID 误判与纠正、最终处置。
