---
name: ssh-login-troubleshooting
description: "Use when SSH 登录失败/被拒/卡住：双侧日志对照定位根因。"
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux, darwin]
metadata:
  hermes:
    tags: [ssh, auth, openssh, fail2ban, troubleshooting, servercat, sshd]
    related_skills: [cloud-sandbox-vm-ops, aws-ec2-ops, selfhosted-service-audit, proxy-node-connectivity]
---

# SSH 登录失败排障（双侧证据对照）

## When to Use

- 用户说"SSH 连不上/登录失败/进不去/一直转圈"；
- 客户端报 `Permission denied (publickey)`、`No available authentication methods`、`Connection closed by remote host`、`Connection reset by peer`、`Operation timed out`；
- 换设备（手机 ServerCat/Termius、新电脑）后连同一台 VPS 失败；
- **用户说"某台机器上某个 App / 某条连接好像断了"**，但其他连接和其他客户端都正常——先按 key 指纹归因，见「铁律五」；
- **用户说"我这台手机/这台电脑上，A、B、C 几个设备全连不上"**——单客户端对多台主机，见「铁律六」，不要按"多台被封"处理；
- **需要区分"包没到服务器"还是"客户端根本没发包"**——这两个在 sshd 日志里长得一模一样，用「决定性判别：让用户在浏览器里打开 SSH 端口」10 秒分开，别靠推断；
- 服务端刚做过加固/升级后，老的连接方式突然失效；
- **日志/日报里 SSH 认证拒绝刷屏**（几千条、单 IP 集中），要把噪音压下去让真问题露出来——此时不需要登录失败，见「扫描噪音压制」章节。

**不适用**：SSH 通道本身正常、只是远端命令执行出错——那不是本技能的范围。

## 用户设备交接与一步一验（优先流程）

- 用户说「一步一步来／先解决 SSH」时，暂停无关轮换、加固和其他主机任务；**一次只处理一台、每条回复只给一个明确界面动作**。根据最新截图里的真实控件和密钥名称指路，等用户反馈再继续，不夹带整份安全清单。
- 先确认具体客户端。ServerCat、Termius、其他手机 App 和 Web UI 不是同一界面，不能用另一款客户端的字段或格式要求指导。
- **先选现有安全钥匙，后考虑新建或导入**。截图只有某个名称时不能凭记忆指派另一把。显示名称、服务端注释和私钥文件名均不是密钥身份；在本地以公钥的「算法＋完整 key blob」比对授权，再结合本次手机重试时间和服务端成功记录确认，原值和指纹不回显。
- ServerCat 的「SSH 密钥＝自动」表示尝试 Keychain 中的密钥，既不证明目标钥匙已被尝试，也不证明已触发 `MaxAuthTries`。若有已证实可用的钥匙，优先在**这一个服务器条目**明确选择它，不删全局 Keychain、不放宽旧算法。
- 同一把手机钥匙能连 A 不代表 B 已授权。B 缺公钥时，在授权范围内备份后只追加该安全公钥，保持其他授权、属主和权限；不把手机私钥传到服务器，不重启无须重启的 sshd。
- 撤销暴露钥匙前，除了自动化依赖，还要核对所有者设备实际使用的身份及独立恢复入口。已有暴露钥匙不因客户端失败恢复；优先切到已安全授权的设备钥匙。
- 分开报告三层验收：①服务端授权/语法通过；②代理的**独立新连接**通过；③用户手机测试成功。前两项不能冒充第三项，手机未反馈时写「待设备验收」。
- 详细方法见 `references/mobile-key-selection-and-handoff.md`；其中案例的最后状态不能当作未来机器的实时配置或已完成验收。

## 铁律一：先对齐"到底是哪台机器"

先在本地核对：用户所指的主机条目、实时 SSH 别名解析、远端主机身份及入口端口。**不把真实 IP、凭据或内部端点打印给模型或贴聊天**；用户截图已遮住地址时不要让其重新暴露。只汇报「目标身份匹配／不匹配」与安全别名。

- 用户客户端填写的是入口地址，可能经过 NAT、端口映射或堡垒机；服务端出网 IP 不一定与入口相同，不能要求三者相等才能算同一主机。
- `ssh -G` 解析的用户、外部端口、IdentityFile 与实时远端身份用于本地交叉核对；名称、历史记忆或同机残留单元不能单独证明目标身份。
- 仅在身份仍有歧义且确有必要时做出网或归属查询。外部 IP 查询会向第三方发送信息，不作为每次排障的默认步骤。
- 对 NAT，分别验证「外部入口＋映射端口」与「内层 sshd 监听」，不能把内层 22 直接替换到手机条目。

## 铁律二：客户端报错只是症状，服务端日志才是证据

**永远不要只看客户端报错就下结论。** 客户端（尤其手机 App）会把各种服务端拒绝笼统报成同一句话。

固定取数（服务端只读）：

```bash
journalctl -u ssh -u sshd --since "30 min ago" --no-pager | tail -40
journalctl -u ssh -u sshd --since "24 hours ago" --no-pager \
  | grep -Ei "Accepted|Failed|Invalid|closed by authenticating|not in PubkeyAcceptedAlgorithms|maximum auth" | tail -20
```

**时间对齐是硬要求**：客户端截图上的本地时间要换算成服务端时区再比对。服务端常是 UTC，用户是 UTC+8。采样时间和时区必须一起写出来，不要凭回复时间猜。

**跨主机比对前，先确认每台日志自己的时区**：同一批机器可能不一致。实测某台 `date -u` 报 `13:20 UTC`，而它的 `journalctl` 打的是 `21:20`（本地 CST）——不先对齐就会把 8 小时的偏移当成"断连发生在几点"，进而错配到错误的事件。取数时把 `date`（不带 `-u`）和 `date -u` 一起打，并在汇报里标明日志时间是哪种。

## 铁律三：人连得上 ≠ 脚本连得上（端口漂移的第二种表现）

端口/别名漂移最先炸的往往不是人手敲的 `ssh`，而是**监控探针、上传脚本、备份任务**——人用 `~/.ssh/config` 里的别名一直正常，硬编码 IP 的调用点则稳定报 `Connection refused` / 退出码 255。所以看到「告警说连不上某主机」时，先判断调用方走的是别名还是裸 IP：

```bash
ssh -o BatchMode=yes <别名> 'echo ok'                       # 通道本身通不通
grep -rn 'root@[0-9]\|@[0-9]\{1,3\}\.[0-9]' <项目>/*.py      # 找硬编码 IP 的调用点
```

判据一句话：**同一台机器、同一把 key，别名能通而脚本 255，就是端口漂移，不是主机宕机**。别据此去重启一台健康的服务。修法统一成「调用方写别名」或显式 `-p <端口>`；改完把同类调用点一次扫干净——实测一个仓库里同时存在 3 处漏端口的调用（`vps_video_module.py`），只修告警点会留下静默坏掉的磁盘统计/清理功能。

## 铁律四：多台同时"连接失败"而服务端零连接记录 = 路径阻断，先别动服务端

用户说"这几台全连不上了"时，先做一次**分层判据**再动手：

| 服务端日志 | 层次 | 该做什么 |
|---|---|---|
| `Failed publickey` / `Connection closed by authenticating` | 认证层 | 查 key、算法、用户名 |
| `Invalid user` / fail2ban 有 `Ban` | 拦截层 | 查封禁与扫描噪音 |
| **该客户端 IP 一条记录都没有** | **连接没到服务器** | 停手，查路径 |

**零记录是硬证据**：TCP 都没建立，`authorized_keys`、`sshd_config`、fail2ban 全部无关。此时**不改 sshd、不追加公钥、不重启服务、不放宽算法**——服务端是健康的，改它只会给后面的判断加变量。

判路径的正确顺序：

1. **先证服务端健康**：从另一台已知正常的主机 `ssh -o BatchMode=yes <别名> 'echo ok'`；再对目标做 TCP 握手读 banner（`socket.create_connection` + `recv`，看到 `SSH-2.0-*` 即证明端口映射与 sshd 都在）。
   **不要为了测端口把目标 IP 交给在线端口检测网站**——那等于把源站 IP 送给第三方，与隐匿要求直接冲突。
2. **按网段分组对比"能连的"和"连不上的"**：把所有条目列出来标出哪台通。共同点几乎总落在 IP 归属/线路（实测例：AWS 段能连，RackNerd / HostPapa / Hytron 段全断），而不是端口号。
   **端口理论必须能解释全部失败项**：失败集合里同时有 22 和 2222/30023 时，"某端口被封"就不成立。
3. **核对客户端填的是域名还是裸 IP**：走 Cloudflare 橙云的域名（443）常在直连被阻断时仍然通，这正好解释"为什么只有某一台能连"。
4. **多个客户端同向失败才是网络问题**：手机 ServerCat 与 Codex App 同时连不上同一台，指向手机出口，而不是某个 App 的配置。
5. **读监听列表不许截断**：`ss -lntup | head -14` 会把后面的端口切掉，实测据此误判"代理服务没在跑"（实际在跑）。要判断某个服务是否监听，直接 `grep -E ':(端口)\b'`，不要用 `head` 看全量输出。

处置优先级：先给**立即可用**的绕行——`ProxyJump` 经一台能连的主机跳转（能连的那台到目标通常也通）；再谈长期方案（把入口挪到 CF 隧道/域名），别长期靠跳板顶着。汇报时明确区分"服务端已验证正常"与"客户端侧待验收"。

完整案例与取证命令见 `references/path-blocked-vs-auth-failure.md`。

## 铁律五：单个客户端"断了" —— 先按 key 指纹归因，别改服务端

触发：用户说「某台机器上某个 App / 某条连接好像断了」，但其他连接、其他客户端都正常。这和铁律四的"多台同时失败"是镜像问题：**只有一个客户端零记录时，优先怀疑客户端，不是路径也不是服务端。**

三向判据：

| 服务端证据 | 判定 | 动作 |
|---|---|---|
| 有 `Failed publickey` / `Connection closed by authenticating` | 认证层 | 查 key、算法、用户名 |
| 有 `Ban` / iptables REJECT / `kex_exchange_identification` 异常 | 拦截层 | 解封、查限流 |
| **该 key 最后一次成功之后，成功/失败/断开记录全无** | 客户端静默消失 | 不动服务端，查设备侧 |

归因三步（全在服务端做，不碰用户手机）：

```bash
# 1. 指纹 → 设备注释：authorized_keys 的注释就是设备台账
ssh-keygen -lf /root/.ssh/authorized_keys

# 2. 每个 key 近 7 天登录次数：谁在连、连得多密
journalctl -u ssh --since "7 days ago" --no-pager \
  | grep "Accepted publickey" | grep -o "SHA256:[A-Za-z0-9+/=]*" | sort | uniq -c | sort -rn

# 3. 某个 key 的最后成功时刻与来源 IP
journalctl -u ssh --since "7 days ago" --no-pager \
  | grep "Accepted publickey" | grep "<指纹前8位>" | tail -5 | cut -c1-140
```

**这一步把"哪台设备、多久连一次、最后一次什么时候"变成可核对的数字**，比问用户"你什么时候断的"快得多，也能直接反驳"是不是你们服务器把我踢了"。

### 先建频率基线，再判"异常"

手机类 App（Codex App、ServerCat）是**高频重连**的：实测一把 `codex-app-iphone` key 7 天登录 833 次，单小时 3~72 次，中间还夹着几小时用户没用的空档。所以"几小时没连接"本身不构成证据。要按小时列出来，看断点是否与报障时间吻合：

```bash
journalctl -u ssh --since "3 days ago" --no-pager | grep "Accepted publickey" \
  | grep "<指纹前8位>" | awk '{print $1,$2,substr($3,1,2)}' | uniq -c | tail -20
```

判据：**高频基线 + 断点后连失败记录都没有 = 客户端根本没再发起连接**。若断点后还有失败记录，那是认证层，走上面的对照表。

### 排除服务端"看不见的层"（缺一不可，全部只读）

```bash
fail2ban-client status sshd | tail -4          # Currently banned 应为 0
iptables -S | grep "<客户端IP>"                 # 应为空
nft list ruleset | grep "<客户端IP>"            # 应为空
cat /proc/sys/net/netfilter/nf_conntrack_count /proc/sys/net/netfilter/nf_conntrack_max
ss -tn state established "( sport = :<端口> )"  # 当前还有没有该客户端的连接
dmesg -T | grep -iE "conntrack|nf_|drop" | tail -5
```

这些层拒绝连接时 sshd 收不到包，日志同样是零记录 —— 不查就会把"被防火墙挡了"误报成"客户端没连"。

### 终极证据：服务器侧 tcpdump 抓 SYN

上面全是"看日志"。日志为零时无法区分"包没到"和"到了但没记录"，**tcpdump 直接看链路层**：

```bash
# 排除已知正常来源，只留可疑客户端；-l 行缓冲，放后台跑
tcpdump -i any -n -l 'tcp port 2222 and not host <本机IP>' > /tmp/tcpdump-2222.log 2>&1 &
sleep 10
pgrep -a tcpdump                                   # 先确认抓包进程真在跑
head -3 /tmp/tcpdump-2222.log                      # 必须看到 listening on
```

判据：

| tcpdump 输出 | 含义 |
|---|---|
| 有 `Flags [S]` / `SYN` | 包到了服务器，问题在握手或认证层 |
| **零包，但 `listening on` 已打印** | 包根本没出客户端，与服务器无关 |

**必须先验抓包自身活着**：零包时先看 `pgrep -a tcpdump` 和日志首行的 `listening on`。
把"抓包进程没起来"当成"客户端没发包"是假阴性，而且**方向和结论一致**——最容易自欺。

实测（2026-11-05）：`tcpdump` 稳定跑了 4 分钟、`listening on` 正常打印，手机点重连期间**零 SYN**，
而同一次会话里浏览器开同一端口立刻留下 `banner exchange`。两份证据并排，才敢写"App 从未发包"。

### 别被 sshd 主进程 uptime 骗了

`ss -eo`/`ps` 里 sshd listener 只跑了 4 小时、而子会话跑了 21 小时，**不等于 sshd 重启过、更不等于它踢了用户**：`systemctl reload ssh` 会 exec 新主进程但保留已建立的子会话，只有 `restart` 才断连。看到这个组合先查 reload 时间点是否早于用户报障。

### 汇报与处置

写清三件事：最后成功时刻（换算到用户时区）、之后零记录、已排除封禁/限流/网络。结论落在"服务端没有拒绝，是客户端没再发起连接"，动作给设备侧（完全退出 App 重开、切换网络重连）。**不要顺手重启健康的 sshd 或远端 app-server** —— 那只会给下一次判断加变量。

完整案例（洛杉矶 RackNerd 上的 Codex App 连接）见 `references/client-key-attribution-and-silent-disconnect.md`。

### 归因之后的下一步：重启/升级远端 app-server 是另一件事

客户端静默消失的结论只到「服务端没拒绝」为止。用户接着说「那你升级一下吧」「重启一下服务」时，
换到 `remote-coding-agent-daemon-ops`：那里有 `daemon version` 三版本比对、`session-N.scope` 悬空判定、
`bootstrap` 托管化与 `update --from-cli --yes` 的坑（少 `--yes` 时**退出码 0 但什么都没做**）。

实测补充（2026-11-05，同一台 RackNerd）：那台 app-server 是手工从 SSH 会话起的，
cgroup 落在 `session-12.scope`（`Active: active (abandoned)`），靠 PPID=1 苟活 36 天。
**「SSH 通、daemon running」不等于它被持久化托管** —— 查 `/proc/<pid>/cgroup` 才知道。

## 铁律六：同一客户端对多台主机全零 = 客户端出网通道断了

触发：用户说「我这台设备上 A、B、C 全部连接失败」。这是铁律四（多个客户端打一台）的**镜像**，判据方向相反，别套用错。

三步取证，全部只读、全部在服务端做：

1. **从独立视角证明每台都健康**——不是只测端口，要真登录：`ssh -o BatchMode=yes <别名> 'hostname'` 逐台成功。
2. **跨主机比对同一把客户端 key 的指纹**：`ssh-keygen -lf ~/.ssh/authorized_keys`。三台指纹一致 = 不是授权丢失、不是 key 换了。
3. **按主机统计「该客户端出口网段」在时间窗内的记录条数**——这是决定性证据：

```bash
for h in <主机1> <主机2> <主机3>; do
  printf "\n== %s ==\n" "$h"
  ssh -o ConnectTimeout=10 "$h" "journalctl -u ssh --since '90 min ago' --no-pager \
    | grep -E '<客户端出口IP或网段正则>' | tail -5 | cut -c1-145; \
    echo \"[matches=\$(journalctl -u ssh --since '90 min ago' --no-pager | grep -cE '<同一正则>')]\""
done
```

| 结果形态 | 结论 |
|---|---|
| 多台都有记录、都是认证失败 | 客户端 key / 配置错 |
| 一台有记录、其余全零 | 单台路径阻断，走铁律四 |
| **多台全零，且断点前刚有一次成功** | **客户端出网通道断了**，服务端全部无关 |

第三种是本节重点：实测洛杉矶 RackNerd / 香港 NAT / HostPapa **三个不同机房同时归零**，物理上不可能同时被墙，只能是客户端到代理节点这一段没了。此时**不改任何一台 sshd、不追加公钥、不重启服务**。

### 配套信号：断点前成功过 + RST 来自代理

实测形态：客户端先正常登录、跑了几十秒，服务端日志是干净的 `Accepted`、无 error；Codex App 侧日志则是

```
failed to upgrade control socket websocket connection: WebSocket protocol error: Handshake not finished
... Connection reset without closing handshake
```

**RST 来自代理节点，不是 sshd**——判据就是同一时间窗内 sshd 日志里那次会话正常结束、没有 `Received disconnect`/`error`。长连接（SSH / WebSocket）最怕代理轮换出口：客户端出口 IP 短时间内在同机房多个地址间跳（实测 `<YOUR_SERVER_IP>` / `<YOUR_SERVER_IP>` 同属一个云厂商段），一跳就 RST，之后客户端不再重试。

### 非标端口是高频共犯

这类环境的 SSH 常在 `2222` / `30023`，而代理规则集常只放行 `80/443`。用户说「全部连接失败」但网页能开时，**先问端口，再看规则**——端口换成非标、规则又刚更新过，是"网页正常、SSH 全挂"最常见的原因。

### 处置

**下这个结论之前必须先做浏览器端口探针**（见「决定性判别」一节）：`matches=0` 只证明"没有 SSH 连接"，不证明"没有包"。
实测就推翻过——三台全零的同一台手机，浏览器开 `http://<IP>:2222` 立刻在 sshd 留下 `banner exchange ... invalid format`，
说明端口一直是通的、是 App 自己不发包。**没做探针就把结论写成"出网断了"，会把用户引到完全错误的方向。**

探针证明确实零包之后，只给客户端侧动作，服务器一个字不动：浏览器开网页（区分"手机断网"与"代理坏了"）→ 查订阅/节点/规则 → 代理 App 杀掉重开或临时直连。汇报时写清「三台服务端均已实测登录成功 + 手机侧零记录」，把结论落在客户端出网，而不是"某台服务器有问题"。

### 同一 App 换目标：区分"App 坏了"与"这条路不通"

探针证明端口可达、App 仍零尝试时，再做一个**同客户端、换目标**的对照（注意：不是换客户端，3.3 那个是换客户端）：

> 问用户："你在同一个 App 里连一台**国内**机器，通不通？"

| 结果 | 结论 |
|---|---|
| 连国内通、连海外非标端口全挂 | App 正常；到海外的路径被拦（分流/端口规则） |
| 连谁都连不上 | App 自身状态坏了（缓存离线态、权限、私钥格式） |

实测 2026-11-05：ServerCat 连本机（国内，装 Hermes 那台）长期"接通"，连洛杉矶 `2222` / 香港 `30023` / HostPapa `2222` 全 `Failed to connect`；
而同一手机浏览器开 `http://<洛杉矶IP>:2222` 立刻在 sshd 留下 `banner exchange`。
三项一拼就是：**App 工作正常，浏览器流量走了代理、App 流量走直连，非标端口直连被墙。**

### VPN 按 App 分流：最隐蔽的一层

「浏览器通 + App 零包 + 同 App 连国内通」三个同时成立，几乎只对应一种配置：**代理软件开了按 App 分流**——
浏览器在代理列表里、SSH App 不在；规则模式下非标端口（`2222`/`30023`）本来也常被漏掉。

处置顺序（全在客户端，服务器不动）：

1. 代理切**全局模式**（Global），立刻重试
2. 或把 SSH App 加入代理列表；或给目标 IP 逐条加规则
3. 长期：把 SSH 入口挪到 `443`（穿透性最好），见「换端口」章节

判据一句话：**网页能开、SSH App 全挂、同 App 连国内通 —— 就是分流，不是服务器。**

### 别把"用户自己的假设"当噪音

用户中途问「我用的 VPN 跟这个有关系吗」时，往往已经摸到边了。**先回答假设、再给证据**，
而不是继续按自己的推断往下走。本次就是用户先问的 VPN，当时还在往"App 缓存离线态"方向查，
绕了半轮才回到分流——用户对自己环境的直觉优先级高于 agent 的默认假设。

完整案例（2026-11-05，手机经代理连三台全失败）见 `references/multi-host-zero-record-client-egress.md`。

## 决定性判别：让用户在浏览器里打开 SSH 端口（10 秒，能推翻上面所有推断）

铁律四/五/六最后都收敛到同一个问题：**"零记录"到底是"包没到服务器"，还是"客户端根本没发包"？**
两者在 sshd 日志里长得一模一样，但结论相反（一个查网络、一个查 App）。**不要靠推断，用下面这一招直接分开。**

让用户在**手机浏览器**里打开：

```
http://<服务器IP>:<SSH端口>
```

浏览器必然显示"无法解析响应 / 无法解析服务器响应 / 乱码"——**这是正确且预期的现象**，因为 `2222` 上说的是 SSH 协议不是 HTTP。然后看 sshd 日志：

| sshd 日志 | 结论 | 下一步 |
|---|---|---|
| `banner exchange: Connection from <客户端IP> port NNNN: invalid format` | **TCP 已建立、端口可达、包确实到了服务器** | 网络无关，问题在 App/客户端侧 |
| 该客户端 IP **一条记录都没有** | 包真的没到 | 走铁律四/六，查路径/出网 |

```bash
journalctl -u ssh --since "10 min ago" --no-pager \
  | grep -vE "invalid user|Invalid user" | grep -v "<已知正常来源IP>"
```

**`banner exchange: ... invalid format` 不是错误、不是攻击特征、不需要处置**——它就是"有人在非 SSH 客户端上连了 SSH 端口"的正常记录。别把它当异常去查。

### 这一招为什么必须先做

2026-11-05 实测：手机对洛杉矶 RackNerd / 香港 NAT / HostPapa **三台全零**，按铁律六已经可以写"客户端出网通道断了"的结论了。
结果浏览器一开 `http://<IP>:2222`，sshd 立刻记下 `banner exchange: Connection from <YOUR_SERVER_IP> ... invalid format` ×4 ——
**手机到那台机器的 `2222` 一直是通的**。真实结论是"App 从未发起连接"，跟出网毫无关系。

判据一句话：**"多台全零"只能证明"没有 SSH 连接"，不能证明"没有包"。** 后者必须用浏览器探针证。

### 证到"端口可达但 App 零尝试"之后

结论落在 App 侧，服务器一个字不动。最有效的动作是**让用户删掉那条环境/主机条目重新添加**，而不是原地编辑：

- 多数 App 会把一次失败缓存成"离线"状态，之后**不再自动重试**（实测断连后 1 小时 45 分零连接尝试，用户手动点也没包发出）
- 原地编辑受"已保存字段只读"限制，改了也不生效（同 `mobile-key-selection-and-handoff.md` 里 3.2 的坑）

同时问一句区分方向：**点重连是"立刻弹离线"还是"转圈几秒才失败"**——立刻弹是本地状态，转圈是我这边应该同时看到包。用户操作时保持 `journalctl -f` 实时盯着，一有包立刻能看到。

### 客户端出口 IP 会轮换，别把旧 IP 当身份

同一台手机在不同时间的出口可能是完全不同的网段（实测 `<YOUR_SERVER_IP>` 美国云厂商 → `<YOUR_SERVER_IP>` 加拿大 Bell）。
**不要用"我记住的那个出口 IP"去 grep 全量日志然后报零记录**——先按时间窗取全部非爆破记录，再从里面认领新 IP。
出口一跳，长连接（SSH/WebSocket）必被 RST，这也是"连上跑了几十秒就掉"的常见来源。

## 错误对照表（客户端 ↔ 服务端）

| 客户端报错 | 服务端日志特征 | 真实原因 |
|---|---|---|
| `Permission denied (publickey)` | `Connection closed by authenticating user root <IP>` | key 不在 `authorized_keys`，用户名填错（如 root vs ubuntu），或签名算法被拒 |
| 无法建立连接 / 零日志 | 服务端日志完全无记录 | 客户端私钥格式不支持（本地拦截拦截）；目标 IP 或端口不匹配（如 22 vs 2222）；网络出口被封 |
| `No available authentication methods` | 同上，或 `maximum authentication attempts exceeded` | key 被拒 **且** 没有别的认证方式（密码已关） |
| `Connection closed by remote host`（很快断） | `userauth_pubkey: signature algorithm ssh-rsa not in PubkeyAcceptedAlgorithms` | 老 RSA key 用 SHA-1 签名，被 OpenSSH 9.x 拒 |
| `Connection reset by peer` | `fail2ban` 有该 IP 的 `Ban` 记录 | IP 被 fail2ban 封禁 |
| `Connection refused` | 无任何日志 | 服务没起 / 端口不对 / 中间有防火墙 DROP |
| 一直挂起至超时 | 无日志或 `kex_exchange_identification` 异常 | 线路干扰、出口封锁 22 端口 |
| `Too many authentication failures` | `Disconnecting authenticating user ... Too many authentication failures` | 客户端一次连接试了太多把 key，撞满 `MaxAuthTries` |

## 三大高频根因

### 1. `ssh-rsa`(SHA-1) 被 OpenSSH 9.x 弃用（最常见）

Ubuntu 24.04 / OpenSSH 9.6 起，`PubkeyAcceptedAlgorithms` 默认只留 `rsa-sha2-256`、`rsa-sha2-512`，**不再包含 `ssh-rsa`**。老式 RSA 私钥 + 老客户端会用 SHA-1 签名，服务端在签名这一步就拒，表现为"握手成功但立刻被踢"。

先核实实际生效值（不要看配置文件猜）：

```bash
sshd -T | grep -i pubkeyacceptedalgorithms
```

两条修法：

- **推荐：换 ED25519 key**。不改任何 sshd 配置，不降安全等级：
  ```bash
  ssh-keygen -t ed25519 -f <path>/newkey -N "" -C "<用途>-<日期>"
  # 追加前先备份
  ssh -i <path>/newkey -o IdentitiesOnly=yes root@<host> 'echo ok'   # 部署后立即实测
  ```
- **应急：放开算法**（SHA-1 降级，仅在无法换 key 时用）：
  ```bash
  printf 'PubkeyAcceptedAlgorithms +ssh-rsa\n' > /etc/ssh/sshd_config.d/00-ssh-rsa-compat.conf
  sshd -t && systemctl reload ssh
  ```

### 2. 客户端用错 key —— PID 只定位连接，不替代密钥证据

- **相同 PID** 通常帮助归并同一次连接中的事件，但同一连接可以尝试多个公钥；仅凭 PID 和几条算法拒绝，不能断定「同一把 key 试三种算法」或「客户端根本没换 key」。
- **不同 PID** 也可能只是同一客户端重连，不能单独证明 Keychain 轮询或认证次数耗尽。
- `ssh-rsa not in PubkeyAcceptedAlgorithms` 仅证明该次提交的旧 SHA-1 签名被拒；RSA 公钥可使用现代 RSA-SHA2 签名，不能把 RSA 密钥类型整体等同于旧算法。
- 可靠证据链：本次手机重试的时间和目标 → 对应连接事件 → 可用的公钥/算法标识 → 当前 `authorized_keys` 的本地精确比对。缺指纹或来源未归属时明确不确定，不打印指纹或真实地址补证。
- 在单台服务器条目明确选择已有、已确认授权的安全钥匙，再实测。只有真实日志显示认证次数耗尽时才评估 `MaxAuthTries`；不能看见「自动」就推断它耗尽，也不建议删除共享 Keychain。

### 3. fail2ban 封禁

```bash
fail2ban-client status sshd          # 看 Currently banned / Banned IP list
fail2ban-client get sshd bantime     # 封多久
fail2ban-client get sshd maxretry    # 几次触发
fail2ban-client get sshd ignoreip    # 白名单
grep -Ei "Ban |Unban " /var/log/fail2ban.log | tail -25   # 时间线
```

排查要点：

- 当前封禁列表里的 IP **逐个核对行为**再判断是不是用户本人。爆破者会试 `admin`/`deploy`/`oracle`/`usuario`/`shutdown` 这类用户名，一眼可辨。
- 自己/受信机器的出口 IP 应在 `ignoreip` 里，否则正常重试也可能被封。
- `maximum authentication attempts exceeded` **不一定**触发 fail2ban 的 ban（取决于 filter 正则），所以"没被封"不等于"没失败"。
  - **但反过来必须警惕**：2026-10-25 实测中，`<YOUR_SERVER_IP>` 在 `02:16:19 maximum authentication attempts exceeded` 之后**确实被封了**。所以不要假设它不会触发，一律以 `iptables -S f2b-sshd` 的实际规则为准。

### 3.1 `fail2ban-client status` 与 iptables 不同步（高频误判点）

**踩过的坑**：先查 `fail2ban-client status sshd | grep <IP>` 返回 0，据此判定"没被封"，继续往算法方向查；几分钟后 `iptables -S f2b-sshd` 里赫然出现该 IP 的 `REJECT`——它是刚被封的，两处状态有滞后。

**固定做法：两处都看，以 iptables 为准。**

```bash
fail2ban-client status sshd | grep "Banned IP"
iptables -S f2b-sshd                    # 真正生效的规则
nft list ruleset | grep -A20 "f2b-sshd" # nft 后端时用这个
```

解封后也要复查两处都清零：

```bash
fail2ban-client set sshd unbanip <IP>
iptables -S f2b-sshd | grep -c <IP>     # 必须为 0
```

### 3.2 "没反应"= 被封，不是密钥问题

用户描述"一直转圈/没反应"时，先查封禁再查别的。被封的特征：

- 服务端 `journalctl -u ssh -u sshd --since "HH:MM"` 里**该来源 IP 完全空白**（REJECT 发生在防火墙，sshd 收不到连接）；
- 但更早的时间点有该 IP 的失败记录；
- `iptables -S f2b-sshd` 有 `-s <IP> -j REJECT --reject-with icmp-port-unreachable`。

判据一句话：**日志里没有你的 IP = 请求没到 sshd = 第2层被封或线路断，绝不是密钥问题。**

### 3.3 `MaxAuthTries` 与 fail2ban 是耦合的

放宽 `MaxAuthTries` 会让单次连接产生更多失败尝试，**反而更快触发 fail2ban 的 `maxretry`**。两者必须一起调，只改一个会制造新问题。

兜底配置建议（`/etc/fail2ban/jail.d/zz-<name>.local`）：

```ini
[sshd]
maxretry = 10
findtime = 10m
bantime  = 12h
```

配合 `sshd_config.d/00-maxauthtries.conf` 的 `MaxAuthTries 10`。改完 `fail2ban-client -t` 校验再 `fail2ban-client reload`。

## 找不到该用哪把 key 时：批量试探会自触发限流

接手一台新机器、`~/.ssh/config` 里没有别名、手上有 5 把私钥时，容易写成
`for u in ubuntu root admin; do for k in *; do ssh -i ...; done; done`（一次 15 条连接）。
**实测后果**：前几把正常报 `Permission denied (publickey)`，随后连接层直接变成
`kex_exchange_identification: Connection closed by remote host` / `Connection reset by peer`，
看起来像"IP 被封了"或"密钥全错"，其实只是 **sshd/fail2ban 的握手限流**，停手约 45 秒后同一把正确的 key 立刻能登。

纪律：

- 一次最多试 3~5 把，命中即停；中间 `sleep 5`，别打满。
- 命中后用 `-o BatchMode=yes -i <key>` 单独复验一次，确认不是限流窗口里的偶发成功。
- 顺序上优先试"用途最贴近"的那把（迁移/运维专用 key 优先于通用 key），别按字母序盲试。
- 出现 `kex_exchange_identification` 后**不要立刻换策略或换端口**，先 `date` 记时间、等 45~60 秒再试一次；
  同时用另一台已知能连的机器确认目标机没宕（判据仍是"服务端日志里有没有你的 IP"）。
- 拿不准时问用户要用户名/密钥，比盲试 15 把快得多，也不留失败记录。

## 服务端最小变更：改 sshd 参数

**永远走 `sshd_config.d/` 目录，不直接改主文件**，理由：单文件可秒级回滚。

```bash
# 1. 备份主文件
cp -a /etc/ssh/sshd_config /etc/ssh/sshd_config.bak.$(date +%Y%m%d-%H%M%S)
# 2. 写独立片段（00- 前缀，因为 MaxAuthTries 等选项是「先出现者优先」）
printf 'MaxAuthTries 10\n' > /etc/ssh/sshd_config.d/00-maxauthtries.conf
chmod 644 /etc/ssh/sshd_config.d/00-maxauthtries.conf
# 3. 语法校验，失败立即回滚
sshd -t || { rm -f /etc/ssh/sshd_config.d/00-maxauthtries.conf; exit 1; }
# 4. reload（Debian/Ubuntu 单元名是 ssh，不是 sshd）
systemctl reload ssh
# 5. 验收
sshd -T | grep -i '^maxauthtries'
systemctl is-active ssh
```

要点：

- `sshd -t` 通过才 reload，写错配置会把 SSH 彻底锁死。
- 改完**必须用现有 key 实连一次**证明没把自己关在门外。
- 回滚：删掉片段文件 + `systemctl reload ssh`，并在回复里明确写出这条回滚路径。
- 顺序陷阱：`sshd_config.d/*.conf` 按字典序加载，且多数选项「首次取值生效」。想让自己的设置赢，用 `00-` 前缀；用 `99-` 可能被前面的 `50-cloud-init.conf` 盖掉。改完一定用 `sshd -T` 看**实际生效值**，不要看文件内容就报成功。

## 扫描噪音压制（资源受限机，装不了 fail2ban）

触发：日报/巡检里 SSH 认证拒绝刷到几千条（实测某机 24h **4265 条**，单 IP 占 1604 条），把真问题淹掉了。

### 先判风险，再决定动不动手

刷屏 ≠ 被攻破。先取三个事实，全部只读：

```bash
sshd -T | grep -E '^(passwordauthentication|permitrootlogin|pubkeyauthentication|maxauthtries)'
ss -lntp | grep -E ':22 '                    # 实际监听端口
journalctl -u ssh --since -24h | grep -oE 'from [0-9.]+' | sort | uniq -c | sort -rn | head
```

判据：`passwordauthentication no` + 仅公钥 + 某次公网探测 filtered，只能说明密码攻击面受限及该探测来源当时未连通，**不能称为“零风险”或据此排除入侵**。继续核对成功认证身份、授权变更、日志留存与其他入口。降扫描噪音与调查入侵是两个目标；若没有异常证据，不为压日志盲目扩大认证权限。

### 资源受限机不要硬装 fail2ban

`apk add fail2ban` 需要 python + iptables/nftables。实测一台 Alpine 小鸡：内存 973MB 但 **available 仅 58MB**、根分区 548MB 只剩 139MB、`which nft iptables` 全空 —— 装上就是 OOM + 撑爆磁盘。

**先查资源再选方案**：

```bash
free -m | head -3; df -h / | tail -1; which nft iptables fail2ban-client 2>/dev/null
```

available < 150MB 或磁盘余量 < 300MB → 走 sshd 内置参数，零依赖：

```ini
# /etc/ssh/sshd_config.d/01-ratelimit.conf
MaxStartups 10:30:60     # 并发未认证连接：10 起丢 30%，60 全丢
LoginGraceTime 20        # 未认证连接存活时间（默认 120s，扫描会挂满）
MaxAuthTries 4           # 单连接认证尝试次数（默认 6）
```

`LoginGraceTime` 和 `MaxAuthTries` 是真正降条数的两个——`MaxStartups` 对「逐个连接、被拒后立即断开」的扫描器几乎不起作用，因为并发本来就低。别指望它。

### Alpine / OpenRC 的落地差异

- 单元管理是 `rc-service sshd`，**不是** `systemctl`（`systemctl list-units` 会返回空，别据此判断 sshd 没跑）
- reload 用 `rc-service sshd reload`，失败再 `restart`；SIGHUP 不断已有会话
- 日志在 `/var/log/messages`，没有 journal（`journalctl -u ssh` 返回 0 行是正常的，不代表没日志）
- 参数"首次取值生效"，`00-` 前缀会赢；本次新增项原配置里都没有，用 `01-` 安全

验收四步（缺一不可）：

```bash
sshd -t                                        # 语法
sshd -T | grep -iE '^(maxstartups|logingracetime|maxauthtries)'   # 实际生效值
rc-service sshd status                         # 进程还在
ssh -o BatchMode=yes <别名> 'echo RECONNECT_OK'  # 没把自己关在门外
```

### 效果边界（别高估）

这三个参数能把条数压下来，但**不会归零**——换源 IP 照样刷。要根治得在**采集侧按来源 IP 聚合成一条**（`<IP> × 4265 次认证拒绝`），而不是在机器上继续加规则。汇报时把这条讲清楚，别让用户以为配完就清净了。



1. **密钥库是全局共享的**。用户手机里那把老 key 可能同时供多台服务器使用，**不能建议删除**——会打断其他机器。正确做法是在**目标服务器条目里改选密钥**，不动密钥库。
2. 若 App 没有"按服务器指定密钥"的选项、只能全局轮询，则服务端 `MaxAuthTries` 要留够（10 起），否则排在后面的 key 永远轮不到。
3. 导入密钥的常见失败：只支持 PEM（`BEGIN RSA PRIVATE KEY`）而不认 OpenSSH 格式（`BEGIN OPENSSH PRIVATE KEY`）；或粘贴时丢了换行。用户说"导入成功但仍连不上"时，先看服务端有没有尝试过新 key 的指纹——没有就是导入/绑定没生效，别去改服务端。
3.1 **私钥格式必须按 App 适配，不要一律给 OpenSSH 格式**（2026-10-25 实测）：

   | 格式 | 首行 | 谁支持 |
   |---|---|---|
   | OpenSSH（现代默认） | `<YOUR_PRIVATE_KEY>` | ServerCat、OpenSSH CLI、多数终端 |
   | PKCS#8 | `<YOUR_PRIVATE_KEY>` | 部分 App（实测：用户编辑 `Codex` 主机条目所用的那个客户端） |
   | SEC1 | `<YOUR_PRIVATE_KEY>` | 同上（ECDSA 专用） |

   **注意别搞混客户端**：同一用户可能同时用多个 SSH App——实测中 ServerCat 能正常吃 OpenSSH 格式的 ED25519，而另一个 App 的 `Codex` 主机条目却拒绝同一格式。**按 App 分别适配，不要假设"能连的那个 App 的 key 另一个也能用"。**

   该 App 会直接报（**本地拦截，请求没到服务端，日志空白，别去查封禁**）：
   > 尚不支持 OpenSSH 私钥。请将 Ed25519 或 ECDSA 密钥导出为 PKCS#8 或 SEC1 PEM 格式，然后重试。

   **关键限制（实测）**：`ssh-keygen -p -m PKCS8` **无法把 ED25519 转成 PKCS#8**——命令返回成功，但首行仍是 `BEGIN OPENSSH PRIVATE KEY`。遇到只吃 PEM 的 App，**直接改用 ECDSA**，别浪费时间转 ED25519。

   ```bash
   # SEC1 PEM（BEGIN EC PRIVATE KEY）
   ssh-keygen -t ecdsa -b 256 -f <path>/key -N "" -m PEM -C "<用途>-<日期>"
   # 再由 SEC1 转 PKCS#8（BEGIN PRIVATE KEY）
   cp <path>/key <path>/key_pkcs8 && ssh-keygen -p -m PKCS8 -f <path>/key_pkcs8 -N ""
   ```

   ECDSA P-256 在 OpenSSH 9.x 默认 `PubkeyAcceptedAlgorithms` 里（`ecdsa-sha2-nistp256`），无需放宽服务端。**两种格式都生成好一起给，并各自用 `ssh -i` 实测登录成功后再交付**，别让用户来回试错。若 App 是粘贴框而非文件导入，提醒用文本编辑器打开文件全选复制。

   **交付前用 openssl 独立验证格式合法**（比 `ssh-keygen -lf` 更能证明结构正确，`-lf` 只看公钥）：

   ```bash
   openssl pkey -in key_pkcs8 -noout -text | head -3   # PKCS#8 -> Private-Key: (256 bit)
   openssl ec   -in key      -noout -text | head -3    # SEC1
   ```

   再查文件无 BOM / 无 CRLF（否则 App 解析失败，且现象和"格式不支持"极像）：

   ```bash
   head -c 3 key | od -An -tx1     # 应为 2d2d2d（'---'），efbbbf 就是 BOM
   grep -c $'\r' key               # 应为 0
   ```

   同时给一份 `.pem` 后缀副本：部分 App 按后缀识别为"可导入文件"，能绕开粘贴环节的换行丢失。

3.2 **"私钥已保存"= 只读态，原地编辑改不动**：用户说"两个格式都试了还是不行"、且仍报同一条格式错误时，几乎都是这个原因。多数 App 的私钥字段保存后变为只读展示，点进去粘贴不会覆盖旧内容。**正确做法：删除整条主机条目，重新添加**，而不是原地编辑。让用户粘贴后先看字段首行是否已变成 `BEGIN PRIVATE KEY` / `BEGIN EC PRIVATE KEY`——首行没变就是没替换成功。

3.3 **报错从"格式不支持"变成"无法建立连接"，但服务端仍零日志**：说明本地格式校验已过，卡在 TCP 层。此时**不要继续猜**，做一个跨客户端对照实验：

   > 让用户用**已经能连的那个 App**（如 ServerCat）连同一台机器。

   - 能连 → 网络没问题，是新 App 自身的配置或实现问题
   - 也不能连 → 用户当前网络到该 IP:22 不通（代理断了 / 蜂窝被挡）

   同时让用户核对 App 里的**端口**是否真是 22——端口填错时服务端同样零日志，与网络不通的表现完全一致。

   注意：隔了几小时后"之前能连现在不能连"很常见，网络环境（Wi-Fi / 蜂窝 / 代理）变了。**不要拿早先的成功记录当作当前网络可用的证据。**
4. 验证某把 key 到底有没有被尝试过：直接 grep 指纹前缀
   ```bash
   journalctl -u ssh -u sshd --since "30 min ago" | grep -i "<指纹前8位>"
   ```

## 换端口：22 被封的标准处置

**症状组合**（四个同时成立才判定为端口被封）：服务端日志零记录、多个客户端同时失败（排除单一 App 问题）、服务端出网正常、负载正常。

### 致命陷阱：socket activation 让 `Port` 配置静默失效

Ubuntu 22.04+ 默认启用 `ssh.socket`。此时：

- `sshd_config` / `sshd_config.d/` 里写 `Port 2222` **完全不生效**；
- 更迷惑的是 `sshd -T` 会**照样显示** `port 2222`，但 `ss -lnt` 里没有该端口。

2026-10-25 实测踩中：写了 `sshd_config.d/00-port-2222.conf` → `sshd -t` 通过 → reload 成功 → `sshd -T` 显示 `port 2222` → **实际只监听 22**。差点误判成"配置没保存"。

**先判断模式**：

```bash
systemctl is-enabled ssh.socket                          # enabled = socket 模式
systemctl show ssh.service -p TriggeredBy --value        # 输出 ssh.socket 就确认
systemctl cat ssh.socket | grep ListenStream
```

**正确改法**（覆盖 socket，不要碰 sshd_config）：

```bash
mkdir -p /etc/systemd/system/ssh.socket.d
cat > /etc/systemd/system/ssh.socket.d/listen.conf <<'CONF'
[Socket]
ListenStream=
ListenStream=0.0.0.0:22
ListenStream=[::]:22
ListenStream=0.0.0.0:2222
ListenStream=[::]:2222
CONF
systemctl daemon-reload
```

`ListenStream=` 空行必须先清空默认值，否则新端口会被叠加成不可预期的结果。

**校验别用 `systemctl cat`**（2026-10-26 实测踩坑）：`systemctl cat ssh.socket` 会把主 unit 和 drop-in 的原文**拼接打印**，主 unit 里的 `ListenStream=0.0.0.0:22` 会照常显示——即使 drop-in 里的空 `ListenStream=` 已经把它清掉，看着像"22 还在"，其实是误判，导致回滚。空 `ListenStream=` 的语义就是清空主 unit 的监听列表。**判断最终生效值**：用 `systemctl show ssh.socket -p Listen --value`，或 restart 后直接 `ss -lnt` 看实际监听（`ss -lnt` 才是最可靠真相，且是"关旧端口"时最终验收的依据）。

**restart 前必须校验**（写错会让 22 也消失，直接锁死自己）：

```bash
LISTEN=$(systemctl show ssh.socket -p Listen --value)
echo "$LISTEN" | grep -qE ':22($|[^0-9])' || { echo "22 丢了，回滚"; rm -rf /etc/systemd/system/ssh.socket.d; systemctl daemon-reload; exit 1; }
systemctl restart ssh.socket
ss -lnt | grep -E ':22 |:2222 '
```

注意 `grep ":22 "` 匹配不到 `0.0.0.0:22 (Stream)` 这种输出（`:22` 后面紧跟 ` ` 之前还有 ` (Stream)`，实际是 `:22 (Stream)`，能匹配；但 `[::]:22` 后面直接是换行会漏），用 `grep -qE ':22($|[^0-9])'` 更稳。

**restart ssh.socket 不会断开已建立的连接**（socket 只管新连接），可安全操作。

### 新端口在 `ss -lnt` 监听但外部仍超时：查 ufw / 主机防火墙

加了端口、`ss -lnt` 也能看到 `0.0.0.0:2222`，但外部 `/dev/tcp` 超时、拿不到 banner——**还有一个防火墙层：ufw（或云安全组）**。2026-10-25 实测：racknerd 那台 `ufw inactive`，加端口直接通；另一台（<YOUR_SERVER_IP>）`ufw active`、默认 `deny (incoming)`、只放行 22/443/80/8388，新加的 2222 被默认 DROP——`ss -lnt` 看着在监听，外面就是连不进。

```bash
ufw status        # active？看已放行端口里有没有新端口
ufw allow 2222/tcp comment "SSH 备用端口"   # 补放行，IPv4/IPv6 都加
```

判据：`ss -lnt` 有监听 + 本机/外部连不上 + 无 sshd 日志 → 别急着怀疑 sshd，先 `ufw status` 和 `iptables -S INPUT` 一起看。ufw 是「默认 deny」策略时，新端口不显式 allow 就是死的。

**别假设每台机器 ufw 状态一致**：同一批 VPS 里可能有的开了 ufw、有的没开，加端口前先 `ufw status` 确认一遍，而不是照搬上一台的成功经验。

### 端口选择

- `2222` / `2022`：非标端口，国内封锁少，首选
- `443`：像 HTTPS，穿透性最好，但可能与现有 web/xray 冲突，先 `ss -lnt` 查
- 保留 22 一段时间做兼容，确认新端口稳定后再考虑关闭

### 验证端口真的可用

```bash
timeout 8 bash -c 'exec 3<>/dev/tcp/<IP>/2222; head -c 80 <&3'   # 必须返回 SSH banner
ssh -p 2222 -i <key> -o IdentitiesOnly=yes root@<IP> 'echo OK'
```

**只看 `ss -lnt` 有监听不算通**，必须拿到 `SSH-2.0-OpenSSH_*` banner + 实际登录成功。

### 关闭旧端口的完整闭环（fail2ban 同步 + 依赖方切换）

换端口不只是加端口。当要**关掉旧端口**时，还有五个坑（2026-10-25 实测）：

1. **fail2ban 保护端口必须同步改**，否则新端口对爆破裸奔。改 `/etc/fail2ban/jail.d/*.local` 里 sshd jail 的 `port = 2222`。

2. **`fail2ban-client reload` 不重建 action**——改 `port` 参数后 iptables 规则不会更新（实测：reload 后 INPUT 链仍是 `--dports 22`）。必须 `systemctl restart fail2ban` 才会把 f2b-sshd 链挂到新端口。

3. **jail.d 多文件 `port` 冲突**：字典序靠后的文件覆盖靠前的，但别信文件内容。restart 后用 `iptables -S INPUT | grep multiport` 看**实际挂载端口**，那才是真相。本次 `sshd-remote-ops.local` 的 `port = ssh` 和 `zz-lemon-sshd.local` 的 `port = 2222` 打架，靠 restart 后看 iptables 才发现。

4. **关旧端口前，先把所有依赖方切到新端口**，否则切断自己。依赖方包括：本机 `~/.ssh/config` 的 Host 块加 `Port 2222`、cron/自动化脚本、其他机器的连接来源。

   **注意**：`~/.ssh/config` 是受保护文件，`patch`/`write_file` 工具会被拒。用 terminal 的 python 精确改，先备份：
   ```bash
   cp -a ~/.ssh/config ~/.ssh/config.bak.$(date +%Y%m%d-%H%M%S)
   python3 -c "import pathlib; p=pathlib.Path('/home/ubuntu/.ssh/config'); s=p.read_text(); old='Host <别名>\n    HostName <IP>\n    User root\n'; new=old.replace('    User root\n','    Port 2222\n    User root\n'); assert old in s; p.write_text(s.replace(old,new))"
   ```

   **别拿 `read_file` 的输出写回（2026-10-29 实测踩中）**：`read_file` 返回的是带行号前缀的 `N|内容` 视图，
   照着 `splitlines()` 再 `write()` 会把 `46|Host dshlab` 这类行号原样写进配置，别名随即失效。
   只用 `open(path).read()` 拿原文，或先 `re.sub(r'^\d+\|', '', line)` 剥前缀；增删 Host 块按块解析
   （遇下一个 `Host ` 或空行即结束），写完必须 `grep -c '^Host '` 核对块数 + 实连一次该别名。
   完整模板见 `references/ssh-config-editing-pitfalls.md`。

5. **关旧端口后，fail2ban 会残留旧端口的 iptables 跳转规则**（restart 时旧 action 卸载不干净）。手动清：
   ```bash
   iptables -D INPUT -p tcp -m multiport --dports 22 -j f2b-sshd
   iptables -S INPUT | grep multiport   # 应只剩 2222
   ```

**验收闭环**（四项全过才算完）：

```bash
timeout 8 bash -c 'cat < /dev/null > /dev/tcp/<IP>/22'            # 旧端口应 Connection refused
timeout 8 bash -c 'exec 3<>/dev/tcp/<IP>/2222; head -c 40 <&3'    # 新端口应返回 banner
ssh -p 2222 -i <key> -o IdentitiesOnly=yes root@<IP> 'echo OK'    # 依赖方仍能登录
iptables -S INPUT | grep -c "dports 2222"                          # fail2ban 已保护新端口
```

## 在远端执行多行脚本

远端排障脚本容易写长。**不要用超长内联 heredoc**（会触发命令解析上限而被整条拦掉，重试同样的写法仍然失败）。正确做法：

```bash
# 1. 本地写文件
write_file -> /home/<u>/.hermes/workspace/<task>.sh
# 2. scp 过去再执行
scp -q -o BatchMode=yes <local>.sh <host>:/tmp/<task>.sh
ssh -o BatchMode=yes <host> 'bash /tmp/<task>.sh; rm -f /tmp/<task>.sh'
```

好处：脚本可复用、可复核、失败后改文件重跑，不用重写整条命令。写操作类脚本内部自带备份 + `sshd -t` 校验 + 失败回滚。

### 短脚本同样会坏在引号上（比长度更隐蔽）

`ssh <host> '...'` 外层是**单引号**，里面的任何单引号都会提前闭合外层。写 Python 补丁时最典型的翻车：

```bash
# 你写的（想改远端 python 文件）
ssh host 'python3 - <<"PY"
if not row or row[2] != 'failed':      # ← 这两个单引号把外层 '...' 提前闭合了
PY'
```

结果是远端文件里被写成 `row[2] != failed`（引号消失），`py_compile` **照样通过**（`failed` 只是未定义变量名），直到运行时才 `NameError`。这类"编译过、运行炸"的静默损坏最难发现。

纪律：

- **远端写 Python 一律走文件传输**（`write_file` → `ssh host 'cat > /tmp/x.py' < /tmp/x.py` → 执行），不要在 `ssh '...'` 里内联带引号的代码
- 不得不用内联时，Python 侧统一用**双引号**字符串（外层单引号不干扰），或 `chr(39)` 拼接
- **`grep -E` 的竖线正则别塞进外层单引号里的双引号**（2026-11-05 实测连坏两次）：`ssh host 'journalctl ... | grep -E "103\.151\.|154\.88\."'` 会被拆词，轻则 `bash: 154.88.: command not found`，重则 grep 整个失效返回空。**这是本技能里最危险的误判**——空结果正好是"服务端零记录"这个核心证据，会把客户端问题误判成"包没到服务器"。正确写法是**外层双引号 + 内层单引号**：
  ```bash
  ssh host "journalctl -u ssh --since '90 min ago' --no-pager | grep -E '103\.151\.|154\.88\.' | tail -5"
  ```
  写完后**必须验一次取样本身有效**：先在已知有记录的主机上跑同一个正则，看到 `matches>0` 才说明命令没写坏，再去解释其他主机上的 `matches=0`。
- **改完必须看实际写入的内容**，不能只信 `py_compile` 通过：`sed -n '<起>,<止>p' <file>` 或 `grep -n '<关键行>' <file>` 逐行肉眼核对
- 字符串替换补丁要 `assert src.count(old) == 1`，并在**全部替换成功后才 write**——中途 assert 失败却已经写了部分，会留下半改状态。本次就是第二次 assert 挂掉、第一次的替换没落盘（好在 assert 在 write 之前，文件没动）
- 行级替换（按 `split('\n')` 索引）比整段字符串匹配更稳，但**改多处时先改后面的索引**，否则前面的插入会让后面的行号偏移

## 汇报口径

- **区分已验证事实与推断**。例：服务端日志里出现某来源 IP 的失败，是事实；"这个 IP 是你手机走代理出来的"是推断，必须标注。
- 不要用"服务端没问题"这种笼统话——用户会理解成"你说没坏但我就是连不上"。要说清楚：**机器没宕、端口通、握手成功，但认证规则拒了你的 key**。一句话版本："不是连不上，是连上了但进不去。"
- 私钥绝不贴在聊天正文里；用文件路径交付，并提醒用户用完删除、建议加 passphrase。
- 输出结论前自检：目标 IP 对了吗？PID 判过了吗？`sshd -T` 的实际值读了吗？改完自己实连验证了吗？

## 案例档案

- `references/case-racknerd-la-20261025.md` — 洛杉矶 RackNerd（<PRIVATE_IDENTIFIER>）ServerCat 登录失败完整排查记录：截图日志、服务端证据、PID 误判与纠正、最终处置。
- `references/mobile-ssh-client-key-formats.md` — 移动端 SSH 客户端私钥格式兼容实录：OpenSSH / PKCS#8 / SEC1 三者差异、`-m PKCS8` 对 ED25519 静默无效的实测、openssl 校验命令、报错演进（有日志 vs 零日志）对照表、跨客户端对照实验方法。
- `references/path-blocked-vs-auth-failure.md` — 多台同时"连接失败"的取证流程：服务端零记录的分层判据、按网段分组对比、第三方主机读 banner 验端口、日志反证、ProxyJump 处置与复现坑。
- `references/client-key-attribution-and-silent-disconnect.md` — 单个客户端"断了"的取证实录（洛杉矶 RackNerd + Codex App）：`ssh-keygen -lf` 指纹→设备台账、按 key 统计登录频率与断点、排除 fail2ban/conntrack/内核丢包、sshd reload 与 restart 的 uptime 差异、Codex session 日志的正确读法。
- `references/multi-host-zero-record-client-egress.md` — 单客户端对三台主机（洛杉矶/香港 NAT/HostPapa）全部失败的取证：逐台真登录、跨主机指纹比对、按主机统计出口网段 `matches` 判据、代理 RST 信号、引号写坏导致的假"零记录"、远端时区不一致坑。
- `references/browser-port-probe-and-app-side-isolation.md` — **"零记录"的两种成因如何分开**：浏览器打开 SSH 端口的决定性探针、`无法解析响应` 是阳性信号、`banner exchange: ... invalid format` 的正确读法、出口 IP 轮换导致旧 IP grep 报假零、证到 App 侧后的删环境重加处置。
