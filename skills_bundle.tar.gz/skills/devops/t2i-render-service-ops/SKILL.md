---
name: t2i-render-service-ops
description: 排查 HTML→图片（t2i）渲染服务：卡片不出图、渲染卡几分钟、模板报错。
version: 1.0.0
author: 柠檬
license: MIT
metadata:
  hermes:
    tags: [t2i, render, playwright, aiohttp, timeout, card, jinja2, debugging]
    related_skills: [astrbot-deploy-ops, telegram-group-bot-suite]
---

# T2I（HTML→图片）渲染服务运维与排障

## When to Use

- 机器人卡片/签到图/榜单图「不出图」「用户说没反应」「要等好几分钟才回」
- 自建或第三方 t2i 服务（`t2i.soulter.top`、`text2img` 类接口）返回 4xx/5xx
- 客户端把错误响应当图片保存，导致后续 `invalid JPEG` / 尺寸校验失败
- 需要判断「是服务慢、服务报错，还是客户端没设超时」

## 1. 先分清三类故障，别一律怪网络

| 现象 | 通常根因 | 判据 |
|---|---|---|
| 卡几分钟才降级/超时 | **客户端没设超时**（aiohttp 默认 total=300s） | 日志里失败时间戳与请求时间差 ≈ 5 分钟 |
| 报 `invalid JPEG` / 尺寸不符 | **客户端不检查状态码**，把 JSON 错误体当图片存盘 | 临时目录出现几 KB「图片」，内容是 `{"code":1,...}` |
| 立刻失败 | 模板 Jinja2 报错 / 端点 403、502 | 响应体直接给出 `template render error: 'xxx' is undefined` |

## 2. 直连服务探测（别靠猜）

```python
import aiohttp, json, time

payload = {
    "tmpl": "<html><body><h1>x</h1></body></html>",   # 或被测项目的真实模板
    "json": False,
    "tmpldata": {},
    "options": {"full_page": False, "type": "jpeg", "quality": 40,
                "clip": {"x": 0, "y": 0, "width": 960, "height": 540},
                "viewport": {"width": 960, "height": 540},
                "animations": "disabled"},
}
async with aiohttp.ClientSession() as s:
    async with s.post(ep + "/generate", json=payload,
                      timeout=aiohttp.ClientTimeout(total=60)) as r:
        b = await r.read()
        print(r.status, r.headers.get("Content-Type"), len(b))
```

**必须用 `json=`**（自动带 `Content-Type: application/json`）。用 `data=` 手工传字符串会得到 **422 Unprocessable Entity**，别误判成服务挂了。

**读 JPEG 尺寸不必装 PIL**：扫 SOF 段
```python
def jpeg_size(b):
    i = 2
    while i < len(b) - 9:
        if b[i] != 0xFF:
            i += 1; continue
        if b[i+1] in (0xC0, 0xC1, 0xC2):
            return (int.from_bytes(b[i+7:i+9], "big"),
                    int.from_bytes(b[i+5:i+7], "big"))
        i += 2 + int.from_bytes(b[i+2:i+4], "big")
```

判读：
- `200 + image/jpeg` → 服务正常，问题在客户端或模板数据
- `500 + application/json` → 模板渲染报错，读 `message` 字段定位缺哪个变量
- `403` → 多半是 UA/风控；带浏览器 UA 复测
- `502` 且耗时极长 → 网关等后端超时，通常意味着 payload 太大或后端崩了

## 3. 常见坑：空数据探测会误报模板错误

用空 `tmpldata` 打真实模板，几乎必然报 `'some_var' is undefined`。**这是探测方法的问题，不是产品 bug**。要判断真实故障：
- 用真实业务数据构造 payload，或
- 直接看客户端 `is_valid_card_jpeg` / 尺寸校验抛错的位置，或
- 在客户端临时打印响应前 200 字节

### 3.1 反向坑：Jinja2 默认非严格，小模板验不出错误

想验证「客户端会不会拦截 500」时，**别用 `{{ undefined_var }}` 造错**。Jinja2 默认 `Undefined` 只把它渲染成空串，服务照样 200 返回一张图，你会误判成「补丁没生效」。

只有参与运算/过滤的变量才抛错（如 `{{ boost_multiplier * 2 }}`、`|round`）。可靠做法：
1. 拿业务真实模板（AstrBot：`from checkin.card import get_checkin_card_template; get_checkin_card_template("default")`，实测 2.07MB）
2. 配**空** `tmpldata`
3. 期望客户端抛 `RuntimeError: HTTP 500 from ...`，而不是返回文件

实测该组合两站都 500（`template render error: 'boost_multiplier' is undefined`），耗时 1.9s / 6.3s —— 服务端其实很快，慢的是客户端没设超时。

## 4. 客户端修复模式（aiohttp）

```python
async def download_image_by_url(url, post=False, post_data=None, path=None, timeout=30):
    async with aiohttp.ClientSession(
        timeout=aiohttp.ClientTimeout(total=timeout)   # 1) 必须有超时
    ) as session:
        async with session.post(url, json=post_data) as resp:
            if resp.status != 200:                      # 2) 必须查状态码
                raise RuntimeError(f"HTTP {resp.status}")
            ...
```

修完效果：500 在数秒内抛出 → 上层 `try/except` 走降级路径（如纯文字卡片），而不是干等 5 分钟。**降级要快，宁可不精美也不能让用户干等。**

## 5. 减少跨境上传成本

模板里内嵌 base64 字体时，单次 POST 可达 2MB+（例如 1.6MB woff2 → 2.07MB payload）。境外机器打国内渲染服务，耗时主要在上传。
- 字体子集化（只留常用字集）能把 payload 砍到 1/4
- 或把渲染服务放到离业务机近的节点
- 或用 `cache_hit` 路径兜住重复请求（同一用户当天第二次渲染可直接复用）

## 6. 排查顺序（照做）

1. 看日志里「请求发出」与「失败/降级」的时间差 → 先定性是慢还是错
2. 直连服务用最小模板探测 → 服务是否活着
3. 用真实模板探测 → 是否模板/数据问题
4. 检查客户端：有没有超时？有没有查状态码？
5. 检查缓存路径是否掩盖了问题（管理员的缓存命中 ≠ 功能正常）
6. 修客户端超时+状态码，让降级在数秒内发生
7. 再考虑模板瘦身或就近部署

## 支持文件

- `scripts/t2i_probe.py` —— 直接可跑的探测脚本：`python3 t2i_probe.py [模板文件] [端点...]`，自动判 200/500/422/403 并读 JPEG 实际尺寸（不依赖 PIL）
- `references/astrbot-checkin-card-case.md` —— 实战案例：AstrBot 签到卡 5 分钟卡死、`download_image_by_url` 缺陷、修复前后耗时对比

## 7. 反模式

- ❌ 看到「没反应」就去查权限/白名单 —— 先查业务数据是否已落库，落库了就是出图问题
- ❌ 拿管理员账号的成功案例当功能正常 —— 管理员常走缓存路径，跳过渲染
- ❌ 服务返回 200 就当成功 —— 内容可能是错误页或尺寸不对，要校验字节头和尺寸
- ❌ 给 aiohttp 请求不设 timeout 就上线 —— 默认 5 分钟会毁掉所有交互体验
