# 案例：AstrBot 签到卡「别人签到没反应」

现场：Telegram 群里管理员签到秒回，群友签到毫无反应。AstrBot v4.29.3，`astrbot_plugin_get_px` v3.8.0，机器在洛杉矶（913Mi）。

## 定性过程

1. **先查业务库**（关键，别先查权限）
   `/opt/astrbot/data/plugin_data/astrbot_plugin_get_px/checkin.sqlite3`
   `checkin_users` / `checkin_records` 里群友记录**已存在** → 签到逻辑成功，问题在出图/发送。
   注意 `checkin_records.background_mode` 为空 = 背景没关联上 = 卡片没生成（正常记录会有 `pixiv_daily` 等值）。

2. **看时间差**
```
11:36:41  签到背景 1 图片下载完成 42.23KB
11:40:35  签到卡渲染失败: 画质=省流量 960x540 错误类型=ValueError
11:40:35  签到卡回退纯文字: stage=card_render
11:41:44  纯文字签到结果送达      ← 用户 11:36:37 发的，等了 5 分钟
```
5 分钟 ≈ aiohttp 默认 total=300s。

3. **直连 t2i 服务探测**
用插件真实模板 + 空 `tmpldata`：
```
{"code":1,"message":"template render error: 'boost_multiplier' is undefined"}
```
→ 服务 1.9s 就返回了，**不慢**，是模板报错。

4. **定位客户端缺陷**：`astrbot/core/utils/io.py::download_image_by_url`
   - 不检查 `resp.status` → 500 的 JSON 被 `save_temp_img` 存成 .jpg
   - 无 timeout → 干等 5 分钟
   - 上层 `is_valid_card_jpeg` 校验「必须是 960x540 JPEG」→ `ValueError`

## 修复（已并入 astrbot-deploy-ops 的幂等补丁脚本 v3）

`download_image_by_url` 加 `timeout: int = 30`、两处 `ClientSession` 传 `ClientTimeout(total=timeout)`、四个 post/get 分支后加 `if resp.status != 200: raise RuntimeError(...)`。

验收（对返回 500 的真实大模板）：
```
t2i.soulter.top:      正确拦截 RuntimeError: HTTP 500  耗时=2.1s
t2i.rcfortress.site:  正确拦截 RuntimeError: HTTP 500  耗时=6.0s
```
原行为 159.6s 才返回 502/存盘失败。

## 为什么管理员「有反应」

管理员当天已签过，`cache_hit=yes` 直接复用缓存卡，**跳过渲染**，秒发。所以他的成功不能证明渲染链路正常 —— 必须测首次渲染（新用户/无缓存）。

## 遗留

`'boost_multiplier' is undefined` 在真实业务数据下是否仍出现未最终确认；当前策略是「失败快速降级纯文字」，卡片出图需再查模板变量兜底或插件版本兼容。

## 相关事实

- AstrBot 渲染默认：`t2i_strategy="remote"`、`t2i_endpoint=""` → `https://t2i.soulter.top/text2img`
- 端点池：`GET https://api.soulter.top/astrbot/t2i-endpoints` → 返回 `data[].url` + `active`
- 备选端点：`https://t2i.rcfortress.site/text2img`（可用但更慢）
- 签到卡模板体积 2.07MB（内嵌 `LXGWWenKaiLite-GB2312.woff2` 1.58MB base64）
