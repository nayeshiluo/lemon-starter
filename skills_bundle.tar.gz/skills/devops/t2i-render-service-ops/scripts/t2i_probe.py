#!/usr/bin/env python3
"""探测 t2i（HTML→图片）渲染服务是否正常。

用法:
    python3 t2i_probe.py                        # 用最小模板测端点存活
    python3 t2i_probe.py <模板文件路径> [端点...]  # 用真实模板测

判读:
    200 + image/jpeg   → 正常（会打印实际尺寸）
    500 + application/json → 模板 Jinja2 报错，读 message
    422               → 你的请求格式错了（多半没带 Content-Type: application/json）
    403               → UA/风控
"""
import asyncio
import json
import sys
import time

try:
    import aiohttp
except ImportError:
    sys.exit("需要 aiohttp: pip install aiohttp")

DEFAULT_ENDPOINTS = [
    "https://t2i.soulter.top/text2img",
    "https://t2i.rcfortress.site/text2img",
]

MIN_TMPL = "<html><body style='margin:0;background:#123'>" \
           "<h1 style='color:#fff'>probe</h1></body></html>"


def jpeg_size(b: bytes):
    """不依赖 PIL，从 SOF 段读 JPEG 宽高。"""
    if b[:2] != b"\xff\xd8":
        return None
    i = 2
    while i < len(b) - 9:
        if b[i] != 0xFF:
            i += 1
            continue
        if b[i + 1] in (0xC0, 0xC1, 0xC2):
            h = int.from_bytes(b[i + 5:i + 7], "big")
            w = int.from_bytes(b[i + 7:i + 9], "big")
            return f"{w}x{h}"
        i += 2 + int.from_bytes(b[i + 2:i + 4], "big")
    return None


async def probe(ep: str, tmpl: str, timeout: int = 60):
    payload = {
        "tmpl": tmpl,
        "json": False,
        "tmpldata": {},
        "options": {
            "full_page": False,
            "type": "jpeg",
            "quality": 40,
            "clip": {"x": 0, "y": 0, "width": 960, "height": 540},
            "viewport": {"width": 960, "height": 540},
            "animations": "disabled",
        },
    }
    host = ep.split("//")[-1][:28]
    t = time.time()
    try:
        async with aiohttp.ClientSession() as s:
            # 必须用 json= ，否则服务返回 422
            async with s.post(ep + "/generate", json=payload,
                              timeout=aiohttp.ClientTimeout(total=timeout)) as r:
                b = await r.read()
                ct = r.headers.get("Content-Type", "")
                el = time.time() - t
                print(f"  {host}: status={r.status} ct={ct[:18]} "
                      f"bytes={len(b)} size={jpeg_size(b)} 耗时={el:.1f}s")
                if r.status != 200:
                    print(f"    body: {b[:200]}")
    except Exception as e:
        print(f"  {host}: {type(e).__name__} {str(e)[:70]} 耗时={time.time()-t:.1f}s")


async def main():
    args = sys.argv[1:]
    tmpl = MIN_TMPL
    if args and not args[0].startswith("http"):
        with open(args[0], encoding="utf-8") as f:
            tmpl = f.read()
        args = args[1:]
        print(f"模板: {args and ''}{len(tmpl)/1024/1024:.2f} MB")
    endpoints = args or DEFAULT_ENDPOINTS
    for ep in endpoints:
        await probe(ep, tmpl)


if __name__ == "__main__":
    asyncio.run(main())
