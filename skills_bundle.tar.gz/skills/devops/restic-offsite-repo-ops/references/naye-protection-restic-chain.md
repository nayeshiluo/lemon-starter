# 案例记录：append-only 仓库的 507 配额墙（2026-11-06 实测）

> 具体主机名用占位符替换，保留可复现的数字与判据。同类链路照此对号。

## 拓扑

| 层 | 实测值 |
|---|---|
| 客户端 | restic **0.14.0**（go1.19.8） |
| 服务端 | rest-server **0.14.0**（go1.24.3），二进制 `/usr/local/bin/naye-rest-server`（自定义名，非标准 `rest-server`） |
| 隧道 | `ssh -NT -p 2222 -L 127.0.0.1:27184:127.0.0.1:27184 <ingest>@<vps>`，进程名只是 `ssh` |
| 服务端参数 | `--append-only --private-repos --path <repos-root> --listen 127.0.0.1:27184 --max-size <YOUR_USER_IDENTIFIER>` |
| 仓库路径 | `<repos-root>/<user>/core`，属主 `<owner>:<owner>` `700` |
| 调度 | backup timer **每小时** → `backup.py`（42 个 SQLite 在线 snapshot 进 `staging/` 再整体备份） |
| 巡检 | health timer **每分钟**，阈值 `age>4500`（75 分钟） |

## 故障表现

`backup.py` 抛 `RuntimeError: Restic backup failed, code 1`；
`/var/lib/<svc>/last-backup.log` 刷屏：

```
Save(<data/c410522ade>) returned error, retrying after 4.755863245s:
  server response unexpected: 507 Insufficient Storage (507)
...
Fatal: unable to save snapshot: server response unexpected: 507 Insufficient Storage (507)
```

`systemctl show <backup>.service` 给出 `Result=success` 但 `ExecMainStatus=1` ——
**`Result` 只看单元是否正常结束，判断成败必须看 `ExecMainStatus`。**

告警链：health 每分钟检查 → 最后一次成功快照是 08:00，到 09:16 跨过 75 分钟 →
`alerts/current.txt` 变成「异地备份超过 75 分钟没有成功更新」并私聊推送。

## 关键数字

| 指标 | 值 |
|---|---|
| `du -sb` 仓库 | 3 494 381 306 B ≈ 3.25 GiB |
| `restic stats --mode raw-data` | 29 快照 / 37 963 blobs / 3.140 GiB |
| `--max-size` | 5 368 709 120 B = 5 GiB |
| 远端 `df` | 34 G 中 25 G 用、7.3 G 可用；inode 16 % |
| `data_added`（手动一次） | 440 774 332 B ≈ 420 MB |
| repo 每小时净增（由 26h 涨到 3.6 G 反推） | ~100–124 MB |

**`du` 3.25 GiB 远低于配额 5 GiB，却稳定 507。**
给 `grep` 找 507 触发条件时，`strings` 只翻到 `max-size` 一类字段，无法从二进制反推公式。

**决定性二分**：把 `--max-size` 从 5 GiB 提到 6 GiB、`daemon-reload` + 重启后，
**同一份数据立刻写入成功**（`snapshot 9997dc51`，21 秒）。→ 闸门确实在配额上，
`du` 与 rest-server 内部计数口径不一致，且这个不一致没有便宜途径可以精确解释。

## 三处配额的一致性问题

`backup.json` 里 `"offsite_capacity_bytes": <YOUR_USER_IDENTIFIER>` 与 service 的 `--max-size`
各写一份。`health.py:72`：

```python
if used > backup_config['offsite_capacity_bytes'] * 0.85:
    issues.append('异地备份仓库已超过容量上限的 85%')
```

只改 service 不改 json → 配额已经 6 GiB，health 仍按 5 GiB 的 85 %（4.25 GiB）判超容，
**几个小时内必然再报一次**。用 `python -c "json.load(...)"` 回读验证，不要 `sed` 改 JSON。

## append-only 挡住客户端 prune

`grep -rn "forget\|prune" /usr/local/libexec/<svc>/` 只有一行注释：

```
"""Root-owned, consistent application backup runner; no production repair/prune."""
```

即：**保留策略整条缺失**，快照只增不减。而 `--append-only` 让客户端无法补——
只能登远端以属主身份跑。

## 预 prune 安全副本：为什么必须硬链接

远端只剩 7.3 G、仓库 3.5 G。`cp -a` 后余量 3.8 G，而 `prune` 重打包还要写新 pack →
中途爆盘的概率很高。改用：

```bash
mkdir -p /var/lib/<restic>/preprune-<ts>
cp -al /var/lib/<restic>/repositories/<user>/core /var/lib/<restic>/preprune-<ts>/core
```
`du --apparent-size` 3.5 G，`df` 的 used **一字节没变**，耗时 4.6 秒。

副本放在 `<repos-root>` 的**上级**（`--path` 指向 `.../repositories`，副本在 `.../preprune-*`），
避免被 rest-server 当成新 repo 暴露。

副本可读性验证：`sudo -u <owner> restic -r <副本> --password-file <pw> snapshots --compact`
→ 31 个快照，与源一致。

## 密码投递

本地 `/etc/<svc>/restic-password`（65 B，root 600）→ 远端临时文件：

```bash
cat /etc/<svc>/restic-password | ssh <vps> \
  'sudo -n sh -c "umask 077; cat > /etc/<svc>/pw-tmp; \
   chown <owner>:<owner> /etc/<svc>/pw-tmp; chmod 600 /etc/<svc>/pw-tmp"'
```
用完 `rm -f`，并用 `ls` 失败信息确认已不存在。脚本里用 `trap cleanup EXIT`。

## `--group-by` 陷阱的实测数据

默认分组（`host,paths`）下，31 个快照的库 dry-run 输出：

```
1 snapshots
keep 1 snapshots: 4e701f81 ...
Would have removed the following snapshots: {5880cd03}
```

只有 1 保留 1 删除 —— **因为路径集合有差异，被拆成多组，每组单独算**。
加 `--group-by host` 后同一条命令输出：

```
6 snapshots
Would have removed the following snapshots:
{520a0335 5880cd03 6c51527d 846ea0d4 d6261814 e16950bf}
```
保留 25 / 删除 6 / 总数 31，自洽。

## prune 收益接近零

- `forget`（keep-hourly 24 / daily 7 / weekly 4 / monthly 3）：删 6 个快照，`FORGET_RC=0`
- `prune`：`[0:00] 100.00% 36 / 36 files deleted`、`PRUNE_RC=0`
- `restic check --read-data-subset=10%`：`no errors were found`
- **`du` 3.6 G → 3.43 G，只降 0.17 G**

原因：每小时增量快照高度重叠，被删的 6 个没有独占数据。

补自动 prune 单元后再跑一次（keep-hourly 8 / daily 4 / weekly 4 / monthly 3）：

- 重打包 51 packs、重建索引 164 packs、删 70 个旧 pack，`no errors were found`
- 快照 26 → **10**，repo 3.4 G → **2.6 G**，`df` 可用 7.3 G → **7.9 G**
- 这次真降了 —— 因为 `keep-hourly` 从 24 砍到 8，删掉的快照里**终于有**独占数据

结论：**prune 能不能释放空间，取决于被删快照有没有独占数据，而不取决于删了几个。**
先 dry-run 看删除集合，再预判能省多少。

## 改频率后的阈值连带

backup timer 从每小时改成每 3 小时（`OnCalendar=*-*-* 00,03,06,09,12,15,18,21:00:00`）后：

- health 阈值 75 分钟 → **210 分钟**（`age>4500` → `age>12600`），文案同步改
- 不改进则每 3 小时之间必然告警一次（最长间隔 3h01m > 75min）

## 最终验收（实测通过值）

| 项 | 值 |
|---|---|
| `restic check` | `no errors were found` |
| `find <repo> -not -user <owner>` | 无输出 |
| 真实 backup | `snapshot 2086d5ca`，`EXIT=0`，258 MB 增量 |
| `health.json` | `backup_age_seconds: 14`、`issues: []` |
| 配额占用 | 2.52 GiB / 6 GiB = **42.1 %** |
| `alerts/current.txt` | `✅【数据保护巡检】此前报告的保护链路异常已恢复` |
| timer 三件套 | backup / prune / health 全 `active` |
