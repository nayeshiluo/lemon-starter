# .hermesenc 式异地链的接收端更换（2026-11-18 实录）

> 适用形态：`scp 上传 + 远端 python 断言门禁 + prune_remote` 的加密异地备份（非 rest-server）。
> 日报 `统一备份=FAILED`、失败点在「向异地发送加密副本」阶段时按此排查。

## 一、先判根因类别：门禁线 vs 带宽 vs 权限

失败 traceback 落在 `publish()` → `remote_python()` 时，远端断言只有几种：

| 断言文本 | 根因 |
|---|---|
| `LA would have less than N GiB free after this upload` | 接收端磁盘卡门禁线 |
| `Ciphertext digest mismatch` | 传输损坏 |
| 其他 exit 非 0 | 权限 / 路径 / host key |

门禁断言的公式通常内嵌在脚本里（例：`free > 4GiB + 包体积`）。**关键认识：这是结构性不是抖动** ——
每次成功上传都会把 free 再压低一个包体积，「今天险过、明天必挂」。换接收端是治本，清磁盘只是续命。

排查命令口径（源机本地，注意失败包按设计保留，别急着删）：

```bash
# 失败留存 workspace（preserved private workspace）就是现成的验收弹药
ls /home/ubuntu/hermes-jobs/tmp/offsite-*/          # 里面有 .hermesenc 真包
ssh <接收机> 'python3 -c "import shutil;print(shutil.disk_usage(\"<REMOTE>\").free)"'
```

## 二、迁移五步（全部实测过的顺序）

1. **备份脚本**：`cp -a offsite_backup.py offsite_backup.py.bak-<tag>-<ts>`。
2. **新接收端建目录**：`mkdir -p <REMOTE>` + `chmod 700`，确认 `df` 余量 ≥ 门禁公式需求 × 2。
3. **旧包迁移**：两端 sha256 先取基线；传输后逐一核对。若旧→新接收机直连被授权拦截/无互信密钥，
   **用源机中转**：源机对两端都有已验证密钥时，`scp 拉下来 → scp 推上去`，两段各验校验和。
   （注意背景长传要用 `background=true + notify_on_complete`，前台 600s 上限会打断 1GB 级文件。）
4. **改脚本引用**：备份主机名会出现在**三处**——`SSH` 常量、scp 上传目标、`--verify` 取回目标。
   `grep -n "<旧主机>" offsite_backup.py` 必须归零；`StrictHostKeyChecking=yes` 要求新主机 key
   已在 known_hosts（先手动 ssh/scp 一次即写入）。
5. **端到端验收**：不要等下一个调度点，直接 import 脚本用**失败留存的真包**跑真函数：

```python
import sys; sys.path.insert(0, '<releases目录>')
import offsite_backup as ob
name, expected = ob.publish(Path('<留存包>'), Path('<对应快照目录>'))
r = ob.prune_remote()   # 验证保留策略在新端生效：retained 数与 max_files 一致
```

验收通过后再删留存包与中转临时目录。

## 三、迁移后必须扫的连带消费方

改完上传目标不等于链路收敛。逐项核对：

- `grep -rln "<旧接收路径>"` 所有 .sh/.py：区分**活跃调度引用**与历史一次性脚本（无 timer/cron 引用的旧
  `aws-*` 命名脚本是死文件，不构成误报源，不要顺手删）；
- 备份校验器（`backup-verify.py` / `backup_policy.py`）是否直连旧接收机探测——若只读本地 ledger 则无需改；
- 旧接收机上的包**先保留**，等新链跑满一个保留周期后再清理，期间它是唯一完整回退点。
  **但不必机械等满一个周期**（2026-11-18 实测）：满足下面两条即可判为孤儿并回收空间——
  ① 新接收端已通过 §4.1 的**取回→解密→隔离恢复**验证（不是只有 sha256）；
  ② 备份是**每日全量**，新端最新包已包含旧端残留包的全部内容（比对 `job.log` 里的
  `snapshot` 时间戳与包内 `BACKUP_POLICY.json`）。两条都成立时，旧端那几个包是纯死数据，
  留着只是占磁盘。本次据此回收 vps-la 上 1.9 GB（两个包），释放后 free 5.3 G → 7.3 G。
  反之，只要有一条不成立（增量备份、或恢复验证没跑过），就必须等满周期。

## 四、最终验收 = 下一个真实调度点

脚本级验收（第三节）只能报「已改」；**已验证**必须等 daily job 真跑一次、新端出现当日包、
日报状态转 SUCCESS。`scp_timeout` 公式按实测带宽估算（例：0.89 MB/s 跨境 → 960M 包 ~18min），
若新线路明显更慢要复核超时上限。

### 4.1 `--verify` 分支默认关闭 ⇒ 异地副本可恢复性可能从未被验证过（2026-11-18 实测）

这是本类链路最容易漏的一层。`publish()` 里的远端 sha256 只证明**字节搬对了**；
取回 → 解密 → 隔离恢复验证是**另一个分支**，而它通常挂在环境变量后面：

```bash
OFFSITE_ARGS=()
[ "${HERMES_BACKUP_VERIFY:-0}" != 1 ] || OFFSITE_ARGS+=(--verify)   # 默认 0 = 不做
```

后果：日报天天 `SUCCESS`、`job.log` 有 `ciphertext_sha256`、`retention` 数字正常，
但**「这份异地副本能不能恢复」从来没被真实跑过**。换接收端（尤其换到高速链路）时
必须补这一次，否则「已验证」三个字没有依据。

验收脚本（可直接复用 `scripts/verify_offsite_retrieve.py` 的思路）：
从远端 `scp` 取回 → `digest()` 比对 → `decrypt()` → `verify_archive()` 到隔离目录。

通过判据（全绿才算 PASS）：取回 sha256 一致 → 解密成功 → 返回体里
5 个数据库 integrity `ok` + 每个嵌套归档 gzip `ok` + `host_files_verified` 达到预期。
本次实测输出形态：

```
[2/4] sha256 e7ede305…b36d4  match=True
[4/4] RESTORE_VALIDATION {"files_verified":10,"databases_verified":[...5个...],
        "nested_archives_verified":{"unified/configs.tar.gz":{"gzip_integrity":"ok","members":3607,
        "online_databases_restored":17}, ...}}
RESULT: PASS
```

通过后把开关写进 cron，让每日备份自带真实恢复验证（本环境香港链路 3.7 MB/s，
取回 968 MB ≈ 4.4 分钟，成本可接受）：

```cron
30 11 * * * HERMES_BACKUP_VERIFY=1 /usr/bin/python3 .../cron-status.py unified-backup -- ...
```

cron 行前置的 `VAR=1 cmd` 是合法的（cron 用 `sh -c` 执行），改完用
`sh -c 'HERMES_BACKUP_VERIFY=1 python3 -c "import os;print(os.environ.get(\"HERMES_BACKUP_VERIFY\"))"'`
自证环境变量真的传进去了。

**验收等级的措辞纪律**：`PUBLISH_OK` / 本地 `source_validation` / 远端取回解密恢复
是三档不同强度的证据，**不能互相替代**。只有最后一档通过才能说「异地副本可恢复」。

## Pitfalls

- **别把失败当时的一次 free 读数当长期判据**：门禁是「随每次成功上传单调恶化」的线，必须按
  「传完这个包后还剩多少」推演明天，不能只看今天过没过。
- **中转传输时校验和两头都要核**（源→中转、中转→目标各一次），只核一端等于没验。
- **留存 workspace 里的 .part / 临时目录**：失败按设计 preserve，验收复用后记得清理，否则源机
  tmp 目录会吃掉 GB 级空间。
- 留存包路径容易搞混：preserved workspace 在 `<hermes-jobs>/tmp/`，不在系统 `/tmp/`。

## 五、rest-server 形态的接收端迁移（2026-11-18 实录，进行中）

`.hermesenc` 与 restic 是两条不同的链，换机步骤也不同。rest-server 侧要搬的是**整个仓库目录**。

1. **先停旧接收端**（`systemctl stop <rest-server>.service`）再打包，避免迁移窗口内写入产生新 pack
   造成两库分裂。打包前记基线：`du -sb <repo>`、文件数、全量 sha256 汇总（`find -type f -exec sha256sum | md5sum`）。
2. **二进制同架构直接复制**：`md5sum` 两端必须一致，起服务前 `--version` 确认（实测 rest-server 0.14.0
   ELF 直接可用）。别在新机重新编译——版本漂移会让仓库元数据不兼容。
3. **凭据与属主**：先建系统用户 `<repo-owner>` / `<ingest-user>`；`htpasswd` → `640 root:<owner>`、
   `password` → `600 root:<owner>`、`/etc/<svc>` → `750 root:<owner>`；`repositories/<user>` 700 且属主是
   `<repo-owner>`。凭据经临时文件 `install -m ... -o -g` 落位后立刻删临时文件，不要 cat 到终端。
4. **systemd 单元照抄旧机**，只改 `--max-size`（换机是唯一顺便抬配额的时机，本次 8G→16G）；
   保留 `--listen 127.0.0.1:<port>` 与 `--append-only --private-repos`，端口不变便于隧道只改主机名。
5. **仓库数据迁移**：7.5 G 级，`tar -C <repos-root> -cf - <user> | gzip -1` 经 hub 中转；实测跨境
   ~1 MB/s，全程 2 小时以上，**必须 `background=true + notify_on_complete`**，中途用
   `process wait` 轮询进度（对比两端文件大小），不要 kill 重传。
6. 解包后 `chown -R <owner>:<owner>`，校验文件数与字节数与基线一致，再起服务。
7. 验收：`restic snapshots` 份数与旧机一致 → `restic check` → 触发一次真实备份 → quota / health 数字回落。

**Pitfall**：迁移期间源机与目标机的 rest-server **不能同时对外可写**，否则两库各自追加，之后无法合并。
先把旧机停掉、隧道指向新机、再起新机，是同一条时间线里的顺序，不是三件独立的事。

### 5.1 建接收端的可复制命令块（2026-11-18 实测）

```bash
# 目标机：用户与目录
useradd --system --home /var/lib/naye-restic --create-home --shell /usr/sbin/nologin naye-restic
useradd --system --shell /usr/sbin/nologin --create-home naye-ingest
mkdir -p /var/lib/naye-restic/repositories/naye /etc/naye-restic
chown -R naye-restic:naye-restic /var/lib/naye-restic
chmod 700 /var/lib/naye-restic/repositories /var/lib/naye-restic/repositories/naye
chmod 750 /etc/naye-restic && chown root:naye-restic /etc/naye-restic

# 凭据（经 hub 中转落到临时文件再 install，不要 cat 到终端）
install -m 640 -o root -g naye-restic /tmp/htpasswd /etc/naye-restic/htpasswd
install -m 600 -o root -g naye-restic /tmp/password /etc/naye-restic/password
rm -f /tmp/htpasswd /tmp/password

# 单元：照抄旧机，只把 --max-size 8G→16G；端口 27184 保持不变
systemctl daemon-reload && systemctl enable --now naye-rest-server.service
ss -tlnp | grep 27184      # 断言：只 LISTEN 127.0.0.1
```

目标端 rest-server **可以提前起**（只监听 127.0.0.1、还没有客户端指向它，无副作用），
这样能在数据落位前就验证二进制、凭据、单元三件事；但「验收」仍然必须等仓库数据到齐。

### 5.2 跨机直连经常不可用，用 hub 中转

- 源机通常**没有**目标机的 ssh 别名或密钥：`scp` 报 `Could not resolve hostname <name>` 或
  `Permission denied (publickey)`。`~/.ssh/config` 里只有源机自己认识的几个 Host。
- 用**两端都有已验证密钥的 hub 机**（通常是跑 Hermes 的这台）两段拉推；优先 **pull 方向**
  （从有密钥的一侧发起），别为了迁数据给源机新发一把钥匙。
- 工具侧还会对 `scp root@<raw-IP>` 这类命令做安全拦截（需要人工批准），所以直连方案本来就不稳。
- 7.5 G 级仓库跨境 ~1 MB/s ≈ **2 小时以上**：`background=true + notify_on_complete`，
  中途 `process wait` 后**对比两端文件大小**判进度（`ls -la <目标>:/tmp/x.tar.gz`），
  不要因为等待超时就 kill 重传——重传等于从头再来。
- 迁移窗口按备份周期挑：3 小时一次备份 ⇒ 两次备份之间有近 2 小时可用；把停服务放在
  备份刚跑完的时刻最安全。
- **迁移会跨过下一个调度点时，主动错峰**：跨境链路总带宽只有 ~1 MB/s，大文件迁移与定时备份
  同时跑会各自逼近超时上限。
  **`kill -STOP <scp pid>` 并不能腾出带宽（本条已被 2026-11-18 实测推翻，原写法是错的）**：
  实测 STOP 之后备份侧仍只有 43–84 KB/s，因为 TCP 会话还挂着、对端 sshd 与内核缓冲仍在占位。
  唯一有效的是 `kill -TERM <pid>` 真正断开连接，带宽立刻回到独占。
  所以迁移**必须做成可续传**（见 §5.3），才敢在调度点前直接终止，而不是指望挂起。

### 5.3 大文件跨境传输用 rsync 续传，不要用裸 scp 赌超时（2026-11-18 实测）

同一条 `naye→aliyun` 线路，同一份 960 MB 包：

| 方式 | 实测速率 | 中断后 |
|---|---|---|
| `scp` 单流（RTT 312ms） | 40–250 KB/s | 从头重传，1334s 超时只到 72–97 MB |
| `rsync --partial --append-verify` | ~490 KB/s | 从已传字节续传，远端 sha256 断言仍然把关 |

结论：**高 RTT 且速率会中途塌陷的跨境链路上，scp 单流不可用于 GB 级传输**。
rsync 的窗口/流水线在这种链路上明显更吃得开，且超时只中断本次尝试、重试不重传。

改造要点（`.hermesenc` 那类 `publish()`）：

```python
# 远端必须先有 rsync：apt-get install -y rsync（Debian 11 实测 3.2.3 可用）
rsync = ['rsync', '-a', '--partial', '--append-verify',
         '-e', 'ssh -o BatchMode=yes -o StrictHostKeyChecking=yes -o ConnectTimeout=8',
         str(encrypted), '<host>:' + REMOTE + '/' + name + '.part']
subprocess.run(rsync, timeout=scp_timeout(encrypted.stat().st_size), check=True)
# 之后的远端 sha256 断言保持不变 —— 续传/半截文件的完整性由它兜底
```

`--append-verify` 会重算已存在部分的校验和：前一次 scp 留下的半截文件如果内容对不上，
rsync 会退回整传，所以「续传」不会把损坏数据当完整。

超时公式按实测最慢值定，不要按乐观值：

```python
# 旧：min(1800, max(900, size/(0.8MB/s)+180))  ← 链路塌到 0.25MB/s 时必挂
def scp_timeout(size_bytes):
    return min(7200, max(1200, int(size_bytes / (0.25 * 1024 ** 2)) + 300))
```

**判定「是源机出网问题还是某一条目的地路径问题」**：同一时刻对两个目的地各传 8 MB 对比。
实测 `naye→vps-la` 仍 1 MB/s、`naye→aliyun` 掉到 0.25 MB/s ⇒ 源机出网正常，是那条国际路径
塌了，此时换协议/续传才是正解，查源机没有任何收益。

**错峰的真正做法**：不要靠「记得手动暂停」。要么把迁移放进与备份同一个 `flock`，
要么接受迁移随时被终止——前提是它可续传（§5.3）。本次事故的直接原因就是
「说了要在调度点前暂停，实际没设」，导致当日 `unified-backup` 因带宽被占而 scp 超时失败。

### 5.4 换接收端前必须过的吞吐闸门（2026-11-18 实测，本条修正了本文件的默认假设）

§五 教的是「怎么搬」，但本次真实结局是：**搬到一半判定目标机不可用，全部回退改道**。
如果开工前先做这个闸门，几小时的跨境传输可以完全省掉。

三轴闸门，缺一不可：

| 轴 | 判据 | 只满足这一轴的后果 |
|---|---|---|
| 磁盘余量 | `free >` 门禁公式需求（如 `4GiB + 包体积`） | 空间够但永远传不完 |
| 门禁公式 | 目标机现有断言能否**长期**满足（随每次成功上传单调恶化） | 今天险过、明天必挂 |
| **源端可达吞吐** | 包体积 / 实测速率 < 调度间隔 | 每天超时失败，且看不到尽头 |

**吞吐怎么测：单流 vs 4 并发，一次就能定性。**

```python
import subprocess, time, concurrent.futures
def up(host, mb=2):
    t0 = time.monotonic()
    subprocess.run(['ssh','-o','BatchMode=yes',host,'cat > /dev/null'],
                   input=b'\0'*(mb*1024*1024), timeout=300)
    return mb/(time.monotonic()-t0)
# 先单流一次，再 4 线程各传一次，比较「合计吞吐」是否叠加
```

判读规则（本次实测，同一源机、同一时段）：

| 目标 | 单流 | 4 并发合计 | 结论 |
|---|---|---|---|
| aliyun（北京，跨境） | 195 KB/s | **178 KB/s** | 并发不叠加 ⇒ **路径级硬顶**，换协议/调超时都救不了 |
| vps-la（洛杉矶） | 332 KB/s | 1422 KB/s | 叠加 ~4× ⇒ 单流限速，多流可用 |
| **yecao（香港）** | **3772 KB/s** | — | 直接可用：968 MB 包 **35 秒** 传完 |

> **并发不叠加 = 路径级 cap（丢包/整形）；并发叠加 = 单流限速。**
> 前者只能换目的地，后者可以靠多流/rsync 解决。不做这一步，就会在一个 180 KB/s 的
> 目的地上反复重试、改超时、改协议，全部无效——这正是本次浪费掉的那几个小时。

辅助证据：`nstat -az | grep -E 'TcpRetransSegs|TCPLostRetransmit|TcpExtTCPTimeouts'` 取两次读数做差。
本次 aliyun 方向重传从 8.2 万涨到 **122 万**、`TCPLostRetransmit` 16 万 ⇒ 跨境丢包是根因，
不是源机问题；同一时刻源机到另一目的地仍有 1 MB/s 即可证明源机出网正常。

**测反向方向时别测成空跑**：`ssh B 'dd ... | cat > /dev/null'` 的数据生成与丢弃都在 B 上，
一个字节都没过网，测出来的只是 ssh 握手时间。正确写法：

```bash
ssh B 'dd if=/dev/urandom of=/tmp/t.bin bs=1M count=8'   # 先在 B 上造文件
ssh B 'cat /tmp/t.bin' > /dev/null                        # 数据真正从 B 流到本地
```

**选定目标后落地时的两个细节**：

- `rsync -a` 保留源端 uid，会在目标端落成 `1000:1000`；目录 700 却放着一个非本机用户的文件，
  之后 `os.replace` 也沿用旧属主。加 `--no-owner --no-group`，让远端按 ssh 用户归属。
- 目标机没装 rsync 时报 `bash: line 1: rsync: command not found` +
  `protocol data stream (code 12)`。这不是网络问题，先 `apt-get install -y rsync`。

**改道必须交代三件事**：本次是「用户已选定迁 aliyun」之后被实测推翻的。回退时同时给出
① 旧目标为什么不成立（实测数字）② 新目标为什么成立（实测数字）③ 旧目标上已产生的中间态
（空转的 rest-server、半截 `.part`、中转 tar）如何处置。只报「改好了」等于把用户的决策无声抹掉。
