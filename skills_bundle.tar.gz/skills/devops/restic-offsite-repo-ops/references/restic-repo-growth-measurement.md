# restic 仓库增长：怎么量，以及三种量错的方式

实测环境：restic 0.14.0（客户端）/ 0.16.4（服务端），rest-server 0.14.0，
仓库 26.4k 文件 / 3.9 GB 处理量 / 每小时快照。采样 2026-11-06。

**结论先行**：restic 的 `data_added` 单次读数**不能**用来推算增长趋势。
同一份数据，「每小时 258 MB」是错的，「每小时 2.2 MiB」才是真的——差 100 倍，
而错的那个读数已经写进过一次结论并被后续测量推翻。

## 一、三层口径，别混用

| 口径 | 从哪取 | 含义 | 能推趋势？ |
|---|---|---|---|
| 仓库总大小 | `du -sh`、health.json 的 `repository_pack_bytes` | 磁盘占用 | ✅ 端到端唯一可信 |
| 快照间真实差异 | 两个快照的 `restic ls --json` 对差 | 数据到底变没变 | ✅ 但必须比 **content hash** |
| `data_added` | 单次 `restic backup --json` 的 summary | 本次写入后端的字节 | ❌ 不是稳态 |

`data_added` 在 prune 重打包、人工大批改文件、索引重建之后会严重虚高。
估速率**只取两次「纯定时、中间无人操作」的相邻快照**。

## 二、量错方式 A：`restic diff` 拿不到大小

```bash
restic diff <snapA> <snapB>            # 文本：只有 + / - / M 和路径
restic diff <snapA> <snapB> --json     # 0.14 的 JSON 只有 message_type/path/modifier
```

0.14 的 `diff --json` **不含 size_before / size_after**，按 `+` 行排序算增量会得到全 0。
别在这条路上写解析代码，直接用 `ls --json` 自己算。

## 三、量错方式 B：只比文件大小（本次真正的坑）

用 `restic ls --json` 取 `size` 做差看着严谨，其实**完全漏掉「大小不变但内容变了」的文件**，
而 SQLite、日志、tar 恰恰是这种。当时正是靠这个错口径得出「staging 只变 30 MB、
对不上 258 MB 新增」的假矛盾，再据此编了一个错误根因。

正确做法是比 `content` 字段（内容块的 sha256 列表），它才是 restic 去重的真实依据。

```python
import json, subprocess

def ls(snap, env):
    """返回 {path: (size, content_tuple)}；content 才是判据。"""
    p = subprocess.run(['/usr/bin/restic', 'ls', '--json', snap],
                       capture_output=True, text=True, env=env, timeout=1200)
    out = {}
    for line in p.stdout.splitlines():
        line = line.strip()
        if not line.startswith('{'):
            continue
        try:
            r = json.loads(line)
        except ValueError:
            continue
        if r.get('struct_type') != 'node' or r.get('type') != 'file':
            continue
        out[r['path']] = (r.get('size') or 0, tuple(r.get('content') or ()))
    return out

a, b = ls('snapA', env), ls('snapB', env)
diff = [(a[k][0], k) for k in a
        if k in b and a[k][0] == b[k][0] and a[k][1] != b[k][1]]
print('大小相同但内容变化:', len(diff), sum(s for s, _ in diff) / 1024**2, 'MiB')
```

字段细节：
- `struct_type` 必须是 `'node'`、`type` 必须是 `'file'`，否则目录和 summary 行会被算进去；
- 大文件的 `content` 可能为空列表，此时只能退回「size + mtime」近似，并在结论里标注是近似。

## 四、量错方式 C：拿手工触发的备份当稳态

本次「258 MB / 420 MB」两个高值都紧跟在人工 prune（重打包 51 pack、删 70 pack）
和大批改代码 + 生成 `.bak` 之后。判据：

```bash
systemctl show <backup>.timer -p LastTriggerUSec     # 定时触发时间
systemctl show <backup> -p ExecMainExitTimestamp     # 实际结束时间
```

两者吻合、且日志里没有 prune / 大批文件改动，才算稳态样本。

## 五、顺手证伪「SQLite 每轮重写导致重复上传」

怀疑 `sqlite3.backup()` 每次产出字节不同 → restic 无法去重。写个确定性测试一票否决，
别靠推理：

```python
import sqlite3, hashlib, tempfile

def snap(src, dst):
    s = sqlite3.connect('file:' + src + '?mode=ro', uri=True, timeout=20)
    d = sqlite3.connect(dst)
    try:
        s.execute('BEGIN')
        s.execute('SELECT name FROM sqlite_schema LIMIT 1').fetchone()
        s.backup(d, pages=512)          # 与生产 backup.py 同参数
    finally:
        d.close(); s.close()
    return hashlib.sha256(open(dst, 'rb').read()).hexdigest()

for src in [小库1, 小库2]:
    t = tempfile.mkdtemp()
    print(src, snap(src, t+'/a.sqlite') == snap(src, t+'/b.sqlite'))
```

实测 3 个未变化的库（848 KB / 2 MB / 594 KB）**全部 True**，字节完全一致 → 假设不成立。
前提是采样期源库没有写入；有活跃写入的库本来就会产生新 chunk，不算 bug。

## 六、实测基线（量级参考）

| 观测 | 数值 |
|---|---|
| 纯定时一小时（26k 文件 / 3.9 GB 处理量） | 真实净增 **2.1 MiB** |
| 33 分钟（含人工改动） | 2.6 MiB |
| 19 小时（含大量改代码 + 手工 prune） | 净增 **88 MiB** |
| `data_added`（人工/prune 后那次） | 258 MB ← 虚高，不可推趋势 |
| `forget` 收 6 个快照后 prune | 3.6 G → 3.43 G（几乎无独有数据可回收） |
| `--keep-hourly 8` 后 prune | 3.4 G → **2.6 G**（25→10 个快照，这次释放 0.8 G） |

最后一行说明：**保留策略收紧到「比备份频率略多」时，prune 才真正开始回收**；
保留过松（如每小时备份却 keep 24）时，被删的都是仍有重叠数据的近邻快照，白跑。

## 七、报结论的措辞纪律

- 「控制住快照数量」和「控制住数据增长」是两件事，**必须分开说**；
  只做了 prune 就说「已根治增长」是错的。
- 报速率必须注明口径：仓库总大小 / 快照内容差 / `data_added`，三者不可互换。
- 引用单次 `data_added` 前，先确认那次是不是纯定时。
- 结论被后续测量推翻时，**回头改掉已经写进技能和报告里的错误根因**，
  否则下一个会话会把假设当事实执行。
