# SQLite 快照去重取证：为什么每周期新增几百 MB

实测环境：naye → vps-la，restic 0.14/0.16，rest-server 0.14.0，每 3 小时备份，
仓库 7.86 GB / 588 pack / 7 快照，采样 2026-11-18。

**结论先行**：这类链路的增长根因通常**不在**「42 个 SQLite 全量快照」这个层面，
而在**某一个库的某一类索引**上。定位到单表之前不要动手优化，否则只会把告警线往后挪。

## 一、先拿到趋势：pack 文件 mtime 聚合（最快最稳）

`restic stats --json` 的 `data_added` 实测在 7 个快照上**全部返回 `0` / `None`**
（该字段只在 `restic backup --json` 的 summary 里有值）。别指望它量趋势。

直接看后端 pack 文件的写入时间，这是 restic 内部唯一诚实的时间轴：

```bash
REPO=/var/lib/restic/repositories/<user>/<repo>

# 近 7 天每日新增
find $REPO/data -type f -newermt '-7 days' -printf '%TY-%Tm-%Td %s\n' \
  | awk '{a[$1]+=$2} END {for (d in a) printf "%s %10.1f MB\n", d, a[d]/1048576}' | sort

# 今天按小时（注意接收机时区，UTC 机要 +8 换算）
find $REPO/data -type f -newermt 'today 00:00' -printf '%TH %s\n' \
  | awk '{a[$1]+=$2} END {for (h in a) printf "%s时 %8.1f MB\n", h, a[h]/1048576}' | sort
```

本次实测输出（接收机 UTC，日界按 UTC 切）：

```
2026-11-13   65.9 MB
2026-11-14   77.3 MB
2026-11-15  258.4 MB
2026-11-16  307.0 MB
2026-11-17 2043.5 MB   ← 异常峰值
2026-11-18  793.0 MB
```

这比任何 `data_added` 推演都直接，而且**峰值日一眼可见**。有峰值就先查那天做了什么
（人工 prune / 大批改文件 / 迁移），没有峰值再往数据源里挖。

## 二、定位到单库：staging 里谁最大

备份脚本通常先把 SQLite 在线快照落到 `staging/`（`sqlite3.backup()`），
staging 会被整体纳入 restic 备份范围。直接按大小排：

```bash
sudo -n ls -lS /var/lib/<svc>/staging/ | head -14
sudo -n du -sb /var/lib/<svc>/staging/
```

配套的 `RESTORE_CATALOG.json`（多数自建链会写）里有 `source → snapshot` 映射，
能立刻把 `db-<hash>.sqlite` 换回真实路径：

```python
import json
d = json.load(open('/var/lib/<svc>/staging/RESTORE_CATALOG.json'))
for r in sorted(d['sqlite'], key=lambda x: -x['bytes'])[:8]:
    print('%10.1f MB  %s' % (r['bytes'] / 1048576, r['source']))
print('合计 %.1f MB / %d 个' % (sum(x['bytes'] for x in d['sqlite'])/1048576, len(d['sqlite'])))
```

本次结果：42 个库合计 871.9 MB，其中 `state.db` 一个就占 **407.7 MB**。

## 三、定位到单表：dbstat（决定性一步）

到这一步仍然不知道 407 MB 花在哪。SQLite 自带 `dbstat` 虚表，按表/索引拆页：

```python
import sqlite3
c = sqlite3.connect('file:/path/to/state.db?mode=ro', uri=True)
print('page_size', c.execute('PRAGMA page_size').fetchone()[0],
      'page_count', c.execute('PRAGMA page_count').fetchone()[0])
for name, mb in c.execute(
        "SELECT name, SUM(pgsize)/1048576.0 mb FROM dbstat "
        "GROUP BY name ORDER BY mb DESC LIMIT 10"):
    print('%8.1f MB  %s' % (mb, name))
```

本次实测（`state.db` 408 MB）：

| 对象 | 大小 |
|---|---|
| `messages` | 202.2 MB |
| `messages_fts_trigram_data` | 131.2 MB |
| `messages_fts_data` | 45.7 MB |
| `system_prompts` | 13.5 MB |
| 三个 `idx_messages_session*` | 9.3 MB |

再查正文实际体积做对照：

```sql
SELECT strftime('%Y-%m', timestamp, 'unixepoch') m, COUNT(*),
       SUM(LENGTH(COALESCE(content,'')) + LENGTH(COALESCE(reasoning,''))) b
FROM messages GROUP BY m ORDER BY m;
```

结果：79,918 条消息，正文合计**只有 94 MB**，而文件 408 MB。
**FTS 全文索引占了 176 MB = 43%**，索引体积是正文的 1.9 倍。

## 四、为什么 FTS 索引会废掉 restic 去重

restic 按内容块（默认 1–8 MiB 变长块）去重。`messages` 表是 append-only 的 B-tree，
新消息只加在尾部 → 旧块稳定、去重良好。

FTS5 的 `*_data` / `*_trigram_data` 是**倒排索引的段式 B-tree**，每插入一条消息
就要重写叶子页、可能触发段合并 → **每次快照有大量页内容位移**，块边界全变。
结果：407 MB 的库每 3 小时几乎全量重新上传，`prune` 也回收不掉（每份都是"新"数据）。

所以「SQLite 分块去重差」这个笼统说法要落到：**不是 SQLite 的问题，是可重建的倒排索引
在内容块层面不可去重**。

## 五、收益实测：从快照里摘掉 FTS

在**副本**上验证（绝不直接动生产库）：

```python
import sqlite3, os
before = os.path.getsize('/tmp/st-test.db')          # 先 cp 一份
c = sqlite3.connect('/tmp/st-test.db')
c.executescript("""
DROP TRIGGER IF EXISTS messages_fts_insert;
DROP TRIGGER IF EXISTS messages_fts_delete;
DROP TRIGGER IF EXISTS messages_fts_update;
DROP TRIGGER IF EXISTS messages_fts_trigram_insert;
DROP TRIGGER IF EXISTS messages_fts_trigram_delete;
DROP TRIGGER IF EXISTS messages_fts_trigram_update;
DROP TABLE IF EXISTS messages_fts;
DROP TABLE IF EXISTS messages_fts_trigram;
DROP VIEW  IF EXISTS messages_fts_trigram_src;
""")
c.commit(); c.execute("VACUUM"); c.close()
print('%.1f MB -> %.1f MB' % (before/1048576, os.path.getsize('/tmp/st-test.db')/1048576))
```

实测：**407.7 MB → 226.4 MB（省 181.3 MB，44%）**，
`messages` 79,923 行、`sessions` 590 行不变，`PRAGMA integrity_check` = `ok`。

注意：DROP 表之前必须**先 DROP 三个触发器**，否则触发器还引用已删的虚表，
后续对 `messages` 的任何写入都会报 `no such table`。

## 六、恢复后索引怎么回来：Hermes 原生延迟重建

不要自己写回填脚本。Hermes 的 `hermes_state_common.py` 有 schema v23 的
**deferred FTS rebuild** 机制，靠 `state_meta` 两个 key 驱动：

| key | 含义 |
|---|---|
| `fts_rebuild_high_water` | 触发重建那一刻的 `MAX(messages.id)` |
| `fts_rebuild_progress` | 后台分块回填已索引到的最大 id |

判据：`high_water` 存在且 `progress < high_water` ⇒ 重建未完成。
`hermes_state.py` 的 `collect_state_db_stats()` 会报 `fts_rebuild_pending`。

同族 marker 还有 `fts_storage_version`（缺失 = pre-v23 老布局）。
`hermes_cli/update_cmd.py` 与 `hermes_cli/session_recovery.py` 里也把这两个 key
列入受保护/需保留的名单——说明「索引可重建」是这套设计的一等假设。

**落地方案（待验收，不要当成已验证流程）**：在备份脚本生成 staging 快照之后、
restic 备份之前，对快照执行上述 DROP + VACUUM，并在恢复路径里写入
`fts_rebuild_high_water = MAX(messages.id)`、`fts_rebuild_progress = -1` 触发重建。
上线前必须跑一遍完整「备份 → 恢复 → 索引重建 → 搜索可用」演练。

## 七、另一条不碰索引的路：归档老会话

如果不想改备份逻辑，先把 `messages` 表本身压小。按月份统计正文体积
（本次 2026-09 13.5 MB / 2026-10 56.6 MB / 2026-11 24.1 MB），
把几个月前的会话归档出去，库和索引会同步变小。

代价是丢搜索历史，收益小于摘 FTS，但风险最低、不需要改任何代码。

## 八、报结论的措辞

- 「每 3 小时新增 463 MB」是**现象**；「FTS 倒排索引占 43% 且块级不可去重」才是**根因**。
  只报现象会被追问，只报根因不给数字会被怀疑。
- 给处置方案时必须标明哪条已验证、哪条待验收：
  「DROP FTS 副本实测省 44%」= 已验证；「恢复后自动重建」= 有代码依据但未跑过全链路演练。
- 提配额属于**争取时间**，不是解决。要同时给出「按当前速率能撑多久」的换算。
