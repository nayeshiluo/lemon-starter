---
name: restic-offsite-repo-ops
description: "restic 异地仓库：507 配额、append-only prune、保留策略。"
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux]
metadata:
  hermes:
    tags: [restic, rest-server, backup, prune, offsite, quota, retention]
    related_skills: [backup-chain-audit, hermes-backup, host-operations-evidence]
---

# restic + rest-server 异地仓库运维

## When to Use

- restic 备份报 `507 Insufficient Storage` 或 `unable to save snapshot: server response unexpected: 507`；
- 客户端 `restic forget` / `prune` 报 `append-only mode disabled` 或直接失败；
- 需要给「每小时/每 N 小时全量快照」这种链补上保留策略（此前只增不减）；
- 异地仓库体积只涨不降、配额快撞顶，需要判断 prune 到底能不能救；
- 巡检报「异地备份超过 N 分钟没有成功更新」，要先分清是链路坏了还是阈值配错了。

**不适用**：Hermes 自身的 `backup_hermes.sh` / `.hermesenc` 链 → `hermes-backup`；
Telegram 分片台账 → `backup-chain-audit` §七；SQLite 服务从零建链 → `backup-chain-audit` §九。
本技能只覆盖 restic + rest-server 这一形态。

## 一、先认清拓扑，别把三层混成一个

```
/etc/<svc>/backup.env     RESTIC_REPOSITORY=rest:http://<user>:<pw>@127.0.0.1:<port>/<repo>/
                          RESTIC_PASSWORD_FILE=...      RESTIC_CACHE_DIR=...
本机 127.0.0.1:<port>     ssh -NT -L <port>:127.0.0.1:<port> <ingest>@<vps>    ← 隧道进程
远端                      rest-server --append-only --private-repos \
                            --path <repos-root> --listen 127.0.0.1:<port> --max-size <bytes>
调度                      <svc>-backup.timer → <svc>-backup.service → backup.py
巡检                      <svc>-health.timer（高频）→ health.py，读 health.json
```

故障可能落在任意一层：隧道进程、rest-server 配额、restic 客户端、health 阈值。
**先按「哪一层返回的错误」定位**，别一上来就清磁盘——本例磁盘剩 7 G，问题在配额不在容量。

## 二、507 只有两个来源

1. rest-server 的 `--max-size` 配额检查；
2. 后端文件系统真拒绝（`df -h`、`df -i`、`df -h /tmp` 全绿就排除）。

### 2.1 `du` 的读数不能否掉配额假设

实测矛盾：`du` 算 3.28 GiB、配额 5 GiB，却稳定 507。
rest-server 内部计数口径（含索引、临时写入、并发 blob）与 `du` 不一致。

> **判据是行为，不是静态数字**：把 `--max-size` 提高后同一份数据立刻写入成功 → 闸门确实在配额上。
> 先做这一步二分，别继续推演计数公式——推不出来，而且会浪费一小时。

## 三、配额写在哪三处，改必须一起改

| 位置 | 作用 | 漏改的后果 |
|---|---|---|
| `<rest-server>.service` 的 `--max-size` | 真正的写入闸门 | 依旧 507 |
| `backup.json` 的 `offsite_capacity_bytes` | health.py 按 `*0.85` 报「超过容量 85%」 | 配额提了仍天天报超容 |
| 备份脚本/告警文案里的 GB 字面量 | 给人看的判据 | 数字与实际不符 |

```bash
cp -a /etc/systemd/system/<rest-server>.service /root/<name>.bak-maxsize-$(date +%Y%m%dT%H%M%S)
sed -i 's/--max-size <YOUR_USER_IDENTIFIER>/--max-size <YOUR_USER_IDENTIFIER>/' /etc/systemd/system/<rest-server>.service
systemctl daemon-reload && systemctl restart <rest-server>
# backup.json 用 python json 改并回读验证，不要 sed 改 JSON
```

**提多少看远端 `df` 余量**：远端只剩 7 G 时提到 7 GiB 等于把另一台机器推去爆盘。
取「够撑到下次 prune 生效」的最小值。

## 四、append-only 决定 prune 必须在服务端、且必须用属主身份

`--append-only` 是防勒索删备份的设计，客户端 forget/prune 会直接被拒。唯一路径：
登远端，**以仓库属主用户**直接操作本地目录（绕开 rest-server）。

```bash
sudo -n -u <repo-owner> restic -r <repo> --password-file <pw> forget ... --prune
```

**绝不能改成 root 跑。** rest-server 以 `User=<repo-owner>` 运行，root 建出来的
pack/index 属主是 root，服务端随后读不到自己的仓库——把一个 507 换成更糟的故障。

收尾断言（必须为空）：
```bash
sudo find <repo> -not -user <repo-owner>
```

## 五、prune 前的安全副本：硬链接，不要 `cp -a`

仓库 3.5 G、远端只剩 7.3 G 时，`cp -a` 立刻把余量吃到 3.8 G，而 `prune` 自己还要写新
pack —— 直接制造爆盘。

```bash
cp -al <repos-root>/<user>/<repo> <repos-root>/../preprune-<ts>/<repo>
```

三条要点：

- **副本放在 `--path` 的上级之外**（`--path=<repos-root>`，副本放 `<repos-root>/../preprune-*`），
  否则 rest-server 会把它当成一个新 repo 暴露出去；
- 复制后验证可读（`snapshots` 快照数须与源一致），否则副本是假的；
- **硬链接会阻止 prune 释放空间**（删旧 pack 只减 link count）。
  所以顺序必须是 prune → `check` → 删副本 → 空间才回吐。
  **不要用 prune 后的体积去评价 prune 效果。**

## 六、密码投递：stdin + trap，用完即删

远端需要密码才能以属主身份跑 restic，但长期留一份是新的泄漏面。

```bash
cat <本地pw> | ssh <vps> 'sudo -n sh -c "umask 077; cat > <远端pw>; \
  chown <owner>:<owner> <远端pw>; chmod 600 <远端pw>"'
```
密码走 stdin，不进命令行、不进 `ps`、不进 audit 的 EXECVE。
脚本里配 `trap cleanup EXIT`，**失败路径也要删**。收尾用 `test ! -e <远端pw>` 确认文件已不存在。

## 七、`--group-by` 用错，dry-run 结论完全失真

默认分组是 `host,paths`。当不同快照的 paths 有微小差异（有的含某些目录、有的不含），
restic 会拆成多组、**每组独立套用保留策略**：31 个快照的库 dry-run 只报「1 snapshot，删 1 个」。

```bash
--group-by host        # 恢复场景只关心主机
```
先 `--dry-run`，确认 **保留数 + 删除数 == 总数**，再真跑。

## 八、保留策略必须与备份频率成对设计

`keep-hourly N` 是「最近 N 小时里每小时留一个」，**不是「留 N 个快照」**。

| 备份频率 | keep-hourly | 24h 内快照数 |
|---|---|---|
| 每小时 | 24 | 24 |
| 每 3 小时 | 8 | 8 |
| 每 6 小时 | 4 | 4 |

频率改了而 keep 值不改，结果要么白留一堆、要么误删。

### 8.1 prune 可能一分钱都省不出来，这是常态

每小时增量快照之间数据高度重叠，被删快照没有独占数据 → `prune` 报
`36 files deleted` 但 `du` 一点没降。

> **必须如实说「prune 只控制了快照数量，没控制数据增长」**，
> 别把 `PRUNE_RC=0` 当成「空间问题解决了」。这是本类链路最容易自我欺骗的一步。

真正压增长只有三条：**降频**、**缩小备份范围**、**提配额**。
先找增长源（例：每轮把几十个 SQLite 全量复制进 `staging/` 再整体备份，
`data_added` 200–420 MB/次），再谈策略。

## 九、给「只增不减」的链补自动 prune 单元

原链路常常只有 backup timer，`backup.py` 里明确写着 `no production repair/prune`。
补一个每日 prune service + timer，**源主机侧驱动、远端执行**：

```ini
[Timer]
OnCalendar=*-*-* 04:40:00     # 错开到两次备份之间
Persistent=true
RandomizedDelaySec=300
```
service 用 `Type=oneshot`、`Nice=19`、`IOSchedulingClass=idle`，别给 pruner 抢 I/O。
脚本内部：投递密码 → forget+prune → `restic check` → 计数 → trap 删密码，任一失败非零退出。

## 十、改频率后必须同步的所有阈值

这是本技能最贵的一条：**改 cadence 会连带打破所有把旧 cadence 写死的阈值**，
而且是以「持续误报」的形式出现，用户会以为是链路坏了。

逐项核对：

- health 里的新鲜度阈值：75 分钟（每小时备份）→ 改 3 小时备份必须放到 210 分钟；
- `offsite_capacity_bytes` 与 `--max-size`；
- 告警文案里的数字（用户和你都会照着文案判断）；
- `Persistent=true` 的补跑行为在新周期下是否仍合理。

阈值 = 周期 + 合理缓冲，并写进注释说明依据，而不是散落的魔数。

## 十一、执行顺序（可直接照做）

```bash
# 0. 停 backup timer，避免 prune 期间写竞争
sudo systemctl stop <svc>-backup.timer

# 1. 基线：df、stats --mode raw-data、快照计数
# 2. 硬链接副本 + 副本可读验证
# 3. 密码 stdin 投递（trap 保清理）
# 4. dry-run 定策略（--group-by host！校验 keep+remove==total）
# 5. forget（秒级）；prune 远端 setsid nohup 后台跑 + 轮询日志（避免工具超时）
# 6. restic check（--read-data-subset=10% 或全量）
# 7. 删副本（空间此刻才回吐）、删远端密码、恢复 timer
# 8. 走完整链路真跑一次 backup（不是只跑 restic 命令），确认服务端仍可写
```

第 8 步不能省：prune 之后要证明 **rest-server 以属主身份仍能正常写入**，
而不是只证明本地 restic 能读。

## 验收清单

| 项 | 命令 | 通过标准 |
|---|---|---|
| 快照数符合策略 | `restic snapshots --compact \| grep -c '^[0-9a-f]\{8\}'` | 与 keep 规则推算一致 |
| 时间跨度没断 | 同上，看最早/最晚 | 覆盖面符合预期，不是只剩最近几个 |
| 完整性 | `restic check` | `no errors were found` |
| 属主没污染 | `find <repo> -not -user <owner>` | 无输出 |
| 端到端可写 | 真实跑一次 backup | `EXIT=0` + 新 snapshot id |
| 配额使用率 | health.json / `stats` | 距 85% 线有明确余量 |
| 临时凭据已清 | `test ! -e <远端pw>` | 退出码 0，文件已不存在 |
| 巡检无告警 | `health.json` 的 `issues` | `[]` |

## Pitfalls

- **只看 `du` 判定「没到配额」是错的**，见 §2.1；用「提配额后是否立刻成功」做二分。
- **`cp -a` 做预 prune 副本会把小盘机器逼爆**，用 `cp -al`。
- **硬链接副本会让 prune 看起来「没释放空间」**，先删副本再看数字。
- **root 跑 restic 会污染仓库属主**，之后 rest-server 全部 5xx。
- **stale lock 要先证进程已死**再 `restic unlock`：`ps -p <pid>` 无输出且 `pgrep -a restic` 为空。
  有活跃 restic 时 unlock 会造成真冲突。
- **prune 完成后必须重跑一次真实 backup**，否则不知道服务端还认不认这个仓库。
- **别把 `PRUNE_RC=0` 当成功结案**，要同时报「快照数、repo 体积、配额占用率」三个数。
- 本类链路的 health 巡检频率通常远高于备份频率（每分钟 vs 每 3 小时），
  **阈值必须按备份周期设，不能沿用「看起来合理」的 1 小时级数字**。

实测细节与完整命令记录见 `references/naye-protection-restic-chain.md`。
