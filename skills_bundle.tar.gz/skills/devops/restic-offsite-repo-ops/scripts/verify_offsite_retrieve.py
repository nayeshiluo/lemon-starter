#!/usr/bin/env python3
"""从异地接收端取回加密包 → 校验 sha256 → 解密 → 隔离恢复验证。

用途：证明「这份异地副本真的能恢复」，而不是只证明「字节搬对了」。
对应 SKILL.md 里 `--verify` 分支默认关闭造成的验证缺口
（见 references/offsite-receiver-migration.md §4.1）。

只读远端：不重传、不删除、不改远端任何文件。本地临时目录用完即删。

用法：
  python3 verify_offsite_retrieve.py \
      --host yecao \
      --name 20261118_133026.hermesenc \
      --sha256 e7ede30522a76daafa9157961894f80c205dc227c8f825629f11be4a6abb36d4 \
      --module /home/ubuntu/hermes-jobs/releases/offsite-20261004/offsite_backup.py

退出码：0 = PASS；非 0 = 失败（取回不一致 / 解密失败 / 恢复验证不过）。
"""
import argparse
import importlib.util
import json
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path


def load_module(path):
    """从文件路径加载 offsite_backup 模块，复用其 digest/decrypt/verify_archive。"""
    spec = importlib.util.spec_from_file_location('offsite_backup', path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--host', required=True, help='ssh 别名或 user@host')
    ap.add_argument('--name', required=True, help='远端包文件名，如 20261118_133026.hermesenc')
    ap.add_argument('--sha256', required=True, help='期望的密文 sha256（来自 job.log 的 ciphertext_sha256）')
    ap.add_argument('--module', required=True, help='offsite_backup.py 路径')
    ap.add_argument('--remote-dir', default=None,
                    help='远端目录，默认取模块的 REMOTE 常量')
    ap.add_argument('--size', type=int, default=None,
                    help='包字节数，仅用于估算超时；默认取远端实际大小')
    ap.add_argument('--keep', action='store_true', help='保留临时目录（排障用）')
    args = ap.parse_args()

    ob = load_module(args.module)
    remote_dir = args.remote_dir or ob.REMOTE

    ws = Path(tempfile.mkdtemp(prefix='offsite-verify-', dir='/home/ubuntu/hermes-jobs/tmp'
                               if Path('/home/ubuntu/hermes-jobs/tmp').is_dir() else None))
    os.chmod(ws, 0o700)
    try:
        # 远端大小 → 估算超时（老版本模块可能没有 scp_timeout）
        size = args.size
        if size is None:
            out = subprocess.run(['ssh', '-o', 'BatchMode=yes', args.host,
                                  f'stat -c %s {remote_dir}/{args.name}'],
                                 capture_output=True, text=True, timeout=60)
            if out.returncode == 0 and out.stdout.strip().isdigit():
                size = int(out.stdout.strip())
        timeout = ob.scp_timeout(size) if (size and hasattr(ob, 'scp_timeout')) else 3600

        fetched = ws / 'retrieved.hermesenc'
        print(f'[1/4] 取回 {args.name} from {args.host}:{remote_dir} '
              f'({size or "?"} B, timeout={timeout}s) ...', flush=True)
        subprocess.run(['scp', '-q', '-o', 'BatchMode=yes',
                        '-o', 'StrictHostKeyChecking=yes', '-o', 'ConnectTimeout=8',
                        f'{args.host}:{remote_dir}/{args.name}', str(fetched)],
                       timeout=timeout, check=True)

        if hasattr(ob, 'protect'):
            ob.protect(fetched)
        got = ob.digest(fetched)
        ok = got == args.sha256
        print(f'[2/4] sha256 {got}  match={ok}', flush=True)
        if not ok:
            print('FAIL: RETRIEVED_HASH_MISMATCH', flush=True)
            return 2

        restored = ws / 'restored.tar'
        print('[3/4] 解密 ...', flush=True)
        ob.decrypt(fetched, restored, (ob.KEY_DIR / 'recovery_private.pem').read_bytes())

        check = ws / 'restore-check'
        check.mkdir(mode=0o700)
        print('[4/4] 隔离恢复验证 ...', flush=True)
        result = ob.verify_archive(restored, check)
        print('RESTORE_VALIDATION', json.dumps(result, ensure_ascii=False), flush=True)

        # 判据：数据库 integrity 全 ok + 嵌套归档 gzip 全 ok
        bad = []
        for k, v in (result.get('nested_archives_verified') or {}).items():
            if v.get('gzip_integrity') not in (None, 'ok'):
                bad.append(f'{k}: gzip {v.get("gzip_integrity")}')
        if not result.get('databases_verified'):
            bad.append('databases_verified 为空')
        if bad:
            print('FAIL: ' + '; '.join(bad), flush=True)
            return 3

        print('RESULT: PASS', flush=True)
        return 0
    finally:
        if args.keep:
            print(f'[keep] 临时目录保留：{ws}', flush=True)
        else:
            shutil.rmtree(ws, ignore_errors=True)


if __name__ == '__main__':
    sys.exit(main())
