---
name: artex-console-ops
description: "Use when 部署/升级/排查 ARTEX 自主渗透测试控制台，或管理其模型池(llm_profiles)。"
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux]
metadata:
  hermes:
    tags: [artex, pentest-console, docker, llm-pool]
---

# ARTEX 控制台运维

## When to Use
用户提到 artex 控制台 / `artex.<PRIVATE_IDENTIFIER>` 打不开、升级版本、增删模型池（llm_profiles）、或 ARTEX 容器/隧道排障时。

## 部署形态（naye 机）

- 目录 `/home/ubuntu/artex/`：`docker-compose.yml`（主服务 artex + postgres）、`docker-compose.auth.yml`（authproxy）、`docker-compose.relay.yml`（cpa-relay）。
- 容器：`artex-artex-1`（镜像 `ruoji6/artex:<ver>`，监听 127.0.0.1:8787 后端 / 8788 流量代理）、`artex-postgres-1`（PG16，库名 artex 用户 artex）、`artex-authproxy`（Caddy，:8899 门禁）、`artex-cpa-relay`。
- 对外：`artex.<PRIVATE_IDENTIFIER>` 经 Cloudflare 命名隧道（`artex-tunnel.service`，token-file 在 `~/.config/lemon-cloudflare/artex-tunnel-runtime.token`）→ authproxy :8899 → 8787。
- 数据：PG 在 named volume；`data/`（jwt.key、sessions、tasks、traffic、transcripts）bind mount，升级不动。

## 排障决策树（外网打不开）

1. `curl https://artex.<PRIVATE_IDENTIFIER>/` → **403 "Forbidden"（正文 9 字节）** = authproxy 门禁 Cookie 过期，不是故障。入口带 `?k=6693dd5288cc0f572033c0675347d783` 种回 Cookie（`artex_gate`，30 天）。Cookie 是 `Secure`，被浏览器拦就换无痕。
2. DNS 应指向 CF（104.21.x/172.67.x）；tunnel 服务 active。
3. 本地 `curl http://127.0.0.1:8787/` 200 = 后端正常。API 401 `{"code":"unauthorized"}` 是 ARTEX 自身登录态（Basic Auth，`settings.auth.password_hash`），与门禁是两层。

## 升级流程（已验证 v0.3.26→v0.3.30）

1. 备份 `docker-compose.yml`，sed 换 image tag；`docker compose pull artex`。
2. `docker compose up -d artex`（注意：此命令会被 Hermes 终端误判为长驻进程，须 background=true + process wait）。
3. 验收：容器 Up、`curl 127.0.0.1:8787/` 200、`docker logs` 有 "reloaded N task(s) from PG"。外网 403 是门禁正常现象，不是失败。

## ⚠️ v0.3.30 前端路由全改名（升级后"其他界面打不开"的真因）

旧一级路径 `/settings` `/llm` `/agents` `/traffic` `/findings` `/companies` 服务端直接 404（返回 `__next_error__` HTML）。新结构：
- `/system/settings`、`/system/llm`、`/system/agents`、`/system/logs`、`/system/tools`、`/system/intercept`、`/system/notify`、`/system/skills`、`/system/mcp`
- `/function/tasks`（未变）、`/function/traffic`、`/function/findings`、`/function/workspace`（原 companies）、`/function/schedules`、`/function/commands`、`/function/repeater`、`/function/sync`、`/function/llm-records`、`/function/assets`
- 诊断法：`curl -b <cookiejar> http://127.0.0.1:8787/<path>/index.txt?_rsc=x`，返回 `1:"$Sreact.fragment"` = 路由存在；返回 `__next_error__` = 404。完整路由清单可 `strings <binary> | grep -oE 'webui/dist/[a-z0-9_/.-]+'`（先 `docker cp artex-artex-1:/app/artex /tmp/` 取二进制）。

## 模型池管理（直接 SQL，面板也可）

表 `llm_profiles`（PG `artex`）：关键字段 `name,format(openai),base_url,model,api_key,is_default,priority,pool_exclude,context_window_k`。
- 完整 26 列结构、批量 INSERT、key 回填、探针脚本、备份命令见 `references/llm-profiles-sql.md`（全部实测可用，别手写）。
- 增模型用 INSERT...SELECT 复制 id=1（默认 profile）的限流/重试/流式字段，仅覆盖 name/base_url/model/api_key/priority，避免手写 26 列。
- priority 数字大的排后面；LG 备用池放 101+ 段。
- 改完 `docker restart artex-artex-1` 让 engine 重读 DB，log 确认 "built provider for LLM profile N"。
- 探针纪律：入库前逐模型最小 chat（max_tokens≥512，防 reasoning-only 空正文误判）；`/v1/models` 空列表≠key 失效。站坑速查见 hermes-custom-providers 技能。
- **「某 provider 用不了」先查 `api_key` 是否为空字符串**（`coalesce(api_key,'')=''`），这是头号真因，不是链路坏。2026-11-17 腾白嫖 6 条全空 → 上游 401；链路（relay/隧道）当时完全正常。查法：`select id,name,base_url,model,case when coalesce(api_key,'')='' then 'EMPTY' else 'SET' end from llm_profiles order by id;`，key 从 `~/.hermes/.env` 对应 `*_API_KEY` 回填。
- **provider 是懒构建**：`built provider for LLM profile N` 只在**首次真正调用**该 profile 时出现，启动日志里只有 default 那 1-2 条是正常的。不能用启动日志条数判断 profile 是否全量加载，也不能据此报"没生效"。要证明某 profile 可用，只能在容器内直调该上游（relay 端口 + 真实 key）看 200+正文。
- 面板实际选中跑一次这步无法代做（登录态在 `settings.auth.password_hash`，不可反推）。汇报时把验收边界讲清楚：DB 行 + relay + 容器内直调已实证，面板验收留给用户。

## 外部网关接入：socat host 网络中继（腾白嫖已验证）

容器访问宿主回环服务的通用模式：`docker run -d --name <relay> --restart unless-stopped --network host --cap-drop ALL --security-opt no-new-privileges:true alpine/socat TCP-LISTEN:<port>,bind=<YOUR_SERVER_IP>,fork,reuseaddr TCP:127.0.0.1:<loopback-port>`。
- ⚠️ 必须 `--network host`；挂 artex 内部网络会 `bind: Address not available`（<YOUR_SERVER_IP> 是宿主侧网关地址）。完整 compose 模板见 `templates/socat-relay-compose.yml`。
- 腾白嫖链路：ARTEX 容器 → `<YOUR_SERVER_IP>:7864`（`artex-wb2api-relay`）→ `127.0.0.1:17863`（`magpie-tunnel.service` 的 user-systemd SSH 隧道）→ vps-la `127.0.0.1:7863`。全程不出公网明文。
- 腾白嫖模型 ID 须带 `global:` 前缀（`global:glm-5.3-flash` 等）；cn 域长期全灭。已入库 6 个（glm-5.3-flash/glm-5.3/deepseek-v4.1-flash/-sg/minimax-m3.1-flash/kimi-k3），全部容器内全链路实测。账号池/单价/风控见 `workbuddy2api-gateway-ops`。

### 本机 magpie 接入（2026-11-17 已通）

`artex-magpie-relay`（独立 compose：`docker-compose.magpie-relay.yml`，`<YOUR_SERVER_IP>:3426` → `127.0.0.1:3425`）。magpie 在 naye 本机，3425 只绑 loopback，且**不校验 api_key**（填占位 `magpie-local` 即可，但 ARTEX 侧该字段不能为空）。
- magpie 有 149 个模型，**model 名必须写全 `provider/model`**（如 `auto/glm-5.3-flash`、`lg/deepseek-v4-pro`、`group/smart-split`），只写模型名会报 `magpie knows no model "group/auto-xxx"`。
- 已入库 3 条（priority 58-60 兜底）：`group/smart-split`（自动选路总入口，922K 上下文）、`auto/glm-5.3-flash`、`lg/deepseek-v4-pro`。
- 已知上游坏的、别选：`cliproxyapi/gpt-6.1-sol`（Codex ChatGPT 账号 `model_not_found`）、`workbuddy2api/global:gpt-6-sol`（`model_unavailable`）、`auto/gpt-6.1-sol`（magpie 无此路由）。选模型前必须实测，magpie 的 `/v1/models` 列表含大量名义可用但上游挂掉的条目。

## priority 分段约定（2026-11-17 起）

fallback 顺序 = `is_default desc, priority desc`。分段：周三默认区 1-9（GLM 5.3 为备胎 priority 2）、哄哄 5-10、腾白嫖 51-56、反重力 19-26、LG 101-108（越大越靠后，纯手动储备）。

## Pitfalls（SQL 写入）

- key 含特殊字符时别在 shell 拼 `psql -c "INSERT ... '$KEY'"`（引号地狱，连续 EOF 错误）：SQL 写文件 + `docker cp` 进容器 + `psql -v wbkey=...` 变量传入，用完删容器内临时文件。容器间变量可用 `docker exec -e VAR=... sh -c 'psql ... -v wbkey=$VAR'`。
- 探腾白嫖类网关须**串行 + ≥1s 间隔**，并发会被在途租约 503 自伤（详见 workbuddy2api-gateway-ops）。

## 安全风险评估口径（用户问"这东西危险吗"）

分两层回答，别混着说：

**暴露面（低）**：容器非 privileged、无 `docker.sock`、非 host 网络、`no-new-privileges`、mem/pids 有上限；8787/8788/8899 只绑 `127.0.0.1`，主机无裸端口；门禁 Caddy 静态 Cookie + ARTEX `password_hash` 两层。

**真实风险（三处，与暴露面无关）**：
1. 门禁是静态单因子，token 明文写在 `Caddyfile` 且同一串就是 Cookie 值、30 天不过期，还会被 CF 日志和 `docker logs artex-authproxy` 记下。链接一漏 = 长期后门。建议换长随机串 + 轮换，别把 key 放 query。
2. 行为面：自主渗透 agent 出网不受限，攻击流量源 IP 是本机，被投诉/停号/当跳板是真实成本。目标授权比技术加固更重要。
3. 数据面：`data/transcripts`、`data/traffic` 含目标响应与可能凭据；`llm_profiles` 里 API key 明文存 PG。目录 700 但无加密无清理策略。

## 2026-11-17 已知线路状态

- 周三 = `token.thxnk.cc/v1`（新站，3 模型：`Deepseek v4.1 Flash`/`GLM 5.3`/`Flux`；Flux 仅 `/v1/images/generations`）。旧域 `<YOUR_PRIVATE_DOMAIN>` 已 Invalid token，任何残留引用都是坏的。
- LG = `leguanai.qutama.de/v1`，当日可用 8 模型：`deepseek-v4-1-flash(-261017)`、`deepseek-v4-flash-ga(-260731)`、`deepseek-v4-pro(-202606)`、`HY-Vision-2.0-instruct`、`hy3`；旧别名 `*-lg1/lg2`、`step-5-preview`、`minimax-m3.1-flash` 等全部 No available channel。key 在 `~/.hermes/.env` 的 `LG_API_KEY`/`IKUN_API_KEY`。
