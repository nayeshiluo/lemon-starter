# llm_profiles 实操 SQL（2026-11-17 实测可用）

## 表结构（26 列，顺序即 ordinal_position）

```
id bigint, name text, format text, base_url text, proxy text, model text,
api_key text, api_key_hint text, rate_per_second double, rate_per_minute double,
context_window_k int, reasoning_effort text, thinking_type text,
is_default bool, priority int, pool_exclude bool, streaming bool,
max_tokens int, max_tokens_field text, session_header_key text,
retry_connect_attempts int, retry_connect_interval_ms int,
retry_empty_attempts int, retry_empty_interval_ms int,
retry_stream_attempts int, retry_stream_interval_ms int,
created_at timestamptz, updated_at timestamptz
```

## 排查：某 provider 用不了

```sql
select id, name, base_url, model, priority, pool_exclude,
       case when coalesce(api_key,'')='' then 'EMPTY' else 'SET' end as key_state
  from llm_profiles order by id;
```

`EMPTY` = 头号真因（发出去是无凭据请求，上游 401），不是链路坏。回填 key 从 `~/.hermes/.env` 对应 `*_API_KEY` 取。

## 回填 key（避免 shell 引号地狱）

```bash
set -a; . /home/ubuntu/.hermes/.env; set +a
docker exec -i artex-postgres-1 psql -U artex -d artex -v wbkey="$WORKBUDDY_API_KEY" <<'SQL'
UPDATE llm_profiles SET api_key = :'wbkey', updated_at = now()
 WHERE base_url LIKE '%7864%' AND coalesce(api_key,'') = '';
SQL
```

`:'wbkey'` 由 psql 自己加引号转义，key 里有特殊字符也安全。

## 批量插模型（复制 id=1 的限流/重试字段）

```sql
INSERT INTO llm_profiles (name,format,base_url,model,api_key,is_default,priority,pool_exclude,
  rate_per_second,rate_per_minute,context_window_k,reasoning_effort,thinking_type,streaming,
  max_tokens,max_tokens_field,session_header_key,
  retry_connect_attempts,retry_connect_interval_ms,retry_empty_attempts,retry_empty_interval_ms,
  retry_stream_attempts,retry_stream_interval_ms,created_at,updated_at)
SELECT v.nm,'openai','http://<YOUR_SERVER_IP>:3426/v1',v.md,'magpie-local',false,v.pr,false,
  p.rate_per_second,p.rate_per_minute,v.cw,p.reasoning_effort,p.thinking_type,p.streaming,
  p.max_tokens,p.max_tokens_field,p.session_header_key,
  p.retry_connect_attempts,p.retry_connect_interval_ms,p.retry_empty_attempts,p.retry_empty_interval_ms,
  p.retry_stream_attempts,p.retry_stream_interval_ms,now(),now()
FROM llm_profiles p,
 (VALUES ('magpie/smart-split','group/smart-split',58,922),
         ('magpie/glm-5.3-flash','auto/glm-5.3-flash',59,128),
         ('magpie/lg-deepseek-v4-pro','lg/deepseek-v4-pro',60,256)) AS v(nm,md,pr,cw)
WHERE p.id = 1;
```

用 VALUES 列表一次插多条，字段只覆盖 name/model/priority/context_window_k，其余从 id=1 继承。

## 入库前探针（容器内直调上游，绕开 ARTEX engine）

```bash
for m in "group/smart-split" "auto/glm-5.3-flash" "lg/deepseek-v4-pro"; do
  docker exec artex-artex-1 sh -c "curl -s -m 90 http://<YOUR_SERVER_IP>:3426/v1/chat/completions \
    -H 'Content-Type: application/json' -H 'Authorization: Bearer magpie-local' \
    -d '{\"model\":\"$m\",\"messages\":[{\"role\":\"user\",\"content\":\"say OK\"}],\"max_tokens\":512}'"
done
```

`max_tokens≥512`：reasoning 模型会把预算烧在 reasoning_tokens 上，给太少会得到 `content: null` 的假阴性。

⚠️ 上面的单行写法在从宿主 shell 套 `docker exec sh -c "..."` 时会因多层引号转义坏成 `invalid character '\\'` 假报错（2026-11-18 实测踩坑）。多模型循环探针一律改为：脚本落宿主文件 → `docker cp` 进容器 → `docker exec sh /tmp/probe.sh` → 用完删除。

## 重启与验收

```bash
docker restart artex-artex-1     # 用 background=true，前台会被判长驻进程
curl -s -o /dev/null -w '%{http_code}\n' http://127.0.0.1:8787/   # 期望 200
docker logs artex-artex-1 2>&1 | grep 'built provider'
```

**懒构建**：`built provider for LLM profile N` 只在首次真正调用该 profile 时出现。启动后只看到 1-2 条是正常的，不代表其余没加载。不要用日志条数判断 profile 是否生效。

## 上游换模型：旧 profile 置 exclude 而不是删（2026-11-19 实测）

订阅源会静默换模型表（LG 旧 7 个一夜全 `model_not_found`）。同步流程：
1. 先拿 provider 真实 key 打上游 `/v1/models` + 逐个 chat 探活，确认新表（`max_tokens≥512`）。
2. 旧 profile **`UPDATE ... SET pool_exclude=true`，不 DELETE**——保留排障与归因痕迹
   （`No available channel for model X` 归因依赖 id→base_url 映射）。
3. 新表按现有规则插：同一网关的中继段接着排（如 magpie 41-69 后），整段备用池排 101+ 段。
4. 备份 → INSERT → `docker restart`（background=true）→ 容器内端到端探针逐个 200 才算完。

示例（LG 2026-11-19 新表：agnes-3.0-flash / GLM-5.3-Flash / hy4-flash / GLM-5.3-Trial / gemma-4，
priority 101-105，旧 `lg/*` 一条 exclude）——VALUES 列表写法同上节，name 用
`magpie/lg-<简称>`、model 用网关全前缀 `lg/<模型id>`。

## 备份（改前必做）

```bash
cd /home/ubuntu/artex
docker exec artex-postgres-1 pg_dump -U artex -d artex -t llm_profiles --data-only \
  > data/llm_profiles-backup-$(date +%Y%m%d-%H%M).sql
```
