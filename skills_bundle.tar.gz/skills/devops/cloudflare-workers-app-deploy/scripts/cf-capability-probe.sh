#!/usr/bin/env bash
# 只读探测：某个 Cloudflare API token 能碰哪些资源族。
# 用法: ./cf-capability-probe.sh /path/to/token [zone_id]
# 不创建、不修改任何资源；只用 GET 列表/详情接口。
set -uo pipefail

TOK_FILE="${1:?usage: cf-capability-probe.sh <token_file> [zone_id]}"
ZONE="${2:-}"
[ -r "$TOK_FILE" ] || { echo "token file unreadable: $TOK_FILE"; exit 1; }

api() {  # api <path>  -> prints "HTTP <code> <first 120 chars of body>"
  local body code
  body=$(curl -s -w '\n%{http_code}' -H "Authorization: Bearer $(cat "$TOK_FILE")" \
    "https://api.cloudflare.com/client/v4/$1")
  code=$(printf '%s' "$body" | tail -n1)
  printf 'HTTP %s  %s\n' "$code" "$(printf '%s' "$body" | sed '$d' | tr -d '\n' | cut -c1-120)"
}

echo "== token file: $TOK_FILE"
echo "-- identity"
api "user/tokens/verify"

echo "-- account discovery (empty array is normal for zone-scoped tokens)"
api "accounts"

if [ -n "$ZONE" ]; then
  echo "-- zone $ZONE"
  api "zones/$ZONE"
  ACC=$(curl -s -H "Authorization: Bearer $(cat "$TOK_FILE")" \
    "https://api.cloudflare.com/client/v4/zones/$ZONE" \
    | python3 -c 'import json,sys
try: print(json.load(sys.stdin)["result"]["account"]["id"])
except Exception: print("")')
  echo "   account_id = ${ACC:-<not readable>}"

  echo "-- zone-scoped capabilities"
  api "zones/$ZONE/dns_records?per_page=1"
  api "zones/$ZONE/settings"
  api "zones/$ZONE/email/routing"
  api "zones/$ZONE/email/routing/rules"
  api "zones/$ZONE/workers/routes"
  api "zones/$ZONE/rulesets"
else
  ACC=""
fi

if [ -n "${ACC:-}" ]; then
  echo "-- account-scoped capabilities"
  api "accounts/$ACC/workers/scripts"
  api "accounts/$ACC/workers/subdomain"
  api "accounts/$ACC/d1/database"
  api "accounts/$ACC/storage/kv/namespaces"
  api "accounts/$ACC/r2/buckets"
  api "accounts/$ACC/cfd_tunnel?is_deleted=false"
  api "accounts/$ACC/tokens"
else
  echo "-- account-scoped capabilities SKIPPED (no account_id)"
fi

cat <<'EOF'

读取方式:
  200 + "success":true   → 该资源族可读写（写权限仍需实测试一次性资源后即删）
  403 / "Authentication error" / code 9109 → 无此权限族
  code 9109 出现在 accounts/<id>/tokens → 无权建新 token，只能向用户索取
注意:
  - user/tokens/verify 返回 active 不代表具备任何资源权限
  - accounts 返回空数组对 zone 级 token 是正常现象，通过 zone 的 account.id 取 account
EOF
