---
name: cloudflare-workers-app-deploy
description: 部署 Cloudflare Workers 全栈应用(D1/KV/R2)：先探 token 权限。
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [devops, cloudflare, workers, d1, r2, email]
    related_skills: [cloudflare-tunnel-ops, subboost-deploy-ops, oss-project-evaluation, worker-observability]
---

# Cloudflare Workers 自建应用部署

适用于「一个 Worker 包打天下」类项目：后端 Workers、数据库 D1、缓存 KV、对象存储 R2、前端打包进 assets。代表项目 `maillab/cloud-mail`（Web 邮箱）。

与 `cloudflare-tunnel-ops`（隧道发布 + 藏源站 IP）不同：这类应用**没有源站**，不需要隧道，域名直接走 Worker 自定义域（custom domain）。

## When to Use

- 部署/升级 Cloudflare Workers 全栈应用（cloud-mail、各类 Workers + D1 面板）
- 需要判断「这个 CF 项目我能不能用、要不要花钱」
- wrangler 报 `Authentication error` / `Failed to automatically retrieve account IDs`
- 要开 CF Email Routing / Email Sending（收发信配额、是否必须 Workers Paid）

## 铁律：先探权，再承诺

**不要先克隆、先 build、先跟用户说"一小时内上线"。** CF 侧资源创建（D1/KV/R2/Email Routing/Workers）是独立权限族，本机存的 token 往往只有 DNS；一旦权限不够，前面所有准备都白做，还要回头找用户补 token。

先跑 `scripts/cf-capability-probe.sh`（见下），拿到「哪个 token 能干什么」的矩阵，再决定路线。探测用 GET 列表接口即可，不产生副作用。

### 已知权限分层（本机实测）

| token 文件 | 实际能做的 | 不能做 |
|---|---|---|
| `~/.config/lemon-cloudflare/ops.token` | 5 个 zone 全量 DNS 读写、Zone Settings、Cache Purge | D1 / KV / R2 / Email Routing / Workers / account 级 API / 建新 token（`9109`） |
| `~/.config/lemon-cloudflare/tunnel-admin.token` | Tunnel 增删改、Workers 列表读、DNS Write、Access Apps | D1 / KV / R2 / Email Routing / subdomain / 建新 token |

两者 `user/tokens/verify` 都 `active`——**active ≠ 权限够**。别拿 verify 通过当成能部署。

account id 别去 `/accounts`（用 zone 级 token 查会返回空数组，看起来像没账号）：从任一 zone 的 `result.account.id` 取。本机 `<PRIVATE_IDENTIFIER>` → `471eb899…`（见 `credential-inventory.json`）。

**权限不足时的正确交付**：给用户一份精确的自定义 token 权限清单（见下），让他建好直接发过来；同时把已完成且可保留的工作（克隆、构建、DNS 快照、冲突核查）如实列出，别假装部署进行中。

需要的自定义 token 权限（Cloudflare Workers 应用最小集）：

- Account：`Workers Scripts:Edit`、`Workers KV Storage:Edit`、`D1:Edit`、`Workers R2 Storage:Edit`、`Account Settings:Read`
- Zone（目标域）：`DNS:Edit`、`Zone:Read`、`Workers Routes:Edit`
- 收发信另加：`Email Routing Rules:Edit`
- 资源限定到具体 account，别给「所有账户」

token 落 `~/.config/lemon-cloudflare/<app>.token`，`chmod 600`，**不写 Git、不打印、不落日志**；用 `$(cat …)` 传给 wrangler，绝不 `export` 到会话可见处。

## 部署流程

### 1. 只读前置核查

```bash
node -v; pnpm -v
curl -s -H "Authorization: Bearer $TOK" \
  "https://api.cloudflare.com/client/v4/zones/$ZONE/dns_records?per_page=200"
curl -s -H "Authorization: Bearer $TOK" "https://api.cloudflare.com/client/v4/zones/$ZONE/email/routing"
```

**动手前把 DNS 全量快照存盘**并报记录数/类型分布，便于回滚：
`~/.config/lemon-cloudflare/dns-snapshot-<zone>-<YYYYmmdd-HHMMSS>.json`

### 2. 克隆 + 构建前端（产物目录要对）

```bash
git clone --depth 1 <repo> ~/apps/<app>
cd ~/apps/<app>/mail-vue && pnpm install && pnpm run build
```
产物目录由项目 `.env.release` 的 `VITE_OUT_DIR` 决定（cloud-mail = `../mail-worker/dist`）。**必须先 build 前端再 deploy**，否则 wrangler 上传的 assets 是空目录，页面 500 而 Worker 日志无异常——最容易误判成「后端挂了」。

构建 ~20s（install 25s + build 12s），走后台 + notify，别前台等。

### 3. 建资源 + 写 wrangler.toml

项目通常提供 `wrangler-action.toml`（CI 用，带 `${NAME}` 等占位）和 `wrangler.toml`（本地用，binding 全注释）。复制 action 版并按实际填充：`d1_databases(database_name/database_id)`、`kv_namespaces(id)`、`r2_buckets(bucket_name)`、`[ai] binding`、`[assets] directory`、`[[send_email]]`、`[triggers] crons`、`[vars]`。

`binding` 名（`db` / `kv` / `r2` / `assets` / `email` / `ai`）**不可改**，代码里硬编码。

### 4. 部署与绑定域名

```bash
cd <worker-dir> && CLOUDFLARE_API_TOKEN=$(cat ~/.config/lemon-cloudflare/<app>.token) \
  CLOUDFLARE_ACCOUNT_ID=<acc> npx --yes wrangler@4 deploy
```
自定义域用 `[[routes]] pattern = "mail.example.com" + custom_domain = true`，由 wrangler 自动建 DNS + 证书。**不要**再手建 CNAME，会和 custom domain 冲突。

### 5. 初始化数据库（一次性）

这类项目有 `/init/:secret` 端点，secret 与 `vars.jwt_secret` 比对，跑完一串 `vX_YDB()` 迁移再 `settingService.refresh`。访问 `https://<domain>/api/init/<jwt_secret>` → 返回 `success`。迁移用 `ALTER TABLE` 包 try/catch，重复跑安全（输出 `跳过字段：…` 属正常）。

### 6. 验收

- 首页 200 且 HTML 含前端资源 hash（证明 assets 打包正确）
- 登录页能拉到配置接口
- 收信：外部真实发一封 → 库里出现记录 → 后台可见
- 发信：真发到外部邮箱并确认收件箱（若仅收不发，用「转发到已验证地址」验证）
- cron 触发器生效（cloud-mail 每小时 `resetDaySendCount`）

## 收发信成本：上线前必须跟用户讲清

**Cloudflare Email Service**（2026-06 价格页核实）：

- **收信 / Email Routing**：Free + Paid 全支持，**入站不限量**
- **发信到任意收件人**：**必须 Workers Paid**（$5/月）；含 3,000 封/月，超出 $0.35/千封；发信仍标 **Beta**
- 只发到账号内「已验证目标地址」：全套餐免费，不计配额
- Free 套餐跑复杂收信 handler 可能 `EXCEEDED_CPU`；Worker 用 `send_email` 发出的邮件在 Email Routing 统计里显示为 **dropped**（其实已投递，看 Email Sending 指标才准）

结论话术：**收信免费随便建；要真往外发信就得掏 $5 Workers Paid，或接 Resend 走另一条腿。**

细节配额（单封 50 收件人 / 25MiB / subject 998 字符、域维度规则上限、suppression list）见 `references/cloudflare-email-service-limits.md`。

## 域名规划（先让用户拍板，别自己定）

- 收信域名 = 邮箱后缀。用 apex（`example.com` → `dad@example.com`）地址最短，但把整个 apex 的 MX 交出去；用子域（`mail.example.com`）隔离干净但地址变长。
- **Web 面板域名和收信域名可以不同**：面板走 `mail.example.com`（custom domain），收信走 apex MX。
- 动手前必须确认 apex 无既有 MX/TXT。已有邮件服务时改用子域，别抢占。
- `/email/routing` 显示 `enabled:false, status:unconfigured` 不代表配置过；`/email/routing/dns` 返回的是「应该配成什么」的建议记录，**不是现有记录**——别把建议当现状。

## 坑

1. **`active` token ≠ 有权限**。先 GET 各资源族列表接口，矩阵清楚再动手。
2. **`/accounts` 返回空数组**用 zone token 是正常的，不是没账号；从 zone 的 `account.id` 取。
3. **wrangler whoami 报 `Failed to automatically retrieve account IDs`**：token 缺 account 读权限。设 `CLOUDFLARE_ACCOUNT_ID` 可绕过检查，但真部署仍会失败——别把「绕过 whoami」当解决。
4. **前端没 build 就 deploy**：assets 空，页面白屏/500，Worker 日志干净，极易误判。
5. **`binding` 名改了就崩**，代码里是硬编码常量。
6. **`/init` 的 secret 必须等于 `vars.jwt_secret`**，不一致返回 `❌ JWT secret mismatch`；它同时是 JWT 签名密钥，别用弱值、别外泄。
7. **DNS 快照要在任何写入前做**，且只写自己新增的记录（无脑清 A/CNAME 是灾难；本机该 zone 挂着 tunnel、面板、反代共 18 条）。
8. **无头机上没有浏览器登录态**：CF OAuth（`wrangler login`）走不通，只能靠 API token。别试着开浏览器兜底，直接要 token。
9. Beta 产品（Email Sending）行为会变，配额与「是否仍需 Paid」每次上线前重看 `developers.cloudflare.com/email-service/platform/pricing/`。

## 支持文件

- `scripts/cf-capability-probe.sh` —— 只读探测某 token 能碰哪些 CF 资源族，输出权限矩阵
- `references/cloudflare-email-service-limits.md` —— Email Service 配额/价格官方原文摘录（2026-06/10 版）
- `references/cloud-mail-deploy.md` —— cloud-mail 项目结构、wrangler 关键项、初始化与实测状态
