---
name: cloudflare-workers-app-deploy
description: 部署 Cloudflare Workers 全栈应用(D1/KV/R2)：先探 token 权限。
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [devops, cloudflare, workers, d1, r2, email]
    related_skills: [cloudflare-tunnel-ops, subboost-deploy-ops, oss-project-evaluation, worker-observability]
---

# Cloudflare Workers 自建应用部署

适用于「一个 Worker 包打天下」类项目：后端 Workers、数据库 D1、缓存 KV、对象存储 R2、前端打包进 assets。代表项目 `maillab/cloud-mail`（Web 邮箱）。

与 `cloudflare-tunnel-ops`（隧道发布 + 藏源站 IP）不同：这类应用**没有源站**，不需要隧道，域名直接走 Worker 自定义域（custom domain）。

## When to Use

- 部署/升级 Cloudflare Workers 全栈应用（cloud-mail、各类 Workers + D1 面板）
- 需要判断「这个 CF 项目我能不能用、要不要花钱」
- wrangler 报 `Authentication error` / `Failed to automatically retrieve account IDs`
- 要开 CF Email Routing / Email Sending（收发信配额、是否必须 Workers Paid）

## 铁律：先探权，再承诺

**不要先克隆、先 build、先跟用户说"一小时内上线"。** CF 侧资源创建（D1/KV/R2/Email Routing/Workers）是独立权限族，本机存的 token 往往只有 DNS；一旦权限不够，前面所有准备都白做，还要回头找用户补 token。

先跑 `scripts/cf-capability-probe.sh`（见下），拿到「哪个 token 能干什么」的矩阵，再决定路线。探测用 GET 列表接口即可，不产生副作用。

### 已知权限分层（本机实测）

| token 文件 | 实际能做的 | 不能做 |
|---|---|---|
| `~/.config/lemon-cloudflare/ops.token` | 5 个 zone 全量 DNS 读写、Zone Settings、Cache Purge、**Email Routing 启用/设置读写**（实测 `POST /email/routing/enable` 成功） | D1 / KV / R2 / Workers 脚本 / Email Routing 规则写入 / account 级 API / 建新 token（`9109`） |
| `~/.config/lemon-cloudflare/tunnel-admin.token` | Tunnel 增删改、Workers 列表读、DNS Write、Access Apps | D1 / KV / R2 / Email Routing / subdomain / 建新 token |

两者 `user/tokens/verify` 都 `active`——**active ≠ 权限够**。别拿 verify 通过当成能部署。

account id 别去 `/accounts`（用 zone 级 token 查会返回空数组，看起来像没账号）：从任一 zone 的 `result.account.id` 取。本机 `<PRIVATE_IDENTIFIER>` → `471eb899…`（见 `credential-inventory.json`）。

**权限不足时的正确交付**：给用户一份精确的自定义 token 权限清单（见下），让他建好直接发过来；同时把已完成且可保留的工作（克隆、构建、DNS 快照、冲突核查）如实列出，别假装部署进行中。

需要的自定义 token 权限（Cloudflare Workers 应用最小集）：

- Account：`Workers Scripts:Edit`、`Workers KV Storage:Edit`、`D1:Edit`、`Workers R2 Storage:Edit`、`Account Settings:Read`
- Zone（目标域）：`DNS:Edit`、`Zone:Read`、`Workers Routes:Edit`
- 收发信另加：`Email Routing Rules:Edit`
- 资源限定到具体 account，别给「所有账户」

token 落 `~/.config/lemon-cloudflare/<app>.token`，`chmod 600`，**不写 Git、不打印、不落日志**；用 `$(cat …)` 传给 wrangler，绝不 `export` 到会话可见处。

### 凭据交接：别让用户贴进对话

用户（至少本机主人）明确拒绝把 API key 粘进聊天——**对话内容会进 session DB**。正确姿势是让他写本地文件，我读文件：

```bash
mkdir -p ~/.config/lemon-cloudflare && chmod 700 ~/.config/lemon-cloudflare
read -rsp "CF邮箱: " E && echo && read -rsp "Key: " K && echo && \
  printf 'email=%s\nkey=%s\n' "$E" "$K" > ~/.config/lemon-cloudflare/cm-bootstrap.key && \
  chmod 600 ~/.config/lemon-cloudflare/cm-bootstrap.key && echo 写入完成
```

`read -s` 不回显、值不进 shell 历史；手机 SSH 客户端不便粘长命令时，退化为 `nano` 手写两行 + `chmod 600`。

**手机端最省事的形态是一条可整段粘贴的命令**（用户问「我该怎么把密钥给你」时直接给这条，别让他读步骤）：

```bash
umask 077; printf '%s' '粘贴KEY' > ~/.config/lemon-cloudflare/<app>.key; chmod 600 ~/.config/lemon-cloudflare/<app>.key; wc -c ~/.config/lemon-cloudflare/<app>.key
```

`wc -c` 返回的字节数就是回执（Resend `re_` key 约 36 字节），让用户只回「写好了」+ 字节数，永远不用把密钥内容告诉我。**用户说「好了」但文件不在 `~/` 时，先查 `/root/`**（他常用 root 登录）：`sudo -n ls -la /root/.config/lemon-cloudflare/`。

拿到高权限凭据（Global API Key / 全权限 token）后的收敛流程：**只用它建一个最小权限 token → 立刻删掉 bootstrap 凭据文件 → 后续全用受限 token → 收尾再删受限 token**。Global API Key **不能单独吊销，只能 Roll，Roll 会打断其他还在用旧 key 的服务**——所以别让用户事后去 Roll，靠压缩暴露窗口控制风险。

### 给用户建 token：别逐屏指路

用户说「好麻烦」就是信号：立刻从「教他点面板」切换到「给我凭据我来操作」，别继续一屏一屏贴截图步骤。若必须指导，先问「手机还是电脑」，并优先给**分类名 + 权限组名**（见 `references/cf-token-creation-ui.md`），别描述像素位置。手机端最多给 3 步一轮，等他回一张截图再继续——一次性灌 9 条权限清单他必然勾错（实测：勾了 `DNS 设置` 而非 `DNS`、勾了 `注册机构:域`、漏了 `Email Routing Rules`）。

### 更快：拿到高权限凭据后用 API 建受限 token（免面板勾选）

用户嫌面板麻烦、直接把 Global API Key 写进本地文件时，**不要再让他去勾 9 条权限**——用 API 一步建好受限 token：

`POST /accounts/{acc}/tokens`，body 是 `{"name":…, "policies":[{effect:allow, resources:{…}, permission_groups:[{id}]}]}`。
resources 键格式：account 级 `com.cloudflare.api.account.<acc_id>`，zone 级 `com.cloudflare.api.account.zone.<zone_id>`，值 `"*"`。
permission group id 用 Global API Key 拉 `/user/tokens/permission_groups?per_page=200` 现查（421 组，按 `name` + `scopes` 过滤），别背 ID。

实测可用的最小集（2026-11，含 ID）与完整 curl 流程见 `references/cf-token-api-bootstrap.md`。建完立刻删 bootstrap 凭据文件，后续只用新 token。

## 部署流程

### 1. 只读前置核查

```bash
node -v; pnpm -v
curl -s -H "Authorization: Bearer $TOK" \
  "https://api.cloudflare.com/client/v4/zones/$ZONE/dns_records?per_page=200"
curl -s -H "Authorization: Bearer $TOK" "https://api.cloudflare.com/client/v4/zones/$ZONE/email/routing"
```

**动手前把 DNS 全量快照存盘**并报记录数/类型分布，便于回滚：
`~/.config/lemon-cloudflare/dns-snapshot-<zone>-<YYYYmmdd-HHMMSS>.json`

### 2. 克隆 + 构建前端（产物目录要对）

```bash
git clone --depth 1 <repo> ~/apps/<app>
cd ~/apps/<app>/mail-vue && pnpm install && pnpm run build
```
产物目录由项目 `.env.release` 的 `VITE_OUT_DIR` 决定（cloud-mail = `../mail-worker/dist`）。**必须先 build 前端再 deploy**，否则 wrangler 上传的 assets 是空目录，页面 500 而 Worker 日志无异常——最容易误判成「后端挂了」。

构建 ~20s（install 25s + build 12s），走后台 + notify，别前台等。

### 3. 建资源 + 写 wrangler.toml

项目通常提供 `wrangler-action.toml`（CI 用，带 `${NAME}` 等占位）和 `wrangler.toml`（本地用，binding 全注释）。复制 action 版并按实际填充：`d1_databases(database_name/database_id)`、`kv_namespaces(id)`、`r2_buckets(bucket_name)`、`[ai] binding`、`[assets] directory`、`[[send_email]]`、`[triggers] crons`、`[vars]`。

`binding` 名（`db` / `kv` / `r2` / `assets` / `email` / `ai`）**不可改**，代码里硬编码。

### 4. 部署与绑定域名

```bash
cd <worker-dir> && CLOUDFLARE_API_TOKEN=$(cat ~/.config/lemon-cloudflare/<app>.token) \
  CLOUDFLARE_ACCOUNT_ID=<acc> npx --yes wrangler@4 deploy
```
自定义域用 `[[routes]] pattern = "mail.example.com" + custom_domain = true`，由 wrangler 自动建 DNS + 证书。**不要**再手建 CNAME，会和 custom domain 冲突。

### 5. 初始化数据库（一次性）

这类项目有 `/init/:secret` 端点，secret 与 `vars.jwt_secret` 比对，跑完一串 `vX_YDB()` 迁移再 `settingService.refresh`。访问 `https://<domain>/api/init/<jwt_secret>` → 返回 `success`。迁移用 `ALTER TABLE` 包 try/catch，重复跑安全（输出 `跳过字段：…` 属正常）。

### 6. 验收

- 首页 200 且 HTML 含前端资源 hash（证明 assets 打包正确）
- 登录页能拉到配置接口
- 收信：外部真实发一封 → 库里出现记录 → 后台可见。**本机 SMTP 直投必被拒（544 5.7.1），必须用户真实邮箱发**，见坑 15b
- 发信：真发到外部邮箱并确认收件箱（若仅收不发，用「转发到已验证地址」验证）
- cron 触发器生效（cloud-mail 每小时 `resetDaySendCount`）

## 收发信成本：上线前必须跟用户讲清

**Cloudflare Email Service**（2026-06 价格页核实）：

- **收信 / Email Routing**：Free + Paid 全支持，**入站不限量**
- **发信到任意收件人**：**必须 Workers Paid**（$5/月）；含 3,000 封/月，超出 $0.35/千封；发信仍标 **Beta**
- 只发到账号内「已验证目标地址」：全套餐免费，不计配额
- Free 套餐跑复杂收信 handler 可能 `EXCEEDED_CPU`；Worker 用 `send_email` 发出的邮件在 Email Routing 统计里显示为 **dropped**（其实已投递，看 Email Sending 指标才准）

结论话术：**收信免费随便建；要真往外发信就得掏 $5 Workers Paid，或接 Resend 走另一条腿。**

细节配额（单封 50 收件人 / 25MiB / subject 998 字符、域维度规则上限、suppression list）见 `references/cloudflare-email-service-limits.md`。

## 域名规划（先让用户拍板，别自己定）

- 收信域名 = 邮箱后缀。用 apex（`example.com` → `dad@example.com`）地址最短，但把整个 apex 的 MX 交出去；用子域（`mail.example.com`）隔离干净但地址变长。
- **Web 面板域名和收信域名可以不同**：面板走 `mail.example.com`（custom domain），收信走 apex MX。
- 动手前必须确认 apex 无既有 MX/TXT。已有邮件服务时改用子域，别抢占。
- `/email/routing` 显示 `enabled:false, status:unconfigured` 不代表配置过；`/email/routing/dns` 返回的是「应该配成什么」的建议记录，**不是现有记录**——别把建议当现状。

## 上线后必须立刻做的安全收尾

跑通 ≠ 可交付。这类自建邮箱/面板类项目**默认对全世界开放**，验收后第一件事是收紧：

- **cloud-mail 的 `setting` 表布尔语义是反的**：`register=0` 是**开放注册**，`register=1` 才是关闭（见 `entity-const.js` 的 `settingConst.register {OPEN:0, CLOSE:1}`）。`send`/`receive`/`add_email`/`many_email`/`forward_status` 同理，全是 0=开。默认 `register=0`，意味着任何人打开站点就能注册 `@你的域` 邮箱当一次性收码邮箱。
- 改完 setting 表**必须再跑一次 `/api/init/<jwt_secret>`**（内部 `settingService.refresh` 刷缓存），否则改了库不生效。
- 收尾话术里主动说明「注册已关，要加账号走后台用户管理或邀请码」，别等用户自己发现。

## 交付时要主动给使用说明

用户在这种项目上线后一定会问「这个项目我如何使用」。**部署完成的那条汇报里就把使用说明带上**（菜单结构、账号=邮箱地址的模型、系统设置里该先配哪几项、已知缺口），别等他追问。cloud-mail 的菜单映射与设置项优先级见 `references/cloud-mail-deploy.md`。

## 坑

1. **`active` token ≠ 有权限**。先 GET 各资源族列表接口，矩阵清楚再动手。
2. **`/accounts` 返回空数组**用 zone token 是正常的，不是没账号；从 zone 的 `account.id` 取。
3. **wrangler whoami 报 `Failed to automatically retrieve account IDs`**：token 缺 account 读权限。设 `CLOUDFLARE_ACCOUNT_ID` 可绕过检查，但真部署仍会失败——别把「绕过 whoami」当解决。
4. **前端没 build 就 deploy**：assets 空，页面白屏/500，Worker 日志干净，极易误判。
5. **`binding` 名改了就崩**，代码里是硬编码常量。
6. **`/init` 的 secret 必须等于 `vars.jwt_secret`**，不一致返回 `❌ JWT secret mismatch`；它同时是 JWT 签名密钥，别用弱值、别外泄。
7. **DNS 快照要在任何写入前做**，且只写自己新增的记录（无脑清 A/CNAME 是灾难；本机该 zone 挂着 tunnel、面板、反代共 18 条）。
8. **无头机上没有浏览器登录态**：CF OAuth（`wrangler login`）走不通，只能靠 API token。别试着开浏览器兜底，直接要 token。
9. Beta 产品（Email Sending）行为会变，配额与「是否仍需 Paid」每次上线前重看 `developers.cloudflare.com/email-service/platform/pricing/`。
10. **新版面板建 token 极易勾错**：`DNS 设置` 不是 `DNS`，`Email Routing Rules` 在「电子邮件和消息」分类。勾完核对 9 条摘要再提交，别让用户凭印象点。详见 `references/cf-token-creation-ui.md`。
11. **别把高权限凭据要进对话**：用户会拒绝，且对话进 session DB。走 `read -s` 写 600 文件 → 我读文件。
12. **用户说「好了」但文件不存在 → 先查 root 家目录**。用户在 SSH 里常用 root，文件落在 `/root/.config/…`；`sudo -n ls` 一次就能确认，别急着让他重写。
13. **worker 目录依赖要单独装**：只在前端目录 `pnpm install` 不够，`mail-worker` 自己也有 `package.json`。否则 wrangler 打包报一串 `Could not resolve "dayjs/plugin/timezone"` / `linkedom` / `ua-parser-js`，看着像源码坏了，其实是没装依赖。
14. **account-scoped token 调 `user/tokens/verify` 可能返回 `1000 Invalid API Token`，但 token 是好的**——同一 token 打 D1/KV/Workers 全 200。判定有效性要用真实资源族接口，别信 verify。
15. **启用 Email Routing 的权限族是独立的，但别急着推给用户**：`/zones/{z}/email/routing` 的 GET/PATCH 与 `/email/routing/enable` 对「只有 `Email Routing Rules:Edit`」的新建 token 全 401，**但本机 `ops.token`（只有 DNS Write + Zone Settings Write）实测 `POST /email/routing/enable` 成功**，且启用后 CF 自动写入 3 条 MX + SPF + DKIM。教训：**权限矩阵要逐个本地 token 试，别按权限名推断**；先在面板找按钮找半天、再让用户点，是白绕一圈。启用后 catch-all 改投 worker 用受限 token 即可：

    ```
    PUT /zones/{z}/email/routing/rules/catch_all
    {"matchers":[{"type":"all"}],"actions":[{"type":"worker","value":["<script-name>"]}],"enabled":true,"name":""}
    ```

    默认 catch-all 是 `actions:[{type:"drop"}], enabled:false`——不改它，邮件进来了也会被丢掉。

15b. **收信验收不能用本机 SMTP 直投**：`nc`/smtplib 连 `route1.mx.cloudflare.net:25` 端口是通的（本机与 vps-la 都 OPEN），但投递会被 CF 边缘拒收：`544 5.7.1 Email was rejected because it was likely unsolicited email`。原因是发件域无 SPF/PTR，属匿名投递。**必须让用户用真实邮箱（Gmail/QQ）发一封**，别浪费时间在自建 SMTP 上，也不要为了验收去配发件域 SPF。可先 `wrangler tail cloud-mail` 挂着，用户发完直接看 `email` 事件与 D1 `email` 表。

    **更好的替代（已实测）**：配好 Resend 之后可以自己闭环，不必等用户——用 `POST https://api.resend.com/emails` 从「外部」把信发到自己的 `admin@<domain>`，走 CF MX 进 worker，一次同时验证「收信落库 + TG 推送」两条链路，25 秒内 D1 就能查到新行。这比让用户配合发信快得多，也是唯一能自助回归的方法。
16. **R2 未开通返回 `10042 Please enable R2 through the Cloudflare Dashboard`**，开通要绑支付方式——这是用户侧动作，提前说明「不开也能收发普通邮件，只是附件不可用」。
16b. **收信验收完成后要顺手确认「收件人是谁」**：D1 `email` 表列名不是 `user_email`，而是 `email_id / send_email / name / account_id / user_id / subject / content / text / create_time / is_del / status / type / message / in_reply_to`；查大邮件用 `length(content)` 别 SELECT 正文。`account` 表一行 = 一个邮箱地址（`account_id/email/user_id/name/all_receive`）。真实投递的判定证据：`send_email` 是对方真实地址、`create_time` 与用户发信时间吻合。
17. **`sudo bash -c '…heredoc…'` 会卡死**（实测 300s 超时）。要 root 读凭据时：payload 写普通文件、`sudo -n bash -c 'source key; curl --data @/tmp/payload.json'`，不要在嵌套 shell 里塞 heredoc；root 写的 /tmp 文件默认 600，ubuntu 侧读不到，先 `chmod 644`。

18. **D1 写入必须走 `params`，且 body 用文件传**：`curl --data '{"sql":"UPDATE … SET x='…'"}'` 会被 SQL 里的单引号截断 shell 引号，返回 `success:true` 但 `changes:0`——看着像成功，其实一行没改（本机踩过，白查一轮）。正确写法：

    ```python
    open("/tmp/q.json","w").write(json.dumps({"sql":"UPDATE setting SET a=?,b=?","params":[v1,v2]}))
    # curl -X POST -H "Content-Type: application/json" --data @/tmp/q.json \
    #   ".../accounts/{acc}/d1/database/{db}/query"
    ```

    判定写入是否真生效看 `meta.changes` 与 `changed_db`，别只看 `success`；改完立刻回读一次确认。

19. **终端输出会把长 JWT/token 脱敏成 `eyJhbG...MgGk`（13 字符），看起来像服务端 bug**。本机踩过：`POST /api/login` 拿到的 token 只有 13 字符，拿它调 `/api/account/list` 全 401「身份认证失效」，差点去查 jwt_secret 和 KV 缓存。真相是工具层对疑似凭据做了截断显示，磁盘/网络上的 token 是完整的 183 字符。**凡是「登录 → 用 token 调接口」的验收，整条链路必须在一个 shell 脚本里完成**（curl 登录写文件 → python 从文件取 token 写 `/tmp/jwt.txt` → `curl -H "Authorization: $(cat /tmp/jwt.txt)"`），只打印最终业务结果，绝不 `print(token)`；一旦打印过就被脱敏，后续全链路都是假 401。同理适用于 Resend key、CF token 的自测。

19b. **接第三方回调（Resend/Stripe 类）前先读它的路由是否免鉴权**。cloud-mail 的 `POST /api/webhooks` 在 `security.js` exclude 列表里，**默认谁都能调**——知道 URL 就能伪造「已送达/退信」改 D1 状态。接入这类回调时同步补 Svix/HMAC 验签（签名原文含 raw body，必须 `c.req.text()` 不能用 `c.req.json()`），并做 5 分钟时间窗防重放。另外：受限 key（如 Resend `Sending access`）**建不了 webhook**（`401 restricted_api_key`），这一步只能用户在面板点，别为它去要 full access key。详见 `references/cloud-mail-deploy.md`。

## 支持文件

- `scripts/cf-capability-probe.sh` —— 只读探测某 token 能碰哪些 CF 资源族，输出权限矩阵
- `references/cf-token-creation-ui.md` —— 2026-11 新版面板建 token 分步：policy 三选一、权限组归属（`DNS` vs `DNS 设置`、Email Routing 在「电子邮件和消息」）、9 条最小集、Global API Key 位置与风险
- `references/cf-token-api-bootstrap.md` —— **免面板**：用 Global API Key 走 API 建受限 token，含 permission group ID 速查表、policies/resources 键格式、能力矩阵验证、假阴性陷阱
- `references/cloudflare-email-service-limits.md` —— Email Service 配额/价格官方原文摘录（2026-06/10 版）
- `references/cloud-mail-deploy.md` —— cloud-mail 项目结构、wrangler 关键项、初始化、`setting` 表 0=开启的陷阱、前端菜单/权限位映射、收信验收实证、**Resend 发信实况**（子域 CNAME 新形态、受限 key 的 401 属正常、`resend_tokens` 裸域名键、发信成功判定）、**收信推送接管闲置 bot**（四个 tg 字段语义、`custom_domain` 决定 View 按钮、多 scope 清命令菜单 + 清持久键盘、停原服务保留目录）、**Resend webhook 状态回写与 Svix 验签**（事件→status 映射表、受限 key 建不了 webhook、免鉴权路由的加固写法、模拟事件自助验收）
