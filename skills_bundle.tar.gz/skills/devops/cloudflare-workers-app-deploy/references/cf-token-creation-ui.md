# Cloudflare 面板建自定义 Token（2026-11 新版界面实测）

旧教程（Policies 平铺、一屏勾完）已过时。现在（2026-11 实测）流程是：

`dash.cloudflare.com/profile/api-tokens` → `Create Token` → 底部 `Create Custom Token` → `Get started`
→ 出现三选一 policy 入口：

- `Start with an Account policy`
- `Start with a Zone policy`
- `Start with a User policy`

## 权限按分类折叠，不是平铺

勾选区是折叠列表，每类显示 `已选/总数`，例如：

| 分类 | 计数示例 |
|---|---|
| 开发人员平台 | 0 / 64 |
| DNS 和区域 | 0 / 10 |
| 电子邮件和消息 | 0 / 9 |
| 规则和配置 | 0 / 9 |

点分类展开再勾权限组，右侧再选 `编辑` / `读取`。

## 权限组归属（最容易勾错的点）

| 需要的权限组 | 所在分类 | 级别 |
|---|---|---|
| `Workers Scripts` | 开发人员平台 | 编辑 |
| `Workers KV Storage` | 开发人员平台 | 编辑 |
| `D1` | 开发人员平台 | 编辑 |
| `Workers R2 Storage` | 开发人员平台 | 编辑 |
| `Workers Routes` | 开发人员平台 | 编辑 |
| `Workers AI` | 开发人员平台 | **读取**（`[ai]` binding 必需，cloud-mail 验证码识别用） |
| `DNS` | DNS 和区域 | 编辑 |
| `Zone`（区域） | DNS 和区域 | 读取 |
| `Email Routing Rules`（电子邮件路由规则） | **电子邮件和消息** | 编辑 |

### 实测勾错项（出现即纠正）

- **`DNS 设置`(DNS Settings) ≠ `DNS`**。前者管 DNSSEC / CNAME flattening 之类 zone 级设置，**不能写 DNS 记录**。要的是名字就叫 `DNS` 那一行（无「设置 / 视图 / 防火墙 / 分析」后缀）。
- `注册机构: 域` 读取 —— 不需要，取消。
- `Account Settings: Read` —— **可以不要**，用 `CLOUDFLARE_ACCOUNT_ID` 环境变量绕过 wrangler 的 account 探测。
- `Cloudflare Pages` / `Queues` / `Hyperdrive` —— 顺手多勾的，取消。
- `Email Routing Rules` 不在「DNS 和区域」，在「电子邮件和消息」。找不到就先展开分类，别用搜索猜。

## 资源范围

- `所有帐户` 下拉必须改成 `包括` → 具体账号（`user@example.com's Account`），否则 token 对名下全部账号生效。
- 区域资源 `包括` → `特定区域` → 目标域。
- `客户端 IP 地址过滤`：保持 `允许` + 输入框留空。
- `TTL`：无过期时间或按需，别填成几小时导致部署中途失效。

## 最终应得的 9 条（Workers + 邮件应用最小集）

```
Workers Scripts        编辑
Workers KV Storage     编辑
D1                     编辑
Workers R2 Storage     编辑
Workers Routes         编辑
Workers AI             读取
DNS                    编辑
Zone                   读取
Email Routing Rules    编辑
```

## Global API Key 的位置（另一条路）

`Profile → API Tokens` 页面上方 `API 密钥 / API Keys` 区块 → `Global API Key` → `查看` → 输入 CF 登录密码确认 → 复制。
需要同时提供账号登录邮箱（`X-Auth-Email` + `X-Auth-Key` 认证）。
注意：**Global API Key 只能 Roll 不能单独吊销**，Roll 会打断其他仍在使用旧 key 的服务。只把它当一次性 bootstrap 凭据，用完立即从磁盘删除，不要让用户去 Roll。

## 账号 API 令牌 ≠ 用户 API 令牌

`dash.cloudflare.com` 里 `帐户 API 令牌 / Account API Tokens` 页面是**账号级** token，不是用户级 `Profile → API Tokens`。两者入口不同，用户停在「帐户 API 令牌」空列表页时，说明走错了页——直接给 `https://dash.cloudflare.com/profile/api-tokens` 这个 URL。
