# cloud-mail 项目实况与部署要点

仓库：https://github.com/maillab/cloud-mail （MIT）｜文档 docs.skymail.ink ｜ 演示 skymail.ink
2026-11-08 核对：15.5k star / 23.3k fork，最近提交 2026-10-25，活跃维护。

## 结构

```
cloud-mail/
├── mail-worker/          # Hono 后端 + 打包后的前端静态资源
│   ├── src/{api,const,dao,email,entity,error,hono,i18n,init,lib,model,security,service,template,utils}
│   ├── src/index.js      # 入口
│   ├── wrangler.toml         # 本地用，binding 默认注释
│   ├── wrangler-action.toml  # CI 用，${NAME}/${D1_DATABASE_ID}/... 占位
│   └── dist/             # 前端构建产物落点（VITE_OUT_DIR）
└── mail-vue/             # Vue3 + Element Plus + PWA
    ├── .env.release  → NODE_ENV=release, VITE_BASE_URL=/api, VITE_OUT_DIR=../mail-worker/dist
    ├── .env.dev      → VITE_BASE_URL=http://127.0.0.1:8787/api
    └── .env.remote
```

技术栈：Workers + Hono + Drizzle + Vue3/Element Plus；D1 数据库、KV 缓存、R2 附件、Workers AI（验证码识别，默认 `@cf/meta/llama-3.1-8b-instruct-fast`）、Turnstile（人机验证）、发信走 Cloudflare Email 或 Resend。

## wrangler 关键项（binding 名不可改）

- `[[d1_databases]] binding="db"`、`[[kv_namespaces]] binding="kv"`、`[[r2_buckets]] binding="r2"`
- `[ai] binding="ai"`、`[assets] binding="assets" directory="./dist" not_found_handling="single-page-application" run_worker_first=true`
- `[[send_email]] name="forward"`（站内转发到已验证邮箱，不限单地址）；另有注释掉的 `name="email"` = CF 原生发件，配了优先
- `[triggers] crons=["0 * * * *"]`（每小时跑 resetDaySendCount，仅 UTC 0 点生效）
- `[build] command = "pnpm --prefix ../mail-vue install && pnpm --prefix ../mail-vue run build"`（wrangler deploy 会自动构建；手动部署前先独立 build 一次便于排查）
- `compatibility_date = "2025-06-04"`
- `[vars]`：`admin`（管理员邮箱）、`domain`（数组，可多域）、`jwt_secret`、`ai_model`、`analysis_cache`、`orm_log`、`project_link`
- 自定义域：`[[routes]] pattern="<host>" custom_domain=true`（action 版用 `${CUSTOM_DOMAIN}`）

## 初始化

`GET /api/init/<secret>`，secret 必须等于 `vars.jwt_secret`，否则 `❌ JWT secret mismatch`。
按序执行 `initDB / v1_1 / v1_2 / v1_3 / v1_3_1 / v1_4 / v1_5 / v1_6 / v1_7 / v2 / v2_3 … v3_4`，每步 `ALTER TABLE` 包 try/catch，重复执行安全（打印 `跳过字段：…`）。最后 `settingService.refresh(c)`，返回 `success`。

## 功能面（决定部署形态）

多用户邮箱、附件收发（R2）、群发、管理员 RBAC + 资源限额、开放 API（批量建号/多条件查邮件）、转发到 TG Bot 或外部邮箱、Workers AI 自动识别验证码、ECharts 数据可视化、标题/登录背景/透明度自定义、Turnstile 防批量注册。

## 本次（2026-11-08）实测状态

**已跑通到「站点可用 + 管理员可登录」，收信与附件待用户侧两步。**

- 克隆 `~/apps/cloud-mail`（commit d115f4c），前端 build 成功，产物落 `mail-worker/dist`（sw.js/workbox 正常）。
- `mail-worker` 需**单独** `pnpm install`，否则 wrangler 打包报 `Could not resolve "dayjs/plugin/timezone"` / `linkedom` / `ua-parser-js`。
- 资源：D1 `cloud-mail`（`00000000-0000-0000-0000-000000000000`，APAC）、KV `cloud-mail-kv`（`e62b8ed5fce34362b16815f0bd6e6845`）。R2 未开通 → `10042`，附件功能不可用。
- wrangler.toml 实测可用要点：`account_id` 直接写死（绕过 whoami 的 account 检查）、`[assets] run_worker_first = true`、`[[routes]] pattern="mail.<PRIVATE_IDENTIFIER>" custom_domain=true` 自动建 DNS + 证书、`[vars] domain=["<PRIVATE_IDENTIFIER>"]`（TOML 数组）、`admin="admin@<PRIVATE_IDENTIFIER>"`。
- `/api/init/<jwt_secret>` → `success`，建出 user/star/verify_record 等表（`size_after` 180224）。
- 管理员注册：`POST /api/register {"email","password"}` 直接成功（默认 `registerVerify` 关闭，响应 `data.regVerifyOpen:false`）；`POST /api/login` 拿 token。管理员身份**不是靠 `user.type`**，而是 `user.email === vars.admin` 时权限判为 `['*']`（见 `user-service.js:37`、`security.js:148`）。密码 ≥6 位。
- D1 表主键是 `user_id` 不是 `id`；`wrangler d1 execute` 的 `--command` 在嵌套引号里易失败，改走 `POST /accounts/{a}/d1/database/{db}/query {"sql":…}` 更稳。
- Email Routing 启用：**`ops.token` 打通**（`POST /zones/{z}/email/routing/enable` → `enabled:true`），新建的受限 token（`Email Routing Rules:Edit`）401。启用后 CF 自动写 3 条 MX（`route1/2/3.mx.cloudflare.net`，优先级 60/25/51）+ SPF `v=spf1 include:_spf.mx.cloudflare.net ~all` + DKIM `cf2024-1._domainkey`。
- catch-all 默认 `{actions:[{type:"drop"}], enabled:false}`，已用受限 token 改为 `PUT /rules/catch_all {"matchers":[{"type":"all"}],"actions":[{"type":"worker","value":["cloud-mail"]}],"enabled":true,"name":""}`。
- 收信验收卡在「需要真实邮箱发信」：本机 smtplib 直投 `route1/2/3.mx.cloudflare.net:25` 端口通、但被拒 `544 5.7.1 likely unsolicited email`（发件域无 SPF/PTR）。让用户用 Gmail/QQ 发到 `admin@<PRIVATE_IDENTIFIER>` 即可，配 `wrangler tail` 看 `email` 事件。
- 该 zone 原无任何 MX/TXT，启用 Email Routing 未影响既有 18 条 A/CNAME（tunnel、面板、反代）。启用后 DNS 变 24 条（+3 MX +SPF +DKIM）。

## 收信验收（已跑通，2026-11-08）

用户用真实 Gmail（`user@example.com`）发到 `admin@<PRIVATE_IDENTIFIER>` 后，D1 立刻落库，证据：

```
SELECT email_id,send_email,name,account_id,user_id,subject,create_time,type,status,length(content)
FROM email ORDER BY email_id DESC LIMIT 5
→ {email_id:1, send_email:'user@example.com', name:'张五', account_id:1,
   user_id:1, subject:'测试', create_time:'2026-11-08 06:17:19', type:0, status:0, clen:6}
```

`email` 表列名：`email_id / send_email / name / account_id / user_id / subject / content / text / create_time / is_del / status / resend_email_id / type / message / in_reply_to`（**没有 `user_email`/`to_email`**，别猜列名）。`account` 表一行 = 一个邮箱地址：`account_id / email / status / latest_email_time / user_id / name / all_receive / sort`。

## setting 表：0 = 开启（反直觉）

`entity-const.js` 的 `settingConst`：`register / send / receive / addEmail / manyEmail / forwardStatus` 全部 `{OPEN:0, CLOSE:1}`；`registerVerify / addEmailVerify` 是 `{OPEN:0, CLOSE:1, COUNT:2}`；`regKey` 是 `{OPEN:0, CLOSE:1, OPTIONAL:2}`。

**默认 `register=0`，即站点开放注册**——上线验收后立刻 `UPDATE setting SET register=1`，然后重跑 `/api/init/<jwt_secret>` 刷缓存，否则前端仍读旧值。

同一张表里还存着：`title`（站点标题）、`background`、`login_opacity`、`notice_*`（公告）、`tg_bot_token`/`tg_chat_id`/`tg_bot_status`（收信推 TG）、`forward_email`/`forward_status`（转发外部邮箱）、`black_subject`/`black_content`（黑名单）、`auto_clean_days`（自动清理，D1 免费 5GB 要设）、`resend_tokens`（JSON，按域名存 Resend API Key）、`bucket/region/endpoint/s3_*`（自带 S3 兼容存储替代 R2）、`site_key`（Turnstile）。

## 前端菜单结构（写使用说明直接照抄）

个人区：写信 / 收件箱 / 已发送 / 草稿箱 / 星标 / 设置。
管理区（admin 或对应 perm）：分析（`analysis:query`）/ 所有用户（`user:query`）/ 所有邮件（`all-email:query`）/ 权限（`role:query`）/ 邀请码（`reg-key:query`）/ 系统设置（`setting:query`）。
权限位：`email:send`、`analysis:query`、`user:query`、`all-email:query`、`role:query`、`reg-key:query`、`setting:query`。

## 发信第三条腿：Resend（2026-11 核实）

- 免费档：**100 封/天**、3 个自定义域名、30 天日志、1 个 webhook；Pro $20/月不限日发量
- 必须验证域名才能发；**不要开 Resend 的「接收邮件」**——它会往 apex 加 MX，和 Cloudflare Email Routing 的 3 条 MX 直接冲突。只开发送
- **2026-11 实测的 DNS 形态变了，别再按老教程改 apex SPF**：Resend 现在给的是子域 CNAME 方案，本机实际记录为
  - `send.<域> CNAME send.forge.rmta.net`
  - `rsend.<域> CNAME rsend-apne1.forge.rmta.net`
  - `resend._domainkey.<域> TXT p=MIGf…`
  Return-Path 走 `send` 子域，所以 **apex 的 `v=spf1 include:_spf.mx.cloudflare.net ~all` 不需要动**，也不用加 `include:amazonses.com`。看到用户已经加了这三条就别再动 DNS，直接发信验证。
- **Key 权限选 `Sending access` 就够，而且是首选**：这种受限 key 调 `GET /domains` 会返回 `401 {"message":"This API key is restricted to only send emails","name":"restricted_api_key"}`，**这不是配错了**，读不到域名列表很正常。判断域名是否验证通过的唯一可靠证据是 `POST /emails` 返回 `{"id":"01a1b9…"}`；别为了「看一眼域名状态」去要全权限 key。
- **接进 cloud-mail**：`setting.resend_tokens` 是 JSON，**键是不带 @ 的裸域名**，代码里 `resendTokens[domain]`（`email-service.js:414`，domain 来自发信账号地址）取值：

  ```json
  {"<PRIVATE_IDENTIFIER>": "re_xxxxxxxx"}
  ```

  同时 `setting.send` 必须为 `0`（OPEN），改完重跑 `/api/init/<jwt_secret>`。没配 Resend 且收件人含站外地址时，发信报 `noSendProvider`。
- 发信成功判定：`POST /api/email/send` 返回 `emailId`，且 D1 `email` 表该行 `status=1`、`resend_email_id` 已写入。
- 送达/退信/投诉状态回写要另配 Resend webhook（免费档 1 个）打到 `POST /api/webhooks`，否则面板永远停在「已发送」。该路由**默认无签名校验**，接入时必须自己补 Svix 验签；且 `Sending access` 受限 key 建不了 webhook。完整做法见下节。

## Resend webhook 状态回写 + Svix 验签（2026-11-08 实测）

**路由与数据流**：`api/resend-api.js` 注册 `POST /api/webhooks`（`security.js` 的 exclude 里有 `'/webhooks'`，所以**完全免鉴权**）。payload 形如 `{"type":"email.delivered","data":{"email_id":"<resend_email_id>"}}`，`resend-service.js` 按 `type` 改 D1 `email` 表状态：

| Resend 事件 | `email.status` |
|---|---|
| `email.sent` | 1 SENT |
| `email.delivered` | 2 DELIVERED |
| `email.bounced` | 3 BOUNCED |
| `email.complained` | 4 COMPLAINED |
| `email.delivery_delayed` | 5 DELAYED |
| `email.failed` | 8 FAILED |

未匹配到 `resend_email_id` 时只 `console.warn` 后 200 返回（防 Resend 因连续 500 熔断关闭 webhook）——这是设计内行为，别当 bug。

**必须补的加固**：默认实现任何人都能 POST 一个已知 `email_id` 把邮件状态改成「已送达/退信」，URL 一旦泄露即可伪造。按 Svix 规范补 HMAC 校验：

- 签名原文 = `${svix-id}.${svix-timestamp}.${rawBody}`，header 取 `svix-id` / `svix-timestamp` / `svix-signature`
- 密钥 = signing secret 去掉 `whsec_` 前缀后 **base64 解码**，再 `crypto.subtle.importKey('raw', …, {name:'HMAC',hash:'SHA-256'})`
- `svix-signature` 是空格分隔的多个 `v1,<base64sig>`，任一匹配即通过
- 校验 `|now - svix-timestamp| <= 300` 秒防重放
- **必须先 `await c.req.text()` 拿原始 body 再 `JSON.parse`**；用 `c.req.json()` 拿不到原文，签名永远对不上

实现落在 `src/api/resend-api.js`，secret 走 `env.RESEND_WEBHOOK_SECRET`（wrangler `[vars]` 或 `wrangler secret put`）。建议「未配置 secret 时只 `console.warn` 放行」，这样代码可以先部署、用户后建 webhook，不会中途 500；配置后自动切强制校验。

**受限 key 建不了 webhook（关键路径阻塞）**：`GET/POST https://api.resend.com/webhooks` 用 `Sending access` key 一律 `401 {"message":"This API key is restricted to only send emails","name":"restricted_api_key"}`。**不要因此去要 full access key**（权限过大），正确做法是让用户在 `resend.com/webhooks` 点 Add Webhook：URL 填 `https://<面板域>/api/webhooks`、事件全勾（至少 delivered/bounced/complained/failed），保存后复制 `whsec_` signing secret 写到本地文件给我。这是唯一必须用户动手的一步，提前说清楚原因。

**自助验收（不用等真邮件）**：从 D1 取一封已发邮件的 `resend_email_id`，直接 POST 模拟事件到 `/api/webhooks` → 断言 HTTP 200 且该行 `status` 从 1 变 2；重新部署后再验一遍（先把 `status` 复位成 1）。验签上线后同法验证「正确签名 200 / 伪造签名 401」。

**重新部署注意**：非交互 shell 里 `npx wrangler deploy` 会报 `In a non-interactive environment, it's necessary to set a CLOUDFLARE_API_TOKEN`，必须 `CLOUDFLARE_API_TOKEN=$(cat …) npx wrangler deploy --config wrangler.toml`。`wrangler.toml` 里 `keep_vars = true` 时已有 vars 会保留，不会被本次部署清掉。


## 收信推送到 Telegram（复用现成 bot，2026-11-08 跑通）

不一定要新建 bot。用户有闲置 bot（如已停用的对话/破甲 bot）时，直接把它的 token 接过来当收信通知器，比新建更省事，也顺手把废弃项目收掉。

**setting 表四个字段（都可直接 UPDATE D1，无需前端）**

| 字段 | 值 | 说明 |
|---|---|---|
| `tg_bot_token` | bot token | 明文存库，前端回显时 `slice(0,20)+******` |
| `tg_chat_id` | `<YOUR_TELEGRAM_ID>` 或 `a,b,c` | **逗号分隔多个 chat**，`telegram-service.js` 会 split 后逐个发 |
| `tg_bot_status` | **0 = 开启**，1 = 关闭 | 同 `settingConst.tgBotStatus {OPEN:0,CLOSE:1}` |
| `custom_domain` | `https://mail.<PRIVATE_IDENTIFIER>` | **必须设**，否则推送卡片里的 `View` 按钮（Web App）指向 `cloudflare.com/404` |

另有 `tg_msg_to / tg_msg_from / tg_msg_text` 可改消息模板；收到的验证码会自动多一个 `copy_text` 按钮。改完**必须重跑 `/api/init/<jwt_secret>`** 刷 KV 缓存。

**接管闲置 bot 的完整顺序**

1. 先 `getMe` 确认 token 对应的 username/名字，别接错 bot
2. 写 D1 四个字段 → 刷缓存
3. 直接 `sendMessage` 到目标 chat 验证通道（不必等真邮件，先把「token+chat_id 可用」和「邮件触发」两件事分开验）
4. 清掉旧人格痕迹，**四件事都要做，少一件用户就能看见残留**：
   - `setMyName` / `setMyDescription` / `setMyShortDescription` 换新名字与说明（旧说明里常写着「发消息触发 AI」之类，必须改）
   - `deleteMyCommands` **要对每个 scope 各调一次**：默认（空 body）、`{"type":"chat","chat_id":…}`、`all_private_chats`、`all_group_chats`、`all_chat_administrators`。只删默认 scope，私聊里旧菜单还在（实测各 scope 返回值互不影响）
   - **底部持久键盘（reply keyboard）服务端删不掉**，必须由 bot 发一条消息带 `{"reply_markup":{"remove_keyboard":true}}` 才能清掉客户端按钮；只清命令菜单的话用户看到的还是旧按钮
   - 历史消息里旧的内嵌 inline 按钮会留在旧消息上、点了无效——这是正常的，不用管
5. 停原项目：`systemctl stop <svc> && systemctl disable <svc>`，确认 `inactive` + `disabled`
6. **保留代码目录与 root 凭据文件**（`/opt/<svc>`、`/root/.hermes/private/*.token`），不删——回滚成本最低，删了才需要重建
7. 收尾主动说明「同机上哪些服务没动」（如 MTProto/SS 代理与 bot 项目无关，别顺手一起停）

**读 root 凭据的姿势**：`sudo -n cp /root/… /tmp/x && sudo -n chown ubuntu:ubuntu /tmp/x && chmod 600 /tmp/x`，用完 `rm -f`。别把 token 打进命令行参数或 echo 出来——会落 shell 历史与日志。

**端到端验收**：两条证据都要拿到才算通——TG 收到卡片 + D1 `email` 表新增一行。配好 Resend 后可以自己造流量：`POST https://api.resend.com/emails` 从外部发到 `admin@<域>`，25 秒内 D1 就会多一行并触发推送，不必等用户配合（本机 SMTP 直投被 544 拒，别试）。注意「先 `sendMessage` 手工验通道」和「真邮件触发推送」是两件事，要分开验。


