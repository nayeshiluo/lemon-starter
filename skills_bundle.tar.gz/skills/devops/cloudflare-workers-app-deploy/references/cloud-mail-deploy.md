# cloud-mail 项目实况与部署要点

仓库：https://github.com/maillab/cloud-mail （MIT）｜文档 docs.skymail.ink ｜ 演示 skymail.ink
2026-11-08 核对：15.5k star / 23.3k fork，最近提交 2026-10-25，活跃维护。

## 结构

```
cloud-mail/
├── mail-worker/          # Hono 后端 + 打包后的前端静态资源
│   ├── src/{api,const,dao,email,entity,error,hono,i18n,init,lib,model,security,service,template,utils}
│   ├── src/index.js      # 入口
│   ├── wrangler.toml         # 本地用，binding 默认注释
│   ├── wrangler-action.toml  # CI 用，${NAME}/${D1_DATABASE_ID}/... 占位
│   └── dist/             # 前端构建产物落点（VITE_OUT_DIR）
└── mail-vue/             # Vue3 + Element Plus + PWA
    ├── .env.release  → NODE_ENV=release, VITE_BASE_URL=/api, VITE_OUT_DIR=../mail-worker/dist
    ├── .env.dev      → VITE_BASE_URL=http://127.0.0.1:8787/api
    └── .env.remote
```

技术栈：Workers + Hono + Drizzle + Vue3/Element Plus；D1 数据库、KV 缓存、R2 附件、Workers AI（验证码识别，默认 `@cf/meta/llama-3.1-8b-instruct-fast`）、Turnstile（人机验证）、发信走 Cloudflare Email 或 Resend。

## wrangler 关键项（binding 名不可改）

- `[[d1_databases]] binding="db"`、`[[kv_namespaces]] binding="kv"`、`[[r2_buckets]] binding="r2"`
- `[ai] binding="ai"`、`[assets] binding="assets" directory="./dist" not_found_handling="single-page-application" run_worker_first=true`
- `[[send_email]] name="forward"`（站内转发到已验证邮箱，不限单地址）；另有注释掉的 `name="email"` = CF 原生发件，配了优先
- `[triggers] crons=["0 * * * *"]`（每小时跑 resetDaySendCount，仅 UTC 0 点生效）
- `[build] command = "pnpm --prefix ../mail-vue install && pnpm --prefix ../mail-vue run build"`（wrangler deploy 会自动构建；手动部署前先独立 build 一次便于排查）
- `compatibility_date = "2025-06-04"`
- `[vars]`：`admin`（管理员邮箱）、`domain`（数组，可多域）、`jwt_secret`、`ai_model`、`analysis_cache`、`orm_log`、`project_link`
- 自定义域：`[[routes]] pattern="<host>" custom_domain=true`（action 版用 `${CUSTOM_DOMAIN}`）

## 初始化

`GET /api/init/<secret>`，secret 必须等于 `vars.jwt_secret`，否则 `❌ JWT secret mismatch`。
按序执行 `initDB / v1_1 / v1_2 / v1_3 / v1_3_1 / v1_4 / v1_5 / v1_6 / v1_7 / v2 / v2_3 … v3_4`，每步 `ALTER TABLE` 包 try/catch，重复执行安全（打印 `跳过字段：…`）。最后 `settingService.refresh(c)`，返回 `success`。

## 功能面（决定部署形态）

多用户邮箱、附件收发（R2）、群发、管理员 RBAC + 资源限额、开放 API（批量建号/多条件查邮件）、转发到 TG Bot 或外部邮箱、Workers AI 自动识别验证码、ECharts 数据可视化、标题/登录背景/透明度自定义、Turnstile 防批量注册。

## 本次（2026-11-08）实测状态

- 已克隆到 `~/apps/cloud-mail`（commit d115f4c），`pnpm install` + `pnpm run build` 成功，产物落 `mail-worker/dist`（含 sw.js / workbox，PWA 正常）。
- 本机 CF token 权限不足，止步于资源创建（D1/KV/R2/Email Routing 全 `Authentication error`，建新 token `9109`）。部署未完成，等待具备 Workers/D1/KV/R2 权限的 token。
- `<PRIVATE_IDENTIFIER>` zone 当时无任何 MX/TXT 记录，18 条 A/CNAME 均属其它服务；DNS 已快照。
- 目标规划：面板 `mail.<PRIVATE_IDENTIFIER>`（custom domain），收信域名待用户在 apex 与子域间拍板。
