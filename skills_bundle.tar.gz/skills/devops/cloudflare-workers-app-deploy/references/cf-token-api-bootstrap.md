# 用 Global API Key 通过 API 建受限 token（免面板勾选）

2026-11 实测流程。适用于用户已经把 Global API Key（X-Auth-Email + X-Auth-Key）写进本地文件、又嫌面板勾权限麻烦的场景。

## 0. 凭据位置

用户常以 root 操作，文件在 `/root/.config/lemon-cloudflare/cm-bootstrap.key`，内容两行 `email=…` / `key=…`。
先 `sudo -n ls -l` 确认存在，再 `sudo -n awk -F= '{print $1"="length($2)}'` 只打印长度校验格式，**不要打印值**。

## 1. 验证 Global Key

```bash
sudo -n bash -c 'source /root/.config/lemon-cloudflare/cm-bootstrap.key; \
  curl -s -H "X-Auth-Email: $email" -H "X-Auth-Key: $key" \
  https://api.cloudflare.com/client/v4/user'
```

返回 `success:true` + 账号邮箱。Global Key 用 `X-Auth-Email`/`X-Auth-Key`，**不是** `Authorization: Bearer`。

## 2. 拉权限组 ID（别背 ID，现查）

```bash
sudo -n bash -c 'source …; curl -s -H "X-Auth-Email: $email" -H "X-Auth-Key: $key" \
  "https://api.cloudflare.com/client/v4/user/tokens/permission_groups?per_page=200" -o /tmp/pg.json'
sudo -n chmod 644 /tmp/pg.json   # root 写的文件默认 600，ubuntu 读不到
```

421 个权限组。按 `name` + `scopes` 过滤，`scopes` 决定 resources 键前缀：
- `com.cloudflare.api.account` → account 级资源
- `com.cloudflare.api.account.zone` → zone 级资源

### 实测 ID 速查（2026-11，仍建议现查校验）

| 权限组 | ID | scope |
|---|---|---|
| Workers Scripts Write | `e086da7e2179491d91ee5f35b3ca210a` | account |
| Workers KV Storage Write | `f7f0eda5697f475c90846e879bab8666` | account |
| D1 Write | `09b2857d1c31407795e75e3fed8617a1` | account |
| Workers R2 Storage Write | `bf7481a1826f439697cb59a20b22293e` | account |
| Workers AI Read | `a92d2450e05d4e7bb7d0a64968f83d11` | account |
| Account Settings Read | `c1fde68c7bcc44588cbb6ddbc16d6480` | account |
| Email Routing Addresses Write | `e4589eb09e63436686cd64252a3aebeb` | account |
| DNS Write | `4755a26eedb94da69e1066d98aa820be` | zone |
| Zone Read | `c8fed203ed3043cba015a93ad1616f1f` | zone |
| Email Routing Rules Write | `79b3ec0d10ce4148a8f8bdc0cc5f97f2` | zone |
| Workers Routes Write | `28f4b596e7d643029c524985477ae49a` | zone |

注意 `DNS Write`（zone）≠ `Account DNS Settings Write`；`Zone Read`（zone）≠ `Account Settings Read`。

## 3. 建 token（payload 走文件，别用 heredoc）

```json
{
  "name": "cloud-mail-deploy",
  "policies": [
    {
      "effect": "allow",
      "resources": { "com.cloudflare.api.account.<ACC_ID>": "*" },
      "permission_groups": [
        { "id": "e086da7e2179491d91ee5f35b3ca210a" },
        { "id": "f7f0eda5697f475c90846e879bab8666" },
        { "id": "09b2857d1c31407795e75e3fed8617a1" },
        { "id": "bf7481a1826f439697cb59a20b22293e" },
        { "id": "a92d2450e05d4e7bb7d0a64968f83d11" },
        { "id": "c1fde68c7bcc44588cbb6ddbc16d6480" }
      ]
    },
    {
      "effect": "allow",
      "resources": { "com.cloudflare.api.account.zone.<ZONE_ID>": "*" },
      "permission_groups": [
        { "id": "4755a26eedb94da69e1066d98aa820be" },
        { "id": "c8fed203ed3043cba015a93ad1616f1f" },
        { "id": "79b3ec0d10ce4148a8f8bdc0cc5f97f2" },
        { "id": "28f4b596e7d643029c524985477ae49a" }
      ]
    }
  ]
}
```

```bash
sudo -n bash -c 'source /root/.config/lemon-cloudflare/cm-bootstrap.key; \
  curl -s -X POST -H "X-Auth-Email: $email" -H "X-Auth-Key: $key" \
  -H "Content-Type: application/json" --data @/tmp/cm-token-payload.json \
  https://api.cloudflare.com/client/v4/accounts/<ACC_ID>/tokens -o /tmp/cm-token-resp.json; \
  chmod 600 /tmp/cm-token-resp.json'
```

响应 `result.value` 就是 token（只返回一次，53 字符）。写盘：

```bash
sudo -n python3 -c "
import json,os
v=json.load(open('/tmp/cm-token-resp.json'))['result']['value']
p='/home/ubuntu/.config/lemon-cloudflare/cloud-mail.token'
open(p,'w').write(v); os.chmod(p,0o600); os.chown(p,1000,1000)"
sudo -n rm -f /root/.config/lemon-cloudflare/cm-bootstrap.key /tmp/cm-token-resp.json /tmp/cm-token-payload.json /tmp/pg.json
```

删 bootstrap 会触发 Hermes 的「批量删除」审批，属预期。

## 4. 验证新 token 的能力矩阵

逐族 GET，看 `success`，别只看 verify：

| 检查 | 端点 | 本机实测结果 |
|---|---|---|
| `user/tokens/verify` | — | ❌ `1000 Invalid API Token`（**假阴性，忽略**） |
| D1 | `accounts/{a}/d1/database` | ✅ |
| KV | `accounts/{a}/storage/kv/namespaces` | ✅ |
| R2 | `accounts/{a}/r2/buckets` | ❌ `10042` 未开通 R2（非权限问题） |
| Workers | `accounts/{a}/workers/scripts` | ✅ |
| DNS | `zones/{z}/dns_records` | ✅ |
| Workers Routes | `zones/{z}/workers/routes` | ✅ |
| Email Routing rules | `zones/{z}/email/routing/rules` | ✅ |
| Email Routing settings | `zones/{z}/email/routing` | ❌ 401（`Email Routing Rules:Write` 不够，需面板启用或补 account 级 `Email Routing Addresses:Write`） |

## 5. 收尾

部署验收完成后删除受限 token：
`DELETE /accounts/{acc}/tokens/{token_id}`（Global Key 已删，需用其他有 `API Tokens:Write` 的凭据；没有就留 token 在盘上并告知用户，600 权限 + 只作用于单 zone）。
