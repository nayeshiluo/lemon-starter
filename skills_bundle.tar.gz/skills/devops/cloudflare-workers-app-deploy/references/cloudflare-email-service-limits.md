# Cloudflare Email Service 限制与价格（原文摘录）

来源与核对日期（全部本次成功读取正文）:
- https://developers.cloudflare.com/email-service/ （页面更新 2026-10-15）
- https://developers.cloudflare.com/email-service/platform/pricing/ （页面更新 2026-06-09）
- https://developers.cloudflare.com/email-routing/limits/ （页面更新 2026-10-30）

## 关键结论

| 能力 | Workers Free | Workers Paid |
|---|---|---|
| 入站（Email Routing） | 支持，**不限量** | 支持，不限量 |
| 出站（Email Sending），任意收件人 | **不可用** | 支持，含 3,000 封/月，超出 $0.35/千封 |
| 出站到「已验证目标地址」 | 免费，不计配额 | 免费，不计配额 |

- 3,000 封按 **account** 计、按月、与 CF 订阅账单周期对齐。
- 硬退信或被 Email Service 接收的邮件都计配额；在 API 边界被拒（含 suppression list 拦截）**不**计。
- Email Sending 仍标 **Beta**。Email Routing 的 Workers 用量按 Workers 定价另计。
- Free 套餐跑复杂收信 handler 可能触发 `EXCEEDED_CPU`，日志可见，需升 Paid。
- Worker 用 `send_email` binding 发出的邮件，在 **Email Routing 汇总里显示为 dropped**（即使投递成功）——核对投递要看 Email Sending 的 metrics/logs，不要看 Routing 汇总。

## 配额细节

内容限制
- 收件人（to/cc/bcc 合计）：50 封/邮件
- 主题：998 字符（RFC 5322）
- 总大小（含附件）：25 MiB
- 自定义头合计：16 KB

Email Routing
- 每域 routing rules：200
- 每 account 已验证目标地址：200（该 account 内所有域共享）
- 入站邮件大小上限：25 MiB
- `References` 头超过 100 条时 `message.reply()` 抛错（防回复环）
- 一个 routing rule = 一个 pattern → 一个目标（地址或一个 Worker）。要一发多目标，用 Worker 对每个目标调一次 `forward()`，且目标需预先验证。

Suppression list
- 每个地址每个 scope 一条有效条目（account 级 + 每发信域各一）
- 分页 `per_page` 上限 1,000（默认 100），无总数统计字段
- 批量导入单次上限 1,000 条；批量导入请求 10 次/分钟（超限 429）
- note 字段 1,000 字符

Zone 维度
- 每 zone 配置的域（Email Routing + Email Sending 合计，含 apex）上限 30

## 提高配额
官方 `Limit Increase Request Form`（limits 页末尾）。新账号日发信量从保守配额起步、按发信行为与退信率自动上调。

## 部署判断要点
- 只想「收信 + 面板看邮件」→ Free 足够，零成本。
- 想当真正邮箱往外发信 → 必须 Workers Paid（$5/月起）。
- 想避开 Beta 波动 → 额外接 Resend 作为发信通道（项目内部支持）。
- 合规：CAN-SPAM / GDPR / CASL，需提供退订并尊重 opt-out，否则发信信誉崩。
