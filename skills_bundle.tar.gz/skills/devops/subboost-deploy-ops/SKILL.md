---
name: subboost-deploy-ops
description: Use when 部署/运维 SubBoost 订阅转换器（含低内存机避 OOM、CF Tunnel 发布）。
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [devops, cloudflare-tunnel, docker, proxy, subscription]
    related_skills: [cloudflare-tunnel-ops, oss-project-evaluation, selfhosted-service-audit]
---

# SubBoost 部署与运维

订阅转换/配置生成工具（Clash·Mihomo / Surge / Loon / V2Ray）。本技能记录 2026-10 在 vps-la（2GB 内存洛杉矶机）实机部署到 `https://sub.<PRIVATE_IDENTIFIER>` 的完整可用路径与全部坑。

## When to Use

- 部署 SubBoost 或其二改版（如 `youko-nobody/subboost-youko`）
- 小内存机（≤2GB）上跑 Next.js 应用被 OOM 卡住
- 需要给自建服务挂 CF Tunnel 且**不能碰**机器上已有隧道
- 排查 SubBoost 订阅不自动刷新 / cron 容器报连不上

## 关键事实（先读，省一半时间）

| 项 | 值 |
|---|---|
| 官方预构建镜像 | `ghcr.io/youko-nobody/subboost-youko:<tag>`，公开可拉，有 `latest` 与版本号 tag |
| 镜像大小 | app ≈1.54GB，postgres:16-alpine ≈420MB，curlimages/curl ≈32MB |
| 运行内存 | app ≈65MB、db ≈23MB、cron ≈6MB（实测 RSS，极轻） |
| 端口 | 容器内 3000，映射到宿主 **127.0.0.1:3001** |
| 必需环境变量 | `DATABASE_URL` `ENCRYPTION_KEY` `JWT_SECRET` `CRON_SECRET` `LOCAL_SETUP_TOKEN` `APP_URL` |
| `APP_URL` | **必须写正式域名** `https://sub.example.com`，不能写 `127.0.0.1`/`localhost`（否则定时任务生成的订阅链接与 `profile-web-page-url` 全错） |
| 管理员初始化 | `/login#setup-token=<LOCAL_SETUP_TOKEN>`，一次性 |

**决定性结论：2GB 机器不要本地 build。** Next.js 16 build 峰值破 1GB，必 OOM。直接拉 GHCR 预构建镜像，compose 里把 `build:` 换成 `image:`。

## 部署流程

### 1. 前置核查（只读）

```bash
ssh <host> "free -m; df -h /; nproc; docker --version; docker compose version; ss -ltnp | grep -E ':3000|:3001'"
```
3000/3001 被占就换端口；内存 available < 800MB 要留意。

### 2. 本地生成文件再 scp（**不要用 SSH heredoc**）

```bash
# 本地目录
mkdir -p ~/.hermes/workspace/subboost-deploy && cd $_
```
`docker-compose.yml` 要点：
- `app.image: ghcr.io/...:2.7.0`（钉版本，别用 latest）
- `ports: ["127.0.0.1:3001:3000"]` ← **只绑回环，绝不裸公网**
- `db` 用 `postgres:16-alpine` + healthcheck + named volume
- `cron` 用 `curlimages/curl`，command 里 `$${CRON_SECRET}` 转义让容器内 sh 展开
- 三个服务都 `restart: unless-stopped`

`.env` 随机生成：
```bash
DBPASS=$(openssl rand -hex 24)
# DATABASE_URL=https://<USER>:<PASSWORD>@db:5432/subboost
# ENCRYPTION_KEY / JWT_SECRET / CRON_SECRET / LOCAL_SETUP_TOKEN 各 openssl rand -hex 32
chmod 600 .env
```

```bash
ssh <host> 'mkdir -p /opt/subboost'
scp docker-compose.yml .env <host>:/opt/subboost/
ssh <host> 'chmod 600 /opt/subboost/.env'
ssh <host> 'cd /opt/subboost && docker compose --env-file .env config --quiet && echo CONFIG_VALID'
```

### 3. 拉镜像（后台，别阻塞）

镜像 1.5GB，小机带宽慢，前台必超时：
```bash
ssh <host> 'cd /opt/subboost && nohup docker compose --env-file .env pull > pull.log 2>&1 &'
# 轮询
ssh <host> 'cd /opt/subboost && tail -3 pull.log; docker images | grep -E "subboost|postgres|curl"'
```

### 4. 起栈 + 验收

```bash
ssh <host> 'cd /opt/subboost && docker compose --env-file .env up -d'
ssh <host> 'cd /opt/subboost && docker compose ps; docker compose logs app --tail 20'
ssh <host> 'curl -s -o /dev/null -w "%{http_code}\n" http://127.0.0.1:3001/api/health/ready'
```
DB 迁移日志应见 `All migrations have been successfully applied.` 与 `✓ Ready`。

### 5. CF Tunnel 发布（不动已有隧道）

**Token 分工（踩过坑）**：
- `~/.config/lemon-cloudflare/ops.token` → **只能写 DNS**，Tunnel 只读，创建报 `Authentication error` / 改报 `Not authorized`
- `~/.config/lemon-cloudflare/tunnel-admin.token` → **能建/改 Tunnel**

先取 account id（account 级 API 必须带 id，否则 `7003 Could not route`）：
```bash
curl -s "https://api.cloudflare.com/client/v4/zones/<ZONE_ID>" -H "Authorization: Bearer $TDNS" \
  | jq -r '.result.account.id'
```

建隧道（`config_src: cloudflare` = 远程管理 ingress）：
```bash
# 1) 建
curl -X POST ".../accounts/$ACC/cfd_tunnel" -H "Authorization: Bearer $TADMIN" \
  -d '{"name":"subboost-tunnel","config_src":"cloudflare"}'
# 2) 取 connector token 写文件（勿打印到聊天）
curl ".../accounts/$ACC/cfd_tunnel/$TID/token" -H "Authorization: Bearer $TADMIN" | jq -r .result > tunnel.token
# 3) 配 ingress
curl -X PUT ".../accounts/$ACC/cfd_tunnel/$TID/configurations" -H "Authorization: Bearer $TADMIN" \
  -d '{"config":{"ingress":[{"hostname":"sub.example.com","service":"http://127.0.0.1:3001"},{"service":"http_status:404"}]}}'
# 4) DNS CNAME -> $TID.cfargotunnel.com, proxied=true（用 DNS token）
```

宿主起**独立** systemd 服务（新 unit 名，绝不改现有 tunnel unit）：
```ini
[Service]
Type=simple
ExecStart=/bin/sh -c '/usr/local/bin/cloudflared --no-autoupdate tunnel run --token $(cat /etc/cloudflared/subboost.token)'
Restart=always
RestartSec=5
```
```bash
chmod 600 /etc/cloudflared/subboost.token
systemctl daemon-reload && systemctl enable --now subboost-tunnel
```

**访问控制**：SubBoost 自带 `/login` 账号密码体系，**不需要** CF Access（邮箱验证码纯属添麻烦）。CF 只负责藏源站 IP。

### 6. 交付：管理员留给用户建

绝不代设密码。给用户一次性链接：
```
https://<domain>/login#setup-token=<LOCAL_SETUP_TOKEN>
```

## 验收清单（逐项实测，缺一不算完）

```bash
# 未登录鉴权（应 401）
for p in /api/subscriptions /api/backup /api/settings/runtime; do
  curl -s -o /dev/null -w "$p -> %{http_code}\n" "https://<domain>$p"; done
# /api/auth/me 应回 {"setupRequired":true,"authenticated":false,"user":null}

# 假 token 拉配置应 404
curl -s -o /dev/null -w '%{http_code}\n' "https://<domain>/api/subscriptions/deadbeefdeadbeef/config.yaml"

# 源站不裸露（从外部直连应 000/拒绝）
curl -s -o /dev/null -w '%{http_code}\n' http://<origin-ip>:3001/

# CF 头 + 无源站泄露
curl -sI "https://<domain>/login" | grep -iE '^server:|^cf-ray:'

# 老隧道仍正常
curl -s -o /dev/null -w '%{http_code}\n' https://rules.<domain>/

# 开机自启
systemctl is-enabled subboost-tunnel <既有tunnel>; systemctl is-active subboost-tunnel <既有tunnel>

# cron 循环活着（有 sleep 360 进程）+ 端点 200
docker exec subboost-cron-1 ps -ef | head
docker exec -e S=$CRON_SECRET subboost-cron-1 sh -c \
  'curl -s -o /dev/null -w "%{http_code}\n" -X POST -H "Authorization: Bearer $S" http://app:3000/api/cron/update-subscriptions'
```

## 坑（全部实测踩过）

1. **`ssh host 'bash -s' <<'EOF'` 会卡死**。远端 bash 读 stdin 与 heredoc 冲突，脚本整个中断、目录都建不出来。→ 一律**本地写文件 + scp**。
2. **execute_code 里嵌套引号/多条 SSH 串联会整体 300s 超时**。→ 写成 `.sh` 文件用 `bash file.sh < /dev/null` 跑，或拆成单条 `terminal` 调用。
3. **单引号里嵌 `$(...)` 触发远端命令替换等待** → 也卡死。避免在 SSH 命令串里塞命令替换。
4. **`Type=notify` + `sh -c` 包装**：cloudflared 实际已连上（日志见 4 条 connection registered），但 systemd 收不到 readiness → 判 timeout、卡 `activating`。→ 用 `Type=simple`。
5. **CF token 权限分层**：DNS token 建不了隧道（`Authentication error`）；account 级 API 漏 account id 报 `7003 Could not route`。先探权再动手，测试用一次性资源（建完即删）。
6. **cron 容器日志只有 2 行"Failed to connect"是正常的**：那是启动瞬间 app 未就绪，`exit 1` 后由 `restart: unless-stopped` 自愈；`curl -fsS` 成功时不输出，所以日志静默=正常。判断健康看 `ps` 有没有 `sleep 360` + 手动打端点。
7. **不要用 `latest` tag**：钉版本号，避免上游更新引入未审代码。
8. **AGPL-3.0**：对外提供服务需向用户提供源码（自用无碍）。
9. 磁盘：部署后 `/` 从 67%→77%（镜像 1.5GB），预留 3GB 以上。
10. **`APP_URL` 填错是隐形坑**：填 `127.0.0.1:3001` 时网页端复制链接看着正常（会用当前访问域名兜底），但后台定时任务生成的链接和 `profile-web-page-url` 响应头是错的。部署时就直接写正式域名，事后改 `.env` 后必须 `docker compose up -d` 重启 app 才生效。

## 监控接入（Komari）

机器在册只覆盖主机层（CPU/内存/流量），**网站 502 探针不会报**。要真正监控可用性：

- 加一条 `ping_tasks`，`type=http`，`target=https://<domain>/api/health/ready`，`interval=60`，挂在**异地**节点上探（真实用户视角）。
- 开该机器的 `offline_notifications.enable=1`（grace 180s）。
- **必须**把 `configs.notification_method` 从默认 `"none"` 改成真实渠道，否则通知永远发不出。

完整 SQL、数据落点（`metrics.db` 的 `ping.latency_ms` / `ping.loss`）、Telegram JS 渠道脚本与坑，见 `monitor-hub-ops` 的「加 HTTP 站点可用性探测 + 打通通知」一节。

## 安全边界
- 端口只绑 `127.0.0.1`，公网入口只走 CF Tunnel。
- `.env`、tunnel token 一律 600，**永不打印到聊天**。
- 订阅输出接口（config.yaml / loon.conf / surge.conf / v2ray）设计上公开可拉，靠订阅 token + 限流保护 → 提醒用户订阅链接等同密码，勿外泄。
- 新增隧道必须与既有隧道**物理隔离**（独立 unit + 独立 token 文件），改前先确认既有 unit 名与状态，改后复验它仍 `active`。
