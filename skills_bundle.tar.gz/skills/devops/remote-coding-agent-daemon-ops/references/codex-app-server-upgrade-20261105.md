# 实测：洛杉矶 RackNerd 上 Codex app-server 升级（2026-11-05）

主机别名 `vps-la`，入口端口 `2222`，`~/.codex/logs_2.sqlite` 为日志源。

## 一、起点状态

| 项目 | 值 |
|---|---|
| 全局 CLI | `codex-cli 0.157.0-alpha.10`（`/usr/local/bin/codex`，npm global） |
| 受管 daemon 包 | `0.157.0-alpha.10`（`~/.codex/packages/app-server-daemon/current/bin/codex`） |
| 运行中进程 | PID 3121 `node /usr/local/bin/codex app-server --listen unix://`，PPID=1，已跑 36 天 |
| cgroup | `user.slice/user-0.slice/session-12.scope`，`Active: active (abandoned)` |
| node / npm | `v18.19.1` / `9.2.0` |

结论：进程能活 36 天是因为 PPID=1 已 daemonize，但 cgroup 仍挂在废弃的 SSH 会话 scope 上——
这正是「手机端连接莫名消失」的结构性隐患。

## 二、SSH 传输层排除（证明不是服务器踢人）

```bash
# 端口
timeout 8 bash -c 'cat < /dev/null > /dev/tcp/<PRIVATE_IDENTIFIER>/2222'   # OPEN
# 服务端 key 台账
ssh-keygen -lf /root/.ssh/authorized_keys
#   5 条：lemon-aws-racknerd-admin / chatgpt-la-vps / servercat-la-iphone /
#         codex-app-iphone / beszel-hub
# 手机 key 最后成功
journalctl -u ssh --since "3 days ago" | grep "0umim1eu" | tail -5
#   Nov 05 09:13:20 UTC 之后再无任何记录
```

配套排除（全部干净）：

- `fail2ban-client status sshd` → `Currently banned: 0`，手机 IP 未封
- `ss -tn state established "( sport = :2222 )"` → 只有本机 7 条隧道，无手机连接
- `nf_conntrack_count / max` → `1097 / 65536`
- `dmesg -T | grep -iE "conntrack|nf_|drop"` → 只有开机那条 `drop_monitor`
- 近 24h `Failed publickey` 计数 `0`

判据成立：**高频基线（该 key 7 天 833 次登录、单小时 3~72 次）+ 断点后连失败记录都没有
= 客户端根本没再发起连接**，不是认证失败、不是封禁、不是服务端踢人。

## 三、升级执行与真实输出

```bash
npm install -g @openai/codex@0.166.0        # changed 2 packages in 24s
codex --version                              # codex-cli 0.166.0

codex app-server daemon version
# cliVersion 0.166.0 / appServerVersion 0.157.0-alpha.10  ← 不一致，daemon 还是旧代码

codex app-server daemon update --from-cli
# Error: app server is running but is not managed by codex app-server daemon

codex app-server daemon stop
# 同样报 not managed

kill -TERM 3121; sleep 5                     # stopped by TERM，无残留 codex 进程

codex app-server daemon bootstrap
# {"status":"bootstrapped","backend":"pid","autoUpdateEnabled":false,
#  "managedCodexVersion":"0.157.0-alpha.10",...}

codex app-server daemon update --from-cli
# Error: daemon installation requires confirmation; rerun with --yes to copy this CLI package
#   ↑ 退出码仍是 0，必须看输出文本，不能只看 $?

codex app-server daemon update --from-cli --yes
# {"status":"updated","installedVersion":"0.166.0","runningVersion":"0.166.0",
#  "message":"The CLI package is selected and pinned. Run `codex app-server daemon update`
#             to return to production updates."}
```

升级后的进程形态（正确的托管形态）：

```
555681  1  /root/.codex/packages/app-server-daemon/releases/local-<hash>-x86_64-unknown-linux-musl/bin/codex \
           app-server --listen unix:// --analytics-default-enabled --managed-daemon
```

socket 指向：`~/.codex/app-server-control/app-server-control.sock -> /tmp/codex-daemon-0/<hash>`

## 四、验收输出

```bash
codex app-server daemon version
# {"status":"running","backend":"pid","managedCodexVersion":"0.166.0",
#  "socketPath":"/root/.codex/app-server-control/app-server-control.sock",
#  "cliVersion":"0.166.0","appServerVersion":"0.166.0"}

codex exec --skip-git-repo-check -c model_reasoning_effort=low "只回复两个字：升级成功"
# codex: 升级成功 / tokens used 2,880 / exit 0
```

模型兼容：`config.toml` 里 `model = "gpt-6-luna"`，新版 `models_cache.json` 共 11 个模型，
`gpt-6-luna` 在列（其余样例：`gpt-6.1-sol`、`gpt-6-astra`、`gpt-6.1-terra`、`gpt-reserve`）。

## 五、日志判读实录

`journalctl -u codex` → `-- No entries --`（非 systemd 单元，属正常）。

`logs_2.sqlite` 最新 12 行（升级后）：

```
12:29:59 INFO  list_models ... GET /models ... status=200 OK
12:29:59 INFO  skills cache cleared (0 entries)
12:30:05 TRACE app-server request: initialize connection_id=ConnectionId(2) request_id=Integer(1)
12:30:05 INFO  <- notification: JSONRPCNotification { method: "initialized" }
12:30:05 TRACE app-server event: remoteControl/status/changed targeted_connections=1
12:30:05 WARN  dropping message for disconnected connection: ConnectionId(2)
```

`dropping message for disconnected connection` 是**旧连接收尾**的正常噪音（daemon 重启时原连接被丢弃），
不要误读成故障。

## 六、备份与回滚

- 备份：`/root/backups/codex-upgrade-20261105T122735Z/`
  （`config.toml`、`auth.json`(600)、`baseline.txt` 含旧版本/进程/daemon version 快照）
- 回滚：`npm install -g @openai/codex@0.157.0-alpha.10` → 恢复 `config.toml` → `daemon update --from-cli --yes`
- 版本已被 pin，恢复自动跟随：`codex app-server daemon update`

## 七、可复用的判据

1. `daemon version` 的 `cliVersion` ≠ `appServerVersion` ⇒ daemon 跑旧代码，npm 升级不影响它。
2. cgroup 落在 `session-N.scope` ⇒ 手工起的，需要 `bootstrap` 才有持久化。
3. `daemon update --from-cli` 不带 `--yes` 时**退出码 0 但什么也没做**——永远回读 `daemon version`。
4. 升级后必查 `models_cache.json` 是否仍含配置里的 model id，否则推理链路直接断。
