# OpenCode v2 手机/远程客户端配对（2026-11-08 实测）

场景：用户在手机上装了 OpenCode App，界面提示 "On your computer, open OpenCode and go to Settings → Pairing, or run `opencode pair --remote`"，要求把服务器上的 opencode 与手机配对。

## 结论先行

- **两条版本线并存**，手机 App 只认 v2。v1（npm `opencode-ai` 1.19.x）没有 `pair` 子命令，敲 `opencode pair` 只会把主 help 横幅再打一遍，容易被误读成"命令没生效"。
- v2 装到 `$HOME/.opencode/bin`，入口名是 `opencode2`，**不覆盖** v1 的 `~/.npm-global/bin/opencode`。不需要卸载 v1。

| 线 | 安装 | 二进制 | `pair` |
|----|------|--------|--------|
| v1 | `npm --prefix ~/.npm-global i -g opencode-ai@latest` | `~/.npm-global/bin/opencode` (1.19.5) | 无 |
| v2 | `curl -fsSL https://opencode.ai/v2/install \| bash` | `~/.opencode/bin/opencode2` (2.2.6) | 有 |

装 v2 前先读一遍安装脚本（`curl -fsSL https://opencode.ai/v2/install -o /tmp/x.sh`）确认 `INSTALL_DIR` 和二进制名，再执行——避免它悄悄顶掉现有 CLI。

## 配对流程

```bash
export PATH="$HOME/.opencode/bin:$PATH"
cd /path/to/project            # 这个目录 = server 的工作区
opencode2 pair --remote --yes
```

- `--remote` 经 OpenTunnel 把 server 暴露到公网（E2E 加密，另需 server password）。
- `--yes` 在非交互终端下必需，否则卡在"确认暴露"提示。
- 输出：一次性链接 `https://<hash>.<tunnel>.opentunnel.xyz/auth/connect/<token>` + ASCII 二维码，**然后进程 exit 0**。

## 关键判读：pair 退出 ≠ 服务停了

`pair` 只是"打印链接"的前台命令，打印完就退出。真正常驻的是它拉起的子进程：

```bash
ps aux | grep 'opencode serve' | grep -v grep    # → opencode serve --service
ss -lntp | grep opencode                          # → 127.0.0.1:<随机端口>
ls -l /proc/<pid>/exe                             # 确认是 ~/.opencode/bin/opencode（v2）
```

实测：pair 退出后 `opencode serve --service` 仍在跑，端口 49374。

交付链接前先验隧道活着：

```bash
curl -s -m 15 -o /dev/null -w '%{http_code}\n' https://<hash>.<tunnel>.opentunnel.xyz/
# 期望 200
```

## 交付纪律

- 链接**一次性、5 分钟过期**。生成→验 200→立刻发，别夹在长报告后面。
- 链接 = 服务器 opencode 的访问权。只给所有者本人，不进群、不落日志、不写进技能文件。
- 工作目录在 pair 时固定。换项目要重跑 `pair`，会出新链接。
- 手机端用 App 底部的 "Paste" 粘链接最快；扫码要终端二维码，截图传手机反而麻烦。

## 附带核实：Console 认证方式

`https://opencode.ai/auth` → 跳 `https://opencode.ai/console/login`。前端 bundle（`/console/assets/index-*.js`）里只有 `auth/register`、`auth/verify-email`、GitHub / Google social provider——**没有手机号/短信登录**，所以接码平台对它无效。这条事实用来回答"能不能接码注册"，省得再翻一遍 bundle。

手动塞 key：`opencode auth login -p opencode`，提示 `Enter your API key`，需 `pty=true` 交互输入。

## 与免费额度的关系

v1 实测 `opencode/*-free` 报 `Free usage limit reached`，且换出口 IP 无效（额度按安装/设备算）。v2 + 手机 App 是否共用同一额度未验证——不要预设换客户端就能刷出额度，也不要批量注册刷免费额度（滥用，会封号）。
