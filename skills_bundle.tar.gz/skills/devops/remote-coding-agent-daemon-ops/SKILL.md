---
name: remote-coding-agent-daemon-ops
description: "Use when 远端 VPS 上编码 agent 常驻服务断连/需升级：分层排障、托管化、版本对齐。"
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux]
metadata:
  hermes:
    tags: [codex, app-server, daemon, upgrade, ssh, systemd, cgroup, vps]
    related_skills: [ssh-login-troubleshooting, selfhosted-service-audit, host-operations-evidence, cloud-sandbox-vm-ops]
---

# 远端编码 Agent 常驻服务运维

## When to Use

远端 VPS 上的编码 agent 以常驻 daemon 形式提供服务，手机/桌面客户端经 SSH 使用该环境时：

- 用户说「XX 的 ssh 连接好像断了」「环境显示离线」「连上了但 codex 没反应」
- 需要**升级**远端 agent CLI（版本落后、协议不兼容、想对齐本机版本）
- 进程活着但客户端连不上；或进程随 SSH 断开而消失
- 远端 daemon 版本与 CLI 版本不一致
- **首次把手机/桌面客户端配对到服务器上的编码 agent**（OpenCode v2 `pair --remote`、隧道暴露、一次性链接交付）

不适用：纯 SSH 登录失败（走 `ssh-login-troubleshooting`）；只读体检（走 `selfhosted-service-audit`）。

## 铁律

1. **先分层，再动手**。传输层（TCP/sshd）与 agent daemon 层是两回事，混在一起查必然误判。
2. **`daemon version` 的三个版本字段就是体检报告**，不一致说明 daemon 还在跑旧代码。
3. **手工在 SSH 会话里起的进程不是托管服务**。cgroup 落在 `session-N.scope` 的 daemon 随时会随会话消失。
4. **升级必须走官方 daemon 子命令**，不要 `pkill` 后手工重起——那会丢掉受管路径，下次还是同样的坑。
5. **验收要真跑一次推理**。`daemon version` 只证明进程起来了，不证明模型链路通。

## 一、分层定位（三条命令定性）

```bash
# ① 传输层
timeout 8 bash -c 'cat < /dev/null > /dev/tcp/<IP>/<port>' && echo OPEN || echo CLOSED
ssh -o ConnectTimeout=10 -o BatchMode=yes <别名> 'hostname; uptime'

# ② daemon 层（JSON 直接给结论）
codex app-server daemon version
# {"status":"running","managedCodexVersion":"...","cliVersion":"...","appServerVersion":"..."}

# ③ 进程形态
ps -eo pid,ppid,etime,user,cmd | grep 'app-server' | grep -v grep
cat /proc/<pid>/cgroup
```

判读：

| 现象 | 结论 | 动作 |
|---|---|---|
| 端口通 + `status: running` + 三版本一致 | daemon 健康，问题在客户端 | 转 `ssh-login-troubleshooting` 铁律五 |
| `status: running` 但 `appServerVersion` ≠ `cliVersion` | 跑的是旧代码 | 升级 / 重启 daemon |
| `status` 非 running | daemon 没起 | `daemon start`（或 `bootstrap`） |
| cgroup 是 `session-N.scope` | 手工起的，会话一断就悬空 | `bootstrap` 接管 |

## 二、日志在 SQLite 里，不在 journalctl

`journalctl -u codex` 返回 `-- No entries --` 是正常的（它不是 systemd 单元）。真实日志：

```bash
python3 - <<'EOF'
import sqlite3, datetime
c = sqlite3.connect("file:/root/.codex/logs_2.sqlite?mode=ro", uri=True)
for ts, lv, tg, body in c.execute(
    "select ts,level,target,substr(feedback_log_body,1,220) from logs order by id desc limit 12"):
    t = datetime.datetime.fromtimestamp(ts).strftime("%H:%M:%S") if ts else "?"
    print(f"{t} {lv}: {body[:180]}")
EOF
```

健康标志：`list_models ... status=200`、`initialize`/`initialized`、`remoteControl/status/changed`。

坑：`where level='ERROR'` 可能返回 0 行，不代表没跑过——先无条件取最新 12 行看时间戳新鲜度，比按 level 过滤可靠。

## 三、升级（顺序不能颠倒）

**CLI 与 daemon 是两个独立二进制**，`npm install -g` 只升 CLI。

| 角色 | 路径 | 升级方式 |
|---|---|---|
| 全局 CLI | `/usr/local/bin/codex` | `npm install -g @openai/codex@<ver>` |
| 受管 daemon | `~/.codex/packages/app-server-daemon/current/bin/codex` | `daemon update --from-cli --yes` |

```bash
# 0. 备份（config/auth 同机备份，600，不读内容）
TS=$(date -u +%Y%m%dT%H%M%SZ); BK=/root/backups/codex-upgrade-$TS
mkdir -p $BK && chmod 700 $BK
cp -a /root/.codex/config.toml /root/.codex/auth.json $BK/ && chmod 600 $BK/auth.json
{ codex --version; npm ls -g --depth=0 | grep codex; node -v; npm -v; } > $BK/baseline.txt

# 1. 查目标版本与 engines（别盲装 alpha）
npm view @openai/codex version
npm view @openai/codex@<ver> engines --json
npm install -g @openai/codex@<ver> && codex --version

# 2. 停掉手工起的旧 daemon（daemon stop 会拒绝，见坑 1）
kill -TERM <pid>; sleep 5; kill -0 <pid> 2>/dev/null && kill -KILL <pid>

# 3. 建立持久化管理（SSH-driven 场景专用）
codex app-server daemon bootstrap

# 4. 把新 CLI 复制成 daemon 包
codex app-server daemon update --from-cli --yes
```

### 坑 1：`not managed by codex app-server daemon`

`daemon stop` / `daemon update` 报这个错，是因为当前进程是手工从 SSH 会话起的、不在 daemon 台账里。
**先 `bootstrap` 接管，再 update**。不要用 `pkill` 绕过。

### 坑 2：`update --from-cli` 少了 `--yes` 等于没做

不带 `--yes` 只打印确认提示然后报 `daemon installation requires confirmation`，**退出码仍是 0**——`EXIT=$?` 会骗人。必须显式 `--yes`，并回读 `daemon version` 确认。

### 坑 3：`--from-cli` 会把版本钉住

输出会写明 "The selected package will be pinned"。以后不再自动跟 production。
恢复跟随：`codex app-server daemon update`（不带 `--from-cli`）。**交付时必须告知用户这一点**。

### 坑 4：先查 engines 再决定要不要动 node

老机器常见 node 18 + npm 9，多数版本 `engines: node >=16` 就够，别想当然升 node。

## 四、验收（四步，缺一不可）

```bash
codex app-server daemon version          # 三个版本字段全部等于新版本
ps -o pid,ppid,etime,cmd -p <newpid>     # PPID=1，cmd 含 --managed-daemon
grep -E '^model' /root/.codex/config.toml
python3 -c "import json;d=json.load(open('/root/.codex/models_cache.json'));print([m.get('id') for m in (d if isinstance(d,list) else d.get('models',[]))][:12])"
codex exec --skip-git-repo-check -c model_reasoning_effort=low "只回复两个字：升级成功"
```

- **配置里的 model id 必须仍在新版 `models_cache.json` 里**，否则升级后一跑就报模型不可用。
- `codex exec` 必须看到模型真实回复 + exit 0。

## 五、回滚

```bash
npm install -g @openai/codex@<旧版本>
cp -a /root/backups/codex-upgrade-<ts>/config.toml /root/.codex/config.toml
codex app-server daemon update --from-cli --yes
codex app-server daemon version
```

`auth.json` 备份只在 OAuth 失效时恢复；平时别覆盖（可能已刷新出新 token）。

## 六、汇报口径

- 分清「升级解决了什么」：版本落后 + 手工进程悬空 ≠「服务器踢人」。
- 若客户端根本没再发起连接，取证归 `ssh-login-troubleshooting` 铁律五，不要在本技能里重复归因。
- **升级成功 ≠ 客户端能连**。用户升级后回「还是连不上」时，第一件事是查服务端日志里**有没有该客户端的连接记录**，而不是继续升版本或回滚：有记录 = 继续查这一层；零记录 = 问题在客户端侧，升级本来就治不了。**别急着写"客户端出网断了"**——实测最终根因是 VPN 按 App 分流：浏览器出网完全正常，只有 App 的流量走直连、海外非标端口被墙。先做浏览器探针 + 同 App 连国内对照，见 `ssh-login-troubleshooting` 的「VPN 按 App 分流」一节。（实测：升级后客户端确实连上并跑通 `initialize`，31 秒后被代理 RST，与升级无关）。**没证据前不回滚刚做完的升级**——那只会再加一个变量。
- **「零记录」不等于「包没到」**。要让用户用手机浏览器打开 `http://<IP>:<SSH端口>`：sshd 出现 `banner exchange: Connection from <客户端IP>: invalid format` 就证明端口一直可达、是 App 自己不发包（实测三台"全零"的手机，一探针就露出四个 banner exchange 记录，结论从"出网断了"翻成"App 未发起连接"）。完整判读见 `ssh-login-troubleshooting` 的「决定性判别」一节。
- 交付时给三件事：版本前后对照表、真实执行的验收输出、回滚路径与 pin 状态。

## 七、把手机客户端配对到服务器上的 agent（OpenCode v2）

Codex 走 `app-server daemon`，OpenCode 走 **v2 的 `pair --remote`**——两套机制不要混。要点（完整流程见 references）：

- **v1 与 v2 并存**：npm 装的 v1（`opencode`，1.19.x）没有 `pair` 子命令；手机 App 只认 v2。v2 用 `curl -fsSL https://opencode.ai/v2/install | bash` 装到 `~/.opencode/bin/opencode2`，不覆盖 v1。
- **`pair` 打印完链接就 exit 0，这是正常的**。真正常驻的是子进程 `opencode serve --service`（`127.0.0.1:<随机端口>`）。别因为前台进程退出就 kill 会话或判定服务死了——先 `ps aux | grep 'opencode serve'`。
- **交付前验隧道**：`curl -o /dev/null -w '%{http_code}' https://<hash>.<tunnel>.opentunnel.xyz/` 要 200。
- **链接一次性、5 分钟过期**，等于服务器访问权：只给所有者本人，不进群、不落日志、不写文件。
- 工作目录在 pair 时固定，换项目要重跑。

## References

- `references/codex-app-server-upgrade-20261105.md` — 洛杉矶 RackNerd 实测全过程：分层证据、session scope 悬空判定、四坑原文报错、0.157.0-alpha.10 → 0.166.0 的完整命令与验收输出。
- `references/opencode-v2-pairing-20261108.md` — OpenCode v1/v2 双线对照、`pair --remote` 手机配对实测（pair 退出但 serve 常驻、隧道 200 验证、5 分钟一次性链接）、Console 认证方式核实（无手机短信登录）。
