#!/usr/bin/env python3
"""日志脱敏自验证。退出码 0 = 全部通过，1 = 有失败项。

用法：
    python3 verify_redaction.py            # 默认导入同目录的 log_safety.py
    python3 verify_redaction.py path/to/log_safety.py

覆盖四件事：
  1. 子 logger 的 record 被处理（最容易骗过自己的地方）
  2. 六类凭据各自命中
  3. 正常文本不被误伤
  4. traceback 里的凭据也被处理
"""

from __future__ import annotations

import importlib.util
import io
import logging
import pathlib
import sys

FAILS: list[str] = []


def load_module(path: str):
    spec = importlib.util.spec_from_file_location("log_safety_under_test", path)
    mod = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(mod)  # type: ignore[union-attr]
    return mod


def check(name: str, cond: bool, detail: str = "") -> None:
    if cond:
        print(f"  PASS  {name}")
    else:
        print(f"  FAIL  {name}  {detail}")
        FAILS.append(name)


def main() -> int:
    target = sys.argv[1] if len(sys.argv) > 1 else str(
        pathlib.Path(__file__).with_name("log_safety.py"))
    if not pathlib.Path(target).exists():
        print(f"找不到被测模块: {target}")
        return 1

    mod = load_module(target)

    buf = io.StringIO()
    handler = logging.StreamHandler(buf)
    handler.setFormatter(logging.Formatter("%(message)s"))
    root = logging.getLogger()
    old_handlers = root.handlers[:]
    root.handlers.clear()
    root.addHandler(handler)
    root.setLevel(logging.INFO)

    try:
        mod.install_log_sanitizer()

        # 1) 子 logger —— 关键：必须用深层子 logger，不能用 root
        log = logging.getLogger("a.b.c")
        log.info("token=%s", "<YOUR_TELEGRAM_TOKEN>")
        out = buf.getvalue()
        check("子 logger 的 TG token 被脱敏", "<TG_TOKEN>" in out and "AAHfake" not in out, out[:120])

        # 2) 六类
        cases = [
            ("openai key", "key <YOUR_API_KEY>", "<API_KEY>"),
            ("github token", "gh <YOUR_GITHUB_TOKEN>", "<GH_TOKEN>"),
            ("aws key", "aws <YOUR_AWS_ACCESS_KEY>", "<AWS_KEY>"),
            ("bearer", "hdr Bearer abcdef1234567890xyz", "Bearer <REDACTED>"),
            ("url cred", "u https://<USER>:<PASSWORD>@example.com/p", "<CRED>@"),
            ("url query", "q /x?token=secret123&ok=1", "token=<REDACTED>"),
        ]
        for name, payload, expect in cases:
            buf.truncate(0); buf.seek(0)
            log.info("%s", payload)
            got = buf.getvalue()
            check(f"{name} 被脱敏", expect in got, got.strip()[:120])

        # 3) 不误伤
        buf.truncate(0); buf.seek(0)
        log.info("normal line chat=%s ok=1 path=/tmp/x", 00)
        got = buf.getvalue()
        check("正常文本未被误伤", "00" in got and "/tmp/x" in got, got.strip()[:120])

        # 4) traceback
        buf.truncate(0); buf.seek(0)
        try:
            raise RuntimeError("boom <YOUR_TELEGRAM_TOKEN>")
        except RuntimeError:
            log.exception("caught")
        got = buf.getvalue()
        has_fmt = any(isinstance(h.formatter, mod.SanitizingFormatter) for h in [handler])
        if has_fmt:
            check("traceback 里的 token 被脱敏", "AAHfake" not in got, got[-200:])
        else:
            print("  SKIP  traceback 检查（formatter 未升级，属已知边界）")

        # 5) 日志没被吞
        buf.truncate(0); buf.seek(0)
        for i in range(5):
            log.info("line %d", i)
        check("日志未被丢弃", buf.getvalue().count("line") == 5, buf.getvalue()[:120])

    finally:
        root.handlers.clear()
        root.handlers.extend(old_handlers)

    print()
    if FAILS:
        print(f"失败 {len(FAILS)} 项: {', '.join(FAILS)}")
        return 1
    print("全部通过")
    return 0


if __name__ == "__main__":
    sys.exit(main())
