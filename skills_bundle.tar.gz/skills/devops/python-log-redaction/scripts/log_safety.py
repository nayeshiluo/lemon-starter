"""日志脱敏模块（可直接拷进项目）。

两层防护：
  1. SanitizingFilter  —— 挂在 handler 上，处理 record.getMessage()
  2. SanitizingFormatter —— 处理 traceback（filter 阶段 exc_text 还是 None，管不到）

用法：
    import logging
    logging.basicConfig(...)          # 先有 handler
    from log_safety import install_log_sanitizer
    install_log_sanitizer()           # 再挂脱敏（顺序不能反）

原则：脱敏失败绝不放行原始记录之外的任何副作用，filter 永远 return True。
"""

from __future__ import annotations

import logging
import re

# 顺序有讲究：先打码具体令牌，再处理 URL 内嵌凭据，最后清控制字符
_PATTERNS: tuple[tuple[re.Pattern[str], str], ...] = (
    (re.compile(r"(?<![\w-])(?:bot)?\d{6,14}:[A-Za-z0-9_-]{20,}"), "<TG_TOKEN>"),
    (re.compile(r"\bsk-[A-Za-z0-9_-]{12,}\b"), "<API_KEY>"),
    (re.compile(r"\b(?:ghp_|gho_|ghu_|ghs_|ghr_|github_pat_)[A-Za-z0-9_]{16,}"), "<GH_TOKEN>"),
    (re.compile(r"\bAKIA[0-9A-Z]{16}\b"), "<AWS_KEY>"),
    (re.compile(r"(?i)\b(Bearer|Basic)\s+[A-Za-z0-9._~+/=-]{8,}"), r"\1 <REDACTED>"),
    (re.compile(r"(?i)(https?://)[^/\s:@]+:[^/\s@]+@"), r"\1<CRED>@"),
    (re.compile(r"(?i)([?&](?:key|token|api_key|access_token|sig|auth|secret)=)[^\s&#]+"), r"\1<REDACTED>"),
    # 零宽 / 双向控制符 / 行分隔符 —— 防日志注入与伪造
    (re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f-\x9f\u2028\u2029\u202a-\u202e\u2066-\u2069]"), ""),
)

_MAX_LEN = 4000


def sanitize(text: object) -> str:
    try:
        out = str(text)
    except Exception:
        return "<unprintable>"
    for pattern, repl in _PATTERNS:
        try:
            out = pattern.sub(repl, out)
        except Exception:
            continue
    if len(out) > _MAX_LEN:
        out = out[:_MAX_LEN] + f"...[truncated {len(out) - _MAX_LEN}]"
    return out


class SanitizingFilter(logging.Filter):
    """挂在 handler 上。挂 logger 上对子 logger 无效。"""

    def filter(self, record: logging.LogRecord) -> bool:
        try:
            try:
                rendered = record.getMessage()
            except Exception:
                rendered = str(record.msg)
            record.msg = sanitize(rendered)
            record.args = ()          # 必须清空，否则 formatter 二次套用会炸
        except Exception:
            pass
        return True                   # 永不丢弃


class SanitizingFormatter(logging.Formatter):
    """处理 traceback。filter 阶段 exc_text 还是 None，只能在这里兜。"""

    def formatException(self, ei) -> str:
        try:
            return sanitize(super().formatException(ei))
        except Exception:
            return "<traceback unavailable>"

    def formatStack(self, stack_info: str) -> str:
        return sanitize(stack_info)


def install_log_sanitizer(upgrade_formatters: bool = True) -> None:
    """挂在 root 的 handler 上，并把 formatter 换成脱敏版。

    必须在 logging.basicConfig(...) / handler 配置之后调用。
    重复调用安全。
    """
    handlers = list(logging.root.handlers)
    for h in handlers:
        try:
            if not any(isinstance(f, SanitizingFilter) for f in h.filters):
                h.addFilter(SanitizingFilter())
            if upgrade_formatters:
                fmt = getattr(h, "formatter", None)
                if fmt is not None and not isinstance(fmt, SanitizingFormatter):
                    new_fmt = SanitizingFormatter(fmt._fmt or "%(message)s", fmt.datefmt)
                    h.setFormatter(new_fmt)
        except Exception:
            continue
    for name in ("", "telegram", "httpx", "httpcore", "aiohttp"):
        lg = logging.getLogger(name)
        if not any(isinstance(f, SanitizingFilter) for f in lg.filters):
            lg.addFilter(SanitizingFilter())


if __name__ == "__main__":
    logging.basicConfig(format="%(levelname)s %(name)s: %(message)s", level=logging.INFO)
    install_log_sanitizer()
    log = logging.getLogger("demo.child")
    log.info("token=%s", "<YOUR_TELEGRAM_TOKEN>")
    log.info("openai key <YOUR_API_KEY>")
    log.info("url https://<USER>:<PASSWORD>@example.com/x?token=secret123&ok=1")
    try:
        raise RuntimeError("leaked <YOUR_TELEGRAM_TOKEN> inside traceback")
    except RuntimeError:
        log.exception("boom")
