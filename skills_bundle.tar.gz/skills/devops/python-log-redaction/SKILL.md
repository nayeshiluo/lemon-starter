---
name: python-log-redaction
description: "Use when 给 Python 服务加日志脱敏，确保凭据不落日志。"
version: 1.0.0
author: 柠檬
license: MIT
platforms: [linux, macos]
metadata:
  hermes:
    tags: [logging, redaction, security, python, credentials, filters]
    related_skills: [host-operations-evidence, journald-log-flood-triage, selfhosted-service-audit]
---

# Python 服务日志脱敏

给已有服务加日志脱敏，保证 token / 密码 / 密钥不进日志文件。核心难点不在正则，
而在**挂载位置**——挂错地方会静默失效，测试还容易骗过自己。

## When to Use

- 服务日志里可能出现 bot token、API key、带凭据的 URL
- 要给现成 Bot / 服务加脱敏，不想动业务代码
- 日志脱敏加了但「感觉没生效」
- 多实例服务（同一份代码、不同 env）需要统一脱敏

**先判断值不值得做**：服务用 `print` 且没有 `logging.basicConfig` 时，加脱敏需要改输出格式，
会影响现有 journalctl 观测习惯 —— 收益不抵风险，明确不做并说明理由，别硬加。

## 铁律：filter 必须挂在 handler 上

**Python logging 的 `logger.filter()` 只对该 logger 自己产生的 record 生效。**
子 logger 的 record 传到 root 时，**不会经过 root logger 的 filters**。

```python
# ❌ 错误：对 logging.getLogger("services.foo") 完全无效
logging.getLogger("").addFilter(SanitizingFilter())

# ✅ 正确：挂在 handler 上，所有经过该 handler 的 record 都过一遍
for h in logging.root.handlers:
    h.addFilter(SanitizingFilter())
```

实测：先用 logger 级挂法，`logging.getLogger("selftest")` 打的 token 原样输出；
换成 handler 级后立刻变成 `<TG_TOKEN>`。

**顺序也很重要**：`basicConfig()` 之前 root 没有 handler，挂上去等于挂空。
必须在 `basicConfig()` / handler 配置**之后**调用 install。

## 实现要点（五个都不能少）

### 1. 先格式化再脱敏，并清空 args

```python
def filter(self, record):
    rendered = record.getMessage()      # 先把 %-args 套进去
    record.msg = sanitize(rendered)     # 再脱敏
    record.args = ()                    # 必须清空，否则 formatter 会二次套用
    return True
```

只改 `record.msg` 不清 `args`，`log.info("token=%s", tok)` 这类调用脱敏后格式化会出错。

### 2. 正则要锚定完整凭据格式，别用「前缀 + 任意字符」

```python
# ❌ 反面教材：会把同前缀的正常内容全吃掉
re.compile(r"471e[0-9A-Za-z_-]{20,}")
# ✅
re.compile(r"(?<![\w-])(?:bot)?\d{6,14}:[A-Za-z0-9_-]{20,}")
```

实测事故：把 Cloudflare Account ID 的片段当前缀做正则，一次误伤 19 个正常文件。

### 3. 覆盖六类，不止 token

| 类别 | 正则要点 |
|---|---|
| Telegram bot token | `\d{6,14}:[A-Za-z0-9_-]{20,}` |
| OpenAI / 中转站 | `sk-[A-Za-z0-9_-]{12,}` |
| GitHub | `ghp_ / gho_ / ghu_ / ghs_ / ghr_ / github_pat_` |
| AWS | `AKIA[0-9A-Z]{16}` |
| Authorization 头 | `(Bearer\|Basic)\s+[A-Za-z0-9._~+/=-]{8,}` |
| URL 内嵌凭据 | `https?://[^/\s:@]+:[^/\s@]+@` 与 `[?&](key\|token\|sig\|auth\|secret)=` |
| **控制字符** | `[\x00-\x08\x0b\x0c\x0e-\x1f\x7f-\x9f\u2028\u2029\u202a-\u202e\u2066-\u2069]` |

最后一类是**日志注入防护**：零宽字符和双向控制符能伪造日志行，必须清掉。

### 4. 绝不吞日志

```python
try:
    ...
except Exception:
    pass
return True          # 永远放行，脱敏失败也要让日志出去
```

脱敏是安全增强，不是访问控制。为了脱敏丢日志会让排障更糟。

### 5. traceback 是独立通路，msg 脱敏管不到

`record.exc_text` 由 **formatter** 在 `format()` 时生成，filter 阶段它还是 `None`。
所以 `log.exception(...)` 里的异常信息**不会被 msg 脱敏覆盖**。

正确做法是自定义 Formatter：

```python
class SanitizingFormatter(logging.Formatter):
    def formatException(self, ei):
        return sanitize(super().formatException(ei))
```

只做 filter 不做 formatter，是**部分脱敏**——必须在报告里说清楚这个边界。

## 验收（三项，缺一不可）

```bash
python3 scripts/verify_redaction.py        # 退出码 0 = 全通过
```

1. **子 logger 的 record 被处理** —— 这是最容易骗过自己的地方。
   用 `logging.getLogger("a.b.c")` 打日志，验证被脱敏；用 root logger 打不算验证。
2. **六类样本各自命中**，且正常文本不被误伤（`Bearer` 后面接的非密钥内容、
   URL 里的普通 query 参数）。
3. **日志量没减少** —— 对比接入前后同一时间窗的日志行数，掉一半就是被吞了。

## 接入步骤（不改业务代码）

```python
# 在入口的 logging 初始化之后
logging.basicConfig(...)          # 已有的配置，不动
try:
    from services.log_safety import install_log_sanitizer
    install_log_sanitizer()
except Exception:
    pass                          # 脱敏不可用不能阻止服务启动
```

多实例服务（同一目录、不同 env）改一份代码即可，重启各实例都生效。

## 已知边界

| 边界 | 说明 |
|---|---|
| traceback | 只上 filter 时未覆盖，需配合 SanitizingFormatter |
| print 输出 | 完全管不到，只对 logging 生效 |
| 日志文件权限 | 脱敏不替代 `chmod 600`，两者都要 |
| 已落盘的历史日志 | 不会追溯清理，需要单独处理 |
| 结构化日志（JSON handler） | 需在序列化前处理，filter 时机可能不对 |

## 支持文件

- `scripts/log_safety.py` — 可直接拷进项目的模块（含 filter + formatter 两层）
- `scripts/verify_redaction.py` — 自验证脚本，退出码 0/1

实测落地：群霸双实例（`lemon-group-bot` / `lemon-group-bot2`）接入后重启，
4 分钟输出 38 行日志未被吞、明文 token 形态 0 条、格式未变。
