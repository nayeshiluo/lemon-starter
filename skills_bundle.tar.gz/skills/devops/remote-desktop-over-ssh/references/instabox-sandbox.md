# InstaBox 沙箱（instabox.sh）实测笔记

2026-10 实测一台名为 `代理浏览器-xoel` 的 InstaBox 机器（免费方案）。

## 登录

- 面板 “SSH config” 里：`HostName ssh.instabox.sh`，`Port 2222`，`User ibssh_xxxxxxxxxxxx`。
- **token 就是用户名**，没有密码也没有 SSH key；面板明确写 “The token is the user name: no password or SSH key”。
- 原文命令：`ssh -p 2222 user@example.com`；另有 Mosh：`mosh --ssh="ssh -p 2222" user@example.com`。
- 本机第一次连会提示未知主机，`StrictHostKeyChecking=accept-new` 即可。

## 机器内部布局

| 项 | 值 |
|---|---|
| 系统 | Debian 13 (trixie)，内核 `*-instabox` |
| 默认规格（免费） | 4 vCPU / 8 GiB，约 7.8 GiB 可用 |
| 用户 | `user`，在 `sudo` 与 `docker` 组 |
| 桌面 | XFCE，`Xvnc :1 -geometry 800x600 -rfbport 5901 -localhost -SecurityTypes None -AlwaysShared` |
| 工作目录 | `/data/workspace`（`AGENTS.md` 指定） |
| 自带工具 | git、gh、curl、jq、node、npm、python3、uv、go、cargo、docker(+compose)、claude、codex、chromium、Xvfb、xdotool、scrot、xrandr、thunar |
| 缺 | playwright CLI、x11vnc、ffmpeg、ImageMagick、tmux |

`~/MACHINE.md` 与 `~/AGENTS.md` 是权威说明文件，包含机器 ID、CLI 用法（`instabox ssh` / `exec` / `files`）、端口发布（`instabox-port publish 3000`）以及“Playwright/Puppeteer 从新 shell 启动的浏览器会 headed 显示在 `DISPLAY=:1`”这条关键约定。

## 操控要点

1. `xrandr` 初值可能是 `367x515`（面板缩放导致），用 `DISPLAY=:1 xrandr -s 1280x800` 拉到正常尺寸再截图。
2. 截图：`DISPLAY=:1 scrot -o /tmp/ib.png`，再 `scp -P 2222` 拉回本机。
3. 输入：`xdotool search --onlyvisible --class Chromium` 拿窗口 id → `windowactivate --sync` → `key ctrl+l` → `type` → `key Return`。
4. 自证：`xdotool getwindowname $w` 从 `about:blank - Chromium` 变成 `Example Domain - Chromium`，说明键盘输入真实生效。
5. Chromium 启动需 `--no-sandbox --user-data-dir=/tmp/cprof1 --no-first-run`（容器内 root/sandbox 限制）。

## 生命周期

- 免费方案：永不计费，但**闲置 30 分钟或运行 8 小时后自动暂停**；暂停后 SSH 不可达，需要用户在面板点启动。
- 机器面板有 1/5 台额度（免费工作区上限），有 Auto-pause / Max runtime 字段。
- 暂停/快照会保留 home 与 `/data`，临时进程（含我起的 Chromium）不保留。

## 注意

- token 属凭据：只从用户材料读取，不写进技能、记忆或日志。
- 本机 `computer_use` 无法驱动它的桌面；只能 SSH + xdotool/scrot。
- 若要实时看画面：`ssh -N -L 5901:127.0.0.1:5901 -p 2222 user@host` 后本地 VNC 连 `localhost:5901`（需用户同意再建隧道）。
