---
name: remote-desktop-over-ssh
description: "操控远端VM桌面：SSH+xdotool截图点击，非本机cua。"
version: 1.0.1
author: 柠檬 (Hermes Agent)
license: MIT
metadata:
  hermes:
    tags: [ssh, remote-desktop, vnc, xvfb, xdotool, cloud-sandbox, gui-automation]
    category: devops
    related_skills: [computer-use, aws-ec2-ops]
---

# 通过 SSH 操控远端图形桌面

触发场景：用户丢来一台云沙箱/远端 VM 的登录信息（InstaBox、Gitpod 类、带 Xvnc/Xvfb 的 VPS），问“这个你能连接操控吗”“帮我在这台机器上开浏览器/点一下/截图”。

核心事实：**本机 `computer_use` / cua-driver 只能驱动本机桌面，不能驱动远端显示。** 远端 GUI 要靠 SSH + 远端 X 工具（`xdotool` 输入、`scrot` 截图、`xrandr` 改分辨率）。所以要先讲清“能做到什么”，再用真实动作证明，而不是口头承诺。

## When to Use

- 用户给出远端机器 SSH 信息并问“能连吗/能操控吗/帮我点一下/截个图”。
- 需要在云沙箱或 VPS 的虚拟桌面里跑浏览器、点 UI、看画面。
- 需要判断某台机器到底有没有可用图形环境（Xvnc / Xvfb / VNC 端口）。
- 不适用：纯命令行任务（直接 SSH 跑命令即可）；本机桌面操控（用 `computer-use` 技能）。

## 1. 先连上（只读验证）

```bash
ssh -p <port> -o BatchMode=yes -o StrictHostKeyChecking=accept-new \
    -o ConnectTimeout=15 <user>@<host> \
    'id; uname -a; nproc; free -m | head -2'
```

- 很多沙箱（如 InstaBox）把 **token 当 SSH 用户名，无密码无密钥**：面板/PDF 里那串 `ibssh_...` 就是 user。凭据只从用户提供的材料取，**不要写进技能文件或记忆**。
- `-o BatchMode=yes` 必须带：避免卡在密码提示上耗死 timeout。
- 未知主机第一次连会写 known_hosts，这是正常且可接受的只读副作用。

## 2. 摸清桌面环境（一次批量只读）

```bash
ssh ... 'echo "== TOOLS =="; for c in xdotool scrot xrandr wmctrl ffmpeg convert Xvfb x11vnc vncviewer tmux; do
  printf "%s: " $c; command -v $c || echo -; done
echo "== LISTEN =="; ss -ltnp 2>/dev/null | head -20
echo "== XPROC =="; ps aux | grep -Ei "xvfb|vnc|chrome|novnc|x11" | grep -v grep
echo "== DOCS =="; cat ~/MACHINE.md ~/AGENTS.md 2>/dev/null | head -60'
```

判断要点：

| 现象 | 含义 |
|---|---|
| `Xvnc :1 -rfbport 5901 -localhost` | 有可用的虚拟桌面，`DISPLAY=:1`，VNC 只绑本地 |
| `Xvfb` 在跑但无 VNC | 有显示无画面输出，只能靠 `scrot` 截图看 |
| 有 `chromium`/`xdotool`/`scrot` | 可直接做 GUI 操控 |
| 无 `xdotool` | 先 `sudo apt-get install -y xdotool`（用户授权后），或退回“仅命令行” |

云沙箱一般会自带 `~/MACHINE.md`、`~/AGENTS.md`：里面写了机器 ID、可用工具、工作目录（常见 `/data/workspace`）、以及浏览器 headed 显示在 `DISPLAY=:1` 的约定。**先读它们，比猜快十倍。**

## 3. 截图（最便宜的“我看到了”）

```bash
ssh ... 'DISPLAY=:1 xrandr | head -3; DISPLAY=:1 scrot -o /tmp/ib.png && ls -l /tmp/ib.png'
scp -P <port> <user>@<host>:/tmp/ib.png /tmp/remote-screen.png
```

- 分辨率异常（如 367x515）时：`DISPLAY=:1 xrandr -s 1280x800`，再截一次。
- 回传给用户用 Markdown 本地绝对路径，例如 `![远端桌面](/tmp/remote-screen.png)`。

## 4. 真实操控 + 用“标题变化”自证

不要只说“已启动”，要让状态可核对：

```bash
ssh ... 'export DISPLAY=:1
nohup chromium --no-sandbox --user-data-dir=/tmp/cprof1 --no-first-run about:blank >/tmp/ch.log 2>&1 &
sleep 8
w=$(xdotool search --onlyvisible --class Chromium | head -1)
xdotool windowactivate --sync $w
xdotool key --window $w ctrl+l; sleep 1
xdotool type --window $w --delay 40 "https://example.com"; sleep 1
xdotool key --window $w Return; sleep 6
echo "标题: $(xdotool getwindowname $w)"'
```

`标题: Example Domain - Chromium` 就是“键盘输入真的生效了”的硬证据——比截图更可靠（尤其在本机视觉模型不可用时）。

其他常用：
- 列窗口：`xdotool search --onlyvisible --name "" getwindowname %@`
- 点击：`xdotool mousemove X Y click 1`
- 纯 Xvfb 场景：浏览器加 `--headless=new` 就没画面，需要画面时用 `xvfb-run` 或直接装 Xvnc。

## 5. 想在本机看实时画面

`ssh -N -L 5901:127.0.0.1:5901 -p <port> <user>@<host>`，再本地 VNC 客户端连 `localhost:5901`。远端 `-SecurityTypes None -localhost` 时无需密码；这属于网络变更，先跟用户确认再建隧道。

## 坑

- **不要拿本机 `computer_use` 去点远端窗口**：它读的是本机 AX/截图，远端窗口在本机根本不存在。
- **清理要单独一次调用**：`pkill` 和“写 `~/.ssh/config` 别名”这类修改不要和执行中的只读检查塞进同一条命令。批量命令里一旦包含破坏性操作，整条会被确认机制拦下（表现为 “BLOCKED: Command timed out without user response”），结果是你既没清理干净、也没建成别名，还得向用户解释残留状态。做法：只读核查一批 → 修改单独一批 → 每次改完复查。
- 被拦下的命令**不要原样重试**，也不要换个写法绕；改成更小的、明确的单步操作，或直接问用户。
- 免费沙箱常“闲置 30 分钟 / 运行 8 小时自动暂停”，暂停后 SSH 直接不通——先提醒用户，别把它当长期服务部署目标。
- 沙箱常有 `sudo` + `docker` 权限，但仍是他人云资源：不要在里面存生产凭据。
- 视觉模型返回 5xx 时不要断言“图坏了/功能不可用”，截图文件照旧回传给用户即可，同时改用窗口标题/进程列表这类文本证据自证。

## 参考

- `references/instabox-sandbox.md`：InstaBox（instabox.sh）沙箱的具体布局、自带工具与操控要点。
