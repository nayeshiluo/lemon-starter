#!/usr/bin/env python3
"""修复 AstrBot Telegram 适配器「回复 bot 消息无法唤醒」的 bug（幂等）

现象：群里只有 @ 有反应，引用/回复 bot 的消息完全没反应。
根因：message.self_id = str(bot.username)，而 Comp.Reply 的 sender_id 填的是数字 user_id，
      waking_check 里 str(sender_id) == str(get_self_id()) 永远不成立。
      At 能work是因为代码专门把 At.qq 改写成了 self_id，Reply 路径漏了。

用法（在 AstrBot 所在机器上，root）：
    python3 reply-wake-patch.py && systemctl restart astrbot

注意：
- Reply.qq 的类型是 int | None，不含 str。改成字符串会抛 pydantic ValidationError，
  被框架吞掉后表现为「每条回复消息都静默失败」，比不修更糟。只改 sender_id。
- AstrBot 升级（uv tool upgrade / pip install -U）会覆盖此补丁，升级后需重跑。
"""
import glob
import shutil
import sys
import time

CANDIDATES = (
    glob.glob(
        "/root/.local/share/uv/tools/astrbot/lib/python3.*/site-packages"
        "/astrbot/core/platform/sources/telegram/tg_adapter.py"
    )
    + glob.glob(
        "/usr/lib/python3*/site-packages/astrbot/core/platform/sources/telegram/tg_adapter.py"
    )
    + glob.glob(
        "/usr/local/lib/python3*/dist-packages/astrbot/core/platform/sources/telegram/tg_adapter.py"
    )
)

OLD = """                message.message.append(
                    Comp.Reply(
                        id=reply_abm.message_id,
                        chain=reply_chain,
                        sender_id=reply_abm.sender.user_id,
                        sender_nickname=reply_abm.sender.nickname,
                        time=reply_abm.timestamp,
                        message_str=reply_message_str,
                        text=reply_message_str,
                        qq=reply_abm.sender.user_id,
                    ),"""

NEW = """                # 被回复的是机器人自己时，sender_id 必须用 self_id(username)，
                # 否则 waking_check 里 Reply.sender_id == get_self_id() 永远不成立
                _reply_sender_is_bot = bool(
                    update.message.reply_to_message.from_user
                    and update.message.reply_to_message.from_user.id == context.bot.id
                )
                _reply_sender_id = (
                    str(context.bot.username)
                    if _reply_sender_is_bot
                    else reply_abm.sender.user_id
                )
                message.message.append(
                    Comp.Reply(
                        id=reply_abm.message_id,
                        chain=reply_chain,
                        sender_id=_reply_sender_id,
                        sender_nickname=reply_abm.sender.nickname,
                        time=reply_abm.timestamp,
                        message_str=reply_message_str,
                        text=reply_message_str,
                        qq=reply_abm.sender.user_id,
                    ),"""


def main() -> int:
    if not CANDIDATES:
        print("错误：找不到 tg_adapter.py，请确认 AstrBot 安装路径", file=sys.stderr)
        return 1
    path = CANDIDATES[0]
    src = open(path, encoding="utf-8").read()

    if "_reply_sender_is_bot" in src:
        print("已修过，无需重复处理:", path)
        return 0

    if OLD not in src:
        print("错误：锚点未匹配，版本可能已变化，请人工核对 convert_message 里的 Comp.Reply 构造", file=sys.stderr)
        return 1

    bak = f"{path}.bak-replyfix-{time.strftime('%Y%m%d%H%M%S')}"
    shutil.copy2(path, bak)
    print("备份:", bak)

    src = src.replace(OLD, NEW, 1)
    # 落盘前必须校验，否则重启即崩
    compile(src, path, "exec")
    open(path, "w", encoding="utf-8").write(src)
    print("已修复，语法校验通过。请执行: systemctl restart astrbot")
    print("重启后务必 grep Traceback / ValidationError，并做一次真实回复测试。")
    return 0


if __name__ == "__main__":
    sys.exit(main())
