---
name: im-bot-wake-troubleshooting
description: IM 机器人不理人/只有@有反应/回复触发失效的排障：唤醒条件、静默异常、端到端验证。
version: 1.0.0
author: 柠檬
license: MIT
metadata:
  hermes:
    tags: [telegram, bot, wake, troubleshooting, astrbot, pydantic, silent-failure]
    related_skills: [telegram-group-assistant, telegram-group-bot-suite, astrbot-deploy-ops]
---

# IM 机器人唤醒与触发排障

## When to Use

- 用户说「只有 @ 才有反应」「回复它没反应」「发前缀没反应」
- 群里 bot 不理人，需要区分：权限拦截 / 未唤醒 / 语音听不懂 / 限流 / 异常被吞
- 改了 bot 源码后「服务 active 但完全没反应」
- 需要证明 bot 到底有没有真的调用模型并发出消息（而不是靠猜）

## 1. 先分清五类「不回」

别急着改代码，先归类。每一类的日志特征完全不同：

| 类别 | 日志特征 | 处置 |
|---|---|---|
| 未唤醒 | 消息进了 pipeline（有 preprocess 日志），但**没有 respond.stage** | 见 §2 唤醒条件 |
| 权限/白名单 | `is not in the session allowlist` | 群 ID 加白名单 |
| 语音无 STT | `has no speech-to-text provider configured` | 配 STT，或确认用户发的是文字 |
| 限流 | rate_limit stall | 调 `platform_settings.rate_limit` |
| **异常被吞** | `No error handlers are registered, logging exception` + Traceback | 见 §4，最坑 |

判定「未唤醒」的硬证据是：**同一条消息有 preprocess 日志、没有 respond 日志**。有 respond 就是已经发出去了，问题在用户端或内容为空。

## 2. 唤醒条件模型（AstrBot 为参照，其它框架同构）

群聊里 bot 不是「看到消息就回」。`core/pipeline/waking_check/stage.py` 的判定：

1. 被 `@`（At 组件 `qq == self_id`）
2. 引用/回复 bot 自己的消息（Reply 组件 `sender_id == self_id`）
3. 消息以 `wake_prefix` 开头 —— **斜杠是前缀的一部分**。配 `/大肥鱼` 就只认 `/大肥鱼 xxx`，发 `大肥鱼 xxx` 不触发
4. `@全体成员`（`ignore_at_all=false` 时）
5. 私聊默认直接唤醒（`friend_message_needs_wake_prefix=false`）
6. 插件的 handler filter（指令本身）

**没有「群里全量响应」开关。** `wake_prefix` 设成空列表只会退化成「仅 @ 和回复」，不会变成每句都回。想让群友免 @ 只能加无斜杠前缀，但那会让闲聊里提到 bot 名字也触发——**先问用户，别默认这么干**。

## 3. 权限/白名单怎么判（AstrBot）

- `platform_settings.id_whitelist` 放**群 ID** 即放行整个群：判断是 `umo not in whitelist and str(get_group_id()) not in whitelist`，命中群 ID 就通过，**与发言人是谁无关**。
- `admins_id` 是按 **sender_id** 逐个比对（`str(event.get_sender_id()) == admin_id`）。把群 ID 塞进 `admins_id` **完全无效**——既不会让群友变管理员，也不给任何权限。想放行群用白名单，别碰 admins_id。

## 4. 改组件/消息模型前的硬规矩

**改字段前先读类型声明**，尤其是 pydantic 模型：

```bash
grep -n "class Reply" -A 20 core/message/components.py   # 看每个字段的 Union
```

本次真实翻车：`Reply.sender_id` 是 `int | None | str`（能放字符串），但 `Reply.qq` 是 `int | None`（**不含 str**）。顺手把 `qq` 也改成 username 字符串 → 每条消息抛 `ValidationError: qq value is not a valid integer` → 被框架的通用异常处理器吞掉 → **用户端表现为「完全没反应」，而服务状态一切正常**。比不修还糟。

**改完先用真实对象验证，别让用户当测试机**：

```bash
/root/.local/share/uv/tools/astrbot/bin/python -c "
from astrbot.core.message.components import Reply
r = Reply(id=1, chain=[], sender_id='bot_username', qq=<YOUR_USER_IDENTIFIER>)
print('OK', r.sender_id, type(r.qq).__name__)"
```

再 `compile()` 校验 → 落盘 → 重启 → 查 traceback。

## 5. 日志相关性的陷阱

`core.event_bus` 打印格式是 `昵称/用户ID`，**不含群 ID**。只看这一行分不清私聊还是群聊，容易误判「用户没在群里测」。

正确做法：拿 `event_bus` 的时间戳去对齐带会话的日志行（`preprocess_stage` 的警告行会带 `Session <平台>:GroupMessage:-100...`），毫秒级相邻（几十 ms）就是同一条消息。

另外 `has no speech-to-text provider configured` 对**纯文本群消息也会报**，是噪音，不代表消息是语音。真语音看插件日志里的 `未从消息中提取到音频`。

## 6. 端到端验证（别信 is-active）

**`systemctl is-active` = active 不等于功能正常。** 本次踩过：服务 active、端口在听、adapter running，但每条消息都静默抛异常。

验收四件套：

1. `journalctl | grep -cE "Traceback|ValidationError"` 归零（计数，不是 tail）
2. 消息落库：`platform_message_history` 按 `user_id = 群ID` 查，带 `message_id`
3. 回复链路：`respond.stage Prepare to send` + 平台发送日志同时出现
4. **真实模型调用**：AstrBot 查 `provider_stats` 表，能证明 LLM 真被调用

```sql
SELECT created_at, umo, provider_model, status, token_output, time_to_first_token
FROM provider_stats ORDER BY created_at DESC LIMIT 5;
```

`status=completed` + `token_output > 0` 才是「真的回了」。这条比任何日志都硬。

## 7. AstrBot 具体案例

TG 适配器 `self_id` 用 username、Reply 组件填数字 ID 导致回复永不唤醒的完整 bug、代码 diff、排查时间线，见
`references/astrbot-telegram-wake-case.md`。
幂等修复脚本：`scripts/reply-wake-patch.py`（拷到目标机执行后重启）。

## 8. 汇报纪律

- 排障结论必须带**时间戳 + 证据来源**，不要只说「应该好了」
- 自己的补丁导致故障，直接认，说明改错了哪个字段、为什么错，不找补
- 用户描述和代码逻辑冲突时，以日志为裁判，并把两者矛盾点讲清楚
- 当前模型看不了图时，明说「我这边看不了图」，请用户用文字描述现象，不要瞎猜截图内容
