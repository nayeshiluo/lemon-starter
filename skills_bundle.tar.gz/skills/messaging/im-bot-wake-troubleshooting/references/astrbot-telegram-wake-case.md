# AstrBot / Telegram 回复唤醒 bug 完整案例

记录于 2026-10-26，AstrBot v4.29.3，uv tool 安装（site-packages 路径见下）。

## 现场

- 机器：`diaomao`（<YOUR_SERVER_IP>，SSH 2222），Ubuntu 24.04，913Mi RAM
- Bot：`@dafeiyu120_bot`（用户叫它「大肥鱼」），是群 `<PRIVATE_IDENTIFIER>` 的管理员
- 面板：`https://astrbot.<PRIVATE_IDENTIFIER>:8443`（CF 橙云 + nginx 8443 反代 127.0.0.1:6185）
- 数据根：`/opt/astrbot/data`，代码：`/root/.local/share/uv/tools/astrbot/lib/python3.12/site-packages/astrbot/`

用户报障：「只有 @ 才有反应，`大肥鱼` 或者回复发言的方式都触发不了」。

## 排查时间线

### 1. 排除环境层（全部通过）

| 检查 | 结果 |
|---|---|
| `getMe` → `can_read_all_group_messages` | `true`（隐私模式已关，群消息全量可读） |
| `getChatMember` → bot 在群身份 | `administrator` |
| `platform_settings.id_whitelist` | 含 `<PRIVATE_IDENTIFIER>`（整群放行） |
| `platform_settings.enable_id_white_list` | `true` |
| 指令权限 | 40 条 `everyone`，群友本来就能用 |

### 2. 日志相关性（关键技巧）

`event_bus` 只打印 `昵称/用户ID`，**不含群 ID**，一开始误判成「用户在私聊测」。

正确做法：对齐时间戳。`preprocess_stage` 的警告行带完整会话：

```
11:04:12.815 [event_bus:117]  zjw120/<YOUR_TELEGRAM_ID>: 大肥鱼 叫爸爸
11:04:12.850 [preprocess_stage:228] Session telegram-main:GroupMessage:<PRIVATE_IDENTIFIER> has no speech-to-text provider configured.
```

差 35 ms → 同一条消息，**确认是群消息**。

三条对照实验（都在群里）：

| 时间 | 消息形态 | 结果 |
|---|---|---|
| 11:04:12 | `大肥鱼 叫爸爸`（无斜杠） | 只有 preprocess，无 respond → 未唤醒 |
| 11:04:33 | `/大肥鱼 叫爸爸`（带斜杠） | 当时正处于崩溃版本，无 respond |
| 11:10:09 | 引用 bot 消息 + `/ 叫爸爸` | **有 respond**（修复后） |

### 3. 两个真因

**真因 A：前缀含斜杠。** `wake_prefix: ["/大肥鱼"]`，用户发的是 `大肥鱼 xxx`，`message_str.startswith("/大肥鱼")` 不成立。

**真因 B：Reply 唤醒判定永远为 False。**

`tg_adapter.py`：

```python
message.self_id = str(context.bot.username)          # → "dafeiyu120_bot"
```

`Comp.Reply` 构造：

```python
sender_id=reply_abm.sender.user_id                   # → <YOUR_USER_IDENTIFIER> (int)
```

唤醒检查：

```python
isinstance(message, Reply) and str(message.sender_id) == str(event.get_self_id())
# "<YOUR_USER_IDENTIFIER>" == "dafeiyu120_bot" → False
```

At 之所以能用，是因为代码专门把 `At.qq` 改写成了 `message.self_id`（`tg_adapter.py` 里 `if name.lower() == message.self_id.lower(): mention.qq = message.self_id`），Reply 路径漏了这一步。

## 修复

位置：`tg_adapter.py` 的 `convert_message`，`Comp.Reply(...)` 之前。

```python
# 被回复的是机器人自己时，sender_id 必须用 self_id(username)，
# 否则 waking_check 里 Reply.sender_id == get_self_id() 永远不成立
_reply_sender_is_bot = bool(
    update.message.reply_to_message.from_user
    and update.message.reply_to_message.from_user.id == context.bot.id
)
_reply_sender_id = (
    str(context.bot.username) if _reply_sender_is_bot else reply_abm.sender.user_id
)
message.message.append(
    Comp.Reply(
        id=reply_abm.message_id,
        chain=reply_chain,
        sender_id=_reply_sender_id,      # 可以是 str
        sender_nickname=reply_abm.sender.nickname,
        time=reply_abm.timestamp,
        message_str=reply_message_str,
        text=reply_message_str,
        qq=reply_abm.sender.user_id,     # 必须保持 int！
    ),
)
```

## 中间那次翻车（重要教训）

第一版把 `qq=_reply_sender_id` 也改了。`Reply.qq` 类型是 `int | None`，不含 `str`：

```
pydantic.v1.error_wrappers.ValidationError: 1 validation error for Reply
qq
  value is not a valid integer (type=type_error.integer)
```

栈顶在 `tg_adapter.py:702 in convert_message` → `components.py:613 Reply.__init__`。异常被 `telegram.ext._application` 的
`No error handlers are registered, logging exception` 捕获并只打日志。

后果：**每一条回复消息都在解析阶段崩溃**，连唤醒检查都到不了。而 `systemctl is-active` 仍是 `active`、端口正常、`Telegram Platform Adapter is running` 照常打印。用户看到的是「更没反应」。

字段类型对照（`core/message/components.py`）：

```python
sender_id: int | None | str = 0     # 能放字符串
qq:        int | None = 0           # 只能整数（deprecated 字段，但仍在校验）
```

## 验证证据

修复后一次完整链路（本地时间 Asia/Shanghai）：

```
11:10:09  event_bus      收到 [引用消息(dafeiyu120_bot: ...)] / 叫爸爸
11:10:25  respond.stage  Prepare to send
11:10:25  tg_event:615   流式输出: 使用 edit_message_text fallback (群聊)
11:10:32  provider_stats 调用完成
```

`provider_stats` 行：

```
created_at 2026-10-26 03:10:32 (UTC) | umo telegram-main:GroupMessage:<PRIVATE_IDENTIFIER>
provider_model cn:kimi-k3-1 | status completed
token_input_other 10690 | token_output 35 | time_to_first_token 5.24s
```

`token_output=35` 证明模型真生成了内容并发出。这是最硬的证据。

## 相关表结构（data_v4.db）

- `provider_stats`：`created_at, umo, conversation_id, provider_id, provider_model, status, token_input_other, token_input_cached, token_output, start_time, end_time, time_to_first_token`
- `platform_message_history`：`created_at, platform_id, user_id, sender_id, sender_name, content, message_id`，`content` 是 JSON（`{"type":"user","message":[{"type":"plain","text":...}],"message_id":...}`）
- `conversations`：`user_id` 形如 `telegram-main:GroupMessage:<PRIVATE_IDENTIFIER>`

## 附带发现

- `has no speech-to-text provider configured` 对**纯文本群消息也报**，是噪音。群里 19 条消息 18 条真语音，只有 1 条触发该警告时才是语音。
- `admins_id: ["astrbot", "<YOUR_TELEGRAM_ID>", "<PRIVATE_IDENTIFIER>"]` 里的群 ID 无效（按 sender_id 比对），无害但不该加。
- 用户后续自己装了两个插件 `astrbot_plugin_private_companion` / `astrbot_plugin_proactive_chat`，前者会拦截 `send_message_to_user`（日志：`已约束被动回复的 send_message_to_user 仅用于媒体投递`）。出现「回复偶尔丢」时优先怀疑它。
