---
name: telegram-quote-sticker
description: "Telegram 群聊 Q 图贴纸功能：引用消息发 q 生成高质感气泡贴纸、私聊双按钮确认/取消与超时自动清理。"
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux, macos]
metadata:
  hermes:
    tags: [telegram, bot, quote-api, sticker, q-sticker, webp, messaging]
    related_skills: [telegram-group-assistant, telegram-ops-bot]
---

# Telegram Q 图贴纸与贴纸包管理规范 (Telegram Quote Sticker & Pack)

## When to Use
- 在 Telegram 机器人群聊中实现「回复消息发送 q」自动生成精美名言/金句气泡贴纸；
- 需要支持「回复消息发 qs」自动创建/追加到用户专属贴纸包（Sticker Set）；
- 需要支持「回复贴纸发 qd」从贴纸包中精准删除指定贴纸；
- 需要基于 quote-api (`/generate.webp`) 搭建 Node.js + canvas 贴纸渲染服务；
- 需要实现「群内触发 → 私聊发送双按钮确认/修改/取消 → 超时自动清理并删除触发指令」防刷屏交互链路。

## 功能矩阵 (q / qs / qd)

| 指令 | 触发方式 | 执行动作 | 结果呈现 |
|---|---|---|---|
| **`q`** | 回复任意消息发 `q` *(或 `q 假话`)* | 渲染单张 WebP 贴纸（**纯粹发言，不带二级回复**） | 贴纸直接发送回群聊原位，秒删指令 |
| **`qh`** | 回复某条**带有回复引用的消息**发 `qh` | **带上被引用的上文历史**渲染 WebP 贴纸 | 完整保留上下级嵌套回复引用 |
| **`q <数字>`** | 回复消息发 `q 3` / `q 5` | **多条连续消息合并引用** | 自动拼接多条消息为长气泡贴纸并发出 |
| **`qs` / `qs <数字>`** | 回复任意消息发 `qs` (或 `qs 3`) | 渲染并加入专属贴纸包（不带二级回复） | 贴纸加入专属贴纸包并发送 |
| **`qhs`** | 回复带引用的消息发 `qhs` | **带上级回复历史**渲染并收录进专属贴纸包 | 贴纸加入专属贴纸包并发送 |
| **`add` / `qs`** | **回复现成贴纸/图片**发 `add` 或 `qs` | **将该现成贴纸一键收录进贴纸包** | 自动转为 512px WebP 并入库 |
| **`qd`** | 回复贴纸发 `qd` | 校验后调用 `RemoveStickerFromSetRequest` | 从贴纸包中移除该贴纸，秒删指令 |
| **`setpack`** | 发送 `setpack <新名称>` | 调用 `RenameStickerSetRequest` | 修改专属贴纸包在 TG 中的显示标题 |

---

## 完整交互与业务流程

### 1. `q` 基础生成流程
```
群聊: 用户回复某消息发送 "q" (或 "q 自定义文字")
  │
  ├─ Bot 提取被回复消息 (文字/Caption/纯媒体)
  ▼
私聊: Bot 发送确认卡片 + [✅ 确认] [❌ 取消] 按钮
  │
  ├─ 点击 [❌ 取消] 或超时 60s ──▶ 删群聊 q + 删私聊卡片 + 清 pending
  └─ 点击 [✅ 确认] ──────────────▶ 调用 quote-api 渲染 ──▶ sendSticker 发回群聊 ──▶ 清理消息
```

### 2. `qs` 贴纸包创建/追加流程
```
群聊: 用户回复某消息发送 "qs"
  │
  ▼ (私聊确认生成 WebP)
查询用户是否已有贴纸包 (name: `q_{user_id}_by_{bot_username}`)
  ├─ 无贴纸包 ──▶ 调用 createNewStickerSet 创建并写入第 1 张
  └─ 已有贴纸包 ─▶ 调用 addStickerToSet 追加当前贴纸
  │
  ▼
返回贴纸包链接: https://t.me/addstickers/q_{user_id}_by_{bot_username}
```

### 3. `qd` 贴纸删除流程
```
群聊/私聊: 用户回复某张贴纸发送 "qd"
  │
  ├─ 获取被回复贴纸的 file_id 与 set_name
  ├─ 鉴权校验: 确保 set_name 属于当前 Bot 且操作人为贴纸包 Owner 或 Admin
  ▼
调用 deleteStickerFromSet(sticker=file_id)
  │
  ▼
删除用户发送的 "qd" 消息，提示 "🗑️ 该贴纸已从贴纸包中移除"
```

---

## 核心 API 与实现代码

### 1. 贴纸包 API 调用规范
```bash
# 1. 创建贴纸包 (createNewStickerSet)
curl -X POST "https://api.telegram.org/bot<BOT_TOKEN>/createNewStickerSet" \
  -F "user_id=<USER_ID>" \
  -F "name=q_<USER_ID>_by_<BOT_USERNAME>" \
  -F "title=<用户昵称>的名言集" \
  -F "stickers=[{\"sticker\":\"attach://sticker_file\",\"format\":\"static\",\"emoji_list\":[\"💬\"]}]" \
  -F "sticker_type=regular" \
  -F "sticker_file=@/tmp/quote.webp"

# 2. 追加到贴纸包 (addStickerToSet)
curl -X POST "https://api.telegram.org/bot<BOT_TOKEN>/addStickerToSet" \
  -F "user_id=<USER_ID>" \
  -F "name=q_<USER_ID>_by_<BOT_USERNAME>" \
  -F "sticker={\"sticker\":\"attach://sticker_file\",\"format\":\"static\",\"emoji_list\":[\"💬\"]}" \
  -F "sticker_file=@/tmp/quote.webp"

# 3. 从贴纸包删除贴纸 (deleteStickerFromSet)
curl -X POST "https://api.telegram.org/bot<BOT_TOKEN>/deleteStickerFromSet" \
  -F "sticker=<STICKER_FILE_ID>"
```

### 2. Python (channel.py) qd 删除逻辑
```python
async def handle_qd_command(update, context):
    msg = update.effective_message
    reply = msg.reply_to_message
    if not reply or not reply.sticker:
        return
    
    sticker = reply.sticker
    set_name = sticker.set_name
    bot_user = await context.bot.get_me()
    
    # 检查贴纸是否属于当前 Bot 管理的包
    if not set_name or not set_name.endswith(f"_by_{bot_user.username}"):
        return
    
    try:
        await context.bot.delete_sticker_from_set(sticker=sticker.file_id)
        # 删除触发的 qd 消息
        await msg.delete()
        # 可选：提示成功
    except Exception as e:
        logger.error(f"Failed to delete sticker: {e}")
```

---

## 核心代码与架构逻辑

### 1. 触发与媒体消息识别 (channel.py)
```python
_quote_text = _rmsg.text or _rmsg.caption or ""
# 回复贴纸/图片/文件/视频/语音：没有文字时设为空，引导私聊输入
if not _quote_text and any(
    getattr(_rmsg, m, None) is not None
    for m in ("sticker", "photo", "document", "video", "voice")
):
    _quote_text = ""
    _is_sticker_reply = True
```

### 2. Pending 缓存数据结构
```python
self._pending_quotes = {
    user_id: {
        "text": "文字内容",
        "from_id": 被回复消息作者ID,
        "from_name": 被回复消息作者名,
        "group_chat_id": 群聊ID,
        "q_msg_id": 群里q消息ID,
        "timestamp": 时间戳,
        "confirm_msg_id": 私聊确认消息ID,
    }
}
```
- **超时机制**：以私聊 `user_id` 为 Key，时间戳超 60 秒自动失效。

### 3. 公共取消与清理逻辑 (`_cancel_pending_quote`)
- 供「取消按钮」、「后台定时清扫」及「新请求进入时顺带清理」共用。
- 核心操作：删除群聊 `q_msg_id`、删除私聊 `confirm_msg_id`、从 `_pending_quotes` 中移除。

### 4. 自动清扫任务 (`_quote_cleanup_loop`)
- 后台每 30 秒执行一次，检查超 60 秒的 pending 任务并执行自动取消。

---

## 服务与底层配置

### 1. quote-api 部署
- **项目仓库**: `https://github.com/LyoSU/quote-api`
- **工作目录**: `workspaces/services/quote-api/`
- **监听端口**: `4888`
- **启动脚本**: `sh backups/start_quote-api.sh`
- **运行环境**: Node.js `v25.6.0` + canvas `3.2.3`（⚠️ 必须为 3.x，Node v25 下 2.x fillStyle 会全黑失效）

### 2. 样式调优要点
- **去水印**: 移除 `@QuotLyBot` 水印（`generate.js` 内 image + stories 处）。
- **去毛玻璃边框**: `composer.js` 中设置 `glassLw = 0`。
- **纯净气泡输出**: `type: 'image'` 模式直接输出 canvas 缓冲：
  ```js
  quoteImage = canvasQuote.toBuffer()
  ```
- **气泡配色**: 白底黑字（API 参数 `backgroundColor: "#FFFFFF"`）。

### 3. API 调用示例
```bash
# 生成贴纸
curl -X POST "http://127.0.0.1:4888/generate.webp" \
  -H "Content-Type: application/json" \
  -d '{
    "backgroundColor": "#FFFFFF",
    "type": "image",
    "messages": [{
      "text": "测试内容",
      "from": {"id": 12345678, "name": "用户名"},
      "avatar": true
    }]
  }' -o /tmp/quote.webp

# 发送 WebP 贴纸到 Telegram 群
curl -X POST "https://api.telegram.org/bot<TOKEN>/sendSticker" \
  -F "chat_id=<CHAT_ID>" \
  -F "sticker=@/tmp/quote.webp"
```

---

## 故障排查与已知问题

| 故障现象 | 根本原因 | 解决方案 |
|---|---|---|
| 生成图片全黑 | canvas 2.x 与 Node.js v25 不兼容导致 fillStyle 失效 | 升级并锁定使用 `canvas 3.2.3` |
| 气泡周围有黑边 | frosted-glass 毛玻璃边框渲染异常 | 在 `composer.js` 中设 `glassLw = 0` |
| 贴纸带有多余白边 | `type: 'image'` 默认 padding 边距 | `generate.js` 直接返回 `canvasQuote.toBuffer()` |
| 私聊无法收到确认卡片 | 用户此前未与 Bot 建立过私聊（Bot 无法主动向无交互用户发起消息） | 提示用户先在私聊中向 Bot 发送 `/start` |
| 贴纸缺少用户头像 | `from.id` 无效或 Bot 无权限获取对应头像 | 确保传入真实 TG 用户 ID 且 Token 拥有头像下载权限 |
| quote-api 无法连接 (4888) | 容器重启导致 `/opt/` 临时文件或进程丢失 | 执行 `sh backups/start_quote-api.sh` 重启服务 |
| 图片/语音发 q 没反应或代码不生效 | 主进程未重启加载修改后的 Python 模块 | 在容器外执行重启脚本或发送信号重启应用进程 |
