---
name: summary
description: "群聊智能总结：/summary 触发，折叠卡片+精准溯源"
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [telegram, summary, group, collapsible, sourcing]
    related_skills: [telegram-group-assistant]
---

# 群聊智能总结 (/summary)

## When to Use
用户输入 `/summary`、`/summary 80条`、`/summary 2h`、`/summary 今天` 时触发。
完整规范与网关配置见 `telegram-group-assistant` 技能，本技能是其可直接调用的指令入口。

## 参数解析

| 用户输入 | 含义 |
|---|---|
| `/summary` | 默认最近 80 条 |
| `/summary 50` / `/summary 50条` | 按条数，范围 15~400 |
| `/summary 30m` / `1h` / `2.5h` / `1d` | 按时间窗口 |
| `/summary 今天` / `今日` | 当日 0 点至今（北京时间 UTC+8）|

## 执行步骤

1. **取数**：读 `~/.hermes/state.db` 的 `messages` 表，按当前会话的群 ID 过滤，取 `observed=1 或 role='user'` 的记录，字段要 `platform_message_id, content, role, timestamp`。

```python
import sqlite3, os
conn = sqlite3.connect(os.path.expanduser('~/.hermes/state.db'))
cur = conn.cursor()
cur.execute("""
    SELECT m.platform_message_id, m.content, m.timestamp
      FROM messages m JOIN sessions s ON m.session_id = s.id
     WHERE s.session_key LIKE ?
       AND (m.observed = 1 OR m.role = 'user')
       AND m.content IS NOT NULL AND length(m.content) > 1
     ORDER BY m.id DESC LIMIT ?
""", (f'%telegram:group:{chat_id}%', limit))
```

2. **清洗**：剔除纯表情、签到打卡、刷屏、指令调用本身。

3. **聚合（核心心法）**：按核心议题重构脉络，凝练 3~4 个话题。以事件 / 技术本质 / 方案 / 共识为主语，**严禁**「张三说…李四回…」式流水账。事实与观点分离。

4. **溯源**：每条要点末尾附真实消息直链，`platform_message_id` 必须来自数据库实查，严禁虚构或错位。多条讨论合并时并列多个来源。
   - 私密超级群：`https://t.me/c/<群ID去-100前缀>/<platform_message_id>`
   - 公开群：`https://t.me/<用户名>/<platform_message_id>`

5. **渲染**：全量原生 HTML 折叠卡片，每个议题一个独立 `<details>`：

```html
<details>
<summary>{Emoji} {议题名称}</summary>

• {浓缩的讨论事实、矛盾焦点与技术细节} [来源](https://t.me/c/4495899387/105480) [来源2](https://t.me/c/4495899387/105488)
</details>
```

末尾固定收尾板块：

```html
<details>
<summary>📋 结论与行动</summary>

• 底层结论或共识。
• 可落地的行动建议或避坑指南。
</details>
```

## 红线（违反即失败）

- ❌ 严禁用 ``` 代码块包裹整个总结 —— 会导致折叠卡片退化成源码文本
- ❌ 严禁使用 `||剧透||`、`>` 引用、`**>` 等格式污染
- ❌ 严禁虚构来源链接或错位引用
- ✅ 网关必须已开启 `rich_messages: true` 与 `rich_messages_allow_cjk: true`（否则中文会降级为纯 Markdown，折叠失效）

## Pitfalls

1. **MTProto 人型不支持 `<details>`**：Telethon 会剥离标签退化成纯文本。人型（UserBot）发总结必须改用 `<blockquote expandable>`，且显式传 `parse_mode="html"`。
2. **群聊上下文过大触发 TPM 429**：若群聊分流用的是低 TPM 的第三方 Provider，数万 token 的总结请求会被限流。群聊应分流到本地 8317 网关的 Gemini（百万上下文、高并发）。
3. **`platform_message_id` 为 NULL**：机器人自身发出的消息该字段可能为空，做溯源时必须过滤掉，否则会生成 `.../None` 的死链。
