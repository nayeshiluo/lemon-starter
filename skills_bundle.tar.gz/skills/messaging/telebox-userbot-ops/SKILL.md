---
name: telebox-userbot-ops
description: "运维 TeleBox 人型号（vps-la 第二号）：插件模型面与 AI 桥接。"
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux]
metadata:
  hermes:
    tags: [telegram, userbot, telebox, node, model-routing, selfhost]
    related_skills: [lemon-userbot, hermes-custom-providers, smart-group-bot-ops]
---

# TeleBox 人型号运维（第二 TG 账号）

上游：`https://github.com/TeleBoxOrg/TeleBox`（Node/TypeScript，插件热加载，配置全在 JSON 文件里）。
本技能是**第二个 Telegram 人型号**在 vps-la 上的现行运维权威。

与 `lemon-userbot` 的区别：那套是 **Python Telethon** 写的第一个号（跑在 naye），
这套是 **Node/TS + 插件体系** 的第二个号（跑在 vps-la）。**两套代码、两套配置、两套结论，不要互相套用。**

## When to Use

- 用户提到「第二人型 / 第二个号 / TeleBox」，或问「人型号有哪些功能在调模型」。
- 给这个号换模型、换中转、排查「某个 AI 功能不回复 / 出图失败」。
- **做全站模型迁移时的必查项**：这个服务第一轮极易被漏掉（目录名带 `test`、不在 Docker 里、
  服务名不含 `userbot`）。见下节「别被目录名骗了」。

## 现行部署事实（2026-11 实测）

| 项 | 值 |
|---|---|
| 主机 / 目录 | `vps-la` / `/opt/telebox-test`（应用在 `app/`） |
| 服务 | `telebox-second-account.service`（systemd，User=`telebox-test`） |
| Node 运行时 | `/opt/telebox-test/runtime/bin/node`（**不是**系统 node，别用 `which node` 判断） |
| 配置根 | `/opt/telebox-test/app/assets/`，每个插件一个目录 |
| 插件注册表 | `/opt/telebox-test/app/assets/tpm/plugins.json`（126 条） |
| 登录态 | 已有 session 文件，重启即 `✅ Existing session detected. Logged in successfully.` |

**别被目录名骗了**：目录叫 `telebox-test`，但它就是**在用的第二个号**，
`systemctl list-units | grep -i tele` 只会看到 `telebox-second-account.service`。
按「test 目录 = 试验品」跳过，就会在「全部换完了吗」这个问题上答错。

`/opt/telebox-test/app/assets/tpm/plugins.json` 是**插件来源清单**，每条只有
`{url, desc, _updatedAt, _contentHash}`，**没有 enable 字段** —— 别拿它判断「某插件是关着的」
（全表 `enabled` 计数恒为 0，是假信号）。

## 七处模型调用面（换模型必须逐处改）

| 插件 | 配置文件（前缀 `/opt/telebox-test/app/`） | 字段 | 协议 |
|---|---|---|---|
| `agent` | `assets/agent/config.json` | `providers.<名>.{base_url,api_key,model,type,auth_method}` + `default_provider` | OpenAI `/chat/completions` |
| `uai` | `assets/uai/config.json` | 同上（引用消息 AI 分析） | OpenAI `/chat/completions` |
| `ai` | `assets/ai/config.json` | `configs.<tag>.{url,key,type}` + `currentChatTag/Model`、`currentSearchTag/Model`、`currentImageTag/Model` | chat/search 走 OpenAI；image 走 `/images/generations` |
| `persona` | `assets/persona/config.json` | `base_url` + `primary_model` / `fallback_model` | 代码自己拼 `${base_url}/chat/completions` |
| `music` | `assets/music/music_config.json` | `music_gemini_base_url` + `music_gemini_model` | **Gemini 原生** `${base}/v1beta/models/{model}:generateContent` |
| `sum` | `assets/sum/summary_config.json` | `aiConfig.providers.<名>.{base_url,api_key,model,type}` + `aiConfig.default_provider` | OpenAI `/v1/chat/completions` |
| `xmsl` | `assets/xmsl/config.json` | `apiMode` / `baseUrl` / `apiKey` / `model` | OpenAI |

两个结构性差异，改之前必须知道：

- **`ai` 有四种模式**（chat / search / image / video），`currentImageModel` 是**生图模型**
  （如 `gpt-image-2`），不能跟着文本模型一起换 —— 换了就是 404。
- **`music` 说 Gemini 协议**，只认 `:generateContent` 路径。把它的 base_url 指向一个纯 OpenAI
  兼容端点，点歌功能会整体失效（而且只在有人点歌时才暴露）。

## 换模型的正确姿势：本地桥接，不改源码

TeleBox 的 provider 配置**不支持自定义请求头**（`agent` 里只有 `auth_method: bearer_token`），
所以遇到「按 UA 拦人」的上游、或需要「主力 + 备用」梯队时，**在宿主机起一个薄桥接**，
把七个插件的 base_url 全指过去，源码一行不动。

现行实现：`telebox-ai-bridge.service`，监听 `127.0.0.1:18319`。

```
/opt/telebox-ai-bridge/bridge.py          # 0755
/etc/telebox-ai-bridge/config.json        # 0600
/etc/telebox-ai-bridge/{command,zhou}.key # 0600，config 里用 "file:/..." 引用
```

桥接承担四件事（缺一件就会坏掉一类功能）：

1. **注入上游必需 header**（UA / 鉴权）—— 插件侧补不了；
2. **Gemini 原生 → OpenAI 转换**：`contents/parts` ↔ `messages`，响应再包回
   `candidates[].content.parts[].text` + `usageMetadata`，否则 `music` 直接 502；
3. **梯队**：主力 → 同厂次选 → 备用站；
4. **非对话端点原样透传**并**原样回传上游状态码**：
   - `ai` 的 `/v1/images/generations`、`/images/edits`、视频任务必须透传给原上游；
   - Gemini 侧若 `generationConfig.responseModalities` 含 `IMAGE`，同样透传，**不能当文本转走**；
   - `urllib` 的 `HTTPError` 必须捕获后回传 `e.code`，否则上游 `429 model_cooldown`
     会被压成桥接自己的 `502`，排查时全跑偏。

桥接自身边界要主动交代：**只做非流式**。插件配置里 `stream` 一律 `false` 才安全。

### 改完怎么重启

```bash
systemctl restart telebox-second-account.service
sleep 20
systemctl is-active telebox-second-account.service
journalctl -u telebox-second-account.service --since "-60s" --no-pager \
  | grep -iE "Logged in successfully|error|插件初始化完成"
```

配置是启动时读的，**改 JSON 必须重启**，没有热加载。

## 验收：三层，缺一层就可能报假成功

```bash
# ① 桥接本身（绕开 Telegram）
curl -s -m 10 http://127.0.0.1:18319/healthz
curl -s -m 10 http://127.0.0.1:18319/v1/models

# ② 两种协议各打一次（用插件自己的 key，从配置里读，别打印）
#    OpenAI:   POST /v1/chat/completions  → 有 choices
#    Gemini:   POST /v1beta/models/<m>:generateContent?key=... → 有 candidates

# ③ 透传保真：同一请求分别打「原上游」和「桥接」，状态码 + 错误正文必须一致
```

②③ 的实测结论（2026-11）：`chat` 200、`gemini_text` 200；
`/v1/images/generations` 经桥接与直连原上游返回**完全相同**的
`429 {"code":"model_cooldown","last_upstream_error":"usage_limit_reached: ..."}` ——
证明透传链路正确，429 是上游生图模型额度问题、与迁移无关。

### 按插件真实请求格式逐条验（比只打一个 `/chat/completions` 强得多）

七个插件**各自拼路径**，只打一条 OpenAI 端点会漏掉 `music`/`persona` 的 Gemini 分支和 `sum` 的路径归一化。
正确做法：从每个插件的配置文件里读它自己的 `base_url`/`url`/`baseUrl` 字段，
按它**自己代码里的拼接规则**组 URL 再打（字段名与拼接规则见上表）。2026-11 复验 7 条全 200：

| 插件 | 实际打的 URL |
|---|---|
| `agent` / `uai` / `persona` | `<base_url>/chat/completions` |
| `xmsl` | `<baseUrl>/chat/completions`（字段是驼峰 `baseUrl`） |
| `ai` | `<configs.cpa.url>/chat/completions` |
| `sum` | **先 strip 末尾 `/v1`**，再拼 `/v1/chat/completions`（`normalizedBaseUrl()` 已归一化，填 `.../v1` 或 `...` 都对，填 `.../v1/v1` 才错） |
| `music` | `<music_gemini_base_url>/v1beta/models/<model>:generateContent?key=<key>` |

`music` 的 key 走 **query 参数**（不是 Bearer），桥接必须实现这个分支。

**诚实边界（更新）**：桥接链路 + **七个插件各自的请求路径与协议**均已逐条实测通过。
仍未做的是**发真实 TG 消息触发插件**的消息级端到端 —— 汇报时写「七插件请求层已验、未经 TG 消息触发」。

### 出图能力不在模型迁移范围内

`plugins/tts.ts` 走 **Azure TTS**（`zh-CN-XiaoxiaoNeural` + region），与模型厂家无关。
换模型站不会影响语音，也**不要**承诺「新模型站带语音」—— 用户问语音时按这个事实答。

## 坑

- **Python `urllib` 默认 UA 会被 Cloudflare 拦（403 `error code: 1010`），axios 默认 UA 不会。**
  桥接是 Python 写的 → 必须显式带 `User-Agent: Mozilla/5.0`；而用 Node/axios 探测同一端点
  不带 UA 也 200。别拿 axios 的结果去推断 Python 侧也通。
- **`18318` 不是独立服务**，是 `sshd` 的本地端口转发（`ss -ltnp` 里属主显示 sshd），
  后端是 CPA 的 `127.0.0.1:8317`。隧道断了桥接的透传就一起断 —— 排查透传失败先看隧道。
- **不要用 `docker exec` 那套思路**：这个服务不在 Docker 里，`/opt/telebox-test` 属主是
  `telebox-test`，改配置要么 `sudo` 要么用 root 身份，改完记得把属主还回去。
- **七个配置文件的 `api_key` 是明文**。备份/取证时不要整份打印，用字段级脱敏
  （只输出长度 / 前缀 / 是否为空）。
- 插件目录里的 `*.bak-*` 是历次改动留下的，恢复时按时间戳挑，别按文件名猜。

## 边界

- 与 `lemon-userbot`（naye，Telethon 第一号）**无共享配置、无共享 session**，任何结论不互通。
- 与群霸 / SGB 是不同项目，模型选型可参考但配置 schema 完全不同。
- 这个号是**人型号**（用户账号），发消息、加群等动作有账号风险，任何自动行为改动先说明后果再动手。
