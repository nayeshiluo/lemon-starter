---
name: telegram-group-bot-suite
description: "构建与运维 Telegram 全能群聊机器人：多卷贴图、音乐点播与群开关、多实例复刻。"
version: 1.3.0
author: Hermes Agent
license: MIT
platforms: [linux, macos]
metadata:
  hermes:
    tags: [telegram, bot, quote-api, sticker, music, netease, group-bot]
    related_skills: [telegram-quote-sticker, telegram-group-assistant]
---

# Telegram 群聊全能管家系统架构与运维规范 (Telegram Group Bot Suite)

## 本部署现行边界（优先于历史案例）

以运行中源码和配置为准。Owner 未开放的功能，群主/管理员不得自行开启；禁言、Ban、解封等危险能力独立授权。旧解析仅归档，中转失败不重新启用。修改技能文本不等于改 Bot 代码，不要求重启 Bot。

### 配置“自己变了”：先查并发 Hermes 会话，别急着判未授权

本机 Web UI 常驻多个 Hermes worker（`hermes_bridge.py --worker-profile default`，各自不同 socket）。另一个会话可能在同一项目目录改 `data/ai_bot_*.json`、`ai_timeout_overrides.json`、`gemini-recovery-revert.py` 并重启服务，当前会话毫无感知。实测一次差点被误判成入侵并回滚。

- **症状**：`order` 位次变了、`overrides` 多出条目、服务在非本人操作时段重启，且**没有对应 `.bak-*`**。
- **取证顺序**（全只读）：`ls -l --time-style=+%m-%d_%H:%M:%S data/ai_bot_*.json data/ai_timeout_overrides.json` 取精确改动时刻 → `journalctl --since/--until` 该时刻 ±2 分钟，抓 `sudo[..]: ubuntu : PWD=<项目目录> ; COMMAND=/usr/bin/systemctl restart ...` 的 **PWD 字段**（判定“谁在项目目录下动手”的关键证据）→ `ps -eo pid,lstart,cmd | grep hermes_bridge` 数 worker 与启动时间。
- **禁止**把“配置与预期不符”直接当未授权变更回滚。先核对另一会话是否已同步相关常量（本例它连 `DEMOTED_ORDER`/`RESTORED_ORDER` 一起改了，`drift=False`，自动还原仍有效）。回滚一个正确的并发改动才是真损坏。
- **判好坏用实测不看位次直觉**：跑 `scripts/verify_summary_chain.py` 对比耗时（本例 13.4s 优于改前 16.7s → 是改进）。
- 同一套群霸配置只在一个会话里改；发现并发改动先向 Owner 确认来源，不要自行“修复”。

完整时间线与复现命令见 `references/concurrent-config-drift.md`。

## When to Use
- 在 Telegram 构建或维护全能群聊机器人（如「群霸项目」）；
- 实现高保真 Q 图贴纸生成（支持 `q`、`qh`、`q N` 正负向提取、会员 Emoji 状态图标、群主紫/管理绿/群员灰三色标签、同人连续合并单头像）；
- 实现贴纸入库（`qs`）带包按钮、贴纸删除（`qd`）与贴纸包满 120 张自动扩容多卷（Vol.2, Vol.3）；
- 实现网易云音乐点播与解析（`/music 歌名/ID/链接`、Top 5 交互式数字点播、官方直链 + B站 Hi-Res 专线中继双轨兜底）；
- 搭建**音乐库预热缓存架构**（廉价 VPS 离线爬取转码 → Telegram 频道中转 → 主站 0 流量 `file_id` 秒发；含**群友点播自动沉淀回预热库**，实现跨群、跨平台归一化秒级复用，用于破解主站出网流量限额与点歌速度瓶颈）；
- 实现群聊智能总结与排障重构（彻底根治“太假”与“对应不上”：双轨持久化防重启断层、非线性回复链与时间戳注入、去八股化自适应 Prompt、来源直链精准对齐；**统一开头注入 `#总结` 标签；支持 `/autosum` 与 `/settings` 二级面板定时总结前 N 小时发言**）；
- 实现各群功能独立开关控制面板（`/settings`、实时指示灯、零公网端口暴露防爆破）。

---

## 配套参考索引

本技能是**群霸双 Bot（@<PRIVATE_IDENTIFIER>_bot / @<PRIVATE_IDENTIFIER>_bot）的现行权威**。以下 references 于 2026-10-25 从 `telegram-group-assistant` 迁入——它们是群霸专属实现细节，此前误挂在 Hermes 网关 Bot 技能下。

| 文件 | 内容 |
|---|---|
| `references/group-sticker-and-quote-spec.md` | 贴纸/引用语义权威规范：直发贴纸禁带回复头、TextQuote 局部引用、会员 Emoji 状态、标签「宁缺毋滥」矩阵、`qh` 四级兜底、媒体复原与动图定格帧、`q N` 方向语义、`qd` 删除、120 张自动分卷 |
| `references/group-moderation-and-sticker-pack.md` | 群霸全景手册：`qs` 真实语义、贴纸包链接卡片、PTB 22.x 建包参数、会员 Emoji、身份标签、二级引用、视频零流量架构、内存环形缓冲、`/color`、`/mute` 白名单与分级菜单矩阵 |
| `references/per-group-feature-toggles-and-tag-enrichment.md` | 群组功能独立开关架构（`/settings`、Inline 状态按钮、单开/单关）、身份标签提取优先级、会员 Emoji、划选局部文字引用 |
| `references/music-bot-service-spec.md` | 网易云/全网音乐点播（@Music163bot 同款）：Eapi 320k 直链加密、黑胶 VIP 凭证、上传 `Timed out`、HTTP Range 长曲截断、SQLite `file_id` 秒播缓存 |
| `references/llm-fallback-chain-and-failure-surfacing.md` | 多级兜底链可复用骨架（`_call_llm()` 返回 `(content, err)`）、`reasoning_content` 坑、静默失败→限时自毁提示、端点探测表与验收清单 |
| `references/dynamic-llm-pool-and-scheduled-summary.md` | API 池/分 Bot 模型调度/定时总结完整架构 |
| `references/group-summary-troubleshooting.md` | 总结与 LLM 节点排障：超时定位、测活、候选窗口截断 |
| `references/music-library-prewarm.md` | 音乐库预热缓存架构（廉价 VPS 爬取→频道中转→0 流量秒发） |
| `references/owner-contact-alerts.md` | Owner 联系提醒实现模板与舰队铺开清单 |
| `references/concurrent-config-drift.md` | 并发 Hermes 会话导致配置漂移的取证时间线 |
| `references/legacy-native-media-archive.md` | **历史归档**：旧原生下载/转码路径，仅在明确恢复请求时读 |

脚本：`scripts/probe_ai_chain.py`（链路体检）、`scripts/verify_summary_chain.py`（总结端到端验收）、`scripts/audit_restricted_members.py`（受限成员体检/修复）、`scripts/verify_contact_alerts.py`、`scripts/verify_desensitization.py`。
模板：`templates/standalone-quote-bot.py`（脱敏独立贴纸 Bot）、`templates/cf-worker-tgbot-media-parser.js`。

**边界**：Hermes 官方网关 Bot 的进群配置、observe 模式、总结格式规范、菜单作用域、权限矩阵、白名单鉴权 → 见 `telegram-group-assistant`。本技能不重复那部分。

## 核心功能模块与指令设计

### 1. 贴图与多卷贴纸包管理 (q / qh / qs / qd)
- **指令矩阵**：
  - `q`：单人金句贴纸，无回复头直发，秒删触发指令；
  - `qh`：带上一级回复历史的嵌套引用气泡（带原媒体缩略图）；
  - `q N`（如 `q 3`）：以被回复消息为起点【向下】顺延合并 3 条连续发言；
  - `q -N`（如 `q -3`）：以被回复消息为终点【向上】回溯合并 3 条连续发言；
  - `qs`：将名言或现有贴纸收录进本群专属贴纸包（**收录成功后仅发送带跳转链接与按钮的卡片，禁止重复发送贴纸原图刷屏**）；
  - `qd`：长按回复想要删除的贴纸发 `/qd`，校验管理员/群主/VIP权限后调取 `deleteStickerFromSet` 彻底注销移除，并即时使贴纸缓存失效；
  - `autosticker`：群聊发言活跃度自动随机发送贴图机制（支持群内 `/autosticker N`、`/settings` 二级面板预设点击切换，以及 Owner 私聊全局遥控）。
- **群聊活跃度随机贴纸池架构 (Autosticker Activity Trigger & Dynamic Pool)**：
  - **业务场景**：群聊活跃时，根据群内发言数量阈值（如每 50 条群友发言）自动从本群专属贴纸包（或群原生关联贴纸包）中随机抽取一张贴纸发送，提升互动趣味性；
  - **贴纸提取与多卷扫描**：
    - 优先扫描本群专属贴纸包 `g_{clean_id}_by_{bot_username}` 及其多卷扩容包 (`Vol.2`..`Vol.N`)；
    - 若专属贴纸包为空，自动回退探测群聊原生绑定的 `chat.sticker_set_name`；
    - 贴纸 `file_id` 列表使用 5 分钟内存热缓存 (`_STICKER_CACHE`)，避免高频请求 Telegram Bot API 导致限流；
    - 在 `qs` 录入新贴纸或 `qd` 删除贴纸后，必须显式调用 `invalidate_group_sticker_cache(chat_id)` 即时刷新池子；
  - **发言计数与安全过滤**：
    - 非指令正常发言触发 `increment_group_message_count`；
    - 达到阈值后原子重置计数器并异步投递 `send_sticker`；
  - **多维操控入口**：
    - 群内指令：`/autosticker [数量]`（`0` 或 `off` 为关闭，无参数查看当前进度）；
    - `/settings` 控制面板：集成 `🎲 活跃度随机贴纸` 专属二级菜单，提供常用预设按钮（`20/30/50/80/100/200条`）与一键开关；
    - 私聊远程控制：Owner 私聊 `/autosticker` 查看所有群组大盘，支持隔空配置 `/autosticker <chat_id> <数量>`。
- **贴图与回复链核心避坑点 (Quote & Reply Chain Pitfalls)**：
  - **严格区分 `q` 与 `qh` 语义边界**：
    - `q`：单人金句贴纸，**绝对不带二级引用气泡**，纯粹突出被回复者的单人发言；
    - `qh`：带上文历史贴纸，**强制启动四级穿透回溯并渲染二级气泡**；
  - **Telegram Bot API 嵌套回复剥离与 `qh` 四级深度穿透体系**：
    - 官方协议陷阱：Telegram Bot API 在向机器人推送消息时，被回复消息对象的 `reply_to_message.reply_to_message` **恒为 None**（官方防止对象无限递归截断）；
    - 若纯靠内存记录消息链，重启或淘汰后 `reply_obj` 丢失，导致 `qh` 惨遭降级为单人贴纸；
    - **双轨四级回溯方案**：
      1. 路径 A：探测原生 `reply_target.reply_to_message`；
      2. 路径 B：从 SQLite `messages` 表依据 `reply_to_msg_id` 秒级深度回溯出真实被引用者 ID、昵称、正文与 `media_file_id`；
      3. 路径 C：提取 Telegram 7.0+ 原生文本引用（`msg.quote` / `external_reply`）；
      4. 路径 D：若目标发言未显式绑定回复链但群友发了 `qh`，兜底抓取群内**紧邻的前一条正常发言**作为对话上下文，保证 100% 输出双层气泡；
  - **全量消息持久化闭环（含纯媒体/贴纸）**：群友发送纯贴纸或纯图片时，也必须打上 `[贴纸 💬]` / `[图片]` 存入 SQLite `messages` 表，杜绝多媒体回复链溯源断层；
  - **服务热重载铁律**：修改 Python 或 Node.js 模块代码后，必须显式触发 `systemctl restart lemon-group-bot.service` 重载服务，严禁在旧进程依然运行时提前报告完成；
  - **同人连续合并与多人多头像 (`chatId`)**：Node.js quote-api 底层对比 `msg[i-1].chatId === msg[i].chatId`。若消息未在外层显式携带 `chatId`，在 JS 中 `undefined === undefined` 恒为 `true`，会导致不同群友发言的头像被错误吞掉。**必须在每条消息外层显式传 `chatId: user_id`**；
  - **标签头衔真实性**：群主紫色 (`#b18fff`)、管理员绿色 (`#5ec26f`)、自定义头衔灰色 (`#aaaaaa`)。**无头衔普通群友严禁凭空伪造「群员」标签，必须留空不绘制**；
  - **Telegram Premium 会员 Emoji 状态**：普通 `User` 对象不携带该字段，必须调用 `bot.get_chat(user_id)` 提取 `emoji_status_custom_emoji_id` 与 `accent_color_id`；
  - **媒体与动图还原**：被引用消息为贴纸或图片时，静态贴纸原样还原，动图/视频贴纸提取官方缩略图定格首帧，严禁使用 `[贴纸]` 纯文本占位符；
  - **`qh` 上下文气泡渲染前置条件与文本补全**：Node.js quote-api 底层要求 `message.replyMessage.name` 和 `message.replyMessage.text` **两者必须同时非空**才会触发绘制二级引用气泡。若被引用对象是纯贴纸/纯图片且没有附言文本，必须自动补上 `[贴纸 🎯]`（携带贴纸 emoji）或 `[图片]` 占位，严禁留空或传 `None`，否则整个 `replyMessage` 会被静默吞掉退化为单人气泡；
  - **双轨消息链持久化与 SQLite 深度回溯**：Telegram Bot API 的 `reply_to_message` 往往只携带直接被回复的对象，无法跨层级拿到爷爷辈/父级历史。若仅依赖内存 `MESSAGE_META_CACHE`，一旦进程重启或内存淘汰，`qh` 将彻底失联退化。必须在 `messages` 表同步持久化 `reply_to_msg_id`、`reply_to_user_name` 与 `media_file_id`，在查询父级关联时实现「内存优先 + SQLite 深度回溯」双轨兜底，并在服务启动时从 SQLite 预热历史消息队列；
  - **别人贴图作为 Q 图主体的识别与首帧抽取**：针对回复别人贴图直接发 `q`，若为静态 WebP 贴纸直接通过 `get_file` 取原图；若为 WebM / TGS 动态贴纸，优先使用官方 thumbnail，若无 thumbnail 则调用本地 FFmpeg 抽取第一帧 PNG 缓冲，以 `data:image/png;base64` 传入 `media` 字段，实现对方专属头像+贴图本体的高保真名言贴纸；
  - **高保真当前实时生效头像获取陷阱 (`user_chat.photo` vs `getUserProfilePhotos`)**：
    - **痛点现象**：Q 图识别出的头像是群友完全陌生的旧照片、历史相册照片或备选公开照片（如历史雕像），群友和管理员反馈“头像错的/不知道哪来的”；
    - **根因分析**：
      1. Telegram 允许用户个人资料保留多张头像相册历史（Carousel）或设置备用公开照片（Public Photo）；
      2. 若调用 `bot.get_user_profile_photos(user_id, limit=1)` 并取 `photos.photos[0]`，在 Telegram 数据结构中它仅仅是相册列表的索引 0，当用户从相册回选过旧头像当主头、或设置过多张头像时，`photos[0]` **并不是**当前正在聊天生效的主头像；
      3. Telegram 官方**唯一能 100% 保证反映用户在群聊与聊天列表中实时生效主头像**的字段，是 `bot.get_chat(user_id)`（返回 `ChatFullInfo`）中的 `user_chat.photo.big_file_id`；
    - **架构解决方案**：
      - 在拉取头像时，**必须绝对优先读取并下载 `user_chat.photo.big_file_id`**，保证 100% 与群内实时渲染视觉对齐；
      - 仅当 `user_chat.photo` 为空（如用户设置了严格隐私保护隐藏头像、或接口受限）时，才回退尝试 `get_user_profile_photos` 作为兜底；
      - 这样不仅消灭了头像错位 Bug，还直接省掉一次 Telegram API 往返请求（降低贴纸生成延时）。
- **贴纸包满 120 张自动扩容**：
  - 命名规范：`g_{chat_id}_by_{bot_username}`，满 120 张时自动升级为 `g_{chat_id}_2_by_{bot_username}`，标题追加 `(Vol 2)`，确保容量无上限。
- **贴纸包创建与触发前置条件**：
  - 必须去 `@BotFather` 执行 `/setprivacy` -> 设置为 `Disable`，否则单字母 `q`/`qs` 不会被 Bot 接收；
  - 机器人 Owner 必须先在私聊中向 Bot 发送一次 `/start` 激活授权，否则创建贴纸包会因 `PEER_ID_INVALID` / `USER_NOT_FOUND` 报错拦截；
  - 独立脱敏部署模板见 `templates/standalone-quote-bot.py`，脱敏自检探针脚本见 `scripts/verify_desensitization.py`（配套一键脚本与文档在 `/home/ubuntu/tg-quote-sticker/`）。
- **对外分享与开源发布时的 4 级静态脱敏审计规范**：
  - **切忌直接打包原有 Git 仓库**：严禁直接 zip 包含 `.git` 目录的代码库，防止黑产通过 `git log -p` 回溯提取历史 commit 中曾遗留的 Bot Token、私人 ID 或私钥；必须另建全新独立目录重写/复制纯净代码；
  - **参数收敛与占位符规范**：所有敏感配置（Token、Owner ID、Webhook、自建服务端点）严格收敛至环境变量（`os.getenv`）与 `.env.example`，示例填入显式假数据（如 `<YOUR_USER_IDENTIFIER>:ABCdef...`），代码绝不设真实 fallback；
  - **4 级自动化静态安全探针**：
    1. 敏感专有标识扫描（Owner TG ID、关联 Bot ID、关联手机号、私有反代域名与别名）；
    2. 非本地回环公网 IP 正则扫描（排除 `127.0.0.1` 和 `0.0.0.0`，扫描所有公网 IPv4）；
    3. Telegram Bot Token 格式正则扫描（`\b\d{8,11}:[a-zA-Z0-9_-]{30,}\b`）；
    4. 部署宿主机绝对路径与用户名扫描（避免暴露 `/home/<user>`、内网映射路径）。

---

### 2. 当前音乐与视频中转（2026-10-16 核对）

- 当前生产为 relay-only；先查 `handlers/messages.py`、`race_adapter.py`、`relay_adapter.py`、`relay_core.py`、`race_video_parts.py` 及现行中转配置，不把历史原生路径当兜底。
- race_adapter 只登记 relay producer。中转失败明确报错、保留原链接，不启动 AWS 下载、转码或旧 services/video_service.py。
- 排队、超时、取消和最终投递以持久任务记录为准；已有任务或投递未确认时先查记录，不盲目重试造成重复发片。
- 核对 Bot、群、请求和结果身份；提交/回传前复核授权、功能开关和任务归属，不跨 Bot 复用未经当前 Bot 验证的 file_id。
- 多段结果核对完整段数、顺序、标题、字幕、来源及幂等边界。部分成功和未确认结果不能报整单成功。
- AWS 控制请求和 Telegram 投递可能仍有流量；中转不代表全系统绝对零流量。重下载/转码留在已有非 AWS 生产端，不新增常驻服务。
- 改动后检查两台 Bot 同版本及配置语义；回归 q/qs、AI、总结、模型切换、权限/私聊面板、定时错峰，以及单视频、多段视频、音乐中转。
- 只有明确恢复请求才读 `references/legacy-native-media-archive.md` 并另行审计；独立 Worker 设计也在该历史参考，不代表活动路由。

### 9. Owner 联系提醒：Bot 被拉进群 / 陌生人私聊 (Owner Contact Alerts)

> 实现模板、stdlib 裸轮询 Bot（广告杀手）变体、踩坑见 `references/owner-contact-alerts.md`；投递验收用 `scripts/verify_contact_alerts.py`（真实 token + 假 update 直调 handler，**不要**为测试另开 UserBot 会话）。

- **触发场景**：任何自建 Bot（群霸双 Bot、运维 Bot、广告杀手）被拉进/移出群，或陌生人私聊它时，给 Owner 发一条提醒。Owner 的诉求是"有人碰我的 Bot 我要立刻知道"，**不是让对方收到任何回复**。
- **架构铁律：独立只读观察 handler，不改业务分流**。用 PTB 单独 handler 组（`group=-1`）挂两个入口，绝不塞进 `handle_group_message` / 指令处理里：
  - `ChatMemberHandler(alert_my_chat_member, ChatMemberHandler.MY_CHAT_MEMBER)`：只处理 **Bot 自身**的成员变更（`old in {left,kicked} and new in {member,administrator}` = 被加入；反向 = 被移出）；`CHAT_MEMBER`（别人的角色变更，已有 audit handler）不要混进来。
  - `MessageHandler(filters.ChatType.PRIVATE & ~filters.User(OWNER_ID), alert_private_message)`：`~filters.User(OWNER_ID)` 必须加，否则 Owner 自己私聊也会被提醒；handler 内再挡 `user.is_bot`。
- **防刷屏**：同一用户 10 分钟冷却，冷却期内只累计 `suppressed` 计数，下次提醒回显"冷却期内另有 N 条未逐条提醒"；状态字典上限 500，超限按最旧淘汰。纯内存即可，重启归零可接受。
- **提醒内容**：Bot 名、群名、群 ID（`<code>`）、操作人（名字+@用户名+数字 ID）、授权状态、北京时间。未授权群被添加时附"确认可信后私聊发 `/auth <群ID>`"——`cmd_auth` 确实支持私聊带 chat_id 参数。
- **双 Bot 共用一份代码**：`lemon-group-bot` 与 `lemon-group-bot2` 的 `WorkingDirectory`/`ExecStart` 完全相同，靠 systemd `Environment=TELEGRAM_BOT_TOKEN=...` 区分身份，`BOT_ID` 由 token 前缀推导。**改一次 `bot.py` 覆盖两台，但必须同时 restart 两个 service**。
- **文案排版**：Bot 消息用 HTML `parse_mode`，ID/指令一律 `<code>` 包裹，昵称经 `html.escape` 截断（200 字），`link_preview_options={"is_disabled": True}`；成功路径必须打 `logger.info`，否则事后无法从日志证明提醒真的发出去了。
- **铺开前先做“有没有必要”判断，不要默认全量铺开**。Owner 问「其他几个 Bot 有必要吗」时，要的是逐台结论而不是全部加上。判断依据（现行舰队实测清单见 `references/owner-contact-alerts.md` 第 5 节）：
  - **是 PTB / 裸 getUpdates 的 Bot** → 可加；**是 Telethon 人形号（UserBot）** → 不加：账号没有 `my_chat_member` 事件，要挂 Telethon 事件并重启人形号，风控与收益不成正比，被拉进陌生群更适合做每日会话审计。
  - **对外服务型 Bot（如 subinfo 订阅查询）** → 只报“被拉进群”，私聊改报“新用户首次”，因为陌生人私聊本就是它的业务入口，逐条提醒会淹没 Owner。
  - **非 Telegram Bot**（gateway / web-ui / MTProto 代理 mtg / API 服务 / subconverter）与其子进程（cleanup-worker、admission UI）→ 无此事件，直接排除。
  - 结论式回答（“只有 X 有必要，其余不用加”）优先于罗列，符合 Owner 的反过度设计偏好。

### 4. 各群独立功能开关控制面板 (/settings)
- **控制维度**：
  - `quote`（名言贴纸）、`ai`（AI 问答）、`summary`（群总结）、`video`（视频去水印）、`music`（音乐点播）、`mute`（禁言风控）；
- **操作与权限隔离**：
  - 群内仅限 **机器人 Owner、本群群主 (Creator)、及授权 VIP** 可唤出并点击开关；
  - 面板按钮带实时状态指示灯（`🟢 开启中` ↔ `🔴 已关闭`），点击原地热切换；
  - 支持私聊远程遥控：Owner 私聊 `/settings` 列出所有已授权群组，隔空管理；
  - 陌生人私聊仅可见 `/help`，其余指令底层静默丢弃，防爆破与恶意刷屏。

---

### 7. 群聊定时总结与 `#总结` 标签归类架构 (Scheduled Summary & Topic Tagging)
- **业务诉求与设计理念**：
  - 总结卡片开头必须加上 `#总结` 话题标签，群友点击标签或在 Telegram 搜索栏输入 `#总结` 即可秒级串联群内所有历史总结，不破坏原生 `<details><summary>` 小三角折叠卡片视觉；
  - 允许自定义每天固定时间点（如 `22:00`、`12:00,22:00`）或循环周期（如每 `4h`）自动总结群内过去具体几个小时（如过去 `4h` 或 `6h`）的发言；
  - 提供指令（`/autosum`）与控制台（`/settings` 二级交互面板）双轨操作，兼顾群内管理与 Owner 私聊大盘遥控。
- **双轨控制形态与指令规范**：
  - **群内指令**：
    - `/autosum`：查看本群当前定时总结规则、上次执行时间与预计下次触发时间；
    - `/autosum 22:00 4h`：每天北京时间 22:00 自动总结过去 4 小时发言；
    - `/autosum 12:00,22:00 6h`：每天 12:00 与 22:00 分别总结过去 6 小时发言；
    - `/autosum 4h 4h`（或 `/autosum 每4小时 4h`）：每隔 4 小时自动总结过去 4 小时发言；
    - `/autosum test`：立即测试触发一次定时总结并投递到群内；
    - `/autosum off`（或 `0`）：关闭本群定时总结；
    - 自然语言捕获：支持群内直接输入 `定时总结 22:00 4h` 或 `自动总结 22:00 4h`。
  - **`/settings` 交互式二级面板**：
    - 集成 `⏰ 定时发言总结` 独立二级菜单，预设常用方案按钮：`🌙 每天 22:00 (前4h)`、`🌙 每天 23:00 (前6h)`、`☀️🌙 每天 12:00&22:00 (前6h)`、`🔄 4h整点循环`、`🔄 6h整点循环`、`🔄 8h循环 (7/15/23点)`、`⚡ 立即测试触发一次`、`🛑 关闭定时总结`；
  - **Owner 私聊大盘遥控**：
    - 私聊输入 `/autosum` 调出全部已授权群组的定时总结状态大盘及配置按钮，支持隔空配置 `/autosum <chat_id> 22:00 4h`。
- **周期循环定时任务的时钟整点对齐规范 (Integer Clock Alignment Pitfall)**：
  - **痛点现象**：若循环调度采用相对当前点击时刻简单累加（`last_run + interval`），当管理员在非整点（如 23:40）点击“8小时循环”时，后续触发时刻将永久滞留在非整数时间点（如 `07:40`、`15:40`、`23:40`），引发群友与管理员“时间点不是整数”、“为什么不是整点总结”的困惑；
  - **设计准则**：在 Telegram 群管定时任务设计中，所有循环类预设必须**默认对齐到自然时钟整点（00 分）**，底层统一映射为确定性时刻列表（`daily_time`）：
    - **8h 循环**：严格锁定 `["07:00", "15:00", "23:00"]`（早 7 点查阅夜间讨论、下午 15 点查阅上午、晚 23 点查阅下午及晚间，完美对齐社群作息）；
    - **6h 循环**：严格锁定 `["00:00", "06:00", "12:00", "18:00"]`；
    - **4h 循环**：严格锁定 `["00:00", "04:00", "08:00", "12:00", "16:00", "20:00"]`；
  - 杜绝任意分钟漂移，让管理员和群友对总结触发时刻（如“明日 07:00”）具备 100% 确定预期。
- **后台调度与防重复执行机制 (`services/scheduler_service.py`)**：
  - **时区标准**：严格对齐北京时间 (UTC+8)；
  - **槽位幂等防重跑 (`last_run_slot`)**：每天固定点模式记录 `YYYY-MM-DD_HH:MM` 时间槽（如 `2026-09-13_22:00`），并在触发判定时比对；只有未跑过的槽位才进入执行逻辑，彻底防止 30 秒轮询重复触发；
  - **样本保护与静默防刷屏**：回溯窗口内若有效发言少于 3 条，调度器自动静默跳过（不向群内发送冷启动或空白总结刷屏），测试模式 (`is_test=True`) 则明确回显样本不足提示；
  - **排版与通道保底**：优先走 `sendRichMessage` 投递原生折叠小三角卡片，超长自动拆包分段（`split_summary_chunks`），富文本不可用时保底转换为 HTML `blockquote expandable` 发送。

---

### 8. 大模型多级自动降级容错与动态调度中心 (LLM Fallback & Dynamic Model Center)

> 完整实现细节与踩坑排障见 `references/dynamic-llm-pool-and-scheduled-summary.md`
> 「/sum 失败但别人成功」的 LLM 节点超时定位与节点实时测活，见 `references/group-summary-troubleshooting.md` 第 0 节；「加了兜底反而更容易失败」的候选窗口截断陷阱见 0.1 节，一键链路体检用 `scripts/probe_ai_chain.py`。

- **业务诉求与去中心化自愈**：群内 `ai` 问答与 `/sum` 群聊总结要求极速响应与高可用。中转站（LFree）主用保证速度与高并发，反重力（Gemini 3.8）等作为稳健兜底；同时必须让机器人拥有者具备**脱离服务器终端也能在 Telegram 内随时换心换脑、换 API Key、改模型代号、添加第三方 API 端点的能力**。
- **双 Bot 混合解耦架构（API 池子全域统一共享，各 Bot 具体模型与优先级完全独立）**：
  - **统一 API 端点池 (`data/ai_endpoints.json`)**：
    - 集中保管所有接口地址（URL）、API Key 与预置默认模型；
    - 爸爸在任一 Bot 发送 `/setapi` 或 `/setkey` 录入新凭据后，**两台 Bot 自动同步享用同一套底座连接池**，绝不需反复录入两次；
  - **分 Bot 独立模型调度 (`data/ai_bot_{BOT_ID}.json`)**：
    - 各 Bot 独立维护自身的 `order`（首选与兜底顺序）、`disabled_nodes`（专属停用开关）与 `model_overrides`（专属模型代号定制）；
    - 主 Bot (`@<PRIVATE_IDENTIFIER>_bot`) 可以在 `/model` 面板把 `LFree·Claude` 设为首选主用；
    - 分身 Bot (`@<PRIVATE_IDENTIFIER>_bot`) 可以在 `/model` 面板把 `反重力·Gemini3.8` 或 `日日新·DeepSeek` 设为首选主用；
    - 某端切换主用模型或修改模型代号（`/setmodel`），**100% 仅对当前 Bot 生效，互不干扰**；
  - **Telegram 原生私聊控制面板 (`/model`)**：
    - 面板顶部动态回显当前操作的 Bot 身份（如 `主 Bot (@<PRIVATE_IDENTIFIER>_bot)` 或 `分身 Bot (@<PRIVATE_IDENTIFIER>_bot)`）；
    - 大盘展示当前 Bot 的完整调用链顺位（1. 👑 首选主用，2. 🛡️ 备用兜底...）；
    - `⚡ 一键全节点测活`：并发 Ping 全部节点（轻量 user "ping" 提示词，max_tokens=5），实时回显各节点毫秒延迟与 HTTP 状态（如 `200 OK (1.8s)`、`429 配额耗尽`、`504 超时`）；
    - 单节点详情面板：点击对应节点按钮，支持【🌟 置顶此节点为主用】、【启停开关】、【单独测活】与【删除自定义节点】；
  - **私聊指令动态热配置与密钥安全自动秒删**：
    - `/setapi <ID> <URL> <KEY> <MODEL> [中文名称]`：向统一池新增/更新端点，并在当前 Bot 置顶为主用；
    - `/setkey <ID> <新Key>`：同步更新统一池中该节点的 API Key；
    - `/setmodel <ID> <新模型名>`：为当前 Bot 单独修改该节点的模型代号；
    - `/delapi <ID>`：从统一池删除自定义节点；
    - **严格敏感信息安全防御**：Bot 接收到包含明文 Key 的 `/setapi` 或 `/setkey` 后，**自动立即秒删该消息**，回显时对 Key 实施前四后四掩码保护（`sk-xxx...xxxx`），绝不让明文密钥留在 Telegram 聊天记录中。
- **环境隔离与密钥读取**：在 `services/ai_service.py` 中实现 `_read_env_val`，优先读取环境变量，未传时自动回退读取 `/home/ubuntu/.hermes/.env`，兼顾 systemd 守护进程与独立运行环境；请求头必须携带标准浏览器 `User-Agent` 防 WAF 拦截；
- **配置热生效铁律（改 JSON vs 改代码，2026-10 实测）**：`data/ai_bot_{BOT_ID}.json` 与 `data/ai_endpoints.json` 是纯 JSON 配置，`load_ai_nodes` → `_read_ai_json` 每次调用直接从文件 `json.load`（无内存缓存），**改完立即热生效、无需重启服务**；只有改 `.py` 代码才要 `systemctl restart lemon-group-bot.service`（及 bot2）。切勿为了改 `order`/`disabled_nodes` 去重启服务。`data/ai_timeout_overrides.json` 同样按 mtime 缓存热生效，用于按节点临时调超时（形如 `{"tengbaipiao": {"large": 30.0}}`），是上游劣化时做临时降级/自动还原的首选载体——比硬编码或改 `.py` 安全得多。注意首节点实际超时仍被 `min(配置值, remaining/slots)` 压到约 24.8s，**把配置调到 35s 对第一位节点无效**，只对后续槽位生效。节点 key 解析规则：`ep.get("key") or _read_env_val(ep["key_env"])`，故 `key` 字段为空但带 `key_env`（如 `DDDAI_API_KEY`/`GEMINI_OFFICIAL_API_KEY`）的节点 key 实际存在 `/home/ubuntu/.hermes/.env`，别误判为「无 key」。**新增兜底节点 runbook**（测活禁用节点、`403`=模型名失效勿加回、稳定节点提前/不稳定远程压后、双 Bot 需分别改 `ai_bot_{BOT_ID}.json`）要点已在上文内联，完整架构见 `references/dynamic-llm-pool-and-scheduled-summary.md`。
- **候选窗口硬上限（`MAX_CHAIN_ATTEMPTS`，2026-10-20 实测踩坑，已由 4 上调至 7）**：`candidates = chain[:MAX_CHAIN_ATTEMPTS]`，**生效链路（`order` 减去 `disabled_nodes`）窗口外的节点永远不会被调用**；群总结属大请求（`max_tokens>=2000`）→ `max_attempts=3`、总预算 75s，节点预算按 `remaining / 剩余槽位` 动态切分。两个致命推论：
  - 往 `order` 前几位插新兜底会把原本健康的节点挤出窗口，表现为「加了兜底反而稳定失败、每次耗时固定 ~70s」；
  - **429/401 这类快速失败只花 0.02~1s 就吃掉一个候选槽**，4 格窗口可能在总预算还剩 50s 时就被耗尽，后面全健康的节点一个都轮不到 —— 所以窗口宽度必须大于「已知会快速失败的节点数 + 需要真正兜底的节点数」。
  - 现行值：`services/ai_limits.py` 的 `MAX_CHAIN_ATTEMPTS = 7`（2026-10-20 由 4 上调，等于启用节点总数，使末位节点不再永远落在窗口外；双 Bot 重启后实测生效）。**窗口宽度只决定“可尝试范围”，不放大尝试次数**——`max_attempts` 仍是 `min(7, 3 大请求 / 2 普通)`，所以调大不会多打上游请求。该常量是 `.py` 代码，改完**必须** `systemctl restart` 两个 Bot，改 JSON 的 order 才不需要重启。
  - 扩链/调序前先跑 `scripts/probe_ai_chain.py` 打印候选窗口（脚本直接从 `ai_limits.py` 读真实上限，不写死）；链路改完用 `scripts/verify_summary_chain.py` 跑真实群消息端到端验收。判读与处置见 `references/group-summary-troubleshooting.md` 0.1，节点增删 runbook 见 `references/dynamic-llm-pool-and-scheduled-summary.md` 第 4 节。
- **透明反馈**：若所有节点均耗尽，发送自毁临时提示明确告知原因，绝不静默装死；
- **深度思考（Thinking/CoT）模型总结泄露与双重过滤防御规范**：
- **痛点与现象**：当调用带 Thinking/Reasoning 机制的模型（如 `gemini-3.8-flash-high`、Claude Thinking、DeepSeek-R1）执行群聊总结或 AI 问答时，模型不仅会在正文前吐出自言自语的分析草稿（例如“分析106条消息...梳理...这话题值得单独”），还会主动将自身推理过程包装为 `<details><summary>💭 思考与分析思路</summary>...</details>` 等看似合法的折叠卡片，直接随正式总结一起发送到群公屏；
- **根本原因**：普通正则仅过滤了显式 `<think>` 标签，大模型自己起带有“思考/思维/分析思路”等标题的业务卡片，或者在卡片之前裸打草稿分析，会直接穿透放行；
- **加固与防护闭环**：
  1. **System Prompt 绝对红线**：在 `SUMMARY_SYSTEM_PROMPT` 的格式红线中明确：*“严禁输出任何思考过程、思维链、分析草稿或自言自语（严禁输出 <think>、<thought> 或以思考/思维为标题的卡片）！直接输出纯净的 <details><summary> 业务卡片语法。”*
  2. **后置全量清洗与硬斩断 (`_clean_card_content`)**：
     - 显式标签剥离扩充：包含 `<think>`、`<thought>`、`<thinking>`、`<reasoning>`、`<reason>` 及其代码块；
     - 伪装卡片深度正则剔除：正则匹配 summary 包含 `思考|思维|thought|thinking|reasoning|思路梳理|分析思路|分析过程|分析记录|推理|推导|内心OS|思维链|Chain-of-thought|CoT` 的 `<details>` 整体剥除；
     - 严格业务卡片前置锚定：以前置首个合法业务 `<details>` 为界斩除其前所有字符（彻底清除任何前置分析草稿），从最后一个 `</details>` 斩除其后杂质；
  3. **修改代码后双 Bot 必须全部热重启生效**：修改 `ai_service.py` 后必须同时执行 `sudo systemctl restart lemon-group-bot.service` 与 `sudo systemctl restart lemon-group-bot2.service` 并校验 status 处于 `active (running)`，杜绝分身 Bot 漏重载导致线上故障。
- **Telegram 原生富文本降级死穴与 HTML 转义吞字避坑 (Rich Message Fallback & HTML Escaping Traps)**：
  - **痛点现象 A（总结/回答发送失败）**：`sendRichMessage` 发生 `Rich_message_content_required` 等偶发错误触发降级时，由于直接使用 `send_message(parse_mode=HTML)` 投递带原生 `<details>` 的文本，Telegram 报 `Can't parse entities: unsupported start tag "details"` 导致发送彻底崩溃；
  - **解决方案 A**：在总结与群聊 AI 问答的所有降级链路中，强制执行双层转换：正则将 `<details>\s*<summary>(.*?)</summary>(.*?)</details>` 替换为 Telegram 官方原生支持的 `<blockquote expandable><b>\1</b>\2</blockquote>`，并将 `**粗体**` 转为 `<b>`、Markdown 链接转为 `<a>`，最后全量剔除任何未匹配的残留 `</?(?:details|summary)[^>]*>` 孤立标签；
  - **痛点现象 B（文字丢失与悬空连续顿号）**：向 Telegram 发送包含技术标签（如解释 `<think>`、`<thought>`、`<details>` 等）的通报或消息时，未用行内代码块包裹或实体转义，Telegram 解析器直接将其当做非法的自定义 HTML 标签并静默隐藏，原本的文本在手机端呈现为诡异的连续悬空顿号（如 `、、、、<reason>`），排版彻底损毁；
  - **解决方案 B**：在任何向 Telegram 客户端汇报的消息中，凡涉及 HTML 标签名、正则符号或变量，必须严格放入行内反引号代码块或转义为 `&lt;tag&gt;`，严禁在常规文本中裸打裸发尖括号；同时避免滥用 Markdown 多级列表混杂导致语法符号原样暴露。

---

### 6. 群聊禁言风控与 Telegram `restrictChatMember` 解禁反弹陷阱 (Mute & Unmute Protocol)
- **指令矩阵**：
  - `/mute [时长]` 或回复某人发 `禁言`：禁言目标成员（默认 10 分钟，支持 `10m`, `2h`, `1d`）；
  - `/unmute` 或回复某人发 `解禁`：立即解除目标成员禁言，恢复全量发言权限。
- **权限边界与安全底线**：
  - 严格限制：仅限机器人拥有者（Owner）、本群群主（Creator）、以及当前群授权特权人员（VIP）可触发；
  - 防越权保护：严禁禁言 Owner、全局 VIP，以及本群群主（接口拦截）。
- **Telegram 底层解禁反弹隐形陷阱 (The Partial Unmute Trap & Rebound Bug)**：
  - **痛点现象**：管理员对群友执行 `/mute` 后，又使用 `/unmute` 解除禁言；群友当即可以发送简短文本，但**过了一段时间后（或客户端重连/数据中心同步/群权限刷新时），群友的发言框再次被锁死，禁言再次复发**！
  - **根本原因剖析**：
    1. Telegram Bot API 官方并没有单独的 `unrestrictChatMember` 接口，解禁必须依然调用 `restrictChatMember`；
    2. **官方协议强制准则**：*“Pass True for all boolean parameters to lift restrictions from a user.”*（要彻底解除限制，必须对所有布尔权限传入 True）；
    3. 若代码在解禁时仅手动构造常见发信权限（如仅设置 `can_send_messages=True` 等 10 项，遗漏了 `can_change_info`, `can_invite_users`, `can_manage_topics`, `can_pin_messages`）：
       - Telegram 服务端会**判定该用户的限制并未解除**，该群友在群组中的身份依然被死锁在 `ChatMemberStatus.RESTRICTED`（受限成员黑名单中）；
       - 由于解禁未显式传递合法的 `until_date`，Telegram 会将未放行项默认为 `until_date: 0`（永久受限）；
       - 一旦群友客户端刷新、与 DC 重新同步群成员元数据，客户端便会重新将该用户判定为受限，造成输入框再次锁死的“禁言反弹”假象；
  - **标准解决方案**：
    - 在解禁逻辑中，**绝对不要手动拼凑部分权限字典**；
    - **必须且只能传入 `ChatPermissions.all_permissions()`**：
      ```python
      # 正确范式：全量权限置为 True，彻底使 Telegram 服务端清除限制
      await bot.restrict_chat_member(
          chat_id=chat.id,
          user_id=target_user_id,
          permissions=ChatPermissions.all_permissions()
      )
      ```
    - 执行后，用户的 Telegram 身份将从 `ChatMemberStatus.RESTRICTED` 真正彻底复位为正常普通成员 `ChatMemberStatus.MEMBER`，`until_date` 变回 `None`，从协议层面彻底消除反弹隐患。
- **限时禁言到期 ≠ 自动解禁（第二个独立反弹元凶，2026-09-13 实测实锤）**：
  - 现象：群友被 `/mute 10m` 等限时禁言后，管理员从未来得及调用 unmute，但**禁言时长到期后群友依然发不出消息**，体感「禁言又触发了」；
  - 底层真相：Telegram `restrictChatMember` 带 `until_date` 到期后**并不会自动把成员恢复为全权限 member**——服务端只是把 `until_date` 置为 epoch 0（`1970-01-01`），成员身份停留 `ChatMemberStatus.RESTRICTED`，权限保持禁言时的全 False 值，直到有人显式下发 `all_permissions()` 才解除；
  - 实测案例：群友 `<YOUR_USER_IDENTIFIER>` 凌晨被默认 10 分钟禁言，数小时后 `get_chat_member` 仍返回 `restricted` + `until_date=1970-01-01`，显式调用 `ChatPermissions.all_permissions()` 后才复位为 `member`；
  - **运维体检/自愈模式**：Bot API 没有枚举群成员的接口（无 getChatMembers），排查「禁言反弹/成员被卡死」时，用 `bot.db` 的 `messages` 表按 `chat_id` 取最近活跃的 `DISTINCT user_id` 作为待检名单（可叠加已知活跃群友 ID 补充），逐个 `get_chat_member` 扫描 `status=restricted` 且 `until_date` 为 epoch 0 的残留受限成员，凡命中一律 `restrict_chat_member(permissions=ChatPermissions.all_permissions())` 修复并复查状态翻转回 `member/None`；建议做成 Bot 启动自检或定时巡检；
  - **排障提示**：群友发「禁言/解禁」文字指令但**没有回复目标消息**时，Bot 只弹一条使用提示就 return，**不产生任何 `execute_mute` 日志**——群友报「Bot 没反应/出bug了」且日志空白时优先怀疑这个，而不是进程故障；
  - **只读审计禁止动 UserBot session（实测）**：仅查询成员/限制状态时，Bot API（`get_chat_member` / `get_chat_administrators` + 本地 `bot.db` 的活跃成员名单）完全够用且零风险；**不要**为了只读检查去复制正在使用的 `.session` 开第二个客户端——同 auth_key 并发有 `AuthKeyDuplicatedError` 风控隐患，且复制会话往往 `get_dialogs` 找不到目标群（该群不在 UserBot 对话框列表时直接返回空），纯属多余动作。
  - **一键体检/修复脚本**见 `scripts/audit_restricted_members.py`（复用 `lemon-group-bot` 项目 venv 与 config，扫描活跃成员，`--fix` 自动修复残留受限）。
