---
name: telegram-group-bot-suite
description: "构建与运维 Telegram 全能群聊机器人：多卷贴图、音乐点播与群开关、多实例复刻。"
version: 1.2.1
author: Hermes Agent
license: MIT
platforms: [linux, macos]
metadata:
  hermes:
    tags: [telegram, bot, quote-api, sticker, music, netease, group-bot]
    related_skills: [telegram-quote-sticker, telegram-group-assistant]
---

# Telegram 群聊全能管家系统架构与运维规范 (Telegram Group Bot Suite)

## When to Use
- 在 Telegram 构建或维护全能群聊机器人（如「群霸项目」）；
- 实现高保真 Q 图贴纸生成（支持 `q`、`qh`、`q N` 正负向提取、会员 Emoji 状态图标、群主紫/管理绿/群员灰三色标签、同人连续合并单头像）；
- 实现贴纸入库（`qs`）带包按钮、贴纸删除（`qd`）与贴纸包满 120 张自动扩容多卷（Vol.2, Vol.3）；
- 实现网易云音乐点播与解析（`/music 歌名/ID/链接`、Top 5 交互式数字点播、官方直链 + B站 Hi-Res 专线中继双轨兜底）；
- 搭建**音乐库预热缓存架构**（廉价 VPS 离线爬取转码 → Telegram 频道中转 → 主站 0 流量 `file_id` 秒发；含**群友点播自动沉淀回预热库**，实现跨群、跨平台归一化秒级复用，用于破解主站出网流量限额与点歌速度瓶颈）；
- 实现群聊智能总结与排障重构（彻底根治“太假”与“对应不上”：双轨持久化防重启断层、非线性回复链与时间戳注入、去八股化自适应 Prompt、来源直链精准对齐；**统一开头注入 `#总结` 标签；支持 `/autosum` 与 `/settings` 二级面板定时总结前 N 小时发言**）；
- 实现各群功能独立开关控制面板（`/settings`、实时指示灯、零公网端口暴露防爆破）。

---

## 核心功能模块与指令设计

### 1. 贴图与多卷贴纸包管理 (q / qh / qs / qd)
- **指令矩阵**：
  - `q`：单人金句贴纸，无回复头直发，秒删触发指令；
  - `qh`：带上一级回复历史的嵌套引用气泡（带原媒体缩略图）；
  - `q N`（如 `q 3`）：以被回复消息为起点【向下】顺延合并 3 条连续发言；
  - `q -N`（如 `q -3`）：以被回复消息为终点【向上】回溯合并 3 条连续发言；
  - `qs`：将名言或现有贴纸收录进本群专属贴纸包（**收录成功后仅发送带跳转链接与按钮的卡片，禁止重复发送贴纸原图刷屏**）；
  - `qd`：长按回复想要删除的贴纸发 `/qd`，校验管理员/群主/VIP权限后调取 `deleteStickerFromSet` 彻底注销移除，并即时使贴纸缓存失效；
  - `autosticker`：群聊发言活跃度自动随机发送贴图机制（支持群内 `/autosticker N`、`/settings` 二级面板预设点击切换，以及 Owner 私聊全局遥控）。
- **群聊活跃度随机贴纸池架构 (Autosticker Activity Trigger & Dynamic Pool)**：
  - **业务场景**：群聊活跃时，根据群内发言数量阈值（如每 50 条群友发言）自动从本群专属贴纸包（或群原生关联贴纸包）中随机抽取一张贴纸发送，提升互动趣味性；
  - **贴纸提取与多卷扫描**：
    - 优先扫描本群专属贴纸包 `g_{clean_id}_by_{bot_username}` 及其多卷扩容包 (`Vol.2`..`Vol.N`)；
    - 若专属贴纸包为空，自动回退探测群聊原生绑定的 `chat.sticker_set_name`；
    - 贴纸 `file_id` 列表使用 5 分钟内存热缓存 (`_STICKER_CACHE`)，避免高频请求 Telegram Bot API 导致限流；
    - 在 `qs` 录入新贴纸或 `qd` 删除贴纸后，必须显式调用 `invalidate_group_sticker_cache(chat_id)` 即时刷新池子；
  - **发言计数与安全过滤**：
    - 非指令正常发言触发 `increment_group_message_count`；
    - 达到阈值后原子重置计数器并异步投递 `send_sticker`；
  - **多维操控入口**：
    - 群内指令：`/autosticker [数量]`（`0` 或 `off` 为关闭，无参数查看当前进度）；
    - `/settings` 控制面板：集成 `🎲 活跃度随机贴纸` 专属二级菜单，提供常用预设按钮（`20/30/50/80/100/200条`）与一键开关；
    - 私聊远程控制：Owner 私聊 `/autosticker` 查看所有群组大盘，支持隔空配置 `/autosticker <chat_id> <数量>`。
- **贴图与回复链核心避坑点 (Quote & Reply Chain Pitfalls)**：
  - **严格区分 `q` 与 `qh` 语义边界**：
    - `q`：单人金句贴纸，**绝对不带二级引用气泡**，纯粹突出被回复者的单人发言；
    - `qh`：带上文历史贴纸，**强制启动四级穿透回溯并渲染二级气泡**；
  - **Telegram Bot API 嵌套回复剥离与 `qh` 四级深度穿透体系**：
    - 官方协议陷阱：Telegram Bot API 在向机器人推送消息时，被回复消息对象的 `reply_to_message.reply_to_message` **恒为 None**（官方防止对象无限递归截断）；
    - 若纯靠内存记录消息链，重启或淘汰后 `reply_obj` 丢失，导致 `qh` 惨遭降级为单人贴纸；
    - **双轨四级回溯方案**：
      1. 路径 A：探测原生 `reply_target.reply_to_message`；
      2. 路径 B：从 SQLite `messages` 表依据 `reply_to_msg_id` 秒级深度回溯出真实被引用者 ID、昵称、正文与 `media_file_id`；
      3. 路径 C：提取 Telegram 7.0+ 原生文本引用（`msg.quote` / `external_reply`）；
      4. 路径 D：若目标发言未显式绑定回复链但群友发了 `qh`，兜底抓取群内**紧邻的前一条正常发言**作为对话上下文，保证 100% 输出双层气泡；
  - **全量消息持久化闭环（含纯媒体/贴纸）**：群友发送纯贴纸或纯图片时，也必须打上 `[贴纸 💬]` / `[图片]` 存入 SQLite `messages` 表，杜绝多媒体回复链溯源断层；
  - **服务热重载铁律**：修改 Python 或 Node.js 模块代码后，必须显式触发 `systemctl restart lemon-group-bot.service` 重载服务，严禁在旧进程依然运行时提前报告完成；
  - **同人连续合并与多人多头像 (`chatId`)**：Node.js quote-api 底层对比 `msg[i-1].chatId === msg[i].chatId`。若消息未在外层显式携带 `chatId`，在 JS 中 `undefined === undefined` 恒为 `true`，会导致不同群友发言的头像被错误吞掉。**必须在每条消息外层显式传 `chatId: user_id`**；
  - **标签头衔真实性**：群主紫色 (`#b18fff`)、管理员绿色 (`#5ec26f`)、自定义头衔灰色 (`#aaaaaa`)。**无头衔普通群友严禁凭空伪造「群员」标签，必须留空不绘制**；
  - **Telegram Premium 会员 Emoji 状态**：普通 `User` 对象不携带该字段，必须调用 `bot.get_chat(user_id)` 提取 `emoji_status_custom_emoji_id` 与 `accent_color_id`；
  - **媒体与动图还原**：被引用消息为贴纸或图片时，静态贴纸原样还原，动图/视频贴纸提取官方缩略图定格首帧，严禁使用 `[贴纸]` 纯文本占位符；
  - **`qh` 上下文气泡渲染前置条件与文本补全**：Node.js quote-api 底层要求 `message.replyMessage.name` 和 `message.replyMessage.text` **两者必须同时非空**才会触发绘制二级引用气泡。若被引用对象是纯贴纸/纯图片且没有附言文本，必须自动补上 `[贴纸 🎯]`（携带贴纸 emoji）或 `[图片]` 占位，严禁留空或传 `None`，否则整个 `replyMessage` 会被静默吞掉退化为单人气泡；
  - **双轨消息链持久化与 SQLite 深度回溯**：Telegram Bot API 的 `reply_to_message` 往往只携带直接被回复的对象，无法跨层级拿到爷爷辈/父级历史。若仅依赖内存 `MESSAGE_META_CACHE`，一旦进程重启或内存淘汰，`qh` 将彻底失联退化。必须在 `messages` 表同步持久化 `reply_to_msg_id`、`reply_to_user_name` 与 `media_file_id`，在查询父级关联时实现「内存优先 + SQLite 深度回溯」双轨兜底，并在服务启动时从 SQLite 预热历史消息队列；
  - **别人贴图作为 Q 图主体的识别与首帧抽取**：针对回复别人贴图直接发 `q`，若为静态 WebP 贴纸直接通过 `get_file` 取原图；若为 WebM / TGS 动态贴纸，优先使用官方 thumbnail，若无 thumbnail 则调用本地 FFmpeg 抽取第一帧 PNG 缓冲，以 `data:image/png;base64` 传入 `media` 字段，实现对方专属头像+贴图本体的高保真名言贴纸；
  - **高保真当前实时生效头像获取陷阱 (`user_chat.photo` vs `getUserProfilePhotos`)**：
    - **痛点现象**：Q 图识别出的头像是群友完全陌生的旧照片、历史相册照片或备选公开照片（如历史雕像），群友和管理员反馈“头像错的/不知道哪来的”；
    - **根因分析**：
      1. Telegram 允许用户个人资料保留多张头像相册历史（Carousel）或设置备用公开照片（Public Photo）；
      2. 若调用 `bot.get_user_profile_photos(user_id, limit=1)` 并取 `photos.photos[0]`，在 Telegram 数据结构中它仅仅是相册列表的索引 0，当用户从相册回选过旧头像当主头、或设置过多张头像时，`photos[0]` **并不是**当前正在聊天生效的主头像；
      3. Telegram 官方**唯一能 100% 保证反映用户在群聊与聊天列表中实时生效主头像**的字段，是 `bot.get_chat(user_id)`（返回 `ChatFullInfo`）中的 `user_chat.photo.big_file_id`；
    - **架构解决方案**：
      - 在拉取头像时，**必须绝对优先读取并下载 `user_chat.photo.big_file_id`**，保证 100% 与群内实时渲染视觉对齐；
      - 仅当 `user_chat.photo` 为空（如用户设置了严格隐私保护隐藏头像、或接口受限）时，才回退尝试 `get_user_profile_photos` 作为兜底；
      - 这样不仅消灭了头像错位 Bug，还直接省掉一次 Telegram API 往返请求（降低贴纸生成延时）。
- **贴纸包满 120 张自动扩容**：
  - 命名规范：`g_{chat_id}_by_{bot_username}`，满 120 张时自动升级为 `g_{chat_id}_2_by_{bot_username}`，标题追加 `(Vol 2)`，确保容量无上限。
- **贴纸包创建与触发前置条件**：
  - 必须去 `@BotFather` 执行 `/setprivacy` -> 设置为 `Disable`，否则单字母 `q`/`qs` 不会被 Bot 接收；
  - 机器人 Owner 必须先在私聊中向 Bot 发送一次 `/start` 激活授权，否则创建贴纸包会因 `PEER_ID_INVALID` / `USER_NOT_FOUND` 报错拦截；
  - 独立脱敏部署模板见 `templates/standalone-quote-bot.py`，脱敏自检探针脚本见 `scripts/verify_desensitization.py`（配套一键脚本与文档在 `/home/ubuntu/tg-quote-sticker/`）。
- **对外分享与开源发布时的 4 级静态脱敏审计规范**：
  - **切忌直接打包原有 Git 仓库**：严禁直接 zip 包含 `.git` 目录的代码库，防止黑产通过 `git log -p` 回溯提取历史 commit 中曾遗留的 Bot Token、私人 ID 或私钥；必须另建全新独立目录重写/复制纯净代码；
  - **参数收敛与占位符规范**：所有敏感配置（Token、Owner ID、Webhook、自建服务端点）严格收敛至环境变量（`os.getenv`）与 `.env.example`，示例填入显式假数据（如 `123456789:ABCdef...`），代码绝不设真实 fallback；
  - **4 级自动化静态安全探针**：
    1. 敏感专有标识扫描（Owner TG ID、关联 Bot ID、关联手机号、私有反代域名与别名）；
    2. 非本地回环公网 IP 正则扫描（排除 `127.0.0.1` 和 `0.0.0.0`，扫描所有公网 IPv4）；
    3. Telegram Bot Token 格式正则扫描（`\b\d{8,11}:[a-zA-Z0-9_-]{30,}\b`）；
    4. 部署宿主机绝对路径与用户名扫描（避免暴露 `/home/<user>`、内网映射路径）。

---

### 2. 网易云音乐点播与解析 (/music)
- **支持输入形态**：
  - 歌名/歌手模糊点播：`/music 晴天 周杰伦`、`点歌 富士山下`；
  - 单曲 ID 直达：`/music 186016`；
  - 官方链接/短链直达：直接发送 `https://music.163.com/#/song?id=...` 或 `163cn.tv`。
- **交互与双轨流式中继架构**：
  ```text
  用户输入歌名 -> 搜索网易云曲库 Top 5 -> 弹出带 [1][2][3][4][5] 内联按钮菜单
     │
     ▼ 点击数字
  主轨：尝试网易云官方外链 CDN (http://music.163.com/song/media/outer/url?id=xxx.mp3)
     ├─ 成功 ──► 下载音频
     └─ 失败 (VIP/海外 404/版权拦截)
           │
           ▼
  副轨：调用 B站 专线中继搜索 Hi-Res 原声 -> 流式拉取音频 -> FFmpeg 实时转码为 320k MP3
     │
     ▼
  Mutagen 注入完整 ID3v2 标签 (Title, Artist, Album, APIC 高清封面)
     │
     ▼
  调用 Telegram bot.send_audio 投递原生音频，本地临时文件即刻彻底销毁
  ```
- **资源与额度保障**：
  - 音乐模块全流程走纯 Python 算法与流式通信，**大模型 Token 消耗为 0**；
  - 本地音频随发随删，0 磁盘累积。
- **高频踩坑记录 (Pitfalls)**：
  - **`Message.reply_text()` 严禁传 `quote=True`**：在 `python-telegram-bot` v20+ 中，`reply_text` 默认即引用消息，传入 `quote=True` 会抛出 `TypeError: unexpected keyword argument 'quote'` 导致整个指令崩溃静默。
  - **模块顶层完整导入 `os`**：异步执行临时文件存在性校验 `os.path.exists(mp3_path)` 与清理 `os.remove()` 时，必须确保文件顶部显式 `import os`，避免因 `NameError: name 'os' is not defined` 导致前端一直悬挂 `⏳ 正在提取` 假死。
  - **音乐提取性能优化（原生 320k 探测 + Telegram file_id 持久化缓存）**：
    - 痛点：音乐提取若每次都退回 B站转码，耗时往往需要 10~15 秒，二次点播依然重复转码，体感较慢。
    - 解决方案：
      1. **直连官方播放器增强 API**：优先探测网易云网页/移动端播放器接口（`api/song/enhance/player/url?br=320000`），直出 320k MP3 直链，绝大部分普通曲目免转码秒出；
      2. **全局 Telegram file_id SQLite 缓存**：创建 `data/music_cache.db`。任意歌曲首次在任意群成功发送后，记录其 Telegram 官方 `tg_file_id`；后续任何群再次点播该曲目时，**0 秒转码、0 流量下载，直接投递已缓存的 file_id**，实现 0.1 秒秒发！
  - **B站兜底音源搜索必须过滤长合集与教程，且必须优先选择轻量体积视频源**：
    - 痛点：搜歌名时容易匹配到 4K 修复超大 MV（体积高达 40MB~60MB），而我们只需 6MB 音频，FFmpeg 却在后台拖拉整个 4K 视频流，耗时长达 40 秒以上且极易网络抖动超时报错；
    - 解决方案：
      1. 严格过滤标题带“伴奏/教学/教程/钢琴谱/简谱/鼓谱/光遇/片段/翻唱/铃声”的干扰视频；
      2. 强制校验标题必须包含原歌曲名，时长限制在 2:45 ~ 7:30 之间；
      3. **体积择优算法**：候选视频中先解析出真实大小，优先选取 10MB~22MB 的轻量正片视频源（速度提升 3 倍以上，单曲 8~10 秒内即可转码搞定）。
  - **视频解析流量去向与 AWS 100GB 出网流量保护**：
    - 流量走向：
      1. 抖音/快手等平台：优先调用 `context.bot.send_video(video=video_url)`，由 Telegram 官方海外数据中心直接向 CDN 下载，**0 AWS 流量消耗**；
      2. 哔哩哔哩/TikTok/直链推流失败回退：视频流必须经由 AWS 实例下载并中转上传至 Telegram，**会消耗 AWS 实际出网带宽**；
    - 保护机制：部署 `services/video_service.py`，凡超过 **35MB** 的大视频自动调用本地 FFmpeg 压缩（720p H.264 CRF 28 veryfast），将 60MB~100MB 视频压至 15MB 左右，削减 75% 带宽，杜绝击穿每月 100GB 免费限额。

  - **“很多歌曲搜不到/全是山寨翻唱”的版权断层与多引擎聚合破局**：
    - 痛点：群友搜索《七里香》、《告白气球》、《兰亭序》、《我的心好累》等歌曲时，Bot 反馈“找不到”或者只搜出“Xai小爱”、“吉拉朵”等低质翻唱；
    - 根因：网易云音乐早年失去周杰伦等顶级歌手的独家版权，在公开检索接口中**彻底剔除了正版原唱**；若只搜网易云必然导致大量顶级热门歌曲“搜不到”；
    - 解决方案：**接入 QQ音乐 / 酷狗公开曲库构建聚合检索（`search_music_all`）**。QQ 音乐覆盖 100% 华语正版版权，联合检索后通过 `(title, artist)` 智能去重，正品原唱稳居首位，命中率飙升至 100%！

  - **B站访客截断断流与 `qn=16` 轻量音频流（速度飙升 5 倍 + 零截断）**：
    - 痛点：降级至 B站提取时，频繁出现 FFmpeg 超时（40秒以上）或生成的音频只有 20~30 秒（唱半句就没了）；
    - 根因：
      1. B站对未登录访客（Guest）策略严苛：若请求 `qn=64`（720P HD），不仅文件体积高达 40MB~60MB 极慢，且海外 Akamai CDN 会在 25MB 左右主动掐断（HTTP 503 / `Stream ends prematurely`），甚至直接作为“高清试看”截取前 30~60 秒；
      2. 抽音频根本不需要高清视频画面！
    - 解决方案：
      1. **强制指定 `qn=16`（360P）轻量流**：单曲视频体积从 50MB 骤降至 **5MB~11MB**，海外 CDN 不再掐线，拉流转码耗时从 40 秒压至 **5~12 秒**；
      2. **多候选自动遍历与时长硬下限拦截**：遍历前 4 个候选视频，转码后使用 `mutagen` 校验实际时长。若音频时长 `< 140s`（小于 2 分 20 秒），立即判定为短片/试看截断，自动剔除并顺延尝试下一候选，直到产出 `140s ~ 450s` 的完整原曲！

  - **第三方音源池生态与个人账号安全防线（行业共识与避坑指南）**：
    - 行业生态：主流免费音乐客户端（洛雪 LX Music、MusicFree 插件）依赖民间自建的逆向抓包解密 API，寿命极短（大部分活几个月就 503 宕机或 DNS 暴毙）；部分大型音乐 Bot 则是批量购买无实名的批发共享小号当耗材挂载；
    - **严禁挂载用户真实个人实名大号**：网易云对海外数据中心（AWS、阿里云等）机房段 IP 检测严格，将个人常用主号长期挂在云端机房有保护性封禁或冻结 VIP 的风险。若无额外闲置小号，**必须完全使用纯免账号双轨架构（官方免费源 + B站 Hi-Res 轻量源 + Telegram 云端 file_id 缓存）**，确保用户个人资产与账号绝对安全。
  - **音频半途截断/仅前几十秒（VIP试听片段与 CDN 长连接早泄根治）**：
    - 痛点：群友反馈音乐“听到一半戛然而止”或“只有几十秒一分钟”。
    - 根因：
      1. 网易云部分 VIP 曲目返回的其实是带 `freeTrialInfo` 的 30~60 秒试听截断片段，若直接当正片发送会导致整首歌只有前几十秒；
      2. 降级走副轨拉取 B站视频流时，若直接走中继代理长连接，海外 Akamai CDN 会在传输中途单方面关闭 TCP 连接（`Stream ends prematurely`），FFmpeg 不会报错而是把截断的前半段直接封装成了 MP3！
    - 解决方案：
      1. **审查并丢弃截断试听流**：校验官方音频长度或标记，试听流直接判定失效并强行切备用源；
      2. **FFmpeg 原生 `-headers` 直灌 CDN 协议头**：FFmpeg 支持 `-headers "Referer: https://www.bilibili.com/\r\nUser-Agent: ...\r\n"` 直接向 B站 CDN 拉流，消灭中继长连接导致的 premature end 截断，100% 下载完整长音频；
      3. **正片时长严格下限过滤**：第一轮筛选时优先匹配 `165 <= total_sec <= 450`（2分45秒 ~ 7分30秒），彻底过滤片段剪辑、光遇琴谱与短片，保证 100% 完整长曲。
  - **Telegram 上传大音频 `Timed out` 超时报错**：
    - 痛点：提取高保真 320k 完整音频时文件大小达 8MB~15MB，调用 `bot.send_audio` 时若网络出现微小抖动，容易抛出 `telegram.error.TimedOut: Timed out`。
    - 根因：`python-telegram-bot` 底层 `HTTPXRequest` 默认写超时极短（通常只有 5 秒）。
    - 解决方案：在 `ApplicationBuilder` 构建 Bot 时，传入自定义 `HTTPXRequest`，将 `media_write_timeout` 放宽至 180 秒（3 分钟）：
      ```python
      custom_request = HTTPXRequest(
          connection_pool_size=16,
          read_timeout=60.0,
          write_timeout=60.0,
          connect_timeout=20.0,
          pool_timeout=20.0,
          media_write_timeout=180.0
      )
      app = ApplicationBuilder().token(BOT_TOKEN).request(custom_request)...
      ```
  - **网易云黑胶 VIP 凭证安全挂载与官方 Eapi 秒级直链（0.9s 无损直出）**：
    - 机制：网易云对海外机房 IP 查得严，个人大号直接在机房 IP 上高频调用有被保护性封禁/下线的风险。若有闲置小号，可将网页端 Cookie 中的 `MUSIC_U` 提取写入独立安全配置文件（严格排除在 Git 之外，`chmod 600`）。
    - 接入官方 Eapi：使用 Android 客户端密钥与 AES-ECB + PKCS7 加密调用 `/eapi/song/enhance/player/url/v1`（带 `level: "exhigh"`），直接提取官方 320k 极高音质直链。
    - 效果：全网所有 VIP 歌曲 0.9 秒内秒级下载并投递，彻底免除第三方中继转码，100% 完整长曲！
  - **搜索交互消灭中间过渡卡顿**：发送 `/music 歌名` 时，后台直接在 0.3 秒内完成曲库检索并一次性直接发送 Top 5 候选卡片与 `[1][2][3][4][5]` 按钮；严禁先发送一条“正在检索...”再调用 `editMessageText` 改卡片，否则客户端网络往返（RTT）会吃掉 2~3 秒无效卡顿。
  - **网梗曲/特殊别名映射与 CDN 中继容错 (Meme Aliases & Relay Stream Fallback)**：
    - **痛点**：群友点播网梗曲（如搜《鸡你太美》）时，所有候选均报错「付费保护或已下架，暂时无法提取音频流」；
    - **根因分析**：
      1. 歌名/别名错位：正曲官方登记名为《只因你太美》（SWIN-S 演唱），群友搜索词为民间梗名《鸡你太美》；B站检索出的原版完整视频标题普遍为《只因你太美》，旧逻辑强制校验 `clean_key in v_title` 导致完全不匹配、全部判定错歌丢弃；
      2. CDN 直连偶发超时：FFmpeg 直连 Akamai CDN 在特定时段握手慢，若超时门槛过短（如 28s）极易早泄中断；
    - **解决方案**：
      1. **注入智能别名映射字典**：为《鸡你太美》等梗曲预置原曲检索别名（如映射至 `只因你太美 原版`、`SWIN 只因你太美`），并在标题匹配算法中建立对称双向模糊放行规则；
      2. **放宽时长门槛**：下限放宽至 140 秒（2分20秒），允许高燃混音、练习室版等优质完整长音频合法通过；
      3. **优先使用 VPS 中继流**：流媒体拉取时优先采用 RackNerd VPS 中继流（防断流能力显著优于直连），并将转码超时放宽至 45 秒，彻底解决假死下架报错。

  - **B站兜底音源提取死锁排障：DASH 纯音频流（`fnval=16`） vs 18MB 完整大视频拉取、Unicode NFKC 跨字符集歌名归一化与 FFmpeg 超时收敛**：
    - **痛点**：群友点歌（尤其是日文/英文/带特殊标点歌曲，如 `好きだよ。～100回の後悔～ (English Ver．)`）时，所有备选均报错「付费保护或已下架，暂时无法提取音频流」，或长时间卡在 `⏳ 正在提取` 超过 1~2 分钟最终超时崩溃；
    - **根因分析**：
      1. **误拖 18MB+ 完整视频大文件**：旧代码调用 `_blocking_parse(..., qn=16)` 默认拉取的是带有画面帧的 MP4 视频流（18MB~40MB）。在通过海外中继或直接向 Akamai CDN 拉流时，FFmpeg 单连接等待网络流极易在 45s 时限内发生 socket 阻塞引发超时；
      2. **标点与异形字符阻断候选匹配（Unicode 错杀）**：B站搜索出的优质完整单曲使用了 ASCII 波浪号 `~`、ASCII 数字 `100` 或不同全角标点，而用户点歌输入的是全角波浪号 `～`、全角数字 `１００` 或不同浊音组合（如 `だ` vs `だ`）。旧逻辑用纯小写 `clean_key in v_title` 判定为完全不匹配，将大量正片单曲错杀；剩下的短片段（如 98 秒的日推片段）又因为 `< 140s` 硬门槛被无情丢弃，导致候选池耗尽报错；
      3. **超时门槛设置过长导致连锁卡顿**：单个候选在 relay 和 direct 均等待 45 秒，连续重试 2 个候选即耗时 3 分钟以上，严重积压。
    - **解决方案**：
      1. **强制提取 B站 原生 DASH 纯音频流 (`fnval=16`)**：解析接口请求 `fnval=16` 直接从 `dash.audio` 中提取最高码率 AAC/M4A 纯音频流（体积从 18MB+ 暴降至 **3MB~7MB**，带宽缩减 75%），FFmpeg 仅做音频转码，2~4 秒内秒级完成，彻底消除视频大文件卡死超时；
      2. **引入 `unicodedata.normalize('NFKC', s)` 深度归一化**：在提取与匹配算法中将全角/半角、平假名/片假名浊音、波浪号 (`～`/`~`)、数字 (`１００`/`100`) 统一归一化，所有异形歌名候选 100% 精准匹配放行；
      3. **FFmpeg 超时收紧至 25 秒并放宽时长下限至 80 秒**：单个流卡顿 25 秒内迅速切下一候选，且放行 80 秒以上的短篇/TV Size 优质单曲，杜绝过度严格拦截。

  - **多实例复刻解耦与全域配置同步 (Multi-Bot Cloning & Default-Quote Policy)**：
    - **痛点与需求**：在同一台服务器上部署多个群管 Bot（如主 Bot `@yecaodi_bot` 与分身 Bot `@qunba_bot`），要求两者的配置、授权群组、VIP 名单、音乐缓存完全实时同步；同时要求新群授权时**默认只开启贴图功能**，其余功能（AI、总结、视频、音乐、禁言）默认关闭，需由 Owner/群主手动按需放开。
    - **双实例权限隔离与能力共享架构（核心原则：能力与缓存共享，权限与开关按 Bot 物理隔离）**：
      - 冲突根源：若两个 Bot 共用同一个 `config.json`，改动一个群的开关（如原 Bot 在某群开启全功能，而新 Bot 在该群希望只开贴图），会导致权限串线互斥。
      - 解决方案：
        1. **配置文件按 `BOT_ID` 物理拆分**：从 `TELEGRAM_BOT_TOKEN` 前缀动态解析 `BOT_ID`，分别绑定独立的配置文件（如 `data/config_8723257160.json` 与 `data/config_8712228275.json`）；
        2. **差异化入群默认开关策略**：
           - 原 Bot (`8723257160`)：入群授权后保持原汁原味，默认开启全部功能 (`True`)；
           - 新 Bot (`8712228275`)：入群授权后默认仅开启名言贴纸 (`quote: true`)，其余功能 (`ai`, `summary`, `video`, `music`, `mute`) 默认返回 `False`，需手动通过 `/settings` 点开；
        3. **细粒度群组专属 VIP 权限隔离 (Per-Group Isolated VIP Policy)**：
           - 业务诉求：除了 Bot 实例级别隔离，每个群组的特权人员（VIP）必须相互独立，在群 A 授予 VIP 的群友去到群 B 必须是普通群友，绝不能产生跨群特权越权；不同 Bot 实例即便在同一个群，各自的 VIP 体系也互不相干；
           - 数据结构改造：在各自 Bot 独立配置文件（`config_{BOT_ID}.json`）中新增 `group_authorized_users: { "chat_id": [uid1, uid2] }` 字典；
           - 指令与上下文感知：
             - 在群聊中发送 `/addvip` 或回复某人加 VIP，系统严格识别为【当前群专属 VIP】，写入本群 `group_authorized_users[chat_id]` 名单，并调用 `sync_group_permissions` 仅向本群下发特权指令菜单；
             - 只有在私聊 Owner 发起 `/addvip` 时，才作为全局跨群 VIP（写入 `authorized_users`）；
           - 权限判定下沉：所有特权校验函数 `can_manage_mute`、`can_use_qs`、`is_user_privileged` 必须显式传入 `chat_id`，取 `authorized_users (全局)` 与 `group_authorized_users[chat_id] (本群专属)` 的并集判定；
           - 查询与移除联动：在群内执行 `/viplist` 仅展示本群专属特权名单，`/delvip` 优先且仅解绑当前群的专属特权，绝不误伤其他群组；
        4. **受保护频道资源「写进数据库让 Bot 调取」的底层真相与穿透模式**：
           - 常见误区：民间常传「把受保护频道的资源写进数据库就能让 Bot 转发」，被误认为可以隔空读取；
           - 官方底层限制：
             1. **Bot 签发沙盒隔离**：Telegram `file_id` 是每个 Bot Token 独立加密签名的，A Bot 无法直接使用 B 频道或他人 Bot 产生的裸 `file_id`，直接使用会报 `file_id invalid`；
             2. **防转发保护拦截**：受保护频道开启了 `has_protected_content: True`，官方强制拦截 `forward_messages` 与 `send_file(doc)`，报 `ChatForwardsRestrictedError`；
           - 正确实现闭环：
             1. 独立节点（如洛杉矶 VPS）以客户端身份绕过转发限制，在内存中直接拉取二进制音频流；
             2. 重新上传发布到己方专属「音乐库频道」；
             3. Telegram 官方此时为己方频道生成了合法的公开 `file_id`，再将该 `file_id`、歌名、歌手写入数据库表 `prewarm_cache`；
             4. 线上群霸 Bot 命中数据库后，以 0.1~0.5 秒直接调取该合规 `file_id` 秒发，兼顾 0 主站流量与受保护资源合法投递；
           - **SQL 数据库结构化多维分类设计 (SQL Structured Classification)**：
             - 数据库不应仅存裸 key，应在 `prewarm_cache` 中固化 `category` (流行飙升/无损热歌/车载高燃DJ/腾讯独家/网易云热歌等)、`source_channel` (溯源原始监控频道)、`source_msg_id` (源消息ID)、`file_format` (FLAC/MP3) 与 `bitrate_kbps`；
             - 建立 `idx_prewarm_cat` 与 `idx_prewarm_title` 复合索引，保证上万条音频按分类毫秒级检索与统计；
             - 运维机器人（`lemon-ops`）配套 `/musiclib` 命令，实时输出多维分类大盘报表并联动每日定时汇总；
        5. **全域能力与高价值数据共享**：
           - 双 Bot 共享 `music_cache.db`（任何一端点播过或预热的歌曲 `file_id` 均可互相 0 流量秒出）；
           - 双 Bot 共享本地 Node.js `quote-api` 渲染服务；
           - 双 Bot 共享 Owner ID；
           - 贴纸包按 `g_{clean_id}_by_{bot_username}` 命名，确保各自贴纸集独立无缝扩容。
    - **群组入群安全与默认功能矩阵控制**：
      - 入群静默：Bot 进群后处于未授权状态，必须由 Owner 执行 `/auth`（或私聊 `/auth <chat_id>`）正式放行；
      - 默认功能开关策略（在 `config.py:get_group_features` 中固化）：新授权群组仅默认开启 `quote: true`（名言贴纸），其余所有功能 `ai`, `summary`, `video`, `music`, `mute` 默认返回 `false`；
      - 增量开启机制：需要开启其他高级功能时，由 Owner 或群主在群内使用 `/settings` 面板点击图标按钮原地热激活；
      - **面板群名称与 ID 双显及持久化缓存 (`group_names`)**：
        - 痛点：私聊发 `/settings` 遥控多群时，若 Bot 进群后尚未产生群消息或 `get_chat()` 出现网络抖动，面板列表往往仅显示冰冷的一长串数字 `chat_id`（如 `群组 -1004465895532 (-1004465895532)`），无法直观分辨是哪个群；
        - 根本原因：Telegram 官方隐私保护机制下，若某个 Bot 实例尚未被拉入该群或无权限，调用 `get_chat()` 会直接抛出 `Bad Request: chat not found` 导致无法实时获取群名；
        - 解决方案：在共享配置文件（如 `data/config.json`）中设立全局持久化字典 `group_names: { "chat_id": "群名" }`。无论是主 Bot 还是新复刻的 Bot，只要任一实例或历史消息捕获过群名，立即固化入库；渲染 `/settings` 面板与列表时优先采用该缓存，确保新 Bot 哪怕尚未被正式拉入对应群聊，也能 100% 优雅展示 `👥 【真实群聊名称】 (群组ID)`，杜绝纯 ID 占位符。
      - **外部授权注入、内存热重载与分级菜单同步 (External Auth Injection & In-Memory Config Trap)**：
        - 机制与陷阱：`config.py` 在模块加载时执行一次性 `config = load_config()`，核心校验函数 `is_group_authorized()` 直接读取内存变量 `config['authorized_groups']`。若外部运维脚本直接覆写 `config_{BOT_ID}.json` 磁盘文件，正在运行的 systemd 守护进程无法自动感知磁盘变更，会导致后台配置已加、线上却依然拦截报未授权；
        - 规范闭环：外部脚本改写 `config_{BOT_ID}.json` 后，必须触发 `systemctl restart lemon-group-botX.service` 重载服务；同时必须联动调用 `sync_group_permissions(bot, chat_id)`，针对该群即时向 Telegram 官方注册分级指令菜单（Owner 14 条全量、Creator/VIP 管理指令、普通成员精简指令）。
      - **公开群链接授权与 Bot 真实入群状态探针 (Chat Resolve & Member Status Probe)**：
        - 业务痛点：用户往往直接抛出群链接（如 `https://t.me/guyufamily888`）要求“帮我授权一下”，但 Telegram 官方不允许 Bot 仅凭链接或邀请码自主加入群组，且超级群（尤其是开启 `has_hidden_members: True` 隐藏成员）通常禁止普通群员添加机器人；
        - 规范处理链路：
          1. 群元数据自动解析：调用 `await bot.get_chat('@username')` 动态解析出真实负数 `chat.id` 与 `chat.title`，并将 `(chat.id, title)` 实时同步写入所有 Bot 实例配置的 `group_names` 缓存；
          2. 自身在籍状态真实核查：超级群隐藏成员模式下虽无法遍历普通成员，但 Bot 始终可以合法调用 `await bot.get_chat_member(chat_id, bot.id)` 探测自身状态；
          3. 精准反馈与拉群直达：若自身状态返回 `ChatMemberStatus.LEFT`，切忌向用户盲目汇报“已成功运行”，必须如实说明后台授权与菜单同步已完成，但机器人物理上尚未入群，并主动提供一键加群直达链接 `https://t.me/{bot_username}?startgroup=true`，指导管理员拉入并赋予对应消息删除权限。
  - **Telethon 跨节点部署与多 IP 并发登录硬锁 (`AuthKeyDuplicatedError`)**：
    - 痛点与官方风控机制：在 VPS 与本地服务器之间直接复制 Telethon `.session` 文件并在两台不同公网 IP 的机器上同时运行客户端时，Telegram 会瞬间触发 `AuthKeyDuplicatedError`（The authorization key was used under two different IP addresses simultaneously, and can no longer be used）；
    - 严重后果：该会话凭证会被 Telegram 服务器永久物理吊销（所有本地与远端相同 key 的 session 立即全量作废报废），导致依赖该会话的 UserBot 进程连续崩溃重启；
    - 铁律与架构防护：
      1. **严禁跨机器直接复用同一个正在使用的 active session 文件**；
      2. 需在独立机器（如海外 VPS）执行爬虫/搬运时，必须使用独立手机号登录生成专用的 session 名字，或在该机器上单独走一次授权流程（单独 session）；
      3. 一旦遭遇 `AuthKeyDuplicatedError`，必须第一时间 kill 掉远端冲突进程并清理废弃 session，杜绝持续发起握手加剧账号风险。

  - **大文件长连接慢速重试阻塞事件循环（防卡死加固）**：
    - 痛点：群友点歌或发送视频链接时，若解析到 80MB+ 的超大非单曲视频，`_download_range_chunks` 在海外 CDN 慢速断流下会反复重试，每个分片超时 30 秒累积拖死 5 分钟，导致 Bot 的事件轮询（Event Loop）被严重挤占，私聊和群聊出现“完全无反应/死机”假象。
    - 解决方案：
      1. **体积硬性截断**：超过 120MB 的超大非单曲资源严禁盲目进行多分片拉取，直接单次流式试探或快速放弃；
      2. **压紧分片重试阈值**：单个 Range 分片超时从 30 秒压缩至 15 秒，重试次数从 4 次压至 2 次，一旦源不稳定在 30 秒内迅速切走或失败，绝不卡死主轮询进程。

  - **跨 Bot 间接通信与 UserBot 代理点歌的可行性辨析（为什么不能找别人的 Bot 中转）**：
    - 协议死穴：Telegram 官方 Bot API 在底层硬性禁止 Bot 与 Bot 相互通信（机器人给其他机器人发消息直接静默丢弃或返回 403，官方为防无限死循环刻意设计），因此群霸 Bot 绝不可能直接私聊 `@Music163bot`；
    - 真人账号/UserBot 中介的实战弊端：若通过 UserBot 代理向公网音乐 Bot 点歌，多经历 5~6 次公网握手导致延时严重翻倍（25~40 秒）；公网 Bot 高峰期排队或宕机会频繁导致点歌超时；高频点歌容易导致个人 Telegram 账号被目标 Bot 封禁或触发 Telegram SpamBot 限流；群友点歌会导致用户本人的私人 Telegram 聊天列表被搜索卡片与音频严重刷屏；
    - 结论与最佳方案：绝不可依赖第三方 Bot 中转。纯免账号走体积优化的轻量音轨源 + 全局持久化 Telegram `file_id` 缓存（二次点播 0.1s 秒出）；若追求官方全曲 0.9s 秒级极速，应采用 1~2 元的无实名网易云废弃月卡小号作为耗材挂载，坚决不拿个人实名大号冒险。

---

### 2.3 音乐库预热缓存架构（跨机预热 + 频道中转，主站 0 流量秒发）

> 完整实现细节（代码骨架、运维命令、实测数据、运行时反向写入、踩坑清单、汇报口径）见 `references/music-library-prewarm.md`

- **核心思想**：把「搜索 → 下载 → 转码 → 上传 Telegram」这套重活整体搬到一台**廉价海外 VPS** 上离线完成；
  主站（如受 100GB 免费出网额度约束的 AWS 机）只保存爬好的 `file_id` 文本索引。
  群友点歌命中预热库时，主站直接 `send_audio(audio=<file_id>)` ——
  **文件由 Telegram 服务器内部复制，主站出网流量 ≈ 0，实测 0.47~1.0 秒秒发**。
- **三段式数据流**：
  ```text
  [预热 VPS]                                        [主站]
  热歌榜(网易云热歌/飙升/新歌 + QQ音乐热歌) ──► 候选池数百首
    → B站 qn=16 轻量流(5~12MB) → FFmpeg 抽音轨
    → ID3 标签 + 专辑封面
    → 上传 Telegram 频道「🎵 柠檬音乐库」并取回 file_id
    → 追加写入 jsonl 索引
                                      │
                          (SSH 只拉几 KB 纯文本索引，不含音频)
                                      ▼
                         data/music_cache.db :: prewarm_cache 表
                                      │
                      群友 /music 点歌 ──► 命中 → 0.5s 秒发（0 流量）
                                       未命中 → 原实时提取链路兜底
  ```
- **点歌优先级必须四段式**：`① 预热库 → ② 本机 file_id 缓存 → ③ 官方直链 → ④ 实时提取兜底`。
  预热库查询键必须用**两端算法完全一致的归一化 key**
  （去括号 → 去 feat/ft/live/remix/伴奏/翻唱/版/无损 → 去非中英数符号 → 小写 → `title|artist`），
  否则爬虫写进去的歌永远查不出来（这是最容易踩的静默不命中坑）。
- **群友点播必须双写：沉淀预热库 + 自动归档到音乐库频道（用户显式预期闭环）**：
  预热库只做 SQLite 写入是不够的 —— 用户对「建了一个音乐库频道」的心理模型是**直观的、肉眼可见的**：
  「我在群里点播了某首歌，这首歌应该**自动出现在频道里**，同时沉淀进缓存方便下次秒调」。
  若只把 `file_id` 写进本地数据库而**没有向频道做 `send_audio` 动作**，用户进频道看不到这首歌，
  就会产生「你怎么没存 / 根本没放到频道里」的负面反馈（实战真实踩坑）。
  - **正确做法（0 额外音频流量的双写闭环）**：
    1. 群内发送成功，拿到该消息的 `audio.file_id`；
    2. 本地 `save_cached_tg_file_id()` + `save_group_prewarm()` 写入预热表；
    3. **关键一步**：立即以该 `file_id` 调 `bot.send_audio(chat_id=<channel_id>, audio=final_fid, ...)` 复制一份到音乐频道（附带 `📥 来源：群友点播自动归档`）；
    4. 此操作在 Telegram 服务端内部完成文件引用复制，**不产生本地到云端的音频上行流量（主站出网流量 ≈ 0）**，耗时仅 ~0.5s；
    5. 频道归档必须用单独 `try/except` 包裹并记日志，即使频道操作偶发失败（如权限变动）也不影响群内正常投递与本地缓存。
- **`sqlite3.INTEGER PRIMARY KEY` 存不下字符串歌曲 ID（静默丢缓存的隐形杀手）**：
  QQ 音乐 / 部分平台的歌曲 ID 是**字符串**（如 `002J5QAZ0n66y1`），
  写入以 `song_id INTEGER PRIMARY KEY` 定义的缓存表会直接抛
  `sqlite3.IntegrityError: datatype mismatch`；由于外层通常是宽泛 `try/except` + `logger.debug`，
  **失败会被完全吞掉**，表现为「明明点播成功过，下次还是要重新下载转码」。
  - 自查一行验证：`conn.execute("INSERT INTO song_cache (song_id, ...) VALUES ('002J5QAZ...', ...)")`
  - 正确做法：**不要用平台 ID 做主键**。另建以归一化 `key TEXT PRIMARY KEY` 为键的
    `prewarm_cache` 表承载全部「可复用」语义，平台 ID 只作为附带的元数据列。
  - 缓存写入路径**禁止静默降级**：至少要 `logger.info` 出实际异常，否则此类 Bug 可以潜伏数周。
- **双向同步闭环（防止预热机重复劳动）**：主站同步脚本除了「拉取远端 JSONL」，
  还要把本地 `origin='群友点播'` 的条目**回推**到预热机的 JSONL（base64 传输避免引号/中文转义问题）。
  预热机爬虫读 JSONL 里的 `key` 做去重，回推后就不会再重复爬同一首歌，
  省下预热机的带宽与频控额度。回推只有几百字节/首，可忽略不计。
- **定时任务与并发锁**：
  - 预热机用 `systemd .timer`（`OnBootSec=5min` + `OnUnitActiveSec=30min`）跑爬取，
    脚本首行**必须加 `flock -n` 单实例锁**，否则手动触发与定时器撞车会并发放大请求量、触发风控；
  - 主站用**静默看守 cron**：有净增才输出汇报，无新增时 stdout 为空保持静默，不打扰用户。
- **拟人化频控**：爬虫每首之间 `sleep 1.8~3.5s`，单轮批量上限可配（默认 12 首），
  状态文件记录 `done_keys` 保证断点续爬、不重复入库。
- **第三方优质音乐频道（带防转发保护）的搬运与提速策略**：
  - **防转发保护 (`ChatForwardsRestrictedError`)**：外部音乐频道（如 FLAC/DJ/320K 频道）普遍开启了防保存保护，禁止 `forward_messages` 和 `send_file(media)` 指针秒传；
  - **实时爬取 vs 异步预热**：点歌时若实时去第三方频道拉取大无损文件（50MB~80MB），拉取耗时近 20s 且重发极耗 AWS 出网流量；**必须交由无限流量的独立预热 VPS 异步慢慢搬运**，上传到己方音乐库频道生成原生 `file_id` 后，群内点歌直接 0.5s 秒出；
  - **Telethon 反序列化构造器构造异常**：高版本 Telethon 在上传大音频到频道时可能抛出非致命的 Constructor ID 警告（如 `Could not find a matching Constructor ID for TLObject 31774388`），代码需捕获后向频道反查最新消息确认上传结果，避免误判为失败。
- **运维机器人日志联动与每日 02:00 汇总 (`/musiclib`)**：
- 运维 Bot 提供 `/musiclib` 实时查询库存、今日新增与来源分布；
- 每天 02:00（北京时间）自动向管理员推送极简汇总；计算今日新增时注意 UTC 存储与北京时间 (+8h) 的时区转换，避免统计失准。
- **无头 VPS Telethon 独立会话认证与私有频道自愈提权闭环**：
  - 针对 `AuthKeyDuplicatedError` 报废后的新号接管，采用分阶段解耦脚本（`req` 发码记录 hash 状态 → `verify` 校验带 2FA 密码登录），会话 `chmod 600` 物理隔离；
  - 新号通过 Bot `exportChatInviteLink` + 客户端 `ImportChatInviteRequest` 自动静默加群；
  - 解决私有广播频道发帖权限死锁：主站 UserBot 监听 IPC 并在目标频道中通过 `iter_participants` 解析出新账号 Entity，自动调用 `EditAdminRequest` 赋予 `post_messages=True` 管理员权限，实现 0 人工干预的全自动上线。
- **平台事实与避坑（务必牢记）**：
  - **Bot 无法创建频道/群**：Telegram Bot API 没有 createChat 能力。必须用**真人账号（Telethon UserBot）**
    调 `CreateChannelRequest(megagroup=False, broadcast=True)` 建频道；
  - **Bot 无法被 `InviteToChannelRequest` 邀请**：会直接报 `Bots can only be admins in channels.`。
    正确做法是**直接对该 Bot 调 `EditAdminRequest(channel, user_id=<bot_username>, admin_rights=...)`** ——
    提权的同时会隐式把 Bot 加入频道，一步到位；
  - **`file_id` 是 Bot 专属的**：同一条音频，A Bot 拿到的 file_id 交给 B Bot 使用会失效。
    因此预热上传与线上点歌**必须使用同一个 Bot Token**（同一 Bot 允许从多台机器分别调用**发送**接口；
    只有 `getUpdates` 长轮询才存在单连接限制，发送侧不冲突）；
  - **`callback_query` 必须先 `answer()` 再做重活**：回调响应窗口只有十几秒，
    若在其之前插入同步阻塞工作，会抛 `telegram.error.BadRequest: Query is too old and response timeout expired or query id is invalid`，
    用户侧表现为「点了按钮一直转圈/无反应」。**`answer()` 必须放在最前，所有耗时同步调用一律包进 `asyncio.to_thread()`**；
  - **`ffmpeg -reconnect*` 参数存在版本差异，必须运行时探测**：
    `-reconnect_delay_total_max` / `-reconnect_max_retries` 是较新版本才提供的 http 协议选项，
    旧版 ffmpeg 遇到会直接 `Unrecognized option ... Error splitting the argument list: Option not found`（rc=8）
    并产出 **0 字节**转码结果；若外围只判「文件存在且够大」就可能被静默记成「提取失败」，极难定位。
    ```python
    def _probe_ffmpeg_option(opt: str) -> bool:
        p = subprocess.run(["ffmpeg", "-h", "protocol=http"],
                           stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=15)
        return opt in p.stdout.decode(errors="ignore")

    RECONNECT_DELAY_TOTAL_OK = _probe_ffmpeg_option("reconnect_delay_total_max")
    # 拼命令时再按需追加该参数，不要写死
    ```

---

### 3. 短视频去水印解析与超大文件自动压缩 (Video Parsing & Compression)
- **支持平台**：抖音无水印（提取纯净直链秒发）、哔哩哔哩（防盗链流式下载直传）、TikTok（SOCKS5 专线中继下载）、YouTube（独立专线引擎 + 会员/限制拦截 + Node.js 运行时 + SOCKS5 中继）、快手等；
- **发言保留规范与群聊公屏响应边界 (Group Public Reply vs DM Illusion)**：
  - 群友分享视频链接的原消息**予以保留**，不粗暴撤回，保持聊天上下文完整；
  - **公屏响应与隔离认知防坑**：Bot 解析视频完成后严格以 `chat_id=chat.id` 将视频回传至**当前接收消息的群聊公屏**。群内所有群友均可实时看到并下载，**绝无私聊推送给任何第三方或指定用户的逻辑**；若测试者在热闹大群内丢入链接测试，活跃群友看到 Bot 发视频发问（如“Bot 发的啥”）属正常公屏互动，切忌误判为“Bot 私信泄露发给了别人”。如需完全私密调试，应在专属测试小群进行。
- **YouTube 专线架构与限制性内容拦截避坑 (YouTube Engine & Membership Traps)**：
  - **痛点与陷阱**：
    1. ParseHub 通用解析对 YouTube 仅返回网页原始 URL（如 `https://youtu.be/...`），而非直接 mp4 CDN 流，下游直接调用 `send_video` 会抛错失败；
    2. YouTube 存在大量「频道会员专享」（Members-only，如特定等级专属）、私享（Private）、年龄限制或直播未完成视频；若在外层直接 `try...except` 吞掉异常返回 `None`，前端会抛出误导性的“视频解析失败或平台不支持”，导致用户误以为 Bot 故障；
    3. YouTube 视频可能长达数小时，若无时长硬拦截，全量拉流会瞬间消耗服务器带宽并突破 Telegram 50MB 上传死线。
  - **专线闭环方案 (`services/youtube_service.py`)**：
    1. **限制性视频精准研判**：
       - 识别 `available to this channel's members` 并正则提取会员等级（如“级别要求：义父 及以上”），返回明确提示 `ℹ️ 该视频为 YouTube 频道会员专属内容...`；
       - 识别私享视频、年龄限制、直播预告，返回友好分类文案，杜绝笼统报错；
       - **机房风控 oEmbed 优雅回显**：遇到 `Sign in to confirm you’re not a bot` 时，调用免登录且不封机房 IP 的 YouTube 官方 oEmbed 接口（`https://www.youtube.com/oembed?url=...`）拉取真实视频标题与频道主，精准提示群友具体哪部视频因风控受限、建议在客户端打开观看；
    2. **JS Challenge 与机房 IP 风控规避**：
       - yt-dlp 调用必须显式指定本地运行时 `--js-runtimes node:/usr/local/bin/node`，防止 JS challenge 求解失败；
       - 遇到机房 IP 人机验证时，自动降级切至 SOCKS5 代理中继重试；
    3. **时长硬门槛与流式压制**：
       - 提前 `--dump-json` 提取元数据，超过 **15 分钟** 的视频直接拦截并友好提示，仅放行 15 分钟以内的短片与 Shorts；
       - 下载合并为 MP4 `video_bytes` 后回传，通过统一管线检测超过 35MB 触发 FFmpeg 极速压缩，再调用 `send_video` 投递。

    - **Bot Token 凭据隔离与幽灵广告盗发溯源 (Bot Token Leaks & Phantom Spam Attack)**：
    - **痛点现象**：自己维护的 Bot 突然开始向所有与其交互过的群友/私聊用户批量群发垃圾广告（如俄语 AI 老照片动效视频），但服务器后台 `journalctl` 与应用日志毫无发送记录，干净如常；
    - **根本原因**：
    1. **Token 泄露到公开代码库**：`config.py` 中写了默认值 `BOT_TOKEN = os.getenv("...", "8723257160:AA...")`，随代码误推至 GitHub 公开仓库；全网黑产自动化扫描器常年监听 GitHub 公开推送，秒级抓取有效 Token 并存入盗发库；
    2. **完全脱离服务器的外部 API 盗发**：Telegram Bot API 是无状态云端 HTTP 接口。攻击者只要拥有 `BOT_TOKEN`，即可直接在他们自己的服务器上调用 `https://api.telegram.org/bot<TOKEN>/sendVideo`；该请求**物理上根本不经过你自己的 VPS**，因此本地无论怎么 grep/查日志都绝不可能抓到发送行为；
    - **闭环排查与防御铁律**：
    1. **断绝公开源**：使用 `gh repo edit <repo> --visibility private --accept-visibility-change-consequences` 立即将仓库锁为私有（Private）；
    2. **代码杜绝硬编码**：`config.py` 严禁提供 fallback 真实 Token，必须从本地独占的 `.env` 文件读取；`.gitignore` 必须将 `.env*` 严格纳入；
    3. **唯一根治手段（吊销换新）**：在 `@BotFather` 执行 `/mybots` -> `API Token` -> `Revoke current token` 立即吊销旧 Token。由于攻击者脚本持有的是旧 Token，吊销瞬间 Telegram API 返回 `401 Unauthorized`，彻底切断所有外部盗发链路；
    4. **公开仓库定期全盘凭据审计**：使用 `gh repo list <owner>` 检索名下所有 Public 仓库，结合正则扫描 `[0-9]{8,10}:[A-Za-z0-9_-]{35}`、`sk-[A-Za-z0-9]{20,}`、`ghp_[A-Za-z0-9]{20,}` 与服务器凭证，杜绝任何明文密钥上云。

- **Bot Token 凭据隔离与幽灵广告盗发溯源 (Bot Token Leaks & Phantom Spam Attack)**：
  - **痛点现象**：自己维护的 Bot 突然开始向所有与其交互过的群友/私聊用户批量群发垃圾广告（如俄语 AI 老照片动效视频），但服务器后台 `journalctl` 与应用日志毫无发送记录，干净如常；
  - **根本原因**：
    1. **Token 泄露到公开代码库**：`config.py` 中写了默认值 `BOT_TOKEN = os.getenv("...", "8723257160:AA...")`，随代码误推至 GitHub 公开仓库；全网黑产自动化扫描器常年监听 GitHub 公开推送，秒级抓取有效 Token 并存入盗发库；
    2. **完全脱离服务器的外部 API 盗发**：Telegram Bot API 是无状态云端 HTTP 接口。攻击者只要拥有 `BOT_TOKEN`，即可直接在他们自己的服务器上调用 `https://api.telegram.org/bot<TOKEN>/sendVideo`；该请求**物理上根本不经过你自己的 VPS**，因此本地无论怎么 grep/查日志都绝不可能抓到发送行为；
  - **闭环排查与防御铁律**：
    1. **断绝公开源**：使用 `gh repo edit <repo> --visibility private --accept-visibility-change-consequences` 立即将仓库锁为私有（Private）；
    2. **代码杜绝硬编码**：`config.py` 严禁提供 fallback 真实 Token，必须从本地独占的 `.env` 文件读取；`.gitignore` 必须将 `.env*` 严格纳入；
    3. **唯一根治手段（吊销换新）**：在 `@BotFather` 执行 `/mybots` -> `API Token` -> `Revoke current token` 立即吊销旧 Token。由于攻击者脚本持有的是旧 Token，吊销瞬间 Telegram API 返回 `401 Unauthorized`，彻底切断所有外部盗发链路；
    4. **公开仓库定期全盘凭据审计**：使用 `gh repo list <owner>` 检索名下所有 Public 仓库，结合正则扫描 `[0-9]{8,10}:[A-Za-z0-9_-]{35}`、`sk-[A-Za-z0-9]{20,}`、`ghp_[A-Za-z0-9]{20,}` 与服务器凭证，杜绝任何明文密钥上云。

- **超大视频自动压缩管线 (FFmpeg Compress Pipeline)**：
  - **痛点与官方限制**：
    1. Telegram 官方对 Bot 上传多媒体（`send_video`）设有 **50MB** 的死线，一旦视频超出 50MB 直接返回 HTTP 413 失败；
    2. 高清视频（60MB~100MB+）极度消耗主机出网流量（如 AWS 每月 100GB 免费限额），且移动端加载严重卡顿缓冲。
  - **解决方案**：视频发送前检测字节大小，超过设定阈值（如 **35MB**）时，自动调用本地多线程 FFmpeg 执行极速压缩：
    ```bash
    ffmpeg -y -threads 2 -i in.mp4 -vf "scale=-2:min(720\,ih)" -c:v libx264 -crf 28 -preset veryfast -c:a aac -b:a 128k out.mp4
    ```
  - **效果**：将 60MB~90MB 的大视频在 2~3 秒内压缩至 15MB 左右，画面高度等比限制在 720p，既 100% 绕开 Telegram 50MB 限制确保投递成功，又节省 70% 出网带宽，实现群友移动端秒开秒播。

### 3.1 Cloudflare Worker 无服务器视频/帖子解析 Telegram 机器人 (Serverless Worker Media Bot)
- **架构价值与适用场景**：
  - 当不希望占用本地/VPS 实例的进程与出网带宽时，使用 Cloudflare Workers 构建轻量、0 闲置成本、全球低延迟的 Telegram 解析机器人；
  - 适用于成人社区、短视频平台、私密论坛等视频帖子直链解析（如海角社区等平台）。
- **核心逆向与解密协议（3 层 Base64 信封与 M3U8 升级）**：
  1. **多层嵌套 Base64 加密**：目标 API（如 `/api/topic/{pid}`）常返回 `{"isEncrypted": true, "data": "..."}`，需经过连续 3 次 Base64 解码并处理 URL-safe 字符替换与 padding 补全，才能还原真实的 JSON 数据对象；
  2. **预览流推导完整流 (Candidate Synthesis)**：针对站方为未付费用户默认下发的试看预览流（如带有 `_preview.m3u8` 或 `_i_preview.m3u8`），利用路径正则推导替换（`_i_preview.m3u8` → `_i.m3u8`、`_preview.m3u8` → `.m3u8`、`_preview` → `/index`），免钻石解锁完整时长直链；
  3. **异步 Webhook 与防超时雪崩**：Telegram Webhook 必须在 1~2 秒内获得 HTTP 200 响应，否则 Telegram 会连续发起指数退避重试导致 Bot 遭遇重试风暴。Worker 必须采用 `ctx.waitUntil(handleMessage(...))` 执行耗时的上游请求与消息发送，主线程立即返回 `200 OK`；
  4. **凭据安全规范**：在 Cloudflare Worker 中绑定环境变量时，敏感项（如 `TG_BOT_TOKEN`、账号 `MEDIA_AUTH_TOKEN`）必须使用 `secret_text`，严禁明文上云；
  5. **完整可部署模板**：生产级脚手架见 `templates/cf-worker-tgbot-media-parser.js`。

---

### 4. 各群独立功能开关控制面板 (/settings)
- **控制维度**：
  - `quote`（名言贴纸）、`ai`（AI 问答）、`summary`（群总结）、`video`（视频去水印）、`music`（音乐点播）、`mute`（禁言风控）；
- **操作与权限隔离**：
  - 群内仅限 **机器人 Owner、本群群主 (Creator)、及授权 VIP** 可唤出并点击开关；
  - 面板按钮带实时状态指示灯（`🟢 开启中` ↔ `🔴 已关闭`），点击原地热切换；
  - 支持私聊远程遥控：Owner 私聊 `/settings` 列出所有已授权群组，隔空管理；
  - 陌生人私聊仅可见 `/help`，其余指令底层静默丢弃，防爆破与恶意刷屏。

---

### 7. 群聊定时总结与 `#总结` 标签归类架构 (Scheduled Summary & Topic Tagging)
- **业务诉求与设计理念**：
  - 总结卡片开头必须加上 `#总结` 话题标签，群友点击标签或在 Telegram 搜索栏输入 `#总结` 即可秒级串联群内所有历史总结，不破坏原生 `<details><summary>` 小三角折叠卡片视觉；
  - 允许自定义每天固定时间点（如 `22:00`、`12:00,22:00`）或循环周期（如每 `4h`）自动总结群内过去具体几个小时（如过去 `4h` 或 `6h`）的发言；
  - 提供指令（`/autosum`）与控制台（`/settings` 二级交互面板）双轨操作，兼顾群内管理与 Owner 私聊大盘遥控。
- **双轨控制形态与指令规范**：
  - **群内指令**：
    - `/autosum`：查看本群当前定时总结规则、上次执行时间与预计下次触发时间；
    - `/autosum 22:00 4h`：每天北京时间 22:00 自动总结过去 4 小时发言；
    - `/autosum 12:00,22:00 6h`：每天 12:00 与 22:00 分别总结过去 6 小时发言；
    - `/autosum 4h 4h`（或 `/autosum 每4小时 4h`）：每隔 4 小时自动总结过去 4 小时发言；
    - `/autosum test`：立即测试触发一次定时总结并投递到群内；
    - `/autosum off`（或 `0`）：关闭本群定时总结；
    - 自然语言捕获：支持群内直接输入 `定时总结 22:00 4h` 或 `自动总结 22:00 4h`。
  - **`/settings` 交互式二级面板**：
    - 集成 `⏰ 定时发言总结` 独立二级菜单，预设常用方案按钮：`🌙 每天 22:00 (前4h)`、`🌙 每天 23:00 (前6h)`、`☀️🌙 每天 12:00&22:00 (前6h)`、`🔄 4h整点循环`、`🔄 6h整点循环`、`🔄 8h循环 (7/15/23点)`、`⚡ 立即测试触发一次`、`🛑 关闭定时总结`；
  - **Owner 私聊大盘遥控**：
    - 私聊输入 `/autosum` 调出全部已授权群组的定时总结状态大盘及配置按钮，支持隔空配置 `/autosum <chat_id> 22:00 4h`。
- **周期循环定时任务的时钟整点对齐规范 (Integer Clock Alignment Pitfall)**：
  - **痛点现象**：若循环调度采用相对当前点击时刻简单累加（`last_run + interval`），当管理员在非整点（如 23:40）点击“8小时循环”时，后续触发时刻将永久滞留在非整数时间点（如 `07:40`、`15:40`、`23:40`），引发群友与管理员“时间点不是整数”、“为什么不是整点总结”的困惑；
  - **设计准则**：在 Telegram 群管定时任务设计中，所有循环类预设必须**默认对齐到自然时钟整点（00 分）**，底层统一映射为确定性时刻列表（`daily_time`）：
    - **8h 循环**：严格锁定 `["07:00", "15:00", "23:00"]`（早 7 点查阅夜间讨论、下午 15 点查阅上午、晚 23 点查阅下午及晚间，完美对齐社群作息）；
    - **6h 循环**：严格锁定 `["00:00", "06:00", "12:00", "18:00"]`；
    - **4h 循环**：严格锁定 `["00:00", "04:00", "08:00", "12:00", "16:00", "20:00"]`；
  - 杜绝任意分钟漂移，让管理员和群友对总结触发时刻（如“明日 07:00”）具备 100% 确定预期。
- **后台调度与防重复执行机制 (`services/scheduler_service.py`)**：
  - **时区标准**：严格对齐北京时间 (UTC+8)；
  - **槽位幂等防重跑 (`last_run_slot`)**：每天固定点模式记录 `YYYY-MM-DD_HH:MM` 时间槽（如 `2026-09-13_22:00`），并在触发判定时比对；只有未跑过的槽位才进入执行逻辑，彻底防止 30 秒轮询重复触发；
  - **样本保护与静默防刷屏**：回溯窗口内若有效发言少于 3 条，调度器自动静默跳过（不向群内发送冷启动或空白总结刷屏），测试模式 (`is_test=True`) 则明确回显样本不足提示；
  - **排版与通道保底**：优先走 `sendRichMessage` 投递原生折叠小三角卡片，超长自动拆包分段（`split_summary_chunks`），富文本不可用时保底转换为 HTML `blockquote expandable` 发送。

---

### 8. 大模型多级自动降级容错与动态调度中心 (LLM Fallback & Dynamic Model Center)

> 完整实现细节与踩坑排障见 `references/dynamic-llm-pool-and-scheduled-summary.md`

- **业务诉求与去中心化自愈**：群内 `ai` 问答与 `/sum` 群聊总结要求极速响应与高可用。中转站（LFree）主用保证速度与高并发，反重力（Gemini 3.8）等作为稳健兜底；同时必须让机器人拥有者具备**脱离服务器终端也能在 Telegram 内随时换心换脑、换 API Key、改模型代号、添加第三方 API 端点的能力**。
- **双 Bot 混合解耦架构（API 池子全域统一共享，各 Bot 具体模型与优先级完全独立）**：
  - **统一 API 端点池 (`data/ai_endpoints.json`)**：
    - 集中保管所有接口地址（URL）、API Key 与预置默认模型；
    - 爸爸在任一 Bot 发送 `/setapi` 或 `/setkey` 录入新凭据后，**两台 Bot 自动同步享用同一套底座连接池**，绝不需反复录入两次；
  - **分 Bot 独立模型调度 (`data/ai_bot_{BOT_ID}.json`)**：
    - 各 Bot 独立维护自身的 `order`（首选与兜底顺序）、`disabled_nodes`（专属停用开关）与 `model_overrides`（专属模型代号定制）；
    - 主 Bot (`@yecaodi_bot`) 可以在 `/model` 面板把 `LFree·Claude` 设为首选主用；
    - 分身 Bot (`@qunba_bot`) 可以在 `/model` 面板把 `反重力·Gemini3.8` 或 `日日新·DeepSeek` 设为首选主用；
    - 某端切换主用模型或修改模型代号（`/setmodel`），**100% 仅对当前 Bot 生效，互不干扰**；
  - **Telegram 原生私聊控制面板 (`/model`)**：
    - 面板顶部动态回显当前操作的 Bot 身份（如 `主 Bot (@yecaodi_bot)` 或 `分身 Bot (@qunba_bot)`）；
    - 大盘展示当前 Bot 的完整调用链顺位（1. 👑 首选主用，2. 🛡️ 备用兜底...）；
    - `⚡ 一键全节点测活`：并发 Ping 全部节点（轻量 user "ping" 提示词，max_tokens=5），实时回显各节点毫秒延迟与 HTTP 状态（如 `200 OK (1.8s)`、`429 配额耗尽`、`504 超时`）；
    - 单节点详情面板：点击对应节点按钮，支持【🌟 置顶此节点为主用】、【启停开关】、【单独测活】与【删除自定义节点】；
  - **私聊指令动态热配置与密钥安全自动秒删**：
    - `/setapi <ID> <URL> <KEY> <MODEL> [中文名称]`：向统一池新增/更新端点，并在当前 Bot 置顶为主用；
    - `/setkey <ID> <新Key>`：同步更新统一池中该节点的 API Key；
    - `/setmodel <ID> <新模型名>`：为当前 Bot 单独修改该节点的模型代号；
    - `/delapi <ID>`：从统一池删除自定义节点；
    - **严格敏感信息安全防御**：Bot 接收到包含明文 Key 的 `/setapi` 或 `/setkey` 后，**自动立即秒删该消息**，回显时对 Key 实施前四后四掩码保护（`sk-xxx...xxxx`），绝不让明文密钥留在 Telegram 聊天记录中。
- **环境隔离与密钥读取**：在 `services/ai_service.py` 中实现 `_read_env_val`，优先读取环境变量，未传时自动回退读取 `/home/ubuntu/.hermes/.env`，兼顾 systemd 守护进程与独立运行环境；请求头必须携带标准浏览器 `User-Agent` 防 WAF 拦截；
- **透明反馈**：若所有节点均耗尽，发送自毁临时提示明确告知原因，绝不静默装死；
- **深度思考（Thinking/CoT）模型总结泄露与双重过滤防御规范**：
- **痛点与现象**：当调用带 Thinking/Reasoning 机制的模型（如 `gemini-3.8-flash-high`、Claude Thinking、DeepSeek-R1）执行群聊总结或 AI 问答时，模型不仅会在正文前吐出自言自语的分析草稿（例如“分析106条消息...梳理...这话题值得单独”），还会主动将自身推理过程包装为 `<details><summary>💭 思考与分析思路</summary>...</details>` 等看似合法的折叠卡片，直接随正式总结一起发送到群公屏；
- **根本原因**：普通正则仅过滤了显式 `<think>` 标签，大模型自己起带有“思考/思维/分析思路”等标题的业务卡片，或者在卡片之前裸打草稿分析，会直接穿透放行；
- **加固与防护闭环**：
  1. **System Prompt 绝对红线**：在 `SUMMARY_SYSTEM_PROMPT` 的格式红线中明确：*“严禁输出任何思考过程、思维链、分析草稿或自言自语（严禁输出 <think>、<thought> 或以思考/思维为标题的卡片）！直接输出纯净的 <details><summary> 业务卡片语法。”*
  2. **后置全量清洗与硬斩断 (`_clean_card_content`)**：
     - 显式标签剥离扩充：包含 `<think>`、`<thought>`、`<thinking>`、`<reasoning>`、`<reason>` 及其代码块；
     - 伪装卡片深度正则剔除：正则匹配 summary 包含 `思考|思维|thought|thinking|reasoning|思路梳理|分析思路|分析过程|分析记录|推理|推导|内心OS|思维链|Chain-of-thought|CoT` 的 `<details>` 整体剥除；
     - 严格业务卡片前置锚定：以前置首个合法业务 `<details>` 为界斩除其前所有字符（彻底清除任何前置分析草稿），从最后一个 `</details>` 斩除其后杂质；
  3. **修改代码后双 Bot 必须全部热重启生效**：修改 `ai_service.py` 后必须同时执行 `sudo systemctl restart lemon-group-bot.service` 与 `sudo systemctl restart lemon-group-bot2.service` 并校验 status 处于 `active (running)`，杜绝分身 Bot 漏重载导致线上故障。
- **Telegram 原生富文本降级死穴与 HTML 转义吞字避坑 (Rich Message Fallback & HTML Escaping Traps)**：
  - **痛点现象 A（总结/回答发送失败）**：`sendRichMessage` 发生 `Rich_message_content_required` 等偶发错误触发降级时，由于直接使用 `send_message(parse_mode=HTML)` 投递带原生 `<details>` 的文本，Telegram 报 `Can't parse entities: unsupported start tag "details"` 导致发送彻底崩溃；
  - **解决方案 A**：在总结与群聊 AI 问答的所有降级链路中，强制执行双层转换：正则将 `<details>\s*<summary>(.*?)</summary>(.*?)</details>` 替换为 Telegram 官方原生支持的 `<blockquote expandable><b>\1</b>\2</blockquote>`，并将 `**粗体**` 转为 `<b>`、Markdown 链接转为 `<a>`，最后全量剔除任何未匹配的残留 `</?(?:details|summary)[^>]*>` 孤立标签；
  - **痛点现象 B（文字丢失与悬空连续顿号）**：向 Telegram 发送包含技术标签（如解释 `<think>`、`<thought>`、`<details>` 等）的通报或消息时，未用行内代码块包裹或实体转义，Telegram 解析器直接将其当做非法的自定义 HTML 标签并静默隐藏，原本的文本在手机端呈现为诡异的连续悬空顿号（如 `、、、、<reason>`），排版彻底损毁；
  - **解决方案 B**：在任何向 Telegram 客户端汇报的消息中，凡涉及 HTML 标签名、正则符号或变量，必须严格放入行内反引号代码块或转义为 `&lt;tag&gt;`，严禁在常规文本中裸打裸发尖括号；同时避免滥用 Markdown 多级列表混杂导致语法符号原样暴露。

---

### 6. 群聊禁言风控与 Telegram `restrictChatMember` 解禁反弹陷阱 (Mute & Unmute Protocol)
- **指令矩阵**：
  - `/mute [时长]` 或回复某人发 `禁言`：禁言目标成员（默认 10 分钟，支持 `10m`, `2h`, `1d`）；
  - `/unmute` 或回复某人发 `解禁`：立即解除目标成员禁言，恢复全量发言权限。
- **权限边界与安全底线**：
  - 严格限制：仅限机器人拥有者（Owner）、本群群主（Creator）、以及当前群授权特权人员（VIP）可触发；
  - 防越权保护：严禁禁言 Owner、全局 VIP，以及本群群主（接口拦截）。
- **Telegram 底层解禁反弹隐形陷阱 (The Partial Unmute Trap & Rebound Bug)**：
  - **痛点现象**：管理员对群友执行 `/mute` 后，又使用 `/unmute` 解除禁言；群友当即可以发送简短文本，但**过了一段时间后（或客户端重连/数据中心同步/群权限刷新时），群友的发言框再次被锁死，禁言再次复发**！
  - **根本原因剖析**：
    1. Telegram Bot API 官方并没有单独的 `unrestrictChatMember` 接口，解禁必须依然调用 `restrictChatMember`；
    2. **官方协议强制准则**：*“Pass True for all boolean parameters to lift restrictions from a user.”*（要彻底解除限制，必须对所有布尔权限传入 True）；
    3. 若代码在解禁时仅手动构造常见发信权限（如仅设置 `can_send_messages=True` 等 10 项，遗漏了 `can_change_info`, `can_invite_users`, `can_manage_topics`, `can_pin_messages`）：
       - Telegram 服务端会**判定该用户的限制并未解除**，该群友在群组中的身份依然被死锁在 `ChatMemberStatus.RESTRICTED`（受限成员黑名单中）；
       - 由于解禁未显式传递合法的 `until_date`，Telegram 会将未放行项默认为 `until_date: 0`（永久受限）；
       - 一旦群友客户端刷新、与 DC 重新同步群成员元数据，客户端便会重新将该用户判定为受限，造成输入框再次锁死的“禁言反弹”假象；
  - **标准解决方案**：
    - 在解禁逻辑中，**绝对不要手动拼凑部分权限字典**；
    - **必须且只能传入 `ChatPermissions.all_permissions()`**：
      ```python
      # 正确范式：全量权限置为 True，彻底使 Telegram 服务端清除限制
      await bot.restrict_chat_member(
          chat_id=chat.id,
          user_id=target_user_id,
          permissions=ChatPermissions.all_permissions()
      )
      ```
    - 执行后，用户的 Telegram 身份将从 `ChatMemberStatus.RESTRICTED` 真正彻底复位为正常普通成员 `ChatMemberStatus.MEMBER`，`until_date` 变回 `None`，从协议层面彻底消除反弹隐患。
- **限时禁言到期 ≠ 自动解禁（第二个独立反弹元凶，2026-09-13 实测实锤）**：
  - 现象：群友被 `/mute 10m` 等限时禁言后，管理员从未来得及调用 unmute，但**禁言时长到期后群友依然发不出消息**，体感「禁言又触发了」；
  - 底层真相：Telegram `restrictChatMember` 带 `until_date` 到期后**并不会自动把成员恢复为全权限 member**——服务端只是把 `until_date` 置为 epoch 0（`1970-01-01`），成员身份停留 `ChatMemberStatus.RESTRICTED`，权限保持禁言时的全 False 值，直到有人显式下发 `all_permissions()` 才解除；
  - 实测案例：群友 `6245931101` 凌晨被默认 10 分钟禁言，数小时后 `get_chat_member` 仍返回 `restricted` + `until_date=1970-01-01`，显式调用 `ChatPermissions.all_permissions()` 后才复位为 `member`；
  - **运维体检/自愈模式**：Bot API 没有枚举群成员的接口（无 getChatMembers），排查「禁言反弹/成员被卡死」时，用 `bot.db` 的 `messages` 表按 `chat_id` 取最近活跃的 `DISTINCT user_id` 作为待检名单（可叠加已知活跃群友 ID 补充），逐个 `get_chat_member` 扫描 `status=restricted` 且 `until_date` 为 epoch 0 的残留受限成员，凡命中一律 `restrict_chat_member(permissions=ChatPermissions.all_permissions())` 修复并复查状态翻转回 `member/None`；建议做成 Bot 启动自检或定时巡检；
  - **排障提示**：群友发「禁言/解禁」文字指令但**没有回复目标消息**时，Bot 只弹一条使用提示就 return，**不产生任何 `execute_mute` 日志**——群友报「Bot 没反应/出bug了」且日志空白时优先怀疑这个，而不是进程故障；
  - **只读审计禁止动 UserBot session（实测）**：仅查询成员/限制状态时，Bot API（`get_chat_member` / `get_chat_administrators` + 本地 `bot.db` 的活跃成员名单）完全够用且零风险；**不要**为了只读检查去复制正在使用的 `.session` 开第二个客户端——同 auth_key 并发有 `AuthKeyDuplicatedError` 风控隐患，且复制会话往往 `get_dialogs` 找不到目标群（该群不在 UserBot 对话框列表时直接返回空），纯属多余动作。
  - **一键体检/修复脚本**见 `scripts/audit_restricted_members.py`（复用 `lemon-group-bot` 项目 venv 与 config，扫描活跃成员，`--fix` 自动修复残留受限）。
