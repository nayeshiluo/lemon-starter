---
name: telegram-group-bot-suite
description: "构建与运维 Telegram 全能群聊机器人：多卷贴图、音乐点播与群开关、多实例复刻。"
version: 1.7.0
author: Hermes Agent
license: MIT
platforms: [linux, macos]
metadata:
  hermes:
    tags: [telegram, bot, quote-api, sticker, music, netease, group-bot]
    related_skills: [telegram-quote-sticker, telegram-group-assistant]
---

# Telegram 群聊全能管家系统架构与运维规范 (Telegram Group Bot Suite)

## 已经有的、别再重复造的机制（2026-11 核实）

判断「要不要借鉴外部项目加某个机制」时先查这张表，避免给已有能力再套一层。

| 机制 | 群霸实现 | 位置 |
|---|---|---|
| Telegram 更新去重 | `guard_update_replay` 挂 `TypeHandler(Update, ...)`，`group=-4` | `bot.py` ~444 |
| 编辑消息重审 | `is_edited_update()` 在 commands/messages 多处早退 | `services/interactive_jobs.py` |
| 命令绕过防护 | `reject_other_bot_commands`（`group=-5`）+ `command_guard.py`「副作用前拒绝」 | `bot.py` ~450 |
| **乐观锁 / 版本 CAS** | `menu_sync.jobs` 表带 `revision`：入队 `revision=jobs.revision+1`，处理时 `DELETE/UPDATE ... AND revision=?` | `services/menu_sync.py` ~17/25/47/50 |
| 陌生人私聊 / 拉群提醒 | `alert_private_message` + `audit_my_chat_member` | `services/contact_alerts.py` |
| 按群查询隔离 | 所有查询带 `chat_id` / `bot_id` | `database.py` |
| 日志脱敏 | `services/log_safety.py`（handler 级 filter + formatter，含 traceback） | 见上节 |

`menu_sync` 的 `revision` 是**完整 CAS 乐观锁，不是单纯自增计数**：任务处理期间若被
重新入队，revision 已变，旧的 `DELETE`/`UPDATE` 会匹配 0 行，不会误删或覆盖新任务。
所以「多端改配置互相覆盖」这个风险**已经不存在**，不需要再引入外部项目的 revision 方案。

**判断原则**：外部项目某机制「看起来高级」时，先在本仓库 grep 三轮（字段名、表名、
以及该机制的同义实现），确认没有再做移植评估。本次差点为群霸补一套「配置乐观锁」，
实际它早就有，而且是更贴合其 SQLite 队列模型的实现。

## 本部署现行边界（优先于历史案例）

以运行中源码和配置为准。Owner 未开放的功能，群主/管理员不得自行开启；禁言、Ban、解封等危险能力独立授权。旧解析仅归档，中转失败不重新启用。修改技能文本不等于改 Bot 代码，不要求重启 Bot。

### 配置“自己变了”：先查并发 Hermes 会话，别急着判未授权

本机 Web UI 常驻多个 Hermes worker（`hermes_bridge.py --worker-profile default`，各自不同 socket）。另一个会话可能在同一项目目录改 `data/ai_bot_*.json`、`ai_timeout_overrides.json`、`gemini-recovery-revert.py` 并重启服务，当前会话毫无感知。实测一次差点被误判成入侵并回滚。

- **症状**：`order` 位次变了、`overrides` 多出条目、服务在非本人操作时段重启，且**没有对应 `.bak-*`**。
- **取证顺序**（全只读）：`ls -l --time-style=+%m-%d_%H:%M:%S data/ai_bot_*.json data/ai_timeout_overrides.json` 取精确改动时刻 → `journalctl --since/--until` 该时刻 ±2 分钟，抓 `sudo[..]: ubuntu : PWD=<项目目录> ; COMMAND=/usr/bin/systemctl restart ...` 的 **PWD 字段**（判定“谁在项目目录下动手”的关键证据）→ `ps -eo pid,lstart,cmd | grep hermes_bridge` 数 worker 与启动时间。
- **禁止**把“配置与预期不符”直接当未授权变更回滚。先核对另一会话是否已同步相关常量（本例它连 `DEMOTED_ORDER`/`RESTORED_ORDER` 一起改了，`drift=False`，自动还原仍有效）。回滚一个正确的并发改动才是真损坏。
- **判好坏用实测不看位次直觉**：跑 `scripts/verify_summary_chain.py` 对比耗时（本例 13.4s 优于改前 16.7s → 是改进）。
- 同一套群霸配置只在一个会话里改；发现并发改动先向 Owner 确认来源，不要自行“修复”。

完整时间线与复现命令见 `references/concurrent-config-drift.md`。

## 舰队 LLM 盘点与迁移边界

用户要求只读盘点时，不写配置/IPC、不临时 toggle 生产节点、不重启，也不另开 Telegram session。先按 systemd 反查实际入口，再区分活动请求、禁用节点、默认兜底、UI 回切与自动恢复；按文本/工具/视觉用途实测选择，文本通过不代表视觉可盲替。递归扫描必须在进入目录前剪枝备份与部署快照，不能只过滤文件名；敏感值在工具输出前即脱敏。源码入口、跨供应商主备与完整检查清单见 `references/fleet-llm-migration-audit.md`。

**整舰队统一迁移（Command 主 / 周三备，2026-11-06）**：端点池、双 Bot `order`/`disabled_nodes`、Ops `/ai`、UserBot 总结/AI/生图 prompt 扩写的具体改法、离线验收与重启排空清单，见 `references/fleet-llm-command-zhousan-cutover.md`。三条硬判据：① 主备必须不同站点，同站换模型名不算容灾；② `get_active_chain()` 顺序正确只证明配置，必须再发真实请求看落点；③ 改 JSON 热生效，只有改 `.py` 才重启。

**⚠️ 该 cutover 快照已作废（2026-11-19 现行：workbuddy 主 / magpie 备 / zhousan 三备，`lg` 禁用）**。
Owner 问「梯队是啥样 / 分别是谁的模型」时的现行快照、溯源三问（节点名 ≠ 上游实体）与只读盘点命令，
见 `references/llm-chain-provenance-inventory.md` + `scripts/probe_chain_provenance.py`。

## ⚠️ 先认身份：群霸 ≠ 感思你（实测被用户当场纠正）

「群霸」= **本项目** `/home/ubuntu/lemon-group-bot`（两个 systemd 服务 `lemon-group-bot` +
`lemon-group-bot2`，共享 `data/`，Bot <PRIVATE_IDENTIFIER> / <PRIVATE_IDENTIFIER> / <YOUR_USER_IDENTIFIER> 三份配置）。
「感思你」= **另一个项目** `/home/ubuntu/smart-group-bot`（Docker，`network_mode: host`，
`@gansini120bot`）。`gansini` 只是「感思你」的拼音，**不是群霸**。
用 Bot Token 前缀反查可定项目，但群霸的 token 不在 `.env` 里直读，**必须再用
`systemctl is-active lemon-group-bot lemon-group-bot2` 交叉确认是不是双服务**，
否则只改了一半还以为改完了。

## 模型配置的四个落点（改模型必查，缺一个就"看着改了没用"）

| 文件/位置 | 内容 | 生效 |
|---|---|---|
| `data/ai_endpoints.json` | 节点表 `{id: {id,name,url,key_env,default_model}}`；**`url` 是完整路径**，含 `/chat/completions` | 热生效 |
| `data/ai_bot_<bot_id>.json` | `order`（顺序回退链）/ `disabled_nodes` / `model_overrides` / `reasoning_effort` / **`summary_model_overrides`** | 热生效 |
| `.env` | **只有** `TELEGRAM_BOT_TOKEN` / `OWNER_ID` / `NEWFOUAPI_API_KEY`；新增源要自己补 `<ID>_API_KEY` | 需重启 |
| `services/ai_service.py` / `config.py` | 代码里的默认端点（含硬编码 `127.0.0.1:8317`） | 改 `.py` 才重启 |

两条最容易错：① `key_env` 是**变量名不是值**；② `url` 必须带 `/chat/completions`，
与 OpenAI SDK 那种只写到 `/v1` 的写法不同 —— 接第三方网关（如 magpie
`http://127.0.0.1:3425/v1/chat/completions`）时就卡在这里。
日常问答读 `default_model`，**总结/日报读 `summary_model_overrides[<节点>]`**，两处分开改。
接网关的完整实测与按角色改法见技能 `magpie-gateway-ops`
的 `references/containerized-client-onboarding.md`。

## When to Use
- 在 Telegram 构建或维护全能群聊机器人（如「群霸项目」）；
- 实现高保真 Q 图贴纸生成（支持 `q`、`qh`、`q N` 正负向提取、会员 Emoji 状态图标、群主紫/管理绿/群员灰三色标签、同人连续合并单头像）；
- 实现贴纸入库（`qs`）带包按钮、贴纸删除（`qd`）与贴纸包满 120 张自动扩容多卷（Vol.2, Vol.3）；
- 实现网易云音乐点播与解析（`/music 歌名/ID/链接`、Top 5 交互式数字点播、官方直链 + B站 Hi-Res 专线中继双轨兜底）；
- 搭建**音乐库预热缓存架构**（廉价 VPS 离线爬取转码 → Telegram 频道中转 → 主站 0 流量 `file_id` 秒发）。
  ⚠️ **2026-11-03 核实：这套「秒发」在现行点歌路径里并没有接上** —— `send_music_file()` 只调 `try_race_music()`，
  `get_prewarmed_file_id()` 全项目零调用点；且 `bot_prewarm_cache` 里 bot1 有 2257 条、bot2 只有 23 条
  （`file_id` 按 bot 隔离，不能跨用）。谈「点歌秒发」前先按 `references/music-search-latency-triage.md` 核实，
  不要照架构稿承诺能力；
- 实现群聊智能总结与排障重构（彻底根治“太假”与“对应不上”：双轨持久化防重启断层、非线性回复链与时间戳注入、去八股化自适应 Prompt、来源直链精准对齐；**统一开头注入 `#总结` 标签；支持 `/autosum` 与 `/settings` 二级面板定时总结前 N 小时发言**）；
- 实现各群功能独立开关控制面板（`/settings`、实时指示灯、零公网端口暴露防爆破）。

---

## 日志脱敏（2026-11 已落地双 Bot，别再重写一遍）

`services/log_safety.py` 已存在，提供 `sanitize()` 与 `SanitizingFilter`，覆盖 6 类：
TG bot token、`sk-`、GitHub token、AWS AK、`Bearer/Basic`、URL 内嵌 `user:pass@`、
URL query 密钥参数，外加零宽/双向控制字符（防日志注入）。`bot.py` 在
`logging.basicConfig(...)` **之后**调用 `install_log_sanitizer()`，已带 try/except 兜底。

**改的是 `.py` → 必须 `systemctl restart lemon-group-bot lemon-group-bot2` 两台都重启。**

### 铁律：Python 的 logger 级 filter 对子 logger 无效

```python
# 错：logging.getLogger().addFilter(f) —— 子 logger 的 record 走 handler，不经过 root logger 的 filters
# 对：挂到 root 已有的每个 handler 上
for h in logging.root.handlers:
    h.addFilter(SanitizingFilter())
```

- 这是「装了脱敏但日志照样漏」的头号原因，自检必须用**子 logger 名**（如
  `logging.getLogger("selftest.child")`）打日志验证，用 root logger 测会假通过。
- 调用顺序：先 `basicConfig()` 建出 handler，再挂 filter，否则 `root.handlers` 是空列表。
- filter 内先 `record.getMessage()` 套用 `%s` 参数再脱敏、随后 `record.args = ()`，
  否则参数里的凭据漏网；`return True` 永不丢日志。
- 验收：重启后 `journalctl -u lemon-group-bot -u lemon-group-bot2 --since '4 min ago' | wc -l`
  日志行数正常（没被吞）+ `grep -cE '[0-9]{8,10}:AA[A-Za-z0-9_-]{30,}'` 为 0。

## 视频解析展示调整

用户要求纯媒体回传时，视频/图片的 caption 必须显式置空（`copy_message` 省略 caption 会继承源文案）；相册与多段视频也必须逐项处理。仅确认 `done` 后将进度/心跳卡延迟 5 秒删除，失败与 uncertain 提示保留；音乐附文、Q 贴图与用户原消息不动。延迟删除任务不得被结束心跳的 `close()` 取消。实现路径、实时间隔测试及进程重启边界见 `references/video-clean-output-and-progress-cleanup.md`。

## `/help` 富文本卡片（2026-11-05 已落地，双 Bot）

Owner 拿别的项目的 `/help` 截图说「要一样好看」时，**先判那张图是什么做的**，别直接上反引号 code：

- 卡片本体 = **整个内容包进一个 `blockquote`**（客户端渲染成左侧蓝条 + 浅蓝底 + 右上引号），段内每行**行尾双空格**硬换行，段间插一行单独的 `>`。普通换行会被合并成一行，这是最容易白改一轮的坑。
- 截图里命令的**蓝色来自 Telegram 自动识别的 `bot_command` 实体**（纯文本 `/sum： 说明` 就会蓝，且只蓝命令本身）。用反引号包命令得到的是等宽+灰底 `code` 实体，跟参考图不是一回事 —— 放大会发现 `/lm add <内容>` 里只有 `/lm` 是蓝，这就是判据。
- 代价：`q`/`qh`/`qs`/`qd` 这类无斜杠触发词不会变蓝。接受它，别混用 code 造成两种风格并存。
- 发送统一走 `handlers/commands.py` 的 `_send_help_card()`：`sendRichMessage` 优先，`reply_markup` 要 `markup.to_dict()`；只有明确被拒才降级原 HTML 文案，`is_ambiguous_delivery_error` 为真则**不重发**。改的是 `.py` → 重启两台。
- 本机没有 Telegram 客户端，**验收看服务端返回的 `rich_message.blocks`**（`scripts/rich_help_probe.py`），别凭想象报「已生效」；给 Owner 的样张只留一条并说明可删。

完整配方、实测对照表、PTB 探针三坑（`Bot.do_api_request` 不可 monkeypatch 等）见 `references/rich-message-help-cards.md`。

**参考截图就是 Smart Group Bot（SGB）的 `/help`，不是「感思你」另一个项目**（2026-11-05 更正，此前本技能误记「SGB 根本没有 `/help`」）。判据：截图里 `/lm` `/lm add` `/voteban` `/av` `/addrule` `/rules` `/warnings` `/clearwarnings` `/spam` `@admin` 逐条对应 `/app/bot/utils/command_catalog.py` 的 `CommandEntry`。它是本机 docker 容器 `smart-group-bot-bot-1`（源码只在镜像里，宿主 `/home/ubuntu/smart-group-bot` 只有 compose + 配置）。

**它的卡片走的是 HTML lane，不是 rich lane**：`cmd_help` → `_answer()` → `bot/services/message_templates.py::render_action_notice()` → `"<b>标题</b>\n\n<blockquote>正文</blockquote>"`，普通 `sendMessage(parse_mode=HTML)`。所以复刻这套观感**不需要 Bot API 10.x**：

- 新 Bot 接入优先用 HTML `<blockquote>`：零依赖、`reply_markup` 原生可用、无需 `is_ambiguous_delivery_error` 降级逻辑，与参考实现逐像素同源。
- 已经用 `sendRichMessage` 的（群霸、LemonOps）不必回改；两种 lane 客户端渲染同为左侧蓝条卡片。
- 标题位置两派都行：SGB 把 `<b>标题</b>` 放在卡片**外**，群霸放在卡片**内**首行。同一舰队要统一，别一半一半。

**全舰队落地矩阵（2026-11-05，逐台文件路径/取 token 方式/重启命令）见 `references/help-card-fleet.md`。** 已改完的：群霸双实例、LemonOps（`main.py::send_help_card()`，与群霸三处差异：无 `services.summary_delivery`、降级走 Markdown、`update.effective_chat` 需 None 守卫）、破甲 `@pojai120_bot`（裸 HTTP `sendMessage` + `parse_mode=HTML`，`send()` 需新增 `parse_mode` 参数）、大肥鱼 `@dafeiyu120_bot`（diaomao AstrBot 4.29.3，幂等补丁脚本 `/root/astrbot-help-card-patch.py`，与 `astrbot-zh-menu-patch.py` 并列、互不覆盖；AstrBot 走 `telegramify_markdown.markdownify()` + `MarkdownV2`，`>` 引用能正确转出）。Emby bot 代码已改但**服务未部署**，无法渲染验收。

**改完 `/help` 命令不等于改完 help —— 一个 Bot 往往有第二个入口。** 本会话 Owner 一句「hermes 的 help 呢 没弄吗」就是踩在这上面：LemonOps 的 `/help` 命令已经出了卡片，但主菜单那个「❓ 帮助 / 关于柠檬」按钮走的是 callback `m:help`，是另一段独立代码，还在发旧的 Markdown 纯文本。动手前先 `grep -n "help_command\|m:help\|get_help_text\|build_help_text"` 把所有引用点列出来，逐个改，再一起验收。同类第二入口还有 `/start`（群霸的 `cmd_start` 两个私聊分支）与菜单里的「使用说明」按钮。

**legacy `ParseMode.MARKDOWN` 不认 `blockquote`**，会把 `>` 原样打出来。要给 `editMessageText`（callback 场景只能编辑不能重发）上卡片，必须走 `parse_mode=HTML` 的 `<blockquote>`。维护两份文案容易漂移，正解是**一份 `lines` 列表 + 两个渲染器**：`_rich_quote(lines)` 出 markdown lane 给 `sendRichMessage`，`_html_quote(lines)` 把 `**x**` 转 `<b>x</b>` 再整块包 `<blockquote>` 给编辑/降级用（`html.escape(quote=False)` 后再替换，顺序别反）。

**Owner 说的「hermes」可能不是你以为的那台。** 舰队里叫 hermes 的有两个：`@hermes_fxo6rwwchvtfrm7k_bot`（= `lemon-ops-bot`）与 `@awsjiba_bot`（= `hermes_cli.main gateway run` 主网关 Bot）。本会话把 LemonOps 改完汇报后 Owner 才回「是这个 @awsjiba_bot」，白做一轮。**先按 username 反查进程再动手**（`ps -eo pid,cmd | grep "hermes_cli.main gateway"`）；拿不准就直接问是哪个 `@username`，别按昵称猜。

**多台连改时的进度节奏**：一次改 4~5 台会连着几十个工具调用，Owner 会在中途连发「好了没 / 好了？/ ？」。每完成一台先回一句「X 已改完并重启，接着做 Y」，不要攒到最后一次性汇报；中途踩空或改错要当场认，别留到总结里补。

判截图字体/颜色**必须先裁到单行**：粗裁 `[0,120,700,520]` 会把整条命令看成蓝色，收紧到 `[40,380,700,470]`（单行 `/lm add <内容>`）才看清「只有 `/lm` 蓝、`add` 与参数是黑」。一次粗裁就下结论会白改一轮。

## 「一条 q 出两张贴纸」：双系统撞车 vs updates 重放（2026-11-21 实测）

Owner 报「最近 q 都生成两次贴图」时，**不要先怀疑 quote-api / 渲染服务**。症状相同、根因两个，必须靠日志分开：

| 根因 | 判据 | 处置方向 |
|---|---|---|
| **双系统撞车**：本 Bot 的 quote feature 与该群人型号（Telethon userbot）同时监听同一条 `q` | `journalctl -u lemon-group-bot -u lemon-group-bot2 \| grep 'admitted kind=quote'` 出现同群同分钟 job | 群里二选一：人型 `quote_handler` 群聊直接 return，或关该群 `group_features.quote` |
| **updates 重复投递**：只有人型一条腿也会双份（Telegram 补拉 difference 重放同一条 NewMessage，人型 handler 无幂等） | 两次渲染前后伴随 `Got difference for channel <id>`；两次 `Uploading file of N bytes` 的 N 完全相同 | 人型侧加 `(chat_id, reply_to_msg_id)` 30s 去重锁（群霸侧已有 `guard_update_replay`，不受影响） |

**取证顺序（全只读）**：群 username → chat_id 用 `getChat?chat_id=@<username>`（`getChatMember` 的 `user_id` 不接受 @username）；再对时间线（群霸 `admitted/finished` vs 人型 `Generating quote sticker`）；最后用 session 只读副本拉群消息，按 `reply_to_msg_id` 分组找重复贴纸组。

两个反直觉点：`Delete command failed` 为 0 **不能**排除重放（Telegram 删已删消息不报错）；「群里有几个 bot」不是证据，要查 quote job 日志 + `group_features` 白名单。完整证据链、判据表与复现脚本见 `references/quote-duplicate-attribution.md` + `scripts/audit_quote_duplicates.py`。

## 总结触发归因：先认消息与账号，再解释权限

遇到“别人发 `.sum` 也触发群霸”，先核对当前入口正则和归一化，再按 admitted 日志里的触发 message_id 对齐原文、机器人账号 ID 与回复链；相邻提示或显示名不足以证明归属。触发原文缺失时明确未知，不能推断它就是 `/sum`，也不能断言相邻响应一定来自第三方。入口是否识别、普通用户能否使用、参数上限及菜单可见性分别核查；问原因不等于授权改权限。核查步骤与本次证据边界见 `references/video-clean-output-and-summary-attribution.md`。

## 配套参考索引

本技能是**群霸双 Bot（@<PRIVATE_IDENTIFIER>_bot / @<PRIVATE_IDENTIFIER>_bot）的现行权威**。以下 references 于 2026-10-25 从 `telegram-group-assistant` 迁入——它们是群霸专属实现细节，此前误挂在 Hermes 网关 Bot 技能下。

| 文件 | 内容 |
|---|---|
| `references/group-sticker-and-quote-spec.md` | 贴纸/引用语义权威规范：直发贴纸禁带回复头、TextQuote 局部引用、会员 Emoji 状态、标签「宁缺毋滥」矩阵、`qh` 四级兜底、媒体复原与动图定格帧、`q N` 方向语义、`qd` 删除、120 张自动分卷 |
| `references/group-moderation-and-sticker-pack.md` | 群霸全景手册：`qs` 真实语义、贴纸包链接卡片、PTB 22.x 建包参数、会员 Emoji、身份标签、二级引用、视频零流量架构、内存环形缓冲、`/color`、`/mute` 白名单与分级菜单矩阵 |
| `references/per-group-feature-toggles-and-tag-enrichment.md` | 群组功能独立开关架构（`/settings`、Inline 状态按钮、单开/单关）、身份标签提取优先级、会员 Emoji、划选局部文字引用 |
| `references/music-bot-service-spec.md` | 网易云/全网音乐点播（@Music163bot 同款）：Eapi 320k 直链加密、黑胶 VIP 凭证、上传 `Timed out`、HTTP Range 长曲截断、SQLite `file_id` 秒播缓存 |
| `references/llm-fallback-chain-and-failure-surfacing.md` | 多级兜底链可复用骨架（`_call_llm()` 返回 `(content, err)`）、`reasoning_content` 坑、静默失败→限时自毁提示、端点探测表与验收清单 |
| `references/dynamic-llm-pool-and-scheduled-summary.md` | API 池/分 Bot 模型调度/定时总结完整架构 |
| `references/ai-fallback-layer-attribution.md` | **「为什么显示的是 X 模型 / 是不是网关挂了」归因层**：时间锚定（最后一次成功 vs 首次失败）、横向测家族区分「网关挂」与「单家族被上游拒」、上游 body 不在日志必须自己发探针、`ep["url"]` 已含 `/chat/completions` 再拼会全 404 的坑、`~/.cli-proxy-api/` 账号 mtime 痕迹、`/v0/management` 401 时的四条替代证据、修复选项代价排序与脱敏汇报口径 |
| `references/llm-chain-provenance-inventory.md` | **「梯队是啥样 / 分别是谁的模型」只读盘点**：现行快照（2026-11-19 workbuddy 主 / magpie 备 / zhousan 三备）、溯源三问（同一个 `workbuddy` 在群霸节点 / magpie provider 里是不同实体）、WorkBuddy2API `/status` 说 healthy 但全 503 的 `credit_floor` 坑、周三站无 UA 403 `1010` 坑 |
| `references/group-summary-troubleshooting.md` | 总结与 LLM 节点排障：超时定位、测活、候选窗口截断 |
| `references/daily-report-quality-triage.md` | **日报「太短/话题少」定量排查**：prompt 话题上限 3～5、归属校验丢条、`get_messages_by_time` 的 `max_limit=3000` 把 24h 窗口截成 ~10h、实测案例与修复选项 |
| `references/music-library-prewarm.md` | 音乐库预热缓存架构（廉价 VPS 爬取→频道中转→0 流量秒发）**⚠️ 架构设计稿，点歌路径当前未接入，见下一行** |
| `references/music-search-latency-triage.md` | **「点歌变慢 / 点不了」先看这篇**：A 搜索 / C 中转两段用 `MEDIA_ROUTE` 行区分、QQ 音源 HTTP 500 拖 5.2s 的实测、串行→并行+失败冷却的改法与验收、**预热库实际未接入**（`get_prewarmed_file_id` 只 import 未调用、bot2 仅 23 条、file_id 跨 bot 不通用）、`music_candidate_artist_mismatch` 的 diagnostics 读法 |
| `references/bot-token-replica-drift.md` | **Bot Token 多机副本漂移**：同 bot 一台正常另一台静默 401 的判据（sha 比对）、revoke 时间线取证、跨机同步（stdin 管道防 ps 泄露）、oneshot+timer 服务 `is-active=inactive` 的误判 |
| `references/owner-contact-alerts.md` | Owner 联系提醒：实现模板、舰队铺开清单、上线后硬伤（`tg://user` 可点链接 / JSONL 留档 / 加固 systemd 写路径）、验证红线 |
| `references/concurrent-config-drift.md` | 并发 Hermes 会话导致配置漂移的取证时间线 |
| `references/standalone-summary-bot-extraction.md` | **功能级脱敏拆包**：把总结/日报从群霸拆成独立可部署项目的模块清单、项目骨架、mock LLM 自检与验收阶梯 |
| `references/autosticker-native-pack-fallback.md` | autosticker 回落到群原生贴纸包导致「Bot 发别人的贴纸」误判为被黑的取证清单与处理选项 |
| `references/dead-group-config-cleanup.md` | **Bot 被踢出群 / 群废弃后的配置空转清理**：`getChat` 区分「被踢」与「群不存在」、`audit_events` 查 `bot_removed` 与匿名管理员、6 处配置残留 + `menu_state.db` 队列清理、热加载与"没被写回"验证 |
| `references/legacy-native-media-archive.md` | **历史归档**：旧原生下载/转码路径，仅在明确恢复请求时读 |
| `references/rich-message-help-cards.md` | **`/help` 做成富文本卡片**：单个 blockquote 的 markdown 方言（行尾双空格硬换行、空 `>` 分段）、命令蓝色来自自动 `bot_command` 实体而**不是**反引号 code、`_send_help_card` 降级策略、无客户端验收法与 PTB 探针坑 |
| `references/help-card-fleet.md` | **`/help` 全舰队落地矩阵**：群霸双实例 / LemonOps / 破甲 / Emby / SGB 基准 / 大肥鱼 逐台文件位置、各不相同的取 token 方式（`systemctl` vs `.config/lemon-ops-bot.env` vs `settings.json`）、LemonOps 导入需 `SUB_PUBLIC_BASE_URL`、假 Update 直调 handler 的端到端验收、SGB 容器内读法；**§1.1 双入口清单 + 一份 lines 两个渲染器（markdown lane / HTML `<blockquote>`）**；**§1.2 AstrBot 包内幂等补丁脚本写法** |
| `references/quote-duplicate-attribution.md` | **「一条 q 出两张贴纸」归因**：双系统撞车 vs updates 重放判据、username→chat_id（`getChatMember` 不收 @username）、session 只读副本取证、`Delete command failed` 为 0 不能排除重放、汇报口径与修复方向 |
| `references/relay-delivery-uncertain.md` | **中转回传 `state=uncertain` 排障**：`delivery_or_commit_unconfirmed` 三条易混文案出处、解析段 vs 回传段分段定位、用探针找回被覆盖的 `bridge_ids`、「原消息被删 → reply 失效」根因与 `reply_to_message_id` 探针、`send_with_reply_fallback` 修复与三处调用点、`RELAY_TRANSFER_FAILED` 日志、离线验收四用例 |

脚本：`scripts/audit_quote_duplicates.py`（**「一条 q 出两张贴纸」取证：session 只读副本拉群消息，按 `reply_to_msg_id` 分组找重复贴纸组**）、`scripts/probe_chain_provenance.py`（**模型梯队只读盘点：逐 Bot 打印 order/disabled/model + summary 覆盖，并对每个节点发真实最小请求打 `served_model`；不打印 key、不改配置**——Owner 问「梯队是啥样/分别是谁的模型」先用它）、`scripts/probe_relay_host.py`（**中转 host 解析探针：socket 直连 submit，打印完整 `result` 含 `album_types` / `video_parts` / `caption`，并提示相册策略风险**——判 HOSTS 该不该放行用它，别用只打 `bridge_ids` 的旧探针）、`scripts/rich_help_probe.py`（**富文本帮助卡探针：发一条 `sendRichMessage`，打印 Telegram 真实解析出的 `blocks` 类型树与 `bot_command` 数量，默认发完即删**；`--from-module handlers.commands:HELP_MD_PUBLIC` 可直测线上常量）、`scripts/probe_ai_chain.py`（链路体检）、`scripts/verify_summary_chain.py`（总结端到端验收）、`scripts/measure_daily_report_context.py`（日报素材量/窗口覆盖复算）、`scripts/daily_report_dryrun.py`（日报全链路干跑、不发群）、`scripts/audit_restricted_members.py`（受限成员体检/修复）、`scripts/relay_reply_probe.py`（判断某条消息是否已被删除、能否被 reply，探测消息发完即删）、`scripts/probe_music_search.py`（点歌搜索逐源计时，定位哪个音源在拖 timeout）、`scripts/verify_contact_alerts.py`、`scripts/verify_desensitization.py`、`scripts/verify_release_tree.py`（发布树扫描：额外拦 `.env`/db/state 等运行期文件，不误报测试假 ID，拆包项目优先用它）。
模板：`templates/standalone-quote-bot.py`（脱敏独立贴纸 Bot）、`templates/cf-worker-tgbot-media-parser.js`。

**边界**：Hermes 官方网关 Bot 的进群配置、observe 模式、总结格式规范、菜单作用域、权限矩阵、白名单鉴权 → 见 `telegram-group-assistant`。本技能不重复那部分。

## 核心功能模块与指令设计

### 1. 贴图与多卷贴纸包管理 (q / qh / qs / qd)
- **指令矩阵**：
  - `q`：单人金句贴纸，无回复头直发，秒删触发指令；
  - `qh`：带上一级回复历史的嵌套引用气泡（带原媒体缩略图）；
  - `q N`（如 `q 3`）：以被回复消息为起点【向下】顺延合并 3 条连续发言；
  - `q -N`（如 `q -3`）：以被回复消息为终点【向上】回溯合并 3 条连续发言；
  - `qs`：将名言或现有贴纸收录进本群专属贴纸包（**收录成功后仅发送带跳转链接与按钮的卡片，禁止重复发送贴纸原图刷屏**）；
  - `qd`：长按回复想要删除的贴纸发 `/qd`，校验管理员/群主/VIP权限后调取 `deleteStickerFromSet` 彻底注销移除，并即时使贴纸缓存失效；
  - `autosticker`：群聊发言活跃度自动随机发送贴图机制（支持群内 `/autosticker N`、`/settings` 二级面板预设点击切换，以及 Owner 私聊全局遥控）。
- **群聊活跃度随机贴纸池架构 (Autosticker Activity Trigger & Dynamic Pool)**：
  - **业务场景**：群聊活跃时，根据群内发言数量阈值（如每 50 条群友发言）自动从本群专属贴纸包（或群原生关联贴纸包）中随机抽取一张贴纸发送，提升互动趣味性；
  - **贴纸提取与多卷扫描**：
    - 优先扫描本群专属贴纸包 `g_{clean_id}_by_{bot_username}` 及其多卷扩容包 (`Vol.2`..`Vol.N`)；
    - 若专属贴纸包为空，自动回退探测群聊原生绑定的 `chat.sticker_set_name`；
    - ⚠️ **这个回落是「Bot 是不是被黑了」的头号误报源**（2026-10-29 实测）：群内从没成功做过 `/q` → 专属包 `g_{clean_id}_by_{bot_username}` 返回 `STICKERSET_INVALID` → autosticker 必然抽到群主自己绑定的官方包，Owner 看到「Bot 发了一张陌生贴纸包里的图」就会怀疑入侵。**先按 `references/autosticker-native-pack-fallback.md` 的四条只读取证（`getChat.sticker_set_name` / 专属包是否存在 / 源文件 mtime / `send_sticker` 调用点数量 / `getWebhookInfo` 为空）定性，再谈修复**；四条都对得上就直接回「不是被黑，是设计内降级」，别先动代码。
    - 处理优先级：① 只关该群（`group_autosticker_intervals[chat_id]=0`，JSON 热生效）→ ② 去掉回落（专属包为空就不发，`.py` 改动需 restart 双 Bot）→ ③ 引导群友做一张 `/q` 把专属包建起来。
    - **群名对不上以 `getChat` 为准**：`group_names` 是历史快照会过时，Owner 口述群名也可能记混（实例：口述「插画领域」，实际 `title=茶话领域`）。先用 `getChat` 的实时 `title`/`username` 定位，再拿 chat_id 回配置比对。
    - 贴纸 `file_id` 列表使用 5 分钟内存热缓存 (`_STICKER_CACHE`)，避免高频请求 Telegram Bot API 导致限流；
    - 在 `qs` 录入新贴纸或 `qd` 删除贴纸后，必须显式调用 `invalidate_group_sticker_cache(chat_id)` 即时刷新池子；
  - **发言计数与安全过滤**：
    - 非指令正常发言触发 `increment_group_message_count`；
    - 达到阈值后原子重置计数器并异步投递 `send_sticker`；
  - **多维操控入口**：
    - 群内指令：`/autosticker [数量]`（`0` 或 `off` 为关闭，无参数查看当前进度）；
    - `/settings` 控制面板：集成 `🎲 活跃度随机贴纸` 专属二级菜单，提供常用预设按钮（`20/30/50/80/100/200条`）与一键开关；
    - 私聊远程控制：Owner 私聊 `/autosticker` 查看所有群组大盘，支持隔空配置 `/autosticker <chat_id> <数量>`。
- **贴图与回复链核心避坑点 (Quote & Reply Chain Pitfalls)**：
  - **严格区分 `q` 与 `qh` 语义边界**：
    - `q`：单人金句贴纸，**绝对不带二级引用气泡**，纯粹突出被回复者的单人发言；
    - `qh`：带上文历史贴纸，**强制启动四级穿透回溯并渲染二级气泡**；
  - **Telegram Bot API 嵌套回复剥离与 `qh` 四级深度穿透体系**：
    - 官方协议陷阱：Telegram Bot API 在向机器人推送消息时，被回复消息对象的 `reply_to_message.reply_to_message` **恒为 None**（官方防止对象无限递归截断）；
    - 若纯靠内存记录消息链，重启或淘汰后 `reply_obj` 丢失，导致 `qh` 惨遭降级为单人贴纸；
    - **双轨四级回溯方案**：
      1. 路径 A：探测原生 `reply_target.reply_to_message`；
      2. 路径 B：从 SQLite `messages` 表依据 `reply_to_msg_id` 秒级深度回溯出真实被引用者 ID、昵称、正文与 `media_file_id`；
      3. 路径 C：提取 Telegram 7.0+ 原生文本引用（`msg.quote` / `external_reply`）；
      4. 路径 D：若目标发言未显式绑定回复链但群友发了 `qh`，兜底抓取群内**紧邻的前一条正常发言**作为对话上下文，保证 100% 输出双层气泡；
  - **全量消息持久化闭环（含纯媒体/贴纸）**：群友发送纯贴纸或纯图片时，也必须打上 `[贴纸 💬]` / `[图片]` 存入 SQLite `messages` 表，杜绝多媒体回复链溯源断层；
  - **服务热重载铁律**：修改 Python 或 Node.js 模块代码后，必须显式触发 `systemctl restart lemon-group-bot.service` 重载服务，严禁在旧进程依然运行时提前报告完成；
  - **同人连续合并与多人多头像 (`chatId`)**：Node.js quote-api 底层对比 `msg[i-1].chatId === msg[i].chatId`。若消息未在外层显式携带 `chatId`，在 JS 中 `undefined === undefined` 恒为 `true`，会导致不同群友发言的头像被错误吞掉。**必须在每条消息外层显式传 `chatId: user_id`**；
  - **标签头衔真实性**：群主紫色 (`#b18fff`)、管理员绿色 (`#5ec26f`)、自定义头衔灰色 (`#aaaaaa`)。**无头衔普通群友严禁凭空伪造「群员」标签，必须留空不绘制**；
  - **Telegram Premium 会员 Emoji 状态**：普通 `User` 对象不携带该字段，必须调用 `bot.get_chat(user_id)` 提取 `emoji_status_custom_emoji_id` 与 `accent_color_id`；
  - **媒体与动图还原**：被引用消息为贴纸或图片时，静态贴纸原样还原，动图/视频贴纸提取官方缩略图定格首帧，严禁使用 `[贴纸]` 纯文本占位符；
  - **`qh` 上下文气泡渲染前置条件与文本补全**：Node.js quote-api 底层要求 `message.replyMessage.name` 和 `message.replyMessage.text` **两者必须同时非空**才会触发绘制二级引用气泡。若被引用对象是纯贴纸/纯图片且没有附言文本，必须自动补上 `[贴纸 🎯]`（携带贴纸 emoji）或 `[图片]` 占位，严禁留空或传 `None`，否则整个 `replyMessage` 会被静默吞掉退化为单人气泡；
  - **双轨消息链持久化与 SQLite 深度回溯**：Telegram Bot API 的 `reply_to_message` 往往只携带直接被回复的对象，无法跨层级拿到爷爷辈/父级历史。若仅依赖内存 `MESSAGE_META_CACHE`，一旦进程重启或内存淘汰，`qh` 将彻底失联退化。必须在 `messages` 表同步持久化 `reply_to_msg_id`、`reply_to_user_name` 与 `media_file_id`，在查询父级关联时实现「内存优先 + SQLite 深度回溯」双轨兜底，并在服务启动时从 SQLite 预热历史消息队列；
  - **别人贴图作为 Q 图主体的识别与首帧抽取**：针对回复别人贴图直接发 `q`，若为静态 WebP 贴纸直接通过 `get_file` 取原图；若为 WebM / TGS 动态贴纸，优先使用官方 thumbnail，若无 thumbnail 则调用本地 FFmpeg 抽取第一帧 PNG 缓冲，以 `data:image/png;base64` 传入 `media` 字段，实现对方专属头像+贴图本体的高保真名言贴纸；
  - **高保真当前实时生效头像获取陷阱 (`user_chat.photo` vs `getUserProfilePhotos`)**：
    - **痛点现象**：Q 图识别出的头像是群友完全陌生的旧照片、历史相册照片或备选公开照片（如历史雕像），群友和管理员反馈“头像错的/不知道哪来的”；
    - **根因分析**：
      1. Telegram 允许用户个人资料保留多张头像相册历史（Carousel）或设置备用公开照片（Public Photo）；
      2. 若调用 `bot.get_user_profile_photos(user_id, limit=1)` 并取 `photos.photos[0]`，在 Telegram 数据结构中它仅仅是相册列表的索引 0，当用户从相册回选过旧头像当主头、或设置过多张头像时，`photos[0]` **并不是**当前正在聊天生效的主头像；
      3. Telegram 官方**唯一能 100% 保证反映用户在群聊与聊天列表中实时生效主头像**的字段，是 `bot.get_chat(user_id)`（返回 `ChatFullInfo`）中的 `user_chat.photo.big_file_id`；
    - **架构解决方案**：
      - 在拉取头像时，**必须绝对优先读取并下载 `user_chat.photo.big_file_id`**，保证 100% 与群内实时渲染视觉对齐；
      - 仅当 `user_chat.photo` 为空（如用户设置了严格隐私保护隐藏头像、或接口受限）时，才回退尝试 `get_user_profile_photos` 作为兜底；
      - 这样不仅消灭了头像错位 Bug，还直接省掉一次 Telegram API 往返请求（降低贴纸生成延时）。
- **贴纸包满 120 张自动扩容**：
  - 命名规范：`g_{chat_id}_by_{bot_username}`，满 120 张时自动升级为 `g_{chat_id}_2_by_{bot_username}`，标题追加 `(Vol 2)`，确保容量无上限。
- **贴纸包创建与触发前置条件**：
  - 必须去 `@BotFather` 执行 `/setprivacy` -> 设置为 `Disable`，否则单字母 `q`/`qs` 不会被 Bot 接收；
  - 机器人 Owner 必须先在私聊中向 Bot 发送一次 `/start` 激活授权，否则创建贴纸包会因 `PEER_ID_INVALID` / `USER_NOT_FOUND` 报错拦截；
  - 独立脱敏部署模板见 `templates/standalone-quote-bot.py`，脱敏自检探针脚本见 `scripts/verify_desensitization.py`（配套一键脚本与文档在 `/home/ubuntu/tg-quote-sticker/`）。
- **对外分享与开源发布时的 4 级静态脱敏审计规范**：
  - **切忌直接打包原有 Git 仓库**：严禁直接 zip 包含 `.git` 目录的代码库，防止黑产通过 `git log -p` 回溯提取历史 commit 中曾遗留的 Bot Token、私人 ID 或私钥；必须另建全新独立目录重写/复制纯净代码；
  - **参数收敛与占位符规范**：所有敏感配置（Token、Owner ID、Webhook、自建服务端点）严格收敛至环境变量（`os.getenv`）与 `.env.example`，示例填入显式假数据（如 `<YOUR_USER_IDENTIFIER>:ABCdef...`），代码绝不设真实 fallback；
  - **4 级自动化静态安全探针**：
    1. 敏感专有标识扫描（Owner TG ID、关联 Bot ID、关联手机号、私有反代域名与别名）；
    2. 非本地回环公网 IP 正则扫描（排除 `127.0.0.1` 和 `0.0.0.0`，扫描所有公网 IPv4）；
    3. Telegram Bot Token 格式正则扫描（`\b\d{8,11}:[a-zA-Z0-9_-]{30,}\b`）；
    4. 部署宿主机绝对路径与用户名扫描（避免暴露 `/home/<user>`、内网映射路径）。

### 功能级脱敏拆包：把总结/日报单独开源（2026-11-05 实测）

Owner 说「把总结和日报脱敏提取出来，我想让别人也能部署」时，**不要复制整个仓库再删文件**——`config.py`/`storage.py`/`ai_service.py` 会把音乐、视频、贴纸、双 Bot 身份全部带回来，删不干净也测不动。正确做法是新建独立目录，只搬核心算法，用本地 mock LLM 做端到端自检。模块清单、项目骨架与完整验收阶梯见 `references/standalone-summary-bot-extraction.md`。

三条硬规则：

- **占位 Token 必须短于扫描正则**。Token 正则 `\d{7,12}:[\w-]{30,50}` 会命中 `<YOUR_USER_IDENTIFIER>:AAExampleToken...` 这类假值，导致**自己的脱敏扫描在自家示例上失败**。示例统一写 `<YOUR_USER_IDENTIFIER>:REPLACE_WITH_OWN_TOKEN`（24 字符），测试里的假 token 同理。
- **扫描器要查运行期文件，不只查字符串**。发布树里出现 `.env`、`messages.db`、`state.json`、`llm_endpoints.json` 直接 FAILED；同时查 `.git`、私钥块、公网 IPv4、`/home/<user>` 绝对路径。只扫 ID 数字会把测试里的假群 ID 全报出来，反而逼人加白名单放水。
- **没有真实 Token 也要能验收**。内置 `http.server` mock 一个 OpenAI 兼容端点，跑「入库 → 取数 → 总结/日报 → 来源校验 → HTML 降级」，断言编造来源被删、无据数字被回退、`<details>` 能转 `<blockquote expandable>`。只跑单测证明不了交付物能跑。

另外三条只在拆包时才会踩到：

- **扫描必须在 `git init` 之前**。`verify_desensitization.py` 把 `.git` 目录直接判 finding，先 init 就永远过不了门；init 之后要复扫，用 `git archive` 导出到临时目录再扫。
- **`BadRequest` 是 `NetworkError` 的子类**（PTB 22）。`is_ambiguous_delivery_error` 必须先显式排除 `BadRequest`（= Telegram 明确拒绝 → 降级 HTML 重发），只有 `NetworkError/TimeoutError/ConnectionError` 才算"可能已发出" → 抛 `DeliveryUncertain`、绝不重发。判反了会变成"真拒绝被记成结果未知，既不降级也不报错"。用两个假 Bot 用例锁死这条。
- **代码全绿 ≠ 发布完成**。SSH 能推不代表能建库（建库只能走 API），`git ls-remote` 先验仓库真实存在再 `push`；完整判据与 Owner 协作口径见 `references/standalone-summary-bot-extraction.md` 第 7 节。

**已落地的产物（2026-11-05）**：`nayeshiluo/tg-summary-bot`（公开，MIT，24 文件）—— 群霸「总结 + 日报」的独立可部署版，`/sum` `/autosum` `/autodaily` `/settings`，45 项离线单测 + mock LLM selftest。

- 它是**清房重写**，不是群霸的子集镜像：**群霸后续改总结/日报不会自动同步过去**，反之亦然。Owner 报「开源版怎么没这个修复」时先确认改在哪一侧，别假设两边同源。
- 发布验收必须在**远端全新克隆**上做（fresh venv + `pip install -r requirements.txt` + 单测 + selftest），本地 venv 通过只证明本机能跑。
- 通用流程（清房重写判据、fail-closed 扫描、建仓/推送、克隆回验）见 `desensitized-open-source-release` 技能；本技能的 `references/standalone-summary-bot-extraction.md` 只保留群霸专属的模块清单与边界决策。
- **贴图能力对外交付三路分流**（贴纸包链接 / 功能拆包 / 人型 Telethon 版，含 webm/VP9 规格与 session string 禁区）见 `references/sticker-capability-export.md`。

---

### 2. 当前音乐与视频中转（2026-10-16 核对）

- 当前生产为 relay-only；先查 `handlers/messages.py`、`race_adapter.py`、`relay_adapter.py`、`relay_core.py`、`race_video_parts.py` 及现行中转配置，不把历史原生路径当兜底。
- **点歌秒回 `FAILED：音乐中转当前不可用` 且 `jobs.db` 无新记录** = 没进中转，是 `relay_config.json` 的 `routes` 缺该群（`validate()` 抛 `route_denied` 被 `allowed()` 吞成 False）。群授权与 `music` 开关都正常也可能缺 route，因为 `authorized_groups` 与 `routes` 是两套独立名单，新增群常只加前者。排查与修复见 `music-relay-triage` 技能的 `route_denied` 一节（配置热加载，补 route 不用重启）。
- **「点歌反应速度慢」先拆两段，别直接怀疑中转**（2026-11-03 实测）：`execute_music_flow()` 只负责搜 Top5 出卡片，出歌在点按钮之后。看 `Interactive job finished kind=music elapsed_s=` 这条日志——**没有 `MEDIA_ROUTE` 行就是只做了搜索**（可优化，实测从 5.7s 降到 0.43s），**有 `MEDIA_ROUTE ... state=done` 才是走中转**（8~23s，固有延迟）。本次根因是 `search_music_all()` 串行打 QQ + 网易云，而 QQ 接口稳定 HTTP 500、每次白等 5.2s；已改成并行 + 单源预算 + 180s 失败冷却。完整拆解、逐源计时方法、预热库为何接不上、`music_candidate_artist_mismatch` 的 diagnostics 读法、`parser_timeout` 与 `music_duration_mismatch` 的误判、`native_song_id` 为何被丢掉，见 `references/music-search-latency-triage.md`。
- **「点歌失败」要分三类，别混成一句「中转坏了」**（2026-11-03 实测：同一晚两次失败，原因完全不同）：

  | 现象 | `result.error` | 判定 |
  |---|---|---|
  | 卡片正常、点按钮后 10~13s 失败 | `music_candidate_artist_mismatch` | **曲库不匹配**，见下条 |
  | 卡片正常、点按钮后等满 ~61s 失败 | `parser_timeout` | 解析 bot 60s 零响应（`stage=no_response` 且**无** `music_diagnostics`）。偶发，跑一首熟歌探针即可判活 |
  | 探针报时长不符 | `music_duration_mismatch` | 校验正确拦截，多半是 `expected_duration` 传错 |

- **`music_candidate_artist_mismatch` 是曲库差异，不是匹配 bug**：群霸用网易云 API 搜索、中转用 `@Music163DownBot` 搜 QQ 音乐曲库。网易云独家的二创/翻唱/DJ 版在 QQ音乐 里歌手名完全不同 —— 实测 `好运来 （必上岸版！）`/`刘楚/DJR7` 的 8 个候选是 `祖海`/`凤凰传奇`/`宋祖英`/`卓依婷`/`二狗威·铭泽致远·刘景坤yu`/`DJ铁柱·野马叔叔`，`title_match_count=7` 但 **`artist_match_count=0`**；`恭喜发财（Cover 刘德华）`/`Aurora.歆Official/洛天依` 同理。严格 artist 约束（防串歌）必然拒绝，属设计内拦截。
  **`native_song_id` 是个断点**：`race_adapter.py:34` 把网易云歌曲 ID 写进 request，但 `/home/ubuntu/lemon-userbot` 全目录 **grep 不到这个字段**，`relay_core.music_queries()` 只用 `title + artist` 拼两次查询（`title artist` → `title`）。精确 ID 传过去就被丢掉，永远只能靠文本碰运气。要根治得在 relay 侧接住它（失败后用 `music.163.com/song?id=<id>` 兜底重试），改动涉及 `relay_core.py` + `relay_worker.py` 且**必须同步镜像到 `lemon-group-bot`**。
  ⚠️ **判定 relay 是否健康，用一首不传 duration 的熟歌**（`relay_probe.py 晴天 周杰伦`）：传错时长会得 `music_duration_mismatch`，极易被误读成 relay 坏了 —— 本会话就先误判过一次。
  ⚠️ `search_music_all()` 是**同步函数**（不是 coroutine），验收脚本里 `await search_music_all(...)` 会报 `TypeError: object list can't be used in 'await' expression`，直接调用即可。
- **视频链接同样哑，且文案不同**：`FAILED：视频中转当前不可用，原链接已保留，未启动原生下载。` —— `try_race_video` 和 `try_race_music` 共用同一个 `race_adapter.allowed()`，**缺一条 route 会同时废掉该群的视频和音乐**。2026-10-27 与 2026-11-01 两次实测都是同一根因（`<YOUR_TELEGRAM_GROUP_ID>` / `<YOUR_TELEGRAM_GROUP_ID>` / `<YOUR_TELEGRAM_GROUP_ID>` 三个群陆续补 route）。Owner 报「某群视频解析坏了」时，**先跑一次跨 Bot 的授权群 × routes 对账**，别先怀疑解析器或上游：
  ```bash
  cd /home/ubuntu/lemon-group-bot && .venv/bin/python3 -c "
  import json;rc=json.load(open('/home/ubuntu/lemon-userbot/relay_config.json'))['routes']
  for bid,f in (('<PRIVATE_IDENTIFIER>','data/config_<PRIVATE_IDENTIFIER>.json'),('<PRIVATE_IDENTIFIER>','data/config_<PRIVATE_IDENTIFIER>.json')):
      c=json.load(open(f));print('== bot',bid)
      for g in map(str,c.get('authorized_groups',[])):
          r=rc.get(g);feat=c.get('group_features',{}).get(g) or {}
          if r!=int(bid) and (feat.get('video') or feat.get('music')):
              print('  ',g,c.get('group_names',{}).get(g),'video=',feat.get('video'),'music=',feat.get('music'),'route=',r)"
  ```
  普通群（id 形如 `-53xxxxxxx`）没有 `video`/`music` 开关，缺 route 属正常，不要一并"补"。修完用真实链接跑 `~/.hermes/skills/messaging/music-relay-triage/scripts/relay_video_probe.py <url> <chat_id>`（`state: ready` + `bridge_ids` 非空即链路通，会在中转群留一条真实视频，不会下发到目标群）。
- **群名对不上时先 `getChat` 定位再动手**：Owner 口述的群名可能是昵称/记混（实例：说「茶百道群」，实际是 `茶话领域`；说「插画领域」，实际也是 `茶话领域`）。含"茶"的群可能不止一个（`茶话领域` / `谷雨茶话馆`），逐个跑 `allowed()` 比对后，把"确认坏的是哪个、另一个是好的"一起报出来，并请 Owner 确认群名，别默认自己猜中的就是那个。
- race_adapter 只登记 relay producer。中转失败明确报错、保留原链接，不启动 AWS 下载、转码或旧 services/video_service.py。
- 排队、超时、取消和最终投递以持久任务记录为准；已有任务或投递未确认时先查记录，不盲目重试造成重复发片。
- 核对 Bot、群、请求和结果身份；提交/回传前复核授权、功能开关和任务归属，不跨 Bot 复用未经当前 Bot 验证的 file_id。
- 多段结果核对完整段数、顺序、标题、字幕、来源及幂等边界。部分成功和未确认结果不能报整单成功。
- AWS 控制请求和 Telegram 投递可能仍有流量；中转不代表全系统绝对零流量。重下载/转码留在已有非 AWS 生产端，不新增常驻服务。
- 改动后检查两台 Bot 同版本及配置语义；回归 q/qs、AI、总结、模型切换、权限/私聊面板、定时错峰，以及单视频、多段视频、音乐中转。
- 只有明确恢复请求才读 `references/legacy-native-media-archive.md` 并另行审计；独立 Worker 设计也在该历史参考，不代表活动路由。

### 9. Owner 联系提醒：Bot 被拉进群 / 陌生人私聊 (Owner Contact Alerts)

> 实现模板、stdlib 裸轮询 Bot（广告杀手）变体、踩坑见 `references/owner-contact-alerts.md`；投递验收用 `scripts/verify_contact_alerts.py`（真实 token + 假 update 直调 handler，**不要**为测试另开 UserBot 会话）。
>
> **aiogram 框架的等价实现**（第三方项目 Smart Group Bot）见 `smart-group-bot-ops`：`my_chat_member` + 私聊兜底 router。那边有个本节 PTB 版遇不到的坑——aiogram 里 filter 命中即视为 update 已消费，函数内提前 `return` 不会交还后续 router，所以兜底 router 必须排在群消息 router **之前**，否则私聊消息被静默吞掉。

- **触发场景**：任何自建 Bot（群霸双 Bot、运维 Bot、广告杀手）被拉进/移出群，或陌生人私聊它时，给 Owner 发一条提醒。Owner 的诉求是"有人碰我的 Bot 我要立刻知道"，**不是让对方收到任何回复**。
- **架构铁律：独立只读观察 handler，不改业务分流**。用 PTB 单独 handler 组（`group=-1`）挂两个入口，绝不塞进 `handle_group_message` / 指令处理里：
  - `ChatMemberHandler(alert_my_chat_member, ChatMemberHandler.MY_CHAT_MEMBER)`：只处理 **Bot 自身**的成员变更（`old in {left,kicked} and new in {member,administrator}` = 被加入；反向 = 被移出）；`CHAT_MEMBER`（别人的角色变更，已有 audit handler）不要混进来。
  - `MessageHandler(filters.ChatType.PRIVATE & ~filters.User(OWNER_ID), alert_private_message)`：`~filters.User(OWNER_ID)` 必须加，否则 Owner 自己私聊也会被提醒；handler 内再挡 `user.is_bot`。
- **防刷屏**：同一用户 10 分钟冷却，冷却期内只累计 `suppressed` 计数，下次提醒回显"冷却期内另有 N 条未逐条提醒"；状态字典上限 500，超限按最旧淘汰。纯内存即可，重启归零可接受。
- **提醒内容**：Bot 名、群名、群 ID（`<code>`）、操作人（名字+@用户名+数字 ID）、授权状态、北京时间。未授权群被添加时附"确认可信后私聊发 `/auth <群ID>`"——`cmd_auth` 确实支持私聊带 chat_id 参数。
- **双 Bot 共用一份代码**：`lemon-group-bot` 与 `lemon-group-bot2` 的 `WorkingDirectory`/`ExecStart` 完全相同，靠 systemd `Environment=TELEGRAM_BOT_TOKEN=...` 区分身份，`BOT_ID` 由 token 前缀推导。**改一次 `bot.py` 覆盖两台，但必须同时 restart 两个 service**。
  - **本地自测配置必须先注入该 Bot 的 token，否则结论全错**：直接跑 `.venv/bin/python3 -c "from config import ..."` 时 `config.py` 会读 `.env` 里那台 Bot 的 token，`BOT_ID` 和 `data/config_<BOT_ID>.json` 都变成另一台的，于是「已授权群」被算成未授权、`allowed()` 返回 False，白白排查半天。正确姿势：
    ```bash
    cd /home/ubuntu/lemon-group-bot && \
    TELEGRAM_BOT_TOKEN=$(systemctl show lemon-group-bot2.service -p Environment --value \
      | tr ' ' '\n' | grep '^TELEGRAM_BOT_TOKEN=' | cut -d= -f2-) \
    .venv/bin/python3 -c "from config import BOT_ID; print(BOT_ID)"
    ```
    先确认打印出的 `BOT_ID` 是目标那台，再去跑任何 `authorized_groups` / `routes` / 功能开关判断。
- **文案排版**：Bot 消息用 HTML `parse_mode`，ID/指令一律 `<code>` 包裹，昵称经 `html.escape` 截断（200 字），`link_preview_options={"is_disabled": True}`；成功路径必须打 `logger.info`，否则事后无法从日志证明提醒真的发出去了。
- **铺开前先做“有没有必要”判断，不要默认全量铺开**。Owner 问「其他几个 Bot 有必要吗」时，要的是逐台结论而不是全部加上。判断依据（现行舰队实测清单见 `references/owner-contact-alerts.md` 第 5 节）：
  - **是 PTB / 裸 getUpdates 的 Bot** → 可加；**是 Telethon 人形号（UserBot）** → 不加：账号没有 `my_chat_member` 事件，要挂 Telethon 事件并重启人形号，风控与收益不成正比，被拉进陌生群更适合做每日会话审计。
  - **对外服务型 Bot（如 subinfo 订阅查询）** → 只报“被拉进群”，私聊改报“新用户首次”，因为陌生人私聊本就是它的业务入口，逐条提醒会淹没 Owner。
  - **非 Telegram Bot**（gateway / web-ui / MTProto 代理 mtg / API 服务 / subconverter）与其子进程（cleanup-worker、admission UI）→ 无此事件，直接排除。
  - 结论式回答（“只有 X 有必要，其余不用加”）优先于罗列，符合 Owner 的反过度设计偏好。
- **上线后才暴露的两个硬伤（2026-10-25 Owner 当面反馈，必须一次做对）**：
  - **纯数字 ID 在 Telegram 客户端搜不到人**。Owner 拿到通知里的 `<YOUR_USER_IDENTIFIER>` 粘进搜索框查不到，只会判定「功能是坏的」。通知里名字必须做成可点链接 `<a href="tg://user?id={id}">{escaped_name}</a>`，点一下直接开资料页。前提是 `parse_mode="HTML"` 且名字已 `html.escape`。广告杀手（stdlib 裸 HTTP）同样可以加 HTML parse_mode，但必须加 HTML→纯文本降级兜底（`BadRequest`/任何异常时 `re.sub(r"<[^>]+>","",text)` 重发）。Hermes 网关侧有独立安全过滤层（`_notice_text` / `protected_text`），切 HTML 时要把 `send_message` 封成 `_send()` 方法，内部 HTML 优先 + 降级兜底，避免历史 pending 纯文本补发时触发 `BadRequest`。完整三框架处理方式见 `references/owner-contact-alerts.md §8`。
  - **不落盘就永远查不回来**。Bot API 没有「列出私聊过我的用户」接口，`getUpdates` 的 offset 已被消费，事后无法回溯；日志里只写 `alert sent` 只能证明发过、证明不了发给谁。每条提醒必须**先 archive 再 send**（发送失败也不丢档），一行一条 JSONL：`ts/kind/bot/user_id/username/name/text/chat_id`。路径按 Bot 隔离——群霸双 Bot 共用代码只有 token 不同，用 `data/contact_alerts_{BOT_ID}.jsonl`；运维 Bot 用 `data/contact_alerts.jsonl`。事后查询：`/home/ubuntu/lemon-ops-bot/query_contact_alerts.py [today|all|YYYY-MM-DD]`（汇总四个 Bot，本地两个 + ssh 拉 vps-la）。
  - **加固过的 systemd 服务不能往 `/var/log/` 随便写**。广告杀手是 `DynamicUser=yes` + `ProtectSystem=strict` + `ReadWritePaths=/var/log/ad-killer-profile`：写 `/var/log/ad-killer/...` 直接 `Permission denied`（它还是指向 `drwx------ root` 的 `/var/log/private/` 的符号链接，连穿透都不行）。落盘前先 `systemctl cat <svc> | grep -E "ReadWritePaths|ProtectSystem|DynamicUser"`，目录只能选 `ReadWritePaths` 列出的那个。`sudo -u <user> test -w` 探权限不可靠（DynamicUser 运行时 uid 与 `id` 显示的不一定一致），以 `ReadWritePaths` 为准。
  - **测试通知绝不能伪装成真实事件**。本次造了 8 条 `user_id=<YOUR_USER_IDENTIFIER>` / `chat_id=<YOUR_TELEGRAM_GROUP_ID>` 的测试提醒发给 Owner，他直接去查这些 ID 查不到 → 白绕一轮排查。正确做法：只验落盘逻辑（`ALERT_LOG` 临时指向 `/tmp`，调 `_archive()` 断言内容，验完删文件，真实档案零污染）；真要验投递就发一条并在文案里写「【功能验证】」。事后复盘**第一句先认账**「那几条是我造的假数据」，再给真实事件清单。
  - **真实事件核查口径**：`journalctl -u <svc> --since today | grep "contact alert"` 取时间线 → 同窗口 `grep -Ei "audit|bot_added"` 补操作人与群 ID（群霸 `audit_my_chat_member` 会记 `audit bot_added chat=%s actor=%s`，能识别出是不是 Owner 自己操作的）。旧代码上线的提醒没落盘，ID 找不回来就如实说找不回来，不要用「可能是某某」去圆。

### 9.1 Bot 被踢出群 / 群废弃：配置空转清理（2026-11-01 实测）

> 完整命令与验证脚本见 `references/dead-group-config-cleanup.md`。

- **症状**：某群日报/定时总结「再没跑过」，journal 里**一行日志都没有**，`last_run_slot` 停在数天前。
- **根因**：Bot 已被移出该群 → 自动失权（`authorized_groups` 早已没有它），但 `group_daily_report` / `group_features` 仍是 `enabled: True`。调度器每天照常触发，`execute_daily_report()` 第一步 `is_feature_enabled()` 返回 False 就 `return True`——**不打日志、不更新 slot**，看起来像"没跑"，其实是"跑了立刻退出"。
- **日报"没跑"的排查不能只看 journal**：必须同时看 `group_daily_report[chat].last_run_slot` 与 `data/bot.db` 该群消息数。消息数为 0 而 `enabled: True` → 基本就是 Bot 已不在群里。
- **先判「群解散」还是「Bot 被踢」**（处理方式不同），`getChat` 错误串实测可区分：
  - `Forbidden: bot was kicked from the supergroup chat` → 群还在，Bot 被移出；
  - `Bad Request: chat not found` → 群已不存在。
  别只凭 Owner 一句"应该是解散了吧"就下结论，先跑一次 `getChat` 定性。
- **谁踢的**：`data/bot.db` 的 `audit_events` 有 `bot_removed` 记录（含 `chat_id` / `created_at`）。若 `actor_username=GroupAnonymousBot`，是**匿名管理员**操作，Telegram 隐藏真人身份——只报时间点，**不能点名、不要用「可能是某某」去圆**。journal 里通常没有 kicked 记录，`grep kick` 为空不能否定被踢。
- **清理范围**：一个群最多 6 处配置残留（`group_authorized_users` / `group_names` / `group_features` / `group_autosticker_intervals` / `owner_feature_grants` / `group_daily_report`，可能还有 `group_scheduled_summary`、`group_quote_colors`）+ `menu_state.db` 的 `jobs`/`subjects` 两张表。**先扫全部命中键再删，别只删日报**；`menu_state.db` 不清会每 6 小时重试一次（实测一条 `attempts=28`，纯噪音）。
- **热生效**：`load_config()` 按文件签名（`st_mtime_ns/st_size/...`）比对缓存，外部改 JSON 后下一次调用即重读，**不用重启**；`save_config()` / `_set_group_schedule()` 写盘前重新读文件，手改不会被内存副本覆盖。改完等 20~30 秒复查一次确认没被写回。
- **汇报必须带对照组**：点一个正常群（如圆桌会议 `enabled: True` / 授权 True）证明"其他 N 个群一条没动"，再给清理清单与行数。

### 4. 各群独立功能开关控制面板 (/settings)
- **控制维度**：
  - `quote`（名言贴纸）、`ai`（AI 问答）、`summary`（群总结）、`video`（视频去水印）、`music`（音乐点播）、`mute`（禁言风控）；
- **操作与权限隔离**：
  - 群内仅限 **机器人 Owner、本群群主 (Creator)、及授权 VIP** 可唤出并点击开关；
  - 面板按钮带实时状态指示灯（`🟢 开启中` ↔ `🔴 已关闭`），点击原地热切换；
  - 支持私聊远程遥控：Owner 私聊 `/settings` 列出所有已授权群组，隔空管理；
  - 陌生人私聊仅可见 `/help`，其余指令底层静默丢弃，防爆破与恶意刷屏。

---

### 7. 群聊定时总结与 `#总结` 标签归类架构 (Scheduled Summary & Topic Tagging)
- **业务诉求与设计理念**：
  - 总结卡片开头必须加上 `#总结` 话题标签，群友点击标签或在 Telegram 搜索栏输入 `#总结` 即可秒级串联群内所有历史总结，不破坏原生 `<details><summary>` 小三角折叠卡片视觉；
  - 允许自定义每天固定时间点（如 `22:00`、`12:00,22:00`）或循环周期（如每 `4h`）自动总结群内过去具体几个小时（如过去 `4h` 或 `6h`）的发言；
  - 提供指令（`/autosum`）与控制台（`/settings` 二级交互面板）双轨操作，兼顾群内管理与 Owner 私聊大盘遥控。
- **双轨控制形态与指令规范**：
  - **群内指令**：
    - `/autosum`：查看本群当前定时总结规则、上次执行时间与预计下次触发时间；
    - `/autosum 22:00 4h`：每天北京时间 22:00 自动总结过去 4 小时发言；
    - `/autosum 12:00,22:00 6h`：每天 12:00 与 22:00 分别总结过去 6 小时发言；
    - `/autosum 4h 4h`（或 `/autosum 每4小时 4h`）：每隔 4 小时自动总结过去 4 小时发言；
    - `/autosum test`：立即测试触发一次定时总结并投递到群内；
    - `/autosum off`（或 `0`）：关闭本群定时总结；
    - 自然语言捕获：支持群内直接输入 `定时总结 22:00 4h` 或 `自动总结 22:00 4h`。
  - **`/settings` 交互式二级面板**：
    - 集成 `⏰ 定时发言总结` 独立二级菜单，预设常用方案按钮：`🌙 每天 22:00 (前4h)`、`🌙 每天 23:00 (前6h)`、`☀️🌙 每天 12:00&22:00 (前6h)`、`🔄 4h整点循环`、`🔄 6h整点循环`、`🔄 8h循环 (7/15/23点)`、`⚡ 立即测试触发一次`、`🛑 关闭定时总结`；
  - **Owner 私聊大盘遥控**：
    - 私聊输入 `/autosum` 调出全部已授权群组的定时总结状态大盘及配置按钮，支持隔空配置 `/autosum <chat_id> 22:00 4h`。
- **周期循环定时任务的时钟整点对齐规范 (Integer Clock Alignment Pitfall)**：
  - **痛点现象**：若循环调度采用相对当前点击时刻简单累加（`last_run + interval`），当管理员在非整点（如 23:40）点击“8小时循环”时，后续触发时刻将永久滞留在非整数时间点（如 `07:40`、`15:40`、`23:40`），引发群友与管理员“时间点不是整数”、“为什么不是整点总结”的困惑；
  - **设计准则**：在 Telegram 群管定时任务设计中，所有循环类预设必须**默认对齐到自然时钟整点（00 分）**，底层统一映射为确定性时刻列表（`daily_time`）：
    - **8h 循环**：严格锁定 `["07:00", "15:00", "23:00"]`（早 7 点查阅夜间讨论、下午 15 点查阅上午、晚 23 点查阅下午及晚间，完美对齐社群作息）；
    - **6h 循环**：严格锁定 `["00:00", "06:00", "12:00", "18:00"]`；
    - **4h 循环**：严格锁定 `["00:00", "04:00", "08:00", "12:00", "16:00", "20:00"]`；
  - 杜绝任意分钟漂移，让管理员和群友对总结触发时刻（如“明日 07:00”）具备 100% 确定预期。
- **后台调度与防重复执行机制 (`services/scheduler_service.py`)**：
  - **时区标准**：严格对齐北京时间 (UTC+8)；
  - **槽位幂等防重跑 (`last_run_slot`)**：每天固定点模式记录 `YYYY-MM-DD_HH:MM` 时间槽（如 `2026-09-13_22:00`），并在触发判定时比对；只有未跑过的槽位才进入执行逻辑，彻底防止 30 秒轮询重复触发；
  - **样本保护与静默防刷屏**：回溯窗口内若有效发言少于 3 条，调度器自动静默跳过（不向群内发送冷启动或空白总结刷屏），测试模式 (`is_test=True`) 则明确回显样本不足提示；
  - **排版与通道保底**：优先走 `sendRichMessage` 投递原生折叠小三角卡片，超长自动拆包分段（`split_summary_chunks`），富文本不可用时保底转换为 HTML `blockquote expandable` 发送。
- **「日报太短 / 只有两三条」排查（2026-11-01 实测，详见 `references/daily-report-quality-triage.md`）**：
  - **不要先怀疑模型偷懒，先量三个数**：话题上限、校验丢了几条、窗口实际覆盖几小时。三者的修复方式完全不同。
  - 话题数原为 **prompt 写死的 3～5 条**（`DAILY_REPORT_SYSTEM_PROMPT` 第 1 条，每条 80～160 字），`_merge_daily_validated_reports` 再 `cap 5`；`_refill_daily_report` **只在 `count < 3` 时才补选**，所以「剩 3 条」就是设计下限，会直接收工且不打任何 refill 日志。
  - **2026-11-01 已按 Owner 授权落地加长**（现行值，勿再按 3～5 判断）：prompt `5～8` 条；`ai_service.py` 新增常量 `DAILY_REPORT_MAX_TOPICS=8` / `DAILY_REPORT_MIN_TOPICS=5`，`_merge_daily_validated_reports` 用 `MAX_TOPICS` 截断、`_refill_daily_report` 用 `MIN_TOPICS` 判阈值。**这三处必须同时改**，只改 prompt 会被 `cap 5` 和「<3 才补选」卡回去。
  - `_validate_daily_report_attribution()` 是丢条主因：标题数字无据 → 整条丢弃；正文数字无据 → 正文降级成原文摘录（读起来变生硬）。模型确实会自己编版本号（实例：来源只写 `Surge`，标题写成 `Surge 6`），**这是防造假的正常拦截，不要为了变长去放宽数字校验**。
  - **最隐蔽的一层：`database.get_messages_by_time()` 默认 `max_limit=3000`**，调度器调用没传这个参数。高活跃群 12h 就有 3800+ 条，只取最新 3000 条时实际只覆盖约 **9.6 小时**，而日报开头仍写「前 12 小时」——标注与覆盖不符比条数少更该先修。**2026-11-01 已修**：`daily_report_service.py` 新增 `DAILY_REPORT_MAX_MESSAGES=8000` 并传给两处 `get_messages_by_time(..., max_limit=...)`；采样逻辑会把 prompt 压回 ~47000 字符，**token 成本基本不变**。
  - 复算素材量用 `scripts/measure_daily_report_context.py`（只读，复刻同一套过滤/截断/采样规则，直接打印窗口总条数、截断后条数、实际覆盖小时数、抽样后进入 prompt 条数）；改完验收用 `scripts/daily_report_dryrun.py`（**同样复刻全链路但不发 Telegram**，直接打印覆盖小时数与话题数，比 `/autosum test` 安全）。
  - 汇报口径：必须同时给「几条」和「实际覆盖几小时」两个数；群里看不到任何错误码，`jobs.db` 里也没有日报记录，日报问题只能从 journal + `data/bot.db` 复算，别去音乐/视频中转链路里找。
- **手动 `/sum` 的分级上限 vs 菜单文案（2026-11-01 实测，Owner 问「现在是无上限了吗」）**：`bot.py` 的 `OWNER_GROUP_COMMANDS` 里写着 `📋 智能总结发言 (无上限)`，**这是早期遗留文案，与代码不符**。真实限制在 `handlers/commands.py:185 parse_summary_arg()`：

  | 身份 | 条数上限 | 时间上限 |
  |---|---|---|
  | Owner / 群管理（`is_user_privileged` 为真） | 3000 条 | 168h（7 天） |
  | 普通群友 | 500 条 | 24h |
  | 不带参数 | 80 条 | — |

  超限**不报错**，静默压到上限并把描述改成「已达普通上限」。实测 `is_privileged=True`：`99999 → 最近 3000 条发言`、`720h → 最近 168 小时发言`；`is_privileged=False`：`9999 → 最近 500 条发言`。**回答这类「是不是无上限」必须真跑一次 `parse_summary_arg()` 两种身份各一遍**，别照菜单文案答（菜单文案只影响观感，不影响实际能力）。
  已知小洞：`昨天` / `昨日` 分支直接 `return 'time', secs`，**没走 `max_hours` 裁剪**，普通群友 `/sum 昨天` 能拿到约 34.7h（>24h 上限）；要修就在该分支补 `min(secs, int(max_hours*3600))`。
  改文案属于 `.py` 改动 → 重启两个 Bot 后还要 `setMyCommands` 才在客户端生效。

- **查库统一口径（本机无 `sqlite3` CLI）**：`sqlite3` 命令会 `command not found`，不要安装也不要原样重试，一律用项目 venv 的 python 读库：
  ```bash
  cd /home/ubuntu/lemon-group-bot && .venv/bin/python3 -c "
  import sqlite3
  c=sqlite3.connect('data/bot.db')
  print([r[0] for r in c.execute(\"SELECT name FROM sqlite_master WHERE type='table'\")])
  "
  ```
  `data/bot.db` 的 `messages` 表列：`id/chat_id/message_id/user_id/user_name/text/created_at/reply_to_msg_id/reply_to_user_name/media_file_id/bot_id`；`created_at` 是 epoch 秒，展示要按 `Asia/Shanghai` 换算。中转任务库在 `/home/ubuntu/lemon-userbot/relay-state/jobs.db`（表 `jobs`，列名是 `state` 不是 `status`）。
- **`journalctl --since 'today 08:00'` 会报 `Failed to parse timestamp`**（2026-11-01 实测两次），一律写完整时刻 `--since '2026-11-01 08:00:00'`，改参数别原样重试。
- **journal 空白不等于 Bot 没收到消息**：实测 `lemon-group-bot2` 在 `01:00–02:00` 整段零日志，而 `data/bot.db` 同一时段正常入库（`01:06`–`01:12`）。判断"有没有收到/处理"以 `bot.db` 的消息行与 `audit_events` 为准，journal 只用来补时间线与错误串；日志缺失时按"该路径本身不打 INFO"处理，不要推成"Bot 掉线"或"消息没进来"。

---

### 8. 大模型多级自动降级容错与动态调度中心 (LLM Fallback & Dynamic Model Center)

> 完整实现细节与踩坑排障见 `references/dynamic-llm-pool-and-scheduled-summary.md`
> 「/sum 失败但别人成功」的 LLM 节点超时定位与节点实时测活，见 `references/group-summary-troubleshooting.md` 第 0 节；「加了兜底反而更容易失败」的候选窗口截断陷阱见 0.1 节，一键链路体检用 `scripts/probe_ai_chain.py`。

- **业务诉求与去中心化自愈**：群内 `ai` 问答与 `/sum` 群聊总结要求极速响应与高可用。中转站（LFree）主用保证速度与高并发，反重力（Gemini 3.8）等作为稳健兜底；同时必须让机器人拥有者具备**脱离服务器终端也能在 Telegram 内随时换心换脑、换 API Key、改模型代号、添加第三方 API 端点的能力**。
- **双 Bot 混合解耦架构（API 池子全域统一共享，各 Bot 具体模型与优先级完全独立）**：
  - **统一 API 端点池 (`data/ai_endpoints.json`)**：
    - 集中保管所有接口地址（URL）、API Key 与预置默认模型；
    - 爸爸在任一 Bot 发送 `/setapi` 或 `/setkey` 录入新凭据后，**两台 Bot 自动同步享用同一套底座连接池**，绝不需反复录入两次；
  - **分 Bot 独立模型调度 (`data/ai_bot_{BOT_ID}.json`)**：
    - 各 Bot 独立维护自身的 `order`（首选与兜底顺序）、`disabled_nodes`（专属停用开关）与 `model_overrides`（专属模型代号定制）；
    - 主 Bot (`@<PRIVATE_IDENTIFIER>_bot`) 可以在 `/model` 面板把 `LFree·Claude` 设为首选主用；
    - 分身 Bot (`@<PRIVATE_IDENTIFIER>_bot`) 可以在 `/model` 面板把 `反重力·Gemini3.8` 或 `日日新·DeepSeek` 设为首选主用；
    - 某端切换主用模型或修改模型代号（`/setmodel`），**100% 仅对当前 Bot 生效，互不干扰**；
  - **Telegram 原生私聊控制面板 (`/model`)**：
    - 面板顶部动态回显当前操作的 Bot 身份（如 `主 Bot (@<PRIVATE_IDENTIFIER>_bot)` 或 `分身 Bot (@<PRIVATE_IDENTIFIER>_bot)`）；
    - 大盘展示当前 Bot 的完整调用链顺位（1. 👑 首选主用，2. 🛡️ 备用兜底...）；
    - `⚡ 一键全节点测活`：并发 Ping 全部节点（轻量 user "ping" 提示词，max_tokens=5），实时回显各节点毫秒延迟与 HTTP 状态（如 `200 OK (1.8s)`、`429 配额耗尽`、`504 超时`）；
    - 单节点详情面板：点击对应节点按钮，支持【🌟 置顶此节点为主用】、【启停开关】、【单独测活】与【删除自定义节点】；
  - **私聊指令动态热配置与密钥安全自动秒删**：
    - `/setapi <ID> <URL> <KEY> <MODEL> [中文名称]`：向统一池新增/更新端点，并在当前 Bot 置顶为主用；
    - `/setkey <ID> <新Key>`：同步更新统一池中该节点的 API Key；
    - `/setmodel <ID> <新模型名>`：为当前 Bot 单独修改该节点的模型代号；
    - `/delapi <ID>`：从统一池删除自定义节点；
    - **严格敏感信息安全防御**：Bot 接收到包含明文 Key 的 `/setapi` 或 `/setkey` 后，**自动立即秒删该消息**，回显时对 Key 实施前四后四掩码保护（`sk-xxx...xxxx`），绝不让明文密钥留在 Telegram 聊天记录中。
- **环境隔离与密钥读取**：在 `services/ai_service.py` 中实现 `_read_env_val`，优先读取环境变量，未传时自动回退读取 `/home/ubuntu/.hermes/.env`，兼顾 systemd 守护进程与独立运行环境；请求头必须携带标准浏览器 `User-Agent` 防 WAF 拦截；
- **配置热生效铁律（改 JSON vs 改代码，2026-10 实测）**：`data/ai_bot_{BOT_ID}.json` 与 `data/ai_endpoints.json` 是纯 JSON 配置，`load_ai_nodes` → `_read_ai_json` 每次调用直接从文件 `json.load`（无内存缓存），**改完立即热生效、无需重启服务**；只有改 `.py` 代码才要 `systemctl restart lemon-group-bot.service`（及 bot2）。切勿为了改 `order`/`disabled_nodes` 去重启服务。`data/ai_timeout_overrides.json` 同样按 mtime 缓存热生效，用于按节点临时调超时（形如 `{"tengbaipiao": {"large": 30.0}}`），是上游劣化时做临时降级/自动还原的首选载体——比硬编码或改 `.py` 安全得多。注意首节点超时的压缩方式**分大小请求两条分支**（`_call_llm_unchecked`，约 `ai_service.py:789-793`）：
`if large_request:` 才做槽位均分 `min(配置值, remaining / slots)`（大请求配置调到 35s 会被压到约 24.8s，只对后续槽位生效）；
`else:` 分支只写 `min(配置值, remaining)` —— **普通请求里首节点独占它自己的配置值**。
所以给普通请求调大单节点超时会直接废掉兜底：`antigravity_gemini.small` 从 16 调到 25 时，
首节点吃 25s、第二个节点只剩 4.5s 必然跟着超时，用户看到的是**空回答**而不是「降级到备用节点」。
日志指纹：`node_elapsed_s=25.8 ... outcome=timed_out` 紧跟 `node=<下一跳> node_budget_s=3.657 outcome=timed_out`。
**改 `ai_timeout_overrides.json` 前先算** `首节点预算 + 兜底最低预算 ≤ 总预算（small=30，再减 FINALIZATION_MARGIN）`，
并跑 `tests/test_audit_fixes.py::BudgetTests`（`test_ordinary_has_two_useful_attempts_within_total_budget` 断言两次尝试各 ≥10s，
是唯一会立刻报红的守卫；small=18 通过，25 报红）。节点 key 解析规则：`ep.get("key") or _read_env_val(ep["key_env"])`，故 `key` 字段为空但带 `key_env`（如 `DDDAI_API_KEY`/`GEMINI_OFFICIAL_API_KEY`）的节点 key 实际存在 `/home/ubuntu/.hermes/.env`，别误判为「无 key」。**新增兜底节点 runbook**（测活禁用节点、`403`=模型名失效勿加回、稳定节点提前/不稳定远程压后、双 Bot 需分别改 `ai_bot_{BOT_ID}.json`）要点已在上文内联，完整架构见 `references/dynamic-llm-pool-and-scheduled-summary.md`。
- **候选窗口硬上限（`MAX_CHAIN_ATTEMPTS`，2026-10-20 实测踩坑，已由 4 上调至 7）**：`candidates = chain[:MAX_CHAIN_ATTEMPTS]`，**生效链路（`order` 减去 `disabled_nodes`）窗口外的节点永远不会被调用**；群总结属大请求（`max_tokens>=2000`）→ `max_attempts=3`、总预算 75s，节点预算按 `remaining / 剩余槽位` 动态切分。两个致命推论：
  - 往 `order` 前几位插新兜底会把原本健康的节点挤出窗口，表现为「加了兜底反而稳定失败、每次耗时固定 ~70s」；
  - **429/401 这类快速失败只花 0.02~1s 就吃掉一个候选槽**，4 格窗口可能在总预算还剩 50s 时就被耗尽，后面全健康的节点一个都轮不到 —— 所以窗口宽度必须大于「已知会快速失败的节点数 + 需要真正兜底的节点数」。
  - 现行值：`services/ai_limits.py` 的 `MAX_CHAIN_ATTEMPTS = 7`（2026-10-20 由 4 上调，等于启用节点总数，使末位节点不再永远落在窗口外；双 Bot 重启后实测生效）。**窗口宽度只决定“可尝试范围”，不放大尝试次数**——`max_attempts` 仍是 `min(7, 3 大请求 / 2 普通)`，所以调大不会多打上游请求。该常量是 `.py` 代码，改完**必须** `systemctl restart` 两个 Bot，改 JSON 的 order 才不需要重启。
  - 扩链/调序前先跑 `scripts/probe_ai_chain.py` 打印候选窗口（脚本直接从 `ai_limits.py` 读真实上限，不写死）；链路改完用 `scripts/verify_summary_chain.py` 跑真实群消息端到端验收。判读与处置见 `references/group-summary-troubleshooting.md` 0.1，节点增删 runbook 见 `references/dynamic-llm-pool-and-scheduled-summary.md` 第 4 节。
- **群里 AI 回答「怎么显示的是 GPT 模型」= 降级链落到第 N 顺位，不是配置被改成 GPT**（2026-11-03 实测）。判读只看两样，**不要先去看 `ai_bot_*.json` 的 order**：
  - journal 的 `LLM 实际使用节点: <名称> (<model>); bot_id=...; fallback_index=N` —— `fallback_index>0` 就是降级；
  - 同一 `request=<id>` 的前几行 `LLM request failed: HTTP <code> (node=<id>)`，逐个节点看真实状态码。
  实例：`<YOUR_TELEGRAM_GROUP_ID> 宸澄Emby（复活版）`（群友口中的 `@ccembytv`）看到 GPT-6 Luna，链是
  `antigravity_gemini`(400) → `tengbaipiao`(503) → `cpa_gpt6_luna`(200)，`fallback_index=2`。
  **第一顺位坏掉时，用户看到的永远是最后一跳的名字**，所以「为什么是 X 模型」本质是「前几跳为什么挂」。
  群名对不上先 `getChat`：`@ccembytv` → `宸澄Emby（复活版）`。
- **拿到 `fallback_index` 之后，归因分三步走**（完整命令与实测见 `references/ai-fallback-layer-attribution.md`）：
  1. **时间锚定**：`grep "实际使用节点: <节点名>" | tail` 找最后一次成功，再按天统计该节点 `http_status=400` —— 两个时刻一出来，就能排除「配置一直错」和「有人改坏了配置」。本次 `11:29` 还成功、`13:33` 起全 400，结论立刻变成「今天中午之后外部变了」。
  2. **横向测家族，不要只测坏的那一个**：同一网关 `/v1/models` 一次返回 22 个模型（claude/codex/gemini/gpt），必须三家各打一次。本次 claude/gpt 全 200、只有 gemini 全 400 ⇒ 网关健康，是**上游对单一渠道的地区限制**；只测 gemini 会误判成「网关死了」，然后白去重启网关、换 key、改配置。
  3. **上游原文不在日志里**：bot journal 只有 `HTTP 400 (node=...)`、`cli-proxy-api` 只有 gin 的 `400 | 1.0s | POST "/v1/chat/completions"`，`grep "location is not supported"` 命中 0 次 —— **必须自己发探针才拿得到 body**，别停在「HTTP 400」就汇报。
- **写探针时先剥 URL 后缀**：`data/ai_endpoints.json` 的 `url` 已是完整路径（含 `/v1/chat/completions`），再拼一次会得到 `.../chat/completions/chat/completions` → **所有端点齐刷刷 404**，第一眼极像「整个网关全死了」。判据：多个不同 provider 同时同一个 404，先怀疑自己拼错，别下结论。
- **两类 `no_healthy_account` 503 必须分开**（最容易误判成「账号废了」的坑）：
  | 内层 | 含义 | 处置 |
  |---|---|---|
  | 带 `code:11158` + `not allowed for user type` | 账号**档位**不含该模型 | 永久，换模型 |
  | **不带 11158**，`all accounts are temporarily unavailable` | 该 **realm 分区**没有健康账号（多半前缀指错） | 改前缀即可 |
  | **不带 11158**，且 `/status` 显示 `healthy=total`、`cooling=0` | 全部账号 `credits` **低于 `credit_floor`**，被网关按 floor 判不健康 | 充值或调 floor；**`/status` 的 `healthy` 字段不会反映这一层** |
  2026-11-03 实例：腾白嫖 `cn:glm-5.3-flash` → 503（无 11158），`global:glm-5.3-flash` → 200，改一个前缀即恢复。
  **`cn:` / `global:` 哪个能用会随账号池增减而翻转，是每次现场测的事，绝不能按记忆套**
  （`hermes-ai-chain-alert-triage` 的 `references/account-tier-model-denied.md` 里「global 全灭、cn 全通」是 2026-10-20 快照，已过时，别再引用）。
  现场三步（只读，key 走 `key_env` 不进命令行）：
  ```bash
  # 1) 该网关真实存在的模型名（前缀写错时这里看得最清楚）
  curl -s <base>/v1/models -H "Authorization: Bearer <key>" \
    | python3 -c "import json,sys;print([m['id'] for m in json.load(sys.stdin)['data'] if 'glm' in m['id']])"
  # 2) 账号池 realm 与 cooling 状态
  curl -s <base>/status -H "Authorization: Bearer <key>"
  # 3) 用第 1 步返回的逐字模型名打一次最小 chat
  ```
  注意：`/v1/models` 返回 200 只证明网关活着，**不能反推你配置里的模型名存在**——网关可能先做账号池路由再校验模型名，于是错误码是 503 而不是 404。
- **`400 User location is not supported for the API use` 是地区锁，不是模型名/密钥问题**：同一节点换任意模型都复现（2026-11-03 实测 `gemini-3.8-flash-high` / `gemini-3-flash` / `gemini-3.5-flash-lite` 全 400），配置层改不动，只能换出口 IP，或把该节点从 `order` 里降位/禁用。留着它每次白等 ~1s 还刷熔断日志。**汇报时不要说「Gemini 挂了」，要说「出口 IP 的地区不被 Gemini 接受」**。
  - **「换出口 IP」不是推测，已实测可恢复**：同一批账号、同一份配置、同一个二进制，只把出口从本机换成代理出口，gemini 立刻 200。验证用**独立实例**（复制 config 到 `/tmp`、改端口、`HTTPS_PROXY=socks5h://...` 启动），**不要动生产网关**；CLIProxyAPI 的 config.yaml 没有 proxy 字段，但它是 Go 程序、尊重 `HTTPS_PROXY` 环境变量。完整命令、代理出口探测、三条恢复方案代价对比见 `cliproxyapi` 的 `references/antigravity-region-ip-400.md`。
  - **只有 gemini 家族挂，同池 claude/gpt 仍 200**（Google 在端点内部按模型家族分流：gemini 套 IP 地区校验，claude 走转售 Anthropic 通道不套）。所以「网关 22 个模型里 claude 能用」**不能**证明网关没问题，别拿这个当收工理由。反过来，也**不要因为"同账号同池"就推断 claude 会一起挂**——本会话就因为先用架构推断回答、被 Owner 一句反问问住；正确做法是读 `~/.cli-proxy-api/antigravity-<email>.json` 的 `antigravity_capability_hints.model_ids` 实证（同时含 claude 与 gemini 即同池）。
- **改 `ai_endpoints.json` 的 `default_model` 是热生效，不用重启**；但改完必须用**服务自己的客户端**验收，不能只 curl 节点：本地跑 `ask_ai()` 前先注入该 Bot 的 `TELEGRAM_BOT_TOKEN`（否则 `BOT_ID` 读错配置文件 → 报「当前没有任何已启用的 AI 模型节点」，这是误报不是真没节点），再 grep `LLM 实际使用节点` 确认落到了期望的节点与 `fallback_index`。
- **透明反馈**：若所有节点均耗尽，发送自毁临时提示明确告知原因，绝不静默装死；
- **推理型模型别放高频角色（2026-11 实测）**：`gemini-3.8-flash-high` 同一个 trivial prompt 烧 **808 tokens / 8.45s**，而 `gemini-3-flash` 只 **34 tokens / 1.24s** —— 差 23 倍 / 7 倍。它适合单次复杂任务，不适合 `main` / `decision` 这类每条消息都跑的角色，慢 8 秒回一句在群里的观感就是「坏了」。判定方法不是看模型名，是**同题同 prompt 比 `usage.total_tokens`**（token 暴涨 = 后端在偷偷跑 CoT）。完整角色矩阵与五步探测见 `oss-project-evaluation` 的 `references/model-role-fitness.md`。
- **深度思考（Thinking/CoT）模型总结泄露与双重过滤防御规范**：
- **痛点与现象**：当调用带 Thinking/Reasoning 机制的模型（如 `gemini-3.8-flash-high`、Claude Thinking、DeepSeek-R1）执行群聊总结或 AI 问答时，模型不仅会在正文前吐出自言自语的分析草稿（例如“分析106条消息...梳理...这话题值得单独”），还会主动将自身推理过程包装为 `<details><summary>💭 思考与分析思路</summary>...</details>` 等看似合法的折叠卡片，直接随正式总结一起发送到群公屏；
- **根本原因**：普通正则仅过滤了显式 `<think>` 标签，大模型自己起带有“思考/思维/分析思路”等标题的业务卡片，或者在卡片之前裸打草稿分析，会直接穿透放行；
- **加固与防护闭环**：
  1. **System Prompt 绝对红线**：在 `SUMMARY_SYSTEM_PROMPT` 的格式红线中明确：*“严禁输出任何思考过程、思维链、分析草稿或自言自语（严禁输出 <think>、<thought> 或以思考/思维为标题的卡片）！直接输出纯净的 <details><summary> 业务卡片语法。”*
  2. **后置全量清洗与硬斩断 (`_clean_card_content`)**：
     - 显式标签剥离扩充：包含 `<think>`、`<thought>`、`<thinking>`、`<reasoning>`、`<reason>` 及其代码块；
     - 伪装卡片深度正则剔除：正则匹配 summary 包含 `思考|思维|thought|thinking|reasoning|思路梳理|分析思路|分析过程|分析记录|推理|推导|内心OS|思维链|Chain-of-thought|CoT` 的 `<details>` 整体剥除；
     - 严格业务卡片前置锚定：以前置首个合法业务 `<details>` 为界斩除其前所有字符（彻底清除任何前置分析草稿），从最后一个 `</details>` 斩除其后杂质；
  3. **修改代码后双 Bot 必须全部热重启生效**：修改 `ai_service.py` 后必须同时执行 `sudo systemctl restart lemon-group-bot.service` 与 `sudo systemctl restart lemon-group-bot2.service` 并校验 status 处于 `active (running)`，杜绝分身 Bot 漏重载导致线上故障。
- **Telegram 原生富文本降级死穴与 HTML 转义吞字避坑 (Rich Message Fallback & HTML Escaping Traps)**：
  - **痛点现象 A（总结/回答发送失败）**：`sendRichMessage` 发生 `Rich_message_content_required` 等偶发错误触发降级时，由于直接使用 `send_message(parse_mode=HTML)` 投递带原生 `<details>` 的文本，Telegram 报 `Can't parse entities: unsupported start tag "details"` 导致发送彻底崩溃；
  - **解决方案 A**：在总结与群聊 AI 问答的所有降级链路中，强制执行双层转换：正则将 `<details>\s*<summary>(.*?)</summary>(.*?)</details>` 替换为 Telegram 官方原生支持的 `<blockquote expandable><b>\1</b>\2</blockquote>`，并将 `**粗体**` 转为 `<b>`、Markdown 链接转为 `<a>`，最后全量剔除任何未匹配的残留 `</?(?:details|summary)[^>]*>` 孤立标签；
  - **痛点现象 B（文字丢失与悬空连续顿号）**：向 Telegram 发送包含技术标签（如解释 `<think>`、`<thought>`、`<details>` 等）的通报或消息时，未用行内代码块包裹或实体转义，Telegram 解析器直接将其当做非法的自定义 HTML 标签并静默隐藏，原本的文本在手机端呈现为诡异的连续悬空顿号（如 `、、、、<reason>`），排版彻底损毁；
  - **解决方案 B**：在任何向 Telegram 客户端汇报的消息中，凡涉及 HTML 标签名、正则符号或变量，必须严格放入行内反引号代码块或转义为 `&lt;tag&gt;`，严禁在常规文本中裸打裸发尖括号；同时避免滥用 Markdown 多级列表混杂导致语法符号原样暴露。

---

### 6. 群聊禁言风控与 Telegram `restrictChatMember` 解禁反弹陷阱 (Mute & Unmute Protocol)
- **指令矩阵**：
  - `/mute [时长]` 或回复某人发 `禁言`：禁言目标成员（默认 10 分钟，支持 `10m`, `2h`, `1d`）；
  - `/unmute` 或回复某人发 `解禁`：立即解除目标成员禁言，恢复全量发言权限。
- **权限边界与安全底线**：
  - 严格限制：仅限机器人拥有者（Owner）、本群群主（Creator）、以及当前群授权特权人员（VIP）可触发；
  - 防越权保护：严禁禁言 Owner、全局 VIP，以及本群群主（接口拦截）。
- **Telegram 底层解禁反弹隐形陷阱 (The Partial Unmute Trap & Rebound Bug)**：
  - **痛点现象**：管理员对群友执行 `/mute` 后，又使用 `/unmute` 解除禁言；群友当即可以发送简短文本，但**过了一段时间后（或客户端重连/数据中心同步/群权限刷新时），群友的发言框再次被锁死，禁言再次复发**！
  - **根本原因剖析**：
    1. Telegram Bot API 官方并没有单独的 `unrestrictChatMember` 接口，解禁必须依然调用 `restrictChatMember`；
    2. **官方协议强制准则**：*“Pass True for all boolean parameters to lift restrictions from a user.”*（要彻底解除限制，必须对所有布尔权限传入 True）；
    3. 若代码在解禁时仅手动构造常见发信权限（如仅设置 `can_send_messages=True` 等 10 项，遗漏了 `can_change_info`, `can_invite_users`, `can_manage_topics`, `can_pin_messages`）：
       - Telegram 服务端会**判定该用户的限制并未解除**，该群友在群组中的身份依然被死锁在 `ChatMemberStatus.RESTRICTED`（受限成员黑名单中）；
       - 由于解禁未显式传递合法的 `until_date`，Telegram 会将未放行项默认为 `until_date: 0`（永久受限）；
       - 一旦群友客户端刷新、与 DC 重新同步群成员元数据，客户端便会重新将该用户判定为受限，造成输入框再次锁死的“禁言反弹”假象；
  - **标准解决方案**：
    - 在解禁逻辑中，**绝对不要手动拼凑部分权限字典**；
    - **必须且只能传入 `ChatPermissions.all_permissions()`**：
      ```python
      # 正确范式：全量权限置为 True，彻底使 Telegram 服务端清除限制
      await bot.restrict_chat_member(
          chat_id=chat.id,
          user_id=target_user_id,
          permissions=ChatPermissions.all_permissions()
      )
      ```
    - 执行后，用户的 Telegram 身份将从 `ChatMemberStatus.RESTRICTED` 真正彻底复位为正常普通成员 `ChatMemberStatus.MEMBER`，`until_date` 变回 `None`，从协议层面彻底消除反弹隐患。
- **限时禁言到期 ≠ 自动解禁（第二个独立反弹元凶，2026-09-13 实测实锤）**：
  - 现象：群友被 `/mute 10m` 等限时禁言后，管理员从未来得及调用 unmute，但**禁言时长到期后群友依然发不出消息**，体感「禁言又触发了」；
  - 底层真相：Telegram `restrictChatMember` 带 `until_date` 到期后**并不会自动把成员恢复为全权限 member**——服务端只是把 `until_date` 置为 epoch 0（`1970-01-01`），成员身份停留 `ChatMemberStatus.RESTRICTED`，权限保持禁言时的全 False 值，直到有人显式下发 `all_permissions()` 才解除；
  - 实测案例：群友 `<YOUR_USER_IDENTIFIER>` 凌晨被默认 10 分钟禁言，数小时后 `get_chat_member` 仍返回 `restricted` + `until_date=1970-01-01`，显式调用 `ChatPermissions.all_permissions()` 后才复位为 `member`；
  - **运维体检/自愈模式**：Bot API 没有枚举群成员的接口（无 getChatMembers），排查「禁言反弹/成员被卡死」时，用 `bot.db` 的 `messages` 表按 `chat_id` 取最近活跃的 `DISTINCT user_id` 作为待检名单（可叠加已知活跃群友 ID 补充），逐个 `get_chat_member` 扫描 `status=restricted` 且 `until_date` 为 epoch 0 的残留受限成员，凡命中一律 `restrict_chat_member(permissions=ChatPermissions.all_permissions())` 修复并复查状态翻转回 `member/None`；建议做成 Bot 启动自检或定时巡检；
  - **排障提示**：群友发「禁言/解禁」文字指令但**没有回复目标消息**时，Bot 只弹一条使用提示就 return，**不产生任何 `execute_mute` 日志**——群友报「Bot 没反应/出bug了」且日志空白时优先怀疑这个，而不是进程故障；
  - **只读审计禁止动 UserBot session（实测）**：仅查询成员/限制状态时，Bot API（`get_chat_member` / `get_chat_administrators` + 本地 `bot.db` 的活跃成员名单）完全够用且零风险；**不要**为了只读检查去复制正在使用的 `.session` 开第二个客户端——同 auth_key 并发有 `AuthKeyDuplicatedError` 风控隐患，且复制会话往往 `get_dialogs` 找不到目标群（该群不在 UserBot 对话框列表时直接返回空），纯属多余动作。
  - **一键体检/修复脚本**见 `scripts/audit_restricted_members.py`（复用 `lemon-group-bot` 项目 venv 与 config，扫描活跃成员，`--fix` 自动修复残留受限）。

## 视频中转排障（video relay triage，2026-11 实测）

### 错误码速查

| 错误码 | 含义 | 处置 |
|---|---|---|
| `parser_busy_timeout` | 解析 bot 当时忙，队列满超时 | 偶发，重试即可；连续多条才检查解析 bot 是否在线 |
| `parser_no_response` | 解析 bot 无回应 | **先查中转群**（见下），不是目标群 |
| `route_denied`（无码，群内1~2s回FAILED） | relay_config.json 缺路由 | 补 `routes[群id]=bot_id`，热加载无需重启 |
| `unsupported_url`（无码，**不建 job、不进 jobs.db**） | `relay_core.HOSTS` 白名单没有该 hostname | 见下方「HOSTS 白名单与 bot 正则不一致」 |
| `delivery_or_commit_unconfirmed`（`state=uncertain`） | 解析成功但回传失败，**最常见是原消息已被删、reply 目标失效** | 见下方「中转回传 `state=uncertain`」一节 + `references/relay-delivery-uncertain.md` |

### HOSTS 白名单与 bot 正则不一致 → 链接被静默丢弃（2026-11-05 实测）

**这是「视频解析坏了但日志全干净」的头号原因**，因为它在建 job 之前就被拒，`jobs.db` 里连一条失败记录都不会有。

两处名单是独立的，必须人工对齐：

| 位置 | 作用 | 覆盖 |
|---|---|---|
| `services/media_urls.py` 的 `MEDIA_URL_PATTERN` | bot 侧**能不能识别出链接** | 允许任意子域（`(?:[a-zA-Z0-9_\-]+\.)?`），含 `kuaishou.com` / `weibo.com` / `pipix.com` / `bili2233.cn` |
| `relay_core.py` 的 `HOSTS` | relay 侧**收不收**（`validate()` 抛 `unsupported_url`） | 逐字列举，**只有** douyin/bilibili(www,裸)/b23.tv/youtube(含 m.)/xiaohongshu/xhslink/x/twitter/tiktok |

`race_adapter.allowed()` 的 `except (OSError, ValueError, KeyError, TypeError): return False` 会把 `unsupported_url` 吞成 False，于是 `try_race_video` 直接 `return False` → 群里只剩一句「FAILED：视频中转当前不可用，原链接已保留，未启动原生下载。」**journal 一行都不打。**

**2026-11-05 收口后的现行状态（HOSTS 23 条，两份 `relay_core.py` md5 必须一致）**：`m.bilibili.com` 走归一化；`bili2233.cn` / `m.douyin.com` 已进 HOSTS；`weibo.com` 家族、`t.bilibili.com`、`kuaishou.com` 全家、`pipix.com` **明确不进**（原因见下表）；`v.xiaohongshu.com` 仍未验证。逐条实测结论：

**2026-11-05 实测结论（@parsehubot 逐条探针，以 `bridge_ids` / `message_ids` 为准）**

| host | 解析 | 群内投递 | 处置 |
|---|---|---|---|
| `m.bilibili.com` | ✅ | ✅ `done` | 走 `canonical_video_url` 归一化成 `www.bilibili.com` |
| `bili2233.cn` | ✅ | ✅ `done` | 直接进 `HOSTS`（`bili2233.cn/<BV>` 302 到 bilibili，是真短链格式） |
| `m.douyin.com` | ✅ | ✅ `done` | 直接进 `HOSTS`（`/share/video/<aweme_id>`，aweme_id 可从 `v.douyin.com` 的 302 Location 里取） |
| `weibo.com` 家族 | ✅ | ❌ 被相册策略拦 | **未加入 HOSTS**。三个真实历史样本全是**图片帖**（`album_types: ["photo"]`），而相册白名单只放 X/Twitter 和 douyin，`validate_relay_first` 会 cancel 成 `race_lost_or_expired`，群里看到「FAILED：中转任务未确认」，容易误判成故障 |
| `t.bilibili.com` | ❌ `parser_no_response` | — | 是「动态」不是视频，别加 |
| `kuaishou.com` / `pipix.com` | 无法验证 | — | 全库历史零样本，构造不出真链接；不要凭"应该支持"就加 |

**验证方法论（关键，别省）**：
- **判成功只看 `jobs.db` 的 `state=done` + `result.message_ids`**。`try_race_video` 返回 `True` **不代表成功** —— 失败路径为了阻止原生兜底也返回 True，且 `except` 分支会吞掉具体原因。
- **同一 `(chat_id, message_id, url)` 的 job_id 是确定的**，复用旧 message_id 再跑会命中已 `done` 的 job → `prepare_relay_first` 抛 `relay_not_ready` → 什么都不发，看起来像"没生效"。每次验证换一个**真实存在**的 message_id。
- **探针提交后不要马上重启 worker**：`ready` 态在重启时会被写成 `uncertain / interrupted_requires_review`，原始 `result`（含 `bridge_ids`、`album_types`）被覆盖，证据丢失。
- **看 `album_types` 才能判"解析成功但投递不了"**：探针要打印完整 `result`，只看 `bridge_ids: True` 会漏掉相册类内容。
- 微博类链接匿名 `curl` 拿不到页面标记，无法从 HTML 判断视频/图片，只能靠 relay 返回的 `album_types`。
- **探针要打印完整 `result`，不要只看 `state`/`bridge_ids`**。用 `scripts/probe_relay_host.py <url> <chat_id>`（socket 直连 submit，打印 `state/error/bridge_ids/album_types/video_parts/caption` 首行，从不打印 token）。只看 `bridge_ids: True` 会把「解析成功但相册策略拦下」误判成通过。
- **读 `jobs.db` 必须只读 URI + 超时**：worker 在跑时普通 `sqlite3.connect(path)` 会被锁住**无限等**（实测把一次批量脚本卡到 300s 超时被杀，什么都没输出）。一律写成
  `sqlite3.connect('file:/home/ubuntu/lemon-userbot/relay-state/jobs.db?mode=ro', uri=True, timeout=5)`，再配外层 `timeout 20`。
- **`uncertain` 是终态、不占队列**，但它是探测/重启留下的垃圾，会一直堆在库里干扰判读（本次 14 条）。清库属数据修改，**先问 Owner 再删**，别顺手 `DELETE`。


**修法：优先在 `canonical_video_url()` 里归一化，不要直接往 HOSTS 塞。** 该函数是设计内的准入归一化点，已有 `m.youtube.com → www.youtube.com` 的先例，且带安全回归测试（拒绝 `m.bilibili.com.evil.test` / `evil.test/m.bilibili.com` / 带凭据 / http / 非 443 端口）。2026-11-05 已加 `m.bilibili.com → www.bilibili.com`：

```python
_CANONICAL_VIDEO_HOSTS = {'m.youtube.com': 'www.youtube.com',
                           'm.bilibili.com': 'www.bilibili.com'}
```

- `relay_adapter.py` **只在 `lemon-group-bot` 有一份**，`lemon-userbot` 没有；但 `relay_core.py` 两份 md5 必须一致（`md5sum` 比对）。
- 改完 `py_compile` → 重启 **两个** Bot（bot1 → sleep 4 → bot2 错峰）→ grep journal 无 traceback。
- 验收三段式（逐级加硬，别跳）：
  1. **纯校验**（不发消息）：`race_adapter.allowed(req)` 必须 True。
  2. **函数级**：`await race_adapter.try_race_video(bot, chat, msg_id, url)` —— 但 **bot 必须是真 `telegram.Bot` 且先 `await bot.initialize()`**，否则 `.id` 抛 `RuntimeError: Bot is not properly initialized`；用 `SimpleNamespace(id=...)` 会在投递阶段炸 `'SimpleNamespace' object has no attribute 'copy_message'`，留下 `uncertain` 脏 job。
  3. **端到端**（会真发消息）：真 Bot + 真实存在的 `message_id` 当 reply 目标，跑完查 `jobs.db` 最新行必须 `state=done` 且 `result={"message_ids":[...]}` —— 那个 message_id 就是群里新出现的视频，是唯一的硬证据。`REPLY_TARGET_GONE` 会降级为不 reply 直发，属正常。
- 子进程直跑 `race_adapter` 前必须 `export TELEGRAM_BOT_TOKEN=$(systemctl show <bot2>.service -p Environment --value | tr ' ' '\n' | grep '^TELEGRAM_BOT_TOKEN=' | cut -d= -f2-)`，否则 `config.BOT_ID` 落到另一个 Bot，`native_allowed()` 读到未授权群直接 False —— 看起来像"修复没生效"。
- `allowed()` 的 `except` 已加 `RELAY_ADMISSION_DENIED` warning（含 url/error_type/detail），2026-11-05 起拒绝原因可查。在此之前是**完全静默**，别再假设"日志干净=链路正常"。
- 探针/端到端验证会留下 `ready` 脏 job 占 `queue_limit` 名额（`Store.add` 判满包含 ready），用完必须 `op=cancel`（`request` 要原样回传 db 里存的那份，否则 `request_binding_mismatch`）。
- **版本保护（2026-11-05 已补齐）**：整个 relay 子系统原先在 git 里全是 `??` untracked（`relay_adapter.py` / `race_adapter.py` / `relay_core.py` / `race_route_policy.py` / `tests/test_youtube_relay_first_20261014.py`），改动零回滚点。现已提交：
  - `lemon-group-bot` → `8b0aabb`（上述 5 文件，885 行）
  - `lemon-userbot` → `1db8370`（`relay_core.py` / `relay_worker.py` / `relay_config.json` / `race_errors.py` / `race_video_parts.py` / `relay_music_diagnostics.py`），并在其 `.gitignore` 补 `relay-state/`、`*.bak-*`、`*.before-*.json`，防止 `jobs.db` 和时间戳备份进库
  - **提交纪律**：两个仓库各有 80+ 项历史脏改动（`git status --porcelain | wc -l` 实测 93 / 22），**只 `git add` 本次动到的文件，绝不 `git add -A`**，否则一次 commit 混入几十项无关改动，等于把回滚点废掉
  - 提交前扫凭据：`grep -nEi 'token|api[_-]?key|password|secret|<provider 域名>'`，本次仅命中 `parsed.password is None` 这类校验逻辑，干净才提交
  - **只本地 commit，不 push**（remote 是 `nayeshiluo/lemon-*`）；push 属对外动作，等 Owner 明确点头


**排查这类问题的高效手段：bot.db × jobs.db 对账。** 把最近 N 天 `messages` 里能提取出媒体链接的行，按 `(chat_id, message_id)` 去 `jobs.db` 的 `request` 里找对应 job，找不到的就是被静默丢弃的；再按 hostname 分组，一眼看出是名单缺口还是 route/开关问题：

```python
# 关键判据：host 不在 HOSTS → 名单缺口；host 在 HOSTS 但无 job → 查 route/feature/_VIDEO_INFLIGHT
stat[(host, host in HOSTS, (chat,mid) in jobkeys, routes.get(str(chat))==bot_id)] += 1
```


### video_bot_id 工作在「中转群」，不需要在目标群里
`relay_config.json` 的 `video_bot_id`（`<YOUR_USER_IDENTIFIER>`）只需是 `relay_chat_id`（`<YOUR_TELEGRAM_GROUP_ID>`，群霸中转站）的成员，**不要求它在被解析的目标群里**。

实测（2026-11-01）：茶话领域（`<YOUR_TELEGRAM_GROUP_ID>`）在 23:15 把该 bot 踢掉（`administrator→kicked`），23:22 第一条请求 `parser_no_response`，23:28 下一条就 `state=done`——因为中转群身份仍是 `member`。

遇 `parser_no_response` 先核查中转群，不是目标群：
```bash
T2=$(systemctl show lemon-group-bot2.service -p Environment --value | tr ' ' '\n' | grep '^TELEGRAM_BOT_TOKEN=' | cut -d= -f2-)
curl -s "https://api.telegram.org/bot$T2/getChatMember" \
  -H 'Content-Type: application/json' -d '{"chat_id":<YOUR_TELEGRAM_GROUP_ID>,"user_id":<YOUR_USER_IDENTIFIER>}' \
  | python3 -c "import sys,json;d=json.load(sys.stdin);print(d.get('ok'),d.get('result',{}).get('status'))"
```

### 频道/皮套身份的消息不进解析（2026-11-02 已修，此前的「设计行为」结论是错的）

旧结论说「消息有、任务没有」是 `_VIDEO_INFLIGHT>=2` 或 URL 去重导致的**设计行为** —— 实测推翻：
代码里**没有任何 URL 去重缓存**，真实根因是 `handle_group_message()` 里频道身份早退，详见本文末尾
「频道/皮套身份触发视频与音乐」一节。判断方法：按发送者身份分列该群链接消息，看是否**所有**
`sender_chat` 消息都没 job、而所有真人消息都有 —— 若是，就是这个早退，不是限流也不是去重。

`is_automatic_forward=True` 的关联频道自动转发另有一条独立限制：`quote_match` 会因该标志被置 None
（`messages.py` 里 `not getattr(msg, "is_automatic_forward", False)`），所以自动转发消息**不能**触发
`/q` 等指令；但视频/音乐解析不受这个标志影响。

### 视频探针脚本
```bash
python3 ~/.hermes/skills/messaging/music-relay-triage/scripts/relay_video_probe.py \
  'https://v.douyin.com/xxxxx/' <YOUR_TELEGRAM_GROUP_ID>
# state: ready / failed    bridge_ids: True / False    error: None / ...
```
成功标志：`state=ready`，`bridge_ids` 非空，`error=None`。探针会在中转群留一条真实视频，不会下发到目标群。

## /sum 参数上限与菜单缓存（2026-11 实测）

`handlers/commands.py: parse_summary_arg()` 是**唯一**参数解析点（`execute_summary` 调用）：
- 普通群友 500 条 / 24h；主人+群管理 3000 条 / 7 天；无参数 80 条。
- `今天`、`半小时` 分支天然不超上限；`昨天` 曾直接 `return secs` **绕过裁剪**（普通用户能拿到 ~48h），已补 `max_secs = int(max_hours * 3600)` 裁剪并加「已达普通上限」后缀。
- `bot.py` 的 `OWNER_GROUP_COMMANDS` 里 sum 描述原写「无上限」，与实际 3000 条/7 天不符，已改为「上限3000条/7天」。改这类文案必须同步核对 `parse_summary_arg` 的真实上限。
- **菜单是逐人 scope 缓存，改常量后仅重启不刷新**。必须排菜单同步再逐个核对：
  ```bash
  python3 -c "from services.menu_sync import enqueue; enqueue('<PRIVATE_IDENTIFIER>','group',-100xxxxxxxxxx)"
  # 等 menu_state.db 的 jobs 跑完，再核对（scope 必须是 chat_member，user 填目标用户）
  curl -s "https://api.telegram.org/bot$TOKEN/getMyCommands" -H 'Content-Type: application/json' \
    -d '{"scope":{"type":"chat_member","chat_id":-100xxx,"user_id":<YOUR_TELEGRAM_ID>}}'
  ```
- **bot1（`lemon-group-bot.service`）的 systemd unit 不注入 `TELEGRAM_BOT_TOKEN`**，token 来自项目 `.env` 或 `~/.hermes/.env` 的 `TELEGRAM_BOT_TOKEN_<PRIVATE_IDENTIFIER>`；用 `systemctl show -p Environment` 取 bot1 token 会拿到空值，`getMe` 返回 `Not Found`（不是 token 失效）。
- 测试：`python3 -m unittest discover -s tests -q`（**未装 pytest**，`test_douyin_share_service`、`test_image_album_service` 会 import 报错，属环境缺失）。`test_io_hotpath.ConfigCacheTests.test_in_place_edit_with_restored_mtime_is_detected` 为既有失败（`config.py`/`json_store.py` 未改动），与业务改动无关。
- 改了日报取数上限/话题上限后，`tests/test_daily_refill.py`、`tests/test_summary_window.py` 的旧断言（3 条/5 条/无 `max_limit`）必须同步更新，否则套件报 FAIL。

## 频道/皮套身份触发视频与音乐（2026-11 实测）

**症状**：关联频道（皮套）在群里发的抖音/快手链接**完全没反应** —— `bot.db` 有消息、`jobs.db` 无 job、journal 无 `MEDIA_ROUTE`。同一链接换成真人发就正常。

**根因**：`handlers/messages.py` 的 `handle_group_message()` 里，频道身份消息命中早退：

```python
if not user or not record_is_user:   # 频道/匿名管理员身份
    ...save_message(...)
    return                            # ← 早退，D 段视频解析(在后面)永远到不了
```

频道身份 `effective_user is None`、`record_is_user=False`，所以只入库不解析。**不是 URL 去重**（代码里没有 seen/processed 缓存），也不是队列满。

**修复（已落地）**：
1. 早退块 `return` 前调用新增的 `_handle_channel_media()`，只放行 `music` 与 `video`，其余指令路径仍不可用。
2. `_channel_identity()` 用 `telegram.User(id=record_user_id, is_bot=False, first_name=...)` 合成身份 —— 音乐缓存 `MUSIC_SEARCH_CACHE[session_key]` 需要 `user.id`，`user=None` 会 AttributeError。
3. `services/interactive_jobs.py` 的 `_allowed()` 放宽为 `feature in ("quote","music")` 才允许 `sender` 身份（视频不走这个入口，直接在 handler 里 `create_task`）。
4. `tests/test_channel_quote_commands.py::test_queue_accepts_quote_and_music_only_and_owner_spoof_is_rejected` 断言同步更新（原断言 `music` 必须为 False）。

**验收要点**：
- 离线分支测试（mock IO、跑真实 `handle_group_message`）：皮套发链接→建 task、皮套 `/music` 与 `点歌`→入队、普通文字→不触发、`video` 关闭→不触发、`_VIDEO_INFLIGHT>=2`→回繁忙。
- 真实配置校验：`jobs._allowed(up,'music')` 对频道身份须为 True，`ai`/`summary`/`video` 仍 False。
- 点歌按钮：`handle_music_callback()` **不校验点击者==缓存 user_id**，只校验 `chat_id` + `bot_id`，所以皮套发的点歌卡片群友能正常点播（无需额外改动）。
- 本地跑必须用项目 venv：`/home/ubuntu/lemon-group-bot/.venv/bin/python3`（系统 `python3` 没有 `telegram` 模块）。
- 离线验收这类分支时，假 Task 必须**可 hash**（`_VIDEO_INFLIGHT` 是 `set`）：用带 `add_done_callback` 的小类，
  别用 `types.SimpleNamespace`，否则 `TypeError: unhashable type`。

## 中转回传 `state=uncertain`（回传结果未确认）

群里显示 `FAILED：回传结果未确认，请先检查群内是否已有视频或音乐；为避免重复，未自动重发。`
`jobs.db` 里 `state=uncertain`、`result={"error":"delivery_or_commit_unconfirmed"}`。

**先分段，别直接查解析**：用 `music-relay-triage` 的 `relay_video_probe.py` 复跑同一 URL，
拿到 `state: ready` + `bridge_ids` 就说明解析链路完好，问题在群霸回传段（`deliver()` / `commit`）。
探针不经 `deliver()`，不会往目标群发媒体。**这一步同时把被 `uncertain` 覆盖掉的 `bridge_ids` 找回来**
（`result` 被整条覆盖是设计，事后库里看不到解析到底成没成）。

**最常见根因：原消息已被删除** → `copyMessage` 的 `reply_to_message_id` 失效 →
`400 Bad Request: message to be replied not found` → 整单标 `uncertain`（其实一条媒体都没发出）。

```bash
export TELEGRAM_BOT_TOKEN=$(systemctl show lemon-group-bot2.service -p Environment --value \
  | tr ' ' '\n' | grep '^TELEGRAM_BOT_TOKEN=' | cut -d= -f2-)
/home/ubuntu/lemon-group-bot/.venv/bin/python3 \
  ~/.hermes/skills/messaging/telegram-group-bot-suite/scripts/relay_reply_probe.py \
  -100xxxxxxxxxx 425365
```

`reply_to N: GONE` 即确认消息已消失。修复是 `relay_adapter.send_with_reply_fallback()`：
**只对 `message to be replied not found` 降级为不带 reply 重发**（400 = 请求整体被拒、一条没发出，
不会重复），其余异常照旧抛、照旧标 `uncertain`、照旧禁止自动重发 —— 这条红线不能放宽。
三处调用点都要包：`deliver()` 单条 `copy_message`、`deliver()` 相册 `send_media_group`、
`race_video_parts.deliver_parts()` 分段 `send_media_group`。

`race_adapter.claimed_relay_delivery()` 原来 `except` 完全不记录异常（群里只看到一句 FAILED、
journal 全空，只能反推），现已加 `RELAY_TRANSFER_FAILED` 日志，排障**先 grep 这行**。

完整证据链、三条易混文案的出处对照、离线验收四用例、以及「改完不重启 = 跑旧代码」等坑，
见 **`references/relay-delivery-uncertain.md`**。

### 排障纪律（中转 / 回传类任务通用）

- **手工探针会往生产群发真实媒体，必须主动认领**。`copyMessage` / `forwardMessage` / `relay_video_probe.py` 都会在群里留下真视频或真音频；查 `uncertain` 时为了验证「不带 reply 能不能成」往往要真发一条。做完**主动告诉 Owner 哪条是验证痕迹、可以直接删**，别默认他看不见或不在意。
- **不要把卡片文案当根因**。`race_errors.failure_text()` 是按 `state` + `producer_errors` 拼出来的展示层，同一个 `uncertain` 文案背后可能是完全不同的上游原因；一律回 `jobs.db` 的 `result.error` 和 request 里的 `message_id` 取证。
- **超长内联命令会被 hardline 拦**（`command parser limit or malformed executable payload`；这不是审批弹窗，加 `--yolo` 也没用）。排查脚本一律 `write_file` 成 `/tmp/xxx.py` + 一个 `/tmp/run_xxx.sh`（内含取 token 的 `export`），再 `bash /tmp/run_xxx.sh`。既绕开拦截，也避免 token 出现在命令行。
- **改 `relay_adapter.py` / `race_adapter.py` / `race_video_parts.py` 必须重启两个 Bot**（只有 JSON 配置是热加载）；改完先 `py_compile`，再 bot1 → sleep 4 → bot2 错峰重启，最后 grep journal 有没有 traceback。

## 「梯队是啥样 / 分别是谁的模型」——只读盘点口径（2026-11-19）

Owner 这类问题要的是**结论表 + 溯源**，不是罗列 JSON。三步缺一步就会把兜底说成主用：

1. `get_active_chain(bot_id)` 拿真实 order/disabled/model（别读 JSON 手算，`load_ai_nodes` 会滤掉 `order` 里已删的端点）；
2. 每个节点按 `key_env` 解析凭据后**发一次真实最小请求**，看返回 `served_model`（顺序对 ≠ 能用，主节点可能 503）；
3. 节点若是本机网关（`127.0.0.1:xxxx`），**再去网关自己的 `providers.json` 查该 model 前缀属于哪个 provider** —— 同一个词 `workbuddy` 在群霸节点表和 magpie provider 表里是**两个不同实体**（`global:` 前缀 = WorkBuddy2API 账号池；`workbuddy/xxx` = magpie 内部 OAuth provider）。

快照与坑见 `references/llm-chain-provenance-inventory.md`，一键跑 `scripts/probe_chain_provenance.py`。
两条实测教训：① WorkBuddy2API 的 `/status` 可能报 `healthy=total` 而实际全 503（全部账号 `credits < credit_floor`，`healthy` 字段不反映这层）；② 周三站 `token.thxnk.cc` 无浏览器 UA 直接 `403 error code 1010`，自制探针漏 UA 会误判「周三挂了」（业务路径本来就注入 UA）。

## AI 兜底节点替换与「真会落下去」的验证（2026-11-03 实测）

群霸的模型链是**两层文件**，换节点只动 JSON、不用改代码：

| 文件 | 作用 |
|---|---|
| `data/ai_endpoints.json` | 共享端点池：`id` / `name` / `url`（**到 `/chat/completions` 为止**）/ `key` 或 `key_env` / `default_model` |
| `data/ai_bot_<bot_id>.json` | 每个 Bot 自己的 `order`（优先级）与 `disabled_nodes` |

两 Bot 各有一份 `ai_bot_*.json`，`order` 默认相同但**必须分别改**，只改一个另一个还留着旧节点。

### 加新端点的三个硬约束

1. **`url` 要写全路径** `https://host/v1/chat/completions`，不是 `base_url`。
2. **优先 `key_env`，不写 `key`**。`_read_env_val()`（`ai_service.py:60`）先读 `os.getenv`，再兜底读 `/home/ubuntu/.hermes/.env`，所以 Hermes 已经在用的 `IKUN_API_KEY` 这类直接就能被群霸复用，**不必把 key 复制进项目**。
3. **不用配 `extra_headers`**：`ai_service.py:777` 的真实调用和 `:466` 的连通性测试都硬编码了浏览器 UA，第三方站的 Cloudflare 1010 拦截不会命中。同理 `_supports_reasoning_effort()`（`:286`）只对 `127.0.0.1:8317` 注入 `reasoning_effort`，外部端点不会被塞这个参数 —— 加第三方端点不用担心这两类 400。

### 总结模型选型与验收：超时、正文、质量分别核实

- 新节点先核对默认超时与整链预算；不能断言“新节点必挂”或“某次基准低于预算就有充足余量”。相同字符数的重复文本与真实多话题聊天不等价。
- 用户贴出失败截图或连续追问时，先简短回应并认领未验收项，立即按 Bot、群、消息 ID 和时间窗口查请求日志；不要重复长篇方案代替已授权执行。用户负责充值某备用时，其他可独立修复项继续推进，不等待充值、不擅改该站凭据。
- 选总结模型用相同真实失败窗口、相同来源与回复链，比有效正文成功率、归因与引用准确性、话题覆盖、耗时和实际额度。问答测活通过不等于长总结适用；目录中的名字只是路由标签，未实测的候选不能按品牌印象推荐为已适合。
- HTTP 200 仍需检查有效正文；记录 `finish_reason`、`usage`、正文/思考字段长度及清洗前后长度，日志不落原始群聊、思考内容或凭据。没有这些证据不得将空正文归因于 token 不足，更不得把思考字段作为答案。
- 失败卡片可能仅展示末位节点。必须按同一请求逐跳还原，不能将末位错误当整链根因；403 按上游错误码区分权限、额度、模型或风控，而非统一叫鉴权失败。
- 验收分层汇报：配置回读、节点调用、真实消息干跑、生产进程加载、Telegram 实际投递。只完成前几层就明确说到哪层；未实际发送不能报群内已修好。优先后台干跑，不让用户反复触发碰运气，不用重启替代原因诊断。

以下是历史超时实验，不构成完整修复或当前推荐；空正文与额度失败的反例见 `references/summary-validation-counterexample.md`。

### 历史实验：新节点默认超时覆盖（2026-11-06）

`get_node_timeout()`（`ai_service.py:633`）只对少数老节点有内置特例，**其余一律走 `else: return 20.0 if large_request else 10.0`**。新接的节点（`command` / `zhousan` 这类）没配覆盖就是 **large 20s / small 10s**。

以下仅是当时合成输入的单次耗时，不能预测真实聊天耗时或稳定性：

| 节点 | 47K 输入 + 2500 tokens HTML 总结 | 20s 预算够吗 |
|---|---|---|
| `reflection/beam:free` | 7.6s | 够（但真实聊天记录更重，实测线上打满 20s） |
| `deepseek/deepseek-v4.1-flash` | 11.4s | 够 |
| `stealth/glyph-cluster:free` | **18.3s** | 逼近上限，一旦抖动必超 |
| `Deepseek v4.1 Flash`（周三） | 11.0s | 够 |

**症状指纹**：群里显示 `❌ 总结生成失败：<末位节点名> 请求超时`，日志是一串

```
LLM node [Command·厂家] 请求超时 (>20.0s)
LLM attempt finished ... node=command fallback_index=0 outcome=timed_out node_budget_s=20.000 node_elapsed_s=20.739
LLM node [周三·Deepseek-V4.1-Flash] 请求超时 (>20.0s)
[CircuitBreaker] 节点 zhousan 触发熔断！连续失败 9 次
```

注意**报错里永远是末位节点名**，真正被打满的是第一个。别看到「周三超时」就去查周三。

**修法**：`data/ai_timeout_overrides.json`（热生效，不用重启）

```json
{"command": {"small": 15.0, "large": 40.0},
 "command_ds": {"small": 15.0, "large": 40.0},
 "zhousan": {"small": 15.0, "large": 40.0}}
```

`large` 写 40 实际落到约 33s —— 大请求会被 `min(配置值, remaining / slots)` 按剩余槽位压缩，这是设计行为，不是没生效。

**历史调序不等于已验证推荐**：当时依据单次耗时把第二备从 Glyph 换为 Deepseek，但后者真实总结随后也返回空正文，不能据此称其更稳。模型费用须核对当前官方定价与账户权益，不从 `:free` 后缀有无推断。

**验收必须走真实总结路径**，不要只 curl 节点：

```python
from services import ai_service
content, err = await ai_service.summarize_messages(
    chat_id=-100xxxxxxxxxx, chat_title="自检群", target_desc="最近 2200 条发言",
    messages=msgs, is_scheduled=False, user_id=<YOUR_TELEGRAM_ID>, style="interactive")
# 期望 content 非空、err 为 None、耗时 < 33s
```

构造重复发言通过只能证明该测试输入可用，不可当作真实群聊复现或线上验收。2026-11-06 合成 2200 条测试 16.7s 成功，但真实 2000 条随后失败：command 与 command_ds 均 HTTP 200 空正文，周三 403 insufficient_user_quota（无有效订阅），并非鉴权错误。必须用失败窗口的真实消息干跑，核对 finish_reason、usage、正文与 reasoning 字段长度及清洗前后长度，区分 token 耗尽、上游空正文和清洗误删。不得仅靠加超时或单次基准声称修好；403 必须读具体错误码，额度问题不能靠重启解决。

## 总结与日常问答分流（2026-11-06 已落地，双 Bot）

群霸原本一条链同时承担日常问答和长总结。reasoning 模型（Beam/Glyph/Kimi）在 47K 输入下会把输出预算几乎全烧在思维链上，表现为 **HTTP 200 + finish_reason=length + 正文 0 字**，而日常短问答完全正常。所以总结必须单独选模型。

### 机制（`services/ai_service.py`）

- `_call_llm(..., purpose=None)` → `_call_llm_unchecked(..., purpose=None)`；只有 `summarize_messages` 与日报 refill 传 `purpose="summary"`。
- `purpose="summary"` 时链路经 `_summary_model_chain(nodes, bot_id)` 换模型，**节点顺序、启停、凭据全部沿用**，只替换 model 与显示名。
- 配置在每 Bot 的 `data/ai_bot_<ID>.json`：
  ```json
  "summary_model_overrides": {"command": "moonshotai/Kimi-K2.5", "command_ds": "reflection/beam:free"}
  ```
  只写节点 id → 模型名；没写的节点原样保留。校验器会拒非法值（非 dict、空串、非字符串）。
- 改 JSON 热生效；**改 `.py` 必须重启**（`sudo -n systemctl restart lemon-group-bot lemon-group-bot2`）。

### 实测结论（真实 2000 条 / 42779 字符，非合成数据）

| 模型 | 结果 | 耗时 |
|---|---|---|
| `moonshotai/Kimi-K2.5` | stop，1876–2567 字，来源链接全有效 | 16.1s / 22.0s |
| `reflection/beam:free` | stop，1571–1611 字 | 19.9s / 16.9s |
| `stealth/glyph-cluster:free` | stop，1663 字 | **52.3s**（太慢，不做交互总结） |
| `moonshotai/Kimi-K2.6` | 90s 超时 | — |
| `Qwen/Qwen3.6-Plus` | 90s 超时 | — |
| `deepseek/deepseek-v4.1-flash` | 反复 length + 8192 全推理 + 正文 0，**不可靠** | 23–70s |

结论：总结链 `Kimi-K2.5 → Beam → 周三`；日常链 `Beam → Deepseek → 周三` 不动。同站两跳 + 跨站兜底。

### 输出预算策略

`_apply_command_output_policy(node, payload, large_request)`：只对**已验证的「节点 id + 模型名」组合**（`_VERIFIED_OUTPUT_ROUTES` 白名单）生效，长请求抬到 `max_tokens≥8192` + `reasoning_effort=low`。当前白名单：`command`/`command_ds` × (`reflection/beam:free`、`moonshotai/Kimi-K2.5`)，以及 `zhousan` × `Deepseek v4.1 Flash`。

**白名单必须覆盖每一个兜底跳**（2026-11-06 踩到）：只给 `command`/`command_ds` 配策略时，第三跳周三仍用 2500 预算，真实 2000 条下 22s 返回空正文。用 `verify_chain.py tertiary`（前两跳注入 503）才能暴露这种"主备都好、兜底空转"的问题。**只测 primary 和 fallback 会漏掉最后一跳。**

白名单机制本身很重要：手动在 `/model` 换到未验证模型时不能盲塞 provider 私有参数（`thinking` 等），实测 Deepseek 会忽略且行为更差。

### 各跳真实 2000 条实测（2026-11-06，周三充值后）

**线上闭环验收**（新进程 PID 12:07 启动，12:28 群内真实 `/sum 2000`）：

```
samples=2000/2000 input_chars=43856
node=command finish_reason=stop output_budget=8192
completion_tokens=1074 reasoning_tokens=0 content_chars=2059
总结·moonshotai/Kimi-K2.5 fallback_index=0 elapsed_s=11.326
```

主链一次命中，11.3s 出 2059 字，零 WARNING/零 ERROR。失败基线是 55.8s + 403。

| 跳 | 模型 | 耗时 | 正文 | 来源 | 卡片 |
|---|---|---|---|---|---|
| 主 | `moonshotai/Kimi-K2.5` | 11.3s（线上）/ 20.2s（脚本） | 2059–2354 字 | 17 | 5 |
| 备 | `reflection/beam:free` | 11.9s | 1549 字 | 16 | 4 |
| 兜底 | `GLM 5.3`（周三） | **9.9s** | 1917 字 | 16 | 5 |

线上比脚本快一倍是 command 厂家 prompt 缓存命中，正常。

周三中转站（ikun）只有 4 个模型，真实 2000 条实测：

| 模型 | 耗时 | 正文 | 结论 |
|---|---|---|---|
| `GLM 5.3` | 15.8 / 11.4 / 11.8s | 2051–2399 字 | **最快最稳，三轮全 stop** |
| `GLM 5.3 Flash` | 37.0s | 2770 字 | 反比 GLM 5.3 慢，思考更啰嗦 |
| `Deepseek v4.1 Flash` | 58.4s | 2506 字 | thinking 极重（7840 tokens 正文仅 2506），淘汰 |
| `Deepseek V4 Pro` | 504 超时 | — | 不可用 |

所以总结兜底跳用 `GLM 5.3`，不是节点默认的 `Deepseek v4.1 Flash`。**别被 "Flash" 名字骗**——GLM 5.3 Flash 比 GLM 5.3 慢三倍。

`GLM 5.3` 在 2500 预算下也能正常出正文（不像 Deepseek 会空转），但总结需要 8000+ 输出空间，仍须进白名单拿 8192 + low。

### 验证脚本不能硬编码配置

`verify_chain.py` 早期版本把 `summary_model_overrides` 写死在脚本里，结果改完生产配置跑 tertiary 仍走旧模型（58.4s），差点误判"改动没生效"。脚本必须读**生产 bot 配置**：

```python
def config(bot_id=None):
    return dict(ORIGINAL_CONFIG('<PRIVATE_IDENTIFIER>'))  # 钉死 bot id
```

钉 bot id 是因为裸跑时没有 `BOT_TOKEN` 环境变量，`BOT_ID` 会退化成 `default` 而读不到真实配置（同时会打 `Configuration unavailable` 警告，属脚本噪音非生产故障）。

### 子代理的“质量不合格”结论必须先回原文复现，再决定要不要撤方案

2026-11-06 翻车：一个只读子代理回报“Kimi K2.5 把话归给错误的人、把‘离群’写成‘被踢’”，据此向用户撤回了已上线的总结选型。随后逐条回原文核对——三份候选正文（Kimi / Beam / 周三）里**根本不存在“被踢/离群/踢出”任何表述**，抽查的 6 条 `message_id` 发言人归属也全部正确。结论不可复现，等于白撤一轮，还误导了用户。

规则：

- 子代理对**生成内容**的判断（归因错、事实错、质量差）只是线索，不是证据。它可能跑的不是同一批文件，也可能幻觉。
- 复现方式：拿它点名的**具体缺陷关键词**在候选正文里全文检索（`grep`/正则），再回 `data/bot.db` 按 `message_id` 查 `user_name` + `text` 核对发言人。两步都命中才算真缺陷。
- **只有能复现的缺陷才能触发方案回滚。** 撤方案的成本比加方案高，别凭一句转述撤。
- 归因抽查的字段名是 `user_name`（不是 `sender_name`），`text` 是正文，`reply_to_msg_id`/`reply_to_user_name` 是回复链。

### 核对总结事实时，模型会“加料”

同一窗口下周三把原文的 `2k` 写成“提了两次总共 200、封口费 2k，合计 2200”——数字是它自己推算拼出来的，原文没有。Kimi 写的“2000”更贴原文。**抽查时要区分“原文有的”和“模型算出来的”**，后者不能当事实写进验收报告。

### `get_node_timeout(node_id, large_request: bool)` 第二参数是布尔

传字符串 `'small'` / `'large'` 会双双走 truthy 分支，全部返回 large 值，看起来像“配置没生效”。正确写法：

```python
ai.get_node_timeout('zhousan', False)  # small
ai.get_node_timeout('zhousan', True)   # large
```

### 裸跑验证脚本时的 `Configuration unavailable` 是噪音

不经 systemd 直接跑脚本时没有 `BOT_TOKEN`，`BOT_ID` 落成 `default`，`CONFIG_FILE` 指向不存在的 `data/config_default.json`，`config.py` 于是打印 `Configuration unavailable; retaining last good settings, cold start fails closed`。**生产服务带环境变量，不受影响。** 看到这行别去改配置，先确认是不是裸跑。

### 403 不等于鉴权失败

`_http_failure_category(status, body)`：`429`、或 `402/403` 且 body 含 `insufficient_user_quota` / `insufficient_quota` / `no active subscription` → `quota_error`，提示“额度不足或订阅不可用”；否则 401/403 才是 `auth_error`。此前周三额度耗尽被笼统显示成“鉴权失败”，误导排查方向。**额度问题充值解决，换密钥/重启无效。**

### 验收（必须三跳都真跑）

```bash
.venv/bin/python backups/command-summary-candidates/verify_chain.py primary    # 主链真跑
.venv/bin/python backups/command-summary-candidates/verify_chain.py fallback   # 注入主节点 503
.venv/bin/python backups/command-summary-candidates/verify_chain.py tertiary   # 注入前两跳 503
```

三模式靠 `MODE_FAILURES = {'fallback': {...}, 'tertiary': {...}}` 决定哪几个 `model` 名被替换成 503，`FallbackSession.post()` 里比对 `kw['json']['model']`。**新增兜底跳时必须同时加进 `MODE_FAILURES['tertiary']`，否则第三跳永远测不到。**

### 换首跳（把新节点排到 order 第一位）的验收

总结和日报**共用同一条链**，不需要分别配置：

```
summarize_messages(style="summary"|"daily")
  → _call_llm(purpose="summary")
  → get_active_chain(bot_id)          # order 排序、过滤 disabled/无 key
  → _summary_model_chain(chain, bot)  # 仅此处应用 summary_model_overrides 换模型名
```

所以改 `order[0]` 就同时改了两者；`summary_model_overrides` 是唯一的「日常 vs 总结」分流点。

- **`scripts/verify_summary_chain.py` 只证明「链能出字」，不证明落点** —— 它不打印实际节点。必须再对一次上游日志，否则 fallback 悄悄接住了你也看不出来。
- 落点核对技巧：群霸请求硬编码浏览器 UA（`Mozilla/5.0 ... Chrome/126.0`），在上游网关日志里 `grep 'Chrome/126'` 就能把群霸的请求从一堆探针流量里挑出来，再对齐模型名、耗时、`tok` 数。
- **`backups/command-summary-candidates/verify_chain.py` 的 `MODE_FAILURES` 写死旧模型名**（`moonshotai/Kimi-K2.5`、`reflection/beam:free`）。插入新首跳后不把新模型名加进去，fallback 就永远测不到首跳。
- 用 `scripts/verify_fallback_landing.py`：注入指定模型 503，断言 `fallback_index > 0` 且落点不等于被注入节点。它不改项目文件、不污染熔断与计数。
- **日常档和总结档要用不同模型**：`ai_endpoints.json` 的 `default_model` 管日常问答，`summary_model_overrides[node_id]` 管总结/日报。两处都设成贵档会被日常流量烧穿 —— 实测同一网关 `glm-5.3` 与 `glm-5.3-flash` 成本差 40 倍以上。
- 插入新节点后池里旧节点**不要删**，留在池中即可；删了 owner 就没法从 `/model` 面板手动回切。
脚本走真实 `summarize_messages` + 只读 SQLite 恢复失败窗口，patch 掉 `admit/finish/attempt/circuit` 避免污染生产计数，不发 TG。断言 `ok=true`、`source_links>0`、`folding_cards>=2`。fallback 模式注入主节点 503 验证第二跳真实落地。

**别再用合成发言验收**：重复构造的假数据 16.7s 就能成功，而真实群聊失败——合成数据的话题密度和长度分布完全不同，通过它不代表线上可用。

### 历史坑（2026-11-06 教训）

- **报错里永远是末位节点名**：`总结生成失败：周三 请求超时` 实际是第一个节点打满预算。别看到周三就去查周三。
- 只加超时不解决空正文：22.8s 有 33s 预算仍空，因为 `max_tokens=2500` 被思考吃光。超时和输出预算是两个独立问题。
- 同一套群霸配置只在一个会话改；发现并发改动先取证（`ls -l --time-style` + `journalctl` 抓 PWD），不要覆盖另一个会话的正确改动。

### 验收：必须证明 fallback 真会落下去

只看 `load_ai_nodes()` 顺序正确**不算验收**（顺序对但 key 缺失、熔断、参数不兼容都可能实际跳过）。用 `toggle_node_enabled()` 临时摘掉主节点，跑真实 `ask_ai()`，再恢复：

```python
from services import ai_service
before = [n["id"] for n in ai_service.get_active_chain(BOT)]
ai_service.toggle_node_enabled("antigravity_gemini", BOT)   # 摘掉主节点
answer, _ = await ai_service.ask_ai("只回复两个字：在线", user_name="探针", chat_id=-100xxx)
ai_service.toggle_node_enabled("antigravity_gemini", BOT)   # finally 里恢复
assert [n["id"] for n in ai_service.get_active_chain(BOT)] == before
```

## antigravity 上游并发上限 = 2，超了是挂起不是拒绝（2026-11-04 实测）

群霸日志里 `node=antigravity_gemini outcome=timed_out node_elapsed_s≈33.4` 那批**不是网络问题**。
逐层排除 + 对照实验（naye 本机，全部实测）：

| 假设 | 结果 |
|---|---|
| TLS/网络层 | `curl` 打 `daily-cloudcode-pa.googleapis.com` ×6 全 40ms，404 正常 |
| IPv6 黑洞 | naye 无全局 IPv6 地址也无默认路由，`curl -6` 直接 ENETUNREACH，不参与 |
| `max_tokens` 过大 | 1500/2500/4000/8000 全 200 |
| prompt 过长 | 3.3 万字、4 万字全 200 |
| 模型名错误 | 会返回 400 `model_not_found`，与超时不同 |

真正的变量是**并发数**，重复 3 轮取稳定值：

| 并发 | 结果 |
|---|---|
| 2 | 6/6 全过（每轮 2/2 × 3） |
| 3 | 8/9（偶发挂 1 个） |
| 4 | 9/12（**每轮恰好挂 1 个**，35s 无响应） |
| 8 | 6/8（2 个挂 60s） |
| **对照 `cpa_gpt6_luna` 并发 8** | **8/8，全在 1.2s 内** |

对照组是关键：同一台机、同一个 CPA、同一时刻，GPT-6 通道 8 并发全过 → 排除 CPA 与网络，是 antigravity 上游的硬并发槽位。

**超限时上游不返回 429，而是把连接挂住**，客户端只能干等到 `node_timeout`（群霸是 30–33s）才放弃 —— 这就是那批 `timed_out` 的来源。

### 修法：per-node 并发闸门 + 快速跳过

`services/ai_service.py` 已加 `_NODE_CONCURRENCY_LIMITS` / `_node_gate()`：

- 闸门在**熔断检查之后、`used_attempts += 1` 之前**获取，拿不到就 `continue` 到下一节点，**不消耗 attempt、不计节点失败**（上游没被请求，不该背锅）。
- `_NODE_GATE_WAIT = 1.5s`：等 1.5 秒拿不到槽位立刻降级，比排队 33 秒划算。
- `finally` 里 `if gate is not None and gate_held: gate.release()` —— 必须带 `gate is not None`，否则 Pyright 报 `Optional` 访问。
- **群霸是两个独立进程**（`lemon-group-bot` / `-bot2`），进程内 `Semaphore` 不跨进程计数，所以**每进程限 1 → 合计 2**，正好压在安全线上。别照抄成 2，那样实际是 4 并发。

效果实测（并发 3，链 = antigravity → GPT-6）：

```
LLM candidate skipped: node concurrency gate busy node=antigravity_gemini waited=1.50s
LLM candidate skipped: node concurrency gate busy node=antigravity_gemini waited=1.50s
并发3: 3/3 成功, 各耗时 [4.29, 2.86, 2.89], 总 4.29s
gate_locked: False
```

改动前同样的并发至少 1 个挂满 33 秒。闸门连续 4 轮串行后 `gate_locked=False`，无泄漏。

### 顺带：4xx 必须记 body

原来只有 `logger.warning("LLM request failed: HTTP %s (node=%s)")`，只有状态码，排查时无法区分「参数被拒」「model_not_found」「上游风控」，只能靠猜。现在非 200 会记 `body=` 前 400 字符。

验证方式：故意把 `model` 改成不存在的名字跑一次，应看到

```
LLM request failed: HTTP 400 (node=antigravity_gemini) body={"error":{"message":"unknown provider for model ...","code":"model_not_found","param":"model"}}
```

### 判读要点

- `outcome=timed_out` + `node_elapsed_s≈node_budget_s` → 上游挂起，查并发
- `outcome=failed` + `http_status=400` + `node_elapsed_s<1s` → 上游快速拒绝，看 body
- 两者都**不等于**用户侧失败：fallback 兜住后 `LLM 实际使用节点:` 会显示真实落点，先查那行再下结论

**通过标志**：日志出现 `LLM 实际使用节点: <新节点名> (...); fallback_index=0` —— 摘掉主节点后新节点变成第 0 位，说明它是链上真正被调用的那个。恢复后必须断言链与 `before` 完全一致，否则会把生产主节点永久关掉。

跑法固定用 `bash /tmp/run_bot2.sh /tmp/xxx.py`（内含取 token 的 export + 项目 `.venv/bin/python3`），不要内联。

### 两个坑

- **`ask_ai()` 的第二个返回值不是节点名**（通常是 `None`），别拿它验收。真实节点只在 `LLM 实际使用节点:` 那行日志里，必须 `logging.basicConfig(level=logging.INFO)` 才打得出来。
- **推理模型给小 `max_tokens` 会返回空 content 但 HTTP 200**。`test_single_node()` 内部 `max_tokens=16`，Deepseek v4.1 Flash 这类会返回空正文 —— 判定可用看 `ok=True`，但验证「能出话」要自己用 ≥200 tokens 打一次。
- **JSON 调序与端点替换不默认重启**：以当前源码 `load_shared_endpoints()` / `load_bot_ai_config()` / `load_ai_nodes()` 的读取机制为准；2026-11-06 只读核实配置按调用重读，修改 `ai_endpoints.json` / `ai_bot_*.json` 可热生效。进程内熔断状态可能暂存，但不等于配置不热读；只有明确需要清理熔断、修改 Python 或启动环境且取得授权时才重启。不要以“重启最干净”为由扩大生产操作范围。

## `unable to open database file` 是 WAL 短连接竞态，不是数据损坏（2026-11-05 实测）

群霸日志里每天 100–200 条：

```
File "storage.py", line 10, in connect
  conn.execute('PRAGMA journal_mode=WAL')
sqlite3.OperationalError: unable to open database file
```

**不是磁盘满、不是权限、不是有人误删文件。** 实测 `df` 65%、inode 2%、8 个库 `integrity_check` 全 `ok`。

根因：`storage.py` 的 `connect()` 每次操作都新建连接、用完 `close()`。WAL 模式下最后一个连接关闭会 unlink `-wal`/`-shm`，而群霸1 + 群霸2 共用同一个 `data/` 目录，多进程并发时就存在竞态。

判据（缺一条别往这上面靠）：

- 报在 **`PRAGMA journal_mode=WAL`** 那一行，不是 `connect()` 本身
- **多个不同 PID 同时报**（单进程 bug 不会跨 PID）
- 集中在服务启动/停止前后几分钟，不是均匀铺满全天
- `PRAGMA integrity_check` 全部 `ok`
- 业务自愈，下一轮连接成功

### 关键误判：audit 里看到 DELETE `-wal`/`-shm` 不等于有人破坏

第一反应容易判成"有清理脚本在删 SQLite 文件"，核对 pid 后方向完全反：

```
syscall=87 (unlink) ... ppid=1 pid=293597 comm="python3"
```

`pid=293597` 就是群霸自己的 MainPID、`ppid=1` 是 systemd → **SQLite 正常关闭行为**。只看 `key="naye_data_delete"` 或 `comm="python3"` 不够，DB 所有者本身也是 python。**必须和 `systemctl show <svc> -p MainPID` 比对。**

### 处置

日志噪音、数据无损，可以不修。要压掉按代价排序：`connect()` 加退避重试（最省事，`OperationalError` 时 sleep 50–200ms 重试 2–3 次）→ 连接复用 → 每 DB 单进程写。

**不要**为了消日志把 `journal_mode` 改成 `DELETE`，那是拿并发能力换安静。

完整判读流程、验收脚本、以及停机窗口伴生噪音的分辨方法见 `error-digest-triage` 的 `references/service-restart-window-triage.md`。

## 巡检 `❌ 服务未运行` 紧跟 `✅ 已恢复` 是一次重启，不是两次故障

Owner 把两条告警截图圈起来问"这些都是啥"时，先对齐秒级时间再答。

实测：`14:59:58` 停止 → `14:59:59` 重启 → 巡检正好在这一秒取样 → `❌`；`15:01:44` 复检 → `✅`。**同一次重启的上下半段。**

判据三条同时看：

| 判据 | 读法 |
|---|---|
| `systemctl show <svc> -p ActiveEnterTimestamp` | 与 `❌` 时间差 <3 秒 → 取样落在重启窗口 |
| `-p NRestarts` | `0` → 不是崩溃重启；上千 → 无限重启循环（实测某 unit 1193 次，全是 `Failed to locate executable`，业务日志里一条报错都没有） |
| journal 有无 `Application is stopping` | 有 = 优雅停止；没有而进程没了 = OOM/段错误，查 `dmesg -T` |

报成两次故障会虚增故障数，也会让人去查不存在的"自愈机制"。

另：巡检按分钟取样，**只能证明取样那一刻**。真实停机时长要自己从 journal 算 `stop → 下次 start` 的间隔 —— 实测抓到过巡检全程未报的 **2 小时 44 分**空窗（`18:57:03` 停 → `21:41:04` 起），因为同期巡检恰好都落在已恢复的时点。这类窗口必须单独列进报告，不能因为"告警显示已恢复"就说没事。
