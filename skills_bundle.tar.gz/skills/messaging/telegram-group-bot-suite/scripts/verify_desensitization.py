#!/usr/bin/env python3
"""Fail-closed scan; private identifiers are loaded only from a private file.

Set DESENSITIZATION_PRIVATE_FILE to a 0600 JSON array outside the scanned tree.
No private denylist, matched value or source line is emitted to logs.
"""
import argparse
import ipaddress
import json
import os
from pathlib import Path
import re
import stat
import sys

def load_private_values(filename,target):
    path=Path(filename).expanduser()
    try:
        info=path.lstat()
        if not stat.S_ISREG(info.st_mode) or stat.S_IMODE(info.st_mode)&0o077:
            raise ValueError('private policy must be a regular 0600 file')
        if path.resolve().is_relative_to(target.resolve()):
            raise ValueError('private policy must be outside the exported tree')
        values=json.loads(path.read_text(encoding='utf-8'))
        if not isinstance(values,list) or any(not isinstance(v,str) or len(v)<3 for v in values):
            raise ValueError('invalid private policy')
        return tuple(values)
    except (OSError,ValueError):
        raise ValueError('private identifier policy missing, unsafe or invalid') from None

def scan(target,values):
    findings=[]
    patterns={
        'group_id':re.compile(r'(?<![\w])-100\d{7,13}(?![\w])'),
        'user_id':re.compile(r'(?<![\w.-])\d{8,15}(?![\w.-])'),
        'phone':re.compile(r'(?<![\w])\+[1-9]\d(?:[ -]?\d){7,14}(?![\w])'),
        'bot_token':re.compile(r'(?<![\w])\d{7,12}:[\w-]{30,50}'),
        'ipv6':re.compile(r'(?<![\w:])(?:[0-9a-fA-F]{0,4}:){2,7}[0-9a-fA-F:.]{0,39}(?![\w:])'),
    }
    for root,dirs,files in os.walk(target,followlinks=False):
        if '.git' in dirs:
            findings.append({'path':str(Path(root)/'.git'),'type':'git_history'})
            dirs.remove('.git')
        for name in files:
            p=Path(root)/name
            if p.is_symlink():
                findings.append({'path':str(p),'type':'symlink'});continue
            try:text=p.read_text(encoding='utf-8')
            except (OSError,UnicodeError):
                findings.append({'path':str(p),'type':'unreadable_file'});continue
            for value in values:
                if value.casefold() in text.casefold():findings.append({'path':str(p),'type':'private_identifier'})
            for kind,pattern in patterns.items():
                for m in pattern.finditer(text):
                    if kind=='ipv6':
                        try:a=ipaddress.ip_address(m.group())
                        except ValueError:continue
                        if a.is_loopback or a.is_unspecified or a in ipaddress.ip_network('2001:db8::/32'):continue
                    findings.append({'path':str(p),'line':text.count('\n',0,m.start())+1,'type':kind})
    return findings

def main():
    parser=argparse.ArgumentParser();parser.add_argument('target',type=Path)
    parser.add_argument('--private-file',default=os.environ.get('DESENSITIZATION_PRIVATE_FILE',''))
    args=parser.parse_args()
    try:
        if not args.target.is_dir() or not args.private_file:raise ValueError('target and private policy required')
        values=load_private_values(args.private_file,args.target)
        findings=scan(args.target,values)
        print(json.dumps({'status':'FAILED' if findings else 'SUCCESS','findings':findings},ensure_ascii=False))
        return int(bool(findings))
    except ValueError as error:
        print('FAILED: '+str(error),file=sys.stderr);return 2

if __name__=='__main__':sys.exit(main())
