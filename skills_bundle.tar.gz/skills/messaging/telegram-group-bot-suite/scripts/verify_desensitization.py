#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
代码与配置脱敏 4 级静态安全扫描探针
用法: python3 verify_desensitization.py <target_dir>
"""

import os
import sys
import re

DEFAULT_SENSITIVE_KEYWORDS = [
    # 填入需要重点拦截的私人 ID、特定域名、手机号、别名等
    "<YOUR_TELEGRAM_ID>", "8723257160", "8712228275", "8903499998",
    "18002619969", "586934.xyz", "fd.586934.xyz", "yd-fd.586934.xyz",
    "yecaodi", "qunba", "45.196.236.222", "198.44.46.38"
]

def scan_directory(target_dir: str):
    if not os.path.isdir(target_dir):
        print(f"❌ 目录不存在: {target_dir}")
        sys.exit(1)

    print(f"🔍 正在对目录进行 4 级静态安全脱敏扫描: {target_dir}")
    violations = []

    # 1. 隐藏版本库扫描
    for root, dirs, files in os.walk(target_dir):
        if ".git" in dirs:
            violations.append(f"[严重安全风险] 发现 .git 目录: {os.path.join(root, '.git')} (历史 commit 可能包含敏感凭据)")

    # 正则表达式定义
    ip_pattern = re.compile(r"\b(?!(?:127\.0\.0\.1|0\.0\.0\.0))\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b")
    token_pattern = re.compile(r"\b\d{8,11}:[a-zA-Z0-9_-]{30,}\b")

    # 2. 全文件逐行深度扫描
    for root, dirs, files in os.walk(target_dir):
        if ".git" in root:
            continue
        for f in files:
            fpath = os.path.join(root, f)
            try:
                with open(fpath, "r", encoding="utf-8", errors="ignore") as fp:
                    for idx, line in enumerate(fp, 1):
                        line_lower = line.lower()
                        # 检查特定关键词
                        for kw in DEFAULT_SENSITIVE_KEYWORDS:
                            if kw.lower() in line_lower:
                                violations.append(f"[{fpath}:{idx}] 命中敏感关键词: '{kw}' -> {line.strip()[:100]}")
                        # 检查非本地公网 IP
                        m_ip = ip_pattern.search(line)
                        if m_ip:
                            violations.append(f"[{fpath}:{idx}] 命中真实公网 IP: '{m_ip.group(0)}' -> {line.strip()[:100]}")
                        # 检查 Telegram Bot Token
                        m_token = token_pattern.search(line)
                        if m_token:
                            violations.append(f"[{fpath}:{idx}] 命中疑似真实 Bot Token: '{m_token.group(0)}'")
                        # 检查包含绝对开发宿主路径
                        if "/home/ubuntu" in line or "/root/" in line:
                            violations.append(f"[{fpath}:{idx}] 包含宿主绝对路径: {line.strip()[:100]}")
            except Exception as e:
                print(f"⚠️ 读取文件失败 {fpath}: {e}")

    print("\n" + "=" * 50)
    if violations:
        print(f"❌ 扫描未通过！共发现 {len(violations)} 项潜在泄漏风险：")
        for v in violations:
            print(f"  • {v}")
        sys.exit(1)
    else:
        print("✅ 扫描全部通过！未发现任何个人标识、Token、真实 IP 或系统绝对路径。")
        print("=" * 50)

if __name__ == "__main__":
    scan_path = sys.argv[1] if len(sys.argv) > 1 else "."
    scan_directory(scan_path)
