#!/usr/bin/env python3
"""群霸总结端到端验收：用真实群历史跑一次生产总结函数，不打扰群。

    cd /home/ubuntu/lemon-group-bot
    .venv/bin/python <skill_dir>/scripts/verify_summary_chain.py --chat 0 --limit 80

通过判据：ERR=None、LEN>300、正文含 <details> 与 t.me 来源链接、耗时 <75s。
"""
import argparse
import asyncio
import sys
import time
from pathlib import Path

BOT_DIR = Path("/home/ubuntu/lemon-group-bot")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--chat", type=int, required=True)
    parser.add_argument("--limit", type=int, default=80)
    parser.add_argument("--title", default="群聊")
    parser.add_argument("--user-id", type=int, default=<YOUR_TELEGRAM_ID>)
    parser.add_argument("--show", type=int, default=0, help="额外打印正文前 N 字符")
    args = parser.parse_args()

    sys.path.insert(0, str(BOT_DIR))
    from database import get_recent_messages
    from services.ai_service import summarize_messages

    messages = get_recent_messages(args.chat, limit=args.limit)
    print(f"samples={len(messages)} limit={args.limit}")
    if len(messages) < 3:
        print("FAIL: 样本不足 3 条")
        return 1

    async def run():
        started = time.monotonic()
        html, err = await summarize_messages(
            args.chat, args.title, f"最近{args.limit}条", messages, user_id=args.user_id
        )
        return html, err, time.monotonic() - started

    html, err, elapsed = asyncio.run(run())
    length = len(html) if html else 0
    checks = {
        "ERR=None": err is None,
        "LEN>300": length > 300,
        "含<details>": bool(html and "<details>" in html),
        "含来源链接": bool(html and "t.me/" in html),
        "耗时<75s": elapsed < 75.0,
    }
    print(f"elapsed={elapsed:.1f}s len={length} err={err}")
    for name, ok in checks.items():
        print(("  PASS " if ok else "  FAIL ") + name)
    if args.show and html:
        print("\n--- 正文前 %d 字符 ---\n%s" % (args.show, html[:args.show]))
    return 0 if all(checks.values()) else 2


if __name__ == "__main__":
    sys.exit(main())
