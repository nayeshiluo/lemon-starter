#!/usr/bin/env python3
"""
群霸 Bot 残留受限成员体检/自愈脚本 (audit_restricted_members.py)

背景：Telegram 限时禁言（restrictChatMember + until_date）到期后**不会自动恢复权限**，
成员停留在 ChatMemberStatus.RESTRICTED + until_date=epoch 0 (1970-01-01)，权限仍全 False，
群友体感「禁言又触发」。唯一解除手段是显式 restrict_chat_member(permissions=ChatPermissions.all_permissions())。

Bot API 无法枚举群成员，因此待检名单取自 bot.db 的 messages 表（按 chat_id 去重活跃用户 ID），
可用 --days 限制最近活跃窗口，可用 --fix 自动修复。

用法（务必在 /home/ubuntu/lemon-group-bot 目录、使用该项目 venv 运行，以便 import config）：
    cd /home/ubuntu/lemon-group-bot
    .venv/bin/python3 <本脚本> -c -1003855449276              # 只体检（只读）
    .venv/bin/python3 <本脚本> -c -1003855449276 --fix        # 体检并自动修复残留受限
    .venv/bin/python3 <本脚本> -c -1003855449276 --days 7     # 只扫最近 7 天活跃成员
    .venv/bin/python3 <本脚本> -c -1003855449276 --extra 7147964726,6245931101   # 追加手工名单

成功判据：修复后 get_chat_member 状态必须翻转 restricted -> member、until_date -> None。
"""
import argparse
import asyncio
import sqlite3
import sys
import time
from pathlib import Path

PROJECT_DIR = Path("/home/ubuntu/lemon-group-bot")
DB_PATH = PROJECT_DIR / "data" / "bot.db"

EPOCH0 = (1970, 1, 1)  # until_date 显示 1970-01-01 即 epoch 0 永久残留


def load_active_user_ids(chat_id: int, days: int) -> list[int]:
    """从 bot.db messages 表按 chat_id 取最近 days 天活跃的 DISTINCT user_id。"""
    since = time.time() - days * 86400
    conn = sqlite3.connect(f"file:{DB_PATH}?mode=ro", uri=True)
    rows = conn.execute(
        "SELECT DISTINCT user_id FROM messages WHERE chat_id=? AND created_at>=? AND user_id NOT IN (0, 777000)",
        (chat_id, since),
    ).fetchall()
    conn.close()
    return [r[0] for r in rows if r[0]]


async def audit(chat_id: int, user_ids: list[int], fix: bool) -> int:
    sys.path.insert(0, str(PROJECT_DIR))
    from config import BOT_TOKEN  # noqa: E402
    from telegram import Bot, ChatPermissions  # noqa: E402

    bot = Bot(BOT_TOKEN)
    residual, errors = [], 0
    for uid in user_ids:
        try:
            m = await bot.get_chat_member(chat_id, uid)
        except Exception as e:
            print(f"  {uid}: 查询失败 {e}")
            errors += 1
            continue
        until = getattr(m, "until_date", None)
        name = (m.user.full_name or m.user.first_name or "?")[:20]
        # 残留受限判定：status=restricted 且 until_date 为 epoch 0（1970-01-01）
        is_residual = str(m.status) == "restricted" and (
            until is None or until.year == EPOCH0[0] and until.month == EPOCH0[1] and until.day == EPOCH0[2]
        )
        tag = ""
        if is_residual:
            residual.append(uid)
            tag = "  <<< 残留受限"
            if fix:
                ok = await bot.restrict_chat_member(
                    chat_id=chat_id,
                    user_id=uid,
                    permissions=ChatPermissions.all_permissions(),
                )
                m2 = await bot.get_chat_member(chat_id, uid)
                tag = f"  <<< 修复-> {m2.status} / {getattr(m2, 'until_date', None)} (ok={ok})"
        print(f"{uid} {name:<22} {m.status:<12} until={until}{tag}")

    print(f"\n待检 {len(user_ids)} 人 | 残留受限 {len(residual)} 人 | 查询失败 {errors} 次")
    if residual and not fix:
        print("提示：加 --fix 可自动用 ChatPermissions.all_permissions() 修复上述残留成员。")
    return len(residual)


def main():
    ap = argparse.ArgumentParser(description="群霸残留受限成员体检/自愈")
    ap.add_argument("-c", "--chat", required=True, type=int, help="群组 chat_id（如 -1003855449276）")
    ap.add_argument("--days", type=int, default=30, help="活跃窗口天数（默认 30）")
    ap.add_argument("--extra", default="", help="额外补充的 user_id 列表，逗号分隔")
    ap.add_argument("--fix", action="store_true", help="自动修复残留受限成员")
    args = ap.parse_args()

    uids = load_active_user_ids(args.chat, args.days)
    if args.extra:
        uids += [int(x) for x in args.extra.split(",") if x.strip()]
    uids = list(dict.fromkeys(uids))  # 去重保序
    if not uids:
        print("待检名单为空：该群最近活跃窗口内没有数据库消息记录。可加 --extra 手工补充名单。")
        return 1
    print(f"群 {args.chat} | 最近 {args.days} 天活跃成员 {len(uids)} 人 | fix={args.fix}\n")
    asyncio.run(audit(args.chat, uids, args.fix))
    return 0


if __name__ == "__main__":
    sys.exit(main())