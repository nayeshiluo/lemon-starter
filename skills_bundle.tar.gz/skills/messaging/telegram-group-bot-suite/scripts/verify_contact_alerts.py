#!/usr/bin/env python3
"""验证 PTB Bot 的 Owner 联系提醒（被拉进群 / 陌生人私聊）是否真能投递。

用真实 Bot Token 构造假 update 直接调用线上 handler：走的是线上同一份格式化与
sendMessage，只是更新不是 Telegram 推来的（避免为测试另开 UserBot 会话）。

用法（必须用目标项目的 venv python，需能 import telegram）：
    TELEGRAM_BOT_TOKEN=<token> \
      /home/ubuntu/lemon-group-bot/.venv/bin/python \
      verify_contact_alerts.py --project /home/ubuntu/lemon-group-bot \
                              --module services.contact_alerts

双 Bot 取第二个 token（不要 echo 到终端）：
    TOKEN=$(sudo -n systemctl show lemon-group-bot2 -p Environment \
            | tr ' ' '\n' | grep '^TELEGRAM_BOT_TOKEN=' | cut -d= -f2)

提示：脚本会给 Owner 发 2 条【功能验证】消息，属预期。
"""
import argparse
import asyncio
import os
import sys
from types import SimpleNamespace

FAKE_ID = 0


def build_updates():
    fake_user = SimpleNamespace(id=FAKE_ID, is_bot=False, full_name="测试陌生人", username="test_stranger")
    dm_msg = SimpleNamespace(text="【功能验证】测试私聊，用于确认联系提醒能送达", caption=None)
    update_dm = SimpleNamespace(effective_message=dm_msg, effective_user=fake_user)
    change = SimpleNamespace(
        chat=SimpleNamespace(id=0, type="supergroup", title="测试群·联系提醒验证"),
        old_chat_member=SimpleNamespace(status="left"),
        new_chat_member=SimpleNamespace(status="member"),
        from_user=SimpleNamespace(id=FAKE_ID, full_name="测试邀请人", username="test_inviter"),
    )
    return update_dm, SimpleNamespace(my_chat_member=change)


async def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--project", required=True, help="项目根目录（插入 sys.path）")
    parser.add_argument("--module", default="services.contact_alerts",
                        help="导出 alert_private_message / alert_my_chat_member 的模块")
    args = parser.parse_args()

    token = os.environ.get("TELEGRAM_BOT_TOKEN", "").strip()
    if not token:
        raise SystemExit("需要 TELEGRAM_BOT_TOKEN 环境变量（可取自 systemd Environment）")

    sys.path.insert(0, args.project)
    from telegram import Bot  # noqa: E402

    mod = __import__(args.module, fromlist=["alert_private_message", "alert_my_chat_member"])
    update_dm, update_mm = build_updates()

    async with Bot(token) as bot:
        ctx = SimpleNamespace(bot=bot)
        if hasattr(mod, "alert_private_message"):
            await mod.alert_private_message(update_dm, ctx)
        if hasattr(mod, "alert_my_chat_member"):
            await mod.alert_my_chat_member(update_mm, ctx)

    print("test alerts sent by bot", token.split(":")[0])


if __name__ == "__main__":
    asyncio.run(main())
