#!/usr/bin/env python3
"""群霸 AI 调用链一键体检：生效链路 / 候选窗口 / 各节点实时延迟。

只读，不改任何配置，不输出密钥。用法：

    cd /home/ubuntu/lemon-group-bot
    .venv/bin/python <skill_dir>/scripts/probe_ai_chain.py            # 两个 Bot 都查
    .venv/bin/python <skill_dir>/scripts/probe_ai_chain.py --bot 0
    .venv/bin/python <skill_dir>/scripts/probe_ai_chain.py --no-ping  # 只看链路不测活
"""
import argparse
import json
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path

BOT_DIR = Path("/home/ubuntu/lemon-group-bot")
DATA = BOT_DIR / "data"


def load_endpoints():
    return json.loads((DATA / "ai_endpoints.json").read_text(encoding="utf-8"))


def read_env_val(key):
    import os
    if os.getenv(key):
        return os.getenv(key)
    try:
        for line in Path("/home/ubuntu/.hermes/.env").read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if line.startswith(f"{key}="):
                return line.split("=", 1)[1].strip("\"'")
    except OSError:
        pass
    return ""


def resolve_key(node):
    key = node.get("key") or ""
    if not key and node.get("key_env"):
        key = read_env_val(node["key_env"])
    return key


def active_chain(bot_id):
    endpoints = load_endpoints()
    cfg = json.loads((DATA / f"ai_bot_{bot_id}.json").read_text(encoding="utf-8"))
    disabled = set(cfg.get("disabled_nodes", []))
    chain = []
    for node_id in cfg.get("order", []):
        node = endpoints.get(node_id)
        if not node:
            continue
        key = resolve_key(node)
        if node_id in disabled or not key or not node.get("url"):
            continue
        chain.append({
            "id": node_id,
            "name": node.get("name", node_id),
            "url": node.get("url", ""),
            "model": (cfg.get("model_overrides") or {}).get(node_id) or node.get("default_model", ""),
            "key": key,
        })
    return chain


def probe(node, timeout=20.0):
    body = json.dumps({
        "model": node["model"],
        "messages": [{"role": "user", "content": "ping"}],
        "max_tokens": 5,
    }).encode()
    req = urllib.request.Request(
        node["url"], data=body,
        headers={
            "Authorization": f"Bearer {node['key']}",
            "Content-Type": "application/json",
            "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/126.0 Safari/537.36",
        },
    )
    started = time.monotonic()
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            resp.read(200)
            return f"OK {resp.status} {time.monotonic() - started:.1f}s"
    except urllib.error.HTTPError as exc:
        return f"HTTP {exc.code} {time.monotonic() - started:.1f}s"
    except Exception as exc:
        return f"{type(exc).__name__} {time.monotonic() - started:.1f}s"


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--bot", action="append", default=None)
    parser.add_argument("--no-ping", action="store_true")
    args = parser.parse_args()

    sys.path.insert(0, str(BOT_DIR))
    from services.ai_limits import MAX_CHAIN_ATTEMPTS  # noqa: E402
    try:
        from services.ai_service import get_node_timeout
    except Exception:
        get_node_timeout = None

    bots = args.bot or [p.stem.replace("ai_bot_", "") for p in sorted(DATA.glob("ai_bot_*.json"))]
    for bot_id in bots:
        chain = active_chain(bot_id)
        print(f"\n=== bot {bot_id} | 生效节点 {len(chain)} | 候选窗口 {MAX_CHAIN_ATTEMPTS} ===")
        for idx, node in enumerate(chain):
            window = "候选" if idx < MAX_CHAIN_ATTEMPTS else "窗口外"
            budget = ""
            if get_node_timeout:
                budget = f" large_t={get_node_timeout(node['id'], True)}s"
            status = "" if args.no_ping else " | " + probe(node)
            print(f"  {idx} [{window}] {node['id']:24s} {node['model']:24s}{budget}{status}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
