/**
 * Cloudflare Worker - Serverless Telegram 媒体/社区帖子解析机器人模版
 *
 * 核心特性：
 * 1. 纯 Serverless 架构，0 闲置服务器成本与 0 端口暴露；
 * 2. Telegram Webhook 原生异步处理（通过 ctx.waitUntil 立即 200 ACK，防止 Telegram 重试雪崩）；
 * 3. 兼容多层嵌套 Base64 加密信封（如海角社区 API 的 3 层 Base64 编码数据包）；
 * 4. 预览 M3U8 流媒体自动推导完整流候选（_preview / _i_preview 规则替换）；
 * 5. 严格 Markdown 转义与降级兜底机制。
 *
 * 环境变量绑定 (Worker Settings -> Variables):
 * - TG_BOT_TOKEN: Telegram 机器人 Token (推荐 secret_text)
 * - MEDIA_BASE_URL: 目标站可用 API 节点域名 (如 https://hjvideo58.com)
 * - MEDIA_AUTH_TOKEN: (可选) 会员账号 Token，用于需要权限的专属帖
 * - MEDIA_AUTH_UID: (可选) 会员账号 UID
 */

export default {
  async fetch(request, env, ctx) {
    if (request.method === "POST") {
      try {
        const update = await request.json();
        if (update.message) {
          ctx.waitUntil(handleMessage(update.message, env));
        }
      } catch (err) {
        console.error("Update processing error:", err);
      }
      return new Response("OK", { status: 200 });
    }

    return new Response("Media Parser Telegram Bot Worker is active.", {
      headers: { "content-type": "text/plain;charset=utf-8" },
    });
  },
};

// 3 层 Base64 解码器 (包含 URL-Safe Base64 规范化与 UTF-8 字节流解码)
function decodeTripleBase64(str) {
  let cur = String(str || "").trim();
  for (let i = 0; i < 3; i++) {
    try {
      let norm = cur.replace(/-/g, "+").replace(/_/g, "/");
      while (norm.length % 4 !== 0) norm += "=";
      const binary = atob(norm);
      const bytes = Uint8Array.from(binary, (c) => c.charCodeAt(0));
      cur = new TextDecoder("utf-8").decode(bytes);
    } catch (_) {
      break;
    }
  }
  return cur;
}

// 从文本或 URL 中提取目标 PID / 帖子 ID
function extractPid(text) {
  if (!text) return null;
  const matchParam = text.match(/(?:pid=|topic\/|topicId=)(\d+)/i);
  if (matchParam) return matchParam[1];
  const matchPureNum = text.trim().match(/^(\d{5,9})$/);
  if (matchPureNum) return matchPureNum[1];
  return null;
}

// 推导完整流候选 M3U8
function buildFullM3u8Candidates(previewUrl) {
  const candidates = [];
  try {
    const original = new URL(previewUrl);
    const rules = [
      [/_i_preview(?=\.m3u8$)/i, "_i"],
      [/_preview(?=\.m3u8$)/i, ""],
      [/-preview(?=\.m3u8$)/i, ""],
      [/\/preview(?=\.m3u8$)/i, "/index"],
    ];
    for (const [pattern, replacement] of rules) {
      const u = new URL(original.href);
      u.pathname = u.pathname.replace(pattern, replacement);
      if (u.href !== original.href && !candidates.includes(u.href)) {
        candidates.push(u.href);
      }
    }
  } catch (_) {}
  return candidates;
}

// 目标 API 请求与解码
async function fetchAndDecodeTopic(pid, env) {
  const baseUrl = (env.MEDIA_BASE_URL || "https://hjvideo58.com").replace(/\/+$/, "");
  const targetUrl = `${baseUrl}/api/topic/${pid}`;

  const headers = {
    "User-Agent": "Mozilla/5.0 (iPhone; CPU iPhone OS 16_6 like Mac OS X) AppleWebKit/605.1.15",
    "Accept": "application/json, text/plain, */*",
    "pcver": "2",
  };

  if (env.MEDIA_AUTH_TOKEN) headers["token"] = env.MEDIA_AUTH_TOKEN;
  if (env.MEDIA_AUTH_UID) headers["uid"] = env.MEDIA_AUTH_UID;

  const res = await fetch(targetUrl, { headers });
  if (!res.ok) {
    throw new Error(`上游接口响应异常 (HTTP ${res.status})`);
  }

  const json = await res.json();
  let rawData = json.data;

  if (typeof rawData === "string") {
    const decodedText = decodeTripleBase64(rawData);
    try {
      rawData = JSON.parse(decodedText);
    } catch {
      throw new Error("响应体多层 Base64 解码后非有效 JSON");
    }
  }

  if (!rawData || typeof rawData !== "object") {
    throw new Error("上游未返回有效帖子详情数据");
  }

  const title = rawData.title || rawData.subject || "无标题";
  const author = rawData.user ? (rawData.user.nickname || rawData.user.name) : "未知作者";
  const attachments = Array.isArray(rawData.attachments) ? rawData.attachments : [];

  const streams = [];
  for (const att of attachments) {
    const cat = String(att.category || att.type || "").toLowerCase();
    const isVideo = cat.includes("video") || (att.remoteUrl && att.remoteUrl.includes(".m3u8"));
    if (isVideo && att.remoteUrl) {
      const fullCandidates = buildFullM3u8Candidates(att.remoteUrl);
      streams.push({
        id: att.id,
        duration: att.video_time_length || att.videoTimeLength || 0,
        originalUrl: att.remoteUrl,
        fullCandidates,
      });
    }
  }

  return { pid, title, author, streams };
}

// Telegram 消息逻辑路由
async function handleMessage(msg, env) {
  const chatId = msg.chat.id;
  const text = msg.text || "";

  if (text === "/start" || text === "/help") {
    await sendTgMessage(
      env.TG_BOT_TOKEN,
      chatId,
      `*媒体/帖子流解析机器人已就绪* 🎬\n\n直接发送：\n• 目标帖子 URL（带 \`pid=12345\`）\n• 或直接输入纯数字 \`PID\`\n\n机器人将自动解密提取视频标题、作者及完整 M3U8 直链。`
    );
    return;
  }

  const pid = extractPid(text);
  if (!pid) return;

  await sendTgMessage(env.TG_BOT_TOKEN, chatId, `🔍 正在检索并解析帖子 PID: \`${pid}\`...`);

  try {
    const result = await fetchAndDecodeTopic(pid, env);

    let reply = `🎬 *${escapeTg(result.title)}*\n`;
    reply += `👤 作者: \`${escapeTg(result.author)}\`\n`;
    reply += `🆔 帖子 PID: \`${result.pid}\`\n\n`;

    if (result.streams.length === 0) {
      reply += `⚠️ *未检测到视频流附件*（可能是纯图文帖或需购买查看）。`;
    } else {
      reply += `📹 *检测到 ${result.streams.length} 条音视频轨道：*\n\n`;
      result.streams.forEach((s, idx) => {
        const dur = s.duration ? `${Math.floor(s.duration / 60)}分${s.duration % 60}秒` : "未知";
        reply += `*【视频流 ${idx + 1}】* (时长: ${dur})\n`;
        if (s.fullCandidates.length > 0) {
          reply += `✨ *完整流候选 (突破预览):*\n\`${s.fullCandidates[0]}\`\n`;
        }
        reply += `🔗 *原始下发流:*\n\`${s.originalUrl}\`\n\n`;
      });
      reply += `💡 *播放提示*：可直接复制上方 \`.m3u8\` 地址导入 PotPlayer / VLC / SenPlayer 播放。`;
    }

    await sendTgMessage(env.TG_BOT_TOKEN, chatId, reply);
  } catch (err) {
    await sendTgMessage(
      env.TG_BOT_TOKEN,
      chatId,
      `❌ *解析失败*：${escapeTg(err.message || String(err))}\n可能当前节点需要刷新分流域名或需配置有效 Token。`
    );
  }
}

// Telegram Markdown 安全转义
function escapeTg(str) {
  if (!str) return "";
  return str.replace(/([_*[\]()~`>#+\-=|{}.!])/g, "\\$1");
}

// 向 Telegram Bot API 发送消息
async function sendTgMessage(token, chatId, text) {
  const url = `https://api.telegram.org/bot${token}/sendMessage`;
  try {
    await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        chat_id: chatId,
        text,
        parse_mode: "Markdown",
        disable_web_page_preview: true,
      }),
    });
  } catch (err) {
    console.error("sendTgMessage error:", err);
  }
}
