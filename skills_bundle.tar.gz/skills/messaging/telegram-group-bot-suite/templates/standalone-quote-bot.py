#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Telegram Q 图名言贴纸机器人 (Standalone Template)
=====================================================
开箱即用独立部署模板，支持环境变量配置与一键运行。
"""

import os
import re
import io
import time
import html
import base64
import logging
import asyncio
import subprocess
from typing import Optional, List, Dict, Any, Tuple

import aiohttp
from PIL import Image
from telegram import (
    Update,
    Bot,
    InputSticker,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
)
from telegram.constants import ParseMode, ChatMemberStatus
from telegram.ext import (
    Application,
    CommandHandler,
    MessageHandler,
    ContextTypes,
    filters,
)

# ==================== 基础配置 ====================
BOT_TOKEN = os.getenv("BOT_TOKEN", "YOUR_BOT_TOKEN_HERE")
OWNER_ID = int(os.getenv("OWNER_ID", "0"))
QUOTE_API_URL = os.getenv("QUOTE_API_URL", "http://127.0.0.1:4888/generate.webp")
DEFAULT_BG_COLOR = os.getenv("DEFAULT_BG_COLOR", "#000000")
ALLOW_ALL_QS = os.getenv("ALLOW_ALL_QS", "false").lower() in ("true", "1", "yes")

MAX_STICKERS_PER_PACK = 120
QUOTE_PATTERN = re.compile(
    r"^[/,\\.，。]?(q|qh|qs|qhs|qd)(?:@\w+)?(?:\s+(-?\d+))?$", re.IGNORECASE
)

logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO,
)
logger = logging.getLogger("QuoteBot")
USER_META_CACHE: Dict[int, Dict[str, Any]] = {}


async def delete_msg_safe(msg):
    try:
        await msg.delete()
    except Exception as e:
        logger.debug(f"Delete message failed: {e}")


async def send_temp_tip(bot: Bot, chat_id: int, text: str, delay: int = 5):
    try:
        m = await bot.send_message(chat_id=chat_id, text=text, parse_mode=ParseMode.HTML)
        await asyncio.sleep(delay)
        await m.delete()
    except Exception:
        pass


def serialize_ptb_entities(entities) -> list:
    if not entities:
        return []
    res = []
    for ent in entities:
        t = str(ent.type).lower().replace("messageentitytype.", "").replace("messageentity", "")
        obj = {"offset": ent.offset, "length": ent.length, "type": t}
        if t == "custom_emoji" and getattr(ent, "custom_emoji_id", None):
            obj["custom_emoji_id"] = str(ent.custom_emoji_id)
        elif t == "text_link" and getattr(ent, "url", None):
            obj["url"] = ent.url
        elif t == "pre" and getattr(ent, "language", None):
            obj["language"] = ent.language
        res.append(obj)
    return res


async def get_user_rich_metadata(
    bot: Bot, chat_id: int, user_id: int, reply_msg=None
) -> Tuple[Optional[dict], dict, Optional[str], Optional[int]]:
    tag_obj = None
    photo_obj = {}
    emoji_status_id = None
    color_id = None

    if not user_id:
        return None, photo_obj, emoji_status_id, color_id

    try:
        member = await bot.get_chat_member(chat_id, user_id)
        is_creator = member.status in ("creator", ChatMemberStatus.OWNER)
        is_admin = is_creator or (member.status == ChatMemberStatus.ADMINISTRATOR)

        msg_sender_tag = getattr(reply_msg, "sender_tag", None) if reply_msg else None
        msg_author_sig = getattr(reply_msg, "author_signature", None) if reply_msg else None
        custom_title = getattr(member, "custom_title", None) or msg_sender_tag or msg_author_sig

        if is_creator:
            tag_obj = {"text": custom_title or "群主", "isAdmin": True, "isCreator": True}
        elif is_admin:
            tag_obj = {"text": custom_title or "管理员", "isAdmin": True, "isCreator": False}
        elif custom_title:
            tag_obj = {"text": custom_title, "isAdmin": False, "isCreator": False}
    except Exception as e:
        logger.debug(f"get_chat_member error: {e}")
        msg_sender_tag = getattr(reply_msg, "sender_tag", None) if reply_msg else None
        if msg_sender_tag:
            tag_obj = {"text": msg_sender_tag, "isAdmin": False, "isCreator": False}

    now = time.time()
    cached = USER_META_CACHE.get(user_id)
    if cached and (now - cached["ts"] < 600):
        emoji_status_id = cached.get("emoji_status_id")
        color_id = cached.get("color_id")
        if cached.get("avatar_b64"):
            photo_obj = {"url": f"data:image/jpeg;base64,{cached['avatar_b64']}"}
        return tag_obj, photo_obj, emoji_status_id, color_id

    av_b64 = None
    current_avatar_file_id = None

    try:
        user_chat = await bot.get_chat(user_id)
        if getattr(user_chat, "emoji_status_custom_emoji_id", None):
            emoji_status_id = str(user_chat.emoji_status_custom_emoji_id)
        if getattr(user_chat, "accent_color_id", None) is not None:
            color_id = user_chat.accent_color_id
        if getattr(user_chat, "photo", None) and getattr(user_chat.photo, "big_file_id", None):
            current_avatar_file_id = user_chat.photo.big_file_id
    except Exception as ce:
        logger.debug(f"get_chat error for {user_id}: {ce}")

    if current_avatar_file_id:
        try:
            f = await bot.get_file(current_avatar_file_id)
            buf = io.BytesIO()
            await f.download_to_memory(buf)
            av_b64 = base64.b64encode(buf.getvalue()).decode("utf-8")
            photo_obj = {"url": f"data:image/jpeg;base64,{av_b64}"}
        except Exception as fe:
            logger.debug(f"download current avatar error: {fe}")

    if not av_b64:
        try:
            photos = await bot.get_user_profile_photos(user_id=user_id, limit=1)
            if photos.total_count > 0:
                f = await bot.get_file(photos.photos[0][-1].file_id)
                buf = io.BytesIO()
                await f.download_to_memory(buf)
                av_b64 = base64.b64encode(buf.getvalue()).decode("utf-8")
                photo_obj = {"url": f"data:image/jpeg;base64,{av_b64}"}
        except Exception as pe:
            logger.debug(f"get_user_profile_photos error: {pe}")

    USER_META_CACHE[user_id] = {
        "ts": now,
        "emoji_status_id": emoji_status_id,
        "color_id": color_id,
        "avatar_b64": av_b64,
    }

    return tag_obj, photo_obj, emoji_status_id, color_id


async def _file_id_to_data_uri(bot: Bot, file_id: str, max_side: int = 460) -> Optional[dict]:
    try:
        f = await bot.get_file(file_id)
        buf = io.BytesIO()
        await f.download_to_memory(buf)
        raw_bytes = buf.getvalue()

        img = None
        try:
            img = Image.open(io.BytesIO(raw_bytes))
            try:
                img.seek(0)
            except Exception:
                pass
        except Exception:
            try:
                p = subprocess.run(
                    ["ffmpeg", "-y", "-i", "pipe:0", "-vframes", "1", "-f", "image2", "-c:v", "png", "pipe:1"],
                    input=raw_bytes,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.DEVNULL,
                    timeout=5,
                )
                if p.returncode == 0 and p.stdout:
                    img = Image.open(io.BytesIO(p.stdout))
            except Exception as fe:
                logger.debug(f"ffmpeg frame extraction failed: {fe}")

        if not img:
            return None

        img = img.convert("RGBA")
        w, h = img.size
        if max(w, h) > max_side:
            scale = max_side / max(w, h)
            img = img.resize((max(1, int(w * scale)), max(1, int(h * scale))), Image.Resampling.LANCZOS)

        out = io.BytesIO()
        img.save(out, format="PNG")
        b64 = base64.b64encode(out.getvalue()).decode("utf-8")
        return {"url": f"data:image/png;base64,{b64}"}
    except Exception as e:
        logger.debug(f"_file_id_to_data_uri failed: {e}")
        return None


def resolve_media_file_id(message) -> Optional[str]:
    try:
        if getattr(message, "sticker", None):
            st = message.sticker
            thumb = getattr(st, "thumbnail", None) or getattr(st, "thumb", None)
            thumb_id = getattr(thumb, "file_id", None)
            if getattr(st, "is_animated", False) or getattr(st, "is_video", False):
                return thumb_id or st.file_id
            return st.file_id
        if getattr(message, "photo", None):
            return message.photo[-1].file_id
        if getattr(message, "animation", None):
            thumb = getattr(message.animation, "thumbnail", None)
            return getattr(thumb, "file_id", None) or message.animation.file_id
        if getattr(message, "video", None):
            thumb = getattr(message.video, "thumbnail", None)
            return getattr(thumb, "file_id", None) or message.video.file_id
    except Exception as e:
        logger.debug(f"resolve_media_file_id failed: {e}")
    return None


async def extract_media_preview(bot: Bot, message, max_side: int = 460) -> Tuple[Optional[dict], Optional[str], Optional[str]]:
    file_id = resolve_media_file_id(message)
    if not file_id:
        return None, None, None
    media = await _file_id_to_data_uri(bot, file_id, max_side)
    return media, ("photo" if media else None), file_id


async def generate_quote_webp(messages_payload: List[Dict[str, Any]], background_color: str = DEFAULT_BG_COLOR) -> Optional[bytes]:
    payload = {
        "backgroundColor": background_color,
        "type": "quote",
        "botToken": BOT_TOKEN,
        "messages": messages_payload,
    }
    try:
        async with aiohttp.ClientSession() as session:
            async with session.post(QUOTE_API_URL, json=payload, timeout=aiohttp.ClientTimeout(total=15)) as resp:
                if resp.status == 200:
                    return await resp.read()
                else:
                    err_text = await resp.text()
                    logger.error(f"Quote-API error ({resp.status}): {err_text}")
    except Exception as e:
        logger.error(f"Failed to generate quote webp: {e}")
    return None


async def add_to_group_sticker_pack(
    bot: Bot,
    chat_id: int,
    chat_title: str,
    webp_bytes: bytes,
    owner_user_id: int,
) -> Tuple[bool, str, Optional[str]]:
    me = await bot.get_me()
    clean_id = str(abs(chat_id)).replace("100", "", 1) if str(abs(chat_id)).startswith("100") else str(abs(chat_id))

    sticker_item = InputSticker(
        sticker=io.BytesIO(webp_bytes),
        emoji_list=["💬"],
        format="static",
    )

    for vol in range(1, 51):
        if vol == 1:
            pack_name = f"g_{clean_id}_by_{me.username}"
            pack_title = f"{chat_title[:20]} 的名言集"
        else:
            pack_name = f"g_{clean_id}_{vol}_by_{me.username}"
            pack_title = f"{chat_title[:16]} 名言集 Vol.{vol}"
        pack_url = f"https://t.me/addstickers/{pack_name}"

        try:
            s_set = await bot.get_sticker_set(name=pack_name)
            if len(s_set.stickers) >= MAX_STICKERS_PER_PACK:
                logger.info(f"Pack {pack_name} is full ({len(s_set.stickers)}/{MAX_STICKERS_PER_PACK}), checking next volume...")
                continue

            await bot.add_sticker_to_set(
                user_id=owner_user_id,
                name=pack_name,
                sticker=sticker_item,
            )
            file_id = None
            try:
                updated_set = await bot.get_sticker_set(name=pack_name)
                if updated_set.stickers:
                    file_id = updated_set.stickers[-1].file_id
            except Exception:
                pass
            return True, pack_url, file_id

        except Exception as e:
            err_msg = str(e).lower()
            if any(k in err_msg for k in ("stickerset_invalid", "set not found", "peer_id_invalid", "sticker set not found")):
                try:
                    await bot.create_new_sticker_set(
                        user_id=owner_user_id,
                        name=pack_name,
                        title=pack_title,
                        stickers=[sticker_item],
                    )
                    file_id = None
                    try:
                        new_set = await bot.get_sticker_set(name=pack_name)
                        if new_set.stickers:
                            file_id = new_set.stickers[-1].file_id
                    except Exception:
                        pass
                    return True, pack_url, file_id
                except Exception as create_err:
                    logger.error(f"Create sticker set (Vol.{vol}) failed: {create_err}")
                    if any(k in str(create_err).lower() for k in ("user not found", "bot was blocked", "can't access")):
                        return False, "NEED_PM_START", None
                    return False, str(create_err), None
            else:
                logger.error(f"Add sticker to set failed: {e}")
                return False, str(e), None

    return False, "ALL_VOLUMES_FULL", None


async def remove_sticker_from_pack(bot: Bot, sticker_file_id: str) -> Tuple[bool, str]:
    try:
        await bot.delete_sticker_from_set(sticker=sticker_file_id)
        return True, "SUCCESS"
    except Exception as e:
        err_msg = str(e).lower()
        logger.warning(f"delete_sticker_from_set error: {e}")
        if any(k in err_msg for k in ("wrong sticker file", "stickerset_invalid", "sticker not found")):
            return False, "NOT_BOT_STICKER"
        return False, str(e)


async def check_user_permission(bot: Bot, chat_id: int, user_id: int) -> bool:
    if ALLOW_ALL_QS:
        return True
    if user_id == OWNER_ID:
        return True
    try:
        member = await bot.get_chat_member(chat_id, user_id)
        return member.status in ("creator", ChatMemberStatus.OWNER, ChatMemberStatus.ADMINISTRATOR)
    except Exception:
        return False


async def handle_quote_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    msg = update.effective_message
    user = update.effective_user
    chat = update.effective_chat

    if not msg or not msg.text:
        return

    m = QUOTE_PATTERN.match(msg.text.strip())
    if not m:
        return

    cmd = m.group(1).lower()
    await delete_msg_safe(msg)

    if not msg.reply_to_message:
        await send_temp_tip(
            context.bot, chat.id,
            "⚠️ 制作名言贴纸时，请先<b>【长按/右键回复】</b>一条群友的消息再发 <code>q</code> 哦～"
        )
        return

    reply_target = msg.reply_to_message

    if cmd == "qd":
        has_perm = await check_user_permission(context.bot, chat.id, user.id)
        if not has_perm:
            await send_temp_tip(context.bot, chat.id, "⚠️ 仅群主或管理员可从贴纸包中删除贴图哦～", delay=5)
            return

        if not reply_target.sticker:
            await send_temp_tip(
                context.bot, chat.id,
                "⚠️ 请长按/右键回复想要删除的【贴纸消息】发送 <code>qd</code> 哦～",
                delay=5,
            )
            return

        st_file_id = reply_target.sticker.file_id
        ok, status = await remove_sticker_from_pack(context.bot, st_file_id)
        if ok:
            await delete_msg_safe(reply_target)
            chat_title = chat.title or "本群"
            await send_temp_tip(
                context.bot, chat.id,
                f"🗑️ <b>已成功将该贴图从【{html.escape(chat_title)}】名言集中彻底移除！</b>",
                delay=5,
            )
        else:
            tip = "⚠️ 该贴图不属于本 Bot 维护的群专属贴纸包，无法删除哦～" if status == "NOT_BOT_STICKER" else f"❌ 删除失败：{html.escape(status)}"
            await send_temp_tip(context.bot, chat.id, tip, delay=5)
        return

    if cmd in ("qs", "qhs"):
        has_perm = await check_user_permission(context.bot, chat.id, user.id)
        if not has_perm:
            await send_temp_tip(context.bot, chat.id, "⚠️ 仅群主或管理员可将内容收录至群贴纸包哦～", delay=5)
            return

    target_sender = reply_target.from_user
    target_user_id = target_sender.id if target_sender else 0

    is_partial_quote = bool(getattr(msg, "quote", None) and getattr(msg.quote, "text", None) and msg.quote.text.strip())
    if is_partial_quote:
        target_text = msg.quote.text.strip()
        target_entities = serialize_ptb_entities(getattr(msg.quote, "entities", None))
    else:
        target_text = reply_target.text or reply_target.caption or ""
        target_entities = serialize_ptb_entities(reply_target.entities or reply_target.caption_entities)

    target_media, target_media_type, _ = await extract_media_preview(context.bot, reply_target)
    if not target_media and not target_text:
        if reply_target.sticker:
            target_text = f"[贴纸 {reply_target.sticker.emoji}]" if getattr(reply_target.sticker, "emoji", None) else "[贴纸]"
        elif reply_target.photo:
            target_text = "[图片]"
        elif reply_target.video:
            target_text = "[视频]"
        elif reply_target.animation:
            target_text = "[GIF动图]"

    tag_obj, photo_obj, emoji_status_id, color_id = await get_user_rich_metadata(
        context.bot, chat.id, target_user_id, reply_msg=reply_target
    )

    from_obj = {
        "id": target_user_id,
        "name": target_sender.full_name if target_sender else "匿名群友",
    }
    if photo_obj:
        from_obj["photo"] = photo_obj
    if emoji_status_id:
        from_obj["emoji_status"] = emoji_status_id
    if color_id is not None:
        from_obj["color_id"] = color_id

    reply_obj = None
    if cmd.startswith("qh"):
        parent_msg = getattr(reply_target, "reply_to_message", None)
        if parent_msg:
            p_sender = parent_msg.from_user
            p_name = p_sender.full_name if p_sender else "群友"
            p_text = parent_msg.text or parent_msg.caption or ""
            if not p_text:
                if parent_msg.sticker:
                    p_text = f"[贴纸 {parent_msg.sticker.emoji}]" if getattr(parent_msg.sticker, "emoji", None) else "[贴纸]"
                elif parent_msg.photo:
                    p_text = "[图片]"
                elif parent_msg.video:
                    p_text = "[视频]"
                else:
                    p_text = "[媒体]"
            p_entities = serialize_ptb_entities(parent_msg.entities or parent_msg.caption_entities)
            reply_obj = {
                "name": p_name,
                "text": p_text,
                "chatId": p_sender.id if p_sender else 0,
            }
            if p_entities:
                reply_obj["entities"] = p_entities
            _, _, p_thumb_id = await extract_media_preview(context.bot, parent_msg, max_side=160)
            if p_thumb_id:
                reply_obj["media"] = {"fileId": p_thumb_id}

    msg_item = {
        "chatId": target_user_id,
        "text": target_text,
        "from": from_obj,
        "avatar": True,
    }
    if target_entities:
        msg_item["entities"] = target_entities
    if tag_obj:
        msg_item["senderTag"] = tag_obj
    if reply_obj:
        msg_item["replyMessage"] = reply_obj
    if target_media:
        msg_item["media"] = target_media
        if target_media_type:
            msg_item["mediaType"] = target_media_type

    msg_items = [msg_item]

    if cmd in ("qs", "qhs"):
        chat_title = chat.title or "本群"
        target_webp_bytes = None

        if reply_target.sticker:
            try:
                st = reply_target.sticker
                file_obj = await context.bot.get_file(st.file_id)
                buf = io.BytesIO()
                await file_obj.download_to_memory(buf)
                img = Image.open(io.BytesIO(buf.getvalue()))
                w, h = img.size
                if max(w, h) != 512:
                    scale = 512 / max(w, h)
                    img = img.resize((max(1, int(w * scale)), max(1, int(h * scale))), Image.Resampling.LANCZOS)
                out_buf = io.BytesIO()
                img.save(out_buf, format="WEBP")
                target_webp_bytes = out_buf.getvalue()
            except Exception as se:
                logger.error(f"Process sticker failed: {se}")

        elif reply_target.photo:
            try:
                ph = reply_target.photo[-1]
                file_obj = await context.bot.get_file(ph.file_id)
                buf = io.BytesIO()
                await file_obj.download_to_memory(buf)
                img = Image.open(io.BytesIO(buf.getvalue()))
                w, h = img.size
                scale = 512 / max(w, h)
                img = img.resize((max(1, int(w * scale)), max(1, int(h * scale))), Image.Resampling.LANCZOS)
                out_buf = io.BytesIO()
                img.save(out_buf, format="WEBP")
                target_webp_bytes = out_buf.getvalue()
            except Exception as pe:
                logger.error(f"Process photo failed: {pe}")

        if not target_webp_bytes:
            target_webp_bytes = await generate_quote_webp(msg_items)

        if not target_webp_bytes:
            await send_temp_tip(context.bot, chat.id, "❌ 名言贴纸渲染失败，请检查 quote-api 服务！", delay=5)
            return

        ok, res_url, _ = await add_to_group_sticker_pack(
            bot=context.bot,
            chat_id=chat.id,
            chat_title=chat_title,
            webp_bytes=target_webp_bytes,
            owner_user_id=OWNER_ID,
        )
        if ok:
            keyboard = InlineKeyboardMarkup([[
                InlineKeyboardButton(text="📦 查看/添加本群贴纸包 →", url=res_url)
            ]])
            await context.bot.send_message(
                chat_id=chat.id,
                text=(
                    f"✅ <b>已收录进【{html.escape(chat_title)}】名言集！</b>\n\n"
                    f"🔗 <b>贴纸包链接：</b>\n{res_url}"
                ),
                reply_markup=keyboard,
                parse_mode=ParseMode.HTML,
                disable_web_page_preview=False,
            )
        else:
            tip = (
                f"⚠️ 无法创建贴纸包：请 Owner (ID: <code>{OWNER_ID}</code>) 先在私聊中向 Bot 发送一次 <code>/start</code> 激活权限！"
                if res_url == "NEED_PM_START"
                else f"❌ 收录贴纸包失败：{html.escape(res_url)}"
            )
            await send_temp_tip(context.bot, chat.id, tip, delay=8)
    else:
        webp_bytes = await generate_quote_webp(msg_items)
        if not webp_bytes:
            logger.warning("Quote-API returned empty bytes")
            return
        await context.bot.send_sticker(chat_id=chat.id, sticker=io.BytesIO(webp_bytes))


async def handle_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = (
        "👋 <b>你好！我是 Telegram Q 图名言贴纸机器人</b>\n\n"
        "💡 <b>在群聊中的使用方法：</b>\n"
        "• <b><code>q</code></b> : 回复发言发 <code>q</code>，生成单张气泡贴纸\n"
        "• <b><code>qh</code></b> : 回复带引用的消息发 <code>qh</code>，带上级历史生成双层贴纸\n"
        "• <b><code>qs</code></b> : 回复消息/贴纸/图片发 <code>qs</code>，收录进群专属贴纸包\n"
        "• <b><code>qd</code></b> : 回复本群贴纸包中的贴纸发 <code>qd</code>，从贴纸包中删除\n\n"
        "⚙️ <i>提示：若要使用 <code>qs</code> 自动建包，Bot Owner 必须先在私聊与机器人对话一次！</i>"
    )
    await update.effective_message.reply_text(text, parse_mode=ParseMode.HTML)


def main():
    if BOT_TOKEN == "YOUR_BOT_TOKEN_HERE":
        print("❌ 请先设置环境变量 BOT_TOKEN！")
        return

    app = Application.builder().token(BOT_TOKEN).build()
    app.add_handler(CommandHandler("start", handle_start))
    app.add_handler(MessageHandler(filters.TEXT & (~filters.COMMAND), handle_quote_command))

    print("🚀 Quote Bot 正在运行中...")
    app.run_polling(drop_pending_updates=True)


if __name__ == "__main__":
    main()
