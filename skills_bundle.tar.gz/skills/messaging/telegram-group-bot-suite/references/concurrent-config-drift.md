# 并发 Hermes 会话改写群霸配置：取证与判定

2026-10-20 实测事件。价值不在“有人改了配置”，而在于**差点被误判为未授权入侵并回滚掉一个正确的改动**。

## 现象

排查另一个问题（异地备份）时顺手核对 `order`，发现与本人 13:07 写入的降级布局不一致：

```
13:07 本人写入：tengbaipiao, cpa_gpt6_luna, antigravity_gemini, cpa_gpt56_luna,
                antigravity_claude, sensenova_deepseek, newfou_gemini_lite
13:46 实际值：  tengbaipiao, cpa_gpt6_luna, cpa_gpt56_luna, newfou_gemini_lite,
                antigravity_claude, sensenova_deepseek, antigravity_gemini
```

同时 `ai_timeout_overrides.json` 从 2 个节点变成 7 个节点（除 gemini 12s 外全部 `large: 35.0`），双 Bot 服务在 13:46 重启过，而**没有任何新的 `.bak-*`**。表面上完全符合“未授权变更”的特征。

## 取证步骤（全部只读）

```bash
# 1) 精确改动时刻
ls -l --time-style=+%m-%d_%H:%M:%S \
  /home/ubuntu/lemon-group-bot/data/ai_bot_*.json \
  /home/ubuntu/lemon-group-bot/data/ai_timeout_overrides.json
# → 三个文件均为 13:46:18

# 2) 该时刻 ±2 分钟的完整日志，找 sudo 的 PWD
journalctl --since "13:46:00" --until "13:48:30" --no-pager | grep -E "sudo\[|systemd\[1\].*(Stop|Start|Deactiv)"
# → sudo[1103655]: ubuntu : PWD=/home/ubuntu/lemon-group-bot ;
#                  USER=root ; COMMAND=/usr/bin/systemctl restart lemon-group-bot.service lemon-group-bot2.service

# 3) 有几个 Hermes worker 在跑
ps -eo pid,lstart,cmd | grep hermes_bridge | grep -v grep
```

关键判据是 **sudo 记录的 `PWD` 字段**：它证明命令是在项目目录下发出的，而不是 cron 或 systemd timer（后两者不会有 `PWD=<项目目录>` 的 ubuntu sudo 会话）。再结合多个 `hermes_bridge.py --worker-profile default` 进程各自不同 socket，即可判定是**另一个 Hermes 会话**在操作。

## 那个会话实际做了什么（是完整且正确的）

1. Gemini 从第 3 位移到最后（它当时 100% 超时，占着第 3 位只会白烧 12s 预算）
2. 其余 6 节点 `large` 超时统一放宽到 35s
3. **同步更新了 `gemini-recovery-revert.py` 的 `DEMOTED_ORDER` 与 `RESTORED_ORDER`**（脚本 mtime 13:46:36，与配置改动同一批）
4. 13:46:46 重启双服务

第 3 点是决定性的：如果只改配置不改脚本常量，`do_revert()` 的漂移保护会把当前布局判为“人工改动过”从而**永久放弃自动还原**。那个会话显然理解这套机制，改得是配套的。

## 验证（判好坏靠实测，不靠位次直觉）

```bash
cd /home/ubuntu/lemon-group-bot && .venv/bin/python \
  /home/ubuntu/.hermes/skills/messaging/telegram-group-bot-suite/scripts/verify_summary_chain.py \
  --chat <PRIVATE_IDENTIFIER> --limit 80
# → elapsed=13.4s len=1205 err=None，五项全 PASS（改前基线 16.7s）
```

```python
# 漂移检测仍有效
import json, importlib.util
spec = importlib.util.spec_from_file_location('g', '/home/ubuntu/hermes-jobs/gemini-recovery-revert.py')
m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
order = json.load(open('/home/ubuntu/lemon-group-bot/data/ai_bot_<PRIVATE_IDENTIFIER>.json'))['order']
print(order != m.DEMOTED_ORDER)          # False → 未漂移，探测 PASS 后会正常还原
print(m.RESTORED_ORDER[0])               # antigravity_gemini
```

结论：13.4s 优于改前 16.7s，自动还原机制完好 → **是改进，不能回滚**。

## 教训

- 本机 Web UI 常驻多个 worker，**同一套生产配置可能被并发修改**；“没有 .bak + 非本人时段重启”不足以判定为异常，必须查 sudo 的 `PWD` 与 worker 列表。
- 回滚前先看关联常量（`DEMOTED_ORDER`/`RESTORED_ORDER`/`MAX_CHAIN_ATTEMPTS`）是否已被配套修改。只看 `order` 一个文件会误判。
- 向 Owner 报告时区分**已验证事实**（时间戳、sudo PWD、实测耗时）与**推断**（“应该是你在另一个窗口让它改的”），并请其确认来源。
- 事后建议：同一套群霸配置只在一个会话里改；并发改动风险是互相覆盖，且双方都看不到对方的操作。
