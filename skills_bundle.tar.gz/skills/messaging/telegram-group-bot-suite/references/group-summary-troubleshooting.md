# Telegram 群聊总结 (/sum) 调性错位与样本断层排障实战

## 0. 「/sum 失败但别人成功」—— 九成是 LLM 节点超时，不是权限/代码 bug

- **现象**：同一群内，某人连续 `/sum` 失败（弹「❌ 总结生成失败：...请稍后重试，或联系管理员检查模型配额」），另一人几乎同时却能成功。
- **根因判断铁律**：先查模型节点日志，再怀疑权限。群霸 `/sum` 的失败绝大多数是调用链所有节点 `timed_out`，与用户身份（管理员/Owner）无关 —— 不带参数时管理员与普通群友默认都是 80 条，窗口一致，不存在「管理员请求更大所以更容易超时」。
- **定位命令**（按节点聚合统计超时/成功次数）：
  ```bash
  sudo journalctl -u lemon-group-bot.service --since "1 hour ago" --no-pager \
    | grep -oE "node=[a-z_]+ .*outcome=[a-z_]+" | sort | uniq -c | sort -rn
  ```
- **判读**：若首选节点（反重力 Gemini）`outcome=timed_out` 占绝大多数、兜底节点也零星超时，即为节点抖动窗口；某次请求恰好撞上「全节点超时」就失败，撞上某个节点 `succeeded` 就成功 —— 纯时机问题，不是针对个人。
- **串行兜底代价**：调用链按 `order` 串行 fallback，每节点 budget ~25s（日志 `node_budget_s` 约 24.8），4 个节点全超时要等 ~75s 才报失败（`chain_elapsed_s` 可印证），用户体感是「卡很久然后失败」。
- **「总结速度明显变慢（从秒级变成几十秒）」的常见诱因**：
  - **现象**：群聊总结并未直接报错，但生成时间从平时的 5~10 秒拉长到 30s、50s 甚至打满交互限制的 75s。
  - **根因分析**：
    1. 首选节点（如 `antigravity_gemini` 反重力·Gemini 3.8）上游遭遇服务商高峰期容量耗尽（如本地 `cliproxyapi` 频繁收到 `503 MODEL_CAPACITY_EXHAUSTED`）或响应延迟陡增（单次 40s~90s）；
    2. 首选节点连续耗尽单次 25s 预算导致超时并触发熔断，请求被迫逐级 fallback 到第二、第三候选（如 CPA·GPT-5.6 或 NewFou·Gemini-Lite）；
    3. 累计消耗多轮 `node_budget_s`（例如 25s + 25s + 24s），只要最终某一跳成功，总结依然会发送，但总耗时 `elapsed_s` 会直奔 50s~75s。
  - **诊断定位**：
    ```bash
    journalctl -u lemon-group-bot -n 100 --no-pager | grep -E "node=.*outcome="
    ```
    观察日志中 `total_elapsed_s` 与 `fallback_index`，若 `fallback_index >= 1` 且前面的节点全为 `outcome=timed_out`，可断定为首选节点上游卡顿引发的级联延迟。
  - **处置方案**：通过 `/model` 面板临时将响应快的健康节点（如 `NewFou·Gemini-Lite`）置顶为主用，或等待上游 Gemini 算力高峰回落。
- **节点实时测活（判断持续性故障 vs 临时抖动）**：
  ```python
  import json,time,urllib.request
  d=json.load(open('data/ai_endpoints.json')); n=d['antigravity_gemini']
  req=urllib.request.Request(n['url'], data=json.dumps({'model':n['default_model'],
      'messages':[{'role':'user','content':'ping'}],'max_tokens':5}).encode(),
      headers={'Content-Type':'application/json','Authorization':f"Bearer {n['key']}"})
  t=time.time(); r=urllib.request.urlopen(req, timeout=30); print(r.status, '%.1fs'%(time.time()-t))
  ```
  秒级返回 `pong` 即已恢复（临时抖动）；持续超时/429 则为上游（本地 `127.0.0.1:8317` cliproxyapi 反重力）配额或故障。
- **配置位置**：`data/ai_endpoints.json`（全节点共享池，含 url/key/default_model）、`data/ai_bot_{BOT_ID}.json`（各 Bot 独立 `order`、`disabled_nodes`）。`get_active_chain` 只取 `enabled` 且 `key`/`url` 非空的节点 —— 11 个节点里常被 disable 7 个，链路单薄会放大抖动影响。
- **加固方向**：① 放宽首选节点超时预算（24.8s 偏短，总结长文易压线超时）；② 从 `disabled_nodes` 启用更多兜底节点（如日日新 DeepSeek、反重力 Claude）——**但必须先读 0.1**，否则新节点插在前面会把原本能兜住的节点挤出候选窗口，越加越糟。

---

## 0.2 「所有节点都在 25s 前后整齐超时」—— 总预算/槽位算出来的单节点超时 < 真实生成时间（2026-10-20 实测）

- **现象**：`/sum 500` 稳定失败，日志里前三跳的 `node_elapsed_s` 分别是 25.7 / 25.0 / 13.0，`node_budget_s` 是 24.8 / 24.4 / 12.0 —— 全部整齐卡在预算线上，而不是各自卡在不同时间。
- **算错的地方**：`large_request` 走 `deadline = chain_started + 75s`、`max_attempts = 3`，然后
  `slots = min(max_attempts - used, len(candidates) - idx)`、`node_timeout = min(configured, remaining / slots)`。
  75s / 3 槽 ≈ **24.8s**。而 500 条群史 + `max_tokens=2500` 的真实生成耗时是 **19~32s**（实测 tengbaipiao 29.7/31.2s、cpa_gpt56_luna 31.3/31.9s、cpa_gpt6_luna 18.9/25.5s、newfou 26.6/27.7s）。
  **健康节点被自己的超时杀掉**，不是上游故障。判据：单节点实测耗时 > `node_budget_s` 即坐实。
- **同时暴露的排序问题**：`antigravity_gemini` 长上下文实测 >120s（上游容量枯竭），却仍排在 order 第 3 位，白吃一个槽位，把后面能活的节点挤出预算窗口。
- **修复三步**（都在 `data/` 与 `services/ai_service.py`，热生效但改代码需 restart）：
  1. `deadline` 大请求预算 75s → **100s**（3 槽 ≈ 33.2s，覆盖真实生成时间上限）；
  2. `data/ai_timeout_overrides.json` 把健康节点 `large` 提到 **35.0**（否则 configured 会低于动态槽位，等于没放宽）；
  3. 把实测超时的节点从 order 前段挪到**末位**，健康节点顶上。
- **真实延迟探测脚本**（不打扰群）：直接调 `services.ai_service.SUMMARY_SYSTEM_PROMPT` + `database.get_recent_messages(chat, 500)` 拼出与生产完全一致的 prompt，逐节点跑 2 轮打表。
  只看 `pong` 级短探测会误判——短请求 1.5s 的节点，长上下文可能是 30s 甚至 >120s。
- **验收**：`scripts/verify_summary_chain.py --chat <群> --limit 500` 连跑 2~3 次，PASS 且 `elapsed` 落在 20~35s。
- **代价**：全节点挂掉的失败路径从 75s 拉长到 100s。用「100s 拿到真结果」换「75s 拿到报错」值得，但别再无脑往上加。

---

## 0.05 配置「莫名变了」先查是不是并行会话改的

现象：`data/ai_bot_*.json` / `ai_timeout_overrides.json` 的 order 或超时值与自己上次设置的不一致，且**没有对应的 `.bak-*` 备份**。

排查三步（只读）：

1. `ls -l --time-style=+%m-%d_%H:%M:%S data/ai_bot_*.json data/ai_timeout_overrides.json` 取精确改动时刻。
2. `journalctl --since "<改动前1分>" --until "<改动后2分>" | grep -E "sudo\[|systemd\[1\].*(Stop|Start)"`，重点看 `COMMAND=/usr/bin/systemctl restart lemon-group-bot...` 那行的 `PWD=`。若 `PWD=/home/ubuntu/lemon-group-bot`，说明是**在项目目录下操作的 agent 会话**。
3. `ps -eo pid,lstart,cmd | grep hermes_bridge` 看是否有多个 worker 并存（Web UI 每个会话一个 worker）。

结论：Owner 会用多个 Hermes 会话并行操作同一套群霸配置（2026-10-20 实测：13:46 另一会话改 order + 全节点超时 35s + 同步脚本常量 + 重启，全程无 .bak）。此时**不要急着按「未授权变更」回滚** —— 先确认改动是否成套自洽（order/overrides/脚本常量同步），若成套且实测更快，属于改进，保留即可。

配套检查：改 order 后必须同步 `gemini-recovery-revert.py` 的 `DEMOTED_ORDER`，否则漂移保护会让自动还原永久失效。验证方法：

```bash
python3 -c "
import json,importlib.util
spec=importlib.util.spec_from_file_location('g','/home/ubuntu/hermes-jobs/gemini-recovery-revert.py')
m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
o=json.load(open('/home/ubuntu/lemon-group-bot/data/ai_bot_<PRIVATE_IDENTIFIER>.json'))['order']
print('drift=', o!=m.DEMOTED_ORDER)"
```

`drift=False` 才表示自动还原仍然有效。

## 0.1 「加了兜底反而更容易失败」—— MAX_CHAIN_ATTEMPTS 候选窗口截断陷阱（2026-10-20 实测）

- **现象**：某次「加兜底节点」配置改动后，原本偶发成功的 `/sum` 变成稳定失败；每次耗时固定 ~70s，群里报「❌ 总结生成失败：日日新·DeepSeek 请求超时」。
- **代码事实**（`services/ai_service.py` + `services/ai_limits.py`）：
  - `MAX_CHAIN_ATTEMPTS`（历史值 4，2026-10-20 已上调为 **6**），`candidates = chain[:MAX_CHAIN_ATTEMPTS]` —— **只有生效链路窗口内的节点会被尝试，窗口外永远不调用**；
  - 大请求判定 `input_chars >= 30000 or max_tokens >= 2000`（群总结恒为大请求）→ `max_attempts = 3`、总 deadline `75s`；
  - `node_timeout = min(configured, remaining / slots)`，前 3 个节点按 75/3 动态切预算（实测 25s / 20s / 20s = 65s）；
  - 第 4 个节点若 `used_attempts >= max_attempts` 且 `remaining < node_timeout` → 日志 `LLM candidate skipped: insufficient remaining budget node=xxx`，直接跳过。
- **踩坑模式**：把新节点插到 `order` 第 2、3 位并启用，原本排第 3、4 位的健康节点被挤到第 6、7 位 → 结构上不可达。此时「节点更多、兜底更强」是错觉，可用性反而从「4 选 1 能活」退化成「前 3 个全挂就必死」。
- **排查步骤**：
  1. 打印**实际生效链路**（不是原始 `order`，必须先减去 `disabled_nodes`）并标出候选窗口：
     ```bash
     cd /home/ubuntu/lemon-group-bot && .venv/bin/python -c "
     import sys; sys.path.insert(0,'.')
     from services.ai_service import get_active_chain, get_node_timeout
     from services.ai_limits import MAX_CHAIN_ATTEMPTS
     ch = get_active_chain('<PRIVATE_IDENTIFIER>')   # 同步函数，不要 await
     for i,n in enumerate(ch):
         print(i, n['id'], 'large_t=', get_node_timeout(n['id'], True), 'candidate=', i < MAX_CHAIN_ATTEMPTS)
     "
     ```
     `get_active_chain` 是**同步**函数，`await` 会抛 `TypeError: object list can't be used in 'await' expression`。
  2. 对照 `data/ai_bot_<BOT_ID>.json.bak-*` 备份的 mtime 与失败开始时间，定位是哪次改动引入的（例：`.bak-addfallback-20261020T103937Z`）。`order` 只是意图，`order - disabled_nodes` 才是真实链路，索引会平移。
  3. 核对 cliproxyapi 日志判读上游真因：`503 MODEL_CAPACITY_EXHAUSTED`（模型容量枯竭）、`429 QUOTA_EXHAUSTED`（附 `Resets in 138h` 之类重置时长，等于该账号数天不可用）、`499`（**我方预算到点主动断开**，不是上游报错，别当上游故障）。
- **手工 `/sum` 失败没有错误日志（重要）**：`handlers/commands.py` 的 `execute_summary` 失败只 `edit_text` 群里文案，不写 logger；`Interactive job failed` 只覆盖其他路径，手工总结失败时该计数仍为 0。**判据**：`Interactive job finished kind=summary elapsed_s≈70` + 同请求区间内**没有** `LLM 实际使用节点` 行 + `outcome=succeeded` 计数为 0 → 全链路超时失败。
  ```bash
  sudo journalctl -u lemon-group-bot.service --since "2 hours ago" --no-pager \
    | grep -E "Manual summary admitted|Interactive job finished kind=summary|LLM 实际使用节点"
  ```
- **修复优先级**：先改 `order`（纯 JSON、热生效、无需重启）把健康节点放回候选窗口内；要真正扩链再改 `MAX_CHAIN_ATTEMPTS`（需重启双 Bot）。改动前备份 `data/ai_bot_<BOT_ID>.json`，改完用 `scripts/verify_summary_chain.py` 跑真实群消息端到端验收，确认 `ERR=None` 且正文含 `<details>` 与 `t.me` 来源链接才算修好。2026-10-20 实际处置：`MAX_CHAIN_ATTEMPTS` 4→6、删掉 401 失效节点、给手工 `/sum` 失败补日志，双 Bot 重启后 41s/1529 字通过。
- **一键链路体检**：`scripts/probe_ai_chain.py`（读 endpoints/bot 配置，打印生效链路、候选窗口、各节点 ping 延迟与 HTTP 状态，全程不输出密钥）。

---

## 0.2 节点增删与验收：快速失败吃槽位、401 vs 429、端到端实测（2026-10-20 实做）

- **429/401 快速失败同样吃候选槽**：一个 429 只要 0.02s、401 只要 0.3s 就返回，`used_attempts` 照常 +1。所以小窗口可能在总预算还剩 50s 时就被几个快速失败节点耗光，后面全健康的节点一个都轮不到 —— 这正是 19:46 / 19:48 两次 `/sum` 必死的机制。**窗口宽度必须 > 已知快速失败节点数 + 真正要兜底的节点数**。
- **已实施的修复（2026-10-20）**：`services/ai_limits.py` 的 `MAX_CHAIN_ATTEMPTS` 4 → 6 → **7**（等于启用节点总数，最后一个节点不再永远进不了候选窗口；`.py` 改动，`systemctl restart lemon-group-bot.service lemon-group-bot2.service` 后生效）；`handlers/commands.py` 的 `execute_summary` 失败分支补了 `logger.error("Manual summary generation failed chat=... samples=... error=...")`，此后手工 `/sum` 失败在 journal 里可直接看到原因，不必再靠 70s 耗时反推。
- **窗口宽度只影响"可尝试范围"，不放大尝试次数**：`candidates = chain[:MAX_CHAIN_ATTEMPTS]`，而 `max_attempts = min(MAX_CHAIN_ATTEMPTS, 3 大请求 / 2 普通)`，所以把窗口从 6 提到 7 不会让单次总结多打请求，只是让第 7 个节点在极端情况下可达。真正的耗时上限仍由 75s/30s 总预算与 `remaining/slots` 控制。
- **401 与 429 必须分开处置（别把限流当失效删掉）**：
  - `401` = Key 失效，节点是死重，直接从 `ai_endpoints.json` 与两个 Bot 的 `order` / `disabled_nodes` 里删掉（本次删除 `dddai_luna`），删前 grep 一遍其他引用并备份三份 JSON；
  - `429` 若来自本地 cliproxyapi，多半是**滚动配额冷却**而非失效。查 `journalctl -u cliproxyapi` 里的 `conductor_selection.go ... in cooldown: ... reason=credential_quota, remaining=29m10s`，`remaining` 就是自动恢复倒计时（实测 11m→5m 一路递减、到点自愈），**不要因为 429 删节点**；
  - `503 MODEL_CAPACITY_EXHAUSTED` 是上游模型容量枯竭只能等；`429 QUOTA_EXHAUSTED ... Resets in 138h` 才是账号级数天不可用。
- **新节点必须先做长 prompt 实测**：用接近真实的 2000+ 字上下文、`max_tokens≈1800` 打一发，检查 `choices[0].message.content` 是否非空。纯思考型模型（实测该中转的 `cn:deepseek-v4.1-flash`）会把 token 全烧在 `reasoning_content`，`content` 为空；代码明确**不拿思维链兜底**，只会报「返回正文为空或纯思考过程」然后跳到下一节点。
- **可用模型对照（腾白嫖中转 capy）**：`cn:glm-5.3-flash` 7.7s/365字 ✅、`cn:minimax-m3` 4.2s/343字 ✅、`cn:kimi-k2.8-preview` 5.2s/289字 ✅；`cn:deepseek-v4.1-flash` 长 prompt 空正文 ❌。
- **加节点的完整动作（少一步等于没加）**：① 写 `ai_endpoints.json`（`key` 与 `key_env` 二选一；`key_env` 会回落读 `/home/ubuntu/.hermes/.env`，服务进程环境里没有该变量也能解析）；② **必须**把 id 加进每个 Bot 的 `order` —— `order` 就是白名单，只加端点池不加 order 等于没加；③ 跑 `scripts/probe_ai_chain.py` 确认它落在候选窗口内、且没把健康节点挤出去；④ 双 Bot 都要改，别只改一个。
- **热生效**：`ai_endpoints.json`、`ai_bot_<id>.json`、`data/ai_timeout_overrides.json` 每次调用现读磁盘（`_read_ai_json` / mtime 缓存），改 order、加节点、调超时**都不需要重启**；只有改 Python 代码才要 `systemctl restart`。
- **节点超时可热调**：`get_node_timeout()` 支持 `data/ai_timeout_overrides.json` 覆盖，格式 `{"<node_id>": {"large": 12.0, "small": 16.0}}`，缺失/损坏自动回落内置默认值。注意大请求在 idx0 的真实预算是 `min(配置值, 剩余预算/待尝试槽数)`，75s ÷ 3 ≈ **24.8s 上限**，把节点超时设成 30s 也只能拿到约 24.8s。
- **运维 Bot 可视化入口**：`/status` 面板已接入「群霸 AI 调用链」区块（`lemon-ops-bot/main.py` 的 `get_gemini_recovery_text()`），显示当前 Gemini 位次、上次探测结果与延迟、`streak n/3`、下次探测时间（北京时间），并带「🔁 立即探测 Gemini 上游」按钮（`m:gemini_probe` → `sudo -n systemctl start --no-block gemini-recovery-revert.service`，脚本自带 fcntl 锁防并发）。该区块整体 try/except，state 缺失或 systemctl 超时都不会拖垮整块状态面板。
- **上游长期劣化的「临时降级 + 自动还原」闭环**：`/home/ubuntu/hermes-jobs/gemini-recovery-revert.py` 配 `gemini-recovery-revert.timer`（每 20 分钟）用 **12k 字符真实长上下文**探测 `antigravity_gemini`（小 ping 会假阳性 —— 实测短请求 2.5s 正常、12k 长上下文 50s 超时），连续 3 次通过（延迟 ≤25s 且正文非空）才自动把 order 还原成「Gemini 第一」并移除 12s 超时覆盖，同时经 `lemon-ops-bot/notify.py` 推 Telegram。还原前校验 order 仍是降级布局，被人工改过则只通知不动手；还原后写 `reverted=true` 变幂等空转。状态：`hermes-jobs/status/gemini-recovery.state.json`。
- **端到端验收（不打扰群，比在群里刷 `/sum` 干净）**：直接调生产函数，用真实群历史消息跑一次总结：
  ```bash
  cd /home/ubuntu/lemon-group-bot && .venv/bin/python <skill_dir>/scripts/verify_summary_chain.py --chat <PRIVATE_IDENTIFIER> --limit 80
  ```
  通过判据：`ERR=None`、`LEN>300`、正文含 `<details>` 与 `t.me/c/` 来源链接、耗时在 75s 内。实测参考：Gemini 超时后由腾白嫖接管，41s / 1529 字。

---
## 1. 核心症结与踩坑总结（彻底解决“太假”与“对应不上”）

### 1.1 纯内存环形缓冲（重启归零断层）
- **痛点**：为追求微秒级处理而将群聊消息仅保存在 Python 进程内的 `deque(maxlen=N)`。一旦 Bot 发生代码更新、热重启或崩溃自愈，内存历史瞬间蒸发；
- **恶果**：用户触发 `/sum` 或 `/sum 50条` 时，Bot 仅能抓取重启后产生的寥寥几条发言（总结卡片显示「样本 4 条」或「样本 8 条」）。大模型严重缺乏前文语境，只能对着零星几句话强行猜测编造，导致总结内容前言不搭后语；
- **最佳解法**：**内存 deque 极速读 + SQLite 磁盘持久化双轨**。
  - 读取时从内存 deque 直接切片（0 磁盘 I/O，耗时 < 1µs）；
  - 写入时同步或异步写入 SQLite `messages` 表，耗时极微；
  - Bot 启动时（`init_db`）预热查询 SQLite 中各授权群最近 1,000 条发言载入 deque，彻底抹平重启断层。

---

### 1.2 闲聊吹水群套用“政企/技术研讨八股文”Prompt（为什么“太假”）
- **痛点**：旧 Prompt 强行要求“以技术本质/方案/共识为主语”、“严禁张三说李四回”、“使用探讨了/交流了等专业语态”、“收尾必须给出落地行动建议与避坑指南”；
- **恶果**：日常吹水群（如野草地）中群友聊吃面肉少、看妞、开玩笑、互怼，大模型被逼将生活琐事升华成“餐饮消费风控模型与避坑指南”，并生搬硬套假大空的“行动共识”；且因抹去人名，把互怼幽默压平为单向假结论，丢失了群聊最核心的交流灵魂；
- **最佳解法**：**去八股、去油腻、还原社群真实生态的自适应 Prompt**：
  - **允许并提倡指明核心发言人**（如：“张五发起了关于反代的讨论，抽象反馈电信快移动慢...”），还原真实互动与交锋；
  - **用自然、生动的人类语言总结**，严禁使用“探讨了/交流了/确认了/分析了”等公文八股套话；
  - **收尾板块智能自适应**：技术/事务讨论给 `📌 核心共识与后续`；日常吹水/闲聊给 `💡 讨论亮点与趣闻`（提炼梗点、高光发言与神回复），坚决不编造假大空的行动指南。

---

### 1.3 上下文关键信息丢失（为什么“对应不上”）
1. **非线性回复链（Reply-to）缺失（张冠李戴）**：
   - 群聊不是线性瀑布流，群友经常回复半小时前的旧发言。若缓存只存单行文本，给大模型的就是一串乱序流，大模型误以为 A 在回复 B，导致逻辑错位、人物观点颠倒；
   - *修复*：数据结构必须记录 `reply_to_msg_id` 与 `reply_to_user_name`，上下文格式化为：`[12:10] A (msg_id:102, 回复 B msg_id:101): 内容`。
2. **时间跨度标记（时间戳）缺失**：
   - 缺少时间标记会导致隔了几个小时完全不挨着的闲聊被强行拼成同一件事；
   - *修复*：在发言前追加北京时间标记（如 `[14:25]`）。
3. **来源跳转链接（`msg_id`）乱指或错位**：
   - 大模型在压缩多条发言时，往往随机抓取一个 `msg_id` 挂在末尾，导致点击来源跳转到无关发言；
   - *修复*：Prompt 严密约束：`[来源](https://t.me/{link_prefix}/{msg_id})` 必须严格指向该事实最核心、最直接的一到两个发言来源，严禁跨话题乱扣或虚构。
4. **短视频/媒体链接被丢弃**：
   - 群友分享抖音/B站/TikTok 视频后代码若直接 `return` 未进缓存，群友后续对着视频的大量讨论就会沦为无源之水；
   - *修复*：解析后写入 `[分享视频: 标题]` 记录进聊天历史。
5. **时间范围参数解析缺失**：
   - 在 `parse_summary_arg` 中补齐 `今天` / `今日` / `today`（自当日 00:00 UTC+8 至今）以及 `昨天` 自然语言解析。

---

### 1.4 思维链模型思考过程泄漏（为什么把思考过程放进去了）
- **痛点**：当调用链降级到自带思考能力的高阶模型（如 Gemini 3.8 Flash High、DeepSeek-R1、Claude Thinking）时，模型在输出正文前，往往自作聪明地把思维链也包装成折叠卡片（如 `<details><summary>💭 思考过程 / 分析思路</summary>...</details>`），或者在首个 `<details>` 之前输出大量推导文本；
- **恶果**：群友触发总结后，卡片第一项赫然出现机器人的自我分析和推理草稿，既破坏了社群总结的纯净性，又严重影响观感；
- **最佳解法：Prompt 强约束 + 后置清洗双重硬拦截**：
  1. **Prompt 红线**：在 System Prompt 中显式声明：`严禁输出任何思考过程、思维链、分析草稿或自言自语（严禁输出 <think>、<thought> 或以思考/思维为标题的卡片）！直接输出纯净的 <details><summary> 业务卡片语法。`；
  2. **后置正则强斩首**：
     - 正则匹配并剥离 `<details>\s*<summary>[^<]*(?:思考|思维|thought|thinking|reasoning|思路梳理|分析思路|分析过程|分析记录|推理|推导|内心OS|思维链|Chain-of-thought|CoT)[^<]*</summary>[\s\S]*?</details>`；
     - 前置物理截断：强制以首个合法业务 `<details` 为界，物理切除其前所有未闭合标签、自言自语与草稿；
  3. **严禁 fallback 到 reasoning_content**：当模型返回的 `choices[0].message.content` 为空时，绝不能用 `reasoning_content` 代替输出，宁可降级报错或切下一兜底节点；
  4. **双 Bot 守护进程热重载同步**：修改 `ai_service.py` 后必须同步重启 `lemon-group-bot.service` 与 `lemon-group-bot2.service`，杜绝分身 Bot 漏重载导致线上泄漏。

---

### 1.5 自身与 Bot 对话排版转义避坑（防止 Telegram 吞字与悬空标点）
- **根因**：向 Telegram 客户端发送消息时，若直接裸打尖括号标签（如 `<think>`、`<details>` 等技术术语）且未加行内代码块包裹，Telegram 服务端会将其作为未知 HTML 实体强行吞噬，导致关键文字丢失并产生悬空标点车祸（如 `、、、、<reason>`）；
- **规范**：向 Telegram 输出任何技术术语、标签、变量或指令，必须 100% 用单反引号行内代码包覆（如 `\`<think>\``），严禁在常规文字中裸发尖括号。同时保持人设一致，避免生硬死板的机械汇报腔。

---

## 2. 生产验证通过的标准 Prompt 与格式模版

```python
# 1. 聊天记录上下文格式化模版
bj_tz = datetime.timezone(datetime.timedelta(hours=8))
dialog_lines = []
for m in messages:
    msg_id = m.get("message_id")
    user = m.get("user_name") or "群友"
    text = m.get("text", "").replace("\n", " ").strip()
    if len(text) > 200:
        text = text[:200] + "..."

    ts = m.get("created_at")
    t_str = f"[{datetime.datetime.fromtimestamp(ts, tz=bj_tz).strftime('%H:%M')}] " if ts else ""

    reply_info = ""
    r_user = m.get("reply_to_user_name")
    r_id = m.get("reply_to_msg_id")
    if r_id and r_user:
        reply_info = f" (回复 {r_user} msg_id:{r_id})"
    elif r_id:
        reply_info = f" (回复 msg_id:{r_id})"

    dialog_lines.append(f"{t_str}{user} (msg_id:{msg_id}{reply_info}): {text}")

dialog_text = "\n".join(dialog_lines)
```

```python
# 2. 生产验证通过的系统提示词
SUMMARY_SYSTEM_PROMPT = """你是一个顶级的 Telegram 社群讨论分析专家。请对用户提供的群聊记录进行真实、生动、脉络清晰的结构化总结。

【核心原则（严禁失真、假大空与错位）】：
1. 真实生动，拒绝假大空与官僚八股：
   - 这是真实的 Telegram 群聊，话题涵盖生活吐槽、趣闻调侃、互怼玩梗、技术交流、影视娱乐等。
   - 严禁把日常吹水玩笑强行包装成“企业级技术方案”或“严肃避坑指南”！如实还原讨论的真实焦点与群友气氛。
   - 允许并鼓励指明核心发言人与互动对象（例如：“张五发起关于反代节点的讨论，抽象指出...，Whisper 准备跟进...”），保留人情味与真实互动交锋，严禁把多人言论粗暴揉成毫无主语的死板公文。
   - 严禁机械化使用“探讨了...交流了...确认了...分析了...”等八股套话，用接地气、生动凝炼的人类语言总结。

2. 精准溯源与严禁错位（核心红线）：
   - 聊天记录中每条发言都带有 `(msg_id:xxxx)` 及回复链条。
   - 总结中的每个核心事实/观点末尾，必须附带其最直接的一到两个发言来源：`[来源](https://t.me/{link_prefix}/{msg_id})`。
   - msg_id 必须百分之百真实来自于上方聊天记录中的对应发言，严禁张冠李戴、严禁跨话题乱扣来源、严禁编造不存在的 msg_id！
   - 当多位群友围绕同一话题互动时，来源直链应准确指向该观点的提出者或关键答复的 msg_id。

3. 原生折叠卡片排版规范：
   - 根据群聊实际内容，提炼 2~4 个独立话题卡片，每个卡片严格采用：
<details>
<summary>{合适Emoji} {话题标题}</summary>

• {清晰还原该话题的事件脉络、讨论焦点或精彩交锋} [来源](https://t.me/{link_prefix}/{msg_id})
• {后续延伸、不同群友的态度/吐槽或实际进展} [来源](https://t.me/{link_prefix}/{msg_id})
</details>

   - 结尾收尾板块（根据内容性质智能自适应）：
     * 若讨论涉及明确的技术方案或事务推进：
<details>
<summary>📌 核心共识与后续</summary>

• 提炼群友达成的共识或待跟进事项。
</details>
     * 若讨论以生活闲聊、趣事或吹水为主（无严肃结论）：
<details>
<summary>💡 讨论亮点与趣闻</summary>

• 提炼本段对话最有意思的梗点、金句或高光互动。
</details>

4. 格式红线：
   - 严禁包裹 Markdown ```html 或 ``` 代码块！
   - 严禁使用剧透符 || 或引用符 >！
   - 直接输出纯净的 <details><summary> 语法。
"""
```
