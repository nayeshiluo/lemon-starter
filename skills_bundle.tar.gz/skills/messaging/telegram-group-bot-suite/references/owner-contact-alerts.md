# Owner 联系提醒（被拉进群 / 陌生人私聊）实现与验证

2026-10-24 实测落地：同一套语义同时上到 4 台自建 Bot。

| Bot | 形态 | 落点 |
|---|---|---|
| `@<PRIVATE_IDENTIFIER>_bot` / `@<PRIVATE_IDENTIFIER>_bot`（群霸双 Bot） | python-telegram-bot 22.8 | `/home/ubuntu/lemon-group-bot/services/contact_alerts.py` + `bot.py` 注册 |
| `@hermes_fxo6rwwchvtfrm7k_bot`（运维 Bot） | PTB | `/home/ubuntu/lemon-ops-bot/contact_alerts.py` + `main.py` 注册 |
| `@shashasha111_bot`（广告杀手，vps-la） | **纯 stdlib 裸 HTTP 轮询** | `/opt/ad-killer/bot.py` 的 `handle()` / `private()` |

## 1. PTB 侧（群霸、运维 Bot）

新增一个只读模块，导出两个 handler，业务代码一行不改：

```python
async def alert_my_chat_member(update, context):
    change = update.my_chat_member
    if not change or change.chat.type not in ("group", "supergroup"):
        return
    old = change.old_chat_member.status; new = change.new_chat_member.status
    added   = old in ("left", "kicked") and new in ("member", "administrator")
    removed = old in ("member", "administrator") and new in ("left", "kicked")
    if not (added or removed):
        return
    ...  # 群名/群ID/操作人/授权状态/北京时间 → send_message(OWNER_ID, parse_mode="HTML")

async def alert_private_message(update, context):
    msg, user = update.effective_message, update.effective_user
    if not msg or not user or user.id == OWNER_ID or user.is_bot:
        return
    ...  # 10 分钟冷却 + suppressed 计数，再 send_message
```

注册（`bot.py` / `main.py` 的 `main()` 里，紧跟 app 构建之后）：

```python
app.add_handler(ChatMemberHandler(alert_my_chat_member, ChatMemberHandler.MY_CHAT_MEMBER), group=-1)
app.add_handler(MessageHandler(filters.ChatType.PRIVATE & ~filters.User(OWNER_ID), alert_private_message), group=-1)
```

要点：
- 用 `group=-1`（群霸已有 `-5/-4/-3/-2` 各司其职），与既有 handler 不冲突；本组只有这两个 handler，不影响后续组执行。
- 群霸的 `~filters.User(OWNER_ID)`；运维 Bot 用 `~filters.User(list(ALLOWED_ADMIN_IDS))`。
- 群霸双 Bot **共用同一目录同一份代码**，只有 systemd `Environment=TELEGRAM_BOT_TOKEN` 不同 → 改一次要 restart 两个 unit。
- 取 Bot 自身身份用 `context.bot.username`，别写死。

## 2. 广告杀手（stdlib 裸轮询）侧

`allowed_updates` 里本来就有 `my_chat_member`，只是没人处理（落到 `if not message: return`）。所以只需：

```python
# handle() 开头，紧跟 chat_join_request 分支之后
if update.get('my_chat_member'):
    try:self.my_chat_member(update['my_chat_member'])
    except Exception as exc:LOG.warning('my_chat_member_alert_failed type=%s',type(exc).__name__)
    return

# private() 的非 owner 分支（原本只转 cases.appeal）
if message.get("from", {}).get("id") != self.owner:
    try:self.alert_stranger_dm(message)
    except Exception as exc:LOG.warning('stranger_dm_alert_failed type=%s',type(exc).__name__)
    if self.cases:self.cases.appeal(message)
    return
```

新增方法 `alert_owner(lines)` / `my_chat_member(change)` / `alert_stranger_dm(message)`；发送用 `self.api.call("sendMessage", chat_id=self.owner, text=text[:900], link_preview_options={"is_disabled": True})`（与既有 `join_profile_review_alert` 同款），`self.owner` 来自 `config.json` 的 `owner_id`，授权判断用 `str(chat_id) in self.store.config["groups"]`。
该 bot 文件是 stdlib-only、模块级只有常量和一个别名 `for` 循环（`if __name__=="__main__"` 才 `main()`），**可以安全 `import bot`** 做验证。
时间戳无 zoneinfo：`time.strftime("%Y-%m-%d %H:%M:%S", time.gmtime(time.time() + 8*3600)) + " (北京)"`。

## 3. 验证套路（关键：不要开第二个 Telethon 客户端）

想制造"真实陌生人私聊"最直觉的做法是用 UserBot 人形号去 DM——**禁止**：同 `.session` 并发有 `AuthKeyDuplicatedError` 风控与 SQLite 锁风险（见本技能第 6 节）。

可行的等价验证（本次采用，8 条测试消息全部送达）：

1. **真实 Bot Token + 构造假 update 直接调 handler**。PTB 侧 `SimpleNamespace` 拼 `effective_user/effective_message` 与 `my_chat_member`，`async with Bot(BOT_TOKEN) as bot` 后 `await alert_private_message(update, SimpleNamespace(bot=bot))` —— 走的是**线上同一份格式化 + 同一套 sendMessage**，只是更新不是 Telegram 推来的。
2. 双 Bot 取第二个 token：`TOKEN=$(sudo -n systemctl show lemon-group-bot2 -p Environment | tr ' ' '\n' | grep '^TELEGRAM_BOT_TOKEN=' | cut -d= -f2)`，只放进子进程 env，**不要 echo**。
3. stdlib Bot 用 shim 复用真方法：把 `Bot.alert_owner / alert_stranger_dm / my_chat_member` 绑到一个假对象（`owner`、`api=Telegram(token)`、`store=SimpleNamespace(config={'groups':{}})`、`_dm_alerts={}`）上调用。
4. 断言方式：脚本无异常退出 + 成功路径 `logger.info("... alert sent ...")`；服务侧再 `journalctl -u <svc> --since -12min | grep -Ei "traceback|error|failed"` 为空、`systemctl is-active` 全 active。

**结论口径**：这一套证明的是"handler 逻辑 + HTML 渲染 + 真实投递"；"Telegram 把真实私聊/成员更新推进 poller" 这一段是标准 Bot API 行为，若没第三方账号实测就不要对 Owner 说成"已端到端验证"，如实说明"等真实事件复核"。

## 4. 踩坑

- **`getattr(SomeClass, "_staticmethod")` 绑到另一个类会丢 `staticmethod` 包装**，调用报 `takes 1 positional argument but 2 were given`。shim 里静态方法要 `setattr(Shim, name, staticmethod(getattr(B.Bot, name)))`。
- **远端内联 heredoc 打补丁必炸**：`ssh host 'cd x && python3 - <<"EOF" ... EOF'` 里的 `'''`、引号、括号会被本地 bash 先解析（本次报 `syntax error near unexpected token '('`），还可能命中 inline payload 拦截。**正确做法：本地写 patch 脚本 → `scp` 到远端 → `ssh host 'python3 /tmp/patch.py'`**，脚本内 `assert s.count(old)==1` + `ast.parse` 自检。
- 改远端前先 `cp -p bot.py bot.py.before-<feature>-$(date -u +%Y%m%dT%H%M%SZ)`，本地同理留 `.bak-<feature>-*`。
- 提醒里的群 ID 用 `<code>` 而非反引号（HTML parse_mode 下反引号原样显示）。
- 未授权群被拉进去时顺手给 Owner 一行 `/auth <chat_id>` 提示，比让 Owner 自己翻 ID 省事。

## 5. 舰队适用范围判断（2026-10-24 实测盘点）

Owner 问「其他几个 Bot 有必要做这个功能吗」时，先盘点再逐台给结论，不要默认全量铺开。

**盘点命令（只读）**：

```bash
systemctl list-units --type=service --state=running --no-legend | awk '{print $1}' \
  | grep -Ei "bot|lemon|userbot|tg|tele|hermes|ops|music|relay"
ssh vps-la 'systemctl list-units --type=service --state=running --no-legend | awk "{print \$1}" \
  | grep -Ei "bot|ad-killer|lemon|workbuddy"'
```

**结论表**：

| 对象 | 形态 | 结论 |
|---|---|---|
| `@<PRIVATE_IDENTIFIER>_bot` / `@<PRIVATE_IDENTIFIER>_bot` | PTB 22.8 | ✅ 已加（共用一份代码，两个 unit 都要 restart） |
| `@hermes_fxo6rwwchvtfrm7k_bot` | PTB | ✅ 已加 |
| `@shashasha111_bot`（ad-killer, vps-la） | stdlib 裸 getUpdates | ✅ 已加（`allowed_updates` 本来就有 `my_chat_member`，只缺分支） |
| `subinfo-bot`（订阅查询，本机） | **stdlib 裸 getUpdates，手写轮询** | ⚠️ 值得做但**不能照搬**：`allowed_updates` 只有 `["message","callback_query"]`，**必须先加 `my_chat_member`**，否则静默不生效；且它面向外部用户，私聊要改成“新用户首次”而非逐条 |
| `lemon-userbot`（柠檬人形号） | Telethon 账号，非 Bot | ❌ 不加：没有 `my_chat_member` 事件；挂 Telethon 事件需重启人形号、有风控风险；被拉陌生群更适合每日会话审计 |
| `hermes-gateway` / `hermes-web-ui` / `lemon-mtg`（MTProto 代理）/ `workbuddy2api` / `lemon-subconverter` | 非 Telegram Bot | ❌ 无此事件 |
| `ad-killer-cleanup-worker` / admission UI 等 | ad-killer 子进程 | ❌ 不是独立 Bot |

**给 Owner 的回答形态**：先一句“只有 X 有必要，其余不用加”，再分「已做 / 待做 / 不用加」三段，待做的那台给出差异化方案（为什么不能照搬）。不要为了显得勤快而建议全量铺开。
