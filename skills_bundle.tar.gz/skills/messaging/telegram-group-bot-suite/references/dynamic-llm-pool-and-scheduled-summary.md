# Telegram 群聊定时发言总结与统一 API 池分 Bot 调度系统架构实战

## 1. 业务背景与踩坑演进

在多群管 Bot（如主 Bot `@yecaodi_bot` 与分身 Bot `@qunba_bot`）并发运行的生产环境中，群聊发言总结与大模型调度经历了两次关键迭代：
1. **从手动总结到定时总结（#总结 标签对齐）**：
   - 群友和管理员不满足于每次手动发 `/sum`，要求定时在早晨醒来、下午、睡前自动回顾过去 N 小时的讨论脉络；
   - 总结必须带有 `#总结` 标签，以便在 Telegram 客户端中一键点击标签过滤出所有历史总结，不破坏原生折叠小三角卡片视觉。
2. **从硬编码大模型到「统一 API 池 + 分 Bot 独立调度」**：
   - 旧代码中 `LLM_CHAIN` 为静态 Python 列表，遇 504/429 虽有 fallback，但若要添加第三方 API（如 DeepSeek 官方、硅基流动等）必须 SSH 进服务器修改代码，剥夺了管理员的自治权；
   - 若每个 Bot 完全物理隔离，录入长 URL 与 API Key 需在多个 Bot 间重复操作，维护极其繁琐；若完全共享，则无法实现主 Bot 跑高质 Claude、分身 Bot 跑低成本 Gemini/DeepSeek 的差异化分工。

---

## 2. 混合解耦架构设计 (Unified API Pool + Per-Bot Model Chain)

```text
┌────────────────────────────────────────────────────────┐
│       🌐 统一 API 端点与凭证池 (data/ai_endpoints.json)   │
│   (存放所有 URL、API Key、预置端点；管理员录入一次，全域共享) │
└───────────────────────┬────────────────────────────────┘
                        │
          ┌─────────────┴─────────────┐
          ▼                           ▼
┌───────────────────────┐   ┌────────────────────────┐
│ 主 Bot (@yecaodi_bot) │   │ 分身 Bot (@qunba_bot)  │
│ (data/ai_bot_8723257160.json)│ (data/ai_bot_8712228275.json)│
├───────────────────────┤   ├────────────────────────┤
│ • 👑 首选: LFree·Claude │   │ • 👑 首选: 反重力·Gemini│
│ • 🛡️ 备用1: 反重力·Gemini│   │ • 🛡️ 备用1: 日日新·DeepSeek│
│ • 🛡️ 备用2: 日日新·DeepSeek│ │ • 🛡️ 备用2: LFree·Claude  │
│ • 专属模型代号定制     │   │ • 专属模型代号定制      │
└───────────────────────┘   └────────────────────────┘
```

### 2.1 数据存储分层
- **统一 API 池 (`data/ai_endpoints.json`)**：
  ```json
  {
    "lfree_claude": {
      "id": "lfree_claude",
      "name": "LFree·Claude",
      "url": "https://ai.lfree.org/bot/<YOUR_BOT_ID>/v1/chat/completions",
      "key": "sk-...",
      "default_model": "claude-opus-5"
    },
    "antigravity_gemini": {
      "id": "antigravity_gemini",
      "name": "反重力·Gemini3.8",
      "url": "http://127.0.0.1:8317/v1/chat/completions",
      "key": "...",
      "default_model": "gemini-3.8-flash-high"
    }
  }
  ```
- **分 Bot 独立配置 (`data/ai_bot_{BOT_ID}.json`)**：
  ```json
  {
    "bot_id": "8723257160",
    "order": ["lfree_claude", "antigravity_gemini", "antigravity_claude", "sensenova_deepseek"],
    "disabled_nodes": [],
    "model_overrides": {
      "lfree_claude": "claude-3-7-sonnet"
    }
  }
  ```

### 2.2 敏感密钥自动秒删与掩码机制
- **痛点**：管理员在 Telegram 私聊中发送 `/setapi` 或 `/setkey` 时，明文 API Key 会留存在 Telegram 聊天记录和云端备份中，极易因设备被窃或截图泄露。
- **防御准则**：
  1. 机器人收到包含 Key 的指令瞬间，**立即调用 `await msg.delete()` 秒删原消息**；
  2. 回复确认消息时，强制调用 `mask_key(key)` 仅保留前 4 位和后 4 位（如 `sk-QOof...9sOz`），绝不在响应中回显完整密钥。

---

## 3. 定时群聊发言总结与时钟整点对齐规范

### 3.1 时钟整点对齐避坑 (Integer Clock Alignment Pitfall)
- **踩坑现象**：
  - 如果循环周期（如“每8小时总结”）基于管理员点击时刻相对递增（`last_run + interval`），一旦在非整点（如 23:40）点击，下次触发就会变成 `07:40`、`15:40`，导致群友和管理员疑惑“为什么不是整点总结”。
- **架构方案**：
  - **循环任务必须默认对齐到自然时钟整点（00 分）**；
  - 预设按钮统一映射为固定北京时间点列表（`daily_time`）：
    - **8h 循环**：严格锁定 `07:00`、`15:00`、`23:00`（早 7 点查阅夜聊、下午 15 点查阅上午、晚 23 点查阅下午及晚间）；
    - **6h 循环**：严格锁定 `00:00`、`06:00`、`12:00`、`18:00`；
    - **4h 循环**：严格锁定 `00:00`、`04:00`、`08:00`、`12:00`、`16:00`、`20:00`。

### 3.2 槽位幂等锁定防重跑 (`last_run_slot`)
- **机制**：
  - 后台常驻轻量调度协程（每 30 秒轮询，校准 UTC+8 北京时间）；
  - 触发时比对槽位 `slot = f"{today_str}_{time_point}"`（如 `2026-09-13_22:00`）；
  - 判定满足触发条件后，**立即写回 slot 状态**，再异步启动总结生成与发送协程，彻底避免 30 秒轮询窗口内的重复执行。

### 3.3 样本不足静默与双轨投递
- **静默防刷屏**：回溯窗口内发言 `< 3` 条时，常规调度自动跳过（测试指令 `/autosum test` 则明确回显提示），避免冷群空白卡片刷屏；
- **排版投递**：抬头统一注入 `#总结 ⏰ 【群聊名】群聊定时总结（前 N 小时 / 样本 M 条）`；优先走 `sendRichMessage` 渲染原生小三角折叠卡片，网络抖动时保底转换为 HTML `blockquote expandable`。
