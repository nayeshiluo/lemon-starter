# Autosticker 回落到群原生贴纸包 —— 「群霸是不是被黑了」误判与取证

2026-10-29 实例：Owner 报「新群霸在一个群里发了一张贴图，是 https://t.me/addstickers/abshjx 里的，不是他自己的贴纸包，群霸是不是被人黑了」。

结论：**没有被黑，是设计内的三级回落**。记录此档以免下次重新推导。

## 触发链（现行代码）

1. `handlers/messages.py` F 段：非指令消息 → `increment_group_message_count(chat.id)`，达到 `group_autosticker_intervals[chat_id]` 后清零并异步 `send_sticker`。
   - journal 标志行：`Group <chat_id> message count reached <N>, sending random sticker`
   - 计数器是内存字典 `_group_message_counters`，**重启归零**，不是持久累计。
2. `services/quote_service.py:get_random_group_sticker(bot, chat_id)`：
   - ① 内存缓存 `_STICKER_CACHE`（TTL 内直接 `random.choice`）
   - ② 本群专属包 `g_{clean_id}_by_{bot_username}`、`g_{clean_id}_{vol}_by_{bot_username}`（vol 2..49；某卷张数 < 120 即视为最后一卷并 break）
   - ③ **专属包为空 → 回落到 `chat.sticker_set_name`**（该群原生绑定的官方贴纸包，由群主设定）
   - 全部为空才返回 None（只打 `logger.debug`，群内无感知）
3. `clean_id` = 群 ID 去掉前导 `100`：`<YOUR_TELEGRAM_GROUP_ID>` → `<YOUR_USER_IDENTIFIER>`。

**推论**：只要这个群从没成功做过 `/q`（专属包不存在），autosticker 必然抽到群主自己的官方包。视觉上「Bot 发了别人的贴纸」，实际是回落。

## 只读取证清单（四条对得上即可明确回复「不是被黑」）

```bash
TOKEN=$(systemctl show lemon-group-bot2.service -p Environment --value \
        | tr ' ' '\n' | grep '^TELEGRAM_BOT_TOKEN=' | cut -d= -f2-)

# 1) 群原生包是谁的 + 群实时标题（配置里的 group_names 会过时）
curl -s "https://api.telegram.org/bot$TOKEN/getChat" -d "chat_id=$CID"   # 看 sticker_set_name / title / username
curl -s "https://api.telegram.org/bot$TOKEN/getStickerSet?name=<sticker_set_name>"

# 2) 本群专属包到底有没有建过
curl -s "https://api.telegram.org/bot$TOKEN/getStickerSet?name=g_<clean_id>_by_<bot_username>"
#    -> Bad Request: STICKERSET_INVALID  == 从没建过

# 3) 代码有没有被改（比 git status 更直接，git status 常因部署常年是脏的）
ls -l --time-style=long-iso services/quote_service.py handlers/messages.py bot.py

# 4) 生产代码里下发点只有几处
grep -rn "send_sticker" --include=*.py . | grep -v -e .venv -e backups -e '\.bak'

# 5) 无外部注入入口（polling 模式 webhook url 应为空）
curl -s "https://api.telegram.org/bot$TOKEN/getWebhookInfo"
```

实例数据：`sticker_set_name=abshjx`（包标题「全能搜索 @equwei」，103 张）、
`g_3922573885_by_<PRIVATE_IDENTIFIER>_bot` → `STICKERSET_INVALID`、
`quote_service.py`/`messages.py` mtime 2026-10-18、`bot.py` 2026-10-24（未变）、
`send_sticker` 仅 `handlers/messages.py:1109`（Q 图）与 `:1737`（autosticker）两处、webhook url 为空。

## 附带发现：群名对不上时以 getChat 为准

Owner 口述「插画领域」，实际 `getChat` 返回 `title=茶话领域`、`username=Jsoo8888`。
`data/config_<bot_id>.json` 的 `group_names` 是历史快照，会过时或被改。
**核对口径**：先 `getChat` 拿实时 `title`/`username` 定位群 → 再用 chat_id 回配置比对，不要反过来信配置名或口述名去猜 chat_id。

## 附带发现：`/q` 跑过 ≠ 专属包已建

该群 `2026-10-28 16:41` 有过一次 `/q`，journal 显示 `Interactive job finished kind=quote elapsed_s=6.974`（正常收尾），但 `g_3922573885_by_<PRIVATE_IDENTIFIER>_bot` 至今仍是 `STICKERSET_INVALID`。
**所以判断「这群有没有专属包」只能查 `getStickerSet`**，不要拿 journal 的 `kind=quote finished` 或群内看到过贴图当证据 —— 那只能证明 Q 图发出去了，证明不了入库建包。
（该群为何没建包未查证，属独立线索；真去查时按 `sticker_belongs_to_chat` 的包名校验与建包日志定位，别先假设是回落逻辑的锅。）

## 处理选项（改前备份，双 Bot 同步）

1. 只关这个群：`group_autosticker_intervals[chat_id] = 0`，JSON 热生效，不用重启。
2. 改降级逻辑：专属包为空就不发（或只发专属包），彻底避免回落到群主官方包 —— 更符合「群霸只发自己包里的贴纸」的预期，属于 `.py` 改动，需 restart 两个 Bot。
3. 什么都不动，引导群友先做一张 `/q` 把专属包建起来（建包后回落自然不再触发）。

给 Owner 的回复按「先结论（没被黑）→ 证据链 → 要不要动 + 选项」组织，不要只丢代码路径。
