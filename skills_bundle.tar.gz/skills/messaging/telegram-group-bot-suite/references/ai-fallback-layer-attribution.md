# AI 降级链的分层归因（哪个节点挂了 vs 网关挂了）

2026-11-03 实测。SKILL.md 第 8 节已给出「显示什么模型 = 最后一跳」的判读法；本篇补的是**归因层**：
拿到 `fallback_index=N` 之后，怎么用最少的请求证明「到底是网关坏了、还是某一家族被上游拒了、还是配置写错了」。

## 一、先做时间锚定，再谈原因

别一上手就说「一直坏的」或「配置写错了」。两个命令就能把范围压死：

```bash
# 1) 该节点最后一次成功（只统计成功行）
sudo journalctl -u lemon-group-bot2.service --since '2026-10-28' --no-pager \
  | grep "实际使用节点: <节点名>" | tail -2

# 2) 该节点失败按天/按小时分布
sudo journalctl -u lemon-group-bot2.service --since '2026-10-28' --no-pager \
  | grep "node=<节点id>" | grep "http_status=400" | awk '{print $1,$2}' | sort | uniq -c
```

本次结果：`11:29:19` 还成功（13.5s，`fallback_index=0`），`13:33:54` 起网关开始 400，`14:19` 起每次问答都 400。

→ 结论直接变成「今天中午之后外部变了」，同时排除了「配置一直错」和「有人改坏了配置」。
**有这个锚点，汇报的可信度完全不同**；没有它，Owner 会怀疑是你/别人动过手。

## 二、横向测家族，不要只测出问题那一个

本地网关（CLIProxyAPI）通常一家挂了多家：本次 `/v1/models` 返回 22 个模型，families = `claude` / `codex` / `gemini` / `gpt`。
**只测 gemini 会得出「网关死了」的错误结论。**

| 结果形态 | 归因 |
|---|---|
| 全家族失败 | 网关 / 端口 / key |
| **只有某一家族失败，其他家族 200** | **上游对该渠道的限制**（地区 / 账号 / 策略），网关是好的 |
| 全部 200 但 Bot 仍降级 | 模型名或参数契约不匹配，去查 request 层 |

本次实测：

```
claude-sonnet-4-6      -> 200 在线
gpt-5.6-luna           -> 200 在线
gpt-6-luna             -> 200 在线
gemini-3.8-flash-high  -> 400 User location is not supported for the API use. (FAILED_PRECONDITION)
gemini-3-flash         -> 400 同上
```

同网关其他家族全 200 ⇒ 网关健康、key 有效、本机网络正常，只有 Gemini 渠道被 Google 按地区拒。
**这一步能挡掉最常见的误判**：去重启网关、去换 key、去改配置，全都是白费。

## 三、上游原文常常不在日志里，必须自己发探针

- bot 的 journal 只有 `LLM request failed: HTTP 400 (node=antigravity_gemini)` —— **没有 body**。
- `cli-proxy-api` 的 journal 只有 gin 的一行 `400 | 1.0s | 127.0.0.1 | POST "/v1/chat/completions"` —— **也没有 body**。
- 直接 `grep "location is not supported"` 全库命中 **0** 次，但这不代表没发生。

所以「400 到底是什么原因」**只能靠探针拿**。不要因为在日志里搜不到细节就停在「HTTP 400」上汇报。

## 四、探针必须自己剥 URL 后缀（本次真实踩坑）

`data/ai_endpoints.json` 里的 `url` 通常是**完整路径**（`.../v1/chat/completions`）。
再拼一次 `/chat/completions` 会得到 `.../v1/chat/completions/chat/completions` → **所有端点齐刷刷 404**，
第一眼极像「整个网关全死了」。

```python
def base_of(url: str) -> str:
    u = url.rstrip("/")
    for suffix in ("/chat/completions", "/completions"):
        if u.endswith(suffix):
            return u[: -len(suffix)]
    return u

# 用法：base = base_of(ep["url"]); call(base, key, "/models") / call(base, key, "/chat/completions", payload)
```

**判据**：如果多个不同 provider 同时返回同一个 404，先怀疑自己拼错路径，不要下「网关挂了」的结论。

## 五、账号层的现场痕迹（`~/.cli-proxy-api/`）

`config.yaml` 的 `auth-dir: ~/.cli-proxy-api`，里面每个 OAuth 账号一个 json：

```
antigravity-<邮箱>.json     ← 反重力（Google OAuth）账号，4 个
codex-<hash>-<邮箱>-plus.json
```

看 `ls -l` 的 mtime：**失败时会触发 token 刷新重试**，所以 mtime 集中在故障时间段（本次 14:21 / 14:33 / 14:39）
就是「反复刷新仍失败」的痕迹。这能佐证「不是 token 过期」（`/v1/models` 返回 200 本身就说明 OAuth 有效）。

⚠️ 只读文件名和 mtime，**不要打印 json 内容**（含 access/refresh token）。

## 六、`/v0/management/*` 走不通时的替代路径

CLIProxyAPI 有 `remote-management`（`allow-remote: false`），但本地打 `/v0/management/auth-files`
用 `X-Management-Key: <secret-key>` 和 `Authorization: Bearer <secret-key>` **都返回 401**。
不要在这上面反复试。

替代证据链（全部只读、都够用）：
1. `/v1/models` 返回 200 ⇒ 网关活着 + OAuth 有效；
2. 多家族横向 chat ⇒ 归因到具体渠道；
3. `~/.cli-proxy-api/` 的 mtime ⇒ 账号刷新痕迹；
4. bot journal 的 `fallback_index` / `http_status` ⇒ 线上真实落点。

## 七、修复选项排序（按代价从低到高）

| 选项 | 做法 | 何时选 |
|---|---|---|
| 降位 / 禁用死节点 | 从 `order` 摘掉或排末位 | 上游限制短期无解，先止损（省掉每次 ~1s 空等 + 熔断日志） |
| 换同网关内的健康模型 | 同网关其他家族已实测 200，直接改该节点 `default_model` | 只想要能力，不坚持某一家 |
| 给网关配代理 | 配置支持 `proxy` 字段，走能过地区校验的出口 | 必须用该家族 |
| 换账号重新 OAuth | 需要 Owner 提供能过校验的账号 | 账号维度被限 |

汇报必须点明：**改哪一层都动不了上游的地区限制**，别让 Owner 以为改配置就能修好。

## 八、汇报口径与脱敏

- 不要写「模型配置错了」。准确说法：配置没错，是降级链落到第 N 顺位；前 N 跳为什么挂，逐条给状态码。
- **不打印 provider 内部端点 `host:port` 与任何 key**，只报 provider 名 + 模型 ID + HTTP 状态码。
- 给时间线时用北京时间，并区分「最后一次成功」「首次失败」「当前仍失败」三个时刻。
