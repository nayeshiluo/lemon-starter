# 音乐库预热缓存架构 · 实现细节

配套 `SKILL.md` 第 2.3 节。适用于「主站出网流量受限（如 AWS 100GB 免费额度）+ 点歌太慢」的场景。

## 1. 为什么是这个架构

| 方案 | 单曲耗时 | 主站出网流量 | 结论 |
|:---|:---|:---|:---|
| 实时下载 + FFmpeg 转码 | 8~15 s | 每首 5~12 MB | 慢且吃流量 |
| 挂个人网易云大号 Cookie 走官方直链 | <2 s | ≈0 | ❌ 机房 IP 挂实名大号有封号风险 |
| 买无实名废弃小号当耗材 | <2 s | ≈0 | ✅ 可行，但需持续补号 |
| **跨机预热 + 频道 file_id 中转** | **0.5~1.0 s** | **≈0** | ✅✅ 无账号依赖、无持续成本 |

关键洞察：**主站 `send_audio(audio=<file_id>)` 时，文件由 Telegram 服务器内部复制到目标会话，
主站只发了一个几百字节的 API 请求** —— 这就是「0 流量秒发」的技术本质。
预热阶段的重活全部落在另一台机器上，与主站的流量额度完全解耦。

## 2. 第一步：创建音乐库频道（必须用真人账号）

Bot API 没有 `createChat`，**Bot 无法建频道**；且 Bot 被 `InviteToChannelRequest` 邀请会报
`Bots can only be admins in channels.`。

用 Telethon UserBot（需先停掉占用同一 `.session` 的 UserBot 服务，建完再拉起）：

```python
from telethon import TelegramClient
from telethon.tl.functions.channels import CreateChannelRequest, EditAdminRequest
from telethon.tl.types import ChatAdminRights

client = TelegramClient(SESSION_PATH, API_ID, API_HASH)
await client.start()

res = await client(CreateChannelRequest(
    title="🎵 柠檬音乐库",
    about="自动爬取的全网热门音乐库，群内 /music 点歌秒速调取",
    megagroup=False,
    broadcast=True,
))
ch = res.chats[0]

# 一行搞定「加入频道 + 提权」，不要用 InviteToChannelRequest
rights = ChatAdminRights(
    post_messages=True, edit_messages=True, delete_messages=True,
    invite_users=True, pin_messages=True,
)
await client(EditAdminRequest(channel=ch, user_id="<BOT_USERNAME>",
                              admin_rights=rights, rank="音乐库管家"))

print("RAW_CHANNEL_ID=", "-100" + str(ch.id))   # 频道 ID 需补 -100 前缀
```

拿到 ID 后验证 Bot 能发帖：
```python
await bot.send_message(chat_id=RAW_CHANNEL_ID, text="...")
```

## 3. 第二步：预热机上的爬虫

### 3.1 候选池来源

```python
网易云热歌榜  https://music.163.com/api/playlist/detail?id=3778678
网易云飙升榜  id=19723756
网易云新歌榜  id=3779629
QQ音乐热歌榜  https://c.y.qq.com/v8/fcg-bin/fcg_v8_toplist_cp.fcg?topid=26&song_num=50&format=json
```
≈ 450 首/轮，`random.shuffle` 后按需取用。

### 3.2 单曲提取链路

```text
① 若该曲有网易云 id：试官方免登录外链
   https://music.163.com/song/media/outer/url?id=<id>.mp3
   校验 content-type 含 audio/mpeg 且体积 > 400KB

② 否则/失败 → B站兜底
   搜索 "<歌手> <歌名>"（失败再退化为仅歌名）
   过滤标题含：伴奏/教学/教程/钢琴谱/简谱/鼓谱/光遇/片段/翻唱/铃声/鬼畜/reaction
   要求标题包含原歌名，且 duration 落在 165~450s
   取 https://api.bilibili.com/x/player/playurl?qn=16&fnval=0 的 durl[0].url
   FFmpeg 带 Referer 头直灌转码为 192k MP3

③ 时长校验：ffprobe 实际时长 < 140s 一律判为截断片段，丢弃并顺延下一候选
④ ID3 打标：ffmpeg -metadata title/artist/album + attached_pic 专辑封面
⑤ send_audio 上传频道 → 取回 file_id
```

### 3.3 B站会话与轻量取流

```python
sess = requests.Session()
sess.headers.update({"User-Agent": UA_PC, "Referer": "https://www.bilibili.com/"})
sess.get("https://www.bilibili.com/", timeout=15)
spi = sess.get("https://api.bilibili.com/x/frontend/finger/spi", timeout=10).json()["data"]
sess.cookies.set("buvid3", spi["b_3"], domain=".bilibili.com")
sess.cookies.set("buvid4", spi["b_4"], domain=".bilibili.com")

# cid 走 pagelist，比 wbi/view 轻且稳定
cid = sess.get("https://api.bilibili.com/x/player/pagelist",
               params={"bvid": bvid}, timeout=12).json()["data"][0]["cid"]

# qn=16 = 360P，体积仅 5~12MB，海外 CDN 不掐线
pj = sess.get("https://api.bilibili.com/x/player/playurl",
              params={"bvid": bvid, "cid": cid, "qn": 16,
                      "fnval": 0, "fnver": 0, "fourk": 0},
              headers={"Referer": f"https://www.bilibili.com/video/{bvid}",
                       "Origin": "https://www.bilibili.com"},
              timeout=15).json()
url = pj["data"]["durl"][0]["url"]
```

### 3.4 ID3 打标（用 ffmpeg，不依赖 mutagen）

```python
cmd = ["ffmpeg", "-y", "-i", mp3_path]
if cover_url:
    cmd += ["-i", cover_url]
cmd += ["-map", "0:a"]
if cover_url:
    cmd += ["-map", "1:v", "-c:v", "mjpeg", "-disposition:v", "attached_pic"]
cmd += ["-c:a", "copy",
        "-metadata", f"title={title}",
        "-metadata", f"artist={artist}",
        "-metadata", f"album={album}",
        "-id3v2_version", "3", out_path]
```
封面拉取失败时要有一条**无封面的降级路径**，否则整首歌会因打标异常而丢弃。

### 3.5 上传与索引

```python
data = {"chat_id": CHANNEL_ID, "title": ..., "performer": ..., "duration": ...,
        "caption": ..., "parse_mode": "HTML"}
files = {"audio": (f"{title}.mp3", fh, "audio/mpeg")}
r = requests.post(f"{TG_API}/sendAudio", data=data, files=files, timeout=180)
fid = r.json()["result"]["audio"]["file_id"]
# 超 50MB 时降级 sendDocument 仍可取到 file_id
```

索引落盘为 **JSONL 追加写**（`title/artist/album/duration/file_id/key/origin/crawled_at`），
外加一个 state JSON 记录 `done_keys` 实现断点续爬。

### 3.6 归一化 key（两端必须字节级一致）

```python
def norm_key(title, artist):
    def _clean(s):
        s = re.sub(r"[\(\)（）\[\]【】]", " ", s or "")
        s = re.sub(r"(feat|ft|live|remix|伴奏|翻唱|版|无损|hi-?res)", " ", s, flags=re.I)
        s = re.sub(r"[^\w\u4e00-\u9fff]+", "", s)
        return s.lower().strip()
    return f"{_clean(title)}|{_clean(artist.split('/')[0] if artist else '')}"
```

## 4. 第三步：主站同步（只传文本）

```python
# 通过 SSH 直接 cat 远端 JSONL —— 几 KB~几百 KB，不含任何音频
cmd = ["sshpass", "-p", VPS_PASS, "ssh", "-o", "StrictHostKeyChecking=no",
       "-o", "ConnectTimeout=15", f"root@{VPS_HOST}",
       f"cat {REMOTE_JSONL} 2>/dev/null || true"]
```

建表与 upsert：
```sql
CREATE TABLE IF NOT EXISTS prewarm_cache (
    key TEXT PRIMARY KEY, title TEXT, artist TEXT, album TEXT,
    duration INTEGER, file_id TEXT, cover_url TEXT, origin TEXT,
    crawled_at TEXT, synced_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
-- ON CONFLICT(key) DO UPDATE SET file_id=excluded.file_id, synced_at=CURRENT_TIMESTAMP
```

## 5. 第四步：点歌侧四段式优先级

```python
# 1A 预热库 → 0.5s / 0 流量
pre = get_prewarmed_file_id(title, artist)
if pre:
    await bot.send_audio(chat_id=..., audio=pre["file_id"],
                         title=pre["title"], performer=pre["artist"], caption=..., ...)
    return
# 1B 本机 file_id 缓存 → 0.1s
# 2  官方直链/官方 Eapi
# 3  实时 B站提取兜底
```
查询失败（file_id 过期等）要**静默降级到下一段**，不能让预热库故障变成点歌失败。

### 5.1 运行时反向写入（群友点播 → 预热库）

预热库只靠爬虫装歌是不够的：**群友真实点播过的歌才是最准的需求信号**，必须沉淀下来。

三个分支都要写回（用同一个 `norm_key`）：

```python
def save_group_prewarm(song_info, tg_file_id):
    key = norm_key(song_info["title"], song_info["artist"])
    conn.execute("""
        INSERT INTO prewarm_cache (key, title, artist, album, duration, file_id, cover_url, origin)
        VALUES (?,?,?,?,?,?,?, '群友点播')
        ON CONFLICT(key) DO UPDATE SET
            file_id = excluded.file_id, duration = excluded.duration,
            synced_at = CURRENT_TIMESTAMP
    """, (key, ..., tg_file_id, ...))
```

调用点：
- 1A 预热命中后 → 也写一次（幂等刷新，顺带把 `origin` 补上）；
- 1B 本机 `file_id` 缓存命中后 → 写一次（把老缓存**迁移**进统一预热表）；
- 2/3 实时提取并 `send_audio` 成功后 → 写一次（**这是最关键的一条**）。

**为什么不直接用 `song_cache` 表按平台 ID 存**：QQ 音乐的 ID 是字符串，
`INTEGER PRIMARY KEY` 会抛 `datatype mismatch` 且被宽泛 `try/except` 吞掉 —— 
群友点播的歌**看起来成功了，实际全都没缓存**。用归一化 `title|artist` 做键就彻底绕开了这个坑。

### 5.2 双向同步（回推，防预热机重复爬）

主站同步脚本在「拉取远端 JSONL」之后，追加一步「把本地群友点播条目推回远端 JSONL」：

```python
payload = "\n".join(json.dumps(rec, ensure_ascii=False) for rec in local_group_records) + "\n"
b64 = base64.b64encode(payload.encode("utf-8")).decode("ascii")
remote_cmd = f"echo '{b64}' | base64 -d >> {REMOTE_JSONL}"   # base64 规避引号/中文转义
```

预热机爬虫读 JSONL 的 `key` 做去重，因此回推后它不会再重复爬这些歌 —— 
省下预热机带宽与频控额度，且让两侧库存收敛。代价只有几百字节/首。

## 6. 第五步：自动化

预热机 `/etc/systemd/system/lemon-music-crawler.{service,timer}`：
```ini
# service
Type=oneshot
ExecStart=/root/run_crawl.sh
TimeoutStartSec=1200
# timer
OnBootSec=5min
OnUnitActiveSec=30min
AccuracySec=1min
```
`run_crawl.sh` 首行加单实例锁：
```bash
exec 9>/var/lock/lemon_music_crawl.lock
flock -n 9 || { echo "[skip] 上一轮仍在运行"; exit 0; }
```

主站侧用静默看守 cron（`no_agent` 模式）：同步脚本在「无净增 / 远端无新数据」时
**必须 stdout 为空**，这样才不会每 15 分钟打扰用户一次。

## 7. 实测数据（参考基线）

| 场景 | 耗时 |
|:---|:---|
| 预热库命中 | **0.467 / 0.470 / 0.484 / 1.035 秒** |
| 本机 file_id 缓存命中 | ~0.1 秒 |
| 首次实时提取（B站轻量流 + 转码） | 8~13 秒 |

流量账本：
- 爬虫下载 + 转码 + 上传频道 → 全部由预热 VPS 承担
- 主站同步 → 每 15 分钟几 KB 文本（每天 < 1MB）
- 群内点歌命中 → 主站 ≈ 0

## 8. 踩坑清单

1. **Bot 不能建频道** → 用 Telethon UserBot；建频道前需先停掉占用同一 `.session` 的服务。
2. **`InviteToChannelRequest` 无法邀请 Bot** → 直接用 `EditAdminRequest` 提权，隐式完成加入。
3. **`file_id` 是 Bot 专属** → 预热上传与线上点歌必须同一个 Bot Token。
4. **归一化 key 不一致 = 永久静默不命中** → 两端共用同一份 `norm_key` 实现。
5. **`callback_query` 未先 `answer()`** → `Query is too old` 报错 + 用户侧一直转圈。
6. **旧版 ffmpeg 不支持 `-reconnect_delay_total_max`** → rc=8、产物 0 字节、极易被误判为「提取失败」；
   必须用 `ffmpeg -h protocol=http` 做运行时能力探测后再决定是否追加该参数。
7. **时长下限校验不可省** → 没有 `< 140s` 拦截，就会把铃声/试看片段当整首歌发出去。
8. **`send_video` 有 50MB 硬限制** → 预热音频一般安全，但视频链路仍需压缩管线兜底。
9. **字符串歌曲 ID 撞上 `INTEGER PRIMARY KEY`** → `sqlite3.IntegrityError: datatype mismatch`；
   QQ 音乐的 songmid 是字符串，必须改用 `key TEXT PRIMARY KEY` 的归一化表。
10. **宽泛 `try/except Exception + logger.debug` 会吞掉缓存写入失败** → 
    症状是「点播成功过但下次还要重下」，可潜伏数周。缓存写入路径至少 `logger.info` 出真实异常。
11. **候选池是会耗尽的** → 热歌/飙升/新歌/QQ 热歌合计约 450 首，
    按每 30 分钟 12 首的节奏约 1.5~2 天就爬完，之后会自动变慢（只捡新上榜歌曲）。
    这是**预期行为不是故障**，需主动向用户说明，并预留「再加歌单源（歌手榜/风格榜/怀旧金曲）」的扩容位。
12. **往另一台机器上叠中转前必须先实测它的吞吐** → 不要凭直觉认为「多一台节点就更省/更快」。
    本次实测：某洛杉矶 VPS 拉 B站 CDN 已经 0 B/s 超时（带宽吃紧），
    而主站直连 Telegram 官方仅 0.48s RTT —— 再叠一层只增加跳数、更慢更脆。
    正确结论是**保留现有最优路径**，靠「关掉该群视频开关」这类功能级开关来控制主站流量，而不是硬加中转。
13. **第三方音乐频道搬运的防转发保护 (`ChatForwardsRestrictedError`)** → 
    优质音乐源频道（如 `@FLAC_HR`、`@DJZYH`、`@MP3_320K`）几乎 100% 开启了 Telegram 的「禁止保存/转发内容保护」。
    - **避坑 1（协议级死穴）**：`client.forward_messages()` 与 `client.send_file(dest, msg.media)` 均会直接抛出 `ChatForwardsRestrictedError: You can't forward messages from a protected chat`，**无法做零流量秒级指针转发**；
    - **避坑 2（实时提取的大文件流量黑洞）**：不能在受流量限额的主站（如 AWS）上对这些保护频道做「群友点歌实时边下边发」—— 尤其是 FLAC 无损文件（50MB~80MB），从 Telegram 数据中心拉取就要 18 秒，重新上传又消耗一次出网流量，单曲消耗 130MB+ 且极易触发 Telegram Bot API 50MB 限制或网络超时；
    - **正确架构**：必须由**无限流量的独立 VPS 在后台异步慢慢爬取**（下载二进制流 → 校验时长/码率 → 过滤超大体积 → 重新发布上传到专属音乐库频道产生新的无保护 `file_id` → 同步给主站）。
    - **避坑 3（Telethon 反序列化 Constructor ID 异常）**：新版 Telegram 服务端下发某些特定通知时，Telethon 可能抛出 `Could not find a matching Constructor ID for TLObject 31774388`。上传成功后捕获此异常，并在稍等 1~2s 后通过 `client.iter_messages(dest, limit=2)` 核验是否真实发送成功，避免误报失败而重复上传。
14. **运维机器人日志集成与每日汇总通知 (`music_daily_report_loop`)** →
    用户需要掌握音乐库的扩容进度，但讨厌频繁打扰：
    - **命令查询**：在运维 Bot 注册 `/musiclib`（或 `/music`），返回预热库总量、今日新增、来源分布（热歌/飙升/新歌/群友点播）、群点缓存数及最近同步时间；
    - **定时简报**：后台守护任务固定在每天早上 02:00（北京时间）准时向管理员推送每日汇总卡片；
    - **时区陷阱**：数据库中若存 UTC 时间戳，计算「今日新增」时必须转为 `datetime(..., '+8 hours')` 或统一时区比对，否则会导致「今天明明爬了上百首，统计却显示今日新增 +0」的虚假汇报。

15. **多 Bot 复刻时的权限配置隔离与能力共享 (Multi-Bot Permission Isolation)** →
    在同一台服务器上跑多个 Bot 实例（主 Bot 与复刻分身 Bot，如 `@yecaodi_bot` 与 `@qunba_bot`）时：
    - **严禁共用单个 `config.json` 的开关与授权群列表**：若多个 Bot 共用一份群组功能开关字典，会导致一个群里的功能变动影响所有 Bot，特别是「原 Bot 进群默认全功能开放，而新 Bot 进群要求默认只开贴图、其余关闭」这种差异化业务需求无法实现；
    - **正确架构**：
      1. **配置文件按 `BOT_ID` 物理切分**：从 `TELEGRAM_BOT_TOKEN` 的前缀自动拆解 `BOT_ID`，分别绑定独立的文件（如 `data/config_{BOT_ID}.json`），群授权名单 `authorized_groups` 与功能开关 `group_features` 完全独立持久化；
      2. **差异化入群默认开关策略**：在 `config.py` 中根据 `BOT_ID` 判断：原 Bot 返回全 `True`，新 Bot 仅 `quote` 为 `True` 其余为 `False`；
      3. **公共资产共享**：底层音乐缓存 `music_cache.db`、`quote-api` 渲染服务、群名称持久化缓存字典 `group_names`、Owner ID 保持全局双向共享，既保证业务数据互通，又彻底阻断权限串线；
      4. **`/settings` 列表群名缓存避坑**：新 Bot 若尚未被拉入某群，调用 `get_chat(chat_id)` 会抛出 `Bad Request: chat not found`；必须在共享配置中维护全局 `group_names: { "chat_id": "群名" }`，面板优先读缓存，确保 100% 优雅展示 `👥 【群聊名称】 (群组ID)`。
16. **群组级别专属 VIP 权限隔离 (Per-Group Isolated VIP Management)** →
    - **业务诉求与风险**：用户要求「两个 Bot 的每个群组 VIP 名单相互独立」，在群 A 赋予某群友特权（如 `/addvip` 贴纸收录、免限额总结、禁言管理），该用户在群 B 必须沦为普通成员，严禁产生跨群越权！
    - **架构设计与数据落盘**：
      - 在各自 Bot 的独立配置文件中设立两层字典：`authorized_users: []`（全局管理员特权）与 `group_authorized_users: { "chat_id": [uid1, uid2] }`（本群专属特权）；
      - **操作语义上下文感知**：
        - 在群聊中使用 `/addvip`（回复某人或输入 UID）：精准识别当前 `chat.id`，仅写入该群专属列表并为该群刷新群内自定义菜单权限；
        - 在私聊中使用 `/addvip`：作为全局 VIP 写入；
      - **全链路判定下沉**：所有权限检测入口（`is_user_privileged`、`can_use_qs`、`can_manage_mute`）均必须透传 `chat_id`，取本群特权与全局特权并集；查询指令 `/viplist` 与删除指令 `/delvip` 在群聊中同样精准局限于当前群，绝不串线其他群组。
17. **Telethon 跨机房复制 Session 导致 `AuthKeyDuplicatedError` 永久暴毙** →
    - **事故复盘**：在部署 VPS 频道搬运爬虫（`channel_music_harvester.py`）时，若直接将主站（AWS）的 `.session` 文件拷贝到远端机器使用，或两地不同 IP 同时发起网络请求，Telegram 服务端会立即返回：
      `AuthKeyDuplicatedError: The authorization key was used under two different IP addresses simultaneously, and can no longer be used.`；
    - **不可逆后果**：此错误并非临时网络抖动，而是 Telegram 云端将该 AuthKey **永久拉黑注销**。任何使用该 Key 的脚本均再也无法握手 Telegram DC，systemd 定时器与服务会连带崩溃退出并变为 `inactive (dead)`，造成搬运任务彻底静默停摆；
    - **排查与验证技巧**：
      1. 检查远端搬运日志（如 `/root/channel_harvest.log`）是否有 `AuthKeyDuplicatedError` 或 `two different IP addresses simultaneously`；
      2. 运行单行探测 `client.connect()`，若抛出 `database is locked` 说明当前有本地服务正在独占该 sqlite session；若抛出 `AuthKeyDuplicatedError` 则确诊凭证已在服务端报废；
    - **铁律防护**：专机专号专用！VPS 上的频道爬虫必须单独走一次登录认证生成独立的 Session，严禁跨公网 IP 节点复制或共用任何 active session 文件。
18. **音乐爬虫时长过滤下限 (`MIN_AUDIO_SEC`) 设得过死导致入库停滞** →
    - **隐蔽陷阱**：爬虫为了过滤几十秒的试听片段或光遇琴谱，容易写死 `MIN_AUDIO_SEC = 140`（必须 >= 2分20秒）；
    - **实际业务痛点**：大量现代流行飙升榜单、抖音热歌、高燃短混音及流行电音（如《梦特黑》137s、《LOST》138s、《妒恨 Beat》136s、《Be My Lover》124s）的正曲长度刚好在 **115s ~ 139s** 之间。过高的门槛会导致爬虫虽然每 30 分钟按时轮询、频繁命中直链，但全部被判定为 `❌ 时长不足丢弃`，造成入库数量长期停滞不动（如卡死在 378 首）；
    - **调优准则**：将正曲过滤门槛从 140 秒适度下调至 **80s ~ 90s**，既能 100% 挡住 30s 试听片段与铃声，又能放行数以百计的 2 分钟优质正版流行单曲。
19. **无头 VPS 上 Telethon 两步验证分离式登录与私有频道自动加群提权闭环 (Headless Telethon Auth & Auto-Promotion Pipeline)** →
    - **无头环境登录痛点**：在远程无交互终端（如海外 Linux VPS）为 Telethon 生成独立 Session 时，传统交互式提示会阻塞终端，难以自动化；
    - **解耦式登录流水线**：
      1. 第一阶段 `req`：实例化 `TelegramClient` 发起 `send_code_request(phone)`，将 `phone` 与 `res.phone_code_hash` 持久化到临时 JSON 状态文件，立即安全断开释放网络连接；
      2. 用户将接收到的验证码与两步验证密码通过聊天窗口发回；
      3. 第二阶段 `verify`：加载状态文件调用 `sign_in(phone, code, phone_code_hash)`，遇到 `SessionPasswordNeededError` 自动提交密码完成鉴权，测试 `get_me()` 并销毁状态文件，收紧 Session 文件权限为 `chmod 600`。
    - **私有广播频道加群与提权死锁排障**：
      - **死锁 1：新账号直接调用 `get_entity(channel_id)` 报 `ValueError: Could not find the input entity for PeerChannel`**：新账号未加入目标私有频道时，Telegram 服务端拒绝暴露频道实体；
        *解法*：由拥有管理权的线上 Bot 调用 `exportChatInviteLink` 生成带 hash 的临时邀请链接，新账号通过 `ImportChatInviteRequest(hash)` 静默秒级加群。
      - **死锁 2：加入频道后无发帖权限（`admin_rights: None`）且普通 Bot 无法提权成员**：广播频道普通成员无法发布音频，而普通 Bot 默认没有 `can_promote_members` 权限；
      - **死锁 3：主站 UserBot 直接对新号 `EditAdminRequest` 报 `Could not find the input entity for PeerUser`**：UserBot 内存没有目标新账号的 InputEntity 缓存；
        *解法*：UserBot 端通过 `client.iter_participants(target_chat)` 遍历频道在籍成员定位新用户对象，拿到真实 Entity 后再执行 `EditAdminRequest(admin_rights=ChatAdminRights(post_messages=True, ...))`，达成 100% 全自动提权，用户无需手动去频道面板操作。

## 9. 汇报口径（用户偏好）

本用户对「看起来完成」零容忍，汇报时必须遵守：
- **先给实测数字再下结论**：`命中 0.467 / 0.470 / 0.484 / 1.035 秒` 这种真实压测数据，
  而不是「已经大幅优化」这类形容词；
- **流量账本要逐条列清**（谁承担哪一段），因为用户在严格守住 AWS 100GB/月免费出网额度；
- **主动交底代价与边界**：例如「候选池 1.5~2 天会爬完」「个人大号挂机房 IP 有封号风险」，
  即使会显得方案不那么完美，也必须先讲清楚；
- **发现旧 Bug 要当场承认并说明影响面**（例：字符串 ID 导致群友点播缓存全部静默丢失），
  不要淡化或包装成「优化」。
