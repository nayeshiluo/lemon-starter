# 运维 Bot 安全与健壮性审计清单（只读）

对已上线的 Telegram 运维 Bot（本项目 `lemon-ops.service` / `/home/ubuntu/lemon-ops-bot/`）做一次整体审计时按此顺序执行。全部步骤只读，不改代码。

## 0. 先定位对象，不要假设

```bash
systemctl list-units --type=service --all --no-pager | grep -iE "ops|bot|lemon"
ps -eo pid,ppid,etime,rss,cmd --sort=-rss | grep -iE "bot|ops" | grep -v grep
systemctl status <svc> --no-pager -l
systemctl cat <svc> --no-pager          # 含 .service.d/ drop-in
```

同时核对 `NRestarts`、`MemoryCurrent`、drop-in 里的 `Environment=`。**注意**：`journalctl | grep -c "Started <名称>"` 这类计数容易因 unit 名大小写/连接符不同而得出 0 的假阴性，别据此断言"从未重启"，用 `systemctl show -p NRestarts`。

## 0.5 用 @username 反查确认对象（用户报名字时必做）

用户常以 `@xxx_bot` 指代某台 bot 并要求「确认一下」。不要靠菜单/记忆猜，直接用 env 里的 token 调 `getMe`：

```bash
cd /home/ubuntu/lemon-ops-bot && python3 - <<'EOF'
import json, urllib.request
env = {}
for line in open('/home/ubuntu/.config/lemon-ops-bot.env'):
    line = line.strip()
    if '=' in line and not line.startswith('#'):
        k, v = line.split('=', 1); env[k] = v.strip().strip('"').strip("'")
t = env['LEMON_OPS_BOT_TOKEN']
r = json.load(urllib.request.urlopen(f"https://api.telegram.org/bot{t}/getMe", timeout=15))
u = r.get('result', {})
print("ok=", r.get('ok'), "username=@" + str(u.get('username')),
      "name=", u.get('first_name'), "id=", u.get('id'))
EOF
```

只打印 `username/first_name/id`，**绝不回显 token**。确认绑定后再动代码；同一台机器上常有多只 bot（群霸双 Bot、userbot、subinfo），错改代价很高。

## 1. 鉴权面（最高优先级）

```bash
grep -nE "ADMIN|ALLOW|whitelist|is_admin|OWNER_ID" main.py | head -40
grep -nE "CallbackQueryHandler|async def .*callback" main.py
grep -nE "add_handler" main.py            # 逐个核对每个 handler 首行是否有 is_admin
```

判定标准：
- `callback_handler` **首行**统一拦截（`if not is_admin(user_id): await query.answer(...); return`）—— 这是正确设计，比在每个分支里各写一遍可靠得多。
- 每个 `CommandHandler` 的函数首行都要有 `is_admin`，逐个抽查，不要只看有名字像 `_command` 的。
- `MessageHandler`（`filters.FORWARDED` / `filters.Document.ALL` / `filters.TEXT`）同样要拦。

## 2. 凭据与注入面

```bash
grep -nE "(sk-|ghp_|xoxb|bot[0-9]{8,}:)" *.py *.json        # 明文密钥
grep -ohE "os\.(environ\.get|getenv)\(['\"][A-Z_]+" *.py | sort -u
grep -nE "shell=True|os\.system|subprocess\.(run|Popen|check_output)" main.py *.py
ls -la <env file> <config>.json                              # 期望 600
```

- 密钥应集中在 `/home/ubuntu/.config/lemon-ops-bot.env`（600），由 `main.py` 顶部 `setdefault` 读入；token 变量名是 `LEMON_OPS_BOT_TOKEN`（不是 `BOT_TOKEN`），缺失时应 `raise RuntimeError` 拒绝启动。
- 配置写入要原子 + 私有：`tempfile.mkstemp` → `json.dump` → `os.replace`，`makedirs(mode=0o700)`。看到直接 `open(path,'w')` 就是隐患。
- 全 list 参数调用 subprocess = 无注入面。**但**要同时看 `sudo -n -l`：若 ubuntu 有 `NOPASSWD: ALL`，则"当前无注入面"是运气而非设计，将来任何一处 shell 拼接即等于 root。这属结构性风险，审计里如实标注，不建议顺手改。

## 3. 后台守护协程

```bash
grep -nE "create_task|async def .*_loop" main.py
```

每个 loop 必须有**外层** `try/except Exception` + `await asyncio.sleep(...)` 兜底，否则一次未捕获异常会让 task 静默死亡，而 systemd 仍显示 `active (running)` —— 这是最难发现的故障形态。

## 4. 定时触发的时间窗语义

对比不同 loop 的写法，**同一份代码里标准不一致就是 bug 信号**：
- 有补跑（catch-up）：`current_time_str >= target_time and last_sign_date != today` ✅
- 只有精确匹配：`now.strftime("%H:%M") == "02:00"` ❌ 30s 轮询下，该分钟若被长任务占住 >60s 就当天静默丢失，且无补跑。

## 5. 命令别名冲突（高频真 bug）

```bash
grep -oE 'CommandHandler\(\[?"?[a-z_", ]+' main.py
grep -n "cancel" main.py
```

把注册表与引导文案交叉比对。本次实测缺陷：`CommandHandler(["stop","cancel","abort"], stop_upload_command)` 让 `/cancel` 变成**紧急停止全部上传**，而影视检索引导文案正写着"随时发送 /cancel 取消"。用户按提示操作 = 误杀全部下载/做种/上传并清空缓存，且 `USER_STATES` 未被清，下一条普通消息还会被当搜索词。
修法：从 stop 别名摘掉 `cancel`，单独注册只清状态的 `cancel_command`。

## 6. 群内开放命令的越权链条

群内对非管理员开放的命令（`/ai`、`/summary`）要追到 IPC 另一端：

```bash
grep -n "def send_ipc_command" -A25 main.py
cd /home/ubuntu/lemon-userbot && grep -n "summary_chat" -A12 userbot.py
```

本次实测：`/summary` 在群内对非管理员开放，且接受任意 `-100xxx` 参数透传给 UserBot 的 `summary_chat`，UserBot 侧**无群白名单校验** → 群友可让 UserBot 总结它所在任意群/频道最近 N 条消息。越权范围 = UserBot 所在的全部会话。
修法：群内非管理员强制忽略 chat_id 参数，只用 `update.effective_chat.id`。

## 7. 成本面

`/ai` 若群内全员开放、无频控、无长度上限，且共享 Gemini/Codex 同池额度，会被刷出 429 连锁影响主链路。审计中作为独立条目列出，建议每用户冷却 + 单次长度上限。

## 8. 并发与工程卫生

- **文件级 IPC 单槽**：固定 `ipc_cmd.json`/`ipc_res.json` + 轮询，且每次调用前 `os.remove` 响应文件 → 并发请求互删响应、串结果。单人使用时概率低，一旦把 `/ai`/`/summary` 开放到群就上升。
- **`except: pass` 计数**：`grep -nE "except.*:\s*$" -A1 main.py | grep -cE "pass$"`。本项目 27 处，与"错误必报禁止静默"的偏好冲突，逐处过一遍，区分可接受的降级与吞掉真错。
- **备份堆积**：代码目录里 `.bak` 可达 1.6M（main.py 就 15 个版本，其中一个还是 root 所有）—— 真要回滚时容易选错。审计提一句，别自作主张清理。
- **日志**：走 journald 无需轮转；`journalctl --since "3 days ago" | grep -iE "traceback|error|exception|failed"` 后要**逐条看内容**，全是 `NetworkError/httpx.ReadError` 自愈 WARN 就是健康，有 Traceback 才是真错。

## 9. 汇报格式（用户明确要求）

- **结论先行**，一句话给总体判断 + 有几个真问题。
- **采样时间必须实读**：`TZ=Asia/Shanghai date`，与指标一起给，标明 CST/UTC。不许用回复时间冒充。
- **分等级**：🔴 P1 真 bug 会误伤 / 🟠 越权与成本 / 🟡 次要。每条给「现象 → 实际后果 → 修法」。
- **区分已验证事实与推断**：抽查过哪些 handler 要写清；没读到的（如 UserBot 侧逻辑）标"待核实"。
- **内存口径**：`systemctl show -p MemoryCurrent` 是字节；`systemctl status` 的 `Memory: 12.1M` 与 ps RSS 不得混同；swap peak 是历史峰值，不代表当前压力。
- 末尾问一句是否动手修 P1/P2，不要未经授权直接改代码。
- **内存口径补充**：重启后 1 分钟内的 RSS 会明显高于稳态（实测同一进程：运行 4h 时 12.1MiB，刚重启 1min 时 68MiB）。别把新鲜启动的采样当稳态成本，也别反过来把 4h 的 12MiB 说成固定成本 —— 单次采样只支持该时刻判断。

## 10. 修复与验收流程（用户说「确认没问题就解决」时走这里）

授权后的顺序固定：**备份 → 最小改动 → 静态校验 → 重启 → 日志零 error → 给可核验证据**。

### 10.1 备份（改前必做）
```bash
cd /home/ubuntu/lemon-ops-bot
cp -p main.py "main.py.bak-auditfix-$(TZ=Asia/Shanghai date +%Y%m%d-%H%M%S)"
```

### 10.2 三类典型修复的最小改法

**A. 命令别名冲突（`/cancel` 误杀上传）**
- `CommandHandler(["stop","abort"], stop_upload_command)` —— 把 `cancel` 摘出去；
- 新增 `cancel_command`：`USER_STATES.pop(user_id, None)` + `clear_user_waiting_lookup(user_id)`（包 try/except，模块可能没有该函数），回一句「已取消当前输入状态，未影响任何下载/上传任务」；
- 单独注册 `CommandHandler("cancel", cancel_command)`；
- 引导文案里的 `/cancel` 不用改 —— 改代码去对齐文案，别反过来改文案迁就 bug。

**B. 群内越权指定 chat_id（`/summary`）**
- 最小改法在 ops-bot 侧加门，不动 UserBot（改对端风险大、易破坏既有链路）：
```python
can_override_chat = is_admin(user_id)
...
if arg_str.startswith("-100") or ...:
    if can_override_chat:
        try: target_chat_id = int(arg_str)
        except ValueError: pass
```
- 非管理员只能总结当前群，`target`（条数）仍可用。改完在对端代码注释里记一句「UserBot 侧仍无群白名单，本端是唯一闸门」，方便下次审计。

**C. 日报静默丢失（`== "02:00"`）**
- 改 `>=` 容错补发 + `last_report_date` 落盘（见 SKILL.md 第 5 条的完整代码）；
- 上线时预置当天日期，避免重启瞬间推一张旧卡片；若当天已错过，明确告知「今天跳过，明天起正常」，不要偷偷补发。

### 10.3 验收（三层，缺一层就不算完成）
```bash
# ① 编译
/home/ubuntu/.hermes/hermes-agent/venv/bin/python3 -m py_compile main.py
# ② 静态断言：别名拆分真的落到注册表（脚本在本 skill 的 scripts/verify_handlers.py）
python3 <skill>/scripts/verify_handlers.py main.py \
  --expect cancel:cancel_command \
  --expect stop:stop_upload_command \
  --forbid-in stop_upload_command:cancel
# ③ 重启 + 日志
sudo -n systemctl restart lemon-ops.service && sleep 6
systemctl is-active lemon-ops.service
systemctl show lemon-ops.service -p NRestarts -p MainPID -p MemoryCurrent --no-pager
journalctl -u lemon-ops.service --since "5 min ago" --no-pager | grep -icE "traceback|exception|error"
```
- `grep -c` 命中 0 条时退出码是 1，不是命令失败 —— 看数字别看 exit_code。
- 重启后日志应出现 `Starting LemonOps Telegram Bot...` / `commands set successfully` / 各守护任务 `started`，即证明协程真的在跑。
- 静态断言只能证明注册表正确，**不能证明交互体验**；结尾请用户真发一条 `/cancel` 验证（会回「当前没有待取消的操作」），如实说明这一层未自测。

### 10.4 收尾汇报
- 列出改了哪几处、每处「原状 → 现在」；
- 明确哪些是**顺带修的**（如日报时间窗），哪些**按用户要求没动**（如 `/ai` 频控、27 处 `except: pass`、备份堆积）—— 后者要给出一句风险说明并等用户点头，别擅自扩范围。

---

## 11. 审计「非本机自研 / 独立部署的第三方 bot」

触发语：「XX 机器人你也审计一下」。对象是**另一台机器上的另一个 bot**（如 `/opt/ad-killer`，代码不是我们写的、不是 git 仓库）。§0~§9 的维度照样适用，但下面 6 条是这类对象特有、且自研 bot 审计时不会遇到的：

1. **先确认是不是 git 仓库**（`git rev-parse --is-inside-work-tree`）。非 git 意味着**没有任何版本控制**，任何修复前必须手工 `cp` 备份并带时间戳；也不能靠 `git diff` 回顾历史改动，只能靠文件 mtime 推断。
2. **凭据位置可能有两份，别改错那份**。systemd `LoadCredential=` 注入的 bot，真凭据在 `/etc/<name>/`（`bot-token` / `ai-key` / `config.json`，应全 600）；而 `/opt/<name>/config.json` 往往是部署时的历史副本（实测 644、329 字节、无密钥）。**只收紧权限到 600，不要删** —— 删掉可能打断某个仍读它的运维脚本，而它不含密钥，风险是「全局可读」不是「泄露」。
3. **崩溃史看 exit code，不看当前 active**。`systemctl show -p NRestarts` 只给次数，会把手动重启和真崩溃混在一起。必须 `journalctl -u <svc> --since "7 days ago" | grep -iE "exited|failed|Main process"` 逐条看，实测 7 天 41 次启动里只有 1 次是真崩溃（exit 1），其余全是部署重启 —— 只报「41 次启动」会吓到用户，只报「active」会漏掉那次崩溃。
4. **数据层单列一项**：SQLite 在 WAL 模式时 `cp` 会得到撕裂副本（`-wal` 未合并），备份必须用 `sqlite3` 在线 `backup()` API + `PRAGMA integrity_check`。另外顺手查 `state.db` 是否有 0 字节残留（实测 `/opt/ad-killer/state.db` 就是 0 字节 root 文件，真库在 `/var/lib/ad-killer/`）。
5. **它自己的「探针」优先于你新写的阈值**：远端若已有 `health_snapshot.py` 这类只读采集器，监控端直接调它、采信它内部的 alive/stale 判定，避免两套阈值漂移（详见 SKILL.md §30）。
6. **退役前必须核实「消费者为零」**。旧隧道/旧服务被判 `retirement_approved: false` 往往是因为「外部依赖未核实」，不是「还在用」。核实手段：① 停之前在目标侧 `ss -lntp` 确认监听；② 停之后确认对端端口消失；③ 关键——**停掉后跑一次真实业务探针**（如 `AI_PROBE ok 200`）证明主服务不依赖它。只做①②就报「已退役」可能把主服务打死。

## 12. 「字段看着自相矛盾」时，先读判定代码再统计分布

实测踩坑：`profile-daily` 输出

```json
{"status":"partial","coverage_complete":false,"profile_attempts":19,"remaining_unchecked":0}
```

`coverage_complete: false` 与 `remaining_unchecked: 0` 看起来不可能同时成立，第一反应是「逻辑 bug」。读 `profile_ads.py:239` 才发现是**三个独立维度**：

```python
complete = profile_ok and history == 'available' and not media_unreviewed
coverage = 'full' if complete else 'profile_only' if (profile_ok and history == 'not_exposed' and not media_unreviewed) else 'partial'
```

- `remaining_unchecked` = **扫描队列**是否清空
- `coverage_complete` = **单人证据面**是否完整（受 Telegram 隐私 `not_exposed` 限制）
- `status` = 综合判定

真实分布（367 条）验证：`profile_only` 286 条（77.9%，成员未开放个人频道历史）、`partial` 49 条（含未审媒体）、`full` 32 条；`decision` 全部 `no_signal`。**属客观隐私限制下的正常结果，不是故障。**

**铁律**：
- 任何 `字段: 值` 让你觉得「不可能」时，先 `grep -n "<field>"` 找到赋值处读条件，**再**用 `GROUP BY` 统计真实分布。
- 不要凭字段名推断语义 —— `unchecked` 在写代码的人脑子里可能指「队列」而不是「证据」。
- 误判成故障的代价是去修一个不存在的问题，比不修更糟（会引入真 bug）。
- 汇报时要把「我一开始猜的是什么、实际是什么」讲出来，别只给正确结论 —— 用户需要知道结论的可信度来自数据而不是你的直觉。


