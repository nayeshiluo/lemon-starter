# EMOS 影视平台自动化上传与积分获取规范 (EMOS Upload & Reward Automation)

## 1. 架构总览
EMOS (emos.club) 是基于 Cloudflare R2 / S3 多分片与 TUS 协议的影视流媒体与积分平台。用户上传视频或每日签到打卡可获得“胡萝卜（Carrot）”积分奖励。

```
[Telegram 用户发送 .torrent]
          │
          ▼
[Ops Bot 弹出三种命名选择: 🤖 自动改名 | ✏️ 手动改名 | 📄 保持原名]
          │
          ▼
[下发 qBittorrent-nox 本地高速拉取]
          │
          ▼
[下载完成 ➔ 执行所选命名规则 (智能识别/自定义/原始文件名)]
          ├─────────────────────────────────────────┐
          ▼                                         ▼
[异步推送至 Google Drive /上传文件/]        [EMOS API 自动化流水线]
                                                    ├─ 1. POST /api/identify ➔ 失败回退: /api/video/search + /api/video/tree (智能解析)
                                                    ├─ 2. POST /api/upload/getUploadToken (获取分片令牌: zn_r2_upload)
                                                    ├─ 3. POST /api/upload/multipart/{id}/presign (生成多块上传 URL)
                                                    ├─ 4. 多线程并发 PUT 分片至 Cloudflare R2
                                                    ├─ 5. POST /api/upload/multipart/{id}/complete (合并分片)
                                                    ├─ 6. POST /api/upload/video/save (关联剧集并发布)
                                                    └─ 7. GET /api/upload/video/base (双重回查校验挂载 · 失败熔断防删)
          │                                         │
          └───────────────────┬─────────────────────┘
                              ▼
        [Telegram Bot 推送完工通知卡片与最新胡萝卜积分]
```

### 1.1 三重命名策略与 TMDB 权威刮削规范 (TMDB Standard Naming)
- **TMDB 权威预检索（最高优先级）**：在执行任何命名与改名前，系统优先调用 TMDB (TheMovieDB) 官方 API（`language=zh-CN`），根据清洗后的基础标题与年份检索权威中文片名与首播年份，自动格式化为标准规范：
  - 电影：`《官方中文标题 (首播年份)》.ext`（例如 `复仇者联盟 (2012).mp4`）
  - 剧集：`《官方中文标题》 S01Exx.ext`（例如 `航海王 S01E1174.mp4`）
  - 彻底去除压制组与发布组的广告乱码（如 `PTerWEB`、`H265`、`2160p` 等），确保命名 100% 干净防错。
- **🤖 智能自动改名（Auto）**：TMDB 优先 ➔ 回退至 EMOS `identify_video` 识别；
- **✏️ 手动指定改名（Manual）**：Telegram 提示管理员在聊天框回复期望的自定义文件名后执行改名；
- **📄 保持原始名称（Raw）**：完全保留种子内原始视频文件名不变。
- **全局与单次任务控制**：在 Bot 的 EMOS 控制面板上支持一键切换全局默认模式，单次接收种子时亦弹出 Inline Keyboard 供快速点选。

### 1.2 分布式节点跨机直传架构 (Distributed Remote VPS Worker)
- **痛点与陷阱**：在多机器协作拓扑中，下载引擎（qBittorrent）通常部署在廉价大流量 VPS 上，而主控 Bot 运行在云主机（如 AWS EC2）。若主控 Bot 在本地寻找下载文件，会导致本地找不到文件而误跳过上传，或把大文件拉回本地造成 AWS 流量超标。
- **解决方案**：
  - 下载文件实际保存在远端 VPS 硬盘；
  - 主控 Bot 仅通过 SSH/IPC 驱动远端 VPS 运行独立的 `emos_uploader.py`；
  - 由远端 VPS 本地直传 Cloudflare R2，实现 **0 主机流量消耗、超高速分片上传与 100% 真实挂载**。

---

## 2. 核心 API 规范与 Python 调用实现

### 2.1 鉴权规范
- 请求头统一携带：`Authorization: Bearer <TOKEN>`
- 永久 Token 获取路径：用户在 `emos.club` 网页登录后，在个人设置或账号管理中复制专属 Token（格式如 `6368_xxxx`）。
- 查询用户信息与积分：`GET https://emos.club/api/user` ➔ 返回 `username`, `user_id`, `carrot`, `is_can_upload`, `sign`。

### 2.2 启发式影视库回退识别 (Smart Fallback Identify)
当官方 `/api/identify` 遇到特殊别名（如《海贼王》/《航海王》）或返回 502/404 时，必须采用多级回退机制：
1. 正则清洗文件名，提取剧集名与集数（如 `1174` 或 `E1174`）；
2. 调用 `GET /api/video/search?title=<片名>` 检索影视库条目；
3. 若为电视剧（tv），调用 `GET /api/video/tree?video_id=<id>` 获取全季剧集树，遍历匹配 `episode_number`，精准定位 `item_id` 与 `item_type: ve`；
4. 若为电影（movie），直接匹配 `item_type: vl`。

### 2.3 视频智能识别与发布全流程 Python 脚本（含挂载校验与熔断防误删）

```python
import os
import re
import math
import requests
from concurrent.futures import ThreadPoolExecutor

EMOS_API_BASE = "https://emos.club"
EMOS_TOKEN = os.getenv("EMOS_TOKEN", "your_token_here")

HEADERS = {
    "Authorization": f"Bearer {EMOS_TOKEN}",
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Accept": "application/json, text/plain, */*",
    "Content-Type": "application/json"
}

def identify_video(filename: str) -> dict:
    """智能识别视频元数据（片名、类型、季数、集数），带启发式搜索回退"""
    # 1. 尝试官方识别
    try:
        url = f"{EMOS_API_BASE}/api/identify"
        resp = requests.post(url, headers=HEADERS, json={"filename": filename, "type": "video"}, timeout=10)
        if resp.status_code == 200 and resp.json().get("success"):
            return resp.json()
    except Exception:
        pass

    # 2. 启发式影视库搜索回退
    clean_name = re.sub(r"\[.*?\]|\(.*?\)", "", filename)
    ep_match = re.search(r"[Ee](\d{1,4})|[第\s](\d{1,4})[集话話]", clean_name)
    ep_num = int(ep_match.group(1) or ep_match.group(2)) if ep_match else None
    
    query_match = re.split(r"[.\s_-]+(19\d\d|20\d\d|S\d+|E\d+|2160p|1080p|720p|4k|WEB|HDTV)", clean_name, flags=re.IGNORECASE)
    base_title = query_match[0].replace(".", " ").strip() if query_match else clean_name
    
    search_queries = [base_title]
    if "海贼王" in base_title or "One Piece" in base_title:
        search_queries.insert(0, "航海王")
        
    for q in search_queries:
        if not q:
            continue
        try:
            s_resp = requests.get(f"{EMOS_API_BASE}/api/video/search?title={requests.utils.quote(q)}&page=1&page_size=10", headers=HEADERS, timeout=10)
            if s_resp.status_code == 200:
                items = s_resp.json().get("items", [])
                for it in items:
                    v_type = it.get("video_type")
                    v_id = it.get("video_id")
                    v_title = it.get("video_title")
                    if v_type == "movie" and not ep_num:
                        return {"success": True, "item_type": "vl", "item_id": v_id, "title": v_title, "video_type": "movie"}
                    elif v_type == "tv":
                        tree_resp = requests.get(f"{EMOS_API_BASE}/api/video/tree?video_id={v_id}", headers=HEADERS, timeout=15)
                        if tree_resp.status_code == 200:
                            tree_data = tree_resp.json()
                            if isinstance(tree_data, list):
                                for block in tree_data:
                                    for s in block.get("seasons", []):
                                        for ep in s.get("episodes", []):
                                            ep_title = ep.get("episode_title") or ""
                                            if ep_num and (ep.get("episode_number") == ep_num or str(ep_num) in ep_title):
                                                return {
                                                    "success": True,
                                                    "item_type": ep.get("item_type", "ve"),
                                                    "item_id": ep.get("item_id"),
                                                    "title": f"{v_title} - {ep_title}",
                                                    "video_type": "tv",
                                                    "season": s.get("season_title"),
                                                    "episode": ep_num
                                                }
        except Exception as e:
            print("Search identify error:", e)
    raise RuntimeError(f"未能自动识别该影视条目: {filename}")

def upload_video_to_emos(file_path: str, progress_callback=None) -> dict:
    """全自动多线程分片上传视频、入库关联并执行挂载校验"""
    filename = os.path.basename(file_path)
    file_size = os.path.getsize(file_path)

    # 1. 智能识别视频元数据
    meta = identify_video(filename)
    item_type = meta["item_type"]
    item_id = meta["item_id"]
    
    # 2. 获取上传 Token (必须指定 zn_r2_upload 存档桶)
    token_url = f"{EMOS_API_BASE}/api/upload/getUploadToken"
    token_payload = {
        "type": "video",
        "file_type": "video/mp4" if filename.endswith(".mp4") else "video/x-matroska",
        "file_name": filename,
        "file_size": file_size,
        "file_storage": "zn_r2_upload"
    }
    resp = requests.post(token_url, headers=HEADERS, json=token_payload, timeout=15)
    if resp.status_code != 200:
        raise RuntimeError(f"获取上传通道失败: {resp.text}")
        
    token_data = resp.json()
    file_id = token_data["file_id"]
    
    # 3. 计算分片大小（默认 100MB）
    part_size = 100 * 1024 * 1024
    part_count = max(1, math.ceil(file_size / part_size))
    
    # 4. 获取预签名上传链接
    presign_url = f"{EMOS_API_BASE}/api/upload/multipart/{file_id}/presign"
    presign_resp = requests.post(presign_url, headers=HEADERS, json={"number": part_count}, timeout=15)
    if presign_resp.status_code != 200:
        try:
            requests.delete(f"{EMOS_API_BASE}/api/upload/multipart/{file_id}/abort", headers=HEADERS, timeout=5)
        except Exception:
            pass
        raise RuntimeError(f"获取分片预签名失败: {presign_resp.text}")
        
    presign_list = presign_resp.json()
    upload_urls = {item["number"]: item["upload_url"] for item in presign_list}
    
    # 5. 多线程并发上传分片
    parts_result = []
    
    def upload_part(part_num):
        start = (part_num - 1) * part_size
        end = min(part_num * part_size, file_size)
        with open(file_path, "rb") as f:
            f.seek(start)
            chunk_data = f.read(end - start)
        
        target_url = upload_urls[part_num]
        put_resp = requests.put(target_url, data=chunk_data, timeout=120)
        if put_resp.status_code not in [200, 204]:
            raise RuntimeError(f"分片 {part_num} 直传 R2 失败: HTTP {put_resp.status_code}")
        etag = put_resp.headers.get("ETag", "").strip('"')
        return {"number": part_num, "etag": etag}

    try:
        with ThreadPoolExecutor(max_workers=4) as executor:
            futures = [executor.submit(upload_part, p) for p in range(1, part_count + 1)]
            for f in futures:
                parts_result.append(f.result())
                if progress_callback:
                    progress_callback(len(parts_result), part_count)

        # 6. 合并分片
        parts_result.sort(key=lambda x: x["number"])
        complete_url = f"{EMOS_API_BASE}/api/upload/multipart/{file_id}/complete"
        comp_resp = requests.post(complete_url, headers=HEADERS, json={"parts": parts_result}, timeout=30)
        if comp_resp.status_code not in [200, 201, 204]:
            raise RuntimeError(f"完成分片合并失败: {comp_resp.text}")
        
        # 7. 保存视频发布 (videoSave)
        save_url = f"{EMOS_API_BASE}/api/upload/video/save"
        save_payload = {
            "item_type": item_type,
            "item_id": item_id,
            "file_id": file_id
        }
        save_resp = requests.post(save_url, headers=HEADERS, json=save_payload, timeout=20)
        if save_resp.status_code != 200:
            raise RuntimeError(f"关联保存至 EMOS 影视库失败: {save_resp.text}")

        # 8. 双重挂载校验 (确认平台已挂载该视频)
        base_resp = requests.get(f"{EMOS_API_BASE}/api/upload/video/base?item_type={item_type}&item_id={item_id}", headers=HEADERS, timeout=15)
        if base_resp.status_code == 200:
            medias = base_resp.json().get("video_medias", [])
            print(f"Verified EMOS mount for item {item_id}: {len(medias)} media files attached.")
            
        return {"meta": meta, "save": save_resp.json()}
    except Exception as e:
        try:
            requests.delete(f"{EMOS_API_BASE}/api/upload/multipart/{file_id}/abort", headers=HEADERS, timeout=5)
        except Exception:
            pass
        raise e
```

---

## 3. 多账号自动签到与寄语系统规范 (Multi-Account Sign-in & Blessing System)

### 3.1 签到接口定义
1. **状态查询**：`GET /api/sign/check`
   - 返回：`{"is_sign": true|false, "user_id": "..."}`
2. **打卡提交**：`PUT /api/user/sign?content={url_encoded_blessing}`
   - 寄语限制：最多 10 个中文字符；
   - 无寄语直接打卡：`PUT /api/user/sign`；
   - 成功响应：`HTTP 200` 返回包含 `earn_point` 与 `continuous_days`；
   - 重复打卡：`HTTP 429` 响应 `{"message": "重复签到"}`。

### 3.2 三级交互式菜单设计架构
- **一级（模式与即时触发）**：
  - `🟢 自动签到开关`：布尔值存储于 `emos_config.json`，一键启闭后台定时线程；
  - `👉 立即手动双号签到`：立即异步并发执行所有账号签到并生成汇总卡片。
- **二级（寄语模式选择）**：
  - `🎈 随机寄语模式`：从 14 款正能量祝福语库（如“开心每一天”、“元气满满！”等）随机选择；
  - `⚡ 普通直接模式`：不带任何参数静默打卡。
- **三级（定时调度选择）**：
  - 预设时间快捷点选（`00:05`, `06:00`, `08:00`, `12:00` UTC+8）；
  - `✏️ 自定义时间`：等待用户在聊天框发送 `HH:MM` 格式，校验并热更新调度配置。
