# 影视自动命名引擎权威规范 v2.0

> 2026-09-04 全链路重写。所有条目均有实测证据，回归套件 `test_media_naming.py`：24 项离线解析 + 10 项联网 TMDB 端到端，全绿。

## 架构：单一真源（铁律）

```
文件名（脏）
    │
    ▼
smart_media_parser.extract_media_metadata()      ← 唯一解析器
    │  产出 title_cn / title_en / year / season(+explicit) / episode
    │       quality / release_group / category / ext
    ▼
smart_media_parser.build_search_candidates()     ← 唯一检索候选来源
    │  分级：中文主名 > 中文首段 > 英文全名 > 英文去定冠词 > 清洗名
    ▼
tmdb_helper.query_tmdb_info() → format_standard_name()   ← 唯一命名出口
    │
    ├─▶ emos_service.format_video_name_standard()   （薄代理，仅兜底）
    ├─▶ emos_module.identify_video()                （只保留 EMOS 树匹配）
    └─▶ emos_uploader.identify_video()              （VPS 侧，同一份代码）
```

**严禁**任何环节自行写正则清洗片名。三处分裂实现会让同一文件在下载、改名、入库三个阶段得出**不同**的片名与集数——这是历史上「命名老出问题」的根因。

产物文件：
- `smart_media_parser.py` — 解析器 + 候选构造
- `tmdb_helper.py` — TMDB 查询 + 标准名生成
- `test_media_naming.py` — 回归套件（`--online` 加跑联网用例）
- `reconcile_pipeline.py` — qB↔EMOS 对账

## 命名输出格式

| 类型 | 格式 | 示例 |
|---|---|---|
| 剧集 | `官方中文名 SxxExx.ext` | `遮天 S01E142.mp4` |
| 电影 | `官方中文名 (年份).ext` | `真人快打 (2021).mkv` |
| TMDB 未命中 | 干净解析名，**绝不**回退原始脏名 | `GuAn S01E07.mkv` |

## 中英文混合标题内嵌字母与短词切分陷阱 (2026-09-05 更新)

### 故障现场：汉字夹带单字母被误割裂
```
输入  Until.the.T-Shirt.Dries.S01E09... (官方中文名《直到T恤干透》)
错误  _split_cn_en() 粗暴按 [a-zA-Z] 切割
      'T' 被当成独立英文剥离，中文标题被腰斩为 '直到 恤干透'
      候选生成器切出 '直到' (2字短词) 送入 TMDB 模糊搜索
      TMDB 首位返回《直到疯狂》(2021 韩剧) S01E09，导致误匹配并错入库到该剧！
正确  title_cn='直到T恤干透' → TMDB 命中 id=322570《直到T恤干透 S01E09.mkv》
```

### 三重对策
1. **内嵌字母保护**：当英文字符仅为单字母或短缩写（如 `T恤`、`3D肉蒲团`、`A计划`、`K线`）且紧邻汉字时，作为中文词整体保留，严禁暴力拆散。
2. **短词前缀候选限制**：仅当中文词包含明确空格且首词长度 $\ge 3$ 时才截取首段，严禁把 `直到`、`如果` 等 2 字通用词送入 TMDB。
3. **EMOS 误入库撤回接口**：若发生识别漂移，调用 `DELETE /api/video/media/delete` 携带 `{"media_id": "xxx"}` 立即撤回错误媒体。

## 六类必修 bug（附实测证据）

### (a) 方括号年份被误当集数

```
输入  [GM-Team][国漫][遮天][2023][142][AVC][GB][1080P].mp4
错误  E=2023        ← \[(\d{1,4})\] 抓到第一个方括号数字就返回
正确  E=142
```

抓集数时必须排除 `19xx/20xx` 与 `1080/2160/720/480`。

### (b) 标题残留 SxxExx 直接把 TMDB 查成 0 条

```
输入  凡人修仙传.Renegade.Immortal.2020.S01E128.2160p.WEB-DL.H265.AAC-OurTV.mp4
错误  title='凡人修仙传 Renegade Immortal S01E128'
      TMDB search/tv?query=<上面这串> → results: 0   ← 实测
正确  title_cn='凡人修仙传' → TMDB 命中 id=106449
```

**根因**：用单条贪婪 `re.sub(r'(2160p|...|S\d+|E\d+).*', '')` 清理时，alternation 里位置更靠后的 `2160p` 先命中，`.*` 把尾部一刀切光，于是位置更靠前的 `S01E128` 永远轮不到被清理。

**正解**：分词后遍历，遇到第一个技术标签 token 立即 `break`。

### (c) 发布组裸子串误匹配

```
输入  Mortal.Kombat.2021.2160p.UHD.BluRay.x265-TERMiNAL.mkv
错误  release_group='Mortal', category='anime'   ← "Mortal" 是动漫组名，恰为片名子串
      《真人快打》被判成动漫

输入  [Sakurato] Kusuriya no Hitorigoto [24]...
错误  title='Sakurato'                            ← 组名冒充片名
```

只认两种边界形式：`[GROUP]`（方括号整体或以组名+分隔符开头）、末尾 `-GROUP`。
末尾组名正则**不含点号**（`[A-Za-z][A-Za-z0-9@_]{1,24}$`），否则 `WEB-DL.H264.AAC` 会被整段当成组名。
另需比对「前一 token + `-` + 候选」是否为技术词，挡住 `WEB-DL` / `DTS-HD` / `HR-HDTV`。

### (d) TMDB `search/multi` 的 `&year=` 被静默忽略

```
实测  search/multi?query=遮天&year=1999
      → [('遮天','tv','2023-05-03'), ...]        年份完全没生效

正确  search/tv?query=早春&first_air_date_year=2026   → 《早春晴朗》id=299952
      search/movie?query=Mortal Kombat&primary_release_year=2021 → 《真人快打》
```

`multi` 只作最后兜底，且不传年份（改为本地按年份重排）。

### (e) 方括号技术标签白名单不全

`[AAC AVC]`、`[HEVC-10bit 1080p AAC]`、`[简繁内封字幕]`、`[国英双语中英双字]` 都曾冒充片名。
判定规则：方括号内容**拆开后全是技术词**即判垃圾（不能只比对整块）。

### (f) 命名逻辑三处分裂

见上方架构图。`emos_service` / `emos_module` / `emos_uploader` 各有一套，且 VPS 上那份还是两天前的旧版。

## 三个额外发现的隐藏坑

### `language=zh-CN` 可能返回英文原名

```
实测  tv/95396?language=zh-CN  → name='Severance'      ← 不是中文！
      tv/95396/alternative_titles → {'iso_3166_1':'CN','title':'人生切割术'}
      tv/95396?language=zh-TW  → name='人生切割術'
```

仅在当前标题无 CJK 时才发起补全请求，按 `alternative_titles` CN→SG→TW→HK，再 `translations` 同序兜底。

### 剧集年份 ≠ 首播年

```
文件  庆余年.第二季...S02E05.2024...
实测  search/tv?query=庆余年&first_air_date_year=2024
      → 《庆余年之大赵逍遥王》(2024 网大)          ❌
      search/tv?query=庆余年（无年份）
      → 《庆余年》(2019-11-26, pop=33.5)          ✓ 正剧
```

带年份与不带年份**各查一次合并去重**，排序权重把「标题完全相等」放在「年份命中」**之前**。

### 必须设相关性下限——宁可不改名，也不接受错的官方名

TMDB 会凭音节相似度返回完全无关的作品：

```
query=GuAn 依次踩到：
  《Chuang Guan Dong Zhong Pian》  ← "guan" 落在中间
  《关中唐十八陵》(Guan Zhong Tang Shi Ba Ling)  ← 前缀命中，覆盖率仅 18%
  《Guan Shan》                     ← 前缀命中，覆盖率 50%，覆盖率闸门也拦不住
```

但同时不能把好匹配挡掉：

```
query=Kusuriya no Hitorigoto → 《药屋少女的呢喃》
      中文名与罗马音查询零字面重叠，但这是正确答案
```

**分层判定**（`_is_relevant`）：

1. **短拉丁查询只认完全相等** — 归一化后 <6 字符且无 CJK 时，跳过所有前缀/子串规则。4 个拉丁字母信息量太低，任何模糊规则都会被音节噪声击穿。
2. **子串/前缀命中须覆盖率 ≥40%** — 命中部分占长串的比例。保住《早春》→《早春晴朗》(2/4=50%)，挡掉《关中唐十八陵》(4/22=18%)。
3. **长拉丁多词查询信任 TMDB 首位** — ≥2 个有效词（长度≥3、非定冠词）且归一化 ≥10 字符时，接受首位结果，以放行罗马音/官方别名场景。
4. **CJK 不受短查询限制** — 两个汉字已是强信息。

## 跨机部署纪律

Ops Bot 在 AWS EC2，但**实际执行命名与上传的是 VPS 上的 `emos_uploader.py`**（SSH 调用，文件落地在 VPS）。

```bash
# 1. 推送
for f in smart_media_parser.py tmdb_helper.py emos_uploader.py; do
  sshpass -p "$VPS_PASS" scp -o StrictHostKeyChecking=no "$f" root@$VPS_HOST:/root/
done

# 2. 双向 md5 必须逐字节一致
md5sum smart_media_parser.py tmdb_helper.py emos_uploader.py
sshpass -p "$VPS_PASS" ssh root@$VPS_HOST 'cd /root && md5sum smart_media_parser.py tmdb_helper.py emos_uploader.py'

# 3. VPS 真机 import + 解析冒烟（VPS 无 telegram 模块，只测实际调用链）
sshpass -p "$VPS_PASS" ssh root@$VPS_HOST 'cd /root && python3 -c "
from tmdb_helper import format_standard_name
print(format_standard_name(\"[早春晴朗].The.Early.Spring.2026.S01E12.1080p.NF.WEB-DL.H264.AAC-UBWEB.mp4\")[0])
"'
```

**教训**：本地改完不同步等于没改。曾出现本地 9/3 改动、VPS 停留在 9/1 的两天脱钩，期间所有命名走的都是旧代码。

**注意**：VPS 上不要放 `emos_module.py` —— 它 `import telegram`，VPS 无此依赖，且 `emos_uploader` 完全不引用它。已移至 `/root/unused/`。

## 动漫发布组专属坑（2026-09-04 第二轮补充）

### 日文/中文组名冒充中文主名

```
输入  [黒ネズミたち] 少女怪兽焦糖恋心 / Otome Kaijuu Caraméliser - 10 (...)
错误  title_cn='黒'        ← 组名含 CJK，第一个非技术方括号就是它
正确  title_cn='少女怪兽焦糖恋心'
```

修法：`_strip_group_prefix()` —— 识别出组名后连带其方括号一起剥离，再**重算**方括号清单。组名映射表补入 `黒ネズミたち`、`三明治摆烂组`、`Nix-Raws`、`北宇治字幕组` 等。

### 多译名并列必须拆开

```
输入  [三明治摆烂组&LoliHouse] 少女怪兽焦糖味 / 少女怪兽焦糖恋心 / Otome Kaijuu Carameliser - 08
错误  title_cn='少女怪兽焦糖味 少女怪兽焦糖恋心'   ← 两个译名黏成一串
正确  title_cn='少女怪兽焦糖味'  title_en='Otome Kaijuu Carameliser'
```

`_split_aliases()` 按 ` / ` 拆分：取第一个中文别名作主名，首个纯拉丁别名作英文名。不拆的话检索词和最终文件名都被污染。

**为什么重要**：同一部番在不同组手里有不同译名（焦糖味 vs 焦糖恋心），不归一到 TMDB 官方名会散成多个目录。

### `1920x1080` 被当成年份

```
输入  ... - 10 (CR 1920x1080 AVC AAC MKV)
错误  year='1920'
```

年份扫描前先 `re.sub(r"\d{3,4}\s*[xX×]\s*\d{3,4}", " ", ...)` 剥掉分辨率写法，同时把该写法加入技术词表。

### 「简繁内封」不带「字幕」二字也要认

原技术词表只匹配 `...字幕` 结尾的组合，`[简繁内封]` 整块漏过去，成了 `title_cn='简繁内封'`。补入 `[国粤中英日韩简繁台港]{1,4}(?:内封|内嵌|外挂)` 的独立分支。

## 回归套件用法

```bash
cd /home/ubuntu/lemon-ops-bot
python3 test_media_naming.py            # 离线 24 项，秒级，改解析器后必跑
python3 test_media_naming.py --online   # 加跑 10 项联网 TMDB 端到端
```

**新增用例的原则**：每修一个 bug 就把触发它的真实文件名钉进 `PARSE_CASES`。生产队列里的真实任务名（从 qB 现场抓）比构造样本有价值得多。

套件内建一条全局硬约束：所有检索候选都不得含 `1080/2160/web-dl/hevc/aac/x265/bluray` 等技术标签残留。

## 配套审计脚本

```bash
python3 audit_imports.py    # 静态查「被当模块用但未 import」的名字
```

**为什么需要它**：这类 bug 的调用点通常包在宽泛的 `except Exception` 里，`NameError` 被吞掉后 UI 只显示「查询失败」，看日志根本发现不了。实测抓到 `main.py` 里写了 `requests.get(...)` 但该模块从未 `import requests` —— 面板的 IP 查询就这样静默失败。凡是「某个字段一直显示失败/空值但代码看起来没错」，先跑这个脚本。

## Fail-Closed 铁律（挂载校验）

`emos_uploader.py` 第 6 步的挂载回查**必须抛异常**，不能只 print：

```python
# ❌ 历史 bug：只打印，medias=0 也返回成功
if base_resp.status_code == 200:
    medias = base_resp.json().get("video_medias", [])
    print(f"[✓] Verified: {len(medias)} media variants present.")
return save_resp.json()

# ✅ 现在：递增重试 3 次（1.5s/3s/4.5s，平台入库有异步延迟），
#    拿不到 medias>0 就抛，本地文件强制保留
if verified_medias <= 0:
    raise Exception("挂载校验失败（Fail-Closed 熔断）...本地源文件已保留")
```

上层 `run_pipeline` 的收尾播报也**严禁**硬编码「已成功入库并挂载 ✅」—— 必须按 `ok_episodes` / `dup_episodes` 分类如实播报，四种情形四套文案。

最坏链路（已封堵）：误报成功 → 平台无媒体 → 传完即删模式删掉源文件 → 积分与文件双失且用户不知情。

## 平台业务性拒绝要与故障区分

EMOS 的「此资源您一周内上传过」是**幂等重复**，不是错误。重试只会一直撞同一道墙。

```python
class DuplicateUploadError(Exception): ...      # emos_uploader.py

# __main__ 退出码契约
#   0 + "SUCCESS!"    → 上传并挂载校验通过
#   3 + "DUPLICATE!"  → 一周内已传过，幂等跳过（非故障）
#   1 + "FAIL!"       → 真实失败，保留本地文件
```

`emos_service.execute_remote_vps_emos_upload()` 按此契约返回 `{"ok": True, "duplicate": True/False}`。

另：SSH 命令拼接必须用 `shlex.quote()`，原来用 f-string 拼单引号，含引号的文件名会破坏命令。
