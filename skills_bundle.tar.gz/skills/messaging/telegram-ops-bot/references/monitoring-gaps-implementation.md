# 运维 Bot 监控盲区补齐 —— 实现配方与判据（2026-10-24 实机落地）

配套 `SKILL.md` §29。四类监控 + 一个审计日志，全部已在 AWS 本机跑通并验收。

## 0. 先做盘点，别堆功能

用户问「还需要什么功能」时，先只读核实三层已有覆盖面，再列盲区：

| 层 | 位置 | 实测已覆盖 |
|---|---|---|
| Bot 自身 daemon | `lemon-ops-bot/main.py` `post_init` 里的 `asyncio.create_task` | EMOS 签到、音乐日报、Ad Killer |
| 资源阈值 | `hermes-jobs/ops-healthcheck.sh` + `lemon-ops-health.timer`（10min） | disk/mem/swap/PSI，带去重与恢复通知 |
| Hermes cron | `~/.hermes/cron/jobs.json` | 三机巡检、Codex 链路、state.db、每日备份、Gemini 额度 |

`ops-healthcheck.sh` 的两个好设计值得复用：**签名去重**（`ALERT:<severity>:<sig列表>` 写 state 文件，签名不变不重发）+ **恢复通知**（问题消失且 state 是 `ALERT:*` 时发一条恢复消息）。新增检查项只要往 `problems[]` / `sig[]` 里追加，去重与恢复自动生效。

---

## 1. 月度出网流量额度（AWS 免费额度 100GB）

**为什么不能用现成的**：`psutil.net_io_counters()` 给的是**开机以来累计收发**，既不区分计费月，也不是 AWS 的计费口径。

**正确口径（三条都踩过）**：
1. **AWS 按十进制 GB 计费**：`bytes / 1_000_000_000`。用 `1024**3` 会少算约 7%（实测 6.13 GB vs 5.71 GiB），100GB 额度会判错。
2. **按 UTC 自然月重置**，不是北京月。面板上必须写清「`YYYY-MM` UTC 月重置」，否则用户拿北京时间对账永远差一天。
3. **只算出网（TX）**，入网不计费。

**采样器（无依赖，不需要 vnstat）**：`/proc/net/dev` 的 ens5 行，字段索引 `cols[0]`=RX、`cols[8]`=TX（去掉 `face:` 前缀后 split）。

```python
def _traffic_read_counters():
    with open("/proc/net/dev", "r", encoding="utf-8") as f:
        for line in f:
            if ":" not in line:
                continue
            name, _, rest = line.partition(":")
            if name.strip() != TRAFFIC_IFACE:   # "ens5"
                continue
            cols = rest.split()
            return int(cols[0]), int(cols[8])
```

**月初种子校准（关键）**：首次为某月建桶时，若 `psutil.boot_time()` 落在同一个月，直接用当前计数器值当月初累计（计数器随开机归零）；否则从 0 起并标记 `seeded_from_boot=False`，面板注明「可能略低于真实值」。**绝不猜历史用量。**

**增量累计**：每次采样存 `last_rx/last_tx` 基线，差值累加；差值 <0（重启/回绕）按 0 处理并把基线重置到当前值。

**告警**：70% / 85% / 100% 三档，`alerted` 数组存在同一个按月分桶的 state 里（`{month: {rx_bytes, tx_bytes, last_rx, last_tx, alerted:[...]}}`），同月同档只报一次。发送成功后才写 `alerted`，失败留待下轮重试。

**验收方式（不必等额度真的涨上去）**：把 state 里的 `tx_bytes` 改成 `int(86e9)`，调 `get_traffic_summary()` 断言 `percent == 86.0`，再改回真实值。这比等到 85% 才能验证快得多。

---

## 2. 核心服务存活聚合

加进 `ops-healthcheck.sh`，复用既有去重/恢复。**三个必须做对的点**：

```bash
declare -A SVC_CRIT=(
  [cliproxyapi]=1 [hermes-gateway]=1 [hermes-web-ui]=1
  [lemon-userbot]=1 [lemon-quote-tunnel]=1 [caddy]=1
)
WATCH_SERVICES="cliproxyapi hermes-gateway hermes-web-ui lemon-group-bot lemon-group-bot2 \
lemon-quote-tunnel lemon-subconverter lemon-userbot caddy fail2ban monitor-agent subinfo-bot bili-relay-tunnel"
down_svcs=()
for svc in $WATCH_SERVICES; do
  systemctl cat "${svc}.service" >/dev/null 2>&1 || continue   # 单元不存在就跳过
  st=$(systemctl is-active "$svc" 2>/dev/null)
  if [[ "$st" != "active" ]]; then
    down_svcs+=("${svc}(${st})")
    sig+=("svc_${svc}")
    [[ -n "${SVC_CRIT[$svc]:-}" ]] && severity="CRIT"
  fi
done
((${#down_svcs[@]})) && problems+=("服务异常: $(IFS=,; echo "${down_svcs[*]}")")
```

1. **只纳管「本来就该常驻」的单元**：on-demand / timer 触发的单元（实测 `lemon-quote-api` 正常就是 `inactive dead`、`lemon-music-sync` 是 timer）一旦进列表就是永久假告警。上表前先 `for s in ...; do systemctl is-active $s; done` 逐个看当前真实状态。
2. **`systemctl cat` 跳过不存在的单元**：不同机器部署不同，缺单元不能算故障。
3. **分级**：挂了立刻全站/全模型不可用的进 `SVC_CRIT`，其余 WARN。别把 fail2ban 这种升成 CRIT，会淹没真故障。

**验证不能直接跑生产脚本**（它会真发 Telegram）：`sed` 成副本，把 `notify.py` 的调用换成 `echo`，`BASE=` 指到 `/tmp`，并把 `WATCH_SERVICES` 换成 `"一个active 一个inactive 一个不存在"` 的组合，连跑两次验证「能识别 + 第二次被去重 + 不存在的不报」。

---

## 3. 备份可恢复性校验（不是「备份跑过」）

脚本：`/home/ubuntu/hermes-jobs/backup-verify.py`，timer `hermes-backup-verify.timer`（每日 04:20 UTC，`Persistent=true`，`Nice=10` + `IOSchedulingClass=idle`）。全通过静默退出 0，任何一项失败则打印中文原因并经 `notify.py` 告警。

**六项判据**：
1. 最新备份目录存在且不超过 30h；
2. `UPLOAD_MANIFEST.json` 可解析，`snapshot_files` 全部存在且大小、SHA-256 一致；
3. 所有 `*.tar.gz` 能完整解压一遍（`gzip.open` 读到 EOF，丢弃输出）；
4. 所有 `*.db` 通过 `PRAGMA quick_check`（只读 URI 打开，别写）；
5. 加密分片完整性（见下）；
6. `~/.hermes/state/backup_ledger.jsonl` 里存在该 stamp 的上传记录且 `message_ids` 非空、`deleted_at` 为空。

**两个必踩的坑**：

- **目录名必须用正则筛**：`glob("hermes-*")` 按字典序会把 `hermes-footer-style-20260924` 排到 `hermes-20261024_034815` 前面（`f` > `2`），于是把三个月前的人工快照当成「最新备份」报「已过期 714 小时」。必须 `re.compile(r"^hermes-\d{8}_\d{6}$")`。
- **加密分片「全部缺失」是正常终态**：`~/.hermes/scripts/backup_hermes.sh` 里的 `cleanup_upload` 通过 `trap ... EXIT` 在上传成功后主动 `unlink` 分片和加密包（1.9G 小盘必须清）。所以判定规则是：
  - 分片齐全 → 校验大小总和 == `manifest.encrypted.bytes` 且逐个 SHA-256；
  - **全部分片都不在** → 正常，前提是 ledger 有该 stamp 的 `message_ids`（异地包才是唯一副本），输出提示「恢复需从 Telegram 离线包取回」；
  - **部分在部分不在** → 真损坏（清理中断/上传不完整），必须告警。

**别把「本地无副本」误报成失败**：本地 `snapshot_files`（data.tar.gz / state.db / *.db）是明文快照，仍可本地恢复大部分数据；只有加密整包依赖异地。汇报时要把这个边界讲清。

**运行成本**：`state.db` 常 200MB+，全量 SHA-256 + gzip 校验实测约 9~34s，所以只做每日一次 + idle IO 优先级，绝不放进 10 分钟的资源巡检。

---

## 4. 证书 / 域名到期

脚本：`/home/ubuntu/hermes-jobs/cert-check.py`。真实 TLS 握手（带 SNI）读叶子证书 `notAfter`：≤14 天 WARN、≤7 天 CRIT、过期/校验失败/解析失败 CRIT。同一 `(域名, 状态)` 12h 内只报一次，恢复时发一条恢复通知。

**核心坑：必须按域名配真实端口，不能一律 443。**
实测 `capy.<PRIVATE_IDENTIFIER>` 的 443 上挂的是 Apple EV 伪装证书（`CN=itunes.apple.com`，SNI 不匹配），真实面板 TLS 在 **2087**（Let's Encrypt，正常）。只测 443 会产出「Hostname mismatch」假告警，而且看起来很像真的证书事故。

```python
DOMAINS = [
    ("<YOUR_PRIVATE_DOMAIN>", 443),
    ("capy.<PRIVATE_IDENTIFIER>", 2087),     # 真实 TLS 不在 443
    ...
]
```

**先证实再告警**：出现 `tls_invalid` 时用 `openssl s_client -connect host:port -servername host` 看 subject/SAN/dates，确认是「端口挂错证书」还是「证书真过期」，再决定报不报。别拿 Python 一句 `Hostname mismatch` 就当事故汇报。

**解析失败/不可达单独归类**：域名可能本就下线或仅内网可达，不要混进证书告警里当 CRIT，单独列出来让用户决定是否从清单移除。

---

## 5. 操作审计日志（设计要点，尚未落地）

现状：通过 bot 重启服务、切模型、停任务**无任何记录**，复盘只能翻 journalctl 猜。
建议形态：`ops_audit.jsonl` 只追加（0600），每条 `{ts_bj, user_id, action, target, result}`，在 `callback_handler` 与高危 `CommandHandler` 的**执行后**写入（不要写在前面，否则失败也会留一条成功记录）；面板加「最近操作」读尾部 N 条。

---

## 5.1 证书到期巡检的端口坑（实测踩过，必看）

`ssl.create_default_context().wrap_socket(server_hostname=domain)` 直连读 `notAfter` 是对的，但**端口不能一律写 443**：

- 实测：`capy.<PRIVATE_IDENTIFIER>` 的 443 上是**伪装证书**（Apple EV，SAN 全是 `*.apple.com`），真实面板 TLS 在 **2087**（Let's Encrypt）。按 443 检查会稳定误报 `Hostname mismatch`，且这个误报会掩盖真正要盯的到期日。
- 写法：`DOMAINS = [(domain, port), ...]`；报错文案带端口；`dns_fail` / `unreachable` 与 `tls_invalid` 分开统计（前者多半是域名已下线，属清单待清理，不该按故障告警）。
- 判据：剩余 ≤14 天 WARN、≤7 天 CRIT、`days<0` 判 expired；去重键 `(domain, status)`，同状态 12h 内不重发；状态由告警转 ok 时发一条恢复通知。
- 面板侧**只读巡检落盘的 state.json，绝不做实时握手**——被墙或超时会把整个 `/status` 拖慢。state 里对 ok 项也要存 `days`/`not_after`，否则面板算不出「最近到期」。
- 验证必须用假证书桩：monkeypatch `get_cert` 返回 `now ± N days`，跑 30/10/5/-2 四档 + 第二次静默 + 恢复通知。只跑真实正常路径等于没测。
- 挂 `OnCalendar=*-*-* 05:35:00 UTC` + `Persistent=true` + `RandomizedDelaySec=180`，与备份校验（04:20 UTC）错开。

## 5.2 写操作审计的最小实现

- 单一 JSONL `ops_audit.jsonl`（0600），字段 `ts/action/uid/detail/result`，`ts` 用 UTC+8 ISO（`datetime.timezone(timedelta(hours=8))`）。
- `os.open(path, O_WRONLY|O_CREAT|O_APPEND, 0o600)` + 单次 `os.write` → 并发安全、无需锁；`getsize` 首次写入抛 `OSError` 属正常要吞。
- 超 2MB `os.replace` 轮转 `.1`；整个函数包 `try/except` 走 `_warn_silent`，审计失败绝不能中断业务（用 `/proc/definitely/not/writable/x.jsonl` 测一遍）。
- 埋点只选真正的写操作：`svc:restart:*`（started/ok/failed 三态都记）、`hr:*`、`sw:*`、`/stop`、`/cancel`。只读菜单不记，否则日志全是噪音。
- 面板入口 `m:audit` → `format_audit_text(12)`，主菜单加「🗂 最近操作」按钮；时间戳裁成 `MM-DD HH:MM` 省宽度。

## 6. 汇报模板（这类任务固定带上的两点）

- **区分「已在跑」与「本次新增」**：用户会以为你在重复造轮子，或者以为旧功能是你加的。
- **自监控悖论**：`ops-healthcheck` 直接走 Telegram HTTP、不依赖 bot 进程，所以 bot 挂了它仍能报；但**整机/网络挂了没有任何东西能报**。兜底要靠外部节点（另一台 VPS 或 Hermes cron 的三机巡检）反向探活，这点必须主动说明，否则用户会误以为监控已经闭环。
