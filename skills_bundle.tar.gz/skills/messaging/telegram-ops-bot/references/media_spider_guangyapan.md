# 影视资源爬虫、去广告清洗与光鸭云盘 (GuangYaPan) 自动化转存架构

## 1. 业务全链路流程
$$\text{TG 频道监控抓取} \longrightarrow \text{正则元数据清洗/去广告} \longrightarrow \text{本地 SQLite 去重入库} \longrightarrow \text{光鸭云盘秒级离线} \longrightarrow \text{云端规范改名与目录归档} \longrightarrow \text{Ops Bot 交互式检索与一键转存}$$

---

## 2. 频道爬虫与清洗引擎设计 (`spider.py` / `batch_spider.py`)

### 2.1 抓取与正则清洗规则
* **频道源**：
  * **常规影视**：`@zhuizhuiju`（追追剧 · 剧集）、`@dyttcili`（电影天堂 · 电影）、`@dmhyshare`（动漫花园 · 动漫）。
  * **AI 短剧**：`@YJTJSC`（国产AI短剧）、`@AIRVIP8`（真人AI短剧）、`@bjcvnjkm`（AI短剧丨AI成人黄片）。
  * **里番动漫**：`@SQDM_A`（成人动漫里番）、`@lifankankan`（里番看看）。
  * **成人专区**：`@yuytyu`、`@AV688`、`@NEWFC2`、`@cili8888`、`@mrny6969`、`@pikpaklove`。
* **双轨存储与云端架构**：
  * **Google Drive (5TB 云端)**：针对 Telegram 媒体直传类型（AI 短剧、里番相册），自动执行多块下载、规范重命名并流式同步至 Google Drive 专区（`🎬 AI短剧` / `🔞 里番专区`）。
  * **光鸭云盘 (GuangYaPan)**：纳管 `/柠檬影视库/` 根目录下的 10 大物理分流分类目录（电影精选、剧集更新、动漫专区、AI短剧、里番专区、AV专区、FC2专区、福利姬、网红福利、成人综合），支持秒级磁力离线与直传双轨。
* **广告清洗正则**：
  ```python
  # 剔除推广前缀、网址与发布页乱码
  clean_t = re.sub(r'【[^】]*】', '', t)
  clean_t = re.sub(r'\[(?:BBTTBA|BD影视|电影天堂|高清剧集网|美剧库)[^\]]*\]', '', t, flags=re.IGNORECASE)
  clean_t = re.sub(r'(?:www\.[a-zA-Z0-9\.\-_]+|6v电影|电影港|地址发布页|收藏不迷路)', '', t, flags=re.IGNORECASE)
  clean_t = re.sub(r'￡[^\s]+', '', t)
  ```
* **分类与目录判定**：
  * 若标题或标签包含 `剧集`、`电视剧`、`第X季`、`全X集`，归类为 `tv`（目标目录：`/柠檬影视库/📺 剧集更新/`）；
  * 其余归类为 `movie`（目标目录：`/柠檬影视库/🎬 电影精选/`）。

---

## 3. 光鸭云盘 (GuangYaPan) 核心 API 规范

光鸭云盘（迅雷 2026 新网盘，`guangyapan.com`）底层采用 Bearer Token 认证：

| 功能 | 请求方法与端点 | 载荷参数 (JSON Body) |
| :--- | :--- | :--- |
| **创建离线下载** | `POST /cloudcollection/v1/create_task` | `{"url": "magnet:?xt=...", "parentId": "目录ID"}` |
| **获取文件列表** | `POST /userres/v1/file/get_file_list` | `{"page": 0, "pageSize": 50, "parentId": "目录ID", "needSubFolderStat": true}` |
| **新建文件夹** | `POST /userres/v1/file/create_dir` | `{"dirName": "文件夹名称", "parentId": "父目录ID"}` |
| **移动文件/目录** | `POST /userres/v1/file/move_file` | `{"fileIds": ["文件ID"], "parentId": "目标父目录ID"}` |
| **云端重命名** | `POST /userres/v1/file/rename` | `{"fileId": "文件ID", "newName": "新文件名"}` |
| **一键生成分享链接** | `POST /userres/v1/share_file` | `{"fileIds": ["文件ID"], "title": "标题", "validateDuration": 0, "shareType": 0, "downloadType": 1, "maxRestoreCount": 0}` |

---

## 4. Telegram Ops Bot 交互式检索与转存面板

### 4.1 核心命令与回调流
* **`/find <关键词>` 指令**：直接查询 SQLite 本地库（支持模糊搜索标题、年份、分类）。
* **卡片式回显**：每条结果展示海报/片名、评分、磁力，并挂载 `InlineKeyboardButton("📥 存入光鸭云盘", callback_data="res:down:<ID>")`。
* **一键离线与状态流转**：
  1. 点击后在后台线程执行 `download_resource_to_guangya(res_id)`；
  2. 光鸭接口返回成功后，通过 `query.answer("✅ 已成功推送到光鸭云盘！", show_alert=True)` 弹出 Toast；
  3. 消息按钮原地修改为 `[✅ 已在光鸭离线]`，防止重复提交。

---

## 5. 每日定时入库对账与 Ops Bot 自动推送总报机制 (Daily 12:00 UTC+8 Sync & Reporting)

### 5.1 调度与频控规范
* **调度时间**：每天中午 **12:00 (UTC+8 / 04:00 UTC)** 由 Hermes Cron 触发 `sync_all_media.py`。
* **流程编排**：
  1. **矩阵抓取**：扫描常规影视矩阵（电影/剧集/动漫）与 18+ 磁力矩阵（AV/FC2/福利姬/网红/成人综合）；
  2. **秒转存**：执行私有频道零流量原生视频秒转存；
  3. **云盘推送与净化**：将未推送资源下发至光鸭云盘对应分类目录，并执行全盘深度去广告净化；
  4. **Ops Bot 自动汇报**：通过 Telegram Bot API (`sendMessage`) 将结构化富文本总报推送到管理员私聊窗口。

### 5.2 汇报卡片格式标准 (HTML)
```html
<b>🍋 柠檬每日入库与转存对账总报</b>
<b>⏰ 汇报时间：</b> <code>2026-08-30 12:00:00 (UTC+8)</code>
━━━━━━━━━━━━━━━━━━
<b>📊 今日对账概览：</b>
• <b>新增磁力入库：</b> <code>+194</code> 条
• <b>零流量秒转存：</b> <code>+20</code> 部
• <b>光鸭离线下发：</b> <code>30</code> 个任务
• <b>影视资源总库：</b> <code>8453</code> 条

<b>🎬 常规影视矩阵入库：</b>
  ├ 电影精选：+12 部
  ├ 剧集更新：+18 部
  └ 动漫专区：+5 部

<b>🔞 18+ 矩阵深度收录：</b>
  ├ 🔞 AV专区(日韩)：+45 条
  ├ 🔞 FC2专区：+20 条
  └ ...
━━━━━━━━━━━━━━━━━━
<i>💖 报告已生成，所有任务已安全归档完毕，请爸爸审阅！</i>
```
