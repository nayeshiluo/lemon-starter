# Emby / 影视服 Telegram 智能中控与低内存运营架构指南

## 适用场景
- 在 512MB ~ 2GB 低内存 VPS 上搭建 Emby / Jellyfin 用户管理、卡密兑换、播放并发风控与 Telegram 运营机器人。
- 内存开销严格控制在 20MB~30MB 内，全异步高并发，杜绝笨重依赖与多进程膨胀。
- 实现群聊内引用回复一键开号/查号/销号、完整积分商城与抽奖、群友掷骰对决/打劫互动游戏及企业级安全防御。

---

## 核心架构设计

```
[ Telegram 客户端 / Web 浏览器 ]
       │
       ▼
[ FastAPI + python-telegram-bot (全异步轻量单进程) ] ── (内存占用 ~20MB)
       ├─ [ aiosqlite (WAL Mode) ] ── 本地存储 用户TG绑定 / 卡密CDKey / 积分经济 / 游戏互动 / 操作日志
       ├─ [ aiohttp Emby Client ] ── 异步 REST API 交互 (/Users, /Sessions, /Policy)
       └─ [ BackgroundScheduler ] ── 定时巡检到期与多开并发强杀
```

---

## 核心功能模块与实现模式

### 1. 群聊引用回复快捷操作（Reply-to-Action 交互范式）
在群聊或私聊中，通过 Telegram 的 `update.message.reply_to_message.from_user` 实现免输参数的极速运维：
- **回复一键开号 (`/create [天数] [密码]`)**：
  1. 自动提取被回复用户的 `tg_id` 与 `username`（无 username 则取 `u_{tg_id}`）；
  2. 自动在 Emby 上开号并继承模板用户权限，生成随机强密码；
  3. 群内发送开通成功卡片，并**自动私聊被回复用户推送登录地址、账号密码及客户端指引**。
- **回复一键查号 (`/info` 或 `/check`)**：
  1. 自动查询被回复用户的 Emby 账号、到期时间、剩余天数、账户积分与设备限制；
  2. 实时比对 Emby `/Sessions`，若该用户正在播放，回显其**播放设备、客户端型号与正在观看的媒体名称**。
- **回复一键销号 (`/deluser`)**：
  1. 调用 Emby REST API 物理删除用户，同时清除 SQLite 数据库绑定记录。

---

### 2. 积分经济与娱乐体系（Points Economy & Gamification）
构建完整的群聊积分闭环，促进群组活跃度与用户粘性：
- **积分获取途径**：
  - 每日签到（`/checkin`）：获得固定天数（如 +1 天）与积分奖励（如 +10 PTS）。
  - 群友转账（`/transfer <用户> <点数>`）：支持回复群友消息一键转账打赏。
  - 管理员调控（`/addpts` / `/delpts`）：活动奖励与积分发放。
- **积分商城 (`/shop`)**：
  - 支持通过 Inline Keyboard 一键兑换时长卡（7天/30天/90天）；
  - 支持兑换**播放并发设备上限 +1 台**（将 `max_devices` 提升，允许更多设备同播）。
- **幸运大转盘抽奖 (`/lottery`)**：
  - 消耗 20 积分抽奖，配置带权重的概率奖池：
    - 👑 5% 欧皇大奖：并发设备数 +1
    - 🎁 15% 大吉：7 天观影时长
    - ✨ 25% 中奖：3 天观影时长
    - 💰 30% 积分红包：35 积分（净赚 15 积分）
    - ☕ 25% 安慰奖：赛博功德 +1
- **积分富豪榜 (`/rank`)**：
  - 实时展示积分 TOP 10 用户排行榜。

---

### 3. 互动对决与小游戏模式（Gaming Modes）
- **⚔️ 掷骰 PK 决斗 (`/dice [押注]` 或 `/duel`)**：
  - **群友决斗**：回复群友消息发送 `/dice 50`，生成带【⚔️ 接受对决】/【🏳️ 认怂拒绝】按钮的决斗卡。受邀者 60 秒内点击应战后双方掷骰比大小，胜者赢走赌注积分，平局退回。
  - **单挑战 Bot**：未回复他人时发送 `/dice 20`，与机器人掷骰对决，胜者双倍返还。
- **🥷 积分打劫 / 劫富济贫 (`/rob`)**：
  - 回复群友消息发送 `/rob`。
  - **成功（45% 概率）**：抢走目标 10%~25% 积分（封顶 80 积分）；
  - **失败（55% 概率）**：打劫翻车被反杀，打劫者被扣除 15 积分赔款转入受害者账户；
  - **新手保护**：积分低于 30 的用户触发贫困保护，不可被打劫；每日限制 5 次防止恶意刷屏。

---

### 4. Emby REST API 关键接口
- **开号与模板继承：** `POST /Users/New` 创建用户后，读取模板用户 `GET /Users/{TemplateId}` 的 `Policy`，将其赋予新用户（保留媒体库权限，确保 `IsAdministrator=False`）。
- **到期冻结/解封：** `POST /Users/{UserId}/Policy` 将 `IsDisabled` 置为 `true` 或 `false`，保留用户历史观影记录与配置。
- **改密：** `POST /Users/{UserId}/Password`，支持用户在 TG 快速自助换密（`/resetpw`）。

---

### 5. 实时流并发风控（防多开 / 防转借）
- 轮询 `GET /Sessions`，提取 `NowPlayingItem` 存在且正在播放的会话。
- 按 `UserId` 分组聚合；当活跃会话数 > 设定最大设备数（默认 2 台，可积分升级）时：
  1. 调用 `POST /Sessions/{SessionId}/Message` 弹出阻断提示；
  2. 调用 `POST /Sessions/{SessionId}/Playing/Stop` 强制掐断播放；
  3. 异步通过 Telegram Bot 向绑定用户私聊推送拦截警告。

---

### 6. 卡密（CD-Key）与到期自动管理
- **卡密格式：** `LEMON-` 前缀 + 12 位密码学安全伪随机字符（`secrets.choice`）。
- **生命周期：** 管理员 `/gen <天数> [张数]` 批量生成；用户 `/redeem <卡密>` 充值秒级延长 `expiry_date`；巡检调度器发现 `expiry_date < now()` 自动调用 Emby 禁用接口并发送 TG 催费通知；兑换后自动秒级解封。

---

### 7. 极轻量单文件 Web 管理后台
- 使用 FastAPI 提供极简 REST API（带 `X-Admin-Token` 头部校验）。
- 前端使用纯单文件 HTML + CDN 版 TailwindCSS + Vue 3（零编译构建），提供实时在线会话监控、一键强踢、卡密批量生成与用户状态管理。

---

### 8. 企业级安全漏洞防御与加固最佳实践

1. **HTML 转义防注入（XSS & Parse Error 防御）**：
   - 外部不可控字段（Emby 媒体名称、用户昵称、客户端名称）拼入 HTML 模板前必须调用 `html.escape()`，防止 Telegram API 解析崩溃或恶意链接钓鱼。
2. **原子性 SQL 防双花（Race Condition & Double-Spend 防御）**：
   - 涉及积分扣减（转账、商城兑换、游戏押注），必须在 SQL 语句直接做条件原子操作：
     ```sql
     UPDATE users SET points = points - ? WHERE tg_id = ? AND points >= ?;
     ```
   - 校验影响行数 `rowcount == 1`，彻底杜绝并发多线程刷积分。
   - 卡密抢兑使用 `UPDATE codes SET used_by = ? WHERE code = ? AND used_by IS NULL;` 条件排他锁。
3. **时序攻击防御（Timing Attack Prevention）**：
   - Web API Token 鉴权使用 `secrets.compare_digest` 恒定时间比对。
4. **防暴力破解与 IP 锁定（Anti-Brute-Force）**：
   - 内置连续鉴权失败计数器，单 IP 连续 5 次鉴权失败自动锁定 5 分钟（返回 HTTP 429）。
5. **防刷屏与流控（Anti-Flood / Rate Limit）**：
   - 增加内存级冷却时间（普通指令 1.5s CD，打劫指令每人每日限 5 次），避免触发 Telegram 全局 429 限流。
6. **未决斗内存泄露清理（Duel State TTL）**：
   - 内存对决挑战池设置 120 秒 TTL 自动回收清理，防止小鸡内存膨胀。
