#!/usr/bin/env python3
"""静态校验 Telegram bot 的 handler 注册表（不启动 bot、不发消息）。

用途：改完 CommandHandler 别名/鉴权后，证明改动真的落到了注册表上。
典型场景：把 `cancel` 从紧急停止别名里摘出来，单独绑到 cancel_command。

用法：
  python3 verify_handlers.py main.py                       # 只打印注册表
  python3 verify_handlers.py main.py --expect cancel:cancel_command
  python3 verify_handlers.py main.py --forbid-in stop_upload_command:cancel
  python3 verify_handlers.py main.py --expect stop:stop_upload_command --forbid-in stop_upload_command:cancel

退出码：0 全部断言通过；1 有断言失败；2 文件解析失败。
"""
import argparse
import ast
import sys


def collect(path):
    """返回 [(commands:list[str], handler_func_name)]。"""
    src = open(path, encoding="utf-8").read()
    tree = ast.parse(src)
    rows = []
    for node in ast.walk(tree):
        if not (isinstance(node, ast.Call) and getattr(node.func, "attr", "") == "add_handler"):
            continue
        if not node.args:
            continue
        inner = node.args[0]
        if not (isinstance(inner, ast.Call) and getattr(inner.func, "id", "") in
                ("CommandHandler", "MessageHandler")):
            continue
        cmds = []
        if len(inner.args) >= 1:
            first = inner.args[0]
            if isinstance(first, ast.List):
                cmds = [e.value for e in first.elts if isinstance(e, ast.Constant)]
            elif isinstance(first, ast.Constant):
                cmds = [first.value]
            else:
                cmds = ["<%s>" % type(first).__name__]
        fname = None
        if len(inner.args) >= 2:
            fn = inner.args[1]
            fname = getattr(fn, "id", None) or getattr(fn, "attr", None) or "<lambda>"
        rows.append((cmds, fname))
    return rows


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("path", nargs="?", default="main.py")
    ap.add_argument("--expect", action="append", default=[],
                    metavar="CMD:FUNC", help="断言 CMD 绑定到 FUNC，可重复")
    ap.add_argument("--forbid-in", action="append", default=[],
                    metavar="FUNC:CMD", help="断言 CMD 未出现在 FUNC 的别名列表里，可重复")
    args = ap.parse_args()

    try:
        rows = collect(args.path)
    except Exception as exc:
        print("PARSE_FAIL: %s" % exc)
        return 2

    print("== handler 注册表 ==")
    for cmds, fname in rows:
        print("%-46s -> %s" % (",".join(cmds), fname))

    failures = []
    for spec in args.expect:
        cmd, _, func = spec.partition(":")
        hit = any(cmd in cmds and fname == func for cmds, fname in rows)
        print(("  OK   " if hit else "  FAIL ") + "expect %s -> %s" % (cmd, func))
        if not hit:
            failures.append(spec)

    for spec in args.forbid_in:
        func, _, cmd = spec.partition(":")
        hit = any(cmd in cmds and fname == func for cmds, fname in rows)
        print(("  FAIL " if hit else "  OK   ") + "forbid %s in %s" % (cmd, func))
        if hit:
            failures.append(spec)

    # 通用提醒：同一命令被注册两次时 pb 只会命中第一个 handler
    seen = {}
    for cmds, fname in rows:
        for c in cmds:
            seen.setdefault(c, []).append(fname)
    dup = {c: f for c, f in seen.items() if len(f) > 1}
    if dup:
        print("== 警告：重复注册（后者可能永不触发） ==")
        for c, fs in dup.items():
            print("  %s -> %s" % (c, fs))

    if failures:
        print("RESULT: FAIL (%d)" % len(failures))
        return 1
    print("RESULT: OK")
    return 0


if __name__ == "__main__":
    sys.exit(main())
