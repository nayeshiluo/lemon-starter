---
name: telegram-ops-bot
description: "构建 Telegram 原生 Inline Keyboard 极轻量服务器运维面板与监控 Bot。"
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux, macos]
metadata:
  hermes:
    tags: [telegram, bot, inline-keyboard, server-ops, monitoring, systemd, python-telegram-bot]
    related_skills: [telegram-group-assistant, aws-ec2-ops, hermes-custom-providers]
---

# Telegram 交互式运维与控制台 Bot 规范 (Telegram Ops Bot)

## When to Use
- 用户需要移动端/Telegram 原生交互式服务器运维面板（如类似“艾琳”Server Management Bot 的 Inline Keyboard 按钮菜单）；
- 需要在不消耗 LLM Token、0 延迟前提下监控 Linux CPU/内存/磁盘/网络、重启服务、抓取日志或一键热切换 Hermes 默认模型；
- 需要搭建轻量独立的伴生 Telegram 监控守护进程并配置 systemd 自启。

## 核心架构与功能矩阵

```
Telegram 客户端 (用户点击 Inline 按钮)
       │
       ▼ (CallbackQuery)
Telegram Ops Bot (异步 Python 守护进程 · 仅限白名单 Admin ID)
       ├─ [ 🖥 系统状态 ] ──▶ psutil 采集 CPU/内存/磁盘/Swap/流量/Uptime ──▶ 原地编辑消息刷新
       ├─ [ 🌐 网络工具 ] ──▶ TCP Ping 测速、DNS 延迟、NAT/代理端口探测 ──▶ 异步执行回显
       ├─ [ ⚡ 性能测试 ] ──▶ 纯 Python 质数算力 + 内存吞吐基准简测 ──▶ 输出跑分与评语
       ├─ [ ℹ️ 节点信息 ] ──▶ 主机名、Linux 内核、硬件架构、Python 环境 ──▶ 静态信息展示
       ├─ [ 🔧 服务管理 ] ──▶ systemctl 状态查询与重启 (cliproxyapi/hermes/userbot/quote-api) ──▶ 鉴权执行
       ├─ [ 🕵️‍♂️ UserBot 控制 ] ──▶ 挂载小号状态、防撤回总开关、模式切换 (仅私聊/白名单/全量) ──▶ 原地刷新
       ├─ [ 📋 运行日志 ] ──▶ journalctl 尾部日志抓取 (裁剪防爆框) ──▶ Markdown 代码块输出
       ├─ [ 🤖 切换模型 ] ──▶ 读写 ~/.hermes/config.yaml 无感热切主模型 ──▶ 弹窗 Toast 回显
       └─ [ 🔄 连通自检 ] ──▶ 多线程并发请求各 Provider 探测连通率 ──▶ 状态汇总报告
```

---

## 标准实现步骤

### 1. 鉴权与安全过滤（最高优先级）
必须在收到任何消息与按钮回调的最前置进行 `user_id` 鉴权：
```python
ALLOWED_ADMIN_IDS = [<YOUR_TELEGRAM_ID>]  # 严格白名单

def is_admin(user_id: int) -> bool:
    return user_id in ALLOWED_ADMIN_IDS
```
非白名单用户点击按钮直接触发 `query.answer("⛔ 权限不足", show_alert=True)` 并拦截。

### 2. 交互式键盘设计规范 (Inline Keyboard Layout)
采用 2 列高频 + 1 列通栏的符合移动端人机工学的网格布局：
```python
keyboard = [
    [InlineKeyboardButton("🖥 系统状态", callback_data="m:status"),
     InlineKeyboardButton("🌐 网络工具", callback_data="m:net")],
    [InlineKeyboardButton("⚡ 性能测试", callback_data="m:perf"),
     InlineKeyboardButton("ℹ️ 节点信息", callback_data="m:info")],
    [InlineKeyboardButton("🔧 服务管理", callback_data="m:service"),
     InlineKeyboardButton("📋 运行日志", callback_data="m:logs")],
    [InlineKeyboardButton("🤖 切换模型", callback_data="m:model"),
     InlineKeyboardButton("🔄 连通自检", callback_data="m:check_all")],
    [InlineKeyboardButton("❓ 帮助 / 关于", callback_data="m:help")]
]
```

### 3. 原地消息刷新与非阻塞异步处理
- 查系统状态、刷新页面时使用 `query.edit_message_text()` 原地更新，避免聊天流刷屏；
- 对于网络 Ping、全量连通自检等耗时任务，先原地编辑为“⏳ 正在探测中...”，再通过 `asyncio.get_event_loop().run_in_executor(None, sync_func)` 在线程池中执行，完成后再次原地更新内容；
- 状态切换或重启操作使用 `query.answer("✅ 已生效", show_alert=True)` 弹出原生 Toast 提示。

### 4. 守护进程与开机自启 (Systemd)
在 `/etc/systemd/system/lemon-ops.service` 注册常驻守护进程：
- ⚠️ 注意：Python 执行路径需指定包含依赖（`psutil`, `telegram`）的完整 venv 路径（如 `/home/ubuntu/.hermes/hermes-agent/venv/bin/python3`），避免系统默认 python 缺少模块导致 `ModuleNotFoundError`。
- `Restart=always` 与 `RestartSec=5`。

---

## 踩坑与避坑指南 (Pitfalls)

1. **Token 隔离（切勿共用 getUpdates）**：
   - Telegram Bot API 规定一个 Bot Token 同一时间只能有一个进程维持 `getUpdates` 长轮询连接。
   - 严禁把正在被 Hermes Gateway 使用的 Token 给伴生 Ops Bot 跑 polling，否则两边会互相踢下线并抛出 `HTTP 409 Conflict: terminated by other getUpdates request`。
   - 必须通过 `@BotFather` 创建一个专用的独立 Bot Token。
2. **Systemd Python 解释器路径**：
   - 不要直接写 `/usr/bin/python3`，Ubuntu 系统环境下很多依赖装在 Hermes 自身的 venv 或用户环境里，必须用 `which python3` 确认确切路径后写入 `.service`。
3. **日志输出裁剪防溢出**：
   - 从 `journalctl` 抓取日志时，限制 `-n 12` 且单条消息字符数保持在 3000 字以内，避免触发 Telegram 单条消息 4096 字符上限报错。
4. **模型配置热修改原则**：
   - 运维 Bot 切换 Hermes 模型时，必须使用原子写入（`atomic_yaml_write`）并先备份 `config.yaml`，防止并发写坏配置文件。
5. **Markdown 实体转义与防悬挂卡死（Markdown Entity Parsing & Fallback）**：
   - 动态拼接外部不可控字符串（如模型名 `DeepSeek-V4-Flash[free]` 包含 `[`、`_`、`*` 等字符）时，若截断后出现未闭合标记（如 `[..`），会触发 Telegram API `Can't parse entities` 异常，导致后续消息无法渲染刷新并永久停留在“正在检测/处理中...”的中间态。
   - **对策一**：动态节点名、模型名必须用行内代码块反引号包裹（如 ``f"`{model.replace('`', '')}`"``），阻止 Telegram 解析器将其识别为 Markdown 语法标记。
   - **对策二**：封装 `safe_edit_text` 异常降级兜底函数，当 Markdown 模式更新失败时，自动捕获并在 except 中降级为纯文本模式（无 parse_mode）再次执行编辑，确保 UI 状态必被刷新。
6. **Telegram 原生菜单指令清理与同步（BotCommand Menu Sync）**：
   - 若 Bot Token 此前曾被其他系统（如 Hermes 默认 Agent）使用，Telegram 云端会残留几十条历史指令。
   - 应在 `ApplicationBuilder().post_init(...)` 中显式调用 `await application.bot.set_my_commands(...)` 覆写专属指令列表（`/start`, `/status`, `/userbot`, `/net`, `/perf`, `/service`, `/model`, `/check`, `/logs`, `/help`）。
   - 同时为各指令显式绑定 `CommandHandler`，确保用户在客户端菜单点击指令时直接唤出对应面板，避免仅支持按钮点击而指令无响应。
7. **伴生 UserBot / 贴纸渲染引擎联动与双向 IPC 机制 (Bot API ↔ UserBot IPC)**：
   - 若服务器上部署了基于 Telethon/MTProto 的 UserBot 客户端或 Node 贴纸渲染服务，应在服务管理面板（`get_service_status`）与日志查看器（`get_logs_text`）中统一纳管其 systemd unit（如 `lemon-userbot.service`, `lemon-quote-api.service`）。
   - **痛点**：官方 Telegram Bot API 无法直接修改/删除由 Telethon 用户客户端创建的专属贴纸包（StickerSet 权限归属于用户小号账号）。
   - **解决方案**：设计轻量文件级 IPC 消息总线（`ipc_cmd.json` 与 `ipc_res.json`）：
     - Ops Bot 派发操作动作（`rename_pack`, `delete_last`, `delete_by_index` 等）；
     - UserBot 启动 `ipc_loop()` 异步轮询消费，调用 Telethon 的 `RemoveStickerFromSetRequest` 或 `RenameStickerSetRequest`；
     - 操作完成后将最新 `count` 与状态写回 `ipc_res.json`，Ops Bot 异步等待（超时 3.5s）并以 Telegram Toast/消息原地刷新实时反馈给管理员。

