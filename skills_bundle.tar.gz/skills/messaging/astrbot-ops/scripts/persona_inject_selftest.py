#!/usr/bin/env python3
"""人格注入插件的离线验收脚本（不需重启、不发真消息、不打扰用户）。

用法（在 AstrBot 服务器上，用 astrbot 自带的 python 跑）：
    /root/.local/share/uv/tools/astrbot/bin/python persona_inject_selftest.py

按实际 UMO / 插件目录改下面三个常量。
三件事必须全 pass 才算生效：目标私聊注入且丢掉 base、群聊原样、陌生私聊原样。
"""
import asyncio
import importlib.util

PLUGIN_MAIN = "/opt/astrbot/data/plugins/astrbot_plugin_persona_yamada/main.py"
PLUGIN_PROMPT = "/opt/astrbot/data/plugins/astrbot_plugin_persona_yamada/prompt.md"
TARGET_UMO = "telegram-main:FriendMessage:<YOUR_TELEGRAM_ID>"
GROUP_UMO = "telegram-main:GroupMessage:0"
STRANGER_UMO = "telegram-main:FriendMessage:111111"
MARKER = "山田小姐"  # prompt.md 里必然出现的特征词

spec = importlib.util.spec_from_file_location("persona_plugin", PLUGIN_MAIN)
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)


class FakeEvent:
    def __init__(self, umo):
        self.unified_msg_origin = umo


class FakeReq:
    def __init__(self, p):
        self.system_prompt = p


plugin = mod.PersonaInject.__new__(mod.PersonaInject)
plugin.prompt = open(PLUGIN_PROMPT, encoding="utf-8").read().strip()
plugin.context = None


async def run(umo, base):
    req = FakeReq(base)
    await plugin.inject(FakeEvent(umo), req)
    return req.system_prompt


BIG = "X" * 51434
a = asyncio.run(run(TARGET_UMO, BIG))
b = asyncio.run(run(GROUP_UMO, "GLOBALRAT"))
c = asyncio.run(run(STRANGER_UMO, "OTHER"))

checks = {
    "目标私聊含人格": MARKER in a,
    "目标私聊丢掉全局长人格": "X" not in a,
    "群聊原样未改": b == "GLOBALRAT",
    "陌生私聊原样未改": c == "OTHER",
}
for k, v in checks.items():
    print(("PASS" if v else "FAIL"), k)
raise SystemExit(0 if all(checks.values()) else 1)
