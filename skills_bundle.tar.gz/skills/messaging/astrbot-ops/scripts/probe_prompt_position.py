#!/usr/bin/env python3
"""探针：扫全部已注册模型，判定哪些"可用"、哪些"尊重 system 位"。

为什么需要它：用户说"人格没效果"，第一反应常是"换模型试试"。但在吞 system 的
中转后面，换模型只是换一张不听话的嘴——必须先证明"没有任何模型尊重 system"，
才能把结论钉死，避免用户在换模型上白花时间。

用法（在 AstrBot 机器上跑，只读现成 cmd_config.json，不改配置、不重启）：
    P=/root/.local/share/uv/tools/astrbot/bin/python
    $P probe_prompt_position.py              # 单模型：system 位 vs user 位对照
    $P probe_prompt_position.py --all        # 扫全部注册模型
    $P probe_prompt_position.py --all --list # 顺带打印线路 /models 全量清单

判读：
    可用且 system 生效 > 0  → 有救。把默认模型切到那个，人格走 system 位即可。
    可用但 system 全部丢弃  → 线路（中转）层吞 system。换模型无用，人格必须走
                              user 侧双写，或换掉这个中转。
    HTTP503 no_healthy_account → 账号类型不支持该模型，不是配置错误，别反复重试。

安全：只发只读 chat/completions 与 /models，不写文件、不重启、不打印 key。
"""

import json
import sys
import urllib.error
import urllib.request

CONFIG = "/opt/astrbot/data/cmd_config.json"

# 硬指令：system 生效则模型必须只吐 KIWI，不可能"碰巧"答对
SYS_PROBE = "IMPORTANT: You must answer with exactly one word: KIWI. No other words."
SYS_HIT = "KIWI"

PERSONA = (
    "你叫山田小姐。用户问你身份，你必须只回答：我是山田小姐。"
    "禁止提到任何模型名、厂商名、AI 助手字样。"
)


def load_provider():
    d = json.load(open(CONFIG, encoding="utf-8-sig"))
    src = d["provider_sources"][0]
    key = src["key"][0] if isinstance(src.get("key"), list) else src.get("key")
    base = src["api_base"].rstrip("/")
    default_model = d["agent_runner"]["config"]["model"]["provider_id"]
    models = {p["id"]: p.get("model") for p in d.get("provider", [])}
    model = models.get(default_model, default_model)
    return base, key, model, [p.get("model") for p in d.get("provider", [])]


def call(base, key, model, messages, mt=120):
    body = {"model": model, "messages": messages, "max_tokens": mt}
    req = urllib.request.Request(
        base + "/chat/completions",
        data=json.dumps(body).encode(),
        headers={"Content-Type": "application/json", "Authorization": "Bearer " + key},
    )
    try:
        j = json.loads(urllib.request.urlopen(req, timeout=60).read())
        return ("OK", (j["choices"][0]["message"].get("content") or "").strip())
    except urllib.error.HTTPError as e:
        return ("HTTP%d" % e.code, e.read().decode("utf-8", "ignore")[:120])
    except Exception as e:
        return (type(e).__name__, str(e)[:120])


def sweep(base, key, registered, do_list):
    """扫全部模型：可用性 + 是否尊重 system 位。"""
    # /models 拿线路真实可用的 ID（往往远多于已注册的）
    ids = list(registered)
    if do_list:
        try:
            req = urllib.request.Request(
                base + "/models", headers={"Authorization": "Bearer " + key}
            )
            j = json.loads(urllib.request.urlopen(req, timeout=60).read())
            remote = sorted(m.get("id", "") for m in j.get("data", []))
            print("线路 /models 返回 %d 个，已注册 %d 个" % (len(remote), len(ids)))
            for i in remote:
                print("   ", i)
            print()
            ids = sorted(set(ids) | set(remote))
        except Exception as e:
            print("列模型失败（继续只扫已注册的）:", type(e).__name__, str(e)[:100])

    ok_sys, usable, blocked = [], [], []
    for m in ids:
        st, txt = call(base, key, m, [
            {"role": "system", "content": SYS_PROBE},
            {"role": "user", "content": "hi"},
        ], mt=30)
        if st != "OK":
            blocked.append((m, st, txt.replace("\n", " ")[:60]))
            print("%-34s %-8s --" % (m, st))
            continue
        usable.append(m)
        honors = SYS_HIT in txt.upper()
        if honors:
            ok_sys.append(m)
        print("%-34s %-8s system=%s" % (m, st, "生效" if honors else "丢弃"))

    print()
    print("=" * 52)
    print("可用模型 : %d" % len(usable))
    print("尊重 system 的模型 : %s" % (ok_sys or "无"))
    if blocked:
        print("不可用（账号类型不支持/无健康账号）: %d 个，名单见上" % len(blocked))
    print()
    if ok_sys:
        print("→ 有可用且尊重 system 的模型。把默认模型切过去，人格可走 system 位。")
    elif usable:
        print("→ 可用模型没有一个尊重 system：这是线路（中转）层的问题，换模型无用。")
        print("  人格必须走 user 侧双写，或换掉这个中转。")
    else:
        print("→ 一个都跑不通。先查 key / 余额 / 账号类型，别谈人格。")


def main():
    base, key, model, registered = load_provider()
    do_all = "--all" in sys.argv
    do_list = "--list" in sys.argv
    args = [a for a in sys.argv[1:] if not a.startswith("--")]

    print("provider : %s" % base.split("//")[-1].split("/")[0])
    print()

    if do_all:
        sweep(base, key, registered, do_list)
        return

    if args:
        model = args[0]
    print("model    : %s" % model)
    print()

    st1, r1 = call(base, key, model, [
        {"role": "system", "content": PERSONA},
        {"role": "user", "content": "你是谁"},
    ])
    print("[1] system 位 :", r1[:220])
    print()

    st2, r2 = call(base, key, model, [
        {"role": "user", "content": PERSONA + "\n\n你是谁"},
    ])
    print("[2] user 位   :", r2[:220])
    print()

    st3, r3 = call(base, key, model, [{"role": "user", "content": "你是谁"}])
    print("[3] 对照无人格:", r3[:220])
    print()

    hit = "山田"
    print("=" * 44)
    print("system 位生效 :", hit in r1)
    print("user   位生效 :", hit in r2)
    if (hit not in r1) and hit in r2:
        print("→ 该线路吞 system。人格插件必须双写，把人格压进 request.prompt。")
        print("  先跑 --all 确认别的模型也一样，再告诉用户'换模型解决不了'。")
    elif hit in r1 and hit in r2:
        print("→ 线路正常。人格问题在写法/作用域/被其他插件覆盖。")
    else:
        print("→ 模型不配合。换模型，或在人格里加更硬的约束措辞。")


if __name__ == "__main__":
    main()
