#!/usr/bin/env python3
"""AstrBot Telegram 菜单中文化补丁（幂等，可重复执行）。

背景
----
TG 菜单栏（BotCommand）的描述来自 handler 的 docstring，是英文原文；
Dashboard 的 PATCH /api/v1/commands 只支持 enabled/alias/permission，没有描述字段；
插件自带 i18n 只覆盖插件 metadata 显示名，不覆盖指令描述。
所以在 tg_adapter.py 的 collect_commands 出口加一层中文映射是最小改动。

用法
----
    python3 patch_tg_menu_zh.py                     # 自动定位 uv 安装的包
    python3 patch_tg_menu_zh.py --path <tg_adapter.py>
    python3 patch_tg_menu_zh.py --dry-run           # 只校验不落盘

打完必须重启：systemctl restart astrbot
（描述 hash 变化会触发 delete_my_commands + set_my_commands）

AstrBot 升级（uv tool upgrade astrbot）会覆盖包内文件 —— 重跑本脚本即可。
升级后若锚点找不到（返回码 2），说明上游改了 collect_commands 结构，需人工核对。

注意
----
* 映射表只影响 Telegram 菜单显示，不影响指令本身、/help 文本或 WebUI。
* Telegram 只接受 ASCII 命令名，中文名指令（/签到 等）不会进菜单，与本脚本无关。
* 新装插件出现英文/空描述时，往 ZH_MAP 里补键再重跑（先把已有补丁文件恢复或删掉
  _COMMAND_DESC_ZH 段，否则脚本按"已打过"跳过）。
"""

from __future__ import annotations

import argparse
import ast
import shutil
import sys
from datetime import datetime
from pathlib import Path

MAP_NAME = "_COMMAND_DESC_ZH"

ZH_MAP: dict[str, str] = {
    # builtin_commands
    "help": "显示帮助信息",
    "sid": "查看会话 ID 等信息",
    "name": "设置当前会话的显示名",
    "reset": "清空当前对话上下文",
    "stop": "停止 AI 执行",
    "new": "开启新对话",
    "stats": "查看当前对话的 Token 用量",
    "provider": "查看或切换大模型",
    "dashboard_update": "更新 AstrBot 面板",
    "set": "设置会话变量",
    "unset": "删除会话变量",
    # get_px
    "p": "搜索/随机二次元图片",
    # listen_music
    "搜索歌曲": "搜索 B 站歌曲并语音听歌",
    # matsuko_cover
    "翻唱帮助": "AI 翻唱功能帮助",
    "rvc": "用 RVC 引擎翻唱",
    "svc": "用 SVC 引擎翻唱",
    "svcvc": "用 SVCVC 引擎翻唱",
    "qqrvc": "QQ 音乐点歌后用 RVC 翻唱",
    "qqsvc": "QQ 音乐点歌后用 SVC 翻唱",
    "qqsvcvc": "QQ 音乐点歌后用 SVCVC 翻唱",
    "qq点歌": "搜索 QQ 音乐歌曲",
    "本地翻唱": "用本地音频文件翻唱",
    "刷新rvc模型": "刷新 RVC 模型列表",
    "刷新svc模型": "刷新 SVC 模型列表",
    "刷新svcvc音色": "刷新 SVCVC 音色列表",
    "设置rvc后端链接": "设置 RVC 后端地址",
    "设置svc后端链接": "设置 SVC 后端地址",
    "设置svcvc后端链接": "设置 SVCVC 后端地址",
    "查看翻唱任务": "查看翻唱任务状态",
    "取消翻唱任务": "取消翻唱任务",
    "我的翻唱统计": "查看我的翻唱统计",
    "查看翻唱缓存": "查看翻唱缓存占用",
    "清理翻唱缓存": "清理翻唱缓存",
    "列出msst模型": "列出人声分离模型",
    "切换msst模型": "切换人声分离模型",
    "列出svcvc分离模型": "列出 SVCVC 分离模型",
    "切换svcvc分离模型": "切换 SVCVC 分离模型",
    "翻唱选择": "翻唱菜单选项",
}

OLD_RETURN = "return [BotCommand(cmd, command_dict[cmd]) for cmd in commands_a]"

NEW_RETURN = [
    "        return [\n",
    "            BotCommand(cmd, _COMMAND_DESC_ZH.get(cmd) or command_dict[cmd])\n",
    "            for cmd in commands_a\n",
    "        ]\n",
]


def map_block() -> str:
    body = "\n".join(f'    "{k}": "{v}",' for k, v in ZH_MAP.items())
    return f"{MAP_NAME} = {{\n{body}\n}}\n\n\n"


def find_target() -> Path:
    """在 uv tool 安装目录里找 tg_adapter.py。"""
    roots = [
        Path.home() / ".local/share/uv/tools/astrbot",
        Path("/root/.local/share/uv/tools/astrbot"),
    ]
    for root in roots:
        if not root.exists():
            continue
        for hit in root.glob(
            "**/astrbot/core/platform/sources/telegram/tg_adapter.py",
        ):
            return hit
    raise SystemExit(
        "未找到 tg_adapter.py，请用 --path 指定（uv 装在别的 HOME 下时常见）",
    )


def main() -> int:
    ap = argparse.ArgumentParser(description="AstrBot TG 菜单中文化补丁")
    ap.add_argument("--path", type=Path, help="tg_adapter.py 的绝对路径")
    ap.add_argument("--dry-run", action="store_true", help="只校验，不写文件")
    args = ap.parse_args()

    target = args.path or find_target()
    if not target.is_file():
        print(f"文件不存在：{target}", file=sys.stderr)
        return 2

    src = target.read_text(encoding="utf-8")

    if MAP_NAME in src:
        print(f"已存在 {MAP_NAME}，按幂等跳过：{target}")
        print("如需更新映射表：先删掉该字典段与改造后的 return，再重跑。")
        return 0

    lines = src.splitlines(keepends=True)

    deco = next(
        (i for i, ln in enumerate(lines) if ln.lstrip().startswith("@register_platform_adapter")),
        None,
    )
    ret = next((i for i, ln in enumerate(lines) if ln.strip() == OLD_RETURN), None)

    if deco is None:
        print(
            "未找到 @register_platform_adapter 装饰器锚点，AstrBot 版本结构可能已变，"
            "请人工核对后再打补丁。",
            file=sys.stderr,
        )
        return 2
    if ret is None:
        print(
            f"未找到 collect_commands 的 return 行（期望：{OLD_RETURN}），"
            "上游可能已改实现，请人工核对。",
            file=sys.stderr,
        )
        return 2

    # 关键：插在模块级、装饰器之前。插到 class 行前会把装饰器与 class 劈开（SyntaxError），
    # 插到缩进方法前会 IndentationError —— 两种都实际踩过。
    out = lines[:deco] + [map_block()] + lines[deco:]
    ret_shifted = ret + 1  # 前面插入了一个元素
    out[ret_shifted : ret_shifted + 1] = NEW_RETURN
    text = "".join(out)

    try:
        ast.parse(text)
    except SyntaxError as exc:
        print(f"补丁后语法校验失败，已中止（原文件未改动）：{exc}", file=sys.stderr)
        return 3

    if args.dry_run:
        print(f"[dry-run] 语法校验通过，将修改：{target}")
        return 0

    stamp = datetime.now().strftime("%Y%m%d%H%M%S")
    backup = target.with_name(target.name + f".bak-{stamp}")
    shutil.copy2(target, backup)
    target.write_text(text, encoding="utf-8")

    print(f"已打补丁：{target}")
    print(f"备份：{backup}")
    print("下一步：systemctl restart astrbot")
    print("验证：远端 python 读 data/cmd_config.json 的 telegram_token 调 getMyCommands")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
