#!/usr/bin/env python3
"""探测线路是否支持 OpenAI function calling（tools / tool_choice）。

用途：给 AstrBot 开 computer_use_runtime=local 之前，先确认中转真的会把
tools 透传给模型。中转吞 system 不影响工具调用（tools 是独立 API 字段），
但吞 tools 会让 execute_shell / file_write 等 7 个工具全部失效，白开。

只读：只调 provider 的 /chat/completions，不写任何配置、不重启服务。

在 AstrBot 主机上用它的 venv python 跑（不需要 import astrbot）：
    /root/.local/share/uv/tools/astrbot/bin/python probe_tool_calling.py
    /root/.local/share/uv/tools/astrbot/bin/python probe_tool_calling.py --all
    /root/.local/share/uv/tools/astrbot/bin/python probe_tool_calling.py \
        --config /opt/astrbot/data/cmd_config.json --models cn:kimi-k3-1

退出码：0 = 至少一个模型支持；1 = 全部不支持（此时别开 local）。
"""

import argparse
import json
import sys
import urllib.error
import urllib.request

DEFAULT_CONFIG = "/opt/astrbot/data/cmd_config.json"

TOOLS = [
    {
        "type": "function",
        "function": {
            "name": "execute_shell",
            "description": "Execute a shell command on the host",
            "parameters": {
                "type": "object",
                "properties": {"command": {"type": "string"}},
                "required": ["command"],
            },
        },
    }
]


def load_source(path):
    d = json.load(open(path, encoding="utf-8-sig"))
    src = d["provider_sources"][0]
    key = src["key"][0] if isinstance(src.get("key"), list) else src.get("key")
    base = src["api_base"].rstrip("/")
    models = [p.get("model") for p in d.get("provider", []) if p.get("enable", True)]
    return base, key, models


def probe(base, key, model):
    body = {
        "model": model,
        "messages": [{"role": "user", "content": "用 execute_shell 跑 id 命令"}],
        "tools": TOOLS,
        "tool_choice": "auto",
        "max_tokens": 200,
    }
    req = urllib.request.Request(
        base + "/chat/completions",
        data=json.dumps(body).encode(),
        headers={"Content-Type": "application/json", "Authorization": "Bearer " + key},
    )
    try:
        j = json.loads(urllib.request.urlopen(req, timeout=90).read())
        msg = j["choices"][0]["message"]
        tc = msg.get("tool_calls")
        if tc:
            fn = tc[0].get("function", {})
            return True, "TOOL_CALL_OK %s %s" % (
                fn.get("name"),
                str(fn.get("arguments"))[:80],
            )
        return False, "NO_TOOL_CALL text=" + str(msg.get("content"))[:80].replace("\n", " ")
    except urllib.error.HTTPError as e:
        return False, "HTTP%d %s" % (e.code, e.read().decode("utf-8", "ignore")[:90])
    except Exception as e:  # noqa: BLE001
        return False, "%s %s" % (type(e).__name__, str(e)[:80])


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default=DEFAULT_CONFIG)
    ap.add_argument("--models", nargs="*", help="默认取配置里已启用的 provider")
    ap.add_argument("--all", action="store_true", help="额外扫线路 /models 全量")
    args = ap.parse_args()

    base, key, registered = load_source(args.config)
    models = args.models or registered

    if args.all:
        try:
            r = urllib.request.Request(base + "/models", headers={"Authorization": "Bearer " + key})
            j = json.loads(urllib.request.urlopen(r, timeout=60).read())
            listed = sorted(m.get("id", "") for m in j.get("data", []))
            print("线路 /models 共 %d 个:" % len(listed))
            for m in listed:
                print("  ", m)
            models = sorted(set(models) | set(listed))
            print()
        except Exception as e:  # noqa: BLE001
            print("拉 /models 失败（继续用已注册模型）:", type(e).__name__, str(e)[:80])

    ok = []
    for m in models:
        good, msg = probe(base, key, m)
        if good:
            ok.append(m)
        print("%-34s %-6s %s" % (m, "OK" if good else "--", msg))

    print()
    print("支持 function calling 的模型: %d/%d" % (len(ok), len(models)))
    if ok:
        print("  ", ", ".join(ok))
        print("→ 可以开 computer_use_runtime=local")
        return 0
    print("→ 全线不支持 tools，别开 local（开了工具也调不动）")
    return 1


if __name__ == "__main__":
    sys.exit(main())
