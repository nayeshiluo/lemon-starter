#!/usr/bin/env python3
"""astrbot_plugin_get_px：/p 搜图金币扣费豁免名单补丁（幂等）

背景：插件 p_coin_cost 默认 20/张，且**没有**管理员豁免机制。
本补丁让指定 sender_id 用 /p 不扣费，其他人照旧扣。

用法：
    python3 getpx_free_patch.py              # 用脚本内 FREE_IDS
    FREE_IDS=<YOUR_TELEGRAM_ID>,123 python3 getpx_free_patch.py
    python3 getpx_free_patch.py --path /opt/astrbot/data/plugins/astrbot_plugin_get_px/pixiv/search.py

之后 systemctl restart astrbot。
"""
import os
import sys

DEFAULT_PATH = (
    "/opt/astrbot/data/plugins/astrbot_plugin_get_px/pixiv/search.py"
)
FREE_IDS = {
    i.strip()
    for i in os.environ.get("FREE_IDS", "<YOUR_TELEGRAM_ID>").split(",")
    if i.strip()
}

CONST = '''
# 免扣金币的 sender_id（管理员）。其他人照旧按 p_coin_cost 扣费。
_P_FREE_SENDER_IDS = {%s}


def _p_is_free_sender(user_id) -> bool:
    return str(user_id or "") in _P_FREE_SENDER_IDS

''' % ", ".join('"%s"' % i for i in sorted(FREE_IDS))

# 模块级常量必须插在顶格定义之前，不能插进类体
OLD_ANCHOR = "class SearchMixin:"

# 1) 余额预检放行
OLD_BAL = '''        cost = self._p_unit_cost()
        if not user_id or cost <= 0 or count <= 0:
            return ""'''
NEW_BAL = OLD_BAL + '''
        if _p_is_free_sender(user_id):
            return ""'''

# 2) 真正扣费处放行
OLD_FIN = '''            if self._p_charging_active() and sent_illust_ids:'''
NEW_FIN = '''            if (
                self._p_charging_active()
                and sent_illust_ids
                and not _p_is_free_sender(event.get_sender_id())
            ):'''


def main() -> int:
    path = DEFAULT_PATH
    if "--path" in sys.argv:
        path = sys.argv[sys.argv.index("--path") + 1]

    src = open(path, encoding="utf-8").read()
    if "_P_FREE_SENDER_IDS" in src:
        print("豁免补丁已存在，无需重复处理")
        return 0

    if OLD_ANCHOR not in src:
        print("FAIL: 找不到 class SearchMixin")
        return 1
    src = src.replace(OLD_ANCHOR, CONST + "\n" + OLD_ANCHOR, 1)

    if OLD_BAL not in src:
        print("FAIL: 找不到 _p_balance_error 的判断块")
        return 1
    src = src.replace(OLD_BAL, NEW_BAL, 1)

    if OLD_FIN not in src:
        print("FAIL: 找不到结算 finally 条件")
        return 1
    src = src.replace(OLD_FIN, NEW_FIN, 1)

    compile(src, path, "exec")

    import shutil
    import time

    bak = path + ".bak-" + time.strftime("%Y%m%d%H%M%S")
    shutil.copy2(path, bak)
    open(path, "w", encoding="utf-8").write(src)
    print("已应用：/p 免扣名单 =", sorted(FREE_IDS))
    print("备份:", bak)
    print("请执行: systemctl restart astrbot")
    return 0


if __name__ == "__main__":
    sys.exit(main())
