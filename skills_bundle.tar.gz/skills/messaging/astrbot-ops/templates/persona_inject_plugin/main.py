# AstrBot 人格注入插件（on_llm_request，system + user 双写）
# 落地位置：/opt/astrbot/data/plugins/astrbot_plugin_persona_<name>/
# 同目录还需要 metadata.yaml 和 prompt.md
# 中文传输走 base64：base64 -w0 main.py | ssh host "base64 -d > <远端路径>"
#
# 关键设计一：私聊内 REPLACE（独占），不要无脑 prepend。
#   若已有全局长人格（如 51KB ratman4080），prepend 会被后面那坨盖掉，等于没注入。
#
# 关键设计二：system 和 user 双写（本文件核心，别省）。
#   部分中转（实测 capy.<PRIVATE_IDENTIFIER>:2087）会把 system 消息丢弃/替换成模型自带的
#   厂商身份声明。那种线路上 request.system_prompt 写得再对也不生效，日志照常打印
#   "注入成功"——用户实测会回你一句"好像不行哎"。所以同时把人格压进 request.prompt。
#   先用 scripts/probe_prompt_position.py 判定线路是否吞 system，再决定是否双写；
#   双写对正常 provider 也无害（人格重复出现一次），所以默认开着。

import os

from astrbot.api import logger
from astrbot.api.event import AstrMessageEvent, filter
from astrbot.api.star import Context, Star

# 精确到人的白名单 UMO。群聊一律不在此列 = 完全不碰。
ENABLED_UMO = (
    "telegram-main:FriendMessage:<YOUR_TELEGRAM_ID>",
)

# True = 私聊里丢弃全局人格，本插件独占
# False = 前置拼接（只有在确认没有长人格压后面时才用）
REPLACE_GLOBAL_PERSONA_IN_PRIVATE = True

# 双写：把人格也压进用户消息。关掉会退回"只有 system 位"的失效状态，别动。
ALSO_INJECT_INTO_USER_MESSAGE = True

# 幂等标记：防每轮重复叠加（长会话里会滚成雪球）
MARKER = "【当前角色：__PERSONA_NAME__】"


class PersonaInject(Star):
    def __init__(self, context: Context):
        super().__init__(context)
        self.prompt = ""
        p = os.path.join(os.path.dirname(__file__), "prompt.md")
        try:
            with open(p, encoding="utf-8") as f:
                self.prompt = f.read().strip()
            logger.info("[persona] prompt loaded: %d chars" % len(self.prompt))
        except Exception as e:
            logger.error("[persona] prompt load failed: %s" % e)

    @filter.on_llm_request()
    async def inject(self, event: AstrMessageEvent, request):
        if not self.prompt:
            return
        umo = getattr(event, "unified_msg_origin", "") or ""
        if umo not in ENABLED_UMO:
            return

        base = getattr(request, "system_prompt", "") or ""
        if REPLACE_GLOBAL_PERSONA_IN_PRIVATE:
            request.system_prompt = self.prompt
            sys_dropped = len(base)
        else:
            request.system_prompt = self.prompt + "\n\n" + base
            sys_dropped = 0

        user_hit = False
        if ALSO_INJECT_INTO_USER_MESSAGE:
            p = getattr(request, "prompt", "") or ""
            if MARKER not in p:
                request.prompt = MARKER + "\n" + self.prompt + "\n\n---\n\n" + p
                user_hit = True

        # 验收证据：prompt loaded 不算生效，要看到这一行
        logger.info(
            "[persona] umo=%s | sys=%d(sys_dropped=%d) user_inject=%s"
            % (umo, len(request.system_prompt), sys_dropped, user_hit)
        )
