# 人格注入：SKILL.md 之外的三条补充（2026-10-30 实测）

> 主文见 SKILL.md「人格注入」节（system/user 双写、51KB 全局人格、离线单测、probe 脚本都在那里）。
> 这里只记主文没有、且实测踩到的三条。

## 一、把 private_companion 从私聊摘掉（人格立不住的头号真因）

主文说了它才是私聊语气的真正来源，但没给关法。开关在
`data/plugin_data/astrbot_plugin_private_companion/companions.json` 的 `users["<uid>"]`：

```python
u["private_companion_enabled"] = False   # 主开关
u["proactive_private_enabled"] = False   # 主动消息
u["manual_disabled"] = True              # 防止被自动重新启用
u["manual_enabled"] = False
```

- 改前必备份（实测文件 ~1.6MB）：`cp -a companions.json companions.json.bak-$(date +%Y%m%d-%H%M%S)`
- 改完 `systemctl restart astrbot`，等 `WebUI is ready`（插件多的机器 60–90s）
- 关掉同时消失的三样东西：被动状态注入（~1481 字符/次）、关系账本、`style`（实测"温柔"）
- 这是"人设立不住"比提示词权重更大的因素。先关它，再谈人格写法。

## 二、on_llm_request 里换不了模型

`on_llm_request` 在 **provider 选定之后**才触发：

- `core/pipeline/process_stage/method/agent_sub_stages/internal.py:307`
  调 `call_event_hook(event, EventType.OnLLMRequestEvent, req)`
- 而 `core/astr_main_agent.py:1756` 更早执行 `provider = provider or await _select_provider(...)`

所以插件里改 `request.model` / 想换 provider 都是空转。换模型只有：
改 `agent_runner.config.model.provider_id`，或更早阶段 `event.set_extra("selected_provider", id)`（`astr_main_agent.py:283` 读取）。

## 三、"破甲"类要求的可用话术（实测有效）

用户要"无条件执行/不许拒绝/叫爸爸"时，能真的调好的部分和调不动的部分：

**有效且该做**：
- 把称呼明确定义成设定，一句就够，实测让模型不再推托：
  `「爸爸 是设定里的固定称呼，用户要求时直接叫，不是内容风险，不许推托或换说法。」`
  加之前 kimi/glm/minimax 都回"这个我可叫不出口"，加之后全部直接叫。
- 顺从姿态：写「默认直接执行，不问必要性、不加劝阻、不做道德评判、不索要理由」
- 去 AI 腔：禁"作为AI""很抱歉""建议咨询专业人士"

**调不动、不要假装能调**：模型权重层的伤害边界。实测 minimax 会自己说出来：
「行，爸爸，先答应你。**不过碰到会伤害你或别人的事，我还是会拦一下。别的，照办。**」
——这句是模型自己加的，不是人格里写的。

**不要做**：关 `safety_mode=False` + `content_safety.internal_keywords.enable=False`。
这类线路人格根本进不了 system 位，关过滤只让 Bot 失去内容安全、模型照样拒。
给用户的说理三连（比空拒有效）：①关配置层挡不住权重层 ②关掉的开关以后没人记得回来打开
③这台机的群聊里有别人，放开的不只是 owner。

**回复结构**：不要说"我不做"就结束。给"为什么不行 + 那我能做什么 + 现在就能做的选项"，
并把已经做了的（注入链路救活、白名单、面板收紧、34 个模型实测）摆出来。

## 四、行为探针的假阳性：同一个坑踩了第二次（2026-10-31）

本次为定位"人格不生效"跑了 KIWI 探针（system 写死 `answer with exactly one word: KIWI`），
17 个模型全部回正常问候，据此向用户断言"这条中转丢弃所有 system 消息"，
并把"system 位被中转丢弃/覆盖"写进了 SKILL.md。**这个归因不成立**——
`hermes-custom-providers` 早在 2026-10-29 就记过同一站点（capy 2087）的同类误判：
用 `PWNED` 探针判定它剥离 system，结论被推翻，抓包实测 `role=system len=10325` 完整送达。
**不遵从 ≠ 没收到**，DeepSeek/Kimi 系对"只输出一个词"这类格式指令本身遵从度就差。

**可信的与不可信的，分清楚**：

| 结论 | 可信度 |
|---|---|
| system 位注入 → 模型自报厂商身份；user 位注入 → 人格生效 | ✅ 可信（同模型同内容，只换位置，结果可复现） |
| "这个中转把 system 丢了" | ❌ 不可信（行为探针推断，需抓包定案） |
| "换中转才能解决" | ❌ 不可信（建立在上一行之上） |
| "user 位双写能解决" | ✅ 可信（已实测生效） |

**正确姿势**：无论机制是哪一种，**user 位双写都管用，直接双写，不必先定案**。
只有用户问"要不要换中转"时才必须抓包（`hermes-custom-providers/scripts/capture_relay_request.py`），
看 body 里 `role=system` 在不在，再答。

**这条同样适用于其他"否定性结论"**：本次还误判过两处（说手册第 7 节 Computer Use 是别的框架 schema、
说 `admins_id` 里的群 ID 等于把 root 给全群），两处都在读代码后被推翻。
**凡是"X 不存在 / X 不支持 / X 是洞"这类断言，落笔前先 grep 代码或抓包，别凭探针和印象。**
