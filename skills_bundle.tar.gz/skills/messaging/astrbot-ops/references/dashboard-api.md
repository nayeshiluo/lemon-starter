# AstrBot Dashboard REST API 备忘（v4.29.3 实测）

Base: `http://<host>:6185`（或经 nginx/HTTPS）。全部 JSON；鉴权用登录返回的 `data.token` 作
`Authorization: Bearer <token>`（**不是 cookie**）。路径前缀 **`/api/v1`**。

## 登录

```
POST /api/v1/auth/login
{"username": "astrbot", "password": "<面板密码>"}
→ {"status":"ok","data":{"token":"eyJhbG...","username":"astrbot",...}}
```
- 密码错误 → 401 `用户名或密码错误`。爸爸改过密码就直接问，别猜别重置。

## 消息平台（bots）

```
GET    /api/v1/bots                       # 列表（token 会脱敏显示 "8670...:***"）
POST   /api/v1/bots                       # 创建
PUT    /api/v1/bots/by-id                 # 更新（payload 含 bot_id）
DELETE /api/v1/bots/by-id?bot_id=...      # 删除
GET    /api/v1/bots/stats
```

创建 Telegram（adapter 读 `telegram_token` 键；还支持可选 `telegram_api_base_url` 自定义 API 地址）：

```json
{"id": "telegram-main", "name": "TG机器人", "type": "telegram", "enable": true,
 "config": {"telegram_token": "<token>"}}
```

创建后日志出现 `Loading IM platform adapter telegram(<id>)` → `Starting Telegram polling` →
`Telegram Platform Adapter is running.`；token 无效会报 invalid 并停止 polling。

## 模型提供商（provider-sources / providers，两层结构）

**source**（服务商级：base_url + key 池）：

```
GET    /api/v1/provider-sources                       # 列表
POST   /api/v1/provider-sources                       # 创建/更新（须含 id）
GET    /api/v1/provider-sources/{source_id}           # 单个
PUT    /api/v1/provider-sources/{source_id}
DELETE /api/v1/provider-sources/{source_id}
GET    /api/v1/provider-sources/{source_id}/models    # 拉该 source 模型列表
```

OpenAI 兼容 source（适配器名 `openai_chat_completion`，读 `api_base`/`key`，key 为数组多 key 轮换）：

```json
{"id": "tengbaipiao", "type": "openai_chat_completion", "enable": true,
 "api_base": "https://capy.<PRIVATE_IDENTIFIER>:2087/v1", "key": ["wb-..."]}
```

**provider**（source 下的具体模型条目；source 字段合并进 provider，provider 字段优先）：

```
GET    /api/v1/providers                                # 列表（⚠️ key 明文回显）
POST   /api/v1/providers                                # 创建（须含 id）
POST   /api/v1/provider-sources/{source_id}/providers   # 创建并自动挂 provider_source_id
PUT    /api/v1/providers/by-id?provider_id=...
DELETE /api/v1/providers/by-id?provider_id=...
POST   /api/v1/providers/{provider_id}/test             # {"prompt":"..."} → data.status=="available"
```

注册模型条目：

```json
{"id": "kimi-k3-1", "type": "openai_chat_completion", "model": "cn:kimi-k3-1", "enable": true}
```

## 配置 profile（默认对话模型）

```
GET /api/v1/config-profiles            # 列表；default 的 path=/opt/astrbot/data/cmd_config.json
GET /api/v1/config-profiles/default    # {"data":{"config":{...},"metadata":{...}}}
PUT /api/v1/config-profiles/default    # body 是整份 config（不是包 {config:...}）
```

改默认对话模型：`config.agent_runner.config.model.provider_id = "<provider_id>"`。
`PUT` 回传整份 config；default 的 `provider_sources/provider/platform` 由服务端保留（防误删）。
其他相关字段：`fallback_provider_ids`（回退链）、`provider_settings.provider_pool`（"*"=全部可用）。

## 其他有用端点

- `GET /api/v1/configs` — 配置列表（is_default 标记）
- `GET /api/v1/providers/schema` / `GET /api/v1/config-profiles/schema` — 字段 schema（有的 400，看源码更靠谱）
- 面板前端 dist 在 `<uv tools>/astrbot/lib/python3.12/site-packages/astrbot/dashboard/`，api/ 目录即全部路由；请求体定义在 `schemas.py`，service 在 `services/config_service.py`

## 采坑记录

- `POST /api/v1/provider-sources` 缺 `id` → 400 `Provider source config must have an 'id' field`
- `POST .../providers` 缺 `id` → 400 `New provider config must have an 'id' field`
- `/api/provider-sources/schema` 可能 400（实现不全），需要字段直接看 `dashboard/api/providers.py` + `schemas.py`
- python urllib 发请求时 401/400 会抛 HTTPError，脚本里要 catch 并打印 body