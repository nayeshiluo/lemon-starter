# AstrBot provider 绑定 / modalities / UA 覆盖（4.29.3 源码实证）

> 场景：给 AstrBot 换主模型、加备用 provider、或要求「主文本一个模型、视觉另一个模型」。
> 全部结论来自 `site-packages/astrbot` 源码逐行核对（4.29.3，2026-11），不是猜 schema。

## 1. provider_sources 与 provider 的合并语义

`core/provider/manager.py::get_merged_provider_config()`：

```python
provider_source_id = pc.get("provider_source_id", "")
...
merged_config = {**provider_source, **pc}      # provider 覆盖 source 同名字段
merged_config["id"] = pc["id"]                 # id 永远取 provider 自己的
```

推论（省很多试错）：

- `api_base` / `key` 放 source，`model` / `modalities` / `custom_headers` 放 provider，都能生效；
- provider 条目里的同名字段**优先**，可以只给某一个 provider 单独加 header 而不影响同 source 的其他模型；
- 删除/替换 source 后，所有 `provider_source_id` 指向它的 provider 一起失效——换 source 必须同步改 `agent_runner.config.model.provider_id` 与 `provider_settings.default_image_caption_provider_id`，否则日志出现
  `Configured Agent Runner model provider ID 'xxx' does not match an enabled provider`（它会自己回退，所以"能跑"会掩盖残留）。

`key` 是**数组**，且支持环境变量引用（`_resolve_env_key_list`）：元素写成 `$MY_KEY` 或 `${MY_KEY}` 时从 `os.getenv` 解析；解析不到会写空串并告警。

## 2. UA 覆盖点：`custom_headers`（这是唯一正解，别改源码）

`core/provider/headers.py::build_provider_headers()`：

```python
DEFAULT_USER_AGENT = f"astrbot/{__version__}"
headers = {"User-Agent": DEFAULT_USER_AGENT}
if isinstance(custom_headers, dict):
    for name, value in custom_headers.items():
        if name.lower() == "user-agent":      # 大小写不敏感
            headers["User-Agent"] = value
        else:
            headers[name] = value
```

`core/provider/sources/openai_source.py` 把它作为 `default_headers=self.custom_headers` 传给 `AsyncOpenAI(...)`（约 372/385 行）。

所以对 UA 门禁的中转（Cloudflare 1010、WAF 403、`Python-urllib`/`astrbot/4.x` 被拦）：

```json
{"id":"command-text","type":"openai_chat_completion","model":"...","provider_source_id":"command",
 "modalities":["text"],"custom_headers":{"User-Agent":"Mozilla/5.0"}}
```

写在 provider 或 source 上都行（见 §1 合并规则）。**不要去 patch `headers.py`** —— `uv tool upgrade` 会覆盖。

## 3. `modalities` 的致命默认值

`core/astr_main_agent.py::_provider_supports_modality()`：

```python
modalities = provider.provider_config.get("modalities", None)
if modalities == []:
    return True   # 空列表按"未配置"处理，向后兼容
return isinstance(modalities, list) and modality in modalities
```

**`modalities: []` 等于"支持一切"，不是"什么都不支持"。** 要把一个纯文本模型（如无视觉的 `reflection/beam:free`）标成文本专用，必须显式写 `["text"]`；写成 `[]` 或干脆不写，AstrBot 都会把图片直接塞给它，然后 400 / 空回复。

配套的两条分流逻辑（同一个文件）：

- `_select_image_chat_provider()`：主 provider 不支持 image 时，**把整条请求切给第一个支持 image 的 fallback provider**（`fallback_provider_ids` 顺序即优先级）。
- `_decorate_llm_request()` / `_ensure_img_caption()`：只有当主 provider 不支持 image **且** 配了 `provider_settings.default_image_caption_provider_id` 时，才走"先让视觉模型描述图片、再由文本模型回答"。

### 「主文本 A + 视觉 B + 文本备用 C」的正确绑定

| 字段 | 值 |
|---|---|
| provider `command-text` | `model=A`，`modalities=["text"]` |
| provider `command-vision` | `model=B`，`modalities=["image","text"]` |
| provider `wednesday-text` | `model=C`，`modalities=["text"]` |
| `agent_runner.config.model.provider_id` | `command-text` |
| `agent_runner.config.model.fallback_provider_ids` | `["wednesday-text"]` |
| `provider_settings.default_image_caption_provider_id` | `command-vision` |

⚠️ **别把视觉 provider 放进 `fallback_provider_ids`**：一旦放进去，`_select_image_chat_provider` 会把所有带图请求整条切给那个 fallback，`default_image_caption_provider_id` 那条 caption 路径就被绕过——视觉模型就不再是你指定的那个了。想要"视觉固定用 B、文本失败才落 C"，就必须让 fallback 链里没有 image-capable provider。

视觉 provider 仍可保留为 enabled（供 `/model` 手动切换 / 插件显式引用），只是不进 fallback 链。

## 4. 审计：谁在真正调用（别只看配置）

`data/data_v4.db` 的 `provider_stats` 是真实调用台账，比配置更能说明"Gemini 还在不在活跃路径"：

```sql
SELECT provider_id, provider_model, count(*), max(created_at)
FROM provider_stats GROUP BY 1,2 ORDER BY 4 DESC LIMIT 12;
```

字段是 `provider_id / provider_model / created_at / umo`。删掉的 provider 仍会留下历史行（可据此判断"这条线曾经是主力"），但**只有 `max(created_at)` 接近当下才算活跃**。

## 5. 插件 / 群覆盖核查

- `data/config/*_config.json` 一律 **UTF-8 BOM**，必须 `encoding="utf-8-sig"` 读，否则 `json.load` 直接抛 `Unexpected UTF-8 BOM`。
- `astrbot_plugin_private_companion` 有 30+ 个 `*_PROVIDER_ID` 字段，实测**全部为空串** = 继承全局，不需要逐个改。它的 `private_image_vision_provider_priority: "astrbot_first"` 表示私聊看图也走 AstrBot 自己的视觉链路 → 改 `default_image_caption_provider_id` 就能覆盖它。
- `model_replacement_rules: []` + `model_replacement_scope: "plugin"` 表示没开模型替换；开了的话会绕过 `agent_runner` 的 provider 绑定，必须一起看。
- `provider_pool: ["*"]` 在 4.29.3 里只出现在 `core/config/default.py` 的默认值，没有消费点 —— 不要以为它会把请求轮询到所有 provider。
- `platform_specific` 只放 `pre_ack_emoji` 之类，没有 per-group 模型覆盖；群级覆盖在 `channel_overrides` 那类上层配置里（AstrBot 本体没有）。

## 6. 改完的验收

1. `python3 -c "import json;json.load(open('/opt/astrbot/data/cmd_config.json'))"` —— 语法 + BOM 回读；
2. `systemctl restart astrbot`，`journalctl -u astrbot --since "-3 min"` 只应有 `WebUI is ready`，**不应有** `does not match an enabled provider`；
3. 真实请求分三层报：文本出 content / 带图请求被正确路由（看 `provider_stats` 新增行落在哪个 provider）/ 主模型受控失败时 fallback 行落在备用 provider。
   `provider_stats` 的新行是唯一能证明"图真的走了视觉模型"的本地证据。
