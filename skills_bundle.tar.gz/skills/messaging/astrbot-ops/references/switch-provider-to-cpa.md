# AstrBot 切换模型源到自建 CPA（反重力）实录

场景：原 source 为第三方中转（腾白嫖 capy 2087）不可用，改用自有 CPA 网关（CLIProxyAPI，naye 本机 8317，公网 `cpa-secure.<域名>` 隧道）。

## 0. 拓扑前提

- AstrBot 在 `diaomao`，CPA 在 `naye`（127.0.0.1:8317）。**跨机只能走公网隧道 + api key**，不能写 127.0.0.1。
- 先测可达性再改配置：从 AstrBot 机器 `curl -s -o /dev/null -w '%{http_code} %{time_total}' https://<cpa-domain>/v1/models -H 'Authorization: Bearer <key>'`。本次 200 / 1.0s。

## 1. CPA 侧：新增专用 key（必须重启才生效）

`~/.hermes` 之外，CPA 的 key 是 `config.yaml` 的 `api-keys:` 静态列表。

```bash
cd /home/ubuntu/cliproxyapi
cp config.yaml config.yaml.bak-astrbot-key-$(date +%Y%m%d-%H%M%S)
NEWK="astrbot-$(openssl rand -hex 32)"
python3 - "$NEWK" <<'EOF'
import sys; k=sys.argv[1]; p="/home/ubuntu/cliproxyapi/config.yaml"
s=open(p).read().replace("api-keys:\n", "api-keys:\n- %s\n"%k, 1)
open(p,"w").write(s)
EOF
sudo systemctl restart cliproxyapi.service   # 关键
```

**坑：CPA 不热加载 api-keys。** 改完文件立刻用新 key 请求会 `401`；`systemctl restart cliproxyapi` 后同 key 变 `200`。重启只影响 2~3 秒，Hermes 自身也用这把网关时要意识到短暂中断，但不必事先停用任何东西。重启后同时回归旧 key（`hermes-…`）仍 200，确认没误伤。

**为每个下游单独发一把 key**（`astrbot-`、`userbot-`、`ops-` 前缀），便于吊销和用量归属，不要复用 `hermes-` 那把。

## 2. 改模型前先实测候选模型

对每个候选发一次最小 chat 请求，看是否真有 content：

```bash
curl -s --max-time 60 https://<cpa-domain>/v1/chat/completions \
  -H "Authorization: Bearer $K" -H 'Content-Type: application/json' \
  -d '{"model":"<model>","messages":[{"role":"user","content":"hi"}],"max_tokens":30}'
```

**坑：带 reasoning 的模型在小 `max_tokens` 下返回空 content。** `gemini-3.8-flash-high` 用 `max_tokens:50` 时 content 为空（reasoning_tokens 吃满），同模型 `max_tokens:30` 却回了正常内容、`usage.completion_tokens_details.reasoning_tokens=105`。判定"模型不可用"前必须排除这个变量：换一次 `max_tokens` 或干脆不传，再看是否 200 + 有 content。AstrBot 不强制 max_tokens，一般不受影响，但自己写探针时容易误杀。

## 3. AstrBot 侧：直接改 cmd_config.json（不必登录面板）

面板密码由爸爸自管、不许擅自重置，因此走文件改配置 + 重启，比要密码更省事。文件：`/opt/astrbot/data/cmd_config.json`。

先备份：`cp cmd_config.json cmd_config.json.bak-switch-<reason>-$(date +%Y%m%d-%H%M%S)`。

四处都要改，漏一处就出 WARN：

```python
d['provider_sources'] = [{'id':'antigravity','type':'openai_chat_completion','enable':True,
                          'api_base':'https://<cpa-domain>/v1','key':[KEY]}]
d['provider'] = [
  {'id':'gemini-3-8-flash-high','enable':True,'type':'openai_chat_completion',
   'model':'gemini-3.8-flash-high','provider_source_id':'antigravity'},
  {'id':'gemini-3-flash','enable':True,'type':'openai_chat_completion',
   'model':'gemini-3-flash','provider_source_id':'antigravity'},
  {'id':'gpt-5-6-luna','enable':True,'type':'openai_chat_completion',
   'model':'gpt-5.6-luna','provider_source_id':'antigravity'},
]
d['provider_settings']['default_image_caption_provider_id'] = 'gemini-3-flash'  # 原指旧 provider
d['agent_runner']['config']['model']['provider_id'] = 'gemini-3-8-flash-high'
d['agent_runner']['config']['model']['fallback_provider_ids'] = ['gemini-3-flash','gpt-5-6-luna']
```

`provider[].id` 是自定义字符串（连字符），`model` 才是上游真实 model id，两者别混。

**坑：只改 provider_sources/provider 不改 `agent_runner.config.model.provider_id`，启动会打：**

```
Configured Agent Runner model provider ID `kimi-k3-1` does not match an enabled provider.
AstrBot will use `gemini-3-8-flash-high` as the fallback chat provider.
```

它虽然自己回退了，但这是残留配置，插件和后续改默认模型都会踩，必须一并改掉。改完重启后应只剩 `WebUI is ready`，无此 WARN。

## 4. 重启与验收

```bash
systemctl restart astrbot.service
journalctl -u astrbot.service --since "-2min" --no-pager | grep -iE "WARN|ERROR|Loading model|WebUI is ready"
```

正常应看到三条 `Loading model openai_chat_completion(<id>) ...` + `WebUI is ready`。

## 5. 端到端真实对话验证（不碰面板密码）

配置加载成功 ≠ 能对话。用爸爸人形号私聊 bot 拿真实回复：

- userbot 在本机 naye 运行、独占 `lemon_userbot.session` 的 SQLite 锁，**不能另开同 session**。
- 按 `lemon-userbot` 技能的边界：同机 + 同出口 IP 的临时副本可用。做法：`shutil.copyfile` 主 session 到 `/tmp/verify_astrbot_<pid>_<uuid>.session`、`chmod 600`、连接后 `send_message('<bot_username>', ...)`、等 20~25 秒 `get_messages(limit=6)` 读回、`disconnect()` 后删副本（含 `-journal`）。
- 私聊而非群里发，避免打扰群友；人形号=爸爸本人，命中 AstrBot 私聊白名单。
- 判定标准：读到 BOT 的实际回复文本（本次 `我现在用的是 gemini-3.8-flash-high。`），不是日志里的 provider 名。

同时确认 `/tmp/verify_astrbot_*` 残留为 0。

## 6. 延迟取舍

`gemini-3.8-flash-high` 带 reasoning，私聊实测约 16 秒；`gemini-3-flash` 近乎秒回。群聊场景如果嫌慢，把主模型换 `gemini-3-flash`、高级模型留兜底即可——但这属于用户取舍，报告里给出选项而不是擅自改。
