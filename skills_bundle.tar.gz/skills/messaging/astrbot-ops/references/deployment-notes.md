# AstrBot 官方事实核查笔记（2026-10-26 从仓库原文核实）

来源：README_zh.md、docs/zh/deploy/astrbot/{docker,cli,sys-pm,when-deployed}.md、compose.yml、.python-version，均在 master 分支 raw 读取。文档站：docs.astrbot.app。

## 项目基本面
- 43.4k star / 3.2k fork，Python，AGPL-3.0，2022-12 创建，提交极活跃（检查当日为 2026-10-25）
- 定位：AI Agent 聊天机器人平台，可当"openclaw alternative"；多平台 IM + LLM + 插件 + MCP + 知识库 + 人格 + 自动上下文压缩

## 消息平台（官方 README 宣称）
QQ（NapCat/OneBot v11）、企业微信、飞书、钉钉、微信公众号、Telegram、Slack 等。
- 接 QQ 需 OneBot 协议端，官方配套 NapCat-Docker 的 compose（NapNeko/NapCat-Docker/compose/astrbot.yml），WebSocket 端口 6199

## 模型提供商（官方宣称）
OpenAI 兼容服务、Anthropic、Gemini、DeepSeek、智谱、Moonshot、Ollama 等；另可接入 Dify、阿里云百炼、Coze。自建 OpenAI 兼容中转可直接填。

## 部署方式清单（官方文档）
1. uv 一键：`uv tool install astrbot --python 3.12` → `astrbot init` → `astrbot run`；升级 `uv tool upgrade astrbot --python 3.12`
2. Docker/Compose：镜像 `soulter/astrbot:latest`，端口 6185（WebUI）/6199（OneBot 可选）；国内镜像 `m.daocloud.io/docker.io/soulter/astrbot:latest`
3. 带沙盒的 compose：`compose-with-shipyard.yml` + `soulter/shipyard-ship:latest`（代码/Shell 执行沙盒）
4. 桌面客户端 / Launcher（不推荐服务器场景）
5. 面板类：宝塔、1Panel、CasaOS；源码部署（venv + requirements.txt 或 uv sync）

## 端口与访问
- 6185 WebUI（0.0.0.0）；6199 OneBot WS（可选）
- 首次登录：用户名 `astrbot`，随机初始密码打印在启动日志（`Initial password` 行）
- Docker 部署不能用 localhost 访问面板（容器网络隔离）；云服务器需在厂商控制台放行端口
- uv 路径改密码/用户名：AstrBot CLI 有 `password` 子命令（Docker 用法 `docker exec -it astrbot astrbot password`，修改后需重启）

## 资源占用（实测 + 官方口径）
- 官方任何部署文档均**未给**内存/CPU 最低配置（docker.md/cli.md/README 全部没有）
- 实测：diaomao（913MiB 总内存）裸跑 RSS ≈180MiB（ps RSS 单次采样），冷启动 ~30s
- 该值不含插件、知识库向量库、沙盒、大并发；一次采样不是固定成本
- 无 Docker 的 uv 路径省掉 docker daemon，适合 <1G 内存小鸡

## 其他核实到的事实
- 面板前端（Dashboard dist）随 pip 包内置，启动不下载
- 启动时自动从 models.dev/api.json 拉 LLM 元数据（联网一次）
- 内置插件：astrbot（基础能力）、builtin_commands（/reset 等指令）
- 数据目录结构：data/{config,plugins,temp,knowledge_base,mcp_server.json,logs}

## 适用判断结论（已对爸爸输出）
- TG 生态价值有限：与群霸双 Bot + Hermes 功能重叠，引入 = 第三套 IM 栈加运维负担
- 真正差异化在 QQ/国内 IM；没有 QQ 群需求则"看看热闹就行"
- 不放 AWS（1.9G 内存 + 100GB/月流量），diaomao/vps-la 可跑