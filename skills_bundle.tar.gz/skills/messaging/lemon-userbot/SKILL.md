---
name: lemon-userbot
description: 柠檬 UserBot（Telethon 真人账号）命令语义与排障：区分 ,ai 单问单答 vs ,sum 群聊总结等。
---

# 柠檬 UserBot（Telethon 真人账号）命令语义与排障

爸爸的真人账号 UserBot，代码在 `/home/ubuntu/lemon-userbot/userbot.py`（约 1853 行）。运行于独立 venv（`/home/ubuntu/lemon-userbot/venv/`）。服务涉及 Q 图贴纸、Emoji 包、群聊总结、AI 问答、反撤回等。

## 触发条件
- 用户问 UserBot 某个命令为什么这样/那样、行为异常、或想了解指令用法。
- 涉及 `,q/.q`、`,sum`,`,ai`、`,qd/.qd`、`,qs/.qs`、`,antidel`、`,makee`、`,adde`、`,de`、`,emojis`、`,setemojipack` 等 UserBot 指令。

## 关键架构事实
- **LLM 调用是无状态、单轮的**：`call_llm_api()` 每次只构造 `messages = [system, user_input]` 发给 `http://127.0.0.1:8317/v1/chat/completions`（gemini-proxy），**没有任何跨轮记忆**。
- 两个核心 prompt：`SUMMARY_SYSTEM_PROMPT`（群聊总结，楪祈同款）与 `AI_ASK_SYSTEM_PROMPT`（单问单答）。两者输出均被统一转换为 Telegram 原生 `<blockquote expandable>` 折叠卡片。
- 输出会清理 ```html/``` 代码块包裹，并兼容转换 `<details><summary>` 为 `<blockquote expandable>`。

## 核心区分（易混，务必查清再答）
| 命令 | 语义 | 上下文来源 / 极简触发别名 |
|------|------|---------------------------|
| `,sum` / `,总结` | **真正的群聊总结** | 用 `iter_messages` 真实抓取群里最多 **400 条**（`max_scan`），过滤指令开头（`,` `.` `，` `。` `/` `!`），按时间正序拼接后喂模型 |
| `,ai` / `,ask` / `,问` | **单问单答**，不是总结 | 只带「回复的那一条消息」或「你输入的提问文本」，**不抓群聊历史** |
| `,画` / `,图` / `,d` / `,draw` | **AI 智能生图** | 爸爸偏好**单字极简指令**（`,画`、`,图`、`,d`）。将中文短语自动经 Gemini-3.7 扩写优化为高质量英文 Diffusion Prompt，调用 Flux 极速生成 1024×1024 高清图回传 |

## AI 生图（轻量化内存机制）
- **内存与性能考量**：在 1GB~2GB 低配 VPS 上，严禁直接在本地常驻加载百兆/千兆离线大模型。生图走 Flux API 极速转发，常驻增量 `<5MB`，不拖慢系统。
- **生图流程**：Prompt 优化（Gemini-3.7 扩写光影/构图/细节）→ 云端 Flux 渲染 → Telegram 图片直发。

## 会员状态 Emoji 与发光动态 Emoji 工作流
UserBot 维护两套专属会员状态 Emoji 包（通过 `telethon` 上传 `CreateStickerSetRequest`/`AddStickerToSetRequest`，带 `emojis=True`）：
1. **静态状态 Emoji 包**（`emoji_{id}_lemon`）：100×100 WebP、1px 细边框 + 2px 微圆角 + NotoSansCJK-Regular 400 + 纯透明底。
   - **颜色预设与偏好**：
     - 基础常规红为 `#E53535`；
     - **超亮大红版/高光纯红规范**：严格采用饱和度与亮度直接拉满的极致纯红（`RGB: (255, 0, 0) / #FF0000`），文字与边框有效像素亮度必须 100% 纯红，严禁暗化或混杂非红分量，同时确保保持原有透明通道与抗锯齿柔边。
   - **流程规范**：新增/重构 Emoji 标签时，先生成预览图发给爸爸确认色彩与排版，确认满意后再正式推送到贴图包中。
   - **多媒体回传注意**：向 Telegram 发送预览图时优先压制超轻量 JPG/WebP（<100KB），避免客户端因 CDN/代理延迟出现持续“转圈圈”。若客户端因 Telegram 媒体 DC 线路拥堵持续转圈，应立即同步提供高速免翻/快开图床直链（如 Litterbox `https://litterbox.catbox.moe/resources/internals/api.php` 或 Uguu `https://uguu.se/upload`），确保秒开预览。
2. **动态发光 Emoji 包**（`glow_{id}_lemon`）：100×100 WebM（VP9 + `yuva420p` 透明通道 + 30fps/30帧 1.0s 循环）、双层渲染（外层高斯模糊呼吸霓虹 + 内层硬核高亮文字与边框）。
   - **批量色调转换/衍生处理避坑规范**：
     - **解码必须指定 libvpx-vp9 + rgba**：使用 `ffmpeg -y -vcodec libvpx-vp9 -i input.webm -pix_fmt rgba frame_%03d.png`，严禁不带 `-vcodec libvpx-vp9` 导致透明通道被误读为不透明黑底！
     - **像素重映射保真**：提取帧后对 RGB 呼吸微光与文字边框进行纯度置换，保持其原有的呼吸动效光晕与 Alpha 渐变。
     - **重新编码标准参数**：`ffmpeg -y -framerate 30 -i frame_%03d.png -c:v libvpx-vp9 -pix_fmt yuva420p -b:v 256k -auto-alt-ref 0 output.webm`。

### IPC 批量更新、导出与完全重构协议
外部脚本可通过写 `/home/ubuntu/lemon-userbot/ipc_cmd.json` 由 UserBot 守护进程自动消费并在 `ipc_res.json` 返回结果：
- **查询包内表情详情**：
```json
{"action": "get_emoji_pack_info", "pack_name": "emoji_8903499998_lemon"}
```
- **导出包内全部 Emoji 媒体至本地**：
```json
{"action": "download_and_inspect_pack", "pack_name": "glow_8903499998_lemon", "out_dir": "/home/ubuntu/exported_glow_emojis"}
```
- **全量精准干净重构（防重复添加）**：
```json
{
  "action": "rebuild_pack_exact",
  "pack_name": "glow_8903499998_lemon",
  "title": "张五的专属Emoji发光版",
  "animated": true,
  "items": [
    {"path": "/tmp/glow_emojis/baba.webm", "name": "baba", "emoji": "✨"}
  ]
}
```
- **批量增量添加**：
```json
{
  "action": "add_to_emoji_pack",
  "pack_name": "emoji_8903499998_lemon",
  "animated": false,
  "items": [
    {"path": "/tmp/static_emojis/帅哥.webp", "name": "帅哥", "emoji": "😎"}
  ]
}
```

`,sum` 支持参数：`parse_summary_target()` 解析条数（纯数字/`XX条`，15~400）或时间（`30m`/`1h`/`2小时`/`今日`/`N天`，最大 7 天）。省略参数默认近 80 条。有效发言 <3 条会报"过少"。

## 常见排障结论
- **Telegram AuthKeyDuplicatedError（跨 IP 并发/多机房 Session 复制与冲突陷阱）**：
  - **报错根因**：同一 `.session` 文件包含固定的底层 `auth_key` 鉴权实体。若直接将 `.session` 文件复制到另一台机器（即使改了文件名），两台不同公网 IP 的机器（如 AWS 主控机与打手 VPS）同时或交替发起连接时，Telegram MTProto 网关会识别出同一个 `auth_key` 存在异地异常并发，直接抛出 `AuthKeyDuplicatedError: The authorization key was used under two different IP addresses simultaneously` 并永久吊销该 Session。
  - **规避与修复**：
    1. **严禁跨 IP 机器直接复制 `.session` 数据库**；
    2. 主机与打手机必须彻底解耦：打手 VPS 优先使用独立的 **Bot Token**（`client.start(bot_token=BOT_TOKEN)`）直连私有频道下载视频，与 UserBot 彻底物理隔离；
    3. 若已被 Telegram 吊销失效，需删除旧 `.session` 与 `auth_state.json`，运行 `request_code.py` 重新向手机发码，再通过 `verify_code.py` 配合 2FA 密码登录恢复。
- **用户拿 `,ai` 想总结群里发言却"总记的是其他内容/跑偏/脑补"**：因为 `,ai` 根本不上送群聊历史，模型面前只有被回复的那一条或裸提问文本，只能自由发挥。正确做法是改用 `,sum /,总结`。这是最常见的误解。
- 想用 `,ai` 基于前文：需先回复某条具体消息再发 `,ai`，它只会带上那一条。

## 排障流程
1. 先读 `userbot.py` 中对应 handler（如 `ai_ask_cmd_handler`、`summary_cmd_handler`、`fetch_and_generate_summary`）确认实际抓取逻辑，再下结论。
2. 区分「该命令设计上就不做 X」与「实现 bug」——多数时候是前者。
3. 涉及修改先向爸爸确认（他偏好单步只读排查，未经确认严禁改/删/重启）。
