---
name: lemon-userbot
description: 柠檬 UserBot（Telethon 人形号）：指令语义、session 副本审计与排障。
---

# 柠檬 UserBot（Telethon 真人账号）命令语义与排障

爸爸的真人账号 UserBot，代码在 `/home/ubuntu/lemon-userbot/userbot.py`（约 1853 行）。运行于独立 venv（`/home/ubuntu/lemon-userbot/venv/`）。服务涉及 Q 图贴纸、Emoji 包、群聊总结、AI 问答、反撤回等。

## 当前官方会话边界（优先于下文历史个案）

2026-10-26 原文核实：Telegram https://core.telegram.org/api/errors 的 `AUTH_KEY_DUPLICATED` 章节明确，非媒体 DC 的同一 authorization/auth_key 并行主连接，不论相同还是不同 IP，都可能触发失效；仅服务器明确授予 `tmp_sessions > 1` 的主连接及专用媒体传输会话例外。Telethon FAQ https://docs.telethon.dev/en/stable/quick-references/faq.html 要求多处使用同一账号时，为每处独立登录取得不同 session。

因此：下文“同机复制实测成功”只能证明当时那次成功，**不是同机同 IP 复制永久安全的保证**；“同账号不同 auth_key 也绝不能并行”亦不能当通则，独立登录与同 key 克隆必须区分。迁移默认不新登录、不复制后双活：先清点同 key 所有调用方，排空旧端主连接，安全快照后交给新机独占；第二个原在远端且身份独立的账号留原位，不因迁移主控而搬它。未出现真实授权失败时不要求重登；若确需多处同时运行，应另行授权并独立登录，不复制 auth_key。迁移验收不得另开正在使用的 session 客户端。此处仅更新操作边界，不改变线上代码或停止现有任务。

### 换机搬运 session 的实测顺序（2026-10-27 已跑通）

session 是活 SQLite（`.session` + `.session-journal`），服务运行中复制必拿到半写状态。固定顺序：

1. 记录旧状态：`systemctl show lemon-userbot.service -p MainPID,ActiveEnterTimestamp`。
2. `systemctl stop lemon-userbot` → **等 6 秒** → 确认 `ps -eo cmd | grep -c '[u]serbot.py'` 为 `0`。旧客户端没完全断开就起新机，是 `AUTH_KEY_DUPLICATED` 的唯一诱因。
3. 停写之后再同步整个应用目录（含 `lemon_userbot.session`、`config.json`、`relay_config.json`）。排除运行期产物：`avatar-bridge.sock`、`__pycache__`、`.pytest_cache`、`logs/`。
4. **哈希门禁**：`lemon_userbot.session` / `config.json` / `relay_config.json` / `userbot.py` 两端 sha256 必须全等，不一致就 abort —— 此刻旧机还完整，回滚零成本。
5. 新机起 `lemon-quote-tunnel.service`（`-L 127.0.0.1:4888` 到 quote-api 所在机）→ 再起 `lemon-userbot.service`。Q 图依赖这条隧道，隧道没通时 `,q` 会静默失败。
6. 验收：日志出现 `UserBot running as: <name> (@<username>)` 与 `Avatar bridge listening on ...` / `Starting IPC Command listener loop...`，且全文无 `AUTH_KEY_DUPLICATED` / `AUTH_KEY_UNREGISTERED`。只有 `Connecting to ... complete!` 不算登录成功。
7. 旧机 `systemctl disable lemon-userbot lemon-quote-tunnel`，防重启后复活第二个同 key 主连接。

回滚注意：新机若已成功登录并刷新过 session，旧机那份副本**可能已失效**，回退要重新验证而不是假设可用。分组切换通用七步见 `aws-ec2-ops` 的 `references/single-writer-cutover-runbook.md`。

## session 风险分级（2026-10-24 历史实测，按上文边界解释）

**曾在此犯过错**：把"禁止跨机复用"误推成"禁止同机复制、必须独立登录"，向爸爸提了无证据的重登要求，被当场质疑「怎么又要登录？你确定吗」。以下为实测校正版。

`AuthKeyDuplicatedError` 的真实触发条件是同一 auth_key 从**不同公网 IP / 不同机器**连接。**同机 + 同出口 IP 下多进程复用同一 auth_key，Telegram 目前放行**，有实证：2026-10-24 06:17 生产 pipeline 经 `isolated_tg.py` 复制主号 session 到 `/tmp` 连接，同时主号 UserBot（PID 470291）在线，两进程同 key 并存，成功下发 175 条（55 通过 / 120 规则拦截），全程零 `AuthKeyDuplicated`，`/tmp` 退出后无残留。

| 场景 | 判定 | 处理 |
|---|---|---|
| 同机、同出口 IP，临时副本跑爬虫 | 实测可用 | 允许；副本须唯一命名 + `600` + 退出即删 |
| 副本被带到他机 / 挂代理 / 换出口 IP | **必封** | 严禁 |
| 同账号在另一台机器独立登录 | 可并存 | 两处**不得同时在线** |

- **不要因为看到 `shutil.copyfile` 就判定违规或要求重登**。先跑指纹审计（见「人形号 session 清点与同 key 副本审计」一节），再按上表判级。
- 生产链路是 `lemon-media-spider/isolated_tg.py` 的 `IsolatedTelegramClient`（`sync_all_adult.py` / `lemon_crawler.py` 在用）：复制到 `/tmp/{prefix}_{pid}_{uuid}.session`，`__aexit__` 删除。手动脚本（`crawl_pikpaklove.py` / `av_actress_pipeline.py` / `crawl_and_save_new3.py`）走 `tg_session_guard.connect_isolated()`，行为与生产一致，**不需要新登录**。
- 已隔离的隐患 session 在 `/home/ubuntu/lemon-session-quarantine-20261024/`（含 README 说明来源与恢复条件），不要当垃圾删。真正该隔离的是「跨机第二登录」和「同 key 复制品」，不是「本机临时副本」。
- **提"需要重新登录/换凭据"之前必须先证明现有凭据确实不可用**：给出指纹、授权状态、日志时间线等证据。无证据的重登要求会被爸爸直接质疑，属过早归因。

## 触发条件
- 用户问 UserBot 某个命令为什么这样/那样、行为异常、或想了解指令用法。
- 用户问「我有几个人形号 / 账号有没有问题」、要清点账号、或准备把 session 迁到新机器 → 走「人形号 session 清点与同 key 副本审计」一节。
- 涉及 `,q/.q`、`,qh/.qh`、`,sum`、`,ai`、`,qd/.qd`、`,qs/.qs`、`,qhs/.qhs`、`,antidel`、`,makee`、`,adde`、`,de`、`,emojis`、`,setemojipack` 等 UserBot 指令。

## 关键架构事实
- **LLM 调用是无状态、单轮的**：`call_llm_api()` 每次只构造 `messages = [system, user_input]` 发给 `http://127.0.0.1:8317/v1/chat/completions`（gemini-proxy），**没有任何跨轮记忆**。
- 两个核心 prompt：`SUMMARY_SYSTEM_PROMPT`（群聊总结，楪祈同款）与 `AI_ASK_SYSTEM_PROMPT`（单问单答）。两者输出均被统一转换为 Telegram 原生 `<blockquote expandable>` 折叠卡片。
- 输出会清理 ```html/``` 代码块包裹，并兼容转换 `<details><summary>` 为 `<blockquote expandable>`。

## 核心区分（易混，务必查清再答）
| 命令 | 语义 | 上下文来源 / 极简触发别名 |
|------|------|---------------------------|
| `,sum` / `,总结` | **真正的群聊总结** | 用 `iter_messages` 真实抓取群里最多 **400 条**（`max_scan`），过滤指令开头（`,` `.` `，` `。` `/` `!`），按时间正序拼接后喂模型 |
| `,ai` / `,ask` / `,问` | **单问单答**，不是总结 | 只带「回复的那一条消息」或「你输入的提问文本」，**不抓群聊历史** |
| `,画` / `,图` / `,d` / `,draw` | **AI 智能生图** | 爸爸偏好**单字极简指令**（`,画`、`,图`、`,d`）。将中文短语自动经 Gemini-3.8 扩写优化为高质量英文 Diffusion Prompt，调用 Flux 极速生成 1024×1024 高清图回传 |
| `,q` / `,qs` | **纯净名言气泡贴纸** | 生成单张 WebP 发言贴纸，**强制不带被回复消息**（纯粹提取当前发言人内容）；`,qs` 同步入库专属贴纸包 |
| `,qh` / `,qhs` | **带回复引言的名言贴纸** | **保留被回复上下文**（Quote with History/Header），气泡内嵌二级被引用发言预览；`,qhs` 同步入库专属贴纸包 |

## AI 生图（轻量化内存机制）
- **内存与性能考量**：在 1GB~2GB 低配 VPS 上，严禁直接在本地常驻加载百兆/千兆离线大模型。生图走 Flux API 极速转发，常驻增量 `<5MB`，不拖慢系统。
- **生图流程**：Prompt 优化（Gemini-3.8 扩写光影/构图/细节）→ 云端 Flux 渲染 → Telegram 图片直发。

## 会员状态 Emoji 与发光动态 Emoji 工作流
UserBot 维护两套专属会员状态 Emoji 包（通过 `telethon` 上传 `CreateStickerSetRequest`/`AddStickerToSetRequest`，带 `emojis=True`）：
1. **静态状态 Emoji 包**（`emoji_{id}_lemon`）：
   - **基础规范**：`100×100` WebP，1px 细边框 + 2px 微圆角 + NotoSansCJK-Regular 400 + 纯透明底。
   - **原版经典线框徽章版型（V8 Unified Rounded Rectangle & Outline Badge 强制准则）**：
     - **画布与包围盒**：`100×100` 画布，严格采用 `[2, 14, 97, 85]` 外边框、`radius=14`（大微圆角）、`width=3` 实心线宽描边，内部纯净透明镂空，**严禁使用实心填充色块胶囊（如红底填满）**。
     - **字体与排版**：NotoSansCJK-Bold `35px` 双字标题，经过光学字心校准，文字颜色与边框完全同色，确保在昵称状态栏、Profile 状态及输入框内完全不压边、清晰饱满。
   - **颜色预设与偏好**：
     - 基础常规红为 `#E53535`；
     - **超亮大红版/高光纯红规范**：严格采用饱和度与亮度直接拉满的极致纯红（`RGB: (255, 0, 0) / #FF0000` 或 `#EB3737`），文字与边框有效像素亮度必须纯红，严禁暗化或混杂非红分量，同时确保保持原有透明通道与抗锯齿柔边；
     - **核心主题配色体系**：红色系（中国/爱国 `#EB3737`）、金橙色系（富强/文明/敬业 `#FDAE02`/`#FE6602`）、科技蓝系（民主/法治/平等 `#0290FD`/`#02A4FC`）、翡翠绿系（和谐/友善 `#55CA1B`）、青蓝系（自由 `#14C7C7`）、紫罗兰系（公正/诚信 `#A128B4`/`#E166FC`）。
   - **流程规范**：新增/重构 Emoji 标签时，先生成预览图发给爸爸确认色彩与排版，确认满意后再正式推送到贴图包中。
   - **多媒体回传注意**：向 Telegram 发送预览图时优先压制超轻量 JPG/WebP（<100KB），避免客户端因 CDN/代理延迟出现持续“转圈圈”。若客户端因 Telegram 媒体 DC 线路拥堵持续转圈，应立即同步提供高速免翻/快开图床直链（如 Litterbox `https://litterbox.catbox.moe/resources/internals/api.php` 或 Uguu `https://uguu.se/upload`），确保秒开预览。
2. **动态发光 Emoji 包**（`glow_{id}_lemon`）：
   - **视频规格**：`100×100` WebM（VP9 + `yuva420p` 透明通道 + 30fps/30帧 1.0s 循环）。
   - **发光机理**：提取 V8 纯线框图层的 Alpha 轮廓，应用双层高斯模糊与**正弦呼吸微光扩散层（Sine Pulse Glow Layer）**，外层高斯模糊呼吸霓虹 + 内层硬核高亮实体文字边框。
   - **批量色调转换/衍生处理避坑规范**：
     - **解码必须指定 libvpx-vp9 + rgba**：使用 `ffmpeg -y -vcodec libvpx-vp9 -i input.webm -pix_fmt rgba frame_%03d.png`，严禁不带 `-vcodec libvpx-vp9` 导致透明通道被误读为不透明黑底！
     - **像素重映射保真**：提取帧后对 RGB 呼吸微光与文字边框进行纯度置换，保持其原有的呼吸动效光晕与 Alpha 渐变。
     - **重新编码标准参数**：`ffmpeg -y -framerate 30 -i frame_%03d.png -c:v libvpx-vp9 -pix_fmt yuva420p -b:v 150k -minrate 50k -maxrate 250k -crf 30 -an output.webm`。

### IPC 批量更新、导出与完全重构协议
外部脚本可通过写 `/home/ubuntu/lemon-userbot/ipc_cmd.json` 由 UserBot 守护进程自动消费并在 `ipc_res.json` 返回结果：
- **查询包内表情详情**：
```json
{"action": "get_emoji_pack_info", "pack_name": "emoji_<PRIVATE_IDENTIFIER>_lemon"}
```
- **导出包内全部 Emoji 媒体至本地**：
```json
{"action": "download_and_inspect_pack", "pack_name": "glow_<PRIVATE_IDENTIFIER>_lemon", "out_dir": "/home/ubuntu/exported_glow_emojis"}
```
- **全量精准干净重构（防重复添加）**：
```json
{
  "action": "rebuild_pack_exact",
  "pack_name": "glow_<PRIVATE_IDENTIFIER>_lemon",
  "title": "张五的专属Emoji发光版",
  "animated": true,
  "items": [
    {"path": "/tmp/glow_emojis/baba.webm", "name": "baba", "emoji": "✨"}
  ]
}
```
- **批量增量添加**：
```json
{
  "action": "add_to_emoji_pack",
  "pack_name": "emoji_<PRIVATE_IDENTIFIER>_lemon",
  "animated": false,
  "items": [
    {"path": "/tmp/static_emojis/帅哥.webp", "name": "帅哥", "emoji": "😎"}
  ]
}
```
**入包前必做预处理（外部图片）**：包里其余表情都是透明底、100×100、1px 级描边的徽章，直接把白底 JPG 塞进去会变成白方块。标准做法：白→透明（按亮度算 alpha，边缘做反预乘，否则红边发粉）→ 按内容 bbox 裁切 → 加约 12% 留白居中 → LANCZOS 缩到 100×100 → 无损 webp。想要最锐利就干脆用 `render_tag_badge_bytes(text, color)` 直接渲染，再 `add_to_emoji_pack`。

**入包后验收（必做）**：`add_to_emoji_pack` 返回的「总计 N」可能是旧缓存——实测刚加完仍报 65，隔几秒 `get_emoji_pack_info` 才变 66，别据此判定失败或重复提交。稳妥做法：等 3~5 秒查 count，再 `download_and_inspect_pack` 把最后两张拉回本地比 alpha 通道（黑底实心版不透明像素约 45%，纯红描边版约 6%），alpha_mad≈0 才算真落地。注意 emoji 包没有删除 action，`delete_by_index` 写死 `q_{id}_lemon` 名言集，加错了只能让爸爸在 Telegram 里手动删。

**落地核验的两个坑**：
1. `GetStickerSet` 计数会瞬时滞后——刚 `add_to_emoji_pack` 返回「总计 65」后 20 秒内再查可能仍读到 64，隔 1~2 分钟复核才稳定，别据此判定添加失败。
2. emoji 包**原无**删除 action（`delete_by_index` 里 pack 名写死 `q_{id}_lemon`）。2026-10 已补通用 `delete_from_pack`：`{"action":"delete_from_pack","pack_name":"emoji_...","file_id":"<doc id>"}`（也支持 1-based `index`），返回剩余数量；改完必须 `sudo systemctl restart lemon-userbot` 才生效（约 8 秒，日志会先刷几条 `RpcCallFailError: GetDialogsRequest`，属 Telegram 瞬时问题）。删除前先 `download_and_inspect_pack` 拿到 file_id，别凭序号删。
3. 独立验证：`download_and_inspect_pack` 导出全部文件后用 PIL 与本地源文件比 `ImageChops.difference` 的均值差，差值最小的那张即新入包项；不要只信 `ipc_res.json` 的自报结果。

- **跨进程群聊抓取与智能总结 (`summary_chat`)**：
```json
{
  "action": "summary_chat",
  "chat_id": <PRIVATE_IDENTIFIER>,
  "target": "6h"
}
```
返回数据格式：`{"ok": true, "msg": "📊 ...", "count": 208, "ts": <YOUR_USER_IDENTIFIER>}`。
当官方 Hermes Bot 因开启群聊降噪（`observe_unmentioned_group_messages: false`）未保留群聊全量闲聊记录时，外部进程或 Hermes 可通过写入 `ipc_cmd.json` 委托 UserBot 的 Telethon 客户端使用 `iter_messages` 抓取真实群聊历史并生成高质感总结，再由 Hermes 转换输出为原生 `<details><summary>` 折叠卡片。

`,sum` 支持参数：`parse_summary_target()` 解析条数（纯数字/`XX条`，15~400）或时间（`30m`/`1h`/`2小时`/`今日`/`N天`，最大 7 天）。省略参数默认近 80 条。有效发言 <3 条会报"过少"。

## 常见排障结论
- **Linux 无头服务器特殊字符（藏文/图腾/花体字）渲染失真或马赛克**：
  - **根本原因**：Linux 精简系统仅包含中日英基础字体。遇到 Unicode 藏文（如 `༒` U+0F12）或数学花体字时，Fontconfig 触发 fallback 机制降级调用系统自带的 `GNU Unifont`（16×16 粗糙点阵位图字体），导致被强制拼成低清阶梯马赛克。
  - **解决方案**：在服务器安装完整矢量字体 `sudo apt-get install -y fonts-tibetan-machine fonts-noto-core fonts-noto-extra && sudo fc-cache -f` 并重启渲染服务，即可输出平滑高精抗锯齿矢量图案。
- **Q 图名言贴纸（quote-api）核心排障要点与设计规范**：
  - **Bot Token 401 导致会员专属 Emoji（Emoji Status）丢失**：`quote-api` 依靠 Bot API `getCustomEmojiStickers` 下载会员专属状态表情与自定义 Emoji 贴纸。若传入已注销/失效的 Bot Token（如硬编码旧文件里的废弃 Token），API 返回 401: Unauthorized，`quote-api` 无法下载表情并在重试时静默剥离名字后的 Emoji。**规范**：`userbot.py` 必须统一从有效环境（如 `~/.hermes/.env` 的 `TELEGRAM_BOT_TOKEN`）读取已验证的健康 Token。
  - **群成员/管理员自定义头衔（rank）与标签识别（终极穿透方案）**：
    - **第一真源（零开销必中）：`msg.from_rank`**：现代 Telegram MTProto 协议直接将发言者的自定义管理头衔挂载在消息实体自身的 `from_rank` 属性上（例如 `msg.from_rank = '負心漢'`）。无需发起任何额外网络请求或权限查询，即使人形在群内是 0 权限平民号，也 100% 必定携带。
    - **第二真源：公开管理员列表（`ChannelParticipantsAdmins`）**：在超级群中，普通成员单查 `GetParticipantRequest` 会被 Telegram 以 `ChatAdminRequiredError` 拒绝；但 Telegram 强制保证**群管理员列表对所有人 100% 公开**，拉取 `iter_participants(filter=ChannelParticipantsAdmins)` 可提取全部管理员的 `rank` 与群主身份。
    - **MTProto 构造器类型错配陷阱**：若调用 `GetParticipantRequest`，channel 参数必须用 `utils.get_input_channel(...)` 转换为 `InputChannel`（构造器 `0xf35aec28`），严禁直接传 `InputPeerChannel`（`0x27bcb6fc`）。
    - **Telegram 原厂标签色彩与身份三轨标准（群主紫 vs 管理绿 vs 成员灰）**：
      - **群主 (Owner)**：淡紫色（`#8544c7` / `#b18fff`），`isCreator: True, isAdmin: True`。默认称呼：频道无 rank 默认为“所有者”，群聊无 rank 默认为“群主”。
      - **普通管理员 (Admin)**：鲜绿色（`#4fae5e` / `#5ec26f`），`isCreator: False, isAdmin: True`。默认称呼：无 rank 默认为“管理员”。
      - **普通群成员（带自定义头衔/称号/署名）**：**静音灰色**（`#8e8e93` / `#aaaaaa`），`isCreator: False, isAdmin: False`。
      - **普通群成员（无头衔）**：返回 `None`，完全不绘制标签，**严禁凭空捏造“群员”标签**。
    - **头衔提取硬编码踩坑防范（严禁无脑 isAdmin=True）**：
      - 提取到 `msg.from_rank` 或 `p_rank` 时，**严禁无脑硬编码返回 `isAdmin: True`**！必须先结合公开管理员名单（`ChannelParticipantsAdmins`）及 `get_permissions` 校验真实管理员身份：若发言者不在管理名单且无管理权限，即便携带自定义头衔，`isAdmin` 也必须赋予 `False`，交由底层渲染为原厂静音灰色标签，避免普通成员标签被误染成管理员专属鲜绿色。
    - **ChannelParticipantSelf 陷阱（引用自己发言时头衔丢失）**：当引用人形账号自己发出的消息时，Telethon 返回 `ChannelParticipantSelf`，其内部既无 `admin_rights` 也不属于 `ChannelParticipantAdmin`，导致 `perms.is_admin` 默认计算为 `False`。提取头衔必须优先读取 `getattr(perms.participant, 'rank', None)`，严禁将 `is_admin` 作为读取 rank 的前提门禁。
    - **匿名管理/频道发帖符号错配陷阱**：`chat_target`（`event.chat_id`）是带 `-100` 的负数，而 `sender.id`（Channel）是正数，直接 `sender.id == chat_target` 恒为 `False`。必须使用 `telethon.utils.get_peer_id(sender) == chat_target` 规范化比对。
    - **quote-api 内嵌图片协议**：UserBot 会把头像和媒体编码为 `data:image/...;base64,...`。`quote-api/utils/image-load-url.js` 必须识别 `data:` URL 并解码为 Buffer；头像的 `avatar.js` 也必须统一通过该加载器再交给 canvas，否则会出现 `Unsupported protocol data:` 或静默回退字母头像。修改后必须用真实 data-URL 调 `/generate.webp`，确认返回有效 WebP 且日志无加载错误。
    - **贴图生成与日志排障定位**：排查 `,q` 生成情况时，优先组合使用 `journalctl -u lemon-userbot -n 50 --no-pager`（查 Telethon 消息上送与文件上传）与 `journalctl -u lemon-quote-api -n 50 --no-pager`（查 `/generate.webp` 耗时、尺寸及报错）。
  - **Q图底色与字色**：底色由 `config.json` 的 `quote.bg_color` 控制，当前配置与代码兜底均为 `#000000`（纯黑）。字色由 quote-api `utils/quote-generate/index.js` 的 `lightOrDark(backgroundColorOne)` 自动判断：深色底 → `#fff` 白字，浅色底 → `#000` 黑字，**无需单独配置**。改底色字色自动跟变。
  - **禁止闪电徽章**：已在 `quote-api/utils/quote-generate/composer.js` 注释「助推闪电徽章已按爸爸要求永久停用」，勿再尝试恢复。
  - **调色板**：quote-api 渲染服务通过 `COLOR_PRESETS`（8个中文色名）与 21 种专属调色板支持名字颜色 `color_id`；底色与字色是独立参数，互不干扰。
  - **二级被回复发言嵌套控制**：`,q` / `,qs` 必须设 `include_reply = False`（纯净名言气泡，不带被回复引言）；`,qh` / `,qhs` 设 `include_reply = True`（保留被回复上下文引言框）。
  - **多发言连续合并（q N）与头像归属机制（群友甲乙各带头像，同人连发合并单头像）**：
    - **底层引擎缺陷**：`quote-api`（Node.js `methods/generate.js`）判定前后两句是否同人时使用的是 `validMessages[i - 1].chatId === validMessages[i].chatId`。若调用方未在消息顶层传入 `chatId`（仅在 `from.id` 传递），在 JS 中 `undefined === undefined` 恒为 `true`，导致不同群友的发言被误判为同人连续，前排群友头像全被剥离！
    - **规范解法**：调用端构建消息对象时必须显式注入 `chatId: user_id`；同时底层 `generate.js` 必须做两级防御：`const cid = msg.chatId || (msg.from && msg.from.id)`，且必须在 `cid && prevCid && String(cid) === String(prevCid)` 为真时才合并气泡去头像。这样有几个人发言就有几个独立头像；唯有同一个人连续发言才将头像归拢合并至最后一句展示。
- **Telegram AuthKeyDuplicatedError（跨 IP 并发/多机房 Session 复制与冲突陷阱）**：
  - **报错根因**：同一 `.session` 文件包含固定的底层 `auth_key` 鉴权实体（256 字节二进制）。若同一 `auth_key` 被检测到从两个不同的公网 IP 同时或交替发起活动 TCP 连接，Telegram MTProto 网关会认定凭证泄露/被盗，直接抛出 `AuthKeyDuplicatedError: The authorization key was used under two different IP addresses simultaneously`，并在服务端**永久吊销**该 Session。
  - **常见触发场景与排查真因**：
    1. **跨机器复制 `.session` 运行**：将 session 文件拷贝到打手 VPS（如 RackNerd）或本地跑爬虫/转存脚本；
    2. **同机不同出口 IP 并发**：UserBot 守护进程直连 AWS 公网 IP，而同机爬虫/临时脚本（如 `isolated_tg.py`）挂载了本地 SOCKS5 代理（如 `rn-tunnel` 1081 出口）或 VPN 并发请求，在 TG 看来依然是两个不同 IP；
    3. **临时 Session 副本陷阱**：通过 `shutil.copyfile` 复制到 `/tmp/*.session` 的副本包含完全相同的 `auth_key`，只要网络路由不同即会暴毙。
  - **关键区分（排除干扰）**：
    - **官方客户端无关**：手机、电脑官方 Telegram 客户端拥有独立签发的全新 `auth_key`，手机切换 WiFi/移动网络/代理**绝不可能**引起 UserBot 的 `AuthKeyDuplicatedError`；
    - **406（Duplicated）vs 401（Unregistered）**：用户在设备列表手动踢下线只会报 401，报 406 必为同一 `auth_key` 的多 IP 并发。
  - **规避与修复**：
    1. **严禁跨 IP 机器直接复制 `.session` 数据库**，专机专用；
    2. 主机与打手机必须彻底解耦：打手 VPS 优先使用独立的 **Bot Token**（`client.start(bot_token=BOT_TOKEN)`）直连私有频道下载视频，与 UserBot 彻底物理隔离；
    3. 若已被 Telegram 吊销失效，需删除旧 `.session` 与 `auth_state.json`，运行 `request_code.py` 重新向手机发码，再通过 `verify_code.py` 配合 2FA 密码登录恢复。
- **用户拿 `,ai` 想总结群里发言却"总记的是其他内容/跑偏/脑补"**：因为 `,ai` 根本不上送群聊历史，模型面前只有被回复的那一条或裸提问文本，只能自由发挥。正确做法是改用 `,sum /,总结`。这是最常见的误解。
- 想用 `,ai` 基于前文：需先回复某条具体消息再发 `,ai`，它只会带上那一条。
- **GitHub 容灾备份规范（Private 仓库）**：
- UserBot 代码已作为私人灾备仓库托管于 `nayeshiluo/lemon-userbot`（严格设置为 **Private**）。
- **绝密红线**：`.gitignore` 必须严密排除 `*.session*`（Telegram MTProto 授权密钥，一旦泄漏等同账号交出且会被风控永封）、`ipc_*.json`、`node_modules/`、`*.bak*`、`.env`。
- **组件完整性**：必须一同纳入 `quote-api/` 源码（需提前清除内部 `.git` 避免变 submodule）、全量 `requirements.txt` 和 `.env.example`。新机恢复仅需 `pip install -r requirements.txt` + `npm install --production`，运行 `request_code.py` 重新接收一次短信验证码即可满血复活。
- **`,ai` 报错闪退/3秒自删（如 API HTTP 400 unknown provider / model_not_found）**：
  - **现象**：用户执行 `,ai` 后，消息短暂变为 `❌ AI 回答失败: ...` 并在 3 秒后被 `event.delete()` 静默清除。
  - **排查路径**：
    1. 查 `journalctl -u lemon-userbot -n 30 --no-pager` 捕获具体异常信息。
    2. 若报错 `unknown provider for model gemini-3.8-flash-high` 或 HTTP 400，系底层 `cliproxyapi`（127.0.0.1:8317）在服务重启时因 DNS 抢跑未拉取到远端模型目录，进入 3 小时刷新真空期。
    3. 查 `journalctl -u cliproxyapi -n 30 --no-pager`；恢复方法：`systemctl restart cliproxyapi` 立即重拉模型，或检查 `systemd-resolved` 依赖。

## 人形号 session 清点与「同 key 副本」审计（多账号 / 多机排查）
触发：用户问「我有几个人形号 / 账号有没有问题」、怀疑人形掉线、或准备把 session 部署到新机器。

**核心判据：比 auth_key 指纹，不看文件名、不看 entities 里的频道列表。**
- 指纹相同 → 同一 auth_key 的**复制品**（跨机/临时副本），任意一处启动并与另一出口 IP 并发即 `AuthKeyDuplicatedError` 永久吊销。
- 指纹不同 → 同账号的**另一次独立登录**，可以并存，但同样严禁跨 IP 并发。

步骤：
1. 限定目录清点，别递归整盘：`find /home/ubuntu /opt /tmp -maxdepth 4 -name "*.session" -printf "%TY-%Tm-%Td %TH:%TM %s %m %p\n" | sort`
2. 一律只读打开（运行中的 session 被 UserBot 独占 SQLite 锁，另起客户端会 `database is locked` 甚至触发 406）：`sqlite3 "file:X.session?mode=ro" "select dc_id,hex(substr(auth_key,1,8)),server_address from sessions;"`
3. 取 `sessions` 表 auth_key 做 `hashlib.sha256(...).hexdigest()[:16]` 当指纹，跨文件横向比对。
4. 归属判断：`select id,name,username,phone from entities where id>0 order by id limit 5`；entities 为空 = 未登录空库残留，可直接判垃圾。要确认自身账号，对**当前未运行**的 session 短连 `get_me()`；运行中的只走 IPC 探活，绝不另连。
5. 反查克隆脚本：`grep -rl "\.session" /home/ubuntu --include=*.py`，重点抓 `shutil.copyfile` / 把主号 session 复制成 `temp_*.session` 再连的写法（`lemon-media-spider/crawl_pikpaklove.py` 就是这种）。
6. 权限：session 必须 `600`；`644` 等于同机任何用户可读走账号，算凭据泄漏面。
7. 批量跑：`scripts/audit_tg_sessions.py`（只读，输出每个文件的 dc / key 指纹 / 权限 / 账号候选）。

已知账号盘点（2026-10 实测基线，复用时须重新核实，别当永久事实）：
- `@zmz1008` 𝒩𝒾𝑔𝒽𝓉 𝒲𝒽𝒾𝓈𝓅𝑒𝓇，ID <PRIVATE_IDENTIFIER> → AWS `lemon-userbot` 主号，session `lemon_userbot.session`。
- Charles（无用户名），ID <YOUR_USER_IDENTIFIER> → vps-la `/root/lemon_channel_harvester.session`，音乐采集 `lemon-channel-harvest.timer` 每 45 分钟一轮。

坑：
- 该 venv 没装 `python-dotenv`，读 `.env` 自己 `split('=',1)` 即可，别为一次查询去装包。
- 精简机（vps-la 等）没有 `sqlite3` 命令，改用 `python3` 的 sqlite3 模块。
- 日志里高频 `Got difference for channel ... updates` 是离线补拉常态，**不等于**并发告警；406 才是。
- 汇报时把「账号本身健康」与「session 副本隐患」分开写，按危险度排序（会被自动执行的克隆脚本 > 闲置副本 > 空库残留 > 权限），别因为存在副本就说账号有问题；清理属破坏性动作，列完证据取授权再动。
- **审计前先分清两套链路，否则会审错对象**：生产 pipeline 走 `isolated_tg.py`（`sync_all_adult.py` / `lemon_crawler.py` 调用），而 `crawl_pikpaklove.py` / `av_actress_pipeline.py` / `crawl_and_save_new3.py` 只是手动脚本，其 TG 主函数在生产链里**不被调用**（只被 import 纯函数）。改错对象等于白改还差点搞挂早 6 点那轮。
- 只读打开用 `mode=ro`；要确认自身账号只能对**当前未运行**的 session 短连 `get_me()`，运行中的走 IPC 探活。

## 排障流程
- **,q / ,qs / ,sum 贴图或指令无响应排障（双轨定位）**：
   - **严禁并发打开 session 文件探活**：运行中的 UserBot 独占持有 `lemon_userbot.session` 的 SQLite 锁。若在外部另起 Python 脚本初始化 `TelegramClient(session_path)`，会报 `sqlite3.OperationalError: database is locked`，更严重者可能触发多连接并发探测导致 Telegram MTProto 判定密钥异常（`AuthKeyDuplicatedError` 风险）。
   - **无锁无害秒级探活（首选 IPC 管道）**：直接向 `/home/ubuntu/lemon-userbot/ipc_cmd.json` 写入探测指令（如 `{"action": "get_emoji_pack_info", "pack_name": "emoji_<PRIVATE_IDENTIFIER>_lemon"}`）。若 0.5 秒内在 `ipc_res.json` 获得返回（如 `ok: True`），可 100% 实锤证明 UserBot 进程在线、Telethon 事件循环健康且与 Telegram DC 保持通信。
   - **Telegram 官方 FloodWait 假死陷阱（特别是在 ,qs / ,add 时）**：
     - **现象**：用户执行 `,qs` 或 `,add` 想要将现成贴纸/图片入库，指令消息瞬间消失，但过了 10~20 秒毫无反应，用户误以为“人形掉线了”。
     - **根因**：下载被回复的图片/贴纸文件时，Telegram 服务端可能对 `GetFileRequest` 下发数秒至十数秒的短频控（`telethon.client.users - INFO - Sleeping for 12s on GetFileRequest flood wait`）。Telethon 默认会自动挂起睡眠等待，等待期间无任何 UI 动静。
     - **排查与验证**：查 `journalctl -u lemon-userbot -n 30 --no-pager`，观察是否有 `Sleeping for XXs on GetFileRequest flood wait`；随后紧跟 `Uploading file ... in 1 chunks` 即证明频控结束后已自动完成入库（可查 `q_{id}_lemon` 贴纸数量确认新增）。
     - **用户指引**：可让用户用小号发送 `,ping` 或 `,状态`，若秒回 `Pong!` 即可彻底打消用户的掉线疑虑。
   - 检查进程状态：`systemctl status lemon-userbot lemon-quote-api --no-pager`。
   - 若 `lemon-quote-api` 活跃而 `lemon-userbot` 处于 `inactive (dead)` / `failed`：
     - 执行 `journalctl -u lemon-userbot -n 50 --no-pager` 定位。
     - 若报错 `AuthKeyDuplicatedError`（异地 IP 并发导致 session 被 TG 官方服务端永久注销）：
       - **只读探测验证**（不破坏文件）：
         ```bash
         /home/ubuntu/lemon-userbot/venv/bin/python3 -c "import asyncio; from telethon import TelegramClient; client=TelegramClient('/home/ubuntu/lemon-userbot/lemon_userbot.session', <YOUR_USER_IDENTIFIER>, '<YOUR_TELEGRAM_CLIENT_API_HASH>'); asyncio.run(client.connect())"
         ```
       - **标准恢复协议**（向爸爸确认手机号后执行）：
         1. 清理已失效 session 及 `/tmp` 孤儿碎片（防止旧副本残留冲撞）：
            `rm -f /home/ubuntu/lemon-userbot/lemon_userbot.session* /home/ubuntu/lemon-userbot/auth_state.json /tmp/*.session /tmp/*_sync_*.session /tmp/crawler_*.session 2>/dev/null`
         2. 发送验证码：
            `/home/ubuntu/lemon-userbot/venv/bin/python3 /home/ubuntu/lemon-userbot/request_code.py <手机号>`
         3. 验证登录（含 2FA，验证码支持 5~6 位）：
            `/home/ubuntu/lemon-userbot/venv/bin/python3 /home/ubuntu/lemon-userbot/verify_code.py <验证码> [2FA密码]`
         4. 权限加固：
            `chmod 600 /home/ubuntu/lemon-userbot/lemon_userbot.session`
         5. 拉起服务并核查全链路：
            `sudo systemctl restart lemon-userbot && sudo systemctl status lemon-userbot --no-pager`
            `journalctl -u lemon-userbot -n 20 --no-pager`
            （必须确认输出 `UserBot running as: ...` 与 `Starting IPC Command listener loop...` 且无任何 406/401 拒连）
2. 先读 `userbot.py` 中对应 handler（如 `ai_ask_cmd_handler`、`summary_cmd_handler`、`fetch_and_generate_summary`）确认实际抓取逻辑，再下结论。
3. 区分「该命令设计上就不做 X」与「实现 bug」——多数时候是前者。
4. 涉及修改先向爸爸确认（他偏好单步只读排查，未经确认严禁改/删/重启）。
