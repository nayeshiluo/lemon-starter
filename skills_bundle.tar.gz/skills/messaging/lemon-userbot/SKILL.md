---
name: lemon-userbot
description: 柠檬 UserBot（Telethon 真人账号）命令语义与排障：区分 ,ai 单问单答 vs ,sum 群聊总结等。
---

# 柠檬 UserBot（Telethon 真人账号）命令语义与排障

爸爸的真人账号 UserBot，代码在 `/home/ubuntu/lemon-userbot/userbot.py`（约 1853 行）。运行于独立 venv（`/home/ubuntu/lemon-userbot/venv/`）。服务涉及 Q 图贴纸、Emoji 包、群聊总结、AI 问答、反撤回等。

## 触发条件
- 用户问 UserBot 某个命令为什么这样/那样、行为异常、或想了解指令用法。
- 涉及 `,q/.q`、`,sum`,`,ai`、`,qd/.qd`、`,qs/.qs`、`,antidel`、`,makee`、`,adde`、`,de`、`,emojis`、`,setemojipack` 等 UserBot 指令。

## 关键架构事实
- **LLM 调用是无状态、单轮的**：`call_llm_api()` 每次只构造 `messages = [system, user_input]` 发给 `http://127.0.0.1:8317/v1/chat/completions`（gemini-proxy），**没有任何跨轮记忆**。
- 两个核心 prompt：`SUMMARY_SYSTEM_PROMPT`（群聊总结，楪祈同款）与 `AI_ASK_SYSTEM_PROMPT`（单问单答）。两者输出均被统一转换为 Telegram 原生 `<blockquote expandable>` 折叠卡片。
- 输出会清理 ```html/``` 代码块包裹，并兼容转换 `<details><summary>` 为 `<blockquote expandable>`。

## 核心区分（易混，务必查清再答）
| 命令 | 语义 | 上下文来源 |
|------|------|-----------|
| `,sum` / `,总结` | **真正的群聊总结** | 用 `iter_messages` 真实抓取群里最多 **400 条**（`max_scan`），过滤指令开头（`,` `.` `，` `。` `/` `!`），按时间正序拼接后喂模型 |
| `,ai` / `,ask` / `,问` | **单问单答**，不是总结 | 只带「回复的那一条消息」或「你输入的提问文本」，**不抓群聊历史** |

## 会员状态 Emoji 与发光动态 Emoji 工作流
UserBot 维护两套专属会员状态 Emoji 包（通过 `telethon` 上传 `CreateStickerSetRequest`/`AddStickerToSetRequest`，带 `emojis=True`）：
1. **静态状态 Emoji 包**（`emoji_{id}_lemon`）：100×100 WebP、1px 细边框 + 2px 微圆角 + NotoSansCJK-Regular 400 + 纯透明底。
2. **动态发光 Emoji 包**（`glow_{id}_lemon`）：100×100 WebM（VP9 + `yuva420p` 透明通道 + 30fps/30帧 1.0s 循环）、双层渲染（外层高斯模糊呼吸霓虹 + 内层硬核高亮文字与边框）。

### IPC 批量更新与添加协议
外部脚本可通过写 `/home/ubuntu/lemon-userbot/ipc_cmd.json` 由 UserBot 守护进程自动消费并在 `ipc_res.json` 返回结果：
```json
{
  "action": "add_to_emoji_pack",
  "pack_name": "emoji_8903499998_lemon",
  "animated": false,
  "items": [
    {"path": "/tmp/static_emojis/帅哥.webp", "name": "帅哥", "emoji": "😎"}
  ]
}
```
动态发光包设置 `"animated": true` 并传入 `.webm` 文件路径即可。

`,sum` 支持参数：`parse_summary_target()` 解析条数（纯数字/`XX条`，15~400）或时间（`30m`/`1h`/`2小时`/`今日`/`N天`，最大 7 天）。省略参数默认近 80 条。有效发言 <3 条会报"过少"。

## 常见排障结论
- **Telegram AuthKeyDuplicatedError（跨 IP 并发/多机房 Session 冲突）**：
  - **报错根因**：同一 `.session` 文件（AuthKey）同时在两个不同的 IP（如旧 AWS 节点与新 VPS）并发发起连接或调用 `GetFileRequest` 下载文件。Telegram MTProto 服务端检测到异常异地并发后，会抛出 `AuthKeyDuplicatedError: The authorization key was used under two different IP addresses simultaneously` 并永久吊销该会话。
  - **规避与修复**：跨机迁移或部署独立打手节点时，严禁让两台机器同时加载同一个活跃 session 文件。迁移前必须先完全停止旧机进程；若已触发吊销，需删除失效的 `.session` 文件，在新机上重新输入手机号与 TG 验证码生成全新的独立 Session。
- **用户拿 `,ai` 想总结群里发言却"总记的是其他内容/跑偏/脑补"**：因为 `,ai` 根本不上送群聊历史，模型面前只有被回复的那一条或裸提问文本，只能自由发挥。正确做法是改用 `,sum /,总结`。这是最常见的误解。
- 想用 `,ai` 基于前文：需先回复某条具体消息再发 `,ai`，它只会带上那一条。

## 排障流程
1. 先读 `userbot.py` 中对应 handler（如 `ai_ask_cmd_handler`、`summary_cmd_handler`、`fetch_and_generate_summary`）确认实际抓取逻辑，再下结论。
2. 区分「该命令设计上就不做 X」与「实现 bug」——多数时候是前者。
3. 涉及修改先向爸爸确认（他偏好单步只读排查，未经确认严禁改/删/重启）。
