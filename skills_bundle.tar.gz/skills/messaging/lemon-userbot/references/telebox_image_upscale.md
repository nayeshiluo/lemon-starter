# TeleBox 与 UserBot 图像超分与画质重构技术架构

本文档记录 UserBot 在 Telegram 场景下实现高质感图像增强、AI 超分辨率与画质修复的底层技术选型与工程实践。

## 1. 核心技术选型演进与避坑总结

| 方案阶段 | 技术路线 | 缺陷 / 陷阱 | 最终定型 |
|---|---|---|---|
| **阶段一** | PIL Lanczos 数学插值 + UnsharpMask 锐化 | 仅像素拉伸，无法脑补真实纹理细节，且易被 TG Photo 降采样压糊 | ❌ 废弃 |
| **阶段二** | 共享代理多模态视觉 API (Gemini/Codex) | 极易遭遇 `429 RESOURCE_EXHAUSTED` 配额耗尽而隐蔽降级回老算法 | ❌ 线上不可靠 |
| **阶段三** | **TeleBox 原版 Nano-Banana (Google Gemini 直连)** | 用户通过 `,banana key 密钥` 绑定专属 Key 直连 Google TPU 集群，3~5秒极速 4K 多模态重绘 | ✅ 主通道 |
| **阶段四** | **Real-ESRGAN NCNN Vulkan (本地轻量化模型)** | 无 Key 或外部断网时的离线兜底，按需调用 ~200MB 峰值，完成真实 AI 神经网络超分 | ✅ 兜底通道 |

## 2. TeleBox 原版 Nano-Banana 架构实现

### 2.1 请求管线
- 端点：`https://generativelanguage.googleapis.com/v1beta/models/gemini-3-pro-image-preview:generateContent?key={apiKey}`
- 载荷：`{ contents: [{ role: "user", parts: [{ text: prompt }, { inline_data: { mime_type, data: base64 } }] }], generationConfig: { responseModalities: ["TEXT", "IMAGE"] } }`
- 响应：提取 `candidates[0].content.parts[].inline_data.data` 进行 Base64 解码与发送。

### 2.2 用户配置与管理指令
- `,banana key <API_KEY>`：写入 `banana_config.json` 保存。
- `,banana config`：查看当前绑定的 API Key 掩码及配置状态。
- `,banana 提示词` / `,hd 提示词` / `,清晰`：以图生图与画质重构。

## 3. 本地 Real-ESRGAN CPU 兜底部署指南

### 3.1 系统依赖
```bash
sudo apt-get update -qq && sudo apt-get install -y -qq mesa-vulkan-drivers libvulkan1
```
* `mesa-vulkan-drivers` 提供 CPU 软件模拟 Vulkan 实现（llvmpipe 256 bits），免去对硬件独立 GPU 的强依赖。

### 3.2 性能与内存剖析实测 (AWS EC2 / 2GB RAM)
* **常驻内存 (Idle)**: `0 MB`（子进程按需启动，用完即退出）
* **运行峰值 (Peak RSS)**: `205 MB` (2x) / `214 MB` (4x)
* **CPU 软件渲染耗时**: `~10s ~ 45s`（取决于原图尺寸，因而优先推荐绑定 Gemini Key 走 Google 3秒云端集群）
* **内存释放**: 子进程退出后操作系统毫秒级 100% 回收，不影响系统平稳运行。

## 4. Telegram 客户端与排坑指南
* **HTML 转义模块**：格式化 `<blockquote expandable>` 消息时调用 `html.escape()`，必须在脚本头部显式 `import html` 与 `import urllib.parse`，避免在发送前抛出 `NameError`。
* **无损文档 vs 照片直发**：高精细节在作为文件（Document）发送时不会被 TG 服务端压缩；作为 Photo 发送时则有直观大图预览。
