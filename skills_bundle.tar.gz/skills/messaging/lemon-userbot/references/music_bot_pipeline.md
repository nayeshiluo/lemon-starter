# 音乐点播与音频解析服务架构设计（群霸 Bot /music 指令）

对标 Telegram 原生优秀音乐机器人 `@Music163bot`（基于 `XiaoMengXinX/Music163bot-Go`），在不消耗额外商业 API 费用的前提下，实现群内点播与音频提取。

## 1. 核心交互流程
1. **口令触发**：
   - `/music <歌名/歌手>`：例如 `/music 晴天 周杰伦`、`/music 富士山下`
   - `/music <歌曲ID>`：例如 `/music 186016`
   - 自动嗅探网易云链接：`https://music.163.com/#/song?id=xxx` 或 APP 短链 `163cn.tv/xxx`
2. **候选交互**：
   - 歌名搜索调取网易云曲库接口 `https://music.163.com/api/search/get?s=...&type=1&limit=5`，提取 Top 5 候选歌曲。
   - 生成带 `[1] [2] [3] [4] [5]` 数字的 Telegram Inline Keyboard 内联按钮。
3. **音频投递**：
   - 用户点击数字或直接输入 ID 时，后台调取音频流并注入 ID3 标签。
   - 通过 `context.bot.send_audio` 原生音频组件发送，自带封面、歌名、歌手与播放进度条。

## 2. 音频下载“双轨自愈引擎”（解决 VIP 与海外版权拦截）
网易云官方对部分热门版权曲目（如周杰伦、陈奕迅）及海外 IP 有严格限制，采用双轨制突破：
- **主轨：网易云官方外链 CDN**
  - 请求 `http://music.163.com/song/media/outer/url?id={song_id}.mp3`
  - 若 `Content-Type` 为 `audio/mpeg` 且大小正常，直接流式下载（速度极快，自带官方元数据）。
- **副轨：B站 Hi-Res 音频中继流式转码**
  - 当官方外链返回 404/html 页面时，自动提取关键词并发起 B站无损视频搜索。
  - 通过常驻 RackNerd 中继获取音视频流，调用本机 `ffmpeg -vn -c:a libmp3lame -b:a 320k` 实时提取高质量 MP3。
  - 100% 保证热门曲目与下架曲目的音频可用性。

## 3. ID3v2 标签注入规范（mutagen）
下载音频后，必须使用 `mutagen.mp3` 与 `mutagen.id3` 注入元数据，否则 Telegram 播放器无法解析歌名与封面：
- `TIT2`：歌曲标题
- `TPE1`：歌手名称
- `TALB`：专辑名称
- `APIC`：专辑封面（二进制 JPEG/PNG，`type=3` Front Cover）
