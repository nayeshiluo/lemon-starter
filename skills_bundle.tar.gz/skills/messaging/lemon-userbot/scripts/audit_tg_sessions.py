#!/usr/bin/env python3
"""只读清点 Telethon session 文件：dc / auth_key 指纹 / 权限 / 账号候选。

用途：判断多个 .session 是「同一 auth_key 的复制品」（高危，跨 IP 并发即 406 永封）
还是「同账号的独立登录」。全程 sqlite mode=ro，不写文件、不连网、不触发 SQLite 锁。

用法：
  python3 audit_tg_sessions.py                     # 扫默认目录
  python3 audit_tg_sessions.py /path/a.session /root/b.session
  python3 audit_tg_sessions.py --root /home/ubuntu --root /opt --root /tmp

判读：
  同一 keyfp 出现在两个文件 → 复制品。危险条件是「从不同出口 IP / 不同机器启动」；
  同机同出口 IP 的多进程复用目前被 Telegram 放行（2026-10-24 生产 pipeline 实测通过），
  所以不要把 /tmp 临时副本一律判成致命，按出口 IP 判级。
  entities 为空 → 未登录空库残留，可直接判垃圾。
  权限非 600 → 同机其他用户可读走账号，属凭据泄漏面。
"""
import argparse
import hashlib
import os
import sqlite3
import stat
import sys

DEFAULT_ROOTS = ["/home", "/root", "/opt", "/tmp"]
MAX_DEPTH = 4


def find_sessions(roots, max_depth=MAX_DEPTH):
    out = []
    for root in roots:
        if not os.path.isdir(root):
            continue
        base_depth = root.rstrip("/").count("/")
        for dirpath, dirnames, filenames in os.walk(root):
            if dirpath.count("/") - base_depth >= max_depth:
                dirnames[:] = []
            for name in filenames:
                if name.endswith(".session"):
                    out.append(os.path.join(dirpath, name))
    return sorted(set(out))


def inspect(path):
    info = {
        "path": path,
        "size": None,
        "mode": None,
        "sessions": [],
        "entities": [],
        "error": None,
    }
    try:
        st = os.stat(path)
        info["size"] = st.st_size
        info["mode"] = stat.S_IMODE(st.st_mode)
    except OSError as exc:
        info["error"] = f"stat: {exc}"
        return info

    try:
        conn = sqlite3.connect(f"file:{path}?mode=ro", uri=True, timeout=2)
        try:
            for dc_id, key, server in conn.execute(
                "select dc_id, auth_key, server_address from sessions"
            ):
                fp = hashlib.sha256(key or b"").hexdigest()[:16]
                info["sessions"].append({"dc": dc_id, "keyfp": fp, "server": server})
            for row in conn.execute(
                "select id, name, username, phone from entities "
                "where id > 0 order by id limit 8"
            ):
                info["entities"].append(row)
        finally:
            conn.close()
    except sqlite3.Error as exc:
        info["error"] = f"sqlite: {exc}"
    return info


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("paths", nargs="*", help="显式 session 文件路径")
    ap.add_argument("--root", action="append", default=None, help="扫描根目录，可多次")
    args = ap.parse_args(argv)

    if args.paths:
        paths = args.paths
    else:
        paths = find_sessions(args.root or DEFAULT_ROOTS)

    if not paths:
        print("未找到 .session 文件")
        return 0

    by_fp = {}
    results = []
    for path in paths:
        info = inspect(path)
        results.append(info)
        for s in info["sessions"]:
            by_fp.setdefault(s["keyfp"], []).append(path)

    for info in results:
        mode = "-" if info["mode"] is None else oct(info["mode"])
        print(f"=== {info['path']}  size={info['size']} mode={mode}")
        if info["error"]:
            print(f"    ERROR {info['error']}")
        if not info["sessions"]:
            print("    sessions: (空库 / 未登录)")
        for s in info["sessions"]:
            shared = by_fp.get(s["keyfp"], [])
            tag = "  <== 同 key 副本 %d 份" % len(shared) if len(shared) > 1 else ""
            print(f"    dc={s['dc']} keyfp={s['keyfp']} server={s['server']}{tag}")
        if info["mode"] is not None and info["mode"] & 0o077:
            print("    WARN 权限过宽，应为 600")
        for e in info["entities"][:5]:
            print(f"    entity {e[0]} | {e[1]} | @{e[2]} | {e[3]}")

    dup = {fp: ps for fp, ps in by_fp.items() if len(ps) > 1}
    if dup:
        print("\n[高危] 以下 auth_key 存在多份复制，严禁同时从不同出口 IP 启动：")
        for fp, ps in dup.items():
            print(f"  {fp}: " + " , ".join(ps))
    return 0


if __name__ == "__main__":
    sys.exit(main())
