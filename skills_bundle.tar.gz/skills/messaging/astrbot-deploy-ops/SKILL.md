---
name: astrbot-deploy-ops
description: 部署/运维 AstrBot（TG/QQ 多平台 AI Bot）：uv 安装、面板 API、中转站接入、菜单中文化。
version: 1.0.0
author: 柠檬
license: MIT
metadata:
  hermes:
    tags: [astrbot, telegram, bot, deployment, uv, systemd, menu]
    related_skills: [telegram-group-assistant, hermes-custom-providers, relay-station-ops]
---

# AstrBot 部署与运维

## When to Use

- 要新搭一台 AstrBot（Telegram / QQ / Discord 多平台 AI Bot）
- AstrBot 面板连不上、外网超时、服务起不来
- 要给 AstrBot 接自建/第三方 OpenAI 兼容中转站模型
- 要把 AstrBot 的 Telegram 指令菜单中文化或精简
- AstrBot 升级后菜单补丁失效需要重打


## 1. 选机器

- 官方文档**没有** CPU/内存最低要求。实际占用：空载 RSS ≈ 180 MiB，启动后可用内存再掉约 100 MiB。
- 重负载变量：Agent 沙箱、多插件（翻唱类吃几 G）、知识库向量库、高并发。
- 模型推理在远端，**不需要 GPU**。
- 结论：**别塞进 1.9G 的 AWS 小机**（会挤压已有服务）；913Mi 的小鸡足够跑纯聊天 + 轻插件。翻唱/人声分离这类插件要另配后端。

## 2. 安装：uv 优先，Docker 次之

小内存机别上 Docker（多一个 daemon + 镜像层）。Python 需 ≥3.12（仓库 `.python-version` = 3.12）。

```bash
curl -LsSf https://astral.sh/uv/install.sh | sh
uv tool install astrbot --python 3.12      # 可执行文件在 /root/.local/bin/astrbot
```

### init 的坑
`astrbot init` 是**交互式**的，在 `/root` 下会报 `Error: Initialization failed:`。必须：

```bash
mkdir -p /opt/astrbot && cd /opt/astrbot && printf "Y\n" | astrbot init
```

数据根目录由 `ASTRBOT_ROOT` 或 **cwd** 决定，产出 `/opt/astrbot/.astrbot`、`/opt/astrbot/data/{config,plugins,temp}`。

### systemd
```ini
[Unit]
Description=AstrBot
After=network-online.target
[Service]
Type=simple
WorkingDirectory=/opt/astrbot
ExecStart=/root/.local/bin/astrbot run
Restart=always
RestartSec=5
Environment=HOME=/root
Environment=PATH=/root/.local/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
[Install]
WantedBy=multi-user.target
```
`WorkingDirectory` 必须对，否则数据目录会跑到别处。

## 3. 外网访问

面板默认 `0.0.0.0:6185`。机器 ufw 默认 DROP 时**必须显式放行**，否则本机 curl 通、外面全超时：

```bash
ufw allow 6185/tcp comment "AstrBot WebUI"
```

要隐藏真实 IP → CF 橙云 + nginx TLS 反代到 `127.0.0.1:6185`（用 CF 支持的端口如 8443）。证书用 `acme.sh --dns dns_cf`（DNS-01，不占 80 端口）。

## 4. 面板 API（自动化配置走这里，别手改 JSON）

登录：`POST /api/auth/login` `{"username","password"}` → `data.token`。
**必须** `Authorization: Bearer <token>`；cookie 单独用会 401 `未授权`。
业务接口前缀 `/api/v1`（`API_V1_PREFIX`）。

| 用途 | 端点 |
|---|---|
| 机器人 | `GET/POST /api/v1/bots`，`PUT /api/v1/bots/by-id` |
| 模型源 | `GET/POST /api/v1/provider-sources`，`GET /{id}/models` |
| 源下建模型 | `POST /api/v1/provider-sources/{id}/providers` |
| 模型 | `GET/POST /api/v1/providers`，`DELETE /by-id?provider_id=`，`POST /{id}/test` |
| 配置档 | `GET/PUT /api/v1/config-profiles/default` |
| 指令 | `GET /api/v1/commands`，`PATCH /api/v1/commands/{handler_full_name}` |

请求体要点：
- bot：`{id, name, type:"telegram", enable:true, config:{telegram_token}}`
- 源：`{id, type:"openai_chat_completion", enable:true, api_base, key:["sk-..."]}` ← key 是**数组**
- 源下的模型：`{id, type:"openai_chat_completion", model, enable:true}` ← **`id` 必填**，只给 `{models:[...]}` 会 400
- 改默认模型：读 `GET /config-profiles/default` 全量 → 改 `agent_runner.config.model.provider_id` → `PUT` 全量回去。PUT 会忽略并服务端重注入 `provider_sources`/`provider`/`platform`，这三块改不动。

自建 OpenAI 兼容中转站（New API / WorkBuddy2API 之类）直接当 `openai_chat_completion` 源用，`api_base` 带 `/v1`。

## 5. TG 指令菜单中文化（核心补丁）

### 为什么必须改源码
- 菜单描述来自 handler **docstring**，全英文。
- 面板 `PATCH /api/v1/commands/{id}` **只能改** `enabled` / `alias` / `permission_group`，**没有 description 字段**。
- 改插件源码会被插件升级覆盖；改核心 `tg_adapter.py` 只需升级后重打。

### 补丁脚本（幂等，已固化）
`scripts/zh-menu-patch.py` → 拷到目标机 `/root/astrbot-zh-menu-patch.py`。四步：
1. 模块级插入 `_COMMAND_DESC_ZH = {command: "中文"}`（**必须插在 `@register_platform_adapter(...)` 装饰器之前**，插 class 前会隔开装饰器导致 `SyntaxError`）
2. `collect_commands()` 的 return 改为 `_COMMAND_DESC_ZH.get(cmd) or command_dict[cmd]`
3. 默认菜单过滤掉 `_OWNER_ONLY_COMMANDS`
4. 给 `_FULL_MENU_CHAT_IDS` 里的 chat 用 `BotCommandScopeChat` 单独设全量菜单

```bash
python3 /root/astrbot-zh-menu-patch.py && systemctl restart astrbot
```

### 关键坑
- **Telegram BotCommand 只接受 ASCII 命令名**。`/签到`、`/搜索歌曲`、`/qq点歌` 这类中文名指令**永远进不了菜单栏**，只能手打。菜单条数 ≠ 指令总数是正常的。
- `last_command_hash` 是 `(command, description)` 的哈希：改了描述哈希就变，重启后自动 `delete_my_commands` + `set_my_commands`，不用手动清。
- 编辑 site-packages 后**必须重启**；改文件期间进程用的是内存里的旧模块，bot 仍能跑，但重启就会崩——所以每次改完先 `compile()` 校验再落盘。
- `uv tool upgrade astrbot` 会覆盖补丁，升级后必须重跑脚本。

### 分 scope 菜单
默认菜单精简（普通群友只看常用），管理员私聊看全量——这是 Telegram scope 机制，**权限没变**，只是菜单显示不同。`getMyCommands` 校验：
```
{"scope": {"type": "chat", "chat_id": <uid>}}
```

## 5.1 坑：群聊回复被吞（LLM 有输出但发不出去）

症状：群聊 `Prepare to send - xxx: `（内容为空）、`provider_stats` 有 `token_output` 但 `conversations` 不落库、用户看不到回复。

排查顺序（按命中率）：
1. **`astrbot_plugin_private_companion` 的 `intercept_astrbot_group_context=true`** —— 劫持 AstrBot 原生群聊上下文，restore 失败时把 `request.conversation` 置 None，回复不落库也不发出。**最常见元凶**，设 `false` 即恢复。
2. 同插件 `enable_smart_silence` / `enable_passive_response_review` / `enable_group_air_reply_guard` 会判定「不该回」，一并关掉做对照。
3. `provider_settings.streaming_response=true` 时群聊走 `edit_message_text fallback`（`tg_event.py:615`），发送后无结果日志。关掉可排除。
4. 模型偶发全 reasoning 无 content（`token_output` 很小、content 空）—— 换模型。

改法：`/api/v1/config-profiles/default` 返回 `{config, metadata}`，**只能 PUT `data["config"]`**，PUT 整个 data 报 `agent_runner must be an object`。插件配置直接改 `/opt/astrbot/data/config/<plugin>_config.json` 后重启。

## 5.2 坑：Telegram 引用回复（Reply）唤醒失效

`waking_check` 用 `str(Reply.sender_id) == str(get_self_id())` 判断，而 TG 适配器 `message.self_id = str(bot.username)`，原生 `sender_id` 却是数字 ID → 永远不等。修法：`sender_id` 填 `str(context.bot.username)`，**`qq` 必须保持 int**（填字符串会 pydantic 报 `qq / value is not a valid integer`，每条引用消息都崩）。此补丁已收进 `scripts/zh-menu-patch.py`。

## 5.3 坑：`/p` 报「所有图片均下载失败」

`astrbot_plugin_get_px` 走 lolicon API，返回的 `i.pixiv.re` 链接实测可用（200）。偶发 `last_reason=http_404` 是单个作品被删/转私密，重试即可。备选反代 `i.pixiv.cat`(500)、`proxy.pixivel.moe`(不可达) 别配。

## 6. 验证清单

```bash
systemctl is-active astrbot
ss -ltnp | grep 6185
journalctl -u astrbot --since "1 min ago" | grep -iE "telegram|error|Traceback"
```
日志要看到 `Telegram Platform Adapter is running.` + `Starting Telegram polling...` 且无 traceback。
菜单：调 TG `getMyCommands`（token 从 `/opt/astrbot/data/cmd_config.json` 的 `platform[].telegram_token` 读，别写进命令行历史）。
模型：`POST /api/v1/providers/{id}/test` → `status: available`。

## 7. 其它要点

- `astrbot` 子命令：`conf` / `help` / `init` / `password` / `plug` / `run`。`conf` 只能改时区、日志级别、面板端口/账号/密码，**改不了** provider/platform。
- 群聊使用前让用户在 BotFather 里 `/setprivacy → Disable`，否则收不到普通群消息。
- 中转站白嫖号常有账号类型限制：`global:gpt-*` 可能报 `model [...] is not allowed for user type [personal_free_user]`（code 11158），这种模型直接删掉别留着当默认。
- 面板密码用 `astrbot password` 改，或 `astrbot conf` 设置；初始随机密码只打印在首次启动日志里。
