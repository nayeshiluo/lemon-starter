#!/usr/bin/env python3
"""AstrBot Telegram 适配器补丁（幂等、可增量）

用途：AstrBot 升级会覆盖 site-packages 里的 tg_adapter.py，升级后运行本脚本即可恢复：
    python3 /root/astrbot-zh-menu-patch.py && systemctl restart astrbot

两个独立补丁，各自幂等，缺哪个补哪个：
  A. 菜单中文化 + scope 分级（默认精简，指定 chat 全量）
  B. 引用回复唤醒修复（Reply.sender_id 填 bot username，qq 保持 int）
"""
import sys

TG_DIR = (
    "/root/.local/share/uv/tools/astrbot/lib/python3.12/site-packages"
    "/astrbot/core/platform/sources/telegram"
)
PATH = TG_DIR + "/tg_adapter.py"

ZH_MAP = '''_COMMAND_DESC_ZH = {
    # builtin_commands
    "help": "显示帮助信息",
    "sid": "查看会话 ID 等信息",
    "name": "设置当前会话的显示名",
    "reset": "清空当前对话上下文",
    "stop": "停止 AI 执行",
    "new": "开启新对话",
    "stats": "查看当前对话的 Token 用量",
    "provider": "查看或切换大模型",
    "dashboard_update": "更新 AstrBot 面板",
    "set": "设置会话变量",
    "unset": "删除会话变量",
    # get_px
    "p": "搜索/随机二次元图片",
    # listen_music
    "搜索歌曲": "搜索 B 站歌曲并语音听歌",
    # matsuko_cover
    "翻唱帮助": "AI 翻唱功能帮助",
    "rvc": "用 RVC 引擎翻唱",
    "svc": "用 SVC 引擎翻唱",
    "svcvc": "用 SVCVC 引擎翻唱",
    "qqrvc": "QQ 音乐点歌后用 RVC 翻唱",
    "qqsvc": "QQ 音乐点歌后用 SVC 翻唱",
    "qqsvcvc": "QQ 音乐点歌后用 SVCVC 翻唱",
    "qq点歌": "搜索 QQ 音乐歌曲",
    "本地翻唱": "用本地音频文件翻唱",
    "刷新rvc模型": "刷新 RVC 模型列表",
    "刷新svc模型": "刷新 SVC 模型列表",
    "刷新svcvc音色": "刷新 SVCVC 音色列表",
    "设置rvc后端链接": "设置 RVC 后端地址",
    "设置svc后端链接": "设置 SVC 后端地址",
    "设置svcvc后端链接": "设置 SVCVC 后端地址",
    "查看翻唱任务": "查看翻唱任务状态",
    "取消翻唱任务": "取消翻唱任务",
    "我的翻唱统计": "查看我的翻唱统计",
    "查看翻唱缓存": "查看翻唱缓存占用",
    "清理翻唱缓存": "清理翻唱缓存",
    "列出msst模型": "列出人声分离模型",
    "切换msst模型": "切换人声分离模型",
    "列出svcvc分离模型": "列出 SVCVC 分离模型",
    "切换svcvc分离模型": "切换 SVCVC 分离模型",
    "翻唱选择": "翻唱菜单选项",
}


'''

CONSTS = '''
# 仅管理员向的指令，不出现在默认菜单里
_OWNER_ONLY_COMMANDS = {"dashboard_update", "set", "unset", "name"}
# 这些 chat 使用完整菜单（全部指令）
_FULL_MENU_CHAT_IDS = [<YOUR_TELEGRAM_ID>]
'''

REPLY_OLD = '''                message.message.append(
                    Comp.Reply(
                        id=reply_abm.message_id,
                        chain=reply_chain,
                        sender_id=reply_abm.sender.user_id,
                        sender_nickname=reply_abm.sender.nickname,
                        time=reply_abm.timestamp,
                        message_str=reply_message_str,
                        text=reply_message_str,
                        qq=reply_abm.sender.user_id,
                    ),
                )'''

REPLY_NEW = '''                _reply_sender_is_bot = bool(
                    update.message.reply_to_message
                    and update.message.reply_to_message.from_user
                    and update.message.reply_to_message.from_user.id
                    == context.bot.id
                )
                _reply_sender_id = (
                    str(context.bot.username)
                    if _reply_sender_is_bot
                    else reply_abm.sender.user_id
                )
                message.message.append(
                    Comp.Reply(
                        id=reply_abm.message_id,
                        chain=reply_chain,
                        sender_id=_reply_sender_id,
                        sender_nickname=reply_abm.sender.nickname,
                        time=reply_abm.timestamp,
                        message_str=reply_message_str,
                        text=reply_message_str,
                        qq=reply_abm.sender.user_id,
                    ),
                )'''


def apply_menu(src: str) -> tuple[str, bool]:
    if "_COMMAND_DESC_ZH" in src:
        return src, False

    old_imp = "from telegram import BotCommand, Update"
    if old_imp in src:
        src = src.replace(
            old_imp, "from telegram import BotCommand, BotCommandScopeChat, Update", 1
        )

    anchor = '@register_platform_adapter("telegram", "telegram 适配器")'
    if anchor not in src:
        anchor = "class TelegramPlatformAdapter(Platform):"
    if anchor not in src:
        raise RuntimeError("菜单补丁：找不到插入锚点")
    src = src.replace(anchor, ZH_MAP + CONSTS + "\n" + anchor, 1)

    old_return = "        return [BotCommand(cmd, command_dict[cmd]) for cmd in commands_a]"
    new_return = """        return [
            BotCommand(cmd, _COMMAND_DESC_ZH.get(cmd) or command_dict[cmd])
            for cmd in commands_a
        ]"""
    if old_return not in src:
        raise RuntimeError("菜单补丁：找不到 collect_commands 的 return 语句")
    src = src.replace(old_return, new_return, 1)

    old_reg = """                self.last_command_hash = current_hash
                await self.client.delete_my_commands()
                await self.client.set_my_commands(commands)"""
    new_reg = """                self.last_command_hash = current_hash
                await self.client.delete_my_commands()
                public_commands = [
                    c for c in commands if c.command not in _OWNER_ONLY_COMMANDS
                ]
                await self.client.set_my_commands(public_commands)
                for _chat_id in _FULL_MENU_CHAT_IDS:
                    try:
                        await self.client.set_my_commands(
                            commands,
                            scope=BotCommandScopeChat(chat_id=_chat_id),
                        )
                    except Exception as _e:
                        logger.warning(
                            f"为 {_chat_id} 设置完整指令菜单失败: {_e!s}",
                        )"""
    if old_reg not in src:
        raise RuntimeError("菜单补丁：找不到 register_commands 的注册代码")
    src = src.replace(old_reg, new_reg, 1)
    return src, True


def apply_reply(src: str) -> tuple[str, bool]:
    if "_reply_sender_is_bot" in src:
        return src, False
    if REPLY_OLD not in src:
        raise RuntimeError("引用回复补丁：找不到 Comp.Reply 构造块")
    src = src.replace(REPLY_OLD, REPLY_NEW, 1)
    return src, True


def main() -> int:
    src = open(PATH, encoding="utf-8").read()

    src, did_menu = apply_menu(src)
    src, did_reply = apply_reply(src)

    if not did_menu and not did_reply:
        print("两个补丁都已存在，无需重复处理")
        return 0

    import shutil
    import time

    bak = f"{PATH}.bak-{time.strftime('%Y%m%d%H%M%S')}"
    shutil.copy2(PATH, bak)
    print("备份:", bak)

    compile(src, PATH, "exec")
    open(PATH, "w", encoding="utf-8").write(src)
    print(f"已应用: 菜单中文化={'是' if did_menu else '跳过'} 引用回复修复={'是' if did_reply else '跳过'}")
    print("语法校验通过。请执行: systemctl restart astrbot")
    return 0


if __name__ == "__main__":
    sys.exit(main())
