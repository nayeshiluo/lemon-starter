# AstrBot 群聊唤醒实测案例（Telegram）

> 环境：AstrBot v4.29.3，uv tool 安装，单群 + 私聊，`@dafeiyu120_bot`。
> 症状：群主报「只有 @ 才有反应，`大肥鱼` 前缀和回复发言都触发不了」。

## 1. 配置基线（先确认这几项，再谈别的）

```json
{
  "wake_prefix": ["/大肥鱼"],
  "platform_settings": {
    "enable_id_white_list": true,
    "id_whitelist": ["<PRIVATE_IDENTIFIER>"],
    "wl_ignore_admin_on_group": true,
    "rate_limit": {"time": 60, "count": 30, "strategy": "stall"},
    "ignore_at_all": false
  },
  "admins_id": ["astrbot", "<YOUR_TELEGRAM_ID>", "<PRIVATE_IDENTIFIER>"]
}
```

配套平台侧确认：

```
getMe          → can_read_all_group_messages: True   # 隐私模式已关
getChat        → 人🐔局（执着白嫖）, type: supergroup
getChatMember  → bot 身份 administrator
```

结论：投递层、白名单、权限都通，问题在唤醒判定。

## 2. 日志归因（关键手法）

三条测试消息，靠 `preprocess_stage` 的群 ID 警告确认全部来自群聊：

```
10:53:06  event_bus: zjw120/<YOUR_TELEGRAM_ID>: 大肥鱼 叫爸爸
10:53:06  WARN preprocess: Session telegram-main:GroupMessage:<PRIVATE_IDENTIFIER> has no speech-to-text...
          → 无 respond 日志 = 未唤醒

10:53:35  event_bus: [引用消息(dafeiyu120_bot: 💰 本次发图消耗 20 金币...)] / 叫爸爸
10:53:35  WARN preprocess: GroupMessage:<PRIVATE_IDENTIFIER> ...
          → 无 respond 日志 = 未唤醒

10:53:54  event_bus: [At:dafeiyu120_bot] 叫爸爸
10:53:54  WARN preprocess: GroupMessage:<PRIVATE_IDENTIFIER> ...
10:53:55  INFO respond.stage: Prepare to send - zjw120/<YOUR_TELEGRAM_ID>
10:53:55  INFO respond.stage: Applying streaming output (telegram-main)
          → 唤醒成功
```

`event_bus` 行本身不含群 ID，光看它会把这三条误判成私聊测试，从而完全走错方向。

## 3. 原因一：前缀缺斜杠

`wake_prefix` 是 `["/大肥鱼"]`，用户发的是 `大肥鱼 叫爸爸`（无 `/`）→ `startswith` 不匹配。

## 4. 原因二：Reply 唤醒失效（上游 bug）

`core/platform/sources/telegram/tg_adapter.py`：

```python
# 第 ~638 行：bot 自身标识存的是 username
message.self_id = str(context.bot.username)          # → "dafeiyu120_bot"

# 第 ~691 行：回复组件塞的是数字 user_id
Comp.Reply(
    id=reply_abm.message_id,
    sender_id=reply_abm.sender.user_id,              # → "<YOUR_USER_IDENTIFIER>"
    qq=reply_abm.sender.user_id,
)
```

`core/pipeline/waking_check/stage.py` 的判定：

```python
if (isinstance(message, Reply)
    and str(message.sender_id) == str(event.get_self_id())):
    is_wake = True
```

`"<YOUR_USER_IDENTIFIER>" == "dafeiyu120_bot"` → 永远 False。

At 之所以能用，是转换阶段专门做了改写：

```python
if name.lower() == message.self_id.lower():
    mention.qq = message.self_id      # At 的 qq 被换成 username
```

Reply 这条路径没有对应处理。

## 5. 修复

被回复者是 bot 时，`sender_id` / `qq` 改用 `self_id`（username）：

```python
_reply_sender_is_bot = bool(
    update.message.reply_to_message.from_user
    and update.message.reply_to_message.from_user.id == context.bot.id
)
_reply_sender_id = (
    str(context.bot.username)
    if _reply_sender_is_bot
    else reply_abm.sender.user_id
)
```

完整幂等脚本见 `scripts/astrbot_fix_reply_wakeup.py`。

注意：`tg_adapter.py` 位于 site-packages，**`uv tool upgrade astrbot` 会覆盖**。同文件上可能还挂着别的补丁（如菜单中文化），升级后要全部重打。

## 6. 副作用提醒

`sender_id` 改成 username 后，任何依赖 `Reply.sender_id` 是数字 ID 的第三方插件可能受影响（翻唱、群分析类插件会读引用链）。改完让用户实测一次业务指令，别只看唤醒通了就收工。

## 7. 附带发现

- `admins_id` 里放了群 ID `<PRIVATE_IDENTIFIER>`：role 判定用 `get_sender_id()`，群 ID 永远不匹配，该条无效（无害但建议清掉）。
- 群里 19 条消息 18 条是语音，全部因 `no speech-to-text provider configured` 被丢弃；纯文本消息也会打同一条警告，属噪音，不能当成"语音消息"的判据。
- `preprocess_stage.stage:228` 的警告在 `waking_check` 和 `whitelist_check` 之后执行，**它的出现本身就证明唤醒和白名单都过了**，是切分排查范围的最好锚点。
