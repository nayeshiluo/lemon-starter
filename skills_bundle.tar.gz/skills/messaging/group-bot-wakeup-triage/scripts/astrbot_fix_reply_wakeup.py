#!/usr/bin/env python3
"""修复 AstrBot Telegram 适配器的 Reply 唤醒判定（幂等）。

问题：
    tg_adapter.py 把 message.self_id 设为 bot 的 username（如 "xxx_bot"），
    但构建 Comp.Reply 时 sender_id 填的是数字 user_id（如 "0"）。
    waking_check 里 `str(message.sender_id) == str(event.get_self_id())` 永远 False，
    导致「引用/回复机器人消息」无法唤醒，只有 @ 有效。

修复：
    被回复者是 bot 自己时，Reply 的 sender_id / qq 改用 username。

用法：
    python3 astrbot_fix_reply_wakeup.py && systemctl restart astrbot

注意：
    - 文件在 site-packages 内，`uv tool upgrade astrbot` 会覆盖，升级后需重跑。
    - 同一文件可能还挂着别的补丁（如菜单中文化），互不影响，各自幂等。
    - 改完必须重启；改文件期间进程用的是内存里的旧模块。
"""
import glob
import shutil
import sys
import time

PATH = None
for _p in (
    glob.glob(
        "/root/.local/share/uv/tools/astrbot/lib/python3.*/site-packages"
        "/astrbot/core/platform/sources/telegram/tg_adapter.py"
    )
    + glob.glob(
        "/usr/lib/python3*/site-packages/astrbot/core/platform/sources"
        "/telegram/tg_adapter.py"
    )
    + glob.glob(
        "/usr/local/lib/python3*/dist-packages/astrbot/core/platform/sources"
        "/telegram/tg_adapter.py"
    )
):
    PATH = _p
    break

if not PATH:
    print("错误：找不到 tg_adapter.py，请手动指定路径", file=sys.stderr)
    sys.exit(1)

OLD = """                message.message.append(
                    Comp.Reply(
                        id=reply_abm.message_id,
                        chain=reply_chain,
                        sender_id=reply_abm.sender.user_id,
                        sender_nickname=reply_abm.sender.nickname,
                        time=reply_abm.timestamp,
                        message_str=reply_message_str,
                        text=reply_message_str,
                        qq=reply_abm.sender.user_id,
                    ),"""

NEW = """                # 被回复的是机器人自己时，sender_id 必须用 self_id(username)，
                # 否则 waking_check 里 Reply.sender_id == get_self_id() 永远不成立
                _reply_sender_is_bot = bool(
                    update.message.reply_to_message.from_user
                    and update.message.reply_to_message.from_user.id == context.bot.id
                )
                _reply_sender_id = (
                    str(context.bot.username)
                    if _reply_sender_is_bot
                    else reply_abm.sender.user_id
                )
                message.message.append(
                    Comp.Reply(
                        id=reply_abm.message_id,
                        chain=reply_chain,
                        sender_id=_reply_sender_id,
                        sender_nickname=reply_abm.sender.nickname,
                        time=reply_abm.timestamp,
                        message_str=reply_message_str,
                        text=reply_message_str,
                        qq=_reply_sender_id,
                    ),"""


def main() -> int:
    src = open(PATH, encoding="utf-8").read()

    if "_reply_sender_is_bot" in src:
        print("已修过，无需重复处理")
        return 0

    if OLD not in src:
        print(
            "错误：锚点未匹配（上游代码可能已变更）。\n"
            "请手动检查 Comp.Reply(...) 处 sender_id / qq 的取值，"
            "把被回复者为 bot 的情况改为 str(context.bot.username)。",
            file=sys.stderr,
        )
        return 1

    bak = PATH + ".bak-replyfix-" + time.strftime("%Y%m%d%H%M%S")
    shutil.copy2(PATH, bak)
    print("备份:", bak)

    src = src.replace(OLD, NEW, 1)
    compile(src, PATH, "exec")
    open(PATH, "w", encoding="utf-8").write(src)
    print("已修复 Reply 唤醒判定，语法校验通过。请执行: systemctl restart astrbot")
    return 0


if __name__ == "__main__":
    sys.exit(main())
