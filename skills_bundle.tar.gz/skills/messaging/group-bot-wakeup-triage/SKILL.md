---
name: group-bot-wakeup-triage
description: 群聊机器人"只有@才理人/发前缀不理/回复没反应"排障：唤醒条件、隐私模式、白名单、日志归因。
version: 1.0.0
author: 柠檬
license: MIT
metadata:
  hermes:
    tags: [telegram, group-bot, wakeup, triage, whitelist, astrbot, debugging]
    related_skills: [astrbot-deploy-ops, telegram-group-bot-suite, telegram-group-assistant]
---

# 群聊机器人唤醒与触发排障

## When to Use

- 用户报「只有 @ 才有反应」「发前缀不理我」「回复机器人没反应」「群里没人能触发它」
- 新机器人刚进群，群友发消息全无响应
- 需要区分：**没收到消息** / **收到了没唤醒** / **唤醒了被白名单拦** / **处理了但失败**

## 第一原则：先定位卡在哪一阶段，再谈权限

所有群聊机器人跑的是同一条流水线：

```
收消息 → 唤醒判定 → 白名单 → 会话状态 → 限流 → 内容安全 → 预处理 → 业务/LLM → 回复
```

AstrBot 的 `core/pipeline/stage_order.py` 就是这个顺序。**后段阶段的日志出现 = 前段全部通过**：

- 有 `preprocess_stage` 日志但没 `respond.stage` 日志 → 唤醒和白名单都过了，卡在业务/LLM
- 完全没有后段日志 → 卡在唤醒或白名单
- 连 `event_bus` 记录都没有 → 消息根本没进来（隐私模式 / 平台没投递）

不要一上来就查权限配置。先把日志切成这两段，问题范围立刻减半。

## 四层排查表

| 层 | 典型现象 | 只读验证 |
|---|---|---|
| 平台投递 | 群里所有消息都收不到 | Bot API `getMe` 看 `can_read_all_group_messages`；false = 隐私模式还开着 |
| 唤醒判定 | 只有 @ 有用，前缀/回复无效 | 看后段日志有没有出现；对比唤醒条件逐条核 |
| 白名单/权限 | 唤醒了但机器人不回 | 白名单阶段日志（`is not in the session allowlist`）；指令 `permission` 字段 |
| 业务/LLM | 有 preprocess 无 respond | provider 连通性、STT、插件报错 |

## 唤醒条件（AstrBot 实证，`waking_check/stage.py`）

群里只有 4 种方式能唤醒，**没有"全量响应"开关**：

1. `@bot`
2. 引用/回复 bot 自己的消息
3. 消息以 `wake_prefix` 开头 —— 配置里**带斜杠**（`["/大肥鱼"]`），用户发 `大肥鱼 xxx` 不匹配
4. `@全体成员`（`ignore_at_all: false` 时）

`wake_prefix` 设成空列表 = 只有 @ 和回复能唤醒，**不会**变成"每句话都回"。想免 @ 全量响应没有官方开关，硬改会刷屏，先跟用户确认。

## 高频坑

### 1. 前缀少了斜杠
配置 `wake_prefix: ["/xxx"]`，用户按口语发 `xxx 你好` → 不匹配。先看配置再断言"功能坏了"。

### 2. Reply 唤醒永久失效（上游 bug，AstrBot 实测）
- `tg_adapter.py` 里 `message.self_id = str(context.bot.username)` → `"xxx_bot"`
- 构建回复组件时 `Comp.Reply(sender_id=reply_abm.sender.user_id)` → 数字 ID `"<YOUR_USER_IDENTIFIER>"`
- 唤醒判定 `str(message.sender_id) == str(event.get_self_id())` → **永远 False**
- At 能用是因为代码专门把 `At.qq` 改写成 username，Reply 这条路径漏了
- 修复脚本：`scripts/astrbot_fix_reply_wakeup.py`（被回复者是 bot 时 `sender_id`/`qq` 改用 username）

**通用教训**：同一套 ID 体系里混用 username 和数字 ID，一定有一处漏改。排查"某个入口就是不生效"时，先打印两边的实际值对比，别读逻辑推理。

### 3. `admins_id` 里放群 ID 无效
role 判定是 `str(event.get_sender_id()) == admin_id`，群 ID 不会等于任何发送者 ID。想让全群可用要配**白名单**：`id_whitelist` 放群 ID，白名单阶段比对 `unified_msg_origin` 和 `get_group_id()`，群 ID 命中即全群放行。两者别混。

### 4. `event_bus` 日志区分不出私聊/群聊
AstrBot `core.event_bus:117` 只打 `昵称/用户ID: 内容`，**不含群 ID**。判断一条消息来自群里还是私聊，要拿它的时间戳去配 `preprocess_stage` 的 `Session telegram-main:GroupMessage:<群ID>` 警告（毫秒级对齐）。

只看 event_bus 会把群内测试误判成私聊测试，从而得出完全相反的结论。

### 5. 语音消息静默丢弃
没配 STT 时每条都报 `has no speech-to-text provider configured`（纯文本消息也会误报，属噪音），语音内容直接丢弃。群里语音占比高时这是"机器人不理人"的主因，不是权限问题。

### 6. 限流
默认 60 秒 30 条、`strategy: stall`，超限直接暂停。群里消息密集时表现像"时好时坏"。

## 菜单作用域（与触发无关，但常一起被问）

- Telegram `BotCommand` **只接受 ASCII 命令名**，`/签到`、`/搜索歌曲` 这类中文名指令永远进不了菜单栏，只能手打。菜单条数 ≠ 指令总数是正常的。
- 分人群菜单用 `BotCommandScopeChat(chat_id=...)`：默认 scope 给精简版，管理员私聊单独设全量。**权限不变，只是菜单显示不同**，别误以为改了权限。
- 校验：`getMyCommands` 不带 scope = 默认；带 `{"scope": {"type": "chat", "chat_id": <uid>}}` = 指定会话。

## 输出规范

排查结论要分开写「已验证事实」和「推断」，并给出下一步单步验证动作。说"修好了"之前必须有真实验证（用户实测或端到端日志），代码改完只是"已修，待验证"。

## 配套文件

- `references/astrbot-telegram-wakeup-case.md` — AstrBot 群聊唤醒完整实测案例：日志时间线、代码位置、修复前后对比
- `scripts/astrbot_fix_reply_wakeup.py` — Reply 唤醒修复（幂等，可重复执行）
