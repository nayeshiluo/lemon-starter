#!/usr/bin/env python3
"""Submit one real video job to the local relay worker and print the outcome.

Usage: relay_video_probe.py <url> [chat_id]
Never prints tokens or credentials.
"""
import json
import os
import random
import socket
import sys

CONFIG = os.environ.get("RELAY_CONFIG", "/home/ubuntu/lemon-userbot/relay_config.json")


def main():
    if len(sys.argv) < 2:
        print("usage: relay_video_probe.py <url> [chat_id]")
        return 2
    url = sys.argv[1]
    cfg = json.load(open(CONFIG))
    routes = cfg.get("routes") or {}
    if len(sys.argv) > 2:
        chat_id = int(sys.argv[2])
    else:
        chat_id = int(next(iter(routes)))
    bot_id = int(routes[str(chat_id)])

    request = {
        "chat_id": chat_id,
        "message_id": 0 + random.randint(1, 0),
        "bot_id": bot_id,
        "kind": "video",
        "url": url,
    }
    request["origin_message_id"] = request["message_id"]

    sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    sock.settimeout(180)
    sock.connect(cfg["socket_path"])
    sock.sendall((json.dumps({"op": "submit", "request": request}) + "\n").encode())
    buf = b""
    while b"\n" not in buf:
        chunk = sock.recv(65536)
        if not chunk:
            break
        buf += chunk
    sock.close()

    reply = json.loads(buf.decode().splitlines()[0])
    data = reply.get("data") or {}
    result = data.get("result") or {}
    print("state:", data.get("state"))
    print("error:", result.get("error"))
    print("type:", result.get("type"))
    print("duration:", result.get("duration"))
    print("bridge_ids:", bool(result.get("bridge_ids")))
    return 0 if data.get("state") == "ready" else 1


if __name__ == "__main__":
    sys.exit(main())
