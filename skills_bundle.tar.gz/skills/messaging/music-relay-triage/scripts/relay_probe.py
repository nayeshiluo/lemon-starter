#!/usr/bin/env python3
"""Submit one real music job to the local relay worker (unix socket) and print the outcome.

Usage: relay_probe.py <title> <artist> [expected_duration]

Reads /home/ubuntu/lemon-userbot/relay_config.json for socket path + routes.
Never prints tokens or credentials - only state / error / caption.
"""
import json
import os
import random
import socket
import sys

CONFIG = os.environ.get("RELAY_CONFIG", "/home/ubuntu/lemon-userbot/relay_config.json")


def main():
    if len(sys.argv) < 3:
        print("usage: relay_probe.py <title> <artist> [expected_duration]")
        return 2
    title, artist = sys.argv[1], sys.argv[2]
    duration = int(sys.argv[3]) if len(sys.argv) > 3 else 0

    cfg = json.load(open(CONFIG))
    routes = cfg.get("routes") or {}
    if not routes:
        print("no routes in config")
        return 2
    chat_id, bot_id = next(iter(routes.items()))
    chat_id, bot_id = int(chat_id), int(bot_id)

    request = {
        "chat_id": chat_id,
        "message_id": 0 + random.randint(1, 0),
        "bot_id": bot_id,
        "kind": "music",
        "title": title,
        "artist": artist,
        "expected_duration": duration,
        "thread_id": None,
    }
    request["origin_message_id"] = request["message_id"]

    sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    sock.settimeout(150)
    sock.connect(cfg["socket_path"])
    sock.sendall((json.dumps({"op": "submit", "request": request}) + "\n").encode())
    buf = b""
    while b"\n" not in buf:
        chunk = sock.recv(65536)
        if not chunk:
            break
        buf += chunk
    sock.close()

    reply = json.loads(buf.decode().splitlines()[0])
    data = reply.get("data") or {}
    result = data.get("result") or {}
    print("state:", data.get("state"))
    print("error:", result.get("error"))
    print("caption:", (result.get("caption") or "").strip())
    print("bridge_ids:", bool(result.get("bridge_ids")))
    return 0 if data.get("state") == "ready" else 1


if __name__ == "__main__":
    sys.exit(main())
