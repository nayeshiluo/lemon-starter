---
name: music-relay-triage
description: 点歌失败/中转不匹配/button_missing 排障与修复。
version: 1.0.0
author: lemon
license: MIT
metadata:
  hermes:
    tags: [telegram, music, relay, triage, lemon-group-bot]
    related_skills: [lemon-userbot, telegram-group-bot-suite]
---

# 点歌中转链路排障（lemon 群霸）

## When to Use / 何时用
- 群友 `/music` 点歌报「匹配失败」「取歌失败」「超时」
- `relay-state/jobs.db` 出现 `failed`，错误码是 `returned_song_mismatch` / `no_exact_song_match` / `button_missing`
- 需要在不退回本地搜索的前提下修复中转链路（**中转永远第一顺位**）

## 链路结构
```
群霸 /music → search_music_all → try_race_music → relay_adapter(relay.sock submit)
   → relay_worker.parse(): 发 "{title} {artist} @Music163DownBot"
   → 点平台按钮 → select_song 选行 → 点数字按钮 → 收到音频文件
   → verify_caption 校验 → forward 到 relay 群 → 存 ready → 群霸 claim/commit 下发
```
关键文件：
- `/home/ubuntu/lemon-userbot/relay_core.py`（解析与比对，**镜像在 lemon-group-bot，必须保持一致**）
- `/home/ubuntu/lemon-userbot/relay_worker.py`（parse / click / 校验 / 重试）
- `/home/ubuntu/lemon-userbot/relay-state/jobs.db`（表 `jobs(id,state,request,result,created)`，**列名是 state 不是 status**）
- `/home/ubuntu/lemon-userbot/relay.sock`（ops: submit / cancel / claim / commit）

## 音乐库预热缓存
点歌命中的"秒发"来自预热库，与上面的中转链路是两条独立通路（命中预热库就不走中转）。
频道、VPS 爬虫、同步任务、`/musiclib`、每日 02:00 总报、外部音源频道、流量账本的完整档案见
**`references/music-library-archive.md`**——那是唯一权威副本，改动后先更新它。

## 第一步：看真实错误，不猜
```bash
sudo journalctl -u lemon-userbot.service --since '30 min ago' --no-pager | grep -E "relay job|button_missing"
sqlite3 /home/ubuntu/lemon-userbot/relay-state/jobs.db \
  "SELECT state, json_extract(result,'\$.error'), json_extract(request,'\$.title'), json_extract(request,'\$.artist')
   FROM jobs WHERE state='failed' ORDER BY created DESC LIMIT 8;"
```
worker 把失败原因写进 `result.error`，并在 journal 打 `relay job <id> failed: <类型>: <消息>`。

## 错误码 → 根因对照
| 错误码 | 真实含义 | 常见原因 |
|---|---|---|
| `button_missing` | `click()` 找不到按钮 | **按钮 text 是 str，select_song 返回 int**；平台按钮是 `QQ Music` 英文而非 `QQ音乐` |
| `returned_song_mismatch` | 交付文案校验失败 | 真实标题带后缀，如 `「夏影 (原曲：夕涼み)」- 麻枝准`，旧代码 `fullmatch` 整行报废 |
| `no_exact_song_match` | 列表里没选中 | 标题含空格/日文/括号（`風の止まり木`、`GOD 釈迦にHip-Hop`）解析漏 |
| `provider_identity_mismatch` | 机器人身份不符 | 配置的 `music_bot_id` 与 `@Music163DownBot` 不一致 |
| `multiple_music_results` | 收到相册 | 群组媒体被当成多结果 |

## 修复要点（已落地，勿回退）
1. `click()` 必须 `str(button.text).strip() != str(label).strip()`，不能直接比 int/str。
2. 交付校验走 `verify_caption()`：宽容定位 `「标题」 - 艺术家`，标题取主干、艺术家按 `;／/、&` 切词取交集，`expected_duration` 做时长锚定。
3. `select_song()` 保留**艺术家硬约束**（请求有艺术家时，艺术家不匹配的行不选），防串歌。
4. 音乐失败降级重试：`music_queries()` 返回 `[歌名+艺术家, 歌名]`，仅在 `no_exact_song_match` / `returned_song_mismatch` 时重试一次。
5. 重试**不能把 request 的 artist 清空**再 `validate()`（validate 要求 artist 非空），只能换查询文本。

## 验收（必须真跑，不能只看进程 active）
```bash
# 1) 队列空再重启
sqlite3 /home/ubuntu/lemon-userbot/relay-state/jobs.db "SELECT state,COUNT(*) FROM jobs GROUP BY state;"
sudo systemctl restart lemon-userbot.service && sleep 6 && systemctl is-active lemon-userbot.service

# 2) 真实提交一单
python3 ~/.hermes/skills/messaging/music-relay-triage/scripts/relay_probe.py 夏影 麻枝准 178

# 3) 成功标志：result.caption 有内容、bridge_ids=True、state=ready
sqlite3 /home/ubuntu/lemon-userbot/relay-state/jobs.db \
  "SELECT state, json_extract(result,'\$.caption') FROM jobs WHERE json_extract(request,'\$.kind')='music' ORDER BY created DESC LIMIT 1;"
```
单测：`cd /home/ubuntu/lemon-userbot && python3 -m pytest tests/test_relay_match.py -q`

## 坑
- 服务在跑时**不要打开** `userbot.session`（会被占用，报 AuthKeyUnregistered）。
- `journalctl` 无 traceback 时看 `relay job ... failed:` 那行；需要细节临时加 `_log.warning`，不打印凭据/URL。
- 改完 `relay_core.py` 必须同步 `/home/ubuntu/lemon-group-bot/relay_core.py`。
- 改前备份到 `/home/ubuntu/backups/relay-match-<ts>/`，回滚拷回两个文件即可。
- 探针会在 relay 群留下真实音频（state=ready），群霸不会下发，属正常验证痕迹。

## 可选下一步（未实施，需明确授权）
- 成功后写回音乐库（`race_music_cache.after_music` 目前 0 调用点）
- 中转彻底失败才用库兜底直发 file_id（0 流量）
