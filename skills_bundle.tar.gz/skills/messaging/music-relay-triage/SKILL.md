---
name: music-relay-triage
description: 点歌失败/中转不匹配/button_missing 排障与修复。
version: 1.0.0
author: lemon
license: MIT
metadata:
  hermes:
    tags: [telegram, music, relay, triage, lemon-group-bot]
    related_skills: [lemon-userbot, telegram-group-bot-suite]
---

# 点歌中转链路排障（lemon 群霸）

## When to Use / 何时用
- 群友 `/music` 点歌报「匹配失败」「取歌失败」「超时」
- `relay-state/jobs.db` 出现 `failed`，错误码是 `returned_song_mismatch` / `no_exact_song_match` / `button_missing`
- 需要在不退回本地搜索的前提下修复中转链路（**中转永远第一顺位**）

## 链路结构
```
群霸 /music → search_music_all → try_race_music → relay_adapter(relay.sock submit)
   → relay_worker.parse(): 发 "{title} {artist} @Music163DownBot"
   → 点平台按钮 → select_song 选行 → 点数字按钮 → 收到音频文件
   → verify_caption 校验 → forward 到 relay 群 → 存 ready → 群霸 claim/commit 下发
```
关键文件：
- `/home/ubuntu/lemon-userbot/relay_core.py`（解析与比对，**镜像在 lemon-group-bot，必须保持一致**）
- `/home/ubuntu/lemon-userbot/relay_worker.py`（parse / click / 校验 / 重试）
- `/home/ubuntu/lemon-userbot/relay-state/jobs.db`（表 `jobs(id,state,request,result,created)`，**列名是 state 不是 status**）
- `/home/ubuntu/lemon-userbot/relay.sock`（ops: submit / cancel / claim / commit）

## 音乐库预热缓存
点歌命中的"秒发"来自预热库，与上面的中转链路是两条独立通路（命中预热库就不走中转）。
频道、VPS 爬虫、同步任务、`/musiclib`、每日 02:00 总报、外部音源频道、流量账本的完整档案见
**`references/music-library-archive.md`**——那是唯一权威副本，改动后先更新它。

## 第一步：看真实错误，不猜
```bash
sudo journalctl -u lemon-userbot.service --since '30 min ago' --no-pager | grep -E "relay job|button_missing"
sqlite3 /home/ubuntu/lemon-userbot/relay-state/jobs.db \
  "SELECT state, json_extract(result,'\$.error'), json_extract(request,'\$.title'), json_extract(request,'\$.artist')
   FROM jobs WHERE state='failed' ORDER BY created DESC LIMIT 8;"
```
worker 把失败原因写进 `result.error`，并在 journal 打 `relay job <id> failed: <类型>: <消息>`。

## 错误码 → 根因对照
| 错误码 | 真实含义 | 常见原因 |
|---|---|---|
| `button_missing` | `click()` 找不到按钮 | **按钮 text 是 str，select_song 返回 int**；平台按钮是 `QQ Music` 英文而非 `QQ音乐` |
| `returned_song_mismatch` | 交付文案校验失败 | 真实标题带后缀，如 `「夏影 (原曲：夕涼み)」- 麻枝准`，旧代码 `fullmatch` 整行报废 |
| `no_exact_song_match` | 列表里没选中 | 标题含空格/日文/括号（`風の止まり木`、`GOD 釈迦にHip-Hop`）解析漏 |
| `provider_identity_mismatch` | 机器人身份不符 | 配置的 `music_bot_id` 与 `@Music163DownBot` 不一致 |
| `multiple_music_results` | 收到相册 | 群组媒体被当成多结果 |
| `route_denied`（**群里看不到错误码**） | 群霸回 `FAILED：音乐中转当前不可用，未启动原生下载。` | `relay_config.json` 的 `routes` 缺该群或 bot_id 不匹配；`race_adapter.allowed()` 吞掉 ValueError 返回 False |

### route_denied 快速定位（2026-10 实例）
群里点歌 1~2 秒就回 `FAILED：音乐中转当前不可用`，且 `jobs.db` **没有新记录** → 没进 relay，是 `allowed()` 提前 False。
```bash
cd /home/ubuntu/lemon-group-bot && python3 -c "
import json;rc=json.load(open('/home/ubuntu/lemon-userbot/relay_config.json'))['routes']
for bid,f in (('<PRIVATE_IDENTIFIER>','data/config_<PRIVATE_IDENTIFIER>.json'),('<PRIVATE_IDENTIFIER>','data/config_<PRIVATE_IDENTIFIER>.json')):
    c=json.load(open(f));print('== bot',bid)
    for g in map(str,c.get('authorized_groups',[])):
        print('  ',g,c.get('group_names',{}).get(g),(c.get('group_features',{}).get(g) or {}).get('music'),'OK' if rc.get(g)==int(bid) else 'MISSING')"
```
修复只需补 `routes[群id]=bot_id`；`relay_worker` 与 `race_adapter` **每次读文件**（热加载），不用重启服务。
注意本地自测必须带该 bot 的 token：`TELEGRAM_BOT_TOKEN=$(systemctl show lemon-group-bot2.service -p Environment --value ...)`，否则 `config.py` 会读成另一个 bot 的配置、误判 authorized=False。

## 修复要点（已落地，勿回退）
1. `click()` 必须 `str(button.text).strip() != str(label).strip()`，不能直接比 int/str。
2. 交付校验走 `verify_caption()`：宽容定位 `「标题」 - 艺术家`，标题取主干、艺术家按 `;／/、&` 切词取交集，`expected_duration` 做时长锚定。
3. `select_song()` 保留**艺术家硬约束**（请求有艺术家时，艺术家不匹配的行不选），防串歌。
4. 音乐失败降级重试：`music_queries()` 返回 `[歌名+艺术家, 歌名]`，仅在 `no_exact_song_match` / `returned_song_mismatch` 时重试一次。
5. 重试**不能把 request 的 artist 清空**再 `validate()`（validate 要求 artist 非空），只能换查询文本。

## 验收（必须真跑，不能只看进程 active）
```bash
# 1) 队列空再重启
sqlite3 /home/ubuntu/lemon-userbot/relay-state/jobs.db "SELECT state,COUNT(*) FROM jobs GROUP BY state;"
sudo systemctl restart lemon-userbot.service && sleep 6 && systemctl is-active lemon-userbot.service

# 2) 真实提交一单
python3 ~/.hermes/skills/messaging/music-relay-triage/scripts/relay_probe.py 夏影 麻枝准 178

# 3) 成功标志：result.caption 有内容、bridge_ids=True、state=ready
sqlite3 /home/ubuntu/lemon-userbot/relay-state/jobs.db \
  "SELECT state, json_extract(result,'\$.caption') FROM jobs WHERE json_extract(request,'\$.kind')='music' ORDER BY created DESC LIMIT 1;"
```
单测：`cd /home/ubuntu/lemon-userbot && python3 -m pytest tests/test_relay_match.py -q`

## 网易云 ID 兜底：二创/翻唱/DJ版下不到的正解（2026-11 落地）

**症状**：群里点歌必失败，`jobs.db` 记 `music_candidate_artist_mismatch`，诊断里 `artist_match_count=0`，
候选全是同名不同歌手（如点「好运来 （必上岸版！）」/刘楚·DJR7，候选只有祖海/凤凰传奇/宋祖英/卓依婷/二狗威/DJ铁柱）。

**根因是结构性的**：群霸用**网易云 API** 搜索出 Top5 卡片，中转却用 `@Music163DownBot` 搜 **QQ音乐**曲库。
网易云独有的二创/翻唱/DJ版在 QQ音乐 没有同歌手版本，`select_song` 的 artist 硬约束必然拒绝。

**解法**：群霸卡片本来就带 `native_song_id`（网易云歌曲 ID），失败后用链接直达。
`@Music163DownBot` **支持** `https://music.163.com/song?id=<id>` 直达（实测返回精确歌曲、`#NetEaseCloudMusic`）。

三处改动（`relay_core.py` 要同步镜像到 `lemon-group-bot/`）：
1. `music_queries()` 追加第三条 `https://music.163.com/song?id={native_song_id}`（仅 `isinstance(int) and >0`）
2. `verify_caption(..., strict=True)` 新增 `strict` 参数；`strict=False` 时只要求有可读标题，
   **时长锚定仍生效**（`duration_mismatch` 照样拒），挡住下错歌
3. `relay_worker._parse_attempt()` 用 `url_mode = str(query).startswith("http")` 传 `strict=not url_mode`；
   `parse()` 的 `music_query_mode` 增 `native_id`，重试门控改为「无 artist **且** 无 native_song_id 才放弃」

**验收**（必须真跑，探针第 4 参数是 native_song_id）：
```bash
python3 ~/.hermes/skills/messaging/music-relay-triage/scripts/relay_probe.py \
  "好运来 （必上岸版！）" "刘楚/DJR7" 163 <YOUR_USER_IDENTIFIER>
# 期望 state: ready / caption「好运来 （必上岸版！）」- 刘楚 / DJR7 / #NetEaseCloudMusic
```
成功时 `music_diagnostics` 为空（只有失败轮才记），journal 里能看到前两轮 `title_artist`/`title_only` 各一条诊断。

## 坑：`ready` 僵尸 job 会永久占满队列（2026-11 实测）

`queue_limit=4`，`Store.add()` 用 `SELECT count(*) ... WHERE state NOT IN ('done','failed','uncertain','expired','cancelled')` 判满
—— **`ready` 不在排除名单里**。submit 后没人 `claim`（探针、或群霸 submit 后重启）的 job 会永远 `ready`，
每个吃掉一个并发位。实测发现 3 个探针残留（10-27 / 11-01 / 11-02）连续几天占着 3/4，只剩 1 个并发位，
表现就是「有时点歌秒回 FAILED」或新 submit 直接 `{"ok":false,"error":"request_rejected"}`。

```bash
# 查占用（应长期为 0）
cd /home/ubuntu/lemon-userbot && python3 -c "
import sqlite3;c=sqlite3.connect('relay-state/jobs.db')
print(c.execute(\"SELECT state,count(*) FROM jobs WHERE state NOT IN ('done','failed','uncertain','expired','cancelled') GROUP BY state\").fetchall())"
# 清理探针残留
python3 -c "
import sqlite3,json;c=sqlite3.connect('relay-state/jobs.db')
c.execute(\"UPDATE jobs SET state='expired',result=? WHERE state='ready'\",(json.dumps({'error':'probe_abandoned'}),));c.commit()"
```
**跑完探针一定要清 `ready`**，否则下次探针会被自己堵死（现象是 `state: None` + `request_rejected`，容易误判成 validate 问题）。

### 已加自动过期（2026-11-03 落地，勿回退）

`relay_core.py` 新增 `READY_UNCLAIMED_TTL = 900.0` 与 `Store._expire_unclaimed_ready(now)`：
`Store.add()` 只在**队列已满时**才调用清理（正常路径零开销），把 `created < now-900` 的 `ready` 置为
`expired` + `{"error":"ready_unclaimed_timeout"}` 后重新计数。**只清 `ready`，`queued` 再老也不动**。
阈值 900s 的依据：最坏 4 条各排到 `total_timeout(120s)` 再加自己 120s ≈ 480s 才 ready，留近一倍余量。
`recover()` 只在**进程重启时**把 `ready` → `uncertain`，所以长期不重启的 userbot 靠这个 TTL 兜底。
回归测试在 `tests/test_relay_match.py` 的 `test_stale_ready_does_not_block_queue` /
`test_fresh_ready_still_blocks_queue` / `test_stale_queued_is_not_expired`。
注意 `tests/test_relay_match.py` 是 **pytest 风格函数**（无 TestCase 类），`unittest discover` 不会收集它，
要单独跑：`./venv/bin/python -c "import sys;sys.path.insert(0,'tests');import test_relay_match as t;[getattr(t,n)() for n in dir(t) if n.startswith('test_')]"`。

## 坑：relay 单测必须用项目 venv

`/home/ubuntu/lemon-userbot` **没有 `.venv`，但有 `venv/`**（服务 `ExecStart=/home/ubuntu/lemon-userbot/venv/bin/python`）。
用系统 `python3` 跑 `tests/` 会 `ModuleNotFoundError: No module named 'telethon'`，表现为 1 failure + 3 errors，
**不是代码坏了**：
```bash
cd /home/ubuntu/lemon-userbot && ./venv/bin/python -m unittest discover -s tests -q   # 15 tests OK
```

## 坑
- 服务在跑时**不要打开** `userbot.session`（会被占用，报 AuthKeyUnregistered）。
- `journalctl` 无 traceback 时看 `relay job ... failed:` 那行；需要细节临时加 `_log.warning`，不打印凭据/URL。
- 改完 `relay_core.py` 必须同步 `/home/ubuntu/lemon-group-bot/relay_core.py`。
- 改前备份到 `/home/ubuntu/backups/relay-match-<ts>/`，回滚拷回两个文件即可。
- 探针会在 relay 群留下真实音频（state=ready），群霸不会下发，属正常验证痕迹。

## 可选下一步（未实施，需明确授权）
- 成功后写回音乐库（`race_music_cache.after_music` 目前 0 调用点）
- 中转彻底失败才用库兜底直发 file_id（0 流量）
