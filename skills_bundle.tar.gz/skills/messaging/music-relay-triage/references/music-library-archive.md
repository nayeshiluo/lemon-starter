# 🎵 柠檬音乐库 · 预热缓存档案（基线）

> 本文件是音乐库架构与运维事实的唯一权威副本。改动架构、频道、定时器或路径后**先更新本文件**，不要在会话记忆里维护第二份。

## 核心思想

把「下载 → 转码 → 上传」的重活全部搬到**洛杉矶 VPS（RackNerd `<PRIVATE_IDENTIFIER>`）**，AWS 只保存爬好的 Telegram `file_id` 文本索引。
群友点歌命中时，AWS 直接 `send_audio(file_id=...)` → **0 AWS 出网流量，约 0.7 秒秒发**。

## 数据流

```
[洛杉矶 VPS]                                  [AWS 实例]
热歌榜(网易云/QQ) ─▶ B站360P轻量流 ─▶ FFmpeg抽音轨
                                ─▶ ID3打标+封面
                                ─▶ 上传 TG 频道「🎵 柠檬音乐库」
                                ─▶ 记录 file_id → lemon_music_cache.jsonl
                                                │
                                    (SSH 只拉几 KB 文本索引)
                                                ▼
                                    data/music_cache.db :: prewarm_cache
                                                │
                                群友 /music 点歌 ─▶ 命中 → 秒发
                                                未命中 → 实时提取（旧链路兜底）
```

## 关键组件

| 组件 | 位置 | 说明 |
|---|---|---|
| `tools/music_crawler.py` | 洛杉矶 VPS `/root/` | 爬取+转码+上传，产出 jsonl |
| `lemon-music-crawler.timer` | 洛杉矶 VPS | systemd 定时器，每 30 分钟爬一轮 |
| `tools/sync_music_cache.py` | AWS | SSH 拉取 jsonl → 写入 `prewarm_cache` 表 |
| `tools/channel_music_harvester.py` | AWS / 私有项目 | 抓外部频道存量音源 |
| `tools/create_music_channel.py` | AWS | 初始化频道 |
| 频道「🎵 柠檬音乐库」 | Telegram | `<YOUR_TELEGRAM_GROUP_ID>`，可人工浏览 |

## 外部音源频道（`channel_music_harvester.py`）

分批平滑轮询，顺序 `MP3_320K → FLAC_HR → DJZYH`：

| username | 名称 | 分类 | 单文件上限 |
|---|---|---|---|
| `@MP3_320K` | 320K飙升榜 | 流行飙升 | 35 MB |
| `@FLAC_HR` | 无损热歌榜 | 无损热歌 | 42 MB |
| `@DJZYH` | — | — | — |

## 本机代码位置

| 用途 | 路径 |
|---|---|
| 运行副本 | `/home/ubuntu/lemon-group-bot/tools/` |
| 私有项目副本（含本档案源 README） | `/home/ubuntu/hermes-ops-private/projects/lemon-group-bot/tools/` |

四个脚本：`music_crawler.py`、`sync_music_cache.py`、`channel_music_harvester.py`、`create_music_channel.py`。
两处副本改动须同步，否则会出现"改了不生效"。

## 运维入口

- **`/musiclib`（别名 `/music`）**：查询音乐库缓存状态，实现于运维 Bot
  `/home/ubuntu/hermes-ops-private/projects/lemon-ops-bot/main.py`（`musiclib_command`）。
- **每日 02:00（北京时间）总报**：`music_daily_report_loop()` 私聊发给 `ALLOWED_ADMIN_IDS`，
  内容由 `format_music_lib_report(stats, is_daily=True)` 生成，`last_report_date` 去重防止重复发送。
- **群友点播自动归档**：点播成功的曲目回推 VPS 归档，进入下一轮预热库。

## 流量账本（严守 AWS 100GB/月免费出网）

| 环节 | 承担方 |
|---|---|
| 爬虫下载 / 转码 | 洛杉矶 VPS |
| 上传 Telegram 频道 | 洛杉矶 VPS |
| AWS 同步索引 | 每 15 分钟拉几 KB ≈ 每天 <1 MB |
| 群内点歌命中预热库 | AWS ≈ 0 流量（TG 服务器内部复制） |

## 凭据与安全约束

- `create_music_channel.py` / `channel_music_harvester.py` 必须通过环境变量 `TELEGRAM_API_ID`、`TELEGRAM_API_HASH` 提供凭据；缺失即退出，**禁止把真实值写入仓库**。旧 `API_HASH` 仅保留读取兼容，部署统一用 `TELEGRAM_API_HASH`（优先级更高）。
- `sync_music_cache.py` 只走 OpenSSH 公钥认证（默认密钥或 ssh-agent），**不接受密码**。
- 运行账户须配置 `vps-la` SSH 别名（HostName / User / 密钥），并先经可信渠道核验 VPS 主机指纹写入 `known_hosts`；主机密钥未知或变化时拒绝连接。

## 排障提示

- 频道里能看到歌、但群友点歌"未命中" → 查 AWS 侧 `prewarm_cache` 是否同步到，而不是重爬。
- 同步正常但点歌仍走实时提取 → 查 `lemon_music_cache.jsonl` 的 `file_id` 是否失效（频道消息被删/频道迁移）。
- `/musiclib` 无响应 → 查运维 Bot 进程，不是音乐库本身故障。
