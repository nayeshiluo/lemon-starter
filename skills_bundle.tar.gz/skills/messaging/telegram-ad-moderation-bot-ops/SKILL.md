---
name: telegram-ad-moderation-bot-ops
description: Use when 排查或改造 AdKiller 反广告机器人判定与发卡。
version: 1.0.0
author: lemon
license: MIT
metadata:
  hermes:
    tags: [telegram, moderation, anti-spam, ad-killer, systemd]
    related_skills: [im-bot-wake-troubleshooting, telegram-group-assistant]
---

# Telegram 反广告 / 风控机器人运维

面向自建 AdKiller（vps-la `/opt/ad-killer`）这类「规则 + AI 双通道 + 来源复核卡」的群风控机器人。核心能力：**先证代码路径，再信用户口述的规则**。

## When to Use

- 「群里的 bot 发言为什么被判广告 / 为什么被删 / 为什么弹了复核卡」
- 「我明明设置过 XX 不视为违规，为什么还触发」→ 优先怀疑规则没落地
- 要改判定口径、发卡行为、观察模式语义
- 要清理历史误判卡片或案件脏数据

## 铁律：用户口述的规则 ≠ 已实现的规则

用户说「我说过群内 bot 发言不算违规」时，**不要**在 README 或指令文案里找证据然后回「已生效」。README 描述的是设计意图，指令回显文案是产品承诺，两者都可能与代码分支脱节。

正确顺序：

1. 在代码里定位该判断的实际分支（grep 关键行为词，如 `is_bot`、`source_scope`、`allow_ids`）
2. 若找不到对应豁免分支 → 结论是「规则没有落地」，直接把证据（文件行号 + 缺失的分支）摆出来
3. 再给可选的改法让用户选，不要自作主张改口径

本次实例：README 写「群内 Bot 只检测广告」，被理解成「不处理」；实际代码对群内 bot 照跑全量规则 + AI，只是免了来源删帖和连带处罚。**「只检测」在风控系统里通常意味着「照判、照归档、照通知」，不等于「豁免」。**

## 观察模式（observe）的真实语义 —— 高频误解

`mode: observe` 只阻断**处罚动作**（`deleteMessage` / `restrictChatMember` / `banChatMember`），**不阻断**归档和群内通知卡。查询 `report` 的 SQL 里没有 mode 条件，所以群里照样弹出复核卡。

用户抱怨「观察模式还打扰群」时，这是设计而非 bug；要安静就得改发卡逻辑。排查任何「模式设了但还有动作」的问题，都要逐个确认是处罚类还是通知类动作。

## 部署形态与真实路径（踩过坑）

| 项 | 真实位置 | 陷阱 |
|---|---|---|
| 生效配置 | `/etc/ad-killer/config.json`（`AD_CONFIG`） | **`/opt/ad-killer/config.json` 是旧副本**，读它会拿到缺 `vision_model`/`fallback`/多余群的过期内容 |
| 状态库 | `/var/lib/private/ad-killer/state.db` | systemd `StateDirectory=ad-killer`；`/var/lib/ad-killer` 是指向 `private/` 的软链 |
| 日志 | `/var/log/private/ad-killer/bot.log` | `journalctl -u ad-killer` 只有 systemd 生命周期行，业务日志在 `bot.log` |
| 凭据 | `/etc/ad-killer/bot-token`（`LoadCredential`） | DynamicUser=yes，服务内路径是 `$CREDENTIALS_DIRECTORY` |

确认哪份配置生效：先看 unit 的 `Environment=AD_CONFIG=`，别猜。

## 模块分工

- `bot.py` — 主入口、命令路由、管理员/白名单、发卡与告警
- `external_bots.py` — 外来 bot / 内联 / 访客调用者、来源复核卡与归档
- `rules.py` — 正则规则（域名、样本相似度、推广词）
- `policy.py` — 按群特性开关（`features`）与判定包装
- `ai.py` — AI 复核提示词与 JSON 解析（`PROMPT` 是可调口径的地方）
- `cases.py` / `management.py` — 案件流程与管理面板

注意类名是 `ExternalBots`（不是 `External`），写验证脚本时别猜。

## external_cases 关键字段语义

| 字段 | 含义 |
|---|---|
| `kind` | `bot` / `inline` / `guest` |
| `source_scope` | `member` / `nonmember` / `unknown` / `approved`（决定是否免来源删帖） |
| `verdict` | `spam` / `normal` / `uncertain` / `queue_full` / `not_checked` |
| `deleted` | `not_requested` / `pending` / `confirmed` / `cancelled` / `rate_limited` / `no_permission` / `missing` |
| `archive` / `archive_state` | 归档频道消息 ID / `not_needed`→`pending`→`sending`→`confirmed` |
| `report` | **>0** 群内复核卡消息 ID；**-1** 发送中或结果不确定；**-2** 已清理/已不存在；**-3** 群内 bot 改为私聊通知、不发群卡 |
| `caller` / `relation` | 真人召唤者；`telegram_user` / `inline_sender` / `reply_trigger` / `temporal:*` / `none` |

`relation='temporal:*'` 只是时间候选，**永不授权处罚**。

## 改造流程（本次验证过）

1. **备份**：`cp -p` 目标 .py 加 `.before-<主题>-<日期>` 后缀，state.db 用 sqlite3 backup 复制到 `/root/`。
2. **最小改动**：只在发卡决策处加分支，不要动检测链路——检测/归档是证据，删掉等于以后没法回溯。
3. **加口径标签**：新分支给 `report` 一个专属负值（如 `-3`），让「为什么没卡」可以直接用一条 SQL 查出来。
4. **补测试**：现有测试文件（`test_external_bots.py` 等）用 fixture 的 FakeAPI 记录调用，照抄一个改动前用例，反转断言即可。
5. **跑基线对比**（关键）：见下节，否则分不清新引入失败与历史遗留。
6. **重启 + 验收**：`systemctl restart ad-killer`，`systemctl is-active` + `NRestarts` + `grep -c Traceback bot.log`。
7. **清历史脏数据**：改完后旧卡片还在库里，需要单独清理（见下）。

## 验证套路：生产库副本 + FakeAPI 端到端

不要拿生产库直接跑 tick()，也不要只靠单测。用 sqlite3 backup API 取一致性副本（直接 `cp` 在 WAL 活跃时会不一致、还可能读出 readonly 错误）：

```python
src = sqlite3.connect("file:/var/lib/private/ad-killer/state.db?mode=ro", uri=True)
dst = sqlite3.connect("/tmp/verify.db")
src.backup(dst)
```

然后在副本里插一条 `report=0` 的假 case，用 FakeAPI / FakeStore / FakeBot 桩驱动 `ext.tick()`，断言：群内 `sendMessage` 带 `reply_markup` 的条数、私聊主人条数、DB 里 `report` 的最终值。两个场景必须都测——命中新分支的，和走老路径的（确认没回归）。

脚本模板见 `scripts/verify_source_card_branch.py`。

## 区分「改动引入」与「历史遗留」测试失败

全量 `python3 -m unittest discover -s . -p "test_*.py"` 有 pre-existing failures（`test_bot` 的菜单命令列表、陌生人私聊静默两项）。汇报前必须证明与本次无关：

```bash
mkdir -p /tmp/adk-before && cp -a /opt/ad-killer/*.py /tmp/adk-before/
cp /opt/ad-killer/<改动文件>.before-<主题>-<日期> /tmp/adk-before/<改动文件>
cd /tmp/adk-before && python3 -m unittest <失败用例>   # 用旧版复现 → 证明 pre-existing
```

**不要**把历史失败当成自己改坏了，也不要改测试来「修绿」。

## 清理历史复核卡

改完规则，库里的 `report>0` 记录仍是活的（`refresh` 还会去 edit 它）。逐条 `deleteMessage` 并回写 `report=-2`（已不存在）/`-3`（本不该有）。Telegram 对旧消息通常返回 `message to delete not found` 或 `can't be deleted`——这是正常结果，不是失败，如实计入汇报。

## 坑

- **AI 判定会漂移**：同一条消息可能先判 `normal`、重试后判 `spam`。日志里看得到连续 `invalid_json` → `model_http_400` → `model_http_503` 的多模型失败，模型链路不稳时口径会从严。判定结果不是确定性函数，别用一次结论反推规则。
- **`external_bot_allow_ids` 只免删帖，不免发卡**。想彻底安静必须改发卡分支。
- **不要为了「安静」删掉检测或归档**：证据链一断，以后无法复核误判。
- 改完 `bot.py` 里 `/adexternal` 的回显文案，否则下次运维看到的仍是旧承诺。
- 服务是 `DynamicUser` + `ProtectSystem=strict`，不要在服务上下文里写 `/opt` 或 `/root`；手工脚本用 root 直接跑。

## 参考

- `references/member-bot-quiet-change.md` — 群内 bot 不发群卡改为私聊通知的完整改动记录
- `scripts/verify_source_card_branch.py` — 生产库副本 + 双场景发卡分支验证脚本
