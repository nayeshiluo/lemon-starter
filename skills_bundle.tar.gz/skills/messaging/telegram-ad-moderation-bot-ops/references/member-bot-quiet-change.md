# 群内 bot 不再发送群内复核卡（2026-11-07）

## 触发场景

ban人群（`<PRIVATE_IDENTIFIER>`）里，`@gansini120bot` 发了一张番号详情卡（SDAM-182，含 JAVBUS 外链 + "种子 11 条"）被判 spam，群里弹出 `EXT-000806 机器人来源复核` 卡（群消息 1378）。用户表示「群内的 bot 发言不视为违规」。

## 真实根因（两条，都不是 bug）

1. **没有任何群内 bot 豁免**：`external_bots.py` 对 `scope=member` 的 bot 只免两件事——`external_nonmember_delete` 不适用、`contain()` 不连带处罚真人。规则与 AI 判定照跑。
2. **observe 不拦通知卡**：查 `report=0` 的 SQL 没有任何 mode 条件，所以即便是 observe 群也照发群内复核卡。observe 只让 `delete()` 短路。

判定来源是 AI 而非正则：08:08:21 判 `normal`（14.2s）→ 08:08:30~31 视觉模型 `invalid_json`、fallback 400、主模型 503 → 08:08:38 重试判 `spam`（"成人影片番号、种子数量及JAVBUS详情外链，属于色情资源推广引流"）。**同一消息 17 秒内两种结论，是模型漂移不是规则 bug。**

## 采用方案（用户选 2）

保留检测与归档（证据不能丢），只把群内 bot 的群内复核卡换成私聊通知。

未采用方案 1：群内 bot 完全豁免（`handle()` 早期 return，不检测不归档）——会断掉证据链。

## 改动

`external_bots.py`，`tick()` 里发卡那一段：

```python
row = self.db.execute("SELECT id FROM external_cases WHERE verdict='spam' AND archive_state='confirmed' "
                      "AND report=0 AND state IN ('review','muted','protected') ORDER BY id LIMIT 1").fetchone()
if row:
    c = self.get(row[0])
    if self.group_member_bot(c):
        # Member bots: archive + owner notice only; never a group review card.
        self.set(c['id'], report=-3)
        self.notify_member_bot(c)
    else:
        self.set(c['id'], report=-1)   # Uncertain send is not blindly replayed.
        try:
            posted = self.api.call('sendMessage', chat_id=c['cid'], text=self.card(c, group=True),
                                   reply_markup=self.keyboard(c['id']), link_preview_options={'is_disabled': True})
            self.set(c['id'], report=posted['message_id'])
        except Exception:
            pass
```

新增两个方法（放在 `warn()` 之前）：

```python
@staticmethod
def group_member_bot(c):
    """Member/approved bots keep detection and archiving, but post no group card."""
    return c['kind'] == 'bot' and c['source_scope'] in {'member', 'approved'}

def notify_member_bot(self, c):
    """Owner-only notice for a member bot judged spam; the group stays silent."""
    try:
        m = json.loads(c['payload'])
        sender = m.get('from') or {}
        text = ('群内机器人广告判定（仅通知，未在群内发卡）\n'
                '群ID：' + str(c['cid']) + '\n消息ID：' + str(c['mid']) + '\n'
                '机器人：' + str(sender.get('username') or sender.get('id')) + '\n'
                '来源范围：' + str(c['source_scope']) + '\n'
                '广告判定：' + str(c['verdict']) + '\n'
                '删除：' + str(c['deleted']) + '\n证据：归档 EXT-' + format(int(c['id']), '06d'))
        sender_fn = getattr(self.api, 'enqueue_send', None)
        if sender_fn:
            sender_fn(chat_id=self.bot.owner, text=text)
        else:
            self.api.call('sendMessage', chat_id=self.bot.owner, text=text)
    except Exception:
        LOG.warning('member_bot_notice_failed case=%s', c['id'])
```

同步改了 `bot.py` 里 `/adexternal` 的回显文案与 `README.md`，否则运维看到的仍是旧承诺。

## 为什么用 `report=-3`

现有负值语义：`-1` 发送中/不确定，`-2` 已清理/不存在。另开 `-3` 表示「本不该发群卡」，一条 SQL 就能区分「没发过卡」和「发过又删了」：

```sql
SELECT count(*) FROM external_cases WHERE kind='bot'
  AND source_scope IN ('member','approved') AND report>0;   -- 应为 0
```

## 验收（生产库副本 + FakeAPI）

| 场景 | 群内发卡 | 私聊主人 | report |
|---|---|---|---|
| 群内成员 bot 判 spam | 0 ✅ | 1 ✅ | -3 ✅ |
| 群外 bot 判 spam（回归） | 1 ✅ | 0 ✅ | 正常卡号 ✅ |

单测 `test_external_bots` 54 项全过；新增 `test_member_bot_spam_archived_without_group_card` 与 `test_guest_bot_still_posts_group_card`。

全量 565 项里 2 项失败为 pre-existing（`test_menus_scoped_to_owner_and_authorized_group_admins`、`test_private_other_users_silent`），用改动前文件复现证明与本次无关。

## 历史脏数据

11 条群内 bot 带群卡的记录：1 条成功删除，10 条 Telegram 返回 `message to delete not found` / `can't be deleted`。全部回写 `report=-2`，库里现在 0 条残留。

## 遗留观察点

视觉模型连续失败会触发判定漂移（同消息 normal → spam）。中转 `127.0.0.1:18317` 的稳定性未在本轮排查，下次遇到「判定反复」先看 `bot.log` 里连续 `AI review attempt failed` 的模型名与错误码。
