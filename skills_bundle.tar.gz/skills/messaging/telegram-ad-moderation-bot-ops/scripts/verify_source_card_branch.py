#!/usr/bin/env python3
"""AdKiller 发卡分支验证：生产库副本 + FakeAPI 双场景断言。

用法（在 vps-la 上以 root 跑）：
    python3 verify_source_card_branch.py [--db /tmp/verify.db]

先在 /opt/ad-killer 里引入 external_bots，再对副本库插假 case 驱动 tick()。
断言两类：命中「群内 bot 不发卡」新分支的，和走老路径的（防回归）。

注意：
  * 用 sqlite3 backup API 取副本，不要直接 cp（WAL 活跃时会不一致/只读报错）
  * 类名是 ExternalBots，不是 External
  * FakeStore 需要接收 db 参数，否则 __init__ 里 UPDATE 会打 readonly 库
"""

import argparse
import json
import sqlite3
import sys
import time

SRC_DB = "/var/lib/private/ad-killer/state.db"
ARCHIVE = 0
OWNER = <YOUR_TELEGRAM_ID>  # 按实际 config 的 owner_id 调整


def clone_db(dst_path):
    src = sqlite3.connect(f"file:{SRC_DB}?mode=ro", uri=True)
    dst = sqlite3.connect(dst_path)
    with dst:
        src.backup(dst)
    dst.close()
    src.close()


class FakeAPI:
    def __init__(self):
        self.calls = []

    def call(self, name, **kw):
        self.calls.append((name, kw))
        if name == "sendMessage":
            return {"message_id": 9999}
        return {"status": "administrator", "can_delete_messages": True,
                "can_restrict_members": True,
                "permissions": {"can_send_messages": True}}

    def enqueue_send(self, **kw):
        self.calls.append(("enqueue_send", kw))


class FakeStore:
    config = {"archive_channel": ARCHIVE}

    def __init__(self, db):
        self.db = db

    def policy(self, cid):
        return {"mode": "observe"}

    def get(self, k, d=None):
        return d

    def set(self, k, v):
        pass


class FakeBot:
    owner = OWNER
    identity = {"id": 123, "username": "shashasha111_bot"}
    management = None
    cases = None

    def moderation_role(self, r):
        return True


def add_case(db, cid, mid, scope, bot_id=0, uname="gansini120bot"):
    payload = {"chat": {"id": cid, "title": "ban人群"},
               "from": {"id": bot_id, "is_bot": True, "username": uname},
               "message_id": mid, "caption": "测试番号", "text": ""}
    db.execute(
        """INSERT INTO external_cases(cid,mid,digest,payload,kind,caller,relation,verdict,deleted,
           archive,archive_state,state,media_ok,created,report,source_scope,linked_case)
           VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
        (cid, mid, "d-" + str(mid), json.dumps(payload), "bot", None, "none", "spam",
         "not_requested", 9999, "confirmed", "review", 1, int(time.time()), 0, scope, 0))
    db.commit()
    return db.execute("select max(id) from external_cases").fetchone()[0]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--db", default="/tmp/verify.db")
    args = ap.parse_args()

    sys.path.insert(0, "/opt/ad-killer")
    import external_bots

    clone_db(args.db)
    db = sqlite3.connect(args.db)
    db.row_factory = sqlite3.Row

    bot = FakeBot()
    bot.store = FakeStore(db)
    bot.api = FakeAPI()
    ext = external_bots.ExternalBots(bot)

    cid = 0
    fails = []

    # 场景 A：群内成员 bot —— 应不发群卡、私聊通知、report=-3
    n = add_case(db, cid, 999001, "member")
    ext.tick()
    cards = [k for m, k in bot.api.calls if m == "sendMessage" and k.get("chat_id") == cid]
    notes = [k for m, k in bot.api.calls if m in ("sendMessage", "enqueue_send")
             and k.get("chat_id") == OWNER]
    rep = db.execute("select report from external_cases where id=?", (n,)).fetchone()[0]
    print(f"[A] 群内发卡={len(cards)} (应0)  私聊={len(notes)} (应1)  report={rep} (应-3)")
    if notes:
        print("    通知:", notes[0]["text"].splitlines()[0])
    if cards or len(notes) != 1 or rep != -3:
        fails.append("A")

    # 场景 B：群外 bot —— 应仍发群卡（回归检查）
    bot.api.calls.clear()
    n = add_case(db, cid, 999002, "nonmember", bot_id=0, uname="outside_bot")
    ext.tick()
    cards = [k for m, k in bot.api.calls if m == "sendMessage" and k.get("chat_id") == cid]
    notes = [k for m, k in bot.api.calls if m in ("sendMessage", "enqueue_send")
             and k.get("chat_id") == OWNER]
    rep = db.execute("select report from external_cases where id=?", (n,)).fetchone()[0]
    print(f"[B] 群内发卡={len(cards)} (应1)  私聊={len(notes)} (应0)  report={rep} (应>0)")
    if len(cards) != 1 or notes or rep <= 0:
        fails.append("B")

    # 残留检查：成员 bot 不该有活的群卡
    left = db.execute("select count(*) from external_cases where kind='bot' "
                      "and source_scope in ('member','approved') and report>0").fetchone()[0]
    print(f"[C] 成员bot残留群卡={left} (应0)")
    if left:
        fails.append("C")

    print("\n结果:", "全部通过" if not fails else f"失败场景 {fails}")
    return 1 if fails else 0


if __name__ == "__main__":
    sys.exit(main())
