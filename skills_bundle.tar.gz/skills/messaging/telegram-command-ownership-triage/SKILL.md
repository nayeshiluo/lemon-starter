---
name: telegram-command-ownership-triage
description: "同一条 TG 指令被多个客户端（人型号/Bot1/Bot2）重复应答时：定位归属、对齐日志、定责与收敛。"
version: 1.0.0
author: Hermes Agent (柠檬)
license: MIT
platforms: [linux]
metadata:
  hermes:
    tags: [telegram, userbot, telethon, bot, dedup, triage, logging]
    related_skills: [lemon-userbot, telegram-quote-sticker, telegram-group-bot-suite]
---

# Telegram 指令归属与重复应答排障

一套账号体系里同时跑着多种客户端时（爸爸的 `naye` 上就有：主号人型号 `lemon-userbot`、群霸1 `lemon-group-bot`、群霸2 `lemon-group-bot2`、vps-la 上 TeleBox 第二号），**同一条指令可能被两个客户端各自应答一次**。用户看到的现象是"功能不稳定/偶尔重复"，实际是归属没划清。

## When to Use

- 「同一个指令生成了两次」「有时候两条、有时候一条」「贴纸/AI/总结重复回」
- 新功能在一个群上线后出现重复，而私聊正常
- 要判断某个群到底该由哪个 Bot / 人型号负责
- 需要在多客户端日志里对齐同一时刻的行为

## 第一原则：先定归属，再查代码

| 客户端 | 典型职责 | 应答范围 |
|---|---|---|
| 人型号（Telethon，`events.NewMessage(outgoing=True, pattern=...)`） | 私聊/收藏夹的 `,q`、`,sum`、`,ai`、生图 | **默认无 chat 类型过滤 → 任何群都答**，这是重复的头号来源 |
| 群霸 Bot（python-telegram-bot，`QUOTE_PATTERN` 等） | 群内正式功能：贴纸、总结、AI、点歌 | 按 `group_features` 逐群开关，且有 `active=1` 并发上限 |
| 第二个群霸 Bot | 另一批群（不同 `bot_id` / 不同 config 文件） | 群与 bot 的对应关系不固定，必须查日志确认 |

**结论模板**：群里的正式功能归群霸（有管理员标签、权限校验、限流）；人型号只保留私聊与收藏夹。反向（关群霸留人型）会丢掉权限/标签能力，一般不选。

## 关键陷阱（都踩过）

1. **只查一个 systemd unit 就下"没撞车"的结论**。不同群分属不同 bot：实测 `<YOUR_TELEGRAM_GROUP_ID>`（宸澄Emby）由 `lemon-group-bot2`/@<PRIVATE_IDENTIFIER>_bot 负责，`<PRIVATE_IDENTIFIER>` 才走 `lemon-group-bot`。`journalctl -u A -u B` 合看时也必须**分别按 unit 统计**，否则时间线会串。
2. **人型号的渲染日志不带 chat_id**。`Generating quote sticker ...` 这类行只有时间，必须向前配对最近一条 `Loaded N admins from ChannelParticipantsAdmins for chat <id>` 才能定位群。日志里没有就别硬猜群，改为按用户描述的时间点反查。
3. **"偶尔重复"被误读成不稳定**。群霸有同群 `active=1` 的 interactive_jobs 上限，用户快速连发时后几条被丢弃，人型号却条条都接 → 现象是"第一条双份、后面只有人型出图"。这是设计内的限流，不是渲染抖动。
4. **群 id 不要靠记忆映射**。查 `data/config_<PRIVATE_IDENTIFIER>.json` 里的群标题表（`grep -o '"-1004[0-9]*": "[^"]*"'`），或 `data/bot.db`；记忆里"某某群=某 id"经常过时。
5. **日志覆盖窗口先确认**。`journalctl -q -o short-iso | head -1` 拿最早一条时间。若窗口只有 5 天，"之前从没出现"可能只是超出留存，不是真的没发生。

## 标准排障步骤（只读）

1. 定时间点：向用户确认现象发生的具体时刻（最好拿到截图时间），再框日志窗口。
2. 各客户端分别取证据：
   - 人型号：`journalctl -u <userbot> --since '<窗口>' -q | grep -E '<业务日志锚点>'`
   - 群霸：`journalctl -u <bot1> -u <bot2> --since '<窗口>' -q | grep -E 'admitted kind=<kind>|finished kind=<kind>'`（**分 unit 汇总**）
3. 对齐时间戳：落在同秒~10 秒窗口内 → 同一条指令双触发；只有一边 → 归单边。
4. 排除业务链故障：若 `Quote-API failed` / 上游 4xx / `Empty` 计数为 0，渲染链无问题，不要再去挖隧道与依赖。
5. 给出归属建议 + 最小改法（一个 `if event.is_group: return` 级别的过滤），改前确认、改后重启并复验同一场景。

## 收敛手段（按侵入度排序）

- **推荐**：在人型号 handler 首行加范围过滤（`event.is_group` / 白名单 chat_id），群里交还群霸。
- 群霸侧关该群 feature：改动小但会丢能力，先问。
- 禁止用"删日志/降级日志级别"来掩盖重复——会让下次排障失去证据。

## 验收

- [ ] 同一群里连发 3 条指令，只有一套客户端出图/出答
- [ ] 私聊里人型号功能仍正常（过滤不能误伤私聊）
- [ ] 群霸的权限/标签/限流行为未变
- [ ] 复验日志里不再出现两侧同秒记录

## 实例

- `references/q-duplicate-emby-group-20261121.md` — 宸澄Emby 群 `,q` 双出图完整时间线、排除项、走过的弯路（含"只查一个 unit"导致误判的过程）。
