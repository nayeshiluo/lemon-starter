# 案例：`,q` 在宸澄Emby 群出图两次（2026-11-21 实测）

现象：爸爸问「一号人型最近 `,q` 为什么都生成两次贴图回复」。

## 结论

不是渲染服务问题。**人型号与群霸2 同群都监听 `,q`**：

- 人型号 `quote_handler` 挂 `@client.on(events.NewMessage(outgoing=True, pattern=r"^[,.，。](qh|qhs|q|qs|QH|QHS|Q|QS)...$"))`，全文件只有这一个 handler，**没有任何 `is_group` / chat 过滤**。
- 该群 `<YOUR_TELEGRAM_GROUP_ID>`（宸澄Emby）由 `lemon-group-bot2`（@<PRIVATE_IDENTIFIER>_bot）负责 quote，`group_features[...].quote = true`。

## 证据时间线（同一台 naye）

人型号渲染（`journalctl -u lemon-userbot`，`Generating quote sticker`）：

```
17:12:45  17:12:50  17:12:54  17:13:17  17:13:27  17:14:07  18:12:26  18:12:38
```

全部 8 次都落在 `<YOUR_TELEGRAM_GROUP_ID>`（靠前一行的 `Loaded 35 admins ... for chat <YOUR_TELEGRAM_GROUP_ID>` 配对得到）。

群霸2 同群 job（`journalctl -u lemon-group-bot2`）：

```
12:00:09 12:08:21 12:08:30 17:04:52 17:08:47 17:12:22 17:12:45
17:14:06 17:14:16 17:14:49 17:16:06 17:16:19 17:16:39
```

对齐结果：

| 时刻 | 群霸2 | 人型号 | 判定 |
|---|---|---|---|
| 17:12:45 | admitted | 同秒渲染 | 双份 |
| 17:14:06 | admitted | 下一秒渲染 | 双份 |
| 17:12:50/54、17:13:17/27 | 无 | 渲染 | 单边 |
| 18:12:26/38 | 无 | 渲染 | 单边 |

单边的原因：群霸 interactive_jobs 同群 `active=1`，连发时后几条被丢弃；人型号不限流，条条都接。

## 排除项（省时间用）

- `journalctl -u lemon-userbot -q | grep -cE 'Quote-API failed|Empty sticker'` → **0**，渲染链无问题，不用查 quote-api 隧道。
- 人型号 5 天内只有这 8 次渲染，之前 0 次 —— 是"最近开始在这个群用 `,q`"，不是"最近才坏"。

## 排查中走过的弯路

1. 先只查 `lemon-group-bot`，17:12 段一条 job 都没有，差点得出"没有撞车"的错误结论；加上 `lemon-group-bot2` 才对上。**两个 unit 必须分开统计。**
2. 一度把 `<YOUR_TELEGRAM_GROUP_ID>` 猜成茶百道，实际是 `宸澄Emby`（从 `data/config_<PRIVATE_IDENTIFIER>.json` 的群标题表查到的）。
3. 在 vps-la / yecao / aliyun / diaomao / vps-hk 上找"另一套人型号"，全部没有 userbot；`/opt/telebox-test` 的 TeleBox 第二号虽有 `quote.ts` 插件，但近期 journal 无 quote 记录。**先确认机器与进程范围，别跨机乱找。**

## 建议改法（未执行，等确认）

`userbot.py` 的 `quote_handler` 首行加：

```python
if event.is_group:
    return
```

群里归群霸2（带管理员标签、`qs` 权限校验），人型号只保留私聊/收藏夹。改后按 session 规范重启服务并复验：群内连发 3 条只出一份，私聊 `,q` 仍正常。
