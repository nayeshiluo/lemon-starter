---
name: telegram-subinfo-bot
description: "Build/maintain airport subscription-query Telegram bots."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux]
metadata:
  hermes:
    tags: [telegram, bot, subscription, airport, proxy, inline-keyboard, systemd]
    related_skills: [telegram-ops-bot, socks5-proxy-setup, lemon-userbot]
---

# 机场订阅查询 Telegram Bot（SubInfo Bot）

## When to Use
- 用户要求复刻/构建「订阅查询机器人」（如 @dycs888_bot 这类：发送机场订阅链接 → 返回流量/到期/节点信息）；
- 需要为订阅链接做流量统计、到期倒计时、节点清单解析的 TG Bot；
- 现有可运行实例：`/home/ubuntu/subinfo-bot/subinfo_bot.py`（systemd unit: `subinfo-bot.service`）。

## 核心原理（订阅协议）
机场订阅链接本质是带 token 的 http(s) URL。服务端行为：
1. **响应头 `subscription-userinfo`** 携带流量统计（关键！）：
   ```
   subscription-userinfo: upload=5368709120; download=21474836480; total=107374182400; expire=1893456000
   ```
   字段：`upload`(已上传B) `download`(已下载B) `total`(总量B) `expire`(Unix时间戳)。单位均为字节。
2. **响应体** 是节点列表：base64 编码的 uri 行（`vless://`/`vmess://`/`trojan://`/`ss://`…）或 Clash YAML（`proxies:`）。
3. **必须模拟客户端 UA**（`clash-verge/v2.0.4` 等）服务端才返回 userinfo 头；裸 curl 默认 UA 常拿不到统计头。

## 进阶功能演进（v3 全能管家架构）
- **本地文件直传解析（.txt / .yaml / .yml / .log）**：处理 Telegram 的 `document` 对象，经 `getFile` 下载临时文件，支持 Clash 配置字典与 URI 行双模解析。
- **用户专属订阅库（SQLite 持久化）**：
  - `/save <名称> <链接>` 存储到本地 SQLite；
  - `/my` 聚合并发轮询所有已存订阅，输出整体健康卡片；
  - `/del <名称>` 移除指定项。
- **纯净节点清洗导出（Clean Nodes Export）**：卡片上提供【📥 导出节点】按钮，将解析到的有效 URI 节点行剔除多余注释或杂质，生成 `clean_nodes.txt` 并以 `sendDocument` 发回。
- **独立项目开源仓库**：该项目已正式开源并托管在 GitHub：`nayeshiluo/subinfo-telegram-bot`（MIT 协议，全套含 Dockerfile、docker-compose、systemd 守护）。代码使用 `SUBINFO_BOT_TOKEN` 环境变量解耦，配合 `.gitignore` 严密杜绝 `subs.db` 与密钥泄漏。
- **开源工程化规范**：将项目独立开源至 GitHub 时，必须配合 `.gitignore`（严防 `subs.db`、`.env`、日志泄漏）、`.env.example`、`Dockerfile`、`docker-compose.yml` 及 MIT License。代码内严格使用环境变量读取 Token。

## 标准实现步骤
1. **Token 验证**：`curl https://api.telegram.org/bot<TOKEN>/getMe` → 确认 `ok:true`、记录 bot id/username（顺带确认是不是爸爸指定的 bot，避免改错对象）。
2. **轻量长轮询**（低配 VPS 首选，实测 34MB 内存）：纯 `requests` + `getUpdates(timeout=50)` 轮询，**不要**上 python-telegram-bot/aiogram——1.9GB 小鸡上每多一个重框架都是负担。
3. **消息处理**：
   - 私聊：直接提取文本中的 `https?://` 链接查询；
   - 群聊：仅响应 `/sub <链接>` 或 `/get <链接>`（防滥用）；
   - 限流：内存 dict 记每用户上次查询时间，间隔 <8s 拒绝。
4. **订阅请求**：`session.get(url, headers=ClashUA, timeout=20, allow_redirects=True, stream=True)`，流式读取上限 2MB。解析最终响应头（重定向后取 `resp.headers` 而非初始头）。
5. **卡片输出**（Markdown）：链接脱敏 + 流量（总/已用↑↓/剩余）+ 进度条（≥60% 橙、≥90% 红）+ 到期时间（UTC+8 换算）+ 剩余天数 + 节点数。sendMessage 失败时**去掉 parse_mode 重发兜底**（动态内容常带 `_*[]` 触发 Can't parse entities）。
6. **Inline Keyboard 三按钮**：`🔄 重新查询` / `🌍 节点详情` / `📋 复制链接`。
7. **命令菜单双层**：① Bot API `setMyCommands`（聊天框 `/` 菜单，含 `/start /menu /sub /get /help`）；② `/menu` 命令弹 Inline Keyboard 图形面板。
8. **部署**：systemd unit，token 走 `Environment=SUBINFO_BOT_TOKEN=...`（不写死进代码），`Restart=always` + `RestartSec=5`，开机自启。

## 关键陷阱（2026-09-09 实测）
1. **callback_data 只有 64 字节**——订阅链接动辄 200+ 字符，**绝不能把链接塞进 callback_data**。正确做法：`callback_data="reload:<message_id>"`，URL 存进程内存 dict（`query_cache[message_id] = url`，TTL 1h，容量上限 200 条自动淘汰最旧 50）。
2. **菜单类回调必须先于缓存检查处理**（真实 bug）：`menu:query` 这类无 URL 上下文的面板回调，若先走 `cache_get(anchor_id)` 会误报「上下文已过期」。分派顺序：`if action == "menu": ...; return` 放在 `try: anchor_id = int(anchor)` 之前。
3. **Markdown 转义**：动态节点名含 `[` `]` 等字符，用反引号包裹或整体降级纯文本重发。
4. **Telegram 消息上限 4096 字符**：节点预览只列前 12 个去重节点名，超出提示「…等共 N 个」。
5. **时区**：到期时间戳必须转北京时间（`timezone(timedelta(hours=8))`），否则倒计时偏差 8 小时。

## 交付节奏（爸爸偏好）
- 爸爸对部署进度敏感（多次「好了没」催促）：**每完成一个可验证节点立即汇报**（token 验证 ✓ → 核心逻辑实测 ✓ → 服务上线 ✓ → 菜单生效 ✓），不要闷头做完一次性交付。
- 上线即向爸爸私聊推送「✅ Bot 已上线」确认消息（真实 API 返回 `ok:true` 才算数）。
- 核心解析逻辑先用本地 mock 机场服务器（返回标准 subscription-userinfo 头 + base64 节点）实测输出，再交付，不空口报成功。
- 最终请爸爸用**真实订阅链接**做端到端验收。

## 扩展方向
- 节点地区国旗统计（香港🇭🇰/日本🇯🇵/美国🇺🇸…按名称关键词匹配聚合）；
- 多订阅保存 + 定时自动查流量推送；
- 集成 subconverter 一键格式转换。

## 支持文件
- `references/subscription-userinfo-protocol.md` — 协议字段详解、节点解析算法、mock 服务器写法。
