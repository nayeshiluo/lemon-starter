# subscription-userinfo 协议详解与节点解析算法

## 协议字段
响应头 `subscription-userinfo` 格式（分号分隔的 key=value）：
```
subscription-userinfo: upload=5368709120; download=21474836480; total=107374182400; expire=1893456000
```
| 字段 | 含义 | 单位 |
|------|------|------|
| `upload` | 已上传流量 | 字节 (B) |
| `download` | 已下载流量 | 字节 (B) |
| `total` | 总流量 | 字节 (B)，缺省/为 0 = 不限量 |
| `expire` | 到期时间 | Unix 时间戳（秒），≤0 = 长期有效 |

流量换算阶梯：B → KB → MB → GB → TB → PB，除 1024；<1024 显示整数，否则保留 2 位小数。
到期倒计时：`(expire_ts - now) / 86400` → 天/小时/分钟；已过期为「⚠️ 已到期」。

## 模拟客户端 UA（关键）
服务端通常按 UA 区分是否返回 userinfo 头。实测可用 UA 池：
```python
CLASH_UAS = [
    "clash-verge/v2.0.4",
    "ClashforWindows/0.20.39",
    "Clash.Meta/1.18",
    "v2rayNG/1.8.10",
    "sing-box/1.10.0",
    "Stash/2.5",
]
```
取第一个即可；请求必须 `allow_redirects=True` 并读**最终响应**的 headers（订阅 URL 常 302 跳转到真实订阅端点）。

## 节点解析算法
响应体可能是三种形态，需依次尝试：
1. **base64 块**：`^[A-Za-z0-9+/]{80,}={0,2}$` 且长度 >80 → base64 解码（补 `=` padding），得到逐行 uri；
2. **明文 uri 行**：正则 `(vless|vmess|trojan|ss|ssr|tuic|hysteria2?|hysteria|wireguard)://` 逐行匹配；
3. **Clash YAML**：以 `proxies:` 或 `- name:` 开头 → 正则抓 `name: "..."` 字段。

节点名提取优先级：`#fragment`（URL 解码）→ vmess 的 `ps` 字段（base64 JSON）→ 兜底 `{proto}节点`。

地区聚合：按节点名关键词匹配国旗字典（香港🇭🇰/日本🇯🇵/美国🇺🇸/新加坡🇸🇬/韩国🇰🇷/台湾🇹🇼…），未匹配归「其他🌐」。

## 链接脱敏
```python
re.sub(r"(token|key|uuid|password|pass|secret)=([^&]+)", r"\1=*****", url, flags=re.I)
```
所有对外展示的订阅链接一律过此函数；callback 日志同样脱敏后记录。

## Mock 机场服务器（本地测试用）
用 `http.server` 起本地服务器，返回标准响应头 + base64 节点体，即可离线验证 Bot 解析全链路：
```python
import base64
from http.server import BaseHTTPRequestHandler, HTTPServer

nodes = [
    "vless://<uuid>@hk1.example.com:443?security=tls&sni=hk1.example.com#🇭🇰 香港01",
    "trojan://password123@jp1.example.com:443#🇯🇵 日本01",
]
body = base64.b64encode("\n".join(nodes).encode()).decode()

class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        self.send_response(200)
        self.send_header("Content-Type", "text/plain; charset=utf-8")
        self.send_header("subscription-userinfo",
            "upload=5368709120; download=21474836480; total=107374182400; expire=1893456000")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body.encode())
    def log_message(self, *a): pass

HTTPServer(("127.0.0.1", 8899), Handler).serve_forever()
```
注意：该 handler 只实现 `do_GET`，`curl -I`（HEAD）会返回 501；测试用 `curl -s -D -` 而非 `-I`。

## Telegram 端要点
- `getUpdates` 必须 `allowed_updates=["message","callback_query"]` 才能收到按钮回调；
- callback_data ≤ 64 字节 → 用 `action:<message_id>` 做锚点，URL 存进程内存；
- 菜单类回调（无 URL 上下文）必须**先于**缓存检查分派，否则误报「上下文已过期」；
- `editMessageText` / `editMessageReplyMarkup` 用于原地刷新卡片和挂按钮；
- sendMessage 带 Markdown 失败时去掉 parse_mode 重发（动态内容常含 `_*[]` 等未闭合标记）。
