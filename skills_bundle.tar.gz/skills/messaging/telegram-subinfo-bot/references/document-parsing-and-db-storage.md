# 订阅管家多模态解析与工程化实践

## 1. Document 文件解析（YAML 与 URI 混合支持）
在 Telegram Bot 中接收用户直接拖拽的 `.txt`、`.yaml`、`.yml` 或 `.log` 文件：
1. 从 `message.document` 获取 `file_id` 和 `file_name`，预设 5MB 上限防止 OOM。
2. 调用 `getFile` 拿到 `file_path`，并通过 `https://api.telegram.org/file/bot<TOKEN>/<file_path>` 流式下载。
3. 解析优先逻辑：
   - 先探测是否为 Base64 编码字符串（若是则解码后进行正则提取）；
   - 使用正则 `(vless|vmess|trojan|ss|ssr|tuic|hysteria2?|wireguard)://` 提取单节点并还原备注；
   - 若未检出 URI 协议行，则尝试调用 `yaml.safe_load()` 解析 `proxies:` 字段中的节点名与类型。

## 2. 节点清洗与动态文件回传 (sendDocument)
当用户点击【📥 导出节点】时：
1. 从内存缓存中提取有效节点对象列表中的 `raw` 属性；
2. 用 `\n` 拼接为纯净的文本字节流；
3. 调用 Telegram Bot API 的 `sendDocument` 接口：
   ```python
   files = {"document": ("clean_nodes.txt", clean_content)}
   params = {"chat_id": chat_id, "caption": "✅ 成功清洗导出节点"}
   requests.post(f"{API_BASE}/sendDocument", data=params, files=files)
   ```

## 3. SQLite 用户订阅库设计
采用用户 ID 物理隔离设计：
```sql
CREATE TABLE IF NOT EXISTS user_subs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    name TEXT NOT NULL,
    url TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(user_id, name)
);
```
- `/save <名称> <链接>` 采用 `INSERT OR REPLACE` 保证幂等；
- `/my` 并发或快速轮询每个订阅，复用 `fetch_sub()` 并生成聚合卡片。

## 4. 开源仓库发布安全防线
推送代码至公开 GitHub 仓库前必须实施三道防线：
1. **源码反查**：`grep -rn "<BOT_TOKEN_PREFIX>" .` 确认没有任何真实 Token 残留；
2. **环境解耦**：源码使用 `os.environ.get("SUBINFO_BOT_TOKEN")`，并提供 `.env.example`；
3. **.gitignore 强拦截**：必须忽略 `subs.db`、`subs.db-journal`、`*.log`、`.env`。
