# 给 SGB 写审核规则：能到什么精度，以及为什么到不了 Ad Killer

Owner 说「怎么设置群规才能像广告杀手一样去广告」时读本文件。
`references/moderation-and-screening.md` 讲的是**闸门链**（开关 → 规则表 → 模型）；
本文件讲的是闸 2 满足之后的下一个问题：**规则内容怎么写、误杀率多少、值不值得做**。

## 结论先行

**SGB 的单条规则引擎到不了 Ad Killer 的精度，调参解决不了。** 已实测三版，规律是
「收紧就漏广告、放松就杀正常提问」，在 52%~90% 召回与 0~3 条误杀之间反复摆动，
不存在一个参数点同时满足高召回 + 零误杀。

要真正对齐，只有三条路（见末节），其中两条要动代码或花钱。

## 一、两者的架构差（这是精度差的根因）

Ad Killer（`vps-la:/opt/ad-killer`）是**四层**：

| 能力 | Ad Killer 实现 | SGB |
|---|---|---|
| 判定方式 | 多信号组合计分，命中 `>=2` 类才判 | 单条规则命中即 `violated=True, confidence=1.0` |
| 疑问/讨论豁免 | `caution` 正则（WARNING + QUESTION + 问号）；强推销时豁免**失效** | **无** |
| 文本归一化 | `normalize()`：NFKC + casefold + 去 `Cf`（零宽）+ `AD_VARIANTS` 繁简映射 | **无**，只对原文跑正则 |
| 分级处置 | `confirmed` / `suspected` / `clean`，suspected 交 AI 复核 | 只有 `warn` / `delete` / `ban` |
| AI 复核 | `ai.py`，`gemini-3.5-flash-lite` | **无** |

Ad Killer 之所以能 0 误杀，不是因为词表写得好，是因为**它有豁免层和复核层兜住边缘案例**。
SGB 把这两层都砍了，只剩第一层，所以词表再精也必然在边缘案例上二选一。

### Ad Killer 的判定分支（可作规则设计参考）

`rules.py: classify()` 按顺序短路返回，分支即「什么组合算广告」：

| reason | 触发条件 |
|---|---|
| `blocked_domain` | 命中 `policy.blocked_domains` 的域名 |
| `learned_exact` | 完整原文命中本群学习样本（不 strip 标点、不截断） |
| `learned_sample` | 去标点指纹相似度 ≥ 0.9 |
| `bot_promotion` | 消息含 `@xxxbot` + `BOT_PUSH` 词（点击/领取/进群/返佣…） |
| `card_promotion` | `vcc|虚拟卡` + 「开卡」+ ≥2 个信号（广告字样/0开卡/包过/联系方式） |
| `promotion_and_contact` | `PROMOTION` 词 + `CONTACT` 正则同时出现 |
| `paid_boost_promotion` | 代刷/刷量 + 收益承诺或推销 |
| `category_and_sales` | `BUSINESS` 类别词 + 推销/引流信号 |
| `behavior_and_promotion` | 转发/外部引用/名片/定位 + `SALES` 词 |
| `sample_similarity` | 与内置样本相似度 ≥ 0.88 |
| `repeated_promotion` | 同群 120 秒内 ≥3 条相同推广（`policy.py: Repeats`） |

`caution` 的构造（`rules.py`）：

```python
visible = URL.sub("", ad_text)                     # 先剥链接，防 ?start= 被当问号
caution = bool(WARNING.search(visible) or QUESTION.search(visible)
               or re.search(r"[?？]", visible))
strong_offer = (strong_contact and promotion) or (BUSINESS.search(compact) and explicit_offer)
if strong_offer:
    caution = False                                 # ← 强推销时豁免失效，这是关键
```

WARNING 词表：`不要信|别信|谨防|骗局|避坑|举报|反诈|被骗|诈骗|不是广告|广告样本`
QUESTION 词表：`怎么|如何|能用吗|可以用吗|是真的吗|怎么办|请问|求助|为什么|失败|不支持`

**SGB 没有这个「强推销时豁免失效」的条件机制**，这是它最大的能力缺口。

## 二、SGB 规则引擎的三个硬约束（写规则前必须知道）

### 1. 审核文本混入了引用元数据

`group.py` 约 6053 行把 reply 上下文拼进 `input_text` 才送审：

```python
reply_context = await _build_reply_context_for_llm(message, llm)
if reply_context:
    input_text = f"{input_text}\n{reply_context}"
```

`reply_context` 形如 `[reply_to_user] id:<YOUR_TELEGRAM_ID> username:@zjw120 name:༒`。
**后果：任何 `@[A-Za-z0-9_]{5,}` 形式的「联系方式」规则都会在正常回复消息上误杀。**
实测 594 条真实群消息里，就有一条「我就用的这个」因为引用对象带 `@username` 被
`promotion_and_contact` 类规则命中。

**规矩**：`CONTACT` 里不要放裸 `@username`，只放 `@xxxbot`（bot 引流）和明确的人类引流动作
（`私聊我|加我|加微信|vx号|点头像|点我`）。`联系` / `点击` / `进群` / `领取` / `代理`
这类单字词太泛，一律不进 `CONTACT`。

### 2. 正则只匹配原文，不做归一化

`_moderation_match_candidates()` 只额外生成 Telegram 命令别名候选，不 NFKC、不去零宽、不转繁简。
实测绕过手法与结果：

| 手法 | 例子 | 裸正则能否拦 |
|---|---|---|
| 加空格 | `加 微 信` | ✗ 要写 `加\s*微\s*信` |
| 全角字母 | `ＶＣＣ卡台 免ｋｙｃ` | ✗ 要写 `[vVｖＶ][cCｃＣ][cCｃＣ]` |
| 零宽字符 | `虚拟\u200b卡` | ✗ 要写 `虚[\s\S]{0,2}拟[\s\S]{0,2}卡` |
| emoji / 符号隔开 | `加微❤️信` `加.微.信` | ✗ 要写 `加[\s\S]{0,3}微[\s\S]{0,3}信` |
| 繁体 | `兼職日結` | ✗ 词表要显式列繁体变体 |
| 同音字 | `加威信` | ✗ 词表要加 `威信` |
| 拼音 | `jia weixin` | ✗ 基本放弃 |

每加一层容错都在放大误杀面（`[\s\S]{0,3}` 会让「加…微…信」这种巧合命中）。
**不要指望规则集能抗定向绕过**——真正的绕过对抗要靠语义规则或 Ad Killer 那套归一化。

### 3. 疑问豁免只能用负向前瞻，且做不到条件失效

SGB 没有 `caution` 变量，只能把豁免写成整条消息级的前缀：

```python
CAUTION = r"^(?![\s\S]*(?:怎么|如何|为什么|请问|求助|是什么|啥意思|什么意思|能用吗|"
CAUTION += r"可以用吗|真的吗|有人用过|是不是|有没有人|骗子|诈骗|假的|违法|举报|谨防|别信|避坑))"
```

`^(?!...)` 在位置 0 用 `[\s\S]*` 扫全文，等价于「整条消息含这些词就不匹配」。

**它的致命缺陷**：豁免是全局的，没有「强推销时豁免失效」。
- 加豁免 → 「日赚500 私聊我，骗子勿扰」被放过（广告带个「骗子」就免疫）
- 不加豁免 → 「这个虚拟卡怎么开卡？」被误杀

这正是 Ad Killer 用 `strong_offer` 解决、而 SGB 无解的那一步。

## 三、三版实测数据（2026-11，594 条真实群消息 + 33 条对抗样本）

负样本：`group_message_archive` 全量导出（594 条真实群聊）。
正样本：Ad Killer 的 7 条 `SAMPLES` + 1 条公开样本 + 19 条补充广告形态（含绕过变体）。
对抗样本：33 条「正常用户讨论广告词」（如「免kyc是什么意思」「虚拟卡怎么开卡？」「举报了一个刷单的」）。

| 版本 | 设计 | 正样本召回 | 真实消息误杀 | 对抗样本误杀 |
|---|---|---|---|---|
| v1 | 纯组合正则，无豁免 | **90%** (18/20) | **0/594** | **3 条** |
| v2 | 加疑问豁免（弱规则） | 70% | 1/594 | 2 条 |
| v3 | 三档分级 + 讨论豁免 + 抗绕过 | 52% | 0/594 | 2 条 |

**关键教训：只看真实群消息会得出「0 误杀」的假结论。** v1 在 594 条真实消息上零误杀，
一加对抗样本立刻暴露 3 条误杀——因为真实群聊里没人讨论「虚拟卡怎么开卡」，
而新成员、技术群、讨论群会。**任何规则集都必须自带对抗样本回归，不能只用历史消息测。**

三版共同的误杀源：
- `虚拟卡 + 开卡` 组合 → 误杀「这个虚拟卡怎么开卡？」
- `免kyc` / `四件套` 单词规则 → 误杀「免kyc是什么意思」
- `包赔稳赚` → 误杀「稳赚不赔这种话能信吗」

性能不是问题：14 条正则跑单条消息最慢 **0.29 ms**，远低于 SGB 的 0.1s 总预算。
**性能从来不是限制，精度才是。**

## 四、四条路（按推荐顺序）

### D（首选，2026-11-04 实测后新增）. 不重造：让 Ad Killer 自己干活

Owner 追问「还有更好的方案吗」时，答案不是再调一版正则，而是**先核实 Ad Killer 到底在不在工作**。
实测结论：它不是「配好了但没用」，是一个在跑、验证过、有真实战绩的系统，而且和 SGB
在同一个群（`<PRIVATE_IDENTIFIER>`），两个 bot 都是管理员。

实测事实（`/var/lib/private/ad-killer/state.db` + `/var/log/private/ad-killer/bot.log`）：

| 项 | 值 |
|---|---|
| 进程 | 2 天 2 小时无重启，`NRestarts=0`，`State: S` + `wchan=do_poll` |
| 入群验证 | **402** 次 |
| 成员名册 | 517 |
| 隔离 | 68 |
| 外部 bot 拦截 | **778**（`guest/spam` 17、`bot/spam` 9、`bot/normal` 659、`bot/uncertain` 16） |
| AI 复核 | 100 条 → spam 10 / normal 88 / uncertain 2 |
| 案件 | 89（`banned` 69 / `cancelled_ban` 2 / `protected` 8 / `simulated_ban` 5） |
| 雪花号扫描 | 18784 人 |

**关键判据：`banned=69` 是在另一个群 `<YOUR_TELEGRAM_GROUP_ID>` 的真实封禁**（含 2 次撤销、2 次管理员驳回），
说明它已经实战验证过，不是纸面逻辑。目标群只有 `simulated_ban=5`，因为那边 `mode: observe`。

`/admode` 四种模式，切之前**自检权限**（没权限会拒绝并说明）：

| 模式 | 行为 | 前置 |
|---|---|---|
| `observe` | 只记录不处置 | — |
| `delete` | 删明确广告，不封人 | `administrator` + `can_delete_messages` |
| `ban CONFIRM` | 删 + 封 | 上面 + `can_restrict_members` |
| `review CONFIRM` | 删 + 禁言等人工 | 仅 Owner |

**所以最优分工是**：广告 + 入群验证归 Ad Killer，AI 聊天 + 群规展示归 SGB。
SGB 的 `moderation` 保持 0 规则即可 —— 不冲突、零成本、零误伤。

为什么这比路线 A 更好：A 的终点就是「把 Ad Killer 的逻辑复制一份进 SGB」，
而 Ad Killer 已经有 `learned_sample` 学习样本、`case_seen` 3750 条去重指纹、89 个案件的人工
复核闭环、`guest` 模式拦截 —— 这些 SGB 抄不走。复制一份等于多一份维护、多一处升级冲突。

**⚠️ 必须先解决的冲突：两个 bot 都在做入群验证会打架。**
Ad Killer 已验 402 次，SGB 的 Turnstile 也开着 → 新成员会被两个 bot 同时禁言、同时要验证。
必须二选一，建议关 SGB 的（Ad Killer 那套跑得更久、有 402 次实证）。

### A. 移植 Ad Killer 的 `classify()` 进 SGB（唯一能真正对齐）

把 `rules.py` 的判定逻辑（组合计分 + `caution` 条件豁免 + 繁简归一）做成新的
`rule_type`（如 `adkiller`），在 `moderation.py` 的 `rule_type` 分流里加一个分支。

- 需要改 `bot/services/moderation.py`（约 100–150 行）+ `bot/db/models.py` 无需改（`rule_type` 是 `String(32)`）
- 必须写进 `LOCAL_PATCHES.md`，升级会被覆盖
- 优点：精度直接等于 Ad Killer，零 token 成本
- 缺点：改源码，与上游升级冲突

**注意 `_moderation_match_candidates()` 的元数据污染问题依然存在**——移植时要先剥掉
`[reply_to_*]` 段再判定，否则 `@username` 照样误杀。

### B. 用 SGB 自带的语义规则

把判定标准写进一条 `rule_type` 非 keyword/regex 的规则，`pattern` 填规则文本
（`build_prompt("moderation").format(rules_json=...)` 会把它塞进 prompt）。

- 不改源码，能理解「这是广告还是讨论」，天然具备疑问/讨论豁免
- 代价：**每条群消息调一次 `moderation` 模型**（与 decision 叠加成双份常驻成本）
- 上游测试非全绿（缺陷 3），误删风险要提前告知

### C. 正则打底 + 语义兜底（成本最优）

`moderation.py` 的循环是**先跑本地规则、命中即 return**，只有没命中的才进 `llm_rules`：

```python
for rule in rules:
    if rule_type == "keyword": ... return violated=True   # 不调模型
    if rule_type == "regex":   ... return violated=True   # 不调模型
    llm_rules.append(rule)
...
if not llm_rules: return 审核通过
```

所以 regex 规则是**免费快速通道**：命中就省掉那次模型调用。
但**没命中的消息仍要调模型**——除非群消息绝大多数能被 regex 拦下（正常闲聊群不可能），
否则成本≈方案 B。

## 五、给 Owner 的汇报口径

- **别承诺「配好规则就等于广告杀手」**。先给架构差（四层 vs 一层）和三版实测数据，
  再说三条路，让 Owner 选。他手上就有 Ad Killer，会拿效果对比。
- **别只报真实消息误杀率**。必须同时给对抗样本结果，否则 0 误杀是假的。
- **别把「开关已开」当交付**。0 条规则 = 空转，见 `moderation-and-screening.md` 第五节。
- Owner 关心「额度」时，方案 B/C 必须先说「每条消息一次模型调用」，
  再说「和 decision 叠加」。
- 规则一旦上线先用 `action=warn`（`warn_threshold` 默认 3 次才升级），别直接 `delete`/`ban`。

## 六、相关文件

- 闸门链与开启清单：`references/moderation-and-screening.md`
- 改运行时配置：`scripts/set_runtime_config.py`
- Guest Bot / bot-to-bot 平台事实：`references/telegram-bot-api-10-platform.md`
- Ad Killer 源码位置：`vps-la:/opt/ad-killer`（`rules.py` / `policy.py` / `domain_guard.py` / `ai.py`）。
  **`observe` 只影响「广告判定后的处置」**，入群验证 / 名册 / 隔离 / 外部 bot 拦截 / 雪花扫描照常跑 ——
  拿 `mode: observe` 判定「它什么都没干」是硬错（本次差点因此误判，实测数据见路线 D）。
- **状态文件真实路径是 `/var/lib/private/ad-killer/state.db`**（systemd `StateDirectory=` 私有挂载），
  日志在 `/var/log/private/ad-killer/bot.log`。`/opt/ad-killer/state.db` 是 **0 字节残留**，
  照它判断会得出「从未写入 / 服务是坏的」的错误结论。核实路径的唯一可靠办法：

  ```bash
  PID=$(systemctl show ad-killer -p MainPID --value)
  ls -l /proc/$PID/fd | grep -vE 'socket|/dev/(null|urandom)'
  cat /proc/$PID/wchan    # do_poll = 正在轮询，不是卡死
  ```
