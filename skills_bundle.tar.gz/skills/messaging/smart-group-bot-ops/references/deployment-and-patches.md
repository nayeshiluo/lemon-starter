# SGB 部署与补丁实录（2026-11-02/03，naye）

本文件是 `smart-group-bot-ops` 的取证底稿：完整部署步骤、踩过的坑、原始错误串、验证输出。
只在上游升级或重建环境时逐条照做；日常运维看 SKILL.md 就够。

## 1. 环境与前置

- Python ≥3.12（项目要求）、Docker 29.x、Caddy（`admin off`，只能 restart 不能 reload）
- 必需：Bot Token、`SUPER_ADMIN_ID`、`CONFIG_MASTER_KEY`、至少一个模型 provider、公网 HTTPS 域名
- 可选：Turnstile/hCaptcha（入群验证）、豆包 TTS 凭据

## 2. `.env` 键位（部署时的实际内容，值不入库）

```bash
BOT_TOKEN=...                      # 从 @BotFather 取，46 字符
SUPER_ADMIN_ID=<YOUR_TELEGRAM_ID>
DATABASE_URL=sqlite+aiosqlite:///./data/bot.db
CONFIG_MASTER_KEY=...              # openssl rand -hex 32，Fernet 由它派生
MINIAPP_PUBLIC_BASE_URL=https://<YOUR_PRIVATE_DOMAIN>
MINIAPP_LISTEN_HOST=127.0.0.1      # host 网络下只绑回环，由 Caddy 反代
MINIAPP_LISTEN_PORT=8480
APP_UID=10001
APP_GID=10001

# load_settings() 要求至少一个 MODEL_PROVIDER_<NAME>_*，否则启动报错
MODEL_PROVIDER_BOOTSTRAP_PROVIDER=openai_compatible
MODEL_PROVIDER_BOOTSTRAP_API_KEY=bootstrap
MODEL_PROVIDER_BOOTSTRAP_API_BASE=http://127.0.0.1:8317/v1
MAIN_PROVIDER_NAME=bootstrap
MAIN_MODEL=gemini-3-flash
```

`bootstrap` 段只是为了过 `bot/config.py:918-922` 的启动校验，真实模型配置在数据库里（Mini App 可改）。
`chmod 600 .env`；`config.toml` 需 `chmod 644`（容器内 app 用户只读挂载，否则 `PermissionError: 'config.toml'`）。

## 3. compose 改动：必须 host 网络

上游默认 `ports: 127.0.0.1:8480:8480` + bridge。**但模型走本机 CPA `127.0.0.1:8317`，bridge 容器访问
`host.docker.internal` 返回 000**（CPA 只监听回环）。

改法：删 `ports:`，加 `network_mode: host`，`.env` 的 `MINIAPP_LISTEN_HOST=127.0.0.1` 保证 Mini App 不裸奔。
原文件备份为 `docker-compose.yml.orig`。

## 4. 模型配置 seed（绕开 Mini App 手点）

用项目自身的类写库，保证格式与加密一致：

```python
from bot.services.runtime_config import (
    ChatRoleConfig, EmbedRoleConfig, ModelFallbackConfig,
    ModelSettingsConfig, ProviderConfig, RuntimeConfig, SecretCipher,
)
cipher = SecretCipher(master_key)          # SHA256(master) -> Fernet
config = RuntimeConfig(models=models)      # model_validator 校验 provider 引用
payload = config.storage_payload()
# 写 RuntimeConfigRecord(id=1) + RuntimeConfigSecret(name=..., ciphertext=cipher.encrypt(...))
```

secrets 的命名约定是 `providers.<provider_name>.api_key`、`movie_info.tmdb_read_access_token`。
**不要手动调 `_validate_model_references()`**，依赖 `model_validator` 即可。

实际角色分配（2026-11）：

| 角色 | provider / model | 说明 |
|---|---|---|
| main | antigravity / `gemini-3-flash` | 本机 CPA |
| decision | antigravity / `gemini-3.1-flash-lite` | 最频繁，选最快 |
| moderation | ikun / `Deepseek v4.1 Flash` | 跨供应商，避免同池 429 |
| compress | antigravity / `gemini-3.5-flash-lite` | |
| vision | antigravity / `gemini-3-flash` | 无 fallback（待补） |
| embed | gemini / `gemini-embedding-001` | 3072 维，不可换 |

## 5. 缺陷 1 取证：embedding 404

**现象**：`LLM failure | stage=embed | model=gemini/gemini-embedding-001 |
error=litellm.NotFoundError: GeminiException -`（错误串为空），随后 `LLM exhausted | no_fallback_left`。

**排除过程**：直接打 OpenAI 兼容端点 `POST /v1beta/openai/embeddings` 是通的（0.52s，3072 维），
说明 key 和模型都对。问题在项目侧的 base_url 改写：

```python
# bot/services/llm.py: _resolve_request_api_base()
if provider_norm != "gemini":
    return base
...
normalized_endpoint = "/v1beta/models"
version_suffix = "/v1beta"
if lower_base.endswith(lower_endpoint): ...        # 否
if lower_base.endswith(version_suffix): ...        # 否（结尾是 /openai）
return f"{normalized_base}{version_suffix}"        # → .../v1beta/openai/v1beta  ← 错
```

**修复**：`providers.gemini.api_base` 从 `https://generativelanguage.googleapis.com/v1beta/openai/`
改为 `https://generativelanguage.googleapis.com/v1beta`（原生端点，`endswith("/v1beta")` 命中第二个分支，原样返回）。

**验收**：

```
embed cfg: gemini | gemini/gemini-embedding-001 | https://generativelanguage.googleapis.com/v1beta
RESULT: OK model=gemini/gemini-embedding-001 dims=3072 n=2
```

日志侧看 `LLM response | stage=embed | dims=3072`。

三种调用方式实测（容器内 `litellm.aembedding`）：

| 写法 | 结果 |
|---|---|
| `model=gemini-embedding-001`，base `/v1beta/openai` | FAIL `APIConnectionError: No module named 'google'`（litellm 按前缀猜成原生） |
| `model=openai/gemini-embedding-001`，base `/v1beta/openai` | OK 3072 |
| `model=gemini/gemini-embedding-001`，base `/v1beta` | OK 3072 |

## 6. 缺陷 2 取证：音乐源

```
kuwo:     0.13s  FAIL HTTP 400 {"detail":"Value of `source` is not supported."}
netease:  0.30s  OK 命中3首（屋顶 - 周杰伦/温岚/吴宗宪, id=5257138）
joox:     0.18s  OK 命中30首
bilibili: 0.43s  OK 但首条是「周杰伦歌曲精选100首」合集视频
```

全链路验证不只看返回码，要真下音频：

```
types=url source=netease id=5257138 br=320
→ 0.26s url 有值
→ 实际 GET：200 audio/mpeg，200000 字节
```

## 7. 补丁：`bot/handlers/notify_owner.py`

Owner 需求「被私聊 / 被拉进群时提示我」。上游只记录 `bot_present` 状态，不发通知；私聊无转达机制。

设计要点：

- `@router.my_chat_member()`：只处理 **Bot 自身**成员变更，`old in {member,administrator,creator}` 与
  `new` 的布尔值相等时直接 return（过滤重复事件）。群维度过滤 `chat.type in ("group","supergroup")`。
- `@router.message(F.chat.type == "private")`：`is_super_admin_user_id` 排除 Owner 本人，其余转达给 Owner，
  **不回复对方**。同一用户 20 秒冷却（模块级 dict，单进程够用）。
- 正文截断 1000 字；无文本时用 `message.content_type` 占位。
- 全部走 `parse_mode="HTML"` + `escape()`，`disable_web_page_preview=True`。
- 通知失败只 `log.warning`，绝不影响主流程。

**注册顺序是唯一容易错的地方**（见 SKILL.md 的 aiogram 陷阱）：

```python
# bot/__main__.py:13
from bot.handlers import admin, commands, group, membership, notify_owner

# bot/__main__.py:384 附近
dp.include_router(commands.router)
dp.include_router(admin.router)
dp.include_router(membership.router)
dp.include_router(notify_owner.router)   # 必须在 group 之前
dp.include_router(group.router)
```

**验证订阅**：

```python
sorted(dp.resolve_used_update_types())
# ['callback_query', 'chat_member', 'edited_message', 'message', 'my_chat_member']
```

`my_chat_member` 缺失 = 事件永远收不到，且不会有任何报错。

## 8. 视觉链路实测

`_append_image_context()` 在主流程里、**决策「要不要回复」之前**调用，所以群里每张图都会被识别，
不需要 @bot。支持 `photo / photo_caption / document / animation / sticker`；`video`、`video_note` 直接旁路
（只审 caption）。

实测：`gemini-3-flash` 2.13s，`prompt_tokens=1098 + completion=25`，准确读出截图中 bot 名与按钮文案。
识别结果以 `[image-vision]` 前缀拼进消息文本，并写入 `group_message_archive`（带 `derived_text`），
所以后续提问能引用图片内容。

代价：每张图约 1100 tokens，群内刷图会烧额度。

## 9. 资源实测命令与输出

```bash
docker stats --no-stream --format '{{.Name}} {{.MemUsage}} {{.CPUPerc}} {{.PIDs}}' smart-group-bot-bot-1
# smart-group-bot-bot-1 313.3MiB / 1.5GiB (20.40%) 0.56% 11

C=$(docker inspect -f '{{.Id}}' smart-group-bot-bot-1)
sudo cat /sys/fs/cgroup/system.slice/docker-$C.scope/memory.peak     # 619 MB
sudo cat /sys/fs/cgroup/system.slice/docker-$C.scope/memory.current  # 313 MB
```

DB 体积拆分（69 条消息时 1.2 MB）：

```bash
sudo python3 -c "
import sqlite3
c=sqlite3.connect('file:/home/ubuntu/smart-group-bot/data/bot.db?mode=ro',uri=True)
for t, in c.execute(\"select name from sqlite_master where type='table' and name not like 'sqlite_%'\"):
    n=c.execute(f'select count(*) from \"{t}\"').fetchone()[0]
    if n: print(t, n)
print('pages', c.execute('pragma page_count').fetchone()[0], 'x', c.execute('pragma page_size').fetchone()[0])
"
```

## 10. 功能完备性盘点（2026-11-03 状态）

| 类别 | 项 | 状态 |
|---|---|---|
| 可用 | AI 聊天 / 群记忆 `/lm` `/compact` / 群规 / `/ban` 系 / 群授权 / Mini App / 点歌 / TMDb 影视 / AV 查询 | ✅ |
| 开着但缺凭据 | TTS（缺豆包 app_id/app_key/access_key）、IMDb 补充（缺 AWS 凭据） | ⚠ |
| 默认关闭 | `moderation`（本次主动关）、`patrol`、`raid_guard`、`vote_ban`、`verification` | ❌ |
| 技术债 | 无 `WEBHOOK_URL` → 轮询模式；12 个过期测试；gemini api_base 缺陷 | 🔧 |

Bot 在群内的权限实测：`status=administrator`，`can_delete_messages / can_restrict_members /
can_pin_messages / can_invite_users / can_manage_chat / can_change_info` 全为 `True`，
`can_promote_members=False`（一般不需要）。

## 11. 备份

```bash
TS=$(TZ=Asia/Shanghai date +%Y%m%d-%H%M%S)
sudo tar czf /home/ubuntu/.hermes/backups/smart-group-bot/sgb-$TS.tar.gz \
    .env config.toml data/bot.db docker-compose.yml \
    bot/handlers/notify_owner.py bot/__main__.py LOCAL_PATCHES.md
sudo chown ubuntu:ubuntu /home/ubuntu/.hermes/backups/smart-group-bot/sgb-$TS.tar.gz
chmod 600 /home/ubuntu/.hermes/backups/smart-group-bot/sgb-$TS.tar.gz
```

`data/` 属主是 `10001`，普通用户读不到，必须 `sudo`。**只打包 `.env` + `config.toml` 而漏了
`data/bot.db` 的包是无效备份**（加密密钥在库里，反过来也一样：只有库没有 `.env` 同样解不开）。
