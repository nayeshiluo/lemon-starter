# 模型迁移只读审计与保存协议

依据：2026-11 部署源码与容器内纯函数探针；行号是当时定位点，升级后按符号复查。未在本次执行迁移或外部模型请求。

## 先界定证据与范围

- 生效持久配置在 `data/bot.db` 的 `runtime_config.payload.models`；只读审计用 SQLite `mode=ro`，不调用可能初始化/写库的 manager 方法。
- 不输出密钥、密文或内部端点；用选择字段/布尔判断代替整份配置转储。查询 secrets 存在性和解密是不同权限范围。
- 先核对宿主与容器关键源码哈希、bind mounts，避免审错部署物。部署目录不必是 git checkout；git status 失败不能说工作区干净。历史测试统计不能代表当前部署已验收。
- “替换 Gemini 反代”不等于“删除所有 Gemini”：沿 embed.provider 找到对应 api_base，判断是否官方原生服务。此次 embed 是 Google 官方原生 `/v1beta` + gemini-embedding-001，保留。更换 embedding 即使维度相同也可能改变向量空间，须另做重索引迁移。

## 新建 OpenAI 兼容 provider

`bot/services/runtime_config.py:ProviderConfig`（约 58）：

- `models.providers[]`：`name`（唯一、小写化）、`provider="openai_compatible"`、`api_base`、`stream=false`、`chat_endpoint="chat_completions"`、`api_key=""`。
- 角色字段：`models.<role>.provider/model/fallbacks`；fallback 为 `{provider, model, request_params}`。保留原有温度、token、超时等，减少迁移变量。
- secrets 路径是 **`providers.<name>.api_key`**，不是 models.providers 路径。
- `secret_changes={"providers.<name>.api_key":{"action":"replace","value":<仅内存提供>}}`；另支持 keep/clear。
- SecretCipher 用 SHA256(CONFIG_MASTER_KEY) 派生 Fernet key；独立表 `runtime_config_secrets` 存密文。save 在同一事务保存配置与 secrets，并带 revision CAS；不要裸 UPDATE JSON。

## 含斜杠模型名是路由陷阱

`bot/config.py:_build_litellm_model`（约 390）遇到 model 内含 `/` 会原样返回，早于 openai_compatible 自动加前缀的逻辑。

容器内已验证的纯函数结果：

- `deepseek/deepseek-v4-flash-vision-exp` → 原样保留；不能仅凭 provider 配置断言必走 OpenAI transport。
- `openai/deepseek/deepseek-v4-flash-vision-exp` → 保留显式 OpenAI 前缀。

通过显式 `openai/<上游原始ID>` 强制兼容路由后，仍须在隔离环境/mock transport 中核验最终请求体 model 是上游原始 ID；本轮未证明完整网络调用链。不要从展示名猜模型 ID。

## 真热更新与离线保存不同

- `bot/web/settings_api.py`：GET/PUT `/api/v1/settings`，PUT schema 为 `{revision, config, secret_changes}`，使用现有认证。
- `RuntimeConfigManager.save()`（约 1423）校验并写库后 apply_to_settings、更新内存 config/revision、调用 `_notify_applied()`。
- `bot/__main__.py:apply_runtime_update`（约 476）通过 `set_apply_callback` 注册，调用 `llm.reconfigure`，后续请求使用新模型。
- **运行中 API 保存不需重启。独立脚本创建的 manager 没有生产 callback，保存后需受控重启生产进程。**不要把两个路径混为一谈。

## 能力与验收边界

文本模型不能用作视觉 fallback。此次上游任务已提供 DeepSeek 视觉实测正确、Beam/Glyph 纯文本的证据；未来供应商能力需重新核实。没有第二个已验证视觉模型时，宁可空 fallback。

隔离环境分别验 system 暗号、main 工具调用、decision/moderation 结构化输出、compress 摘要、vision 实图，并做 fallback 故障注入。生产验收检查 revision、角色与回退链、embed 不变、真实行为和健康状态；schema 测试通过不等于网络或模型能力通过。

备份时先核对 Compose 实际环境来源，不假设文件总叫 `.env`。运行中 SQLite 有 WAL 时使用 online backup API 获取一致快照，不能只复制主 DB；与 CONFIG_MASTER_KEY 来源、Compose/config、补丁代码一起限权/加密保存。此备份路径是后续执行建议，本次只读审计未执行备份恢复演练。
