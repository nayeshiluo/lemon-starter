# 防盗链 HLS 的签名转发端点

适用：任何「服务端能取到流、客户端点开必 403」的媒体源。SGB 里首个落地是 MissAV 的
`surrit.com` CDN，但模式与站点无关 —— 换站点只需改 `Referer` 与 base URL。

## 第 0 步：先查源站是不是已经自转发（这一步能省掉整个代理）

**动手写转发端点之前必须先查这个。** 镜像/聚合站为了让自己的页面能播，常把 CDN 域名
改写成**同源路径**再转发。一旦如此，「给页面链接」就是零成本正解，自建代理纯属多余，
还要白吃本机带宽、多一个会坏的组件。

MissAV 镜像站（`www.missav888.net`）实例，详情页 JS 里就一行：

```js
source = source.replace(/https:\/\/(([a-zA-Z0-9-]+\.)+[a-zA-Z]{2,})\//,
                        'https://www.missav888.net/jmpres/$1/');
```

即 `https://surrit.com/{uuid}/...` → `https://www.missav888.net/jmpres/surrit.com/{uuid}/...`。
浏览器打开详情页时同源请求自动带 Referer，页面自带 Plyr + hls.js，直接就能播。

实测 `/jmpres/` 端点（同一个 m3u8）：

| 请求 | 结果 |
|---|---|
| 带 `Referer: <详情页 URL>` → m3u8 | 200，71864 字节，4417 行 `#EXTM3U` |
| 带 `Referer: https://www.missav888.net/`（站点根就行）→ 分片 | 200，744668 字节真分片 |
| **不带 Referer** | **200，但返回 23111 字节占位 JPEG** |

最后一行是坑：**无 Referer 不是 403，而是 200 + 一张图**。只看状态码会以为「通了」。
验收必须看 body 是不是 `#EXTM3U`、分片是不是 600KB 级。

不需要浏览器就能查（在容器里跑 aiohttp）：

```python
html = await fetch(page_url)
print("/jmpres/" in html)                     # 有同源转发
print("eval(function(p,a,c,k,e,d)" in html)   # 播放地址仍是 packer 编码
```

通用特征：搜 `jmpres` / `/proxy/` / `/stream/` / `replace(/https:` 这类改写痕迹，
或者直接看页面里的 `<video>` 是不是被 JS 赋 `src` 而不是写死 CDN 地址。

### 决策顺序

```
① 浏览器打开源站详情页，能播吗？
     能 → 卡片直接给页面 URL，零带宽，到此结束
② 不能，但页面里有同源转发路径 → 一样给页面 URL
③ 只有裸 m3u8、必须自定义 header → 才建下面的签名转发端点
```

给页面 URL 时记得**同源去重**：`detail.url == detail.watch_url` 时只渲染一次，
否则卡片里两个链接指向同一个地方。SGB 的落法是 `AVDetail.watch_url` +
caption「在线观看」+ 按钮「▶️ 在线播放」，代理只作兜底。

## 判定：是不是 Referer/UA 防盗链

先用 `aiohttp` 做四组矩阵，别用 ffprobe（它对 header 传递另有坑）：

| 组合 | 典型结果 |
|---|---|
| `User-Agent` only | 403 |
| `Referer` only | 403 |
| **UA + Referer** | **200 `#EXTM3U`** |
| UA + Referer + Origin/Accept | 200（多余，不必加） |

结论：UA 与 Referer **缺一不可**。同时验证分片（不是只有 playlist）：
分片通常只需 UA + Referer，`#EXT-X-TOKEN` 之类往往**服务端并不校验**，别为它写代码。

再补一条反例：把 Referer 设成**源站自己**（镜像站域名）通常 403 —— 说明校验的是
「伪装成从正版站点的页面点进来的」，所以 Referer 值要填**正版站域名**，不是当前能访问的镜像域名。

## 什么时候才需要服务端转发（第 0 步排除之后）

Telegram / Safari / 绝大多数手机播放器都**不能注入自定义请求头**。
`InlineKeyboardButton(url=...)`、`<a href>` 超链接、直接粘 m3u8 给播放器 —— 全部 403。
除非 Owner 明确用支持自定义 header 的播放器（VLC/IINA 桌面版可以），
否则**当且仅当源站没有可播页面（第 0 步 ①② 都不成立）**时，才只剩转发一条路。

分清两件事：给**页面 URL** 没问题 —— Telegram 内置浏览器正常加载页面，页面自己发的
同源请求带 Referer；403 的只有**裸流地址**。早期把这两件事混为一谈，白建了一整套代理。

## 架构

```
客户端 → https://<自己的域名>/avp/{exp}/{sig}/{b64}/{filename}
                    ↓ 校验签名与过期
              本机 aiohttp 带 UA + Referer 请求 CDN
                    ↓
         m3u8 → 重写内部所有 URL 后再返回
         分片 → 流式透传
```

签名保证不被当公开代理刷；过期时间保证链接不会永久有效。

## 实现骨架（`bot/services/av_proxy.py`）

```python
_PROXY_PREFIX = "/avp"
_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 ... Chrome/<YOUR_SERVER_IP> Safari/537.36"

def _secret() -> str:
    raw = os.environ.get("CONFIG_MASTER_KEY") or os.environ.get("AV_PROXY_SECRET")
    return hashlib.sha256(f"av-proxy:{raw}".encode()).hexdigest()

def _sign(exp: int, url: str) -> str:
    return hmac.new(_secret().encode(), f"{exp}:{url}".encode(), hashlib.sha256).hexdigest()[:20]

def build_proxy_url(raw_url: str, ttl: int = 7200) -> str:
    base = os.environ["MINIAPP_PUBLIC_BASE_URL"].rstrip("/")
    exp = int(time.time()) + ttl
    b64 = base64.urlsafe_b64encode(raw_url.encode()).decode().rstrip("=")
    name = ...            # 见下方「坑 1/2」
    return f"{base}{_PROXY_PREFIX}/{exp}/{_sign(exp, raw_url)}/{b64}/{name}"
```

handler 侧：

1. 解 `exp` / `sig` / `b64`，`time.time() > exp` → 403，`hmac.compare_digest` 失败 → 403
2. 只允许 `http(s)://`，防 SSRF
3. `session.get(target, headers={"User-Agent": _UA, "Referer": referer})`
4. `Content-Type` 含 `mpegurl` 或 URL 含 `.m3u8` → 读文本、逐行重写、以
   `application/vnd.apple.mpegurl` 返回，并带 `Cache-Control: no-store`
5. 否则 `web.StreamResponse` + `iter_chunked(65536)` 透传

m3u8 重写（相对路径必须先 `urljoin` 成绝对再签名，否则播放器拿到的是相对本站的路径）：

```python
for line in body.splitlines():
    s = line.strip()
    if not s or s.startswith("#"):
        out.append(line)          # 保留 #EXT-X-* 原样
        continue
    out.append(build_proxy_url(urljoin(base_url, s), ttl=remaining) or s)
```

`ttl` 传 `exp - now`（剩余时间），保证重写出来的子链接不会比入口链接活得更久。

session 用模块级懒加载单例，别每个分片新建 `ClientSession`（一条 720p 片源有 2000+ 分片）。

## 三个必踩的坑

### 坑 1：URL 没有扩展名，播放器与 ffprobe 直接拒绝

```
[hls] URL https://host/avp/.../aHR0cHM6... is not in allowed_segment_extensions
Invalid data found when processing input
```

纯 base64 结尾的 URL 没有后缀，HLS demuxer 连解析都不开始。**末尾必须补原文件名**：

```python
path = raw_url.split("?", 1)[0]
name = path.rstrip("/").rsplit("/", 1)[-1] or "video.m3u8"   # playlist
```

### 坑 2：分片伪装成 `.jpeg`，`.jpeg` 不在 ffmpeg 的 HLS 白名单

CDN 把 MPEG-TS 分片命名成 `video0.jpeg`、`Content-Type: image/jpeg`。
即使加 `-allowed_extensions ALL` 仍然被拒。**分片名统一改成 `.ts`**（内容本来就是 TS）：

```python
if ".m3u8" in path.lower():
    name = <原文件名>
else:
    name = "seg.ts"     # 不要沿用 .jpeg
```

### 坑 3：`Content-Type` 是 `image/jpeg`，播放器当图片丢掉

上游返回图片 MIME，客户端拿到二进制也不当视频解。转发时改写：

```python
"Content-Type": "video/mp2t" if ct.lower().startswith("image/") else (ct or "application/octet-stream")
```

## 验收：不用等人播，ffprobe 就能证

拿代理链接直接喂 ffprobe，能读出编码/分辨率/时长就说明整条链路（playlist 重写 → 分片透传 →
Content-Type）全部正确：

```bash
sudo docker compose exec -T bot ffprobe -v error -allowed_extensions ALL \
  -select_streams v:0 -show_entries stream=codec_name,width,height \
  -show_entries format=duration -of default=nw=1 "$PROXY_URL"
```

期望输出（实测 MissAV 720p）：

```
codec_name=h264
width=1280
height=720
duration=8820.576229      ← 2小时27分
```

注意：`ffprobe` 直接对**原始 CDN 链接**加 `-headers "Referer: ..."` 会 403 ——
ffmpeg 的 header 传递与 aiohttp 不一致，别用它判断「CDN 是否可访问」，那一步用 aiohttp 矩阵测。

## 想把流量搬到别的机器？先验证上游可达性，别先搭架子

Owner 看到「视频全走本机」一定会问「能不能走别的机器」。答案是**先测，而且大概率不行**。

同一部片、同一个 m3u8、同样的 `User-Agent` + `Referer`，用 aiohttp 从三台机器请求：

| 机器 / 出口 | 结果 |
|---|---|
| naye（Leaseweb SG） | **200 `#EXTM3U`** |
| vps-la（Racknerd） | 403，4544 字节拦截页 |
| diaomao（Taipei101） | 403，4549 字节拦截页 |

CDN 按 **IP 段**放行，只有原机能过。这种情况下无论加多少中转，取流那一步都必然 403。

### 陷阱：`curl` 会给出假阴性

**在 naye 本机上，`curl -A <UA> -H "Referer: https://missav.ws/"` 同样返回 403，而 aiohttp 返回 200。**

也就是说除了 IP 段，CDN 还在看 TLS 指纹 / 客户端特征。用 curl 判断「这台机器能不能访问」会得出
完全错误的结论——本机明明可用却判成被封。**可达性探针一律用 aiohttp，不用 curl。**

同理，`ffprobe -headers "Referer: ..."` 对原始 CDN 链接也 403，别拿它当连通性依据。

### 正确顺序（这次搞反了，白搭一轮）

```
① 在目标机跑 aiohttp 探针，确认能取到 #EXTM3U
② 只有 ① 通过，才去建 tunnel / systemd / venv
③ 部署完再端到端验一次
```

本次先建了 Cloudflare Tunnel + ingress + DNS + systemd + venv，外部 `/healthz` 已经 200、
源站 IP 也隐藏成功，最后才发现上游 403 —— 全部作废。

### 跨机部署时必须改的两个环境变量

如果确实需要端点与 SGB 分离（例如 CDN 对两台都放行），有两处不能靠默认值：

```python
def _secret() -> str:
    # 显式 AV_PROXY_SECRET 优先，否则两边各自从 CONFIG_MASTER_KEY 派生必然对不上
    explicit = os.environ.get("AV_PROXY_SECRET", "").strip()
    if explicit:
        return explicit
    raw = os.environ.get("CONFIG_MASTER_KEY") or "sgb-av-proxy-fallback"
    return hashlib.sha256(f"av-proxy:{raw}".encode()).hexdigest()
```

```python
base = (os.environ.get("AV_PROXY_PUBLIC_BASE")
        or os.environ.get("MINIAPP_PUBLIC_BASE_URL") or "").rstrip("/")
```

`AV_PROXY_SECRET` 用 `openssl rand -hex 32` 生成，两边写同一个值（600 权限）。
排障时只比指纹，别打印明文：

```bash
grep '^AV_PROXY_SECRET=' .env | sed 's/^AV_PROXY_SECRET=//' | tr -d '\n' | sha256sum | cut -c1-16
```

签名对不上时服务返回 `403 bad signature`，签名通过但上游拒绝时返回 **`upstream error`**（非 200 透传）——
看到 `upstream error` 就说明问题在出口 IP，别再查密钥。

### 回滚清单（决定放弃时一次清干净）

```bash
# 远端
systemctl disable --now <svc>-tunnel.service <svc>-proxy.service
rm -f /etc/systemd/system/<svc>-tunnel.service /etc/systemd/system/<svc>-proxy.service
rm -f /etc/cloudflared/<svc>.token
rm -rf /opt/<svc>
systemctl daemon-reload && systemctl reset-failed <svc>-tunnel.service <svc>-proxy.service
# 确认同机其他 tunnel 仍 active、端口已释放

# Cloudflare：先删 DNS 记录，再 clean connections，最后删 tunnel
# DELETE /zones/{zone}/dns_records/{id}
# DELETE /accounts/{acct}/cfd_tunnel/{tid}/connections
# DELETE /accounts/{acct}/cfd_tunnel/{tid}
# 本地 token / meta.json 一并删除
```

删完 `curl https://<域名>/healthz` 应返回 `000`（Could not resolve host），才算真干净。
**同机已有的 tunnel 全程 `is-active` 必须保持 active**，回滚后要复核一遍。

## 成本与开关

- 视频流全部经本机中转。单路 720p 约 **2–3 Mbps**，一部片约 1–1.5 GB。
  云厂商按流量计费的机器（如 AWS 100GB/月）**不要开**；固定带宽/不限流量的 VPS 可以。
- 开关：`AV_PROXY_ENABLED=0` → 端点不注册，`build_proxy_url()` 返回空串，展示层自动回退裸链。
- Referer 可覆盖：`AV_PROXY_REFERER`（镜像站换域名时不用改代码）。
- 打开前主动告诉 Owner 这条带宽代价，别等他发现流量涨了才说。
