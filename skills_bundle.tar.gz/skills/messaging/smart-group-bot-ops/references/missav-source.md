# 接入 missav 检索源（2026-11 实测，已闭环）

目标：给 SGB 的 AV 检索加第 5 个源，拿到中文标题 + m3u8 在线播放直链
（现有 javbus / madouqu / dmm / fc2 都没有播放直链）。

**结论**：搜索、详情、m3u8 直链**全部验证可用**。
分片**不校验** `#EXT-X-TOKEN`，只要 `UA + Referer: https://missav.ws/` 就 200。
但 Telegram 打开外链不带自定义 Referer，所以**没有给用户「在线播放」按钮**（见 §八）。

---

## 一、域名现状：官方站全废

| 域名 | 结果 |
|---|---|
| `missav.com` | **空壳**。所有路径一律 `301 -> /`，页面 24KB 无内容 |
| `missav.ws` | Cloudflare `403` |
| `missav.ai` | Cloudflare `403` |
| `missav.tv` | `401` |
| `www.missav888.net` | **200，无 CF 拦截，可抓**（当前在用） |
| `missav.live` | 200，有卡片但链接数少，备选 |

URL 形态（**两种都要收**）：

- 番号搜索：`https://<host>/dm44/cn/ssis-001`（`dm44` 是线路编号，每张卡可能不同，别写死）
- 关键词搜索：`https://<host>/cn/dldss-578`（**没有 `/dmNN` 前缀**）
- 详情页都能 `GET`，返回同样的 OG 标签

## 二、Cloudflare 绕过尝试（都失败，别重复）

| 方法 | 结果 |
|---|---|
| `cloudscraper` 1.2.71 | 全部 403，`cf_challenge=True`，版本太旧 |
| Playwright + `chrome-headless-shell` | 卡在 `Just a moment...`，6 次轮询 3s 后仍是挑战页 |
| 伪装 UA / Accept-Language | 无效 |

Playwright 环境本身能跑（装 `libnspr4 libnss3 libatk1.0-0 libatk-bridge2.0-0
libatspi2.0-0 libcups2 libxcomposite1 libxdamage1` 后 `ldd` 无缺失），
**是 CF 识别出无头 + 数据中心 IP**，不是依赖问题。要真过只能上 FlareSolverr / 住宅代理 / 有头交互，
维护成本远超收益 —— **走镜像站**。

## 三、搜索结果解析

卡片结构（Alpine.js + Tailwind）：

```html
<div @mouseenter="setPreview('UUID')" class="thumbnail group">
  <div class="relative aspect-w-16 aspect-h-9 ...">
    <a href="https://www.missav888.net/dm44/cn/ssis-001" alt="ssis-001">
      <video data-src="https://spic2-47.vcwinford.cc/ssis-001/preview.mp4"></video>
      <img class="lozad w-full" data-src=".../cover-t.jpg" src="data:image/png;base64,...">
    </a>
    ...
  </div>
  <div class="my-2 text-sm text-nord4 truncate"><a href="...">TITLE</a></div>
</div>
```

**关键陷阱**：结果网格容器是
`<div x-data x-init="$nextTick(() => { initLozad() })" class="grid grid-cols-2 ...">`。
`x-init` 里的 **`=>`** 会让 `<div[^>]*class="([^"]*grid[^"]*)"` 这类正则在 `>` 处断掉，
**匹配不到容器**。任何「属性到第一个 `>` 为止」的正则在这页都会翻车。

正确做法：**按卡片 class 切分**，不要找容器：

```python
for chunk in re.split(r'class="thumbnail group"', content)[1:]:
    block = chunk[:8000]        # 截断，避免跨到下一张卡
    href  = _extract_first(r'<a[^>]+href=["\']([^"\']+)["\']', block)
    cover = _extract_first(r'<img[^>]+data-src=["\']([^"\']+)["\']', block)
    title = _clean_text(_strip_tags(_extract_first(r'truncate["\'][^>]*>(.*?)</div>', block)))
```

必须过滤的导航链接：`/search/`、`/actresses`、`/genres/`、`/saved/`、`/tags`、`/ranking`。

### slug → 番号：取最后一段，不要正则整条 URL

**踩过的坑**：对整条 URL 跑 `/([a-z0-9]{2,8}-[a-z0-9]{2,6})` 会先命中 CDN 分片前缀
`/dm44/` 或直接匹配失败，导致番号恒为空。正确做法是先取 slug 再规范化：

```python
def _missav_slug_code(url: str) -> str:
    slug = (url or "").rstrip("/").rsplit("/", 1)[-1]   # /dm52/cn/ssis-001-uncensored-leak
    if not slug:
        return ""
    fc2 = normalize_fc2_code(slug)      # fc2-ppv-5002306 -> FC2-PPV-5002306
    if fc2:
        return fc2
    return normalize_av_code(slug)      # ssis-001-uncensored-leak -> SSIS-001（\b 边界自然截断）
```

- **FC2 必须先判**，否则 `normalize_av_code` 会把 7 位数字判掉
- `caribbeancom-110226-001` 这类超长厂牌（>10 字母）`normalize_av_code` 匹配不到，
  code 留空可接受（标题里已有完整番号），别为此放宽全局正则 —— 会影响其他四源

## 四、详情页：OG 标签全都有，别去啃正文

```
og:title / og:image / og:url / og:description
og:video:release_date   -> "2021-02-21"
og:video:duration       -> 秒数或 ISO-8601（"7080" / "PT1H58M" 都要吃）
og:video:actor          -> 多条，一演员一标签
og:video:director
```

类型（genres）走链接，但**要过滤全局导航**：只要 href 含 `/dm` 且含 `/genres/` 的，
`/cn/genres`、`/cn/genres/VR` 是导航不是本片类型。

时长格式化：

```python
def _format_iso_duration(raw: str) -> str:
    value = raw.strip()
    if value.isdigit():
        total = int(value)
    else:
        m = re.fullmatch(r"P(?:\d+D)?T(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?", value, re.I)
        h, mi, s = (int(p or 0) for p in m.groups())
        total = h * 3600 + mi * 60 + s
    h, rem = divmod(total, 3600)
    ...  # 7080 -> "1小时58分"，PT1H58M 同结果
```

## 五、m3u8 藏在 Dean Edwards packer 里，纯 Python 可解

```js
eval(function(p,a,c,k,e,d){...}('f=\'8://7.6/5-4-3-2-1/e.0\';...',
  16,16,'m3u8|d20308920041|9c38|411c|45a1|0c73d32d|com|surrit|https|video|1280x720|source1280|842x480|source842|playlist|source'.split('|'),0,{}))
```

**字典直接暴露在 payload 后面**，`8=https`、`7=surrit`、`6=com`，base36 索引替换即可：

```python
B36 = "0123456789abcdefghijklmnopqrstuvwxyz"

def _unpack(payload, words):
    def swap(m):
        idx = 0
        for ch in m.group(1):
            idx = idx * 36 + B36.index(ch.lower())
        return words[idx] if 0 <= idx < len(words) and words[idx] else m.group(0)
    decoded = re.sub(r"\b([0-9a-zA-Z]+)\b", swap, payload).replace("\\'", "'")
    return dict(re.findall(r"(\w+)\s*=\s*'([^']*\.m3u8[^']*)'", decoded))
```

解开后：

```
source      = https://surrit.com/{uuid}/playlist.m3u8        # master，三档码率
source842   = https://surrit.com/{uuid}/842x480/video.m3u8
source1280  = https://surrit.com/{uuid}/1280x720/video.m3u8
```

UUID 是标准格式：`00000000-0000-0000-0000-000000000000`。
**不需要浏览器**，纯正则 + base36 就够 —— 这是整个方案能落地的前提。

## 六、CDN 防盗链：UA 和 Referer 缺一不可

CDN 是 `surrit.com`。实测组合（请求 `.../1280x720/video.m3u8`）：

| 请求头 | 结果 |
|---|---|
| 只带 `User-Agent` | **403** |
| 只带 `Referer: https://missav.ws/`（无 UA） | 403 |
| 什么都不带 | 403 |
| `UA` + `Referer: https://missav.ws/` | **200 `#EXTM3U`** |
| `UA` + `Referer: https://missav.ai/` | 200 |
| `UA` + `Referer: https://www.missav888.net/` | **403**（镜像站自己的来源反而不行） |

要点：
- **Referer 必须伪装成官方站 `missav.ws` / `missav.ai`**，不能用镜像站域名
- UA 用常见桌面 Chrome 串
- 镜像站页面请求和 CDN 请求是两套 Referer，别混用

## 七、播放列表结构 + token 已确认不校验

`playlist.m3u8` 是 **master**：

```
#EXTM3U
#EXT-X-VERSION:3
#EXT-X-TOKEN=AZiFTO2YzYhlDM5YDO0UTY8NTNykTN8VjNugDNx4SN4EjL4kTM

#EXT-X-STREAM-INF:BANDWIDTH=800000,RESOLUTION=640x360
640x360/video.m3u8
#EXT-X-STREAM-INF:BANDWIDTH=2800000,RESOLUTION=1280x720
1280x720/video.m3u8
```

`1280x720/video.m3u8` 是 **media playlist**：2205 个 `#EXTINF`，同样带 `#EXT-X-TOKEN`。
**分片文件名伪装成 `.jpeg`**：`video0.jpeg`、`video1.jpeg`……

分片实测（`video0.jpeg`，744 KB，`Content-Type: image/jpeg`）：

| 请求头 | 结果 |
|---|---|
| `UA` + `Referer` | **200** |
| `UA` + `Referer` + `X-Token: <playlist 里的 token>` | 200（与上同字节数） |
| `UA` + `Referer` + `?token=<token>` | 200 |
| 只带 `UA` | 403 |

**结论：`#EXT-X-TOKEN` 是标记不是校验**，分片只要 UA+Referer。
所以**不需要做 SGB 侧视频代理**（那会把 1.6 GB 流量压到 naye 上，AWS 额度直接爆）。

## 八、交付形态：不给「在线播放」按钮

直链服务端能 200，但用户点不到：

- Telegram 打开 `InlineKeyboardButton(url=...)` 时**不带自定义 Referer** → 必然 403
- 浏览器地址栏直接粘也不带 → 403
- 只有支持自定义请求头的播放器（IINA / VLC / SenPlayer）手动加 `Referer: https://missav.ws/` 才能播

所以展示层最终形态：

- `_build_av_detail_caption`：只给「画质」标签（`1280x720`），**不给播放行**
- `_build_av_detail_text`：给「播放直链」裸 URL + 一行
  `<i>该 CDN 仅接受 Referer: https://missav.ws/ 的请求，普通浏览器直接打开会 403。</i>`
- `_build_av_detail_keyboard`：**只有「浏览种子」和「打开详情页」**，播放按钮已删除

长度实测：caption 408 字符、text 555 字符，均远低于 Telegram 上限（1024 / 4096）。

## 九、代码落点（已合入，含后续修复）

| 文件 | 改动 |
|---|---|
| `bot/config.py` | `av_missav_base_url` / `av_missav_referer` |
| `bot/services/av_search.py` | `AVDetail.play_urls: dict[str,str]`、`_search_missav`、`_parse_missav_search`、`_fetch_missav_detail`、`_parse_missav_detail`、`_missav_slug_code`、`_unpack_missav_playlist`、`_format_iso_duration`、`_missav_stream_for_code`、`_enrich_with_missav` |
| `bot/services/av_search.py` | `_search_impl` 合并改**轮询交错**；`_lookup_by_code_impl` 并行 `create_task` 补播放直链 + missav 兜底；`_fetch_detail_impl` 各源分支包 `_enrich_with_missav` |
| `bot/handlers/commands.py` | `_source_name` 加 `missav`、`_pick_best_play_url`、详情 text 加播放行 + Referer 说明、**键盘不加播放按钮** |

性能实测（`lookup_by_code`，含补链）：

| 番号 | 串行补链 | 并行补链 |
|---|---|---|
| `SSIS-001` | 3.16s | **0.60s** |
| `SSNI-777` | 1.27s | **0.75s** |
| `ABP-123` | 4.06s | 0.87s / 4.56s（镜像站自身抖动，单独测 missav 段 0.7–2.2s） |

搜索聚合验收：`巨乳` 共 18 条，missav 占 5 条（第 5/8/11/14/17 位），
`javbus 6 / madouqu 5 / dmm 1 / fc2 1 / missav 5` —— 交错合并生效。

改动约 300 行，无新增第三方依赖（正则 + 标准库）。
**升级上游会被覆盖**，必须记进 `LOCAL_PATCHES.md`，并把「合并仍是轮询交错」列入升级复核项。

## 十、仍然存在的限制

- 镜像站是**第三方**，域名随时挂/改版；`av_missav_base_url` / `av_missav_referer` 必须可配置
- 镜像站**不索引 FC2**（`FC2-PPV-xxxxxxx` 查询 missav 返回 0）
- 内容与官方不同步，新片可能滞后
- `caribbeancom-110226-001` 这类超长厂牌番号 code 为空（标题里有完整番号）
