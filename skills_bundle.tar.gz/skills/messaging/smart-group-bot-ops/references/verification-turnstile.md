# SGB 入群验证 / Turnstile 落地实录

2026-11-03 在 naye 上把 `verification` 从 `enabled=false` 开到可用状态的完整过程。
所有命令都在 `/home/ubuntu/smart-group-bot` 下执行。

## 0. 前置判断：这功能值不值得开

开启后新成员进群是**先禁言再验证**，10 分钟不验直接踢。熟人小群开了纯添麻烦；
开放群 / 资源群才值得。开之前问清楚要开哪几个群 —— 这个开关**没有群级粒度**。

## 1. Owner 交付密钥的方式

不要在聊天里贴 key。沿用 Token 那套：

```bash
sudo tee /root/sgb_turnstile >/dev/null <<'EOF'
SITE_KEY=0x4AAAAAAAA...
SECRET_KEY=0x4AAAAAAAA...
EOF
sudo chmod 600 /root/sgb_turnstile
```

读完立刻 `shred -u`，中间不落任何其它文件。

也可以让 Owner 直接在 Mini App → 设置中心 → 入群验证 里填，效果一样（写库路径相同），
事后由助手复核。这条对 Owner 更省事，优先推荐。

## 2. 查配置：payload 空 ≠ 没保存

第一遍查 payload 得到：

```
turnstile_site_key: len=24   fp=2d411cdc     ← 有值
turnstile_secret_key: len=0  fp=-            ← 空！
```

**这是设计如此**，secret 走 `runtime_config_secrets` 加密表，payload 里留空占位。
当时差点误报「Secret Key 没存进去」，查表才发现是完整的。

```bash
sudo -n python3 - <<'PY'
import sqlite3
db = sqlite3.connect('/home/ubuntu/smart-group-bot/data/bot.db')
db.row_factory = sqlite3.Row
for r in db.execute("select * from runtime_config_secrets"):
    d = dict(r)
    print({k: (f"<len {len(str(v))}>" if isinstance(v, str) and len(v) > 40 else v)
           for k, v in d.items()})
PY
```

表结构（踩过坑：以为列名叫 `key_name`，实际是 `name`）：

| 列 | 说明 |
|---|---|
| `name` | 形如 `verification.turnstile_secret_key` |
| `ciphertext` | Fernet 密文，约 140 字符 |
| `updated_by` | Telegram user id |
| `updated_at` | UTC |

## 3. 解密验证格式（不打印明文）

```bash
sudo -n docker compose exec -T bot python - <<'PY'
import asyncio, hashlib
from bot.services.runtime_config import SecretCipher   # 不是 bot.services.secret_cipher
from bot.config import load_settings
from bot.db.engine import init_db
from bot.db.models import RuntimeConfigSecret
from sqlalchemy import select

async def main():
    s = load_settings()
    cipher = SecretCipher(s.config_master_key)   # 传原始 master key 字符串
    engine, sf = await init_db(s.database_url)
    async with sf() as sess:
        r = (await sess.execute(select(RuntimeConfigSecret).where(
            RuntimeConfigSecret.name == "verification.turnstile_secret_key"))).scalar_one()
        pt = cipher.decrypt(r.ciphertext)
        print(f"len={len(pt)} prefix={pt[:4]!r} fp={hashlib.sha256(pt.encode()).hexdigest()[:8]}")
    await engine.dispose()

asyncio.run(main())
PY
```

实测输出：`len=35 prefix='0x4A' fp=92ec9399` —— 长度和前缀都对。

格式基线：

| 字段 | 长度 | 前缀 |
|---|---|---|
| Turnstile Site Key | 24 | `0x4A` |
| Turnstile Secret Key | 35 | `0x4A` |

## 4. 假 token 探针（核心技巧）

不用等人进群，直接问 Cloudflare「你认这个 secret 吗」：

```bash
sudo -n docker compose exec -T bot python - <<'PY'
import asyncio, json, aiohttp
from bot.services.runtime_config import SecretCipher
from bot.config import load_settings
from bot.db.engine import init_db
from bot.db.models import RuntimeConfigSecret
from sqlalchemy import select

async def main():
    s = load_settings(); cipher = SecretCipher(s.config_master_key)
    engine, sf = await init_db(s.database_url)
    async with sf() as sess:
        r = (await sess.execute(select(RuntimeConfigSecret).where(
            RuntimeConfigSecret.name == "verification.turnstile_secret_key"))).scalar_one()
        secret = cipher.decrypt(r.ciphertext)
    await engine.dispose()
    async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=15)) as c:
        async with c.post("https://challenges.cloudflare.com/turnstile/v0/siteverify",
                          data={"secret": secret, "response": "dummy-token-probe"}) as resp:
            print("http:", resp.status)
            print("body:", json.dumps(await resp.json(), ensure_ascii=False))

asyncio.run(main())
PY
```

实测返回：

```json
{"error-codes": ["invalid-input-response"], "success": false, "messages": []}
```

判读：

| `error-codes` | 结论 |
|---|---|
| `invalid-input-response` | **secret 有效**，只是 token 是假的 —— 这就是通过 |
| `invalid-input-secret` | secret 错了，回 Mini App 重填 |

注意 `success` 恒为 `false`（假 token 当然不过），**只看 `error-codes`，别看 `success`**。

## 5. 开开关

改 payload 的 `verification.enabled`，`revision + 1`，重启容器。

```bash
sudo -n python3 - <<'PY'
import json, sqlite3, datetime
p = '/home/ubuntu/smart-group-bot/data/bot.db'
db = sqlite3.connect(p); db.row_factory = sqlite3.Row
row = db.execute("select revision, payload from runtime_config order by revision desc limit 1").fetchone()
rev, payload = row["revision"], row["payload"]
cfg = json.loads(payload)
cfg["verification"]["enabled"] = True
db.execute("update runtime_config set revision=?, payload=?, updated_by=?, updated_at=? where revision=?",
           (rev+1, json.dumps(cfg, ensure_ascii=False, separators=(",", ":")), <YOUR_TELEGRAM_ID>,
            datetime.datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S'), rev))
db.commit()
print(f"revision {rev} -> {rev+1}")
PY
```

只翻一个布尔值时直接改 JSON 可行；**动 provider / 模型引用时不要这么干**，
必须走 `RuntimeConfig.model_validate(payload)` → `storage_payload()`，否则绕过引用校验。

`sudo python3` 写出的中间备份文件属主是 root，普通用户 `rm` 会 `Operation not permitted`，
要 `sudo rm`。更省事的做法：不留中间文件，改前直接把 payload 打到 stdout 存档。

## 6. 验收清单

```bash
sudo -n docker compose restart bot
sleep 12
sudo -n docker compose ps --format '{{.Name}} {{.Status}}'          # Up (healthy)
curl -s -o /dev/null -w '%{http_code}\n' https://<YOUR_PRIVATE_DOMAIN>/healthz   # 200
sudo -n docker compose logs --since 60s bot | grep -i 'verif\|turnstile'      # verification sweeper started
curl -s http://127.0.0.1:8480/verify | grep -o 'cf-turnstile\|data-sitekey="[^"]*"'
```

`/verify` 路由在 `bot/services/verify_web.py` 里注册（`app.router.add_get("/verify", ...)`），
和 `/healthz`、`/settings` 并列。页面 200 且同时含 `cf-turnstile` 与 `data-sitekey` 才算前端就绪。

日志出现 `verification sweeper started` 是关键信号 —— 它证明超时踢人的后台任务真的起来了，
比读 `enabled=true` 可靠。

## 7. 最大的坑：Bot 不是管理员就静默不触发

入群检测链路：

```
bot/handlers/membership.py
  ChatMemberUpdatedFilter(IS_NOT_MEMBER >> IS_MEMBER)
```

**Telegram 只把 `chat_member` 更新推给群管理员。** Bot 没有管理员权限时：
不报错、不告警、日志干净、配置显示 enabled —— 就是一个也不验证。

所以开 verification 前必须逐群确认：

```bash
curl -s "https://api.telegram.org/bot$BOT_TOKEN/getChatMember?chat_id=<群ID>&user_id=<bot_id>"
# 需要 status=administrator 且 can_restrict_members=true（禁言靠它）
```

这次 `ban人群`（`<PRIVATE_IDENTIFIER>`）已确认是 administrator 且权限齐全；
另一个群 `<PRIVATE_IDENTIFIER>` 的权限查询命令审批超时被拦，**未确认**，
汇报时如实标注为待验证项，不要默认它也 OK。

## 8. WebView 兼容性（结论：能跑）

Cloudflare 官方对 WebView 的要求：JS 执行、DOM storage、可访问 `challenges.cloudflare.com`、
能连 `about:blank` / `about:srcdoc`、UA 全程一致、无严格 CSP。

Telegram 官方客户端默认满足。桌面版 WebView 限制更多，**验收优先手机**。
若某客户端白屏/转圈，先换官方手机客户端复现，再怀疑配置。

创建 widget：`Widget Mode` 选 **Managed**；`Hostnames` 只填域名
（`<YOUR_PRIVATE_DOMAIN>`），不带 `https://`、路径、端口。

## 9. 全局影响

`verification` 是全局开关，一开所有已授权群同时生效，没有群级粒度。
开之前要跟 Owner 确认每个群的性质，别把一个熟人小群顺手锁成「进群禁言 10 分钟」。
