# SGB 交付后体检（全只读，约 10 分钟）

Owner 问「目前没有其他问题了吧」时，按这份清单**实测**，不要凭「容器 healthy」作答。
下面所有命令只读：不改配置、不重启、不写库。2026-11-03 实跑一次，五个判据全部踩过假阳性。

## 一、四条命令的体检矩阵

```bash
cd /home/ubuntu/smart-group-bot

# 1) 容器
sudo docker compose ps --format 'table {{.Name}}\t{{.Status}}\t{{.Image}}'

# 2) 公网端点（四个都要 200；/settings-assets/app.js 是前端真相）
for p in /healthz /settings /verify /settings-assets/app.js; do
  printf "%-26s %s\n" "$p" \
    "$(curl -s -o /dev/null -w '%{http_code} %{time_total}s' --max-time 15 https://<YOUR_PRIVATE_DOMAIN>$p)"
done

# 3) 容器资源 + cgroup 峰值
sudo docker stats --no-stream --format '{{.MemUsage}} | cpu={{.CPUPerc}} | pids={{.PIDs}}' smart-group-bot-bot-1
C=$(sudo docker inspect -f '{{.Id}}' smart-group-bot-bot-1)
sudo cat /sys/fs/cgroup/system.slice/docker-$C.scope/memory.peak

# 4) 主机
free -m | awk 'NR==1||NR==2'; df -h / | tail -1; uptime
```

2026-11-03 基线：`Up (healthy)`；四端点 200 / 0.22s 级；**369 MiB / 1.5 GiB**、cpu 1.4%、PIDs 11；
cgroup peak **651 MB**（上限 1536 MB，约 42%）；主机 available 9093 MB、磁盘 82 G 余、load 0.06。

内存从 313 MB 涨到 369 MB 属正常（向量 + 缓存增长），不是泄漏 —— 判泄漏看 cgroup peak 是否贴着上限。

## 二、日志判读

```bash
sudo docker logs --since 60m smart-group-bot-bot-1 > /tmp/sgb_log.txt 2>&1
echo "总行数: $(wc -l < /tmp/sgb_log.txt)"
echo "ERROR/Traceback: $(grep -icE 'traceback|\[error\]|critical' /tmp/sgb_log.txt)"
echo "WARNING: $(grep -ic 'warning' /tmp/sgb_log.txt)"
grep -vE '\[info\]|INFO' /tmp/sgb_log.txt | tail -20
```

判据：ERROR / WARNING **都应为 0**；`grep -v INFO` 只应剩下别的语言标记的日志行。

健康时的正常噪音（别当成问题）：

- `pending batch decision done | action=skip` 反复出现 —— decision 模型在判断要不要回复，没 @ 就 skip，
  每条群消息都会跑一次（约 2 s）。这是**成本点**，不是故障。
- `aiohttp.access ... "GET /healthz" 200` 每分钟若干条 —— 容器 healthcheck。
- `stage=embed ... dims=3072` 与 `stage=decision` 成对出现 —— 记忆链路正常。

注意日志是**中文级别词**（`信息` / `警告` / `错误`），`grep 'ERROR'` 可能漏；
用 `\[error\]` + `traceback` + `critical` 三个并集更稳。

## 三、数据库

```python
import sqlite3, json
c = sqlite3.connect("file:/home/ubuntu/smart-group-bot/data/bot.db?mode=ro", uri=True)
print("integrity:", c.execute("PRAGMA integrity_check").fetchone()[0])   # 必须 ok
print("journal  :", c.execute("PRAGMA journal_mode").fetchone()[0])      # 应为 wal
for t in [r[0] for r in c.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name")]:
    print(f"{t:36s}", c.execute(f"SELECT COUNT(*) FROM {t}").fetchone()[0])
print("revision:", c.execute("SELECT revision, updated_by, updated_at FROM runtime_config ORDER BY revision DESC LIMIT 1").fetchone())
```

2026-11-03 基线（约 954 页 × 4096 B ≈ 3.9 MB）：`integrity ok`、`wal`；
`group_message_archive` 317 / `group_message_archive_embeddings` 317（**必须相等**）/
`message_vectors` 312 / `webhook_inbox_updates` 338 / `groups` 2 / `authorized_groups` 2 /
`runtime_config` 1 行 / `runtime_config_secrets` 5 行。

`runtime_config` 只有 **1 行**（每次保存覆盖同一行、revision 递增），所以**看不到历史版本**——
改动前的 payload 备份一旦删掉就无法回溯。改开关前先 `cp` 一份 payload 到 `/tmp`。

## 四、五个会骗人的判据（本节是重点）

### 1. `last_error IS NOT NULL` 把空串算成错误

```sql
-- 错：338 行全被判成「有错误」
SELECT COUNT(*) FROM webhook_inbox_updates WHERE last_error IS NOT NULL;
-- 对：
SELECT COUNT(*) FROM webhook_inbox_updates WHERE last_error IS NOT NULL AND last_error <> '';
```

实测 338 条 `last_error` 全是 `''`，且 `completed_at` 全部非空、`dead_lettered_at` 全空 ——
**队列其实是 100% 健康**。正确口径是分别看 `completed_at IS NULL`（积压）、
`dead_lettered_at IS NOT NULL`（死信）、`last_error <> ''`（真错误）三个数。

### 2. 两套向量表，join 错列就得出「317 条没向量化」

| 表 | 键 | 含义 |
|---|---|---|
| `message_vectors` | `message_id` = **字符串** `<PRIVATE_IDENTIFIER>:1258`（即 `message_key`） | 短期记忆 / 召回 |
| `group_message_archive_embeddings` | `archive_id` = **整数**，对应 `group_message_archive.id` | 归档向量 |

`message_vectors.message_id = group_message_archive.id`（int vs varchar）**恒不匹配**，
会得到「archive missing vector: 317 / 317」这种看起来致命的结论。正确 join：

```sql
-- 短期向量覆盖率
SELECT COUNT(*) FROM group_message_archive a
 WHERE NOT EXISTS (SELECT 1 FROM message_vectors v WHERE v.message_id = a.message_key);
-- 归档向量覆盖率（这个才是 100% 硬指标）
SELECT COUNT(*) FROM group_message_archive a
 WHERE NOT EXISTS (SELECT 1 FROM group_message_archive_embeddings e WHERE e.archive_id = a.id);
```

实测：按 `message_key` 只缺 5 条（bot 自身/空消息，正常），归档向量 0 缺失。

### 3. `runtime_config` 的开关不等于代码默认值

`RaidGuardSettingsConfig.enabled` / `VoteBanSettingsConfig.enabled` 代码里都是 `bool = False`，
但库里是 `True`。原因：`app.js` **有** `raid_guard.enabled` / `vote_ban.enabled` 表单项，
Owner 早先在 Mini App 保存 Turnstile 时被表单一并提交上去了。

所以「配置和默认值不一致」**不等于**被入侵或代码被改。汇报口径：

> 「这两个是开着的，代码默认是关，应该是你在设置中心勾上的。」

再给风险判断，而不是直接去关：

| 开关 | 触发条件 | 误伤概率 |
|---|---|---|
| `raid_guard` | 60 s 内进 8 人 → 锁群 600 s + 质询踢人 | 低（小群一天进不了 8 人），但真触发会误伤 |
| `vote_ban` | 5 票 + 3 次触发 | 极低（要多人投票） |

查这类差异前先确认「UI 里有没有这个字段」（`grep -o "raid_guard\.[a-z_]*" bot/web/static/app.js`），
有字段就说明是合法入口改的，没有字段才是可疑来源。

### 4. `docker system df` 的 Build Cache total ≠ 可回收

```
Build Cache     84        0         5.543GB   78.06MB
```

5.5 GB 里只有 **78 MB** 可回收（其余被现有镜像层引用）。别按 total 汇报「能省 5.5 G」，
`docker builder prune -f` 实测也就回收几百 MB。

同理 `Images 3.111GB / RECLAIMABLE 1.325GB (42%)` 属其他服务镜像层（subboost 等），未确认前不动。

### 5. 站点根路径 404 是正常的

`https://<YOUR_PRIVATE_DOMAIN>/` 返回 **404** —— 只注册了 `/healthz` `/settings` `/verify`
`/settings-assets/`，没有根路由。这不是 Caddy 配错、也不是容器没起。

顺带复核 Caddy 其他站点没被影响（`admin off` 只能 restart，重启前先记基线）：

```bash
systemctl is-active caddy
for h in aws beszel komari sgb; do
  printf "  %-10s %s\n" "$h" "$(curl -s -o /dev/null -w '%{http_code}' --max-time 10 https://$<YOUR_PRIVATE_DOMAIN>/)"
done
```

基线：aws 200 / beszel **302**（登录跳转，正常）/ komari 200 / sgb **404**（无根路由）。

## 五、群权限（顺手收掉 verification 的前置条件）

```python
# 容器内跑：sudo docker compose exec -T bot python - < /tmp/check_groups.py
TOKEN = os.environ["BOT_TOKEN"]
for gid in ("<PRIVATE_IDENTIFIER>", "<PRIVATE_IDENTIFIER>"):
    getChatMember(chat_id=gid, user_id=me["id"])
```

判据：`status=administrator` 且 **`can_restrict_members=True`**（禁言/踢人靠它，verification 全靠这个）。
`can_invite_users` / `can_change_info` 缺失不影响核心功能，如实记录即可。

2026-11-03 实测两群都是 administrator：`ban人群` 权限齐全；`人🐔局（执着白嫖）`
缺 `can_invite_users` / `can_change_info`，其余齐全 —— verification 两群都能生效。

## 六、汇报结构

先给「没有阻塞性问题」，再给一张体检表（项 / 结果），然后单列两类：

1. **需要 Owner 确认的**：与默认值不一致的开关（给触发条件 + 误伤概率，让他决定关不关）
2. **还没验证过的**：不是故障，是没机会测 —— 例如 `join_verifications=0`（还没有新成员进群）、
   `notify_owner` 真实通知、BotFather 的 Main Mini App 入口

不要把这三点混进「问题」里，也不要因为没法测就略过不提。
