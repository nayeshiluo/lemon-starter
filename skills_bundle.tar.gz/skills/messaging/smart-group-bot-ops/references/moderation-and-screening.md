# SGB 审核与筛查：闸门链、规则成本、开启清单

Owner 问「打开它」「能不能拦广告」「guest bot 会不会漏」时按本文件答。
核心结论：**SGB 的审核不是一个开关，是三层闸门串联，任何一层没满足都表现为「静默放过」**
（不报错、不告警、日志干净）。

## 一、三层闸门

```
moderation.enabled ──┬─→ 普通消息审核        group.py 约 6105
                     ├─→ 其他 bot 消息筛查   group.py 约 5940  （还需 bot_screening_enabled）
                     └─→ 入群资料审查        membership.py 约 2531
                                    ↓
                         moderation_rules 表非空（三条链路共同的第二道闸）
                                    ↓
                         moderation 模型（仅语义规则才调）
```

### 闸 1：`moderation.enabled`

- 库字段：`runtime_config.payload.moderation.enabled`
- 代码默认值 `True`（`ModerationSettingsConfig.enabled`），**但 DB 实际值是最终生效值**
- 读它必须走 `RuntimeConfigManager.initialize()` 之后的 Settings；`load_settings()` 单独调
  只会返回 `config.toml` 静态默认，看不到 Mini App 的改动

### 闸 2：`moderation_rules` 表非空

`bot/services/moderation.py` `evaluate()` 开头：

```python
if not rules:
    log.info("审核通过 (无启用规则)")
    return make_verdict(violated=False, reason="", rule=None, conclusive=True)
```

**0 条规则 = 每条消息直接放行，不调模型、零成本、零拦截。** 这是最容易被误报成
「已经开了」的状态：开关是 `True`，容器 healthy，日志无错，实际什么都不拦。

查规则数（容器内跑，宿主 `sqlite3` CLI 在 naye 上不可用）：

```python
import sqlite3
c = sqlite3.connect("/app/data/bot.db")
print(c.execute("select count(*) from moderation_rules").fetchone()[0])
print(c.execute(
    "select group_id, rule_type, action, enabled, count(*) "
    "from moderation_rules group by group_id, rule_type, action, enabled"
).fetchall())
```

### 闸 3：`bot_screening_enabled`（仅其他 bot 的消息）

```python
raw_bot_sender = bool(message.from_user and message.from_user.is_bot
                      and not _uses_sender_chat_identity(message))
if raw_bot_sender:
    if (
        not getattr(settings.moderation, "enabled", False)      # ← 第一个条件就 return
        or not getattr(settings.moderation, "bot_screening_enabled", False)
        or bot_sender_id == int(getattr(bot_me, "id", 0) or 0)
    ):
        return
```

`bot_screening_enabled=True` 单独毫无意义。默认阈值 `bot_screening_message_count=5`：
每个 bot 在每个群累计 5 条干净消息后进白名单，之后不再审；白名单前违规计数清零。
群管理员 bot 与人工豁免 bot 直接跳过；`/unaiexempt` 可撤销白名单。

### 闸 3.5：BotFather 的 Bot-to-Bot Communication Mode

**不开这个，SGB 根本收不到其他 bot 的群消息**，闸 2 闸 3 全满足也白搭。
只能在手机上操作：`/mybots` → 选 bot → Bot Settings → 开启 bot-to-bot 相关开关。
Bot API 无对应方法，Agent 碰不到 —— 汇报时必须单列成「需要你手动做的一步」。

## 二、三类规则的成本差

`moderation.py` 按 `rule_type` 分流，**只有落到 `llm_rules` 的才调模型**：

| `rule_type` | 处理方式 | 成本 | 命中行为 |
|---|---|---|---|
| `keyword` | `pattern.casefold() in candidate` 本地包含匹配 | **零** | 直接 `violated=True, confidence=1.0` |
| `regex` | `safe_regex` + 总预算 0.1s，单次 0.02s | **零** | 同上；超预算置 `deterministic_inconclusive=True` |
| 其他（含未知 legacy 类型） | 进 `llm_rules` → `llm.moderation(system, user_input)` | **每条消息一次** | 由模型判置信度 |

注意末尾注释：`# Unknown legacy rule types are treated as semantic rules rather than
silently ignored.` —— 写错 `rule_type` 不会失效，而是**悄悄变成最贵的那类**。

语义规则与 `decision` 叠加成双份每消息成本（decision 实测约 2391 prompt tokens）。
Owner 刚问过「额度耗在哪」时，建议语义规则必须同时说「成本翻倍」。

## 三、开 `moderation` 的连带影响

1. **入群资料审查一起启用**（`membership.py:2531` 同一个 `moderation.enabled` 判断），
   查名字 / username / bio 是否命中规则；仍然受闸 2 限制
2. 违规走 `warn_threshold`（默认 3）累计，达阈值动作升级
3. 低置信度 `ban` 规则会发起真人质询（`challenge_timeout_seconds` 默认 600s），
   依赖已配好的 Turnstile / hCaptcha 与公网地址，否则不发起
4. 审核通知归入 `moderation` 自动删除类别

## 四、开启前后验收清单

开启前：

- [ ] 备份 `.env` + `data/` + `LOCAL_PATCHES.md`
- [ ] 已告知误删风险（上游测试非全绿，见 SKILL.md 缺陷 3）
- [ ] 建议先单群开、观察几天再推主群（开关是**全局**的，一开所有已授权群同时生效）

开启后：

- [ ] `docker compose restart bot`（不重启则运行中进程仍是旧 Settings）
- [ ] 容器内走 `RuntimeConfigManager` 读回 `True`，且 `mgr.revision` 已 +1
- [ ] `docker compose logs --since 2m bot | grep -ciE "traceback|ERROR"` = 0
- [ ] `/healthz` 200，容器 `Up (healthy)`
- [ ] **闸 2 状态明确**：`moderation_rules` 条数写进汇报，0 条就直说「空转」

## 五、回答模板

> 开关已开（revision N，运行时生效，healthy，0 报错）。但规则表 0 条，
> `evaluate()` 第一步就返回「审核通过 (无启用规则)」—— 现在零成本、零拦截。
> 要真拦还差两步：加规则（三种类型，成本差一个数量级）+ BotFather 开 bot-to-bot（只能你手动）。

别答「已经打开了」就结束 —— 那是把「开关状态」当成「防护能力」，
Owner 会以为广告已经有人管了。
