# Telegram Bot API 10.x 平台能力：Guest Mode / Bot-to-Bot / Ephemeral

官方原文于 2026-11-03 逐页读取核实。任何 TG 机器人项目都适用，不限于 SGB。

来源：

- <https://core.telegram.org/api/bots/guest-mode>（MTProto 侧完整定义）
- <https://core.telegram.org/bots/features>（Bot Features → Guest Bots / Ephemeral / Streaming）
- <https://core.telegram.org/bots/api-changelog>（版本与日期）

## Guest Mode（Bot API 10.0，2026-05-08）

官方一句话定义：

> Guest bots can be queried by username from any non-secret private chat, group and supergroup
> (except for groups/supergroups with content protection enabled), posting their results
> directly into the chat, even if they're not a member.

即：**不需要是群成员，被 @ 就能在群里以自己的身份发一条消息。**

### 硬约束

| 约束 | 值 |
|---|---|
| 一条消息里最多同时 @ | **3 个** guest bot |
| 每次调用能回几条 | **1 条** |
| 拿不拿得到聊天历史 | 拿不到 |
| 拿不拿得到成员列表 | 拿不到 |
| 之后还会不会收到该群消息 | **不会**，除非再次被 @ 或被回复 |
| 哪些聊天不支持 | secret chat；开了 content protection 的群/超级群 |

### Bot API 字段（10.0 新增）

- `User.supports_guest_queries` —— 该 bot 是否支持 guest 查询
- `Message.guest_bot_caller_user` / `Message.guest_bot_caller_chat` —— 谁召唤的
- `Message.guest_query_id` —— 回答案引
- `Update.guest_message` —— guest 查询专用 update
- `SentGuestMessage` 类 + `answerGuestQuery` 方法 —— 应答入口

### MTProto 侧（TL schema）

```
updateBotGuestChatQuery#cdd4093d flags:# query_id:long message:Message
    reference_messages:flags.0?Vector<Message> qts:int = Update;

messages.setBotGuestChatResult#b8f106e3 query_id:long
    result:InputBotInlineResult = InputBotInlineMessageID;
```

- bot 通过 `qts` 序列收到 `updateBotGuestChatQuery`，含 `query_id`、触发消息 `message`、
  以及被引用的上下文 `reference_messages`（如被回复的那条）。
- 应答用 `messages.setBotGuestChatResult`，结果格式与 inline query 的 `InputBotInlineResult` 相同。
- bot 自身开关：`user.bot_guestchat` 标志；常客列表用 `topPeerCategoryBotsGuestChat`
  （`contacts.getTopPeers` 的 `bots_guestchat` 位）。
- guest bot 发出的消息带 `message.guestchat_via_from`，指向召唤者。

### 和 Inline Mode 的区别（官方原话）

> Inline Mode is for fetching or accessing content (e.g. gifs, quotes, articles) via a bot
> to send it **yourself** in one tap, while Guest Mode allows a bot to actively participate
> and independently reply **as itself** in any chat based on the relevant context.

一句话：inline 是「帮你发」，guest 是「bot 自己说话」。

### 怎么开

BotFather → 该 bot 的 Mini App 设置 → 打开 **Guest Mode**。

## Bot-to-Bot Communication（同批 10.0）

- bot 之间可以互相看到对方在群里的消息并对话，前提是双方都开了
  **Bot-to-Bot Communication Mode**（BotFather 里设）。
- 官方明确警告：必须处理循环（全局与按发送者/接收者都要有最大交互深度或超时），
  「另一个 bot 立刻持续回复」时自己的 bot 仍要稳定，否则会被平台限流或处罚。
- **运维含义**：任何「审核其他 bot 消息」的功能（如 SGB 的 `bot_screening`）都以此为前提，
  没开这个开关时审核链路收不到消息、静默空转。

## Ephemeral Messages（群内私密回复）

- bot 可以在群里发**只有某个用户和 bot 可见**的消息，用于欢迎语、私聊式提示、个性化摘要。
- 用户点 inline 按钮时也可以就地弹出 ephemeral 回复，替换原消息视图，不影响其他人看到的内容。
- 支持回复与提前删除。
- 反过来的「ephemeral command」：用户的指令本身对其他成员和其他 bot 完全不可见。

## 其他同代能力（了解即可）

- **Streaming Replies**：私聊里先出 draft（`sendMessageDraft` / `sendRichMessageDraft`），
  生成完再发正式消息；用户可点 Stop，bot 收到 `MessageGenerationStopped` 可取消后端任务。
  空 draft 显示 `Thinking…`。
- **Rich Messages**：`sendRichMessage` + 一组 `RichBlock*`（表格、折叠、地图、幻灯片、
  代码块、数学公式等），是对 `sendRichMessage`/`<details>` 那套的官方结构化替代。
- **Private-chat Topics**：私聊也能开 forum topic，需在 BotFather 为该 bot 启用。

## 对群管项目的实际影响（SGB 实例）

1. **「禁止拉 bot 进群」拦不住 guest 广告**：广告机根本不在成员列表里，踢无可踢，
   只能做**消息级审核**。
2. SGB 的 `bot_screening` 就是为此写的（5 条干净消息换白名单），但它的门禁在
   `moderation.enabled`，不是 `bot_screening_enabled` —— 详见 SKILL.md 对应小节。
3. SGB 自身**没有实现 guest mode**（代码里没有 `answerGuestQuery`），它是常驻群管理员 bot，
   本来也不需要。
4. 想做「随叫随到、不入群」的助手型 bot，才该开 Guest Mode；做群管的不要开。
