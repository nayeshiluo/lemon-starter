"""SGB 模型角色生效值复验（容器内跑，只读）。

用途：换 provider / 下线供应商之后，证明「进程真正在用的」六个角色模型是什么，
并对 main / decision / moderation / compress / embed 各发一次真实请求。

⚠️ 不要用 load_settings() 单独判断：它只读 config.toml 的静态默认，会拿到
   早已废弃的 provider（实测拿到过 gemini-3-flash@127.0.0.1:8317 → 401 Invalid API key，
   被误报成「key 失效 / 配置坏了」）。必须走 runtime_config。

跑法（宿主）：
    chmod 644 /tmp/verify_model_roles.py
    docker cp /tmp/verify_model_roles.py <容器>:/tmp/verify_model_roles.py
    docker exec -u root <容器> chmod 644 /tmp/verify_model_roles.py   # 容器内非 root 读不了 cp 进来的 600 文件
    docker exec -u root -w /app <容器> python3 /tmp/verify_model_roles.py

或直接 stdin（无需 chmod 坑）：
    docker exec -i -w /app <容器> python3 - < /tmp/verify_model_roles.py
"""
import asyncio
import json
import sys

sys.path.insert(0, "/app")

from bot.config import load_settings                        # noqa: E402
from bot.db.engine import init_db                           # noqa: E402
from bot.services.llm import LLMService                     # noqa: E402
from bot.services.runtime_config import RuntimeConfigManager  # noqa: E402

ROLES = ("main", "vision", "decision", "moderation", "compress", "embed")


def desc(x):
    if x is None:
        return "None"
    fb = [getattr(f, "model", "?") for f in (getattr(x, "fallbacks", None) or [])]
    return f"{getattr(x, 'model', '?')} @ {getattr(x, 'api_base', '?')} fb={fb}"


async def main():
    settings = load_settings("/app/config.toml")
    engine, sf = await init_db(settings.database_url)
    rc = RuntimeConfigManager(session_factory=sf, settings=settings)
    cfg = await rc.initialize()

    # payload 层
    print("=== revision:", getattr(rc, "_revision", "?"))
    ms = cfg.models
    print("providers:", [p.name for p in ms.providers])
    for role in ROLES:
        r = getattr(ms, role, None)
        if r is None:
            print(f"  payload {role:11s}: <角色不存在>")
            continue
        print(
            f"  payload {role:11s}: provider={r.provider!r} model={r.model!r} "
            f"fb={[(f.provider, f.model) for f in r.fallbacks]}"
        )

    # 精确找残留厂商名（普通英文单词容易误命中，按 payload 路径列出）
    target = sys.argv[1] if len(sys.argv) > 1 else None
    if target:
        hits = []

        def walk(o, path=""):
            if isinstance(o, dict):
                for k, v in o.items():
                    walk(v, f"{path}.{k}")
            elif isinstance(o, list):
                for i, v in enumerate(o):
                    walk(v, f"{path}[{i}]")
            elif isinstance(o, str) and target.lower() in o.lower():
                hits.append((path, o[:70]))

        walk(cfg.model_dump())
        print(f"\n=== '{target}' 命中 {len(hits)} 处（看路径是否 {target}.provider / {target}.model）")
        for p, v in hits[:12]:
            print("   ", p, "->", v)

    # 生效层：apply_to_settings 是 RuntimeConfig 的方法，不是 Manager 的
    cfg.apply_to_settings(settings)
    b = settings.bot
    print("\n=== 生效模型（settings.bot.*）")
    for name in ("main_model", "vision_model", "decision_model",
                 "moderation_model", "compress_model", "embed_model"):
        print(f"  {name:18s} = {desc(getattr(b, name, None))}")

    llm = LLMService(
        b.main_model, b.decision_model, b.compress_model,
        moderation=b.moderation_model, vision=b.vision_model,
        embed=b.embed_model, max_context_tokens=b.max_context_tokens,
    )

    print("\n=== 真实调用")
    for label, fn in (
        ("main.generate", lambda: llm.generate("你是测试助手", "只回复两个字：通过")),
        ("decision", lambda: llm.decision("你是决策器", "只回复两个字：通过")),
        ("moderation", lambda: llm.moderation("你是审核器", "只回复两个字：通过")),
        ("compress", lambda: llm.compress("你是压缩器", "只回复两个字：通过")),
    ):
        try:
            out = await fn()
            print(f"  {label:16s} -> {(out or '')[:40]!r}")
        except Exception as e:                     # noqa: BLE001
            print(f"  {label:16s} -> EXC {type(e).__name__}: {str(e)[:130]}")

    try:
        vecs = await llm.embed(["测试文本"])
        print(f"  embed            -> dim={len(vecs[0]) if vecs and vecs[0] else 0}")
    except Exception as e:                         # noqa: BLE001
        print(f"  embed            -> EXC {type(e).__name__}: {str(e)[:130]}")

    await engine.dispose()


asyncio.run(main())
