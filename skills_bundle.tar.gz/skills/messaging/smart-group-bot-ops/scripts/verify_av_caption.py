#!/usr/bin/env python3
"""验证 SGB 的 AV 详情渲染：用户真正看到的那份 caption 里有没有可播入口。

为什么要单独测渲染层：`_send_av_detail()` 有封面时走 `answer_photo(caption=...)`，
`_build_av_detail_text()` 只在无封面降级路径才被调用。只测 service 层的
`detail.play_urls` 会得出「改好了」的错误结论。

判定口径（按优先级）：
  1. `watch_url` 有值 → caption 必须含「在线观看」（原站页面，零带宽，默认路径）
  2. 否则 `play_urls` 有值 → caption 必须含「播放直链」（/avp/ 签名转发，兜底路径）
  3. 两者都没有 → 不要求播放入口

用法（在部署目录下执行，脚本走 stdin 进容器，不落盘、不涉及属主）：

    sudo -n docker compose exec -T bot python - SSIS-001 ABP-123 \
        < ~/.hermes/skills/messaging/smart-group-bot-ops/scripts/verify_av_caption.py

退出码 0 = 全部合规；1 = 有番号缺可播入口、caption 超长、或两种入口同时出现。
"""

import asyncio
import sys

sys.path.insert(0, "/app")

from bot.config import load_settings  # noqa: E402
from bot.handlers.commands import (  # noqa: E402
    _build_av_detail_caption,
    _build_av_detail_text,
)
from bot.services.av_search import AVSearchService  # noqa: E402

CAPTION_LIMIT = 1024


def _mode(detail) -> str:
    if detail.watch_url:
        return "原站页面"
    if detail.play_urls:
        return "代理链接"
    return "无"


async def main(codes: list[str]) -> int:
    settings = load_settings()
    service = AVSearchService(settings)
    failed = False

    for code in codes:
        try:
            detail = await service.lookup_by_code(code)
        except Exception as exc:  # noqa: BLE001 - 探针要报出所有失败
            print(f"[FAIL] {code}: lookup 抛异常 {type(exc).__name__}: {exc}")
            failed = True
            continue

        if detail is None:
            print(f"[FAIL] {code}: lookup 返回 None")
            failed = True
            continue

        caption = _build_av_detail_caption(detail)
        text = _build_av_detail_text(detail)

        mode = _mode(detail)
        has_watch_key = "在线观看" in caption
        has_play_key = "播放直链" in caption
        # 两种入口互斥：同时出现说明展示层分支写错了
        exclusive_ok = not (has_watch_key and has_play_key)
        entry_ok = (
            (mode == "原站页面" and has_watch_key)
            or (mode == "代理链接" and has_play_key)
            or mode == "无"
        )
        length_ok = len(caption) < CAPTION_LIMIT
        # watch_url 与 url 相同时不该再出现「详情页」，否则同一链接渲染两遍
        dup_ok = not (detail.watch_url and detail.watch_url == detail.url and "详情页" in caption)
        ok = entry_ok and length_ok and exclusive_ok and dup_ok
        failed = failed or not ok

        print(f"{code}: source={detail.source} mode={mode} play_urls={list(detail.play_urls)}")
        print(f"  watch_url={detail.watch_url or '(empty)'}")
        print(
            f"  caption len={len(caption)} 在线观看={has_watch_key} 播放直链={has_play_key} "
            f"text 在线观看={'在线观看' in text} 合规={ok}"
        )
        if not ok:
            reasons = []
            if not entry_ok:
                reasons.append(f"缺可播入口（mode={mode}）")
            if not length_ok:
                reasons.append(f"caption {len(caption)} ≥ {CAPTION_LIMIT}")
            if not exclusive_ok:
                reasons.append("在线观看 与 播放直链 同时出现")
            if not dup_ok:
                reasons.append("watch_url == url 但「详情页」重复渲染")
            print(f"  原因: {'; '.join(reasons)}")
            print("  --- 用户实际看到的 caption ---")
            print(caption)

    return 1 if failed else 0


if __name__ == "__main__":
    args = sys.argv[1:] or ["SSIS-001"]
    raise SystemExit(asyncio.run(main(args)))
