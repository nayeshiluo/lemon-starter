#!/usr/bin/env python3
"""安全修改 SGB 运行时配置（runtime_config.payload）。

容器内执行，stdin 管道喂入：

    # 1) 先 dry-run 看 before/after
    sudo docker compose exec -T -e SGB_FIELD=moderation.enabled -e SGB_VALUE=true \
        bot python - < scripts/set_runtime_config.py

    # 2) 确认无误后加 SGB_APPLY=1 真写
    sudo docker compose exec -T -e SGB_FIELD=moderation.enabled -e SGB_VALUE=true \
        -e SGB_APPLY=1 bot python - < scripts/set_runtime_config.py

    # 3) 必须重启，否则运行中的进程仍是旧 Settings
    sudo docker compose restart bot && sleep 45

环境变量：
    SGB_FIELD   点号路径，如 moderation.enabled / raid_guard.join_threshold
    SGB_VALUE   新值；自动尝试 JSON 解析（true/false/数字/数组/对象），失败则当字符串
    SGB_APPLY   "1" 才真正落库；缺省 dry-run
    SGB_OWNER   updated_by，缺省 <YOUR_TELEGRAM_ID>

为什么不用 init_db()：它会跑整套 SQLite 迁移，对着正在服务的库跑有锁冲突风险。
RuntimeConfigManager 只读写 runtime_config / runtime_config_secrets 两张已存在的表。
"""
from __future__ import annotations

import asyncio
import json
import os
import sys

from sqlalchemy.ext.asyncio import async_sessionmaker, create_async_engine

from bot.config import load_settings
from bot.services.runtime_config import RuntimeConfigManager

FIELD = (os.environ.get("SGB_FIELD") or "").strip()
RAW_VALUE = os.environ.get("SGB_VALUE")
APPLY = os.environ.get("SGB_APPLY", "").strip() == "1"
OWNER = int(os.environ.get("SGB_OWNER") or <YOUR_TELEGRAM_ID>)


def parse_value(raw: str) -> object:
    """优先按 JSON 解析，让 true/false/数字/数组都正确落地。"""
    text = raw.strip()
    lowered = text.lower()
    if lowered in {"true", "false"}:
        return lowered == "true"
    if lowered in {"null", "none"}:
        return None
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        return raw  # 原样字符串，保留大小写与空格


def get_path(payload: dict, path: str):
    node = payload
    for part in path.split("."):
        if not isinstance(node, dict) or part not in node:
            raise KeyError(f"payload 里没有这个路径：{path}（断在 {part!r}）")
        node = node[part]
    return node


def set_path(payload: dict, path: str, value) -> None:
    parts = path.split(".")
    node = payload
    for part in parts[:-1]:
        nxt = node.get(part)
        if nxt is None:
            nxt = {}
            node[part] = nxt
        if not isinstance(nxt, dict):
            raise TypeError(f"{part!r} 不是 dict，无法继续下钻：{path}")
        node = nxt
    node[parts[-1]] = value


async def main() -> int:
    if not FIELD or RAW_VALUE is None:
        print("ERR: 必须设置 SGB_FIELD 与 SGB_VALUE", file=sys.stderr)
        return 2

    value = parse_value(RAW_VALUE)
    settings = load_settings()
    engine = create_async_engine(settings.database_url)
    factory = async_sessionmaker(engine, expire_on_commit=False, autoflush=False)

    try:
        mgr = RuntimeConfigManager(session_factory=factory, settings=settings)
        cfg = await mgr.initialize()

        try:
            before = get_path(cfg.storage_payload(), FIELD)
        except KeyError as exc:
            print(f"ERR: {exc}", file=sys.stderr)
            return 3

        print(f"revision      : {mgr.revision}")
        print(f"field         : {FIELD}")
        print(f"before        : {before!r}")
        print(f"after         : {value!r}")
        if before == value:
            print("NOOP          : 值已相同，无需改动")
            return 0

        if not APPLY:
            print("DRY-RUN       : 未写库。确认后加 -e SGB_APPLY=1 重跑")
            return 0

        payload = cfg.storage_payload()
        set_path(payload, FIELD, value)
        new_cfg = await mgr.save(
            payload, expected_revision=mgr.revision, updated_by=OWNER
        )
        applied = get_path(new_cfg.storage_payload(), FIELD)
        print(f"SAVED         : revision {mgr.revision}, {FIELD} = {applied!r}")
        print("NEXT          : docker compose restart bot（不重启进程仍是旧值）")
        return 0 if applied == value else 4
    finally:
        await engine.dispose()


if __name__ == "__main__":
    raise SystemExit(asyncio.run(main()))
