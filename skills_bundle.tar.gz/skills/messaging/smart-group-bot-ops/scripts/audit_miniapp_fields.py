#!/usr/bin/env python3
"""Mini App 字段一致性审计：找出「后端有 schema、前端没渲染」的半套补丁。

背景（2026-11 真实事故）：
  给 AV 检索加了 missav_base_url / missav_referer，只改了后端 pydantic schema，
  没改 bot/web/static/app.js 的 renderMedia()，结果 Mini App 里看不到，
  而且用户在页面上保存一次就会被 Pydantic 用默认值覆盖 —— 看起来像「功能没了」。
  这个脚本一条命令就能发现。

用法（在宿主或容器内均可，只要能读到 /app/bot 或部署目录）：
    python3 audit_miniapp_fields.py /app

退出码：0 = 全部对齐；1 = 有字段只在后端、未在前端渲染（就是半套补丁）。

只读，不修改任何文件。
"""

from __future__ import annotations

import re
import sys
from pathlib import Path

# 跳过这些 section：前端不负责渲染，或属于内部/敏感项
SKIP_PREFIX = (
    "providers.",
    "models.",
    "verification.",      # 密钥类走 secret_changes，前端用专门控件
)

FIELD_RE = re.compile(r"""field\(\s*["']([\w.]+)["']""")
TOGGLE_RE = re.compile(r"""toggle\(\s*["']([\w.]+)["']""")


def collect_frontend_fields(app_js: Path) -> set[str]:
    text = app_js.read_text(encoding="utf-8", errors="ignore")
    return set(FIELD_RE.findall(text)) | set(TOGGLE_RE.findall(text))


def collect_backend_fields(runtime_config: Path) -> dict[str, set[str]]:
    """解析 runtime_config.py 里各个 *SettingsConfig 的字段，返回 {section: {field}}。"""
    src = runtime_config.read_text(encoding="utf-8", errors="ignore")

    # 抓 class XxxSettingsConfig(StrictModel): ... 直到下一个顶层 class
    classes = re.findall(
        r"class\s+(\w*SettingsConfig)\s*\([^)]*\)\s*:(.*?)(?=\nclass\s|\Z)",
        src,
        re.DOTALL,
    )

    out: dict[str, set[str]] = {}
    for cls_name, body in classes:
        # AVCaptionConfig -> av ; StickerSettingsConfig -> stickers
        section = re.sub(r"(Settings)?Config$", "", cls_name)
        section = re.sub(r"([a-z0-9])([A-Z])", r"\1_\2", section).lower()
        # 常见单复数/缩写修正
        section = {
            "av": "av", "sticker": "stickers", "moderation": "moderation",
            "music": "music", "vision": "vision", "memory": "memory",
            "scheduled": "scheduled", "verification": "verification",
            "model": "models", "provider": "providers", "welcome": "welcome",
            "keyword": "keyword", "proactive": "proactive", "tts": "tts",
        }.get(section, section)

        fields = set(re.findall(r"^\s{4}(\w+)\s*:\s*\w+.*Field\(", body, re.MULTILINE))
        if fields:
            out.setdefault(section, set()).update(fields)
    return out


def main() -> int:
    root = Path(sys.argv[1] if len(sys.argv) > 1 else "/app")
    app_js = root / "bot" / "web" / "static" / "app.js"
    rc = root / "bot" / "services" / "runtime_config.py"

    for p, label in ((app_js, "app.js"), (rc, "runtime_config.py")):
        if not p.exists():
            print(f"找不到 {label}: {p}")
            return 1

    front = collect_frontend_fields(app_js)
    back = collect_backend_fields(rc)

    print(f"前端已渲染字段: {len(front)} 个")
    print(f"后端 section: {len(back)} 个")
    print()

    missing: list[tuple[str, str]] = []
    for section, fields in sorted(back.items()):
        if any(section.startswith(s) for s in SKIP_PREFIX):
            continue
        not_rendered = sorted(
            f for f in fields
            if f"{section}.{f}" not in front and not any(
                k.startswith(s) for k in (f"{section}.{f}",) for s in SKIP_PREFIX)
        )
        if not_rendered:
            missing.append((section, not_rendered))

    if not missing:
        print("✅ 全部后端字段都已在前端渲染")
        return 0

    print("⚠️  以下字段只在后端、前端未渲染（半套补丁）：")
    for section, fields in missing:
        print(f"\n  [{section}]")
        for f in fields:
            print(f"    - {section}.{f}")
            # 直接给出应该加进 app.js 的那一行
            print(f'      ${{field("{section}.{f}", "…显示名…", {{ type: "text", maxlength: 1000 }})}}')

    print()
    print("修法：把上面列出的项加进 bot/web/static/app.js 对应 section，")
    print("     并同步 bot/web/static/index.html 的 ?v= 版本号，然后重建镜像。")
    print("     注意：只加后端 schema 而不加前端，用户保存时会被 Pydantic 默认值覆盖。")
    return 1


if __name__ == "__main__":
    sys.exit(main())
