"""验收 MissAV 签名转发链路（/avp）。

在容器内跑（宿主机 /tmp 文件属主不对，别 docker cp）：

    sudo docker compose exec -T bot python - < scripts/verify_av_proxy.py

可用环境变量覆盖：AV_TEST_CODE（默认 SSIS-001）、AV_TEST_TTL（默认 7200）。

判定标准：
  1. proxy URL 非空（MINIAPP_PUBLIC_BASE_URL 已配、AV_PROXY_ENABLED 未关）
  2. playlist 200，且 body 首行是 #EXTM3U
  3. 重写后的子链接也指向本域名（说明 m3u8 内部 URL 已改写）
  4. 分片 200 且字节数 > 10000（Content-Type 应为 video/mp2t）
  5. caption 里含「播放直链」且长度 < 1024
"""

from __future__ import annotations

import asyncio
import os
import sys

sys.path.insert(0, "/app")

import aiohttp  # noqa: E402

from bot.config import load_settings  # noqa: E402
from bot.handlers.commands import _build_av_detail_caption  # noqa: E402
from bot.services.av_proxy import build_proxy_url  # noqa: E402
from bot.services.av_search import AVSearchService  # noqa: E402

CODE = os.environ.get("AV_TEST_CODE", "SSIS-001")
TTL = int(os.environ.get("AV_TEST_TTL", "7200"))


async def main() -> int:
    settings = load_settings()
    service = AVSearchService(settings)

    detail = await service.lookup_by_code(CODE)
    if detail is None:
        print(f"FAIL: lookup_by_code({CODE}) 返回 None")
        return 1

    print(f"source={detail.source} code={detail.code} play_urls={list(detail.play_urls)}")
    if not detail.play_urls:
        print("FAIL: 没有 play_urls，先查 _enrich_with_missav 是否生效")
        return 1

    raw = detail.play_urls.get("source1280") or next(iter(detail.play_urls.values()))
    proxied = build_proxy_url(raw, ttl=TTL)
    if not proxied:
        print("FAIL: build_proxy_url 返回空 —— 检查 MINIAPP_PUBLIC_BASE_URL / AV_PROXY_ENABLED")
        return 1
    print(f"proxy={proxied}")

    caption = _build_av_detail_caption(detail)
    ok_caption = "播放直链" in caption and len(caption) < 1024
    print(f"caption len={len(caption)} has_play={'播放直链' in caption}")

    async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=40)) as session:
        async with session.get(proxied) as resp:
            body = await resp.text(errors="replace")
            print(f"playlist status={resp.status} ctype={resp.headers.get('Content-Type')} bytes={len(body)}")
            if resp.status != 200 or not body.startswith("#EXTM3U"):
                print("FAIL: playlist 不是有效 m3u8（检查签名、过期、上游 Referer）")
                return 1

        lines = [ln.strip() for ln in body.splitlines() if ln.strip()]
        media = [ln for ln in lines if not ln.startswith("#")]
        rewritten = [ln for ln in media if "/avp/" in ln]
        print(f"media_lines={len(media)} rewritten={len(rewritten)}")
        if not rewritten:
            print("FAIL: m3u8 内部 URL 未改写，播放器会直连 CDN 并 403")
            return 1

        async with session.get(rewritten[0]) as seg:
            data = await seg.read()
            ctype = seg.headers.get("Content-Type", "")
            print(f"segment status={seg.status} bytes={len(data)} ctype={ctype}")
            ok_segment = seg.status == 200 and len(data) > 10000

    print()
    print("PASS" if (ok_caption and ok_segment) else "FAIL")
    if ok_caption and ok_segment:
        print("再跑一次 ffprobe 确认可解码（应输出 h264 / 1280 / 720）：")
        print(f'  ffprobe -v error -allowed_extensions ALL -select_streams v:0 \\')
        print(f'    -show_entries stream=codec_name,width,height -of default=nw=1 "{proxied}"')
        return 0
    return 1


if __name__ == "__main__":
    raise SystemExit(asyncio.run(main()))
