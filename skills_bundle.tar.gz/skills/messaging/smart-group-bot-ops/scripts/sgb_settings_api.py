#!/usr/bin/env python3
"""SGB 官方设置 API 客户端：GET/PUT /api/v1/settings（Telegram Mini App 鉴权）。

用法：
    python sgb_settings_api.py get --out cfg.json
    python sgb_settings_api.py put --config cfg.json --revision 10 --secrets secrets.json

secrets.json 形如 {"providers.command.api_key": "..."}，文件权限 600，用完删除。
BOT_TOKEN / SUPER_ADMIN_ID 从容器 env 读取，不落盘、不打印。
"""
from __future__ import annotations

import argparse
import hashlib
import hmac
import json
import os
import subprocess
import sys
import time
from urllib.parse import urlencode

import requests

BASE = os.environ.get("SGB_BASE", "http://127.0.0.1:8480")
CONTAINER = os.environ.get("SGB_CONTAINER", "smart-group-bot-bot-1")


def container_env() -> dict[str, str]:
    raw = subprocess.check_output(
        ["docker", "inspect", CONTAINER, "--format", "{{range .Config.Env}}{{println .}}{{end}}"],
        text=True,
    )
    out: dict[str, str] = {}
    for line in raw.splitlines():
        if "=" in line:
            k, v = line.split("=", 1)
            out[k] = v
    return out


_ENV = container_env()
_BOT_TOKEN = _ENV["BOT_TOKEN"]
_ADMIN_ID = int(_ENV["SUPER_ADMIN_ID"])


def init_data() -> str:
    """每次调用重新生成：auth_date 有新鲜度窗口，不能缓存。"""
    data = {
        "auth_date": str(int(time.time())),
        "query_id": "AAH" + str(int(time.time() * 1000)),
        "user": json.dumps(
            {"id": _ADMIN_ID, "first_name": "Admin", "username": "admin", "language_code": "zh"},
            separators=(",", ":"),
            ensure_ascii=False,
        ),
    }
    check = "\n".join(f"{k}={data[k]}" for k in sorted(data))
    secret = hmac.new(b"WebAppData", _BOT_TOKEN.encode(), hashlib.sha256).digest()
    data["hash"] = hmac.new(secret, check.encode(), hashlib.sha256).hexdigest()
    return urlencode(data)


def _headers() -> dict[str, str]:
    return {"Authorization": f"tma {init_data()}", "Content-Type": "application/json"}


def get_settings() -> dict:
    r = requests.get(f"{BASE}/api/v1/settings", headers=_headers(), timeout=30)
    r.raise_for_status()
    return r.json()


def put_settings(config: dict, revision: int, secrets: dict[str, str] | None = None) -> dict:
    body: dict = {"revision": revision, "config": config}
    if secrets:
        body["secret_changes"] = {
            path: {"action": "replace", "value": value} for path, value in secrets.items()
        }
    r = requests.put(f"{BASE}/api/v1/settings", headers=_headers(), json=body, timeout=60)
    try:
        payload = r.json()
    except Exception:
        payload = {"text": r.text[:400]}
    return {"status": r.status_code, "body": payload}


def main() -> int:
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    g = sub.add_parser("get")
    g.add_argument("--out")
    p = sub.add_parser("put")
    p.add_argument("--config", required=True)
    p.add_argument("--revision", type=int, required=True)
    p.add_argument("--secrets")
    args = ap.parse_args()

    if args.cmd == "get":
        doc = get_settings()
        cfg = doc["config"]
        print(f"revision={doc['revision']} sections={list(cfg)}")
        print(f"providers={[x['name'] for x in cfg['models']['providers']]}")
        print(f"configured_secrets={doc.get('configured_secrets')}")
        print(f"restart_required_paths={doc.get('restart_required_paths')}")
        if args.out:
            json.dump(cfg, open(args.out, "w"), ensure_ascii=False, indent=1)
            print(f"written {args.out}")
        return 0

    cfg = json.load(open(args.config))
    secrets = json.load(open(args.secrets)) if args.secrets else None
    res = put_settings(cfg, args.revision, secrets)
    print(f"PUT status={res['status']}")
    if res["status"] != 200:
        print(json.dumps(res["body"], ensure_ascii=False)[:800])
        return 1
    back = get_settings()
    print(f"readback revision={back['revision']}")
    for role in ("main", "vision", "decision", "moderation", "compress", "embed"):
        r = back["config"]["models"][role]
        print(role, r["provider"], r["model"], [(f["provider"], f["model"]) for f in r.get("fallbacks", [])])
    return 0


if __name__ == "__main__":
    sys.exit(main())
