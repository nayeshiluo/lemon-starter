# 本地补丁清单（升级时必看）

本目录**不是纯净上游代码**，升级前必须读完本文，否则会被覆盖并导致启动崩溃。

- 上游仓库：https://github.com/Hamster-Prime/Smart_Group_Bot
- 当前部署版本：`d02cb9b642101b7462c267e287723b6df364d2bb`（2026-11-04）
- 上一基线：`82c3703daba218b36255132c9bf51ebc444c6480`（2026-09-06）
- 现行镜像：`smart-group-bot-bot:20261106-v2`
- 回滚镜像：`smart-group-bot-bot:latest`（`94967c4bbc5c`）
- 补丁仓库工作副本：`~/.hermes/workspace/sgb-analysis-upstream`，分支 `local-full`

## 0. 升级血泪教训（2026-11-06）

第一次升级只按旧版本文档打了 3 处补丁，结果 `RuntimeConfig` 报
`av.missav_base_url / av.missav_referer Extra inputs are not permitted`，容器崩溃循环。

原因：**旧文档漏记了 AV/MissAV 一整套本地定制（5 个文件）**。数据库里的
runtime_config 已含这两个键，代码不认识就直接启动失败。

**规则：任何升级前先做部署目录与上游基线的全量 diff，不要相信补丁文档的完整性。**

```bash
sudo -n cp -a /home/ubuntu/smart-group-bot/bot /tmp/sgb-deployed
git -C ~/.hermes/workspace/sgb-analysis-upstream archive <基线commit> bot prompt | tar -x -C /tmp/sgb-base
diff -rq /tmp/sgb-base/bot /tmp/sgb-deployed | grep -v 'web/static'
```

## 1. 完整本地补丁（8 个文件）

| # | 文件 | 类型 | 内容 |
|---|---|---|---|
| 1 | `bot/handlers/notify_owner.py` | 新增 | owner 通知：被私聊、被拉群/踢出；同用户 20s 去重；排除 owner 本人 |
| 2 | `bot/__main__.py` | 修改 | import 加 `notify_owner`；`notify_owner.router` 必须在 `group.router` **之前** |
| 3 | `bot/services/av_proxy.py` | 新增 | 防盗链 HLS 签名转发路由 + `build_proxy_url` |
| 4 | `bot/services/av_search.py` | 修改 | MissAV 源：slug 代码归一化、Dean Edwards packed 播放列表解包 |
| 5 | `bot/handlers/commands.py` | 修改 | `missav` 站点标签、`_pick_best_play_url`（1280/842/多码率）、画质与在线观看字段 |
| 6 | `bot/config.py` | 修改 | 新增 `av_missav_base_url`、`av_missav_referer` |
| 7 | `bot/services/runtime_config.py` | 修改 | `AVSettingsConfig` 新增同名字段 + 三处映射（加载/应用到 settings/回写） |
| 8 | `bot/services/verify_web.py` | 修改 | `register_av_proxy_routes(app)` 挂到 Mini App aiohttp 应用 |

`bot/web/static` 在上游基线存在、部署目录不存在，属正常现象（由镜像提供，不是本地定制）。

### router 顺序原因

`group.router` 的 `on_group_message` 用 `F.text | F.caption | ...` 匹配所有文本消息，
函数内虽 `if not is_group(message): return`，但 aiogram 已判定该 update 被处理。
所以 `notify_owner.router` 必须排在 `group` 之前。

## 2. 数据库配置改动（不在源码里，升级不受影响，但必须保留）

| 项 | 值 | 原因 |
|---|---|---|
| `models.providers.gemini.api_base` | `https://generativelanguage.googleapis.com/v1beta` | 上游 `_resolve_request_api_base` 会拼 `/v1beta`，填 `.../v1beta/openai/` 会变成 `.../openai/v1beta` → embedding 404 |
| `moderation.enabled` | `false` | 第一阶段只开聊天，防误删 |
| `music.default_source` | `netease` | GD Studio 已下线 kuwo 源，返回 400 |
| `music.stable_sources` | 移除 `kuwo` | 同上 |
| `av.missav_base_url` | `https://www.missav888.net` | 与补丁 6/7 配套，**删掉会导致启动崩溃** |
| `av.missav_referer` | `https://missav.ws/` | 同上 |

## 3. 部署方式（现行）

- 部署目录只有 `bot/ prompt/ config.toml data/ docker-compose.yml`，**没有 Dockerfile**；
  镜像在上游完整源码目录构建，不必在部署目录 build。
- `docker-compose.yml` 用 `image:` 固定 tag，`network_mode: host`（必须，模型走本机 CPA `127.0.0.1:8317`）。
- 容器内 `/app/config.toml` 与 `/app/data` 为 bind mount，其余代码来自镜像。

## 4. 升级步骤（已验证）

```bash
cd ~/.hermes/workspace/sgb-analysis-upstream
git fetch origin && git checkout -B local-full <新上游commit>
# 重放第 1 节 8 个补丁（或 git merge 上一版 local-full 分支）
git -c user.name=Hermes -c user.email=hermes@localhost merge <上一版local-full> --no-edit

# 冒烟（不启动 bot）
docker build -t smart-group-bot-bot:<日期> .
docker run --rm --entrypoint python smart-group-bot-bot:<日期> -m compileall -q /app/bot
docker run --rm --entrypoint python -e CONFIG_MASTER_KEY=x smart-group-bot-bot:<日期> \
  -c "from bot.services.runtime_config import AVSettingsConfig; print([k for k in AVSettingsConfig.model_fields if 'missav' in k])"

# 切换（compose 里改 image tag 后）
cd /home/ubuntu/smart-group-bot && docker compose up -d --no-build --force-recreate
```

## 5. 升级后必须复核

1. `grep -n 'notify_owner\|include_router' bot/__main__.py` → notify_owner 行号小于 group
2. 容器 `RestartCount=0`、`Up (healthy)`、`/healthz` 200
3. 日志 `【出口】更新分发返回 | 状态=已转后台/等待终态` 出现（新版终态追踪生效）
4. 日志 ERROR / Traceback 计数为 0
5. Mini App 本地 `127.0.0.1:8480/settings` 与公网 `https://<YOUR_PRIVATE_DOMAIN>/settings` 均 200
6. 群消息 `pending batch finished` 正常出结果

## 6. 回滚（1 分钟）

```bash
cd /home/ubuntu/smart-group-bot
sed -i 's#image: smart-group-bot-bot:.*#image: smart-group-bot-bot#' docker-compose.yml
docker compose up -d --no-build --force-recreate
```

数据库备份：`~/.hermes/backups/smart-group-bot/pre-upgrade-<时间戳>/bot.db`（sqlite `.backup`，`quick_check=ok`）。
