"""本地 OpenAI 兼容 embedding 服务（fastembed CPU，仅监听 127.0.0.1）。

用途：供应商没有 embedding 时的独立替代，不依赖任何第三方 key。
依赖：pip install fastembed fastapi uvicorn
运行：uvicorn local-embed-service:app --host 127.0.0.1 --port 8491
模型：BAAI/bge-small-zh-v1.5 → 512 维；首次启动下载，建议 HF_ENDPOINT=https://hf-mirror.com
"""
from __future__ import annotations

import os
from typing import Any

from fastapi import FastAPI
from fastembed import TextEmbedding
from pydantic import BaseModel

MODEL = os.environ.get("EMBED_MODEL", "BAAI/bge-small-zh-v1.5")
_model = TextEmbedding(MODEL)
_dim = len(next(iter(_model.embed(["dimension probe"]))))

app = FastAPI()


class EmbedRequest(BaseModel):
    input: str | list[str]
    model: str | None = None


@app.get("/healthz")
def healthz() -> dict[str, Any]:
    return {"ok": True, "model": MODEL, "backend": "fastembed", "dimensions": _dim}


@app.post("/v1/embeddings")
def embeddings(req: EmbedRequest) -> dict[str, Any]:
    texts = [req.input] if isinstance(req.input, str) else list(req.input)
    vectors = [v.tolist() for v in _model.embed(texts)]
    return {
        "object": "list",
        "model": req.model or MODEL,
        "data": [{"object": "embedding", "index": i, "embedding": v} for i, v in enumerate(vectors)],
        "usage": {"prompt_tokens": sum(len(t) for t in texts), "total_tokens": sum(len(t) for t in texts)},
    }
