---
name: telegram-group-assistant
description: "配置 Hermes Telegram Bot 进群：观察群消息、@触发总结、原生可折叠富文本总结指令与规范。"
version: 1.1.0
author: Hermes Agent
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [telegram, group, bot, gateway, summarization, observe, mention, rich-messages]
---

# Telegram 群聊助手与智能总结规范

本技能涵盖 Hermes Telegram Bot 进群配置、群聊观察（observe 模式）、以及**权威级原生 HTML `<details><summary>` 可折叠群聊总结体系**。

## 1. 核心架构与技能树 (Summary Skill Tree)

```
├── 1. 数据采集与监听层 (Data Layer)
│   ├── 数据源：state.db (SQLite) 中的 messages 表（observed=1 或 role='user'）
│   └── 字段提取：platform_message_id, content, sender, timestamp
├── 2. 检索与解析层 (Retrieval & Filter)
│   ├── 双模检索切片：
│   │   ├── 条数维度：如 50、80条、120条（默认 80，范围 15~400）
│   │   └── 时间维度：如 30m（半小时）、1h（1小时）、2.5h、今日/今天（0点至今）、1d（1天）
│   └── 噪音清洗：过滤纯表情包、签到打卡、无实质内容的刷屏与指令调用
├── 3. 语义分析与聚合层 (Analysis & Clustering - 核心心法)
│   ├── 去流水账化：按核心议题深度重构脉络，严禁“张三说...李四回...”式的机械复述
│   ├── 主语视角：以事件、技术本质、方案、共识为主语
│   ├── 事实与观点分离：区分事实要点、重要互动与零散闲聊
│   └── 精准来源直链：所有核心事实末尾必须附带真实消息链接，绝不臆测
└── 4. 格式渲染与安全核验层 (Formatting & Verification)
    ├── 原生折叠卡片：每个议题板块及收尾均独立采用 <details><summary>Emoji 标题</summary>...</details>
    ├── 管道保障：网关启用 rich_messages: true 与 rich_messages_allow_cjk: true
    └── 安全红线：严禁包裹 Markdown 代码块（```），严禁 ||、>、**> 格式污染
```

---

## 2. 总结输出权威格式规范

### 结构规则
1. **议题板块（3~4 个精炼话题）**：
   每个话题独立使用 `<details><summary>` 包裹：
   ```html
   <details>
   <summary>{Emoji} {议题名称}</summary>

   • {高度浓缩的讨论事实、矛盾焦点与技术细节} [来源](https://t.me/c/{chat_id去-100}/{msg_id})
   • {衍生结论或方案细节} [来源](https://t.me/c/{chat_id去-100}/{msg_id})
   </details>
   ```
2. **收尾固定板块**：
   最后一个折叠块固定为：
   ```html
   <details>
   <summary>📋 结论与行动</summary>

   • 提炼讨论中的底层结论或共识。
   • 明确后续可落地的行动建议或避坑指南。
   </details>
   ```
3. **来源直链构造与校验**：
   - 私密超级群：`https://t.me/c/<群ID去-100前缀>/<platform_message_id>`
     示例：群 `-1004495899387` + 消息 `105480` → `[来源](https://t.me/c/4495899387/105480)`
   - 公开群/频道：`https://t.me/<群组用户名>/<platform_message_id>`
   - **严谨对齐**：来源链接中的 `platform_message_id` 必须严格通过真实数据库查询匹配该事实发言所在消息，严禁虚构或错位。当单条要点综合多条讨论时，可并列多个精准来源，如 `[来源1](...) [来源2](...)`。

---

## 3. 标准输出模板示例

<details>
<summary>🎬 影视服运营机制与流媒体负载分析</summary>

• 探讨了 Emby 公益服与公费服的运营现状与放号策略：群友指出公益服普遍面临“领号多、实际观影少”的情况，服务端采用 strm 直链由客户端本地解析播放，CPU 占用极低，主要瓶颈在磁盘缓存与网络 IO [来源](https://t.me/c/4495899387/105480) [来源](https://t.me/c/4495899387/105488) [来源](https://t.me/c/4495899387/105500) [来源](https://t.me/c/4495899387/105502)
• 交流了通过设置“观看保号”规则或转向公费运营以提升活跃度的可行性，分析了群组规模扩大对服务器并发负载的实际影响 [来源](https://t.me/c/4495899387/105492) [来源](https://t.me/c/4495899387/105493) [来源](https://t.me/c/4495899387/105497)
</details>

<details>
<summary>🤖 AI 助手调优与总结技能树规范探讨</summary>

• 围绕 Bot 总结功能的指令识别与格式输出进行实操交流，确认应通过固化标准技能（Skill）与严格格式拦截器来实现稳定输出，避免黑盒试错 [来源](https://t.me/c/4495899387/105503) [来源](https://t.me/c/4495899387/105517)
• 群友调侃了 AI 助手从千问到 Hermes 的长期调教历程与日常互动体验 [来源](https://t.me/c/4495899387/105507) [来源](https://t.me/c/4495899387/105514)
</details>

<details>
<summary>📋 结论与行动</summary>

• 明确 Emby 流媒体服务采用 strm 直链架构时核心关注存储读写与带宽，算力开销相对可控。
• 确立 Bot 总结规范需依托体系化 Skill 与原生 HTML 结构渲染，确保格式纯净与精准溯源。
</details>

---

## 4. 网关配置与底层保证

要确保 `<details><summary>` 在 Telegram 客户端 100% 渲染为原生折叠小三角，`~/.hermes/config.yaml` 必须包含：

```yaml
telegram:
  rich_messages: true
  rich_messages_allow_cjk: true
```

- `rich_messages: true`：开启 Bot API 10.1 Rich Message 管道。
- `rich_messages_allow_cjk: true`：禁止因为包含中文字符而自动降级为 Markdown 纯文本。

---

## 4.1 协议生态与折叠卡片差异（Bot API vs MTProto 人型）

在 Telegram 生态中，群聊总结的折叠呈现存在协议级差异：
1. **Bot API 10.1 官方机器人管道（柠檬款·首选推荐）**：
   - 依赖网关开启 `rich_messages: true` 与 `rich_messages_allow_cjk: true`；
   - 原生支持 `<details><summary>Emoji 标题</summary>\n\n内容...</details>`；
   - **客户端呈现**：极简纯净的**原生小三角折叠卡片**（无外部引用粗线/底色气泡，视觉效果最利落）。
2. **MTProto 个人号 / UserBot 协议（人型）**：
   - Telethon 原生 HTML 解释器不支持 `<details><summary>`（解析会剥离标签退化为纯文本）；
   - Telegram MTProto 协议对普通用户消息仅支持 `MessageEntityBlockquote(collapsed=True)`；
   - **客户端呈现**：带浅色背景与左侧引用竖线的**展开式引用气泡（Expandable Blockquote）**，需使用 `<blockquote expandable><b>Emoji 标题</b>\n\n内容...</blockquote>`。
3. **人型联动转交模式 (IPC Handover)**：
   - 若群内通过人型指令（如 `,sum`）触发总结，但希望呈现纯正的「柠檬款」小三角折叠卡片，可采用人型扫描聊天记录后通过 IPC 唤起 Hermes Bot，以官方 Bot 身份发送 `<details><summary>` 富文本消息。

---

## 5. 群聊指令弹窗精简与作用域隔离规范 (Group Menu Cleanliness)

### 背景与痛点
默认情况下，Telegram Bot 启动时会把全部（60+ 条）管理、调试与技能指令通过 `setMyCommands` 注册到群聊作用域。当群友输入 `/` 时，过长的指令弹窗不仅造成视觉污染，还会暴露管理员专用指令（如 `/model`, `/stop`, `/restart`, `/cron`）。

### 解决方案：Scope 级菜单隔离
Telegram Bot API 支持按作用域（Scope）独立注册指令菜单：
1. **群聊作用域 (`BotCommandScopeAllGroupChats` / `all_group_chats`)**：
   - 精选 6 项高频群聊指令（`/help`, `/model`, `/stop`, `/summary`, `/clear`, `/whoami`），并与 `group_user_allowed_commands` 白名单对齐；
   - 即时生效 API 调用：
     ```bash
     curl -s "https://api.telegram.org/bot$TOKEN/setMyCommands" \
       -H "Content-Type: application/json" \
       -d '{"commands":[{"command":"help","description":"查看帮助与使用说明"},{"command":"model","description":"切换当前使用的 AI 模型"},{"command":"stop","description":"终止群内谈话或当前任务"},{"command":"summary","description":"智能总结群内近期发言 (例: /summary 50条)"},{"command":"clear","description":"重置群聊上下文记忆"},{"command":"whoami","description":"查看我的身份与使用权限"}],"scope":{"type":"all_group_chats"}}'
     ```
2. **私聊作用域 (`BotCommandScopeAllPrivateChats`)**：
   - 维持全量管理员指令（`help`, `new`, `stop`, `model`, `status` 等），不影响管理员在私信中的全功能运维。
3. **底层保障**：
   - 在平台适配器（`plugins/platforms/telegram/adapter.py`）中，确保注册 `BotCommandScopeAllGroupChats` 时仅推送群聊允许指令列表，防止网关重连时被全量覆盖。
