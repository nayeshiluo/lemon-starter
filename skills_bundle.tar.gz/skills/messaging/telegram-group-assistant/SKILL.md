---
name: telegram-group-assistant
description: "配置 Hermes Telegram Bot 进群：观察群消息、@触发总结、原生可折叠富文本总结指令与规范。"
version: 1.1.0
author: Hermes Agent
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [telegram, group, bot, gateway, summarization, observe, mention, rich-messages]
---

# Telegram 群聊助手与智能总结规范

本技能涵盖 Hermes Telegram Bot 进群配置、群聊观察（observe 模式）、以及**权威级原生 HTML `<details><summary>` 可折叠群聊总结体系**。

## 1. 核心架构与技能树 (Summary Skill Tree)

```
├── 1. 数据采集与监听层 (Data Layer)
│   ├── 数据源：state.db (SQLite) 中的 messages 表（observed=1 或 role='user'）
│   └── 字段提取：platform_message_id, content, sender, timestamp
├── 2. 检索与解析层 (Retrieval & Filter)
│   ├── 双模检索切片：
│   │   ├── 条数维度：如 50、80条、120条（默认 80，范围 15~400）
│   │   └── 时间维度：如 30m（半小时）、1h（1小时）、2.5h、今日/今天（0点至今）、1d（1天）
│   └── 噪音清洗：过滤纯表情包、签到打卡、无实质内容的刷屏与指令调用
├── 3. 语义分析与聚合层 (Analysis & Clustering - 核心心法)
│   ├── 去流水账化：按核心议题深度重构脉络，严禁“张三说...李四回...”式的机械复述
│   ├── 主语视角：以事件、技术本质、方案、共识为主语
│   ├── 事实与观点分离：区分事实要点、重要互动与零散闲聊
│   └── 精准来源直链：所有核心事实末尾必须附带真实消息链接，绝不臆测
└── 4. 格式渲染与安全核验层 (Formatting & Verification)
    ├── 原生折叠卡片：每个议题板块及收尾均独立采用 <details><summary>Emoji 标题</summary>...</details>
    ├── 管道保障：网关启用 rich_messages: true 与 rich_messages_allow_cjk: true
    └── 安全红线：严禁包裹 Markdown 代码块（```），严禁 ||、>、**> 格式污染
```

---

## 2. 总结输出权威格式规范

### 结构规则
1. **议题板块（3~4 个精炼话题）**：
   每个话题独立使用 `<details><summary>` 包裹：
   ```html
   <details>
   <summary>{Emoji} {议题名称}</summary>

   • {高度浓缩的讨论事实、矛盾焦点与技术细节} [来源](https://t.me/c/{chat_id去-100}/{msg_id})
   • {衍生结论或方案细节} [来源](https://t.me/c/{chat_id去-100}/{msg_id})
   </details>
   ```
2. **收尾固定板块**：
   最后一个折叠块固定为：
   ```html
   <details>
   <summary>📋 结论与行动</summary>

   • 提炼讨论中的底层结论或共识。
   • 明确后续可落地的行动建议或避坑指南。
   </details>
   ```
3. **来源直链构造与校验**：
   - 私密超级群：`https://t.me/c/<群ID去-100前缀>/<platform_message_id>`
     示例：群 `-1004495899387` + 消息 `105480` → `[来源](https://t.me/c/4495899387/105480)`
   - 公开群/频道：`https://t.me/<群组用户名>/<platform_message_id>`
   - **严谨对齐**：来源链接中的 `platform_message_id` 必须严格通过真实数据库查询匹配该事实发言所在消息，严禁虚构或错位。当单条要点综合多条讨论时，可并列多个精准来源，如 `[来源1](...) [来源2](...)`。

---

## 3. 标准输出模板示例

<details>
<summary>🎬 影视服运营机制与流媒体负载分析</summary>

• 探讨了 Emby 公益服与公费服的运营现状与放号策略：群友指出公益服普遍面临“领号多、实际观影少”的情况，服务端采用 strm 直链由客户端本地解析播放，CPU 占用极低，主要瓶颈在磁盘缓存与网络 IO [来源](https://t.me/c/4495899387/105480) [来源](https://t.me/c/4495899387/105488) [来源](https://t.me/c/4495899387/105500) [来源](https://t.me/c/4495899387/105502)
• 交流了通过设置“观看保号”规则或转向公费运营以提升活跃度的可行性，分析了群组规模扩大对服务器并发负载的实际影响 [来源](https://t.me/c/4495899387/105492) [来源](https://t.me/c/4495899387/105493) [来源](https://t.me/c/4495899387/105497)
</details>

<details>
<summary>🤖 AI 助手调优与总结技能树规范探讨</summary>

• 围绕 Bot 总结功能的指令识别与格式输出进行实操交流，确认应通过固化标准技能（Skill）与严格格式拦截器来实现稳定输出，避免黑盒试错 [来源](https://t.me/c/4495899387/105503) [来源](https://t.me/c/4495899387/105517)
• 群友调侃了 AI 助手从千问到 Hermes 的长期调教历程与日常互动体验 [来源](https://t.me/c/4495899387/105507) [来源](https://t.me/c/4495899387/105514)
</details>

<details>
<summary>📋 结论与行动</summary>

• 明确 Emby 流媒体服务采用 strm 直链架构时核心关注存储读写与带宽，算力开销相对可控。
• 确立 Bot 总结规范需依托体系化 Skill 与原生 HTML 结构渲染，确保格式纯净与精准溯源。
</details>

---

## 4. 网关配置与底层保证

要确保 `<details><summary>` 在 Telegram 客户端 100% 渲染为原生折叠小三角，`~/.hermes/config.yaml` 必须包含：

```yaml
telegram:
  rich_messages: true
  rich_messages_allow_cjk: true
```

- `rich_messages: true`：开启 Bot API 10.1 Rich Message 管道。
- `rich_messages_allow_cjk: true`：禁止因为包含中文字符而自动降级为 Markdown 纯文本。

### 4.0 群聊独立模型分流与上下文降噪配置 (Channel Overrides & Observe Tuning)
当群聊中需要使用轻量极速模型（避免私聊的高强度思考/推理模型导致群聊响应慢、卡顿），且避免群聊被动吃进过多无意义闲聊上下文时，可在 `~/.hermes/config.yaml` 进行如下调优：

1. **群聊独立模型分流 (`channel_overrides`)**：
   ```yaml
   telegram:
     channel_overrides:
       "-1004495899387":
         model: deepseek-v4-flash
         provider: 日日新
   ```
2. **关闭被动闲聊监听（仅被 @/指令唤醒，不额外注入未提及上下文）**：
   ```yaml
   telegram:
     observe_unmentioned_group_messages: false
   ```
3. **上下文容量硬限制**：
   ```yaml
   session_reset:
     mode: token
     token_limit: 16000
   ```

### 4.0.1 群聊大上下文与第三方 Provider TPM 熔断排障 (RateLimit 429 TPM Exhausted)
- **典型故障特征**：
  - 群内 @Bot 或触发指令后无响应；
  - Gateway 日志 (`journalctl -u hermes-gateway -n 50`) 出现：`openai.RateLimitError: Error code: 429 - {'error': {'message': 'inference tpm exhausted', 'type': 'invalid_request_error', 'code': '429001'}}` 并在重试 3 次后抛出 `API call failed after 3 retries. Connection error.`；
  - 日志显示单次上下文过大（如 `msgs=31 tokens=~59,020`）。
- **根因分析**：
  - 某些第三方中转站或模型平台（如日日新 SenseNova 等）对普通账户设置了严格的 **每分钟 Token 吞吐（TPM）** 限额；
  - 群聊中如果累计闲聊未及时清空，单次带上数万 Token 直接击穿供应商 TPM 阈值导致调用失败。
- **排障与防护方案**：
  1. **模型分流选型**：群聊 `channel_overrides` 优先指定 TPM 极高、百万上下文的轻量极速模型（如本地 8317 CPA 双账号挂载的 `gemini-3.7-flash` 或 `gemini-3-flash`），避免将低 TPM 额度模型暴露给高频群聊。
  2. **群聊会话重置**：在群聊中输入 `/clear` 立即清空堆积的历史上下文。
  3. **网关自动重置限制**：在 `~/.hermes/config.yaml` 严格配置 `session_reset.token_limit: 16000`，防止群聊上下文无限膨胀。

---

## 4.1 协议生态与折叠卡片差异（Bot API vs MTProto 人型）

在 Telegram 生态中，群聊总结的折叠呈现存在协议级差异：
1. **Bot API 10.1 官方机器人管道（柠檬款·首选推荐）**：
   - 依赖网关开启 `rich_messages: true` 与 `rich_messages_allow_cjk: true`；
   - 原生支持 `<details><summary>Emoji 标题</summary>\n\n内容...</details>`；
   - **客户端呈现**：极简纯净的**原生小三角折叠卡片**（无外部引用粗线/底色气泡，视觉效果最利落）。
2. **MTProto 个人号 / UserBot 协议（人型）**：
   - Telethon 原生 HTML 解释器不支持 `<details><summary>`（解析会剥离标签退化为纯文本）；
   - Telegram MTProto 协议对普通用户消息仅支持 `MessageEntityBlockquote(collapsed=True)`；
   - **客户端呈现**：带浅色背景与左侧引用竖线的**展开式引用气泡（Expandable Blockquote）**，需使用 `<blockquote expandable><b>Emoji 标题</b>\n\n内容...</blockquote>`。
3. **人型联动转交模式 (IPC Handover)**：
   - 若群内通过人型指令（如 `,sum`）触发总结，但希望呈现纯正的「柠檬款」小三角折叠卡片，可采用人型扫描聊天记录后通过 IPC 唤起 Hermes Bot，以官方 Bot 身份发送 `<details><summary>` 富文本消息。
   - **反向委托机制**：当官方 Hermes Bot 未开启群聊被动全量监听（`observe_unmentioned_group_messages: false`）但收到群内总结指令（如 `总结 6h` / `/summary 6h`）时，Hermes 可通过向 `/home/ubuntu/lemon-userbot/ipc_cmd.json` 写入 `{"action": "summary_chat", "chat_id": <群ID>, "target": "6h"}`，直接委托后台常驻 UserBot（Telethon 客户端 `iter_messages`）抓取完整历史并生成总结，再由 Bot 转换为 `<details><summary>` 原生折叠卡片输出。

---

## 4.2 人型（UserBot）AI 随身问答 (,ai) 总结同款折叠卡片标准与排障规范

### 1. 全量折叠卡片（Expandable Blockquote）排版规范（对齐群聊总结质感）
在群聊中以真人号（UserBot）发出 AI 解答时，严禁普通杂乱的 Markdown 或大段生硬纯文本，必须全面对齐群聊总结的**全量原生可折叠卡片（`<blockquote expandable>`）标准**：
- **四大核心折叠板块**：
  1. `<blockquote expandable><b>💡 核心结论与本质</b>\n\n• 一句话直击本质与核心答案。\n• 关键定性/底层逻辑。</blockquote>`
  2. `<blockquote expandable><b>⚙️ 核心技术机制与链路对比</b>\n\n• 链路对比（如 <code>Client ➔ Edge ➔ 目标</code>）。\n• 技术原理解析，重点词 <b>加粗</b>，命令/配置用 <code>...</code>。</blockquote>`
  3. `<blockquote expandable><b>⚖️ 两种模式/利弊深度剖析</b>\n\n• 优势与收益。\n• 缺陷、风控点与注意事项。</blockquote>`
  4. `<blockquote expandable><b>📋 总结与实战建议</b>\n\n• 场景选型建议。\n• 落地操作要点。</blockquote>`
- **去机械化与废话**：严禁出现 `🤖 AI 解答：` 前缀，严禁“你好”、“作为AI”、“希望对你有帮助”等客套废话。

### 2. 避免 HTML 标签暴露（关键避坑）
- **根因**：Telethon 在编辑或发送带有 `<blockquote expandable>` 等 HTML 标签的消息时，若未显式指定 `parse_mode="html"`，Telegram 客户端会将其作为纯文本渲染，导致所有 HTML 标签源码直接暴露给用户。
- **规范实现**：
  - 剥离 LLM 输出可能附带的 ````html 或 ```` 标记；
  - 统一转换 `<details><summary>` 和普通 `<blockquote>` 为 `<blockquote expandable>`；
  - 调用 `await event.edit(answer, parse_mode="html", link_preview=False)`，并加入异常捕获 fallback。

### 3. UserBot 掉线排查与无交互环境重新授权流程
当 UserBot 的 Telethon Session 失效时，systemd 后台服务启动会因等待终端 stdin 输入手机号抛出 `EOFError` 并陷入 auto-restart 崩溃循环：
- **排查特征**：`systemctl status lemon-userbot` 处于 `activating (auto-restart)`，日志显示 `EOFError: EOF when reading a line`。
- **标准化重新授权流程**：
  1. 先停止服务避免冲突：`sudo systemctl stop lemon-userbot`
  2. 触发手机号验证码请求：`python3 request_code.py <手机号>`
  3. 接收并输入验证码（含 2FA）：`python3 verify_code.py <验证码> [2FA密码]`
  4. 启动并验证服务：`sudo systemctl start lemon-userbot && sudo systemctl status lemon-userbot`

---

## 5. 群聊指令弹窗精简与作用域隔离规范 (Group Menu Cleanliness)

### 背景与痛点
默认情况下，Telegram Bot 启动时会把全部（60+ 条）管理、调试与技能指令通过 `setMyCommands` 注册到群聊作用域。当群友输入 `/` 时，过长的指令弹窗不仅造成视觉污染，还会暴露管理员专用指令（如 `/model`, `/stop`, `/restart`, `/cron`）。

### 解决方案：Scope 级菜单隔离与 /clear 清理指令打通
1. **`/clear` 网关指令支持**：
   - 官方 Hermes 核心将 `/clear` 标记为终端专用 `cli_only`，在网关中输入会报 `Unknown command /clear`。
   - 需在 `hermes_cli/commands.py` 的 `COMMAND_REGISTRY` 中将 `/clear` 作为 `aliases=('reset', 'clear')` 挂载在 `/new` 之下，并在 `GATEWAY_KNOWN_COMMANDS` 中生效。
2. **Telegram Bot API Scope 级隔离**：
   - 群聊作用域 (`BotCommandScopeAllGroupChats` / `all_group_chats`) 精选 6 项高频群聊指令（`/help`, `/model`, `/stop`, `/summary`, `/clear`, `/whoami`），并与 `group_user_allowed_commands` 白名单对齐；
   - 即时生效 API 调用：
     ```bash
     curl -s "https://api.telegram.org/bot$TOKEN/setMyCommands" \
       -H "Content-Type: application/json" \
       -d '{"commands":[{"command":"help","description":"🌸 查看帮助与使用说明"},{"command":"model","description":"🤖 切换当前使用的 AI 模型"},{"command":"stop","description":"🛑 终止群内谈话或当前任务"},{"command":"summary","description":"📋 智能总结群内近期发言"},{"command":"clear","description":"🧹 清理重置群聊上下文记忆"},{"command":"whoami","description":"👤 查看我的身份与使用权限"}],"scope":{"type":"all_group_chats"}}'
     ```
3. **私聊作用域 (`BotCommandScopeAllPrivateChats`) 与别名去重避坑**：
   - 维持全量管理员指令（`help`, `new`, `stop`, `model`, `status` 等），不影响管理员在私信中的全功能运维。
   - **别名重复避坑 (Priority Duplication Pitfall)**：
     - **根因**：在 `config.yaml` 的 `command_menu.priority` 中若同时包含 `new` 和 `clear`，由于 `clear` 是 `new` 的别名，网关生成菜单时会将 pin 的别名独立展示并复用主命令文案，导致私聊菜单出现两条紧邻且文案完全相同的条目（`/new` 和 `/clear` 均为“开启新会话（全新会话 ID + 历史）”）。
     - **最佳实践**：私聊 `priority` 列表仅保留 `/new`（或二选一保留一个），无需重复配置别名 `clear`。即使菜单不展示 `/clear`，底层别名路由依然有效，手打 `/clear` 同样能正常清屏重置。群聊则继续使用单独的 `/clear`（“重置群聊上下文记忆”）。

---

## 7. 群聊模型分流、Fallback 粘滞陷阱与 TPM 限流排障 (Channel Overrides & Session Recovery)

### 1. 群聊长上下文与 TPM 429 报错排查
- **现象**：群聊内提问或总结时，Bot 无应答，日志抛出 `openai.RateLimitError: Error code: 429 - {'message': 'inference tpm exhausted'}` 并伴随重试失败。
- **根因**：群聊在持续闲聊后累积了数十条历史消息（50,000+ tokens），若此时群聊分流使用的模型 Provider（如日日新 SenseNova 等）单分钟 Token 配额（TPM）较小，单次请求会直接打爆 TPM 限流。
- **推荐选型**：群聊优先采用本地 8317 CPA 网关承载的 Gemini 主模型（`gemini-3.7-flash-high`），其百万级上下文容量与超高并发配额可完全杜绝 429 风险。

### 2. Session 级别 `fallback_active` 粘滞陷阱与修复
- **机制**：当群聊会话因某次异常触发自动降级（Fallback）后，底层会在 `state.db` 的 `sessions` 表中固化记录 `fallback_active: true` 及当时的降级 Provider。即使后续在 `config.yaml` 的 `channel_overrides` 中修正了模型，该群聊 Session 仍会因历史状态锁定在降级模型上。
- **恢复与重置方法**：
  1. **群内直接执行**：在群聊中发送 `/clear`，重置会话并重新按最新 `channel_overrides` 生成 Session。
  2. **底层数据库直接修复**：
     ```python
     import sqlite3, os
     conn = sqlite3.connect(os.path.expanduser('~/.hermes/state.db'))
     cur = conn.cursor()
     cur.execute('''
         UPDATE sessions 
         SET model = 'gemini-3.7-flash-high',
             model_config = '{"gateway_runtime": {"provider": "custom:gemini-proxy", "base_url": "http://localhost:8317/v1", "api_mode": "chat_completions", "fallback_active": false}}'
         WHERE session_key = 'agent:main:telegram:group:<群ID>'
     ''')
     conn.commit()
     ```

---

## 6. Telegram Bot 菜单汉化与分发跨机避坑 (Bot Menu Localization & Distribution)

### 痛点与机制解析
当将自用配置/环境打包分享给他人安装后，对方启动 Bot 可能会发现左下角 `/` 菜单栏全部变成了英文指令描述：
1. **源码解耦机制**：Hermes 在启动时通过 `plugins/platforms/telegram/adapter.py` 调用 Telegram Bot API `setMyCommands` 上报指令描述。若打包脚本仅同步了 `~/.hermes/` 用户数据（skills/config.yaml 等），而未包含本地修改过的 Python 核心源码（`hermes_cli/commands.py`），对方全新安装的官方原版 Python 包默认均为英文描述。
2. **Telegram 云端状态与缓存**：Bot 的指令列表是按 `BOT_TOKEN` 注册在 Telegram 云端服务器上的。对方换用新申请的 Token 且未主动下发过中文命令集时，将维持官方原版英文。

### 解决方案

#### 方案一：@BotFather 零代码覆盖（推荐）
在 Telegram 中向 `@BotFather` 发送 `/setcommands`，选择对应的 Bot，直接粘贴中文指令集（私聊已去重，仅保留 `/new`）：
```text
help - 查看帮助与使用说明
model - 切换当前使用的 AI 模型
new - 开启新会话 (全新会话 ID + 历史)
stop - 终止当前任务或后台进程
status - 查看系统与Token状态
summary - 智能总结近期发言 (例: /summary 50条)
whoami - 查看我的身份与权限
```

#### 方案二：基于真实配置的免重启即时云端推送 (`setMyCommands`)
通过调用 `hermes_cli.commands.telegram_menu_commands`，自动根据 `config.yaml` 的优先级与限制生成私聊完整菜单（60条），并结合群聊精简白名单（6条）免重启直接推送到 Telegram API：

1. **优先级调整命令（以移除私聊冗余 /clear 别名为例）**：
```bash
# 查询当前 priority 列表中 clear 的索引
hermes config get platforms.telegram.extra.command_menu.priority.2
# 精准移除指定索引的别名
hermes config unset platforms.telegram.extra.command_menu.priority.2
```

2. **已装机器一键免重启热推送脚本（直接读取 `~/.hermes/.env` + 动态计算）**：
```bash
python3 - << 'PY'
import sys, os, re, json, urllib.request
sys.path.insert(0, '/home/ubuntu/.hermes/hermes-agent')
from hermes_cli.commands import telegram_menu_commands, telegram_menu_max_commands

env = {}
for l in open(os.path.expanduser('~/.hermes/.env')):
    m = re.match(r'^([A-Z_]+)=(.*)$', l.strip())
    if m: env[m.group(1)] = m.group(2).strip('"\'')
tok = env.get('TELEGRAM_BOT_TOKEN')
if not tok: exit('❌ 未找到 TELEGRAM_BOT_TOKEN')

mx = telegram_menu_max_commands()
cmds, hid = telegram_menu_commands(mx)
priv = [{'command': n, 'description': d[:256]} for n, d in cmds]

# 群聊维持 6 条极简白名单
grp = [
    {'command': 'help', 'description': '🌸 查看帮助与使用说明'},
    {'command': 'model', 'description': '🤖 切换当前使用的 AI 模型'},
    {'command': 'stop', 'description': '🛑 终止群内谈话或当前任务'},
    {'command': 'summary', 'description': '📋 智能总结群内近期发言'},
    {'command': 'clear', 'description': '🧹 重置群聊上下文记忆'},
    {'command': 'whoami', 'description': '👤 查看我的身份与使用权限'},
]

for scope, payload, label in [
    ({'type': 'default'}, priv, 'default'),
    ({'type': 'all_private_chats'}, priv, 'all_private_chats'),
    ({'type': 'all_group_chats'}, grp, 'all_group_chats'),
]:
    req = urllib.request.Request(
        f"https://api.telegram.org/bot{tok}/setMyCommands",
        data=json.dumps({'commands': payload, 'scope': scope}).encode(),
        headers={'Content-Type': 'application/json'}
    )
    r = json.loads(urllib.request.urlopen(req, timeout=15).read())
    print(f"{label}: ok={r.get('ok')} ({len(payload)} 条)")
print('✅ Telegram Bot 作用域菜单已同步并云端生效！')
PY
```

2. **一键安装包（`install.sh`）自动化集成模式**：
在安装脚本获取到 `$CFG_TG_TOKEN` 之后，直接通过无外部第三方依赖的 `urllib.request` 自动完成云端同步，使新部署环境无需人工干预即可原生支持中文。

> **注意**：Telegram 客户端在收到更新后可能有短暂本地缓存，完全退出客户端并重新打开聊天框即可立即刷新为中文。

