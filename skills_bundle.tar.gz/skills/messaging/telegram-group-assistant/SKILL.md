---
name: telegram-group-assistant
description: "配置 Hermes Telegram Bot 进群：观察群消息、@触发总结、原生可折叠富文本总结指令与规范。"
version: 1.1.0
author: Hermes Agent
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [telegram, group, bot, gateway, summarization, observe, mention, rich-messages]
---

# Telegram 群聊助手与智能总结规范

本技能涵盖 Hermes Telegram Bot 进群配置、群聊观察（observe 模式）、以及**权威级原生 HTML `<details><summary>` 可折叠群聊总结体系**。

## 1. 核心架构与技能树 (Summary Skill Tree)

```
├── 1. 数据采集与监听层 (Data Layer)
│   ├── 数据源：state.db (SQLite) 中的 messages 表（observed=1 或 role='user'）
│   └── 字段提取：platform_message_id, content, sender, timestamp
├── 2. 检索与解析层 (Retrieval & Filter)
│   ├── 双模检索切片：
│   │   ├── 条数维度：如 50、80条、120条（默认 80，范围 15~400）
│   │   └── 时间维度：如 30m（半小时）、1h（1小时）、2.5h、今日/今天（0点至今）、1d（1天）
│   └── 噪音清洗：过滤纯表情包、签到打卡、无实质内容的刷屏与指令调用
├── 3. 语义分析与聚合层 (Analysis & Clustering - 核心心法)
│   ├── 去流水账化：按核心议题深度重构脉络，严禁“张三说...李四回...”式的机械复述
│   ├── 主语视角：以事件、技术本质、方案、共识为主语
│   ├── 事实与观点分离：区分事实要点、重要互动与零散闲聊
│   └── 精准来源直链：所有核心事实末尾必须附带真实消息链接，绝不臆测
└── 4. 格式渲染与安全核验层 (Formatting & Verification)
    ├── 原生折叠卡片：每个议题板块及收尾均独立采用 <details><summary>Emoji 标题</summary>...</details>
    ├── 管道保障：网关启用 rich_messages: true 与 rich_messages_allow_cjk: true
    └── 安全红线：严禁包裹 Markdown 代码块（```），严禁 ||、>、**> 格式污染
```

---

## 2. 总结输出权威格式规范

### 结构规则
1. **议题板块（3~4 个精炼话题）**：
   每个话题独立使用 `<details><summary>` 包裹：
   ```html
   <details>
   <summary>{Emoji} {议题名称}</summary>

   • {高度浓缩的讨论事实、矛盾焦点与技术细节} [来源](https://t.me/c/{chat_id去-100}/{msg_id})
   • {衍生结论或方案细节} [来源](https://t.me/c/{chat_id去-100}/{msg_id})
   </details>
   ```
2. **收尾固定板块**：
   最后一个折叠块固定为：
   ```html
   <details>
   <summary>📋 结论与行动</summary>

   • 提炼讨论中的底层结论或共识。
   • 明确后续可落地的行动建议或避坑指南。
   </details>
   ```
3. **来源直链构造与校验**：
   - 私密超级群：`https://t.me/c/<群ID去-100前缀>/<platform_message_id>`
     示例：群 `-1004495899387` + 消息 `105480` → `[来源](https://t.me/c/4495899387/105480)`
   - 公开群/频道：`https://t.me/<群组用户名>/<platform_message_id>`
   - **严谨对齐**：来源链接中的 `platform_message_id` 必须严格通过真实数据库查询匹配该事实发言所在消息，严禁虚构或错位。当单条要点综合多条讨论时，可并列多个精准来源，如 `[来源1](...) [来源2](...)`。

---

## 3. 标准输出模板示例

<details>
<summary>🎬 影视服运营机制与流媒体负载分析</summary>

• 探讨了 Emby 公益服与公费服的运营现状与放号策略：群友指出公益服普遍面临“领号多、实际观影少”的情况，服务端采用 strm 直链由客户端本地解析播放，CPU 占用极低，主要瓶颈在磁盘缓存与网络 IO [来源](https://t.me/c/4495899387/105480) [来源](https://t.me/c/4495899387/105488) [来源](https://t.me/c/4495899387/105500) [来源](https://t.me/c/4495899387/105502)
• 交流了通过设置“观看保号”规则或转向公费运营以提升活跃度的可行性，分析了群组规模扩大对服务器并发负载的实际影响 [来源](https://t.me/c/4495899387/105492) [来源](https://t.me/c/4495899387/105493) [来源](https://t.me/c/4495899387/105497)
</details>

<details>
<summary>🤖 AI 助手调优与总结技能树规范探讨</summary>

• 围绕 Bot 总结功能的指令识别与格式输出进行实操交流，确认应通过固化标准技能（Skill）与严格格式拦截器来实现稳定输出，避免黑盒试错 [来源](https://t.me/c/4495899387/105503) [来源](https://t.me/c/4495899387/105517)
• 群友调侃了 AI 助手从千问到 Hermes 的长期调教历程与日常互动体验 [来源](https://t.me/c/4495899387/105507) [来源](https://t.me/c/4495899387/105514)
</details>

<details>
<summary>📋 结论与行动</summary>

• 明确 Emby 流媒体服务采用 strm 直链架构时核心关注存储读写与带宽，算力开销相对可控。
• 确立 Bot 总结规范需依托体系化 Skill 与原生 HTML 结构渲染，确保格式纯净与精准溯源。
</details>

---

## 4. 网关配置与底层保证

要确保 `<details><summary>` 在 Telegram 客户端 100% 渲染为原生折叠小三角，`~/.hermes/config.yaml` 必须包含：

```yaml
telegram:
  rich_messages: true
  rich_messages_allow_cjk: true
```

- `rich_messages: true`：开启 Bot API 10.1 Rich Message 管道。
- `rich_messages_allow_cjk: true`：禁止因为包含中文字符而自动降级为 Markdown 纯文本。

### 4.0 群聊独立模型分流与上下文降噪配置 (Channel Overrides & Observe Tuning)
当群聊中需要使用轻量极速模型（避免私聊的高强度思考/推理模型导致群聊响应慢、卡顿），且避免群聊被动吃进过多无意义闲聊上下文时，可在 `~/.hermes/config.yaml` 进行如下调优：

1. **群聊独立模型分流 (`channel_overrides`)**：
   ```yaml
   telegram:
     channel_overrides:
       "-1004495899387":
         model: deepseek-v4-flash
         provider: 日日新
   ```
2. **关闭被动闲聊监听（仅被 @/指令唤醒，不额外注入未提及上下文）**：
   ```yaml
   telegram:
     observe_unmentioned_group_messages: false
   ```
3. **上下文容量硬限制**：
   ```yaml
   session_reset:
     mode: token
     token_limit: 16000
   ```

### 4.0.1 群聊大上下文与第三方 Provider TPM 熔断排障 (RateLimit 429 TPM Exhausted)
- **典型故障特征**：
  - 群内 @Bot 或触发指令后无响应；
  - Gateway 日志 (`journalctl -u hermes-gateway -n 50`) 出现：`openai.RateLimitError: Error code: 429 - {'error': {'message': 'inference tpm exhausted', 'type': 'invalid_request_error', 'code': '429001'}}` 并在重试 3 次后抛出 `API call failed after 3 retries. Connection error.`；
  - 日志显示单次上下文过大（如 `msgs=31 tokens=~59,020`）。
- **根因分析**：
  - 某些第三方中转站或模型平台（如日日新 SenseNova 等）对普通账户设置了严格的 **每分钟 Token 吞吐（TPM）** 限额；
  - 群聊中如果累计闲聊未及时清空，单次带上数万 Token 直接击穿供应商 TPM 阈值导致调用失败。
- **排障与防护方案**：
  1. **模型分流选型**：群聊 `channel_overrides` 优先指定 TPM 极高、百万上下文的轻量极速模型（如本地 8317 CPA 双账号挂载的 `gemini-3.7-flash` 或 `gemini-3-flash`），避免将低 TPM 额度模型暴露给高频群聊。
  2. **群聊会话重置**：在群聊中输入 `/clear` 立即清空堆积的历史上下文。
  3. **网关自动重置限制**：在 `~/.hermes/config.yaml` 严格配置 `session_reset.token_limit: 16000`，防止群聊上下文无限膨胀。

---

## 4.1 协议生态与折叠卡片差异（Bot API vs MTProto 人型）

在 Telegram 生态中，群聊总结的折叠呈现存在协议级差异：
1. **Bot API 10.1 官方机器人管道（人机群·官方小三角标准·柠檬款首选）**：
   - **呈现效果**：极简纯净的**原生小三角折叠卡片（`<details><summary>`）**（无外部引用粗竖线，无灰色底纹气泡，视觉效果最轻盈高级）；
   - **关键避坑（严重陷阱）**：
     - 普通 `sendMessage` 的 `parse_mode="HTML"` **根本不支持 `<details>` 标签**！若直接用标准 HTML 发送 `<details>`，Telegram Bot API 会抛出：`Bad Request: can't parse entities: Unsupported start tag "details"`；
     - **必须通过 Bot API 10.1 原生富文本管道发送**：
       ```python
       # 初始发送：
       await bot.do_api_request("sendRichMessage", api_kwargs={
           "chat_id": chat_id,
           "rich_message": {"markdown": "<details>\n<summary>Emoji 标题</summary>\n\n• 内容 [来源](url)\n</details>"}
       })
       # 消息编辑（支持更新占位流）：
       await bot.do_api_request("editMessageText", api_kwargs={
           "chat_id": chat_id,
           "message_id": msg_id,
           "rich_message": {"markdown": markdown_content}
       })
       ```
2. **MTProto 个人号 / UserBot 协议（人型）**：
   - Telethon 原生 HTML 解释器不支持 `<details><summary>`（解析会剥离标签退化为纯文本）；
   - Telegram MTProto 协议对普通用户消息仅支持 `MessageEntityBlockquote(collapsed=True)`；
   - **客户端呈现**：带浅灰色底色背景与左侧引用竖线的**展开式引用气泡（Expandable Blockquote）**，需使用 `<blockquote expandable><b>Emoji 标题</b>\n\n内容...</blockquote>`。
3. **人型联动转交模式 (IPC Handover)**：
   - 若群内通过人型指令（如 `,sum`）触发总结，但希望呈现纯正的「柠檬款」小三角折叠卡片，可采用人型扫描聊天记录后通过 IPC 唤起 Hermes Bot，以官方 Bot 身份发送 `<details><summary>` 富文本消息。
   - **反向委托机制**：当官方 Hermes Bot 未开启群聊被动全量监听（`observe_unmentioned_group_messages: false`）但收到群内总结指令（如 `总结 6h` / `/sum 6h`）时，Hermes 可通过向 `/home/ubuntu/lemon-userbot/ipc_cmd.json` 写入 `{"action": "summary_chat", "chat_id": <群ID>, "target": "6h"}`，直接委托后台常驻 UserBot（Telethon 客户端 `iter_messages`）抓取完整历史并生成总结，再由 Bot 转换为 `<details><summary>` 原生折叠卡片输出。

---

## 4.2 人型（UserBot）AI 随身问答 (,ai) 总结同款折叠卡片标准与排障规范

### 1. 全量折叠卡片（Expandable Blockquote）排版规范（对齐群聊总结质感）
在群聊中以真人号（UserBot）发出 AI 解答时，严禁普通杂乱的 Markdown 或大段生硬纯文本，必须全面对齐群聊总结的**全量原生可折叠卡片（`<blockquote expandable>`）标准**：
- **四大核心折叠板块**：
  1. `<blockquote expandable><b>💡 核心结论与本质</b>\n\n• 一句话直击本质与核心答案。\n• 关键定性/底层逻辑。</blockquote>`
  2. `<blockquote expandable><b>⚙️ 核心技术机制与链路对比</b>\n\n• 链路对比（如 <code>Client ➔ Edge ➔ 目标</code>）。\n• 技术原理解析，重点词 <b>加粗</b>，命令/配置用 <code>...</code>。</blockquote>`
  3. `<blockquote expandable><b>⚖️ 两种模式/利弊深度剖析</b>\n\n• 优势与收益。\n• 缺陷、风控点与注意事项。</blockquote>`
  4. `<blockquote expandable><b>📋 总结与实战建议</b>\n\n• 场景选型建议。\n• 落地操作要点。</blockquote>`
- **去机械化与废话**：严禁出现 `🤖 AI 解答：` 前缀，严禁“你好”、“作为AI”、“希望对你有帮助”等客套废话。

### 2. 避免 HTML 标签暴露（关键避坑）
- **根因**：Telethon 在编辑或发送带有 `<blockquote expandable>` 等 HTML 标签的消息时，若未显式指定 `parse_mode="html"`，Telegram 客户端会将其作为纯文本渲染，导致所有 HTML 标签源码直接暴露给用户。
- **规范实现**：
  - 剥离 LLM 输出可能附带的 ````html 或 ```` 标记；
  - 统一转换 `<details><summary>` 和普通 `<blockquote>` 为 `<blockquote expandable>`；
  - 调用 `await event.edit(answer, parse_mode="html", link_preview=False)`，并加入异常捕获 fallback。

### 3. UserBot 掉线排查与无交互环境重新授权流程
当 UserBot 的 Telethon Session 失效时，systemd 后台服务启动会因等待终端 stdin 输入手机号抛出 `EOFError` 并陷入 auto-restart 崩溃循环：
- **排查特征**：`systemctl status lemon-userbot` 处于 `activating (auto-restart)`，日志显示 `EOFError: EOF when reading a line`。
- **标准化重新授权流程**：
  1. 先停止服务避免冲突：`sudo systemctl stop lemon-userbot`
  2. 触发手机号验证码请求：`python3 request_code.py <手机号>`
  3. 接收并输入验证码（含 2FA）：`python3 verify_code.py <验证码> [2FA密码]`
  4. 启动并验证服务：`sudo systemctl start lemon-userbot && sudo systemctl status lemon-userbot`

---

## 5. 群聊指令弹窗精简与作用域隔离规范 (Group Menu Cleanliness)

### 背景与痛点
默认情况下，Telegram Bot 启动时会把全部（60+ 条）管理、调试与技能指令通过 `setMyCommands` 注册到群聊作用域。当群友输入 `/` 时，过长的指令弹窗不仅造成视觉污染，还会暴露管理员专用指令（如 `/model`, `/stop`, `/restart`, `/cron`）。

### 解决方案：Scope 级菜单隔离与 /clear 清理指令打通
1. **`/clear` 网关指令支持**：
   - 官方 Hermes 核心将 `/clear` 标记为终端专用 `cli_only`，在网关中输入会报 `Unknown command /clear`。
   - 需在 `hermes_cli/commands.py` 的 `COMMAND_REGISTRY` 中将 `/clear` 作为 `aliases=('reset', 'clear')` 挂载在 `/new` 之下，并在 `GATEWAY_KNOWN_COMMANDS` 中生效。
2. **Telegram Bot API Scope 级隔离**：
   - 群聊作用域 (`BotCommandScopeAllGroupChats` / `all_group_chats`) 精选 6 项高频群聊指令（`/help`, `/model`, `/stop`, `/summary`, `/clear`, `/whoami`），并与 `group_user_allowed_commands` 白名单对齐；
   - 即时生效 API 调用：
     ```bash
     curl -s "https://api.telegram.org/bot$TOKEN/setMyCommands" \
       -H "Content-Type: application/json" \
       -d '{"commands":[{"command":"help","description":"🌸 查看帮助与使用说明"},{"command":"model","description":"🤖 切换当前使用的 AI 模型"},{"command":"stop","description":"🛑 终止群内谈话或当前任务"},{"command":"summary","description":"📋 智能总结群内近期发言"},{"command":"clear","description":"🧹 清理重置群聊上下文记忆"},{"command":"whoami","description":"👤 查看我的身份与使用权限"}],"scope":{"type":"all_group_chats"}}'
     ```
3. **私聊作用域 (`BotCommandScopeAllPrivateChats`) 与别名去重避坑**：
   - 维持全量管理员指令（`help`, `new`, `stop`, `model`, `status` 等），不影响管理员在私信中的全功能运维。
   - **别名重复避坑 (Priority Duplication Pitfall)**：
     - **根因**：在 `config.yaml` 的 `command_menu.priority` 中若同时包含 `new` 和 `clear`，由于 `clear` 是 `new` 的别名，网关生成菜单时会将 pin 的别名独立展示并复用主命令文案，导致私聊菜单出现两条紧邻且文案完全相同的条目（`/new` 和 `/clear` 均为“开启新会话（全新会话 ID + 历史）”）。
     - **最佳实践**：私聊 `priority` 列表仅保留 `/new`（或二选一保留一个），无需重复配置别名 `clear`。即使菜单不展示 `/clear`，底层别名路由依然有效，手打 `/clear` 同样能正常清屏重置。群聊则继续使用单独的 `/clear`（“重置群聊上下文记忆”）。

---

## 7. 群聊模型分流、Fallback 粘滞陷阱与 TPM 限流排障 (Channel Overrides & Session Recovery)

### 1. 群聊长上下文与 TPM 429 报错排查
- **现象**：群聊内提问或总结时，Bot 无应答，日志抛出 `openai.RateLimitError: Error code: 429 - {'message': 'inference tpm exhausted'}` 并伴随重试失败。
- **根因**：群聊在持续闲聊后累积了数十条历史消息（50,000+ tokens），若此时群聊分流使用的模型 Provider（如日日新 SenseNova 等）单分钟 Token 配额（TPM）较小，单次请求会直接打爆 TPM 限流。
- **推荐选型**：群聊优先采用本地 8317 CPA 网关承载的 Gemini 主模型（`gemini-3.7-flash-high`），其百万级上下文容量与超高并发配额可完全杜绝 429 风险。

### 2. Session 级别 `fallback_active` 粘滞陷阱与修复
- **机制**：当群聊会话因某次异常触发自动降级（Fallback）后，底层会在 `state.db` 的 `sessions` 表中固化记录 `fallback_active: true` 及当时的降级 Provider。即使后续在 `config.yaml` 的 `channel_overrides` 中修正了模型，该群聊 Session 仍会因历史状态锁定在降级模型上。
- **恢复与重置方法**：
  1. **群内直接执行**：在群聊中发送 `/clear`，重置会话并重新按最新 `channel_overrides` 生成 Session。
  2. **底层数据库直接修复**：
     ```python
     import sqlite3, os
     conn = sqlite3.connect(os.path.expanduser('~/.hermes/state.db'))
     cur = conn.cursor()
     cur.execute('''
         UPDATE sessions 
         SET model = 'gemini-3.7-flash-high',
             model_config = '{"gateway_runtime": {"provider": "custom:gemini-proxy", "base_url": "http://localhost:8317/v1", "api_mode": "chat_completions", "fallback_active": false}}'
         WHERE session_key = 'agent:main:telegram:group:<群ID>'
     ''')
     conn.commit()
     ```

---

## 8. 群聊 Bot 权限矩阵、隐私模式与幽灵指令秒删规范 (Permissions, Privacy & Ghost Commands)

### 1. 隐私模式 (Privacy Mode) 避坑与配置
- **Telegram 默认状态**：Bot 默认处于 `Privacy Mode: ENABLED`。在此模式下，Bot 仅能接收：
  1. 以 `/` 开头的显式 Slash 指令；
  2. 显式 `@BotUsername` 的消息；
  3. 回复 Bot 自身消息的回复；
  4. 进群等系统服务消息。
- **场景冲突**：若要实现无斜杠指令（如回复消息发 `q` / `qs`、直接发 `ai <问题>`）或自动嗅探解析分享链接（如抖音 `v.douyin.com`、Bilibili `b23.tv`），开启隐私模式会导致 Bot 无法收到普通群友的文字更新。
- **必做操作**：在 `@BotFather` 中执行 `/setprivacy` → 选择对应 Bot → 点击 **`Disable`**（关闭隐私模式），确保 getMe 返回 `can_read_all_group_messages: True`。

### 2. 管理员权限 (Admin Rights) 与消息撤回限制
- **核心限制**：Telegram Bot API 规定普通群成员身份的 Bot 只能删除自身发出的消息，**绝对无法删除其他群友的消息**。
- **必要权限**：将 Bot 进群提升为管理员（Administrator），且必须显式勾选 **`Delete Messages`（删除消息 / `can_delete_messages`）** 权限。

### 3. 幽灵指令秒删交互规范 (Stealth / Ghost Trigger Pattern)
为避免群聊内产生大量 `q`、`qs`、`ai ...` 的指令噪音，提升版面质感：
1. **即时撤回**：Bot 监听到触发指令后的首个动作必须是调用 `delete_message(chat_id, message_id)` 秒删触发者消息（毫秒级执行，不阻塞后续生成逻辑）。
2. **Q 图贴纸呈现**：秒删群友的 `q` 之后，直接以被引用的消息为上下文向群内发送 512px WebP 贴纸，视觉上呈现“凭空变出贴纸”的无痕体验。
3. **AI 问答呈现**：秒删群友的 `ai <问题>` 之后，调用大模型生成回答，输出时可在首行附带提问者署名：
   > 💡 <b>{sender_name}</b> 提问：<i>{query_text}</i>
   
   接着展开富文本解答，既保留溯源又消除指令刷屏。
4. **长口令清理**：群友粘贴带有大段冗余广告词和防风控字符的分享链接（如抖音口令）时，Bot 识别后立即秒删原消息，并将解析后的纯净无水印原片直接发回群内。

### 4. 群聊白名单授权与敏感指令动态鉴权 (Group Whitelist & Role Auth)
- **群组白名单准入机制**：
  - 未经 Owner 授权的群聊完全保持静默（不监听、不触发、不响应任何业务指令），防止 Bot 被任意拉入外部陌生群滥用；
  - 维护动态白名单配置（如 `config.json`），仅允许 Owner 发送 `/auth`（在群内发自动绑定当前群，或私聊发 `/auth <群ID>`）激活群聊服务，支持 `/unauth` 和 `/groups` 动态运维。
- **敏感指令（`qs` 收录贴纸包）角色鉴权**：
  - 任何群友发送 `qs` 均会被**秒删指令**；
  - 随后调用 `await bot.get_chat_member(chat_id, user_id)` 动态核验权限：仅当发送者为群主（`creator`）、管理员（`administrator`）或 Owner 白名单用户时，才触发调用 `addStickerToSet` / `createNewStickerSet` 将贴纸入库并发出；普通群友发送后仅指令被删，群内完全无感。
- **私聊与群聊指令菜单隔离 (Scope Isolation)**：
  - 群聊菜单 (`BotCommandScopeAllGroupChats`)：呈现群聊功能全集（`/help`, `/summary`, `/ai`, `/q`, `/qs`）；
  - 私聊菜单 (`BotCommandScopeAllPrivateChats`)：普通用户仅显示唯一的 `/help` 指令，隐藏一切群聊与运维指令。

### 5. 海外云服务器短视频无水印解析实战 (ParseHub Engine)
- **风控痛点**：海外机房 IP（如 AWS 新加坡/美东等）直接请求抖音 Web API 会被字节安全网关直接拦截（`403 Blocked by ArgusSecurityPlugin Uifid Not Found`），或因缺失 `ttwid` / `a_bogus` 报错。
- **实测方案**：集成开源的 `parsehub` 引擎，其内置动态参数签名与移动端 SSR 降级解算机制，无需登录 Cookie 即可稳定从 `v.douyin.com` 短链解析出 1080P 无水印视频直链（`v3-dy-o.zjcdn.com`）及图集列表，配合 Telegram Bot 原生 `send_video` / `send_media_group` 完成秒级推流。

---

## 9. 群聊总结指令精简、中文免斜杠触发与方案 B 特权分级规范 (/sum, 总结 & Tiered Limits)

### 1. 指令短化与中文自然语言直接触发
群聊中输入 `/summary` 往往需要切换输入法且拼写冗长，针对社群体验进行双轨重构：
- **快捷 Slash 指令**：统一精简为 `/sum`（如 `/sum 50`、`/sum 2h`）；
- **免斜杠中文直接触发**：正则捕获 `^总结(?:[：:\s]+([\s\S]+))?$`，群友在输入框直接发 `总结`、`总结 80条`、`总结 30m` 即可毫秒级启动总结流水线；
- **双模参数归一化算法**：
  - 条数维度：匹配 `^(\d+)(?:条)?$`；
  - 时间维度：支持 `m/min/分/分钟/半小时`（转秒）、`h/hr/时/小时`（转秒）、`d/day/天`（转秒）。

### 2. 方案 B 特权分级模式 (Tiered Privileges)
防止普通群友高频大跨度请求打爆网关并发，同时保障管理人员的深度回溯需求：
- **普通群友**：单次总结上限锁定在 **500 条 / 24 小时**，超额输入时自动收敛至 500 条并附带 `（已达普通上限）` 提示；
- **特权用户（Owner、群主/管理员、VIP）**：条数上限完全放开至 **3,000 条**，时间跨度放开至 **7 天**；
- **Telegram 4096 字符防爆舱算法 (Auto-Chunking)**：
  超长总结如果一次性发出，会触发 Telegram API `MESSAGE_TOO_LONG` 异常。必须在输出前按 `</blockquote>\s*\n*` 或 `</details>` 边界智能切分为 ≤3800 字符的多段 Payload，首段编辑 `status_msg`，后续段落顺序追发，保证 100% 稳定投递。

### 3. 主动 VIP 赋权指令体系
Owner 可随时给群内活跃成员或协管人员派发特权：
- **快捷回复赋权**：在群内回复某人发言发送 `/addvip`，自动提取被回复者 ID 并落盘持久化；
- **显式 ID 赋权**：`/addvip <user_id>`（私聊或群聊均可）；
- **移除与审计**：`/delvip <user_id>`、`/viplist`。
- **权限继承**：被授予 VIP 的用户自动同步解锁 `qs` 专属贴纸入库权限与总结无限制特权。

### 4. 总结模板全量对齐人型群（楪祈同款·权威总结标准）
排版结构严格继承 UserBot 风格：
```html
📊 <b>【{群聊名称}】群聊智能总结（{范围描述} / 样本 {条数} 条）</b>

<blockquote expandable><b>🎬 {Emoji} {议题名称}</b>

• {以技术/事件本质重构的深度事实} <a href="https://t.me/c/{clean_id}/{msg_id}">来源</a>
• {核心方案、共识或分歧细节} <a href="https://t.me/c/{clean_id}/{msg_id}">来源</a>
</blockquote>

<blockquote expandable><b>📋 结论与行动</b>

• 提炼讨论中的底层结论或共识。
• 明确后续可落地的行动建议或避坑指南。
</blockquote>
```

### 5. 独立群聊助理 Bot 运行避坑实战 (All-in-One Bot Architecture & Pitfalls)
- **指令与菜单双轨兼容陷阱 (`~filters.COMMAND` 导致菜单指令静默丢失)**：
  在群聊菜单注册了 `/q`、`/qs`、`/ai`、`/sum`，若消息处理器使用了 `filters.ALL & ~filters.COMMAND` 且未注册独立的 `CommandHandler`，群友从 Telegram 菜单点击发送的带 `/` 指令会被框架直接判定为原生命令丢弃。必须统一正则匹配 `^[/,\.，。]?(q|qh|qs|ai|sum)` 并在处理器中采用 `filters.ALL`，确保斜杠与纯文本 100% 毫秒级捕获。
- **幽灵模式与防呆撤回交互 (Ghost Deletion & Ephemeral Tips)**：
  群内高频操作（`q` 贴纸、`qs` 贴纸入库、`sum` 总结）在收到 Update 瞬间（0.1 秒内）调用 `delete_message` 秒删用户触发指令。
  ⚠️ **例外：`ai <问题>` 与 `/ai` 的提问消息一律不删除**（爸爸明确纠正，覆盖本文档他处的旧描述）——提问需保留在群内，便于群友看清是谁在问什么；只有 `q` / `qs` / `sum` 一类纯触发指令才秒删。若群友直接发 `q` 未长按引用任何消息，切忌静默无响应，应发送临时引导并在 5 秒后自动调用 `delete()` 销毁，既提供清晰反馈，又绝不弄脏群聊版面。
- **Bot API 10.1 原生小三角与超长拆包 (Rich Message Delivery)**：
  调用 `do_api_request("sendRichMessage", ...)` 发送 `<details><summary>` 原生折叠小三角卡片。长文本按 `</details>\n\n` 安全切分（≤3800 字符），第一段编辑初始状态消息，后续分段顺序推入，杜绝 Telegram 4096 字符溢出。
- **贴纸包官方 file_id 绑定与 PTB 22.x 避坑**：
  PTB v21/v22 的 `create_new_sticker_set` 已移除 `sticker_format` 参数，格式必须放在 `InputSticker(..., format="static")` 内部；`qs` 入库成功后必须通过 `get_sticker_set(pack_name)` 获取 `stickers[-1].file_id` 发送，方可在客户端点击时直接弹窗呼出专属贴纸包。
- **抖音解析零服务器流量架构**：
  调用 `bot.send_video(chat_id, video=video_url)` 时直接传入视频 CDN URL，视频由 Telegram DC 直连字节跳动 CDN 拉取分发，服务器本身仅消耗 10~30KB 的元数据解析流量，彻底规避 AWS 100GB/月出网消耗。
- **群成员风控禁言与解禁 (/mute & /unmute)**：
  根据爸爸明确纠正规则，严格收敛为仅限：① 机器人拥有者 (Owner / 爸爸)、② 本群群主 (Creator / ChatMemberStatus.OWNER)、③ 拥有者指定特权人员 (/addvip)。普通群管理员无权使用禁言功能，违者拦截并提示；严禁禁言拥有者、群主与特权指定人员；支持双模指定（长按回复某人发言，或在参数中指定 `@username` / `user_id`）；参数支持自然时间解析（`10m`, `1小时`, `1d`, `永久`）；通过本地用户记录表解析 `@username` 映射关系。
- **全主流短视频跨平台解析与 0 服务器出网流量架构**：
  直接将 CDN 直链交付给 Telegram Bot API `send_video`，由 Telegram DC 直连拉取，AWS 服务器仅收发 10~30KB 接口元数据，完全不吃服务器出网流量。
  ⚠️ **关键交互红线：群友发送的视频链接消息 100% 完整保留在群聊中，绝不秒删！** Bot 解析出视频后以 `reply_to_message_id=msg.message_id` 引用回复的形式发出视频。
  ⚠️ **各平台解析路径并不统一，不能只靠 parsehub 一把梭**（实测修正，详见 `references/multi-platform-video-parsing.md`）：
  - **抖音**：`parsehub` 直连即可（已验证出 1080P 无水印直链，Telegram DC 直取）；
  - **TikTok**：必须 `yt-dlp --impersonate chrome`（依赖 `curl_cffi` 求解原生 JS 挑战并下载 mp4 字节流上传，秒级完成）；parsehub 与网页抓取均拿不到 `playAddr`；
  - **哔哩哔哩**：走 `curl_cffi` + `wbi` 签名 + 视频页 `X-BILI-SEC-TOKEN` 时序方案拿到直链，流式拉取到内存后以 `send_video(video=buf)` 秒级直传；
  - **YouTube**：机房 IP 下还需 JS 运行时与 cookies，优先级建议后置。
- **解析前必做的一步：先确认素材本身还存在**（本次最大时间浪费点）：
  分享链接（尤其 TikTok `/t/` 短链、B站 `b23.tv`）指向的内容经常已被删除，此时任何解析器都会失败，且报错与「代码写错」几乎无法区分。
  - TikTok 判定：请求 `https://www.tiktok.com/player/api/v1/items?item_ids=<id>`，返回 `{"code":"ok"}` = 存活，`{"code":"nil_core_data"}` = **视频不存在，别再改代码**（页面内 `webapp.video-detail.statusCode == 10204` 同理）；
  - 通用判定：用 yt-dlp 对一个已知长期存在的参照样本试跑一次，能成功即说明问题在链接/素材，而非环境或代码。
- **配套文件**：
  - `references/multi-platform-video-parsing.md` — 各平台实测路径矩阵、B站 wbi 签名与 cookie 时序、防盗链中继验证清单、明确的未打通项；
  - `templates/media-relay-server.py` — 可直接部署的「补 Referer 流式中继」（支持 Range/206、域名白名单、零第三方依赖、systemd 常驻）。
- **交互语义校准（爸爸逐条纠正过，务必遵循）**：
  - **`qs` 的语义是「把现成的贴图/图片收录进贴纸包」，不是「把发言转成贴图」**。回复现成 sticker / photo 时应**原样提取该素材**入库（`get_file(...).download_to_memory()` → PIL 缩放到 512px → 重编码 WEBP）；只有回复纯文字发言时才退化为调用 quote-api 渲染金句。
  - **`qs` 成功后要把本群贴纸包链接以卡片与 Inline 按钮发出来**（包含 `https://t.me/addstickers/<pack>` 及按钮 `[ 📦 查看/添加本群贴纸包 → ]`），这是爸爸明确要求的对齐截图交互，点击即可在 Telegram 原地弹窗添加整套群贴纸包。
  - **`ai` 提问消息不删**（见上文幽灵模式例外）；回复某条发言发 `/ai` 时，以被回复内容为提问上下文，并以「回复该消息」的形式输出解答卡片。
  - **总结的会话缓存只放内存、不落盘**：爸爸担心「一直录发言会把 Bot 变卡」。平时只在进程内维护 per-chat 的 `deque(maxlen=N)` 环形缓冲——零磁盘 I/O、零网络请求、零大模型调用，仅在 `/sum` / `总结` 触发瞬间切片送模型。**切勿做持续 SQLite 写入**。
  - **群独立贴图底色**：`/color` 按群持久化底色（`group_quote_colors: {"<chat_id>": "#hex"}`），仅限群主/管理员/特权用户修改，默认 `#000000`；内置预设须包含爸爸偏好的**猛男芭比粉 `#FF1493`** 与**魅惑梦幻紫 `#7B1FA2`**。
- **群专属贴纸包独立隔离与直链唤起**：
  每个群聊拥有专属的贴纸包（`g_{clean_chat_id}_by_{bot_username}`），标题为【群名 的名言集】；归属设为 Owner 避免群友未 `/start` 报错；追加成功后发送云端 `file_id`，群友点击贴纸可直接弹窗打开整套本群贴纸包。
- **回复发言发 /ai 针对性解答**：
  支持回复群内发言发送 `/ai`，自动提取原发言作为提问上下文，以回复形式输出官方原生 `<details><summary>` 小三角折叠解答卡片。


---

## 6. Telegram Bot 菜单汉化与分发跨机避坑 (Bot Menu Localization & Distribution)

### 痛点与机制解析
当将自用配置/环境打包分享给他人安装后，对方启动 Bot 可能会发现左下角 `/` 菜单栏全部变成了英文指令描述：
1. **源码解耦机制**：Hermes 在启动时通过 `plugins/platforms/telegram/adapter.py` 调用 Telegram Bot API `setMyCommands` 上报指令描述。若打包脚本仅同步了 `~/.hermes/` 用户数据（skills/config.yaml 等），而未包含本地修改过的 Python 核心源码（`hermes_cli/commands.py`），对方全新安装的官方原版 Python 包默认均为英文描述。
2. **Telegram 云端状态与缓存**：Bot 的指令列表是按 `BOT_TOKEN` 注册在 Telegram 云端服务器上的。对方换用新申请的 Token 且未主动下发过中文命令集时，将维持官方原版英文。

### 解决方案

#### 方案一：@BotFather 零代码覆盖（推荐）
在 Telegram 中向 `@BotFather` 发送 `/setcommands`，选择对应的 Bot，直接粘贴中文指令集（私聊已去重，仅保留 `/new`）：
```text
help - 查看帮助与使用说明
model - 切换当前使用的 AI 模型
new - 开启新会话 (全新会话 ID + 历史)
stop - 终止当前任务或后台进程
status - 查看系统与Token状态
summary - 智能总结近期发言 (例: /summary 50条)
whoami - 查看我的身份与权限
```

#### 方案二：基于真实配置的免重启即时云端推送 (`setMyCommands`)
通过调用 `hermes_cli.commands.telegram_menu_commands`，自动根据 `config.yaml` 的优先级与限制生成私聊完整菜单（60条），并结合群聊精简白名单（6条）免重启直接推送到 Telegram API：

1. **优先级调整命令（以移除私聊冗余 /clear 别名为例）**：
```bash
# 查询当前 priority 列表中 clear 的索引
hermes config get platforms.telegram.extra.command_menu.priority.2
# 精准移除指定索引的别名
hermes config unset platforms.telegram.extra.command_menu.priority.2
```

2. **已装机器一键免重启热推送脚本（直接读取 `~/.hermes/.env` + 动态计算）**：
```bash
python3 - << 'PY'
import sys, os, re, json, urllib.request
sys.path.insert(0, '/home/ubuntu/.hermes/hermes-agent')
from hermes_cli.commands import telegram_menu_commands, telegram_menu_max_commands

env = {}
for l in open(os.path.expanduser('~/.hermes/.env')):
    m = re.match(r'^([A-Z_]+)=(.*)$', l.strip())
    if m: env[m.group(1)] = m.group(2).strip('"\'')
tok = env.get('TELEGRAM_BOT_TOKEN')
if not tok: exit('❌ 未找到 TELEGRAM_BOT_TOKEN')

mx = telegram_menu_max_commands()
cmds, hid = telegram_menu_commands(mx)
priv = [{'command': n, 'description': d[:256]} for n, d in cmds]

# 群聊维持 6 条极简白名单
grp = [
    {'command': 'help', 'description': '🌸 查看帮助与使用说明'},
    {'command': 'model', 'description': '🤖 切换当前使用的 AI 模型'},
    {'command': 'stop', 'description': '🛑 终止群内谈话或当前任务'},
    {'command': 'summary', 'description': '📋 智能总结群内近期发言'},
    {'command': 'clear', 'description': '🧹 重置群聊上下文记忆'},
    {'command': 'whoami', 'description': '👤 查看我的身份与使用权限'},
]

for scope, payload, label in [
    ({'type': 'default'}, priv, 'default'),
    ({'type': 'all_private_chats'}, priv, 'all_private_chats'),
    ({'type': 'all_group_chats'}, grp, 'all_group_chats'),
]:
    req = urllib.request.Request(
        f"https://api.telegram.org/bot{tok}/setMyCommands",
        data=json.dumps({'commands': payload, 'scope': scope}).encode(),
        headers={'Content-Type': 'application/json'}
    )
    r = json.loads(urllib.request.urlopen(req, timeout=15).read())
    print(f"{label}: ok={r.get('ok')} ({len(payload)} 条)")
print('✅ Telegram Bot 作用域菜单已同步并云端生效！')
PY
```

2. **一键安装包（`install.sh`）自动化集成模式**：
在安装脚本获取到 `$CFG_TG_TOKEN` 之后，直接通过无外部第三方依赖的 `urllib.request` 自动完成云端同步，使新部署环境无需人工干预即可原生支持中文。

> **注意**：Telegram 客户端在收到更新后可能有短暂本地缓存，完全退出客户端并重新打开聊天框即可立即刷新为中文。

