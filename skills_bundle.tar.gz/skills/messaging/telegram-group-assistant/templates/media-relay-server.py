#!/usr/bin/env python3
"""
媒体 CDN 防盗链中继 (Referer-injecting streaming relay)

用途
----
Telegram 服务器执行 send_video(video=<url>) 时不携带 Referer，
而抖音/B站/TikTok 等 CDN 对无 Referer 请求直接 403。
本服务接收 ?u=<原始 CDN 直链>，补上正确的 Referer 后流式转发，
使 Telegram 能正常拉取。部署在低流量成本的 NAT 小鸡 / 低价 VPS 上，
主服务器只需传一个 URL 字符串，出网流量 ≈ 0。

特性
----
- 域名白名单：防止沦为开放代理
- 透传 Range：支持 206 / Content-Range（Telegram 分块下载必需）
- 纯流式：256KB 分块转发，不在内存或磁盘缓冲整个文件
- 零第三方依赖：仅用标准库，适合极简容器

部署
----
    # 1. 上传
    scp media-relay-server.py root@<HOST>:/opt/media_relay_server.py

    # 2. systemd 常驻（SSH 里 nohup & 会在会话退出时被杀，务必用 systemd）
    cat > /etc/systemd/system/media-relay.service <<'UNIT'
    [Unit]
    Description=Media CDN Referer Relay
    After=network.target

    [Service]
    Type=simple
    ExecStart=/usr/bin/python3 /opt/media_relay_server.py 8899
    Restart=always
    RestartSec=3

    [Install]
    WantedBy=multi-user.target
    UNIT

    systemctl daemon-reload && systemctl enable --now media-relay

    # 3. 验证（缺一不可）
    curl -o /dev/null -w "%{http_code} %{content_type}\n" -r 0-1048575 "http://<HOST>:8899/?u=<直链URL编码>"
    curl -o /dev/null -w "%{http_code} %{content_range}\n" -H "Range: bytes=1000-1999" "http://<HOST>:8899/?u=<直链URL编码>"
    # 期望：200 video/mp4 与 206 Content-Range: bytes 1000-1999/<total>

调用侧
------
    relayed = f"http://{RELAY_HOST}/?u=" + urllib.parse.quote(direct_url, safe="")
    await bot.send_video(chat_id=chat_id, video=relayed, caption=...)
"""
import sys
import urllib.parse
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

# ── 按被中继的平台增删白名单 ─────────────────────────────────────────────
ALLOWED_SUFFIXES = (
    # 哔哩哔哩
    "bilibili.com", "bilivideo.com", "bilivideo.cn", "akamaized.net",
    "hdslb.com", "biliapi.net", "szbdyd.com",
    # TikTok（如启用）
    "tiktokcdn.com", "tiktokcdn-us.com", "tiktokv.com", "tiktok.com",
)

# ── 按目标主机决定 Referer ──────────────────────────────────────────────
REFERER_RULES = (
    (("tiktok",), "https://www.tiktok.com/"),
    (("bilibili", "bilivideo", "hdslb", "akamaized"), "https://www.bilibili.com/"),
)
DEFAULT_REFERER = "https://www.bilibili.com/"

UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36")

BUF = 256 * 1024
PASS_THROUGH = ("Content-Type", "Content-Length", "Content-Range",
                "Accept-Ranges", "Last-Modified", "ETag")


def _referer_for(target: str) -> str:
    low = target.lower()
    for keys, ref in REFERER_RULES:
        if any(k in low for k in keys):
            return ref
    return DEFAULT_REFERER


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, fmt, *args):
        sys.stderr.write("[media-relay] " + (fmt % args) + "\n")
        sys.stderr.flush()

    def _fail(self, code: int, msg: str):
        body = msg.encode()
        self.send_response(code)
        self.send_header("Content-Type", "text/plain; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_HEAD(self):
        self._proxy(head_only=True)

    def do_GET(self):
        self._proxy(head_only=False)

    def _proxy(self, head_only=False):
        qs = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
        raw = (qs.get("u") or [None])[0]
        if not raw:
            return self._fail(400, "missing u param")
        target = urllib.parse.unquote(raw)

        host = urllib.parse.urlparse(target).hostname or ""
        if not any(host == s or host.endswith("." + s) for s in ALLOWED_SUFFIXES):
            return self._fail(403, "host not allowed: " + host)

        req = urllib.request.Request(target)
        req.add_header("Referer", _referer_for(target))
        req.add_header("User-Agent", UA)
        rng = self.headers.get("Range")
        if rng:
            req.add_header("Range", rng)          # ← 断点续传必需

        try:
            upstream = urllib.request.urlopen(req, timeout=45)
        except urllib.error.HTTPError as e:
            return self._fail(e.code, "upstream %s" % e.code)
        except Exception as e:
            return self._fail(502, "upstream error: %s" % e)

        self.send_response(upstream.status)
        for k in PASS_THROUGH:
            v = upstream.headers.get(k)
            if v:
                self.send_header(k, v)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        if head_only:
            upstream.close()
            return

        try:
            while True:
                chunk = upstream.read(BUF)        # ← 流式，不缓冲整文件
                if not chunk:
                    break
                self.wfile.write(chunk)
        except (BrokenPipeError, ConnectionResetError):
            pass
        finally:
            upstream.close()


if __name__ == "__main__":
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 8899
    sys.stderr.write(f"[media-relay] listening on 0.0.0.0:{port}\n")
    ThreadingHTTPServer(("0.0.0.0", port), Handler).serve_forever()
