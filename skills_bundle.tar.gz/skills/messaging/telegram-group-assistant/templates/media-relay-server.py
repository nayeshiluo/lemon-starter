#!/usr/bin/env python3
"""Archived legacy media relay: intentionally cannot start a listener.

This is not the deployed relay-only integration and is not a proxy server.
The previous implementation is retained in the restricted maintenance backup.
Do not restore it automatically or deploy it on AWS.
Any future replacement requires independent review of authenticated or
short-lived signed access, TLS, egress/redirect controls, quotas, concurrency,
cancellation, and compatibility with Telegram media fetches.
"""
import sys

ARCHIVED_EXIT_CODE = 2
ARCHIVED_NOTICE = (
    "FAILED: legacy media relay template is archived and cannot start. "
    "Use the verified deployed relay-only path. A replacement requires "
    "independent review and deployment approval. No listener was created.\n"
)


def main():
    sys.stderr.write(ARCHIVED_NOTICE)
    return ARCHIVED_EXIT_CODE


if __name__ == "__main__":
    raise SystemExit(main())
