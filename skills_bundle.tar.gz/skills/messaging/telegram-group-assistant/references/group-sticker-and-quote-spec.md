# Telegram 群聊 Q 图贴纸、头衔标签与贴纸包扩容全套规范 (群霸项目)

> ⚠️ 本文档已于最近一次会话按爸爸的口头纠正做了**反向修订**。以下两处旧写法已被明确推翻，谁再照旧写会直接被用户驳回：
> 1. 旧写法「必须为每一个发言者（包括普通群员）赋予兜底 `[群员]` 标签」→ **已废除**。爸爸原话：「没有标签的群成员你是不是都给他编辑群员了？为什么？没有就没有就行了，不要添加额外的」。
> 2. 旧写法「嵌套引用靠 `reply_target.reply_to_message` 存在与否判断」→ **已废弃**。Telegram Bot API 规定该字段永远不含下一层（见 §1.5）。

---

## 1. 核心交互红线（爸爸明确纠正）

1. **直接发送贴图（严禁带回复头）**：
   - 生成贴图后，调用 `bot.send_sticker(chat_id=chat.id, sticker=...)` 直接发送至群聊；
   - **绝对严禁传入 `reply_to_message_id`**！回复原消息会导致贴纸上方挂着巨大的引用框，破坏版面极简感；直接发送呈现真人随手甩表情包的清爽体验。
   - 同理，`qs` 成功后的贴纸包链接卡片也不挂 `reply_to_message_id`。

2. **局部划选引用回复 (TextQuote) 识别**：
   - 用户在客户端划选部分文字点击「Quote / 引用回复」发 `/q` 时，优先检测 `msg.quote`；
   - 提取 `msg.quote.text` 与 `msg.quote.entities`，**100% 只将选中的这一句话制作贴纸**，严禁粗暴抓取整段长发言；
   - 存在 `msg.quote.text` 时**忽略 `q N` 的条数合并**（局部引用天然只针对一句）。

3. **会员 Emoji 状态徽章 (Emoji Status) 提取**：
   - Telegram Premium 会员名字正后方的专属表情状态（不是消息正文里的 custom_emoji 表情！两者常被混淆，爸爸专门澄清过指的是**名字后面的状态图标**）不包含在普通 `User` 对象中；
   - 必须调用 `await bot.get_chat(user_id)` 提取 FullChat，获取 `emoji_status_custom_emoji_id` 与 `accent_color_id`；
   - 注入 `from.emoji_status` 与 `from.color_id`，quote-api 自动调取官方 `getCustomEmojiStickers` 渲染在名字后方；
   - 配合 10 分钟内存 TTL 缓存消除重复网络开销。
   - 消息正文里的行内会员表情是另一条链路：序列化 `MessageEntityCustomEmoji` 为 `{"type": "custom_emoji", "offset", "length", "custom_emoji_id"}` 放进 `msg.entities`。

4. **身份头衔彩色标签体系 (SenderTag — 有则显示，无则留空)**：
   - **当前正确矩阵（覆盖旧版"全员兜底"写法）**：

     | 身份 | 是否绘制 | 文字 | 颜色 |
     |---|---|---|---|
     | 群主 creator | ✅ | `custom_title` 否则 `群主` | 💜 `#b18fff`(dark) / `#8544c7`(light) |
     | 管理员 administrator | ✅ | `custom_title` 否则 `管理员` | 💚 `#5ec26f` / `#4fae5e` |
     | 普通成员**有**自定义头衔 | ✅ | 该头衔 | ⚪ `#aaaaaa` / `#8e8e93` |
     | 普通成员**无**任何头衔 | ❌ 不绘制 | — | — |

   - 取值顺序：`member.custom_title` → `reply_msg.sender_tag` → `reply_msg.author_signature`；三者皆空且非管理 → `tag_obj = None`，**直接不传 `senderTag` 字段**；
   - 底层 4888 quote-api 收到 `senderTag: null` 就留空不绘制，这是**正确行为**，不要去"补偿"它；
   - `Message.sender_tag` 是 Bot API 22.7+ 为超级群提供的字段，普通群聊里常为 None，只能当兜底不能当主源。

5. **二级引用气泡 (Nested Quote Reply) — Bot API 协议级陷阱**：
   - ⚠️ **Telegram Bot API 官方明文规定**：`reply_to_message` 字段里的 Message 对象**不会再包含它自己的 `reply_to_message`**（原文：*"the Message object in this field will not contain further reply_to_message fields even if it itself is a reply"*）。因此 `reply_target.reply_to_message` **永远是 None**，照它写等于二级引用功能永久失效。人型（Telethon/MTProto）能用 `get_reply_message()` 是因为协议层给了全量 RPC。
   - 正确做法是**自建内存回复链索引**：Bot 收到每条群消息时，把 `{"message_id", "user_id", "user_name", "text", "entities", "reply_to", "media_file_id"}` 记入 per-chat 字典，并用 `deque(maxlen=3000)` 维护有序 ID 链 + 溢出淘汰，防止字典无界膨胀。
   - 取上级引用的四级兜底顺序（逐级 fallback）：
     1. `reply_target.reply_to_message`（同聊天内有时仍有值，作为路径 A）；
     2. 内存索引 `get_message_reply_info(chat_id, reply_target.message_id)`（**主力路径**）；
     3. `reply_target.quote` + `reply_target.external_reply`（Telegram 7.0+ 的划选引用 / 外链引用）；
     4. 仅当指令以 `qh` 开头且以上全空时，用 `get_preceding_message()` 取群内紧邻上一条发言作为对话上下文兜底——**但这条兜底只能挂在 `qh` 上，不能挂在普通 `q` 上**，否则普通单人贴纸会被莫名塞进一句无关发言。
   - 详见 `references/qh-nested-reply-bot-api-limitation.md`。

6. **被引用的贴纸/图片必须"复原"，不是打 `[贴纸]` 占位符**：
   - 爸爸原话：「刚刚在使用的时候遇到了别人他的贴图，你直接识别成 `[贴纸]` 了，这点有办法改进吗？能直接复原出贴图本身吗？动图的话抓一个定格就可以了」。
   - 渲染时通过 `msg.media = {"url": "data:image/png;base64,..."}` 加 `msg.mediaType = "photo"` 注入气泡内媒体；`text` 置空即可，quote-api 仅凭 name + media 也能渲染出气泡。
   - **动图/视频贴纸定格帧的零依赖技巧**：`Sticker.thumbnail`（或旧名 `.thumb`）的 `file_id` 对**静态 WebP、Lottie `.tgs`、视频 `.webm` 三种贴纸都返回一张静态预览图**，直接拿它当定格首帧即可，**不需要 ffmpeg，也不需要 rlottie**。静态贴纸用 `sticker.file_id` 原图效果更好。
   - 同法可提取 `photo[-1].file_id`、`animation.thumbnail.file_id`、`video.thumbnail.file_id`。
   - `qh` 的上级引用气泡也带缩略图：给 `replyMessage` 加 `{"media": {"fileId": "<thumb_file_id>"}}`，4888 引擎会像 Telegram 客户端一样在引用框左侧画出小图（`index.js` 中通过 `telegram.getFileLink(fileId)` 加载）。
   - **必须配套零流量设计**（爸爸严控 AWS 100GB/月出网）：平时记录群消息只存 `file_id` 字符串（`resolve_media_file_id()`，纯字段读取、零下载），**只有真正渲染贴纸的那一刻才 `download_to_memory` 那一张图**。切勿在消息入库路径里下载图片，否则群里刷贴纸会在后台悄悄吃光流量。

7. **`q N` 多条合并 —— 方向语义（爸爸口述修正）**：
   - `q 3`（**正数 = 向下**）：以被回复消息为**起点**，顺延取后续 3 条（含自身），按时间正序；
   - `q -3`（**负数 = 向上**）：以被回复消息为**终点**，回溯取前 3 条（含自身），按时间正序；
   - 正则须含可负号：`(?:\s+(-?\d+))?$`；`int()` 后夹到 `±20`；
   - 任一方向取不满时向反方向补齐，避免贴纸条数缩水；
   - 合并时逐条重建 `from` / `senderTag` / `entities` / `media`，整理成 `messages[]` 一次送渲染，得到一张多气泡长贴纸；
   - 历史坑：v1 只解析了数字却始终只传单条 `msg_item`；v2 方向搞反成向上回溯。两个坑都踩过，别重蹈。

8. **多发言人多头像与同人连续合并单头像 (Multi-Speaker Avatars & Streak Grouping — 爸爸明确纠正)**：
   - 爸爸原话：「q3 这种指令是，如果是两个人发言，你只在最后一条发言里用了发言者的头像，前面的人的头像你没有弄进去。我需要你做到：有几个人发言，就有几个头像；如果是相同的人连续发言，你才可以只用一个头像，可以做到吗？」
   - **底层致命漏洞复盘**：
     - 在 4888 `quote-api`（`generate.js`）中，判定前后两条消息是否为同人连续发言是根据：
       `const nextSame = i < validMessages.length - 1 && validMessages[i + 1].chatId === validMessages[i].chatId;`
       `if (nextSame) validMessages[i].avatar = false;`
     - 若客户端传入的每条消息外层未携带 `chatId`（且未在 `normalizeMessage` 中将 `from.id` 补位给 `chatId`），则前后两条的 `chatId` 均为 `undefined`；
     - 在 JS 中 `undefined === undefined` 恒为 `true`！导致无论参与讨论的是几个完全不同的人，渲染引擎都将整组消息误判为【同一个人连续发言】，从而把除最后一条外的所有头像全部强行置为 `false` 剥离掉！
   - **双重加固方案（双端对齐）**：
     1. **`quote-api` 引擎级修复（`methods/generate.js`）**：
        - `normalizeMessage` 自动兜底：`if (!message.chatId && message.from && message.from.id) message.chatId = message.from.id;`；
        - 同人校验严格化：`const cid = validMessages[i].chatId || (validMessages[i].from && validMessages[i].from.id);`，必须双方均拥有有效且相同的 `cid`（`Boolean(cid && nextCid && String(cid) === String(nextCid))`）才视为同人，严禁 `undefined` 误判。
     2. **Bot 消息装配器修复（`handlers/messages.py`）**：
        - 构造 `msg_item` 以及 `q N` 链条中的每个 `c_item` 时，必须显式注入 `'chatId': target_user_id` / `'chatId': c_uid` 以及各自的高清头像 `photo`。
   - **渲染呈现规则（严格对齐 Telegram 客户端原生行为）**：
     - **不同发言者（A 发言 ➔ B 发言）**：两人均展示各自独立头像（`groupPos = 'single'`）；
     - **同一人连续发言（A 发言 ➔ A 再发言 ➔ B 发言）**：A 的第一条气泡角变直、隐藏头像；A 的最后一条展示头像；随后的 B 正常展示自身头像。

---

## 2. 贴纸包管理与自动多卷扩容

1. **贴纸删除指令 (`/qd` / `qd`)**：
   - 回复贴纸发 `/qd`，调用 `deleteStickerFromSet(sticker=file_id)`，从群名言集中彻底注销移除；
   - 严格权限白名单：仅限【管理、群主、拥有者、指定特权人员】使用（`can_use_qs()` 同源鉴权）；
   - 自动秒删指令并清理群内贴纸消息，发送 5 秒自毁确认卡片；
   - 错误分支：`BadRequest: Wrong sticker file specified` → 说明该贴纸不属于本 Bot 维护的包，向用户提示"不属于本群贴纸包，无法删除"。

2. **贴纸包 120 张上限与自动无缝扩容 (Vol.2, Vol.3...)**：
   - Telegram 官方限制单个静态贴纸包最多 120 张；
   - 每次 `qs` 入库前先 `get_sticker_set(name)` 查张数，`>= 120` 则 `continue` 到下一卷；
   - 卷命名：Vol.1 = `g_{clean_chat_id}_by_{bot_username}`，Vol.N = `g_{clean_chat_id}_{N}_by_{bot_username}`，标题 Vol.N = `{群名前16字} 名言集 Vol.{N}`；
   - `qs` 成功发出的链接与卡片按钮始终指向**当前正在写入的那一卷**，容量彻底无上限。

3. **贴纸包链接卡片与 Inline 按钮**：
   - `qs` 成功后，除了直接发送贴纸外，发送带有专属链接与 Inline 按钮的消息：
     ```text
     ✅ 已收录进【本群名称】名言集！

     🔗 贴纸包链接：
     https://t.me/addstickers/g_<群ID>_by_<bot_username>
     ```
     配挂内联按钮 `[ 📦 查看/添加本群贴纸包 → ]`，点击即可在客户端原地弹窗添加整套贴纸包。

4. **群专属贴纸包命名与归属**：
   - 每个群独立贴纸包 `g_{clean_chat_id}_by_{bot_username}`（`clean_chat_id` = 去掉 `-100` 前缀的绝对 ID），标题 `【群名】的名言集`；
   - `create_new_sticker_set(user_id=...)` 的 `user_id` 统一填 **Owner 的 ID**，这样群内任何管理员都能建包/追加，群友无需先私聊 `/start`；
   - PTB 22.x 已移除 `create_new_sticker_set` 的 `sticker_format` 关键字参数，格式必须写在 `InputSticker(..., format="static")` 内部，否则 `TypeError`；
   - 入库成功后 `get_sticker_set(pack_name).stickers[-1].file_id` 拿到云端 file_id 再 `send_sticker`，群友点击贴纸即可原地弹窗呼出整套包。
