# Telegram 音乐点播服务开发与排障规范 (@Music163bot 同款)

本规范总结了在 Telegram 群聊机器人中实现高保真网易云/全网音乐点播与解析服务的完整架构、防踩坑排障与性能优化经验。

---

## 1. 架构全景

```
用户指令 (/music 歌名 / 歌曲ID / 163分享链接)
   │
   ├─► 1. 缓存快查：检查本地 SQLite (music_cache.db) 是否有 Telegram 官方 tg_file_id
   │         └── 有：直接以 audio=file_id 投递，0 秒秒发，0 流量，0 转码！
   │
   ├─► 2. 识别输入：
   │         ├── 纯数字 / 网易云分享链接 ──► 直接解析 song_id，跳过搜索菜单
   │         └── 歌名/歌手 ──► 调用搜索 API 提取 Top 5，直接发送带 [1][2][3][4][5] 内联按钮卡片
   │
   ├─► 3. 用户点击数字按钮 (music_play:{session_key}:{idx})：
   │         ├── 方案 A0（顶级优先）：网易云官方 Eapi 客户端接口 (携带黑胶 VIP MUSIC_U Cookie)
   │         │       └── 0.9 秒极速获取官方 320k 极高音质 MP3 原声直链！
   │         ├── 方案 A1：网易云公开增强播放接口 (非 VIP 免费曲目直链)
   │         └── 方案 B（免 VIP 兜底）：B站 Hi-Res 专线中继 + FFmpeg 原生转码
   │
   ├─► 4. 元数据注入：通过 mutagen 为 MP3 写入 TIT2(歌名)、TPE1(歌手)、TALB(专辑) 与 APIC(封面)
   │
   └─► 5. 投递并缓存：通过 bot.send_audio 发送，成功后将返回的 tg_file_id 写入本地 SQLite 库供下次瞬间回放。
```

---

## 2. 核心避坑指南 (Critical Pitfalls)

### 坑 1：Message.reply_text() 的 `quote=True` 报错
- **现象**：群友发 `/music` 或任何指令后，Bot 完全死寂无反应，后台抛出：
  `TypeError: Message.reply_text() got an unexpected keyword argument 'quote'`
- **根因**：在 `python-telegram-bot` v21.x+ 中，`reply_text` 默认就会引用被回复消息，早已废弃 `quote` 参数。
- **规范**：直接调用 `await msg.reply_text("...")`，严禁传 `quote=True`。

### 坑 2：大音频文件上传超时 `❌ 音乐文件发送失败：Timed out`
- **现象**：歌曲转码完成（8MB~15MB），但在调用 `bot.send_audio` 上传至 Telegram 官方数据中心时，等待数秒后抛出 `telegram.error.TimedOut: Timed out`。
- **根因**：`ApplicationBuilder().build()` 默认使用的 `HTTPXRequest` 对写操作的超时阈值非常苛刻（默认 5~10 秒），上传大文件一旦网络轻微波动便直接中断。
- **规范**：在 `bot.py` 构建 Application 时必须自定义 `HTTPXRequest`：
  ```python
  from telegram.request import HTTPXRequest

  custom_request = HTTPXRequest(
      connection_pool_size=16,
      read_timeout=60.0,
      write_timeout=60.0,
      connect_timeout=20.0,
      pool_timeout=20.0,
      media_write_timeout=180.0  # 为音频/视频媒体文件上传开辟 3 分钟宽容度
  )
  app = ApplicationBuilder().token(BOT_TOKEN).request(custom_request)...build()
  ```

### 坑 3：VIP 会员歌曲“听到一半就没了 / 只有几十秒”
- **现象**：群友反馈某首歌听着听着，唱到一半突然中断（如只有 40 秒或 1 分钟）。
- **根因分析**：
  1. **网易云官方试听截断**：未带 VIP 凭证调用官方接口时，网易云返回的是 `freeTrialInfo`（30~60秒高潮试听流），并非全曲；
  2. **B站海外 CDN 长连接早泄 (`Stream ends prematurely`)**：通过中继下载大视频时，Akamai CDN 会在传输中途断开连接，FFmpeg 退出码为 0 但只转出了前一半音频。
- **根治方案**：
  1. **配置网易云黑胶 VIP `MUSIC_U`**：这是最根本、音质最高（官方 320k/无损）的方案；
  2. **免 VIP 兜底时长过滤**：在视频源筛选时，**必须严格限制时长在 2分45秒 ~ 7分30秒**，并过滤包含 `伴奏`、`教学`、`教程`、`钢琴谱`、`鼓谱`、`光遇` 等干扰项；
  3. **FFmpeg 直接带 Header 请求**：
     ```python
     hdr_str = "Referer: https://www.bilibili.com/\r\nUser-Agent: Mozilla/5.0 ...\r\n"
     cmd = ["ffmpeg", "-y", "-threads", "2", "-headers", hdr_str, "-i", direct_cdn_url, "-vn", "-c:a", "libmp3lame", "-b:a", "192k", "-preset", "ultrafast", out_path]
     ```

### 坑 4：体感慢的交互瓶颈消除
- **旧做法**：收到指令先发一条“正在检索”，收到 API 结果再 `edit_message_text` 换成菜单。两次 Telegram 交互直接消耗 2~3 秒。
- **优化**：曲库 API 查询耗时极短（<0.3秒），直接静默完成搜索，**单次请求直接发出带 `[1][2][3][4][5]` 按钮的完整菜单**，整体体感提升 70%！

---

## 3. 网易云官方 Eapi 核心加解密与 VIP 认证实现

网易云官方移动端使用的是 AES-128-ECB 加密的 Eapi 协议（固定密钥 `b"e82ckenh8dichen8"`）：

```python
import json, hashlib
from Cryptodome.Cipher import AES

def _pkcs7_padding(data: bytes) -> bytes:
    pad_len = 16 - (len(data) % 16)
    return data + bytes([pad_len] * pad_len)

def eapi_encrypt(api_path: str, query_body: dict) -> str:
    request_text = json.dumps(query_body, separators=(',', ':'))
    message = f"nobody{api_path}use{request_text}md5forencrypt".encode("latin1")
    msg_digest = hashlib.md5(message).hexdigest()
    raw = f"{api_path}-36cd479b6b5-{request_text}-36cd479b6b5-{msg_digest}".encode("utf-8")
    data = _pkcs7_padding(raw)
    cipher = AES.new(b"e82ckenh8dichen8", AES.MODE_ECB)
    encrypted = cipher.encrypt(data)
    return f"params={encrypted.hex().upper()}"
```

**请求方式**：
- 请求地址：`https://interface3.music.163.com/eapi/song/enhance/player/url/v1`
- 请求头注入：
  - `User-Agent: NeteaseMusic/9.3.40.1753206443(164);Dalvik/2.1.0 (Linux; U; Android 9)`
  - `Cookie: os=Android; appver=9.3.40; deviceId=...; MUSIC_U=<用户黑胶Cookie>; __remember_me=true`
- Body 参数：
  ```python
  body = {
      "ids": json.dumps([str(song_id)]),
      "level": "exhigh",  # standard(128k), higher(192k), exhigh(320k), lossless(flac)
      "encodeType": "mp3"
  }
  ```
- 返回结果中的 `data[0].url` 即为**官方 100% 完整、母带级 320k 原生音频直链**，下载仅需 0.8~1.2 秒！

---

## 4. Telegram 云端持久化缓存模式 (0 流量秒出)

为避免每次群友点歌都重复下载和消耗服务器带宽，在本地维护一个轻量 SQLite 表：

```sql
CREATE TABLE IF NOT EXISTS song_cache (
    song_id INTEGER PRIMARY KEY,
    title TEXT,
    artist TEXT,
    album TEXT,
    duration INTEGER,
    cover_url TEXT,
    tg_file_id TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

- **逻辑**：
  1. 点播某歌曲前，先查询 `SELECT tg_file_id FROM song_cache WHERE song_id = ?`；
  2. 若命中，直接调用 `bot.send_audio(chat_id, audio=cached_file_id, ...)`；
  3. **效果**：0 毫秒转码、0 字节出网、0.2 秒瞬发，彻底解决并发与重复点播瓶颈！
