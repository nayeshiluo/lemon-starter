# 群组功能独立开关与高保真群成员标签规范 (Per-Group Feature Toggles & Tag Enrichment)

## 一、 群组功能独立开关架构 (Per-Group Feature Toggles)

### 1. 业务痛点
不同的 Telegram 群聊对于机器人的功能诉求截然不同：
- 某些大群只需要「名言贴纸 (q/qs)」和「群聊总结 (/sum)」，不需要短视频解析（避免群友频繁分享视频导致刷屏）；
- 某些专业技术群需要「AI 智能问答」与「成员禁言风控」，不需要娱乐贴纸功能；
- 某些闲聊群需要开启「短视频解析」，但需要禁用「AI 问答」以节省 Token 消耗。

### 2. 架构设计与持久化存储
在 `data/config.json` 中维护按 `chat_id` 隔离的字典结构：
```json
{
  "group_features": {
    "-1004465895532": {
      "quote": true,
      "ai": true,
      "summary": true,
      "video": false,
      "mute": true
    }
  }
}
```

#### 核心代码实现 (`config.py`)
```python
AVAILABLE_FEATURES = {
    "quote": {"name": "名言贴纸 (q/qs/qd)", "icon": "💬"},
    "ai": {"name": "AI 问答 (ai)", "icon": "🤖"},
    "summary": {"name": "群聊总结 (/sum)", "icon": "📋"},
    "video": {"name": "视频解析 (抖音/B站/TikTok)", "icon": "🎬"},
    "mute": {"name": "成员禁言风控 (/mute)", "icon": "🔇"},
}

def get_group_features(chat_id: int) -> dict:
    """获取群功能启用状态，默认全开"""
    cfg = load_config()
    group_cfg = cfg.get("group_features", {}).get(str(chat_id), {})
    return {k: group_cfg.get(k, True) for k in AVAILABLE_FEATURES}

def is_feature_enabled(chat_id: int, feature_key: str) -> bool:
    return get_group_features(chat_id).get(feature_key, True)

def set_group_feature(chat_id: int, feature_key: str, enabled: bool) -> None:
    cfg = load_config()
    cfg.setdefault("group_features", {})[str(chat_id)][feature_key] = enabled
    save_config(cfg)
```

### 3. 多模态交互控制 (`/settings` / `/feature` / `/switch`)
1. **交互式面板 (Inline Keyboard)**：
   - 仅限拥有者、本群群主 (Creator) 或授权 VIP 操作；
   - 按钮动态显示当前状态：`💬 名言贴纸 : 🟢 开启中` / `🔴 已关闭`；
   - 点击后通过 CallbackQuery 原地编辑消息（`edit_message_text`），无刷屏无感切换。
2. **命令行快速单开/单关**：
   - 支持中英文别名：`/settings video off`、`/feature ai on`、`/settings 视频 关`。
3. **私聊大盘遥控**：
   - 拥有者在私聊输入 `/settings` 可直接列出所有已授权群聊按钮，跨群遥控任意群组功能。

---

## 二、 高保真身份头衔彩色标签规范 (SenderTag Enrichment)

### 1. quote-api 的空白丢失机制（这是正确行为，不要去"补偿"）
- **底层原理**：Node.js quote-api 渲染引擎如果收到 `senderTag: null` 或 `undefined`，右侧标签位置将**彻底留空不进行任何绘制**。
- ⚠️ **重要纠正（覆盖本文件旧版"必须全量兜底"的写法）**：爸爸明确否决了给无标签成员硬塞 `[群员]` 的做法 —— "没有标签的群成员 你是不是都给他编辑群员了 为什么 没有就没有就行了 不要添加额外的"。
  **Telegram 原生规则就是「没有标签则不显示」**，请与人型保持一致：`senderTag = None` 时不绘制即可，既不是 bug 也不需要 fallback。

### 2. 身份映射标准（宁缺毋滥）
| 角色 | 状态判定 | 是否绘制 | 标签颜色 (暗色/亮色) | 显示文字 |
| :--- | :--- | :---: | :--- | :--- |
| **👑 群主 (Creator / Owner)** | `status == "creator"` 或 `ChatMemberStatus.OWNER` | ✅ | 💜 官方梦幻紫 (`#b18fff` / `#8544c7`) | `custom_title` 否则 `群主` |
| **👮 管理员 (Administrator)** | `status == "administrator"` | ✅ | 💚 官方清新绿 (`#5ec26f` / `#4fae5e`) | `custom_title` 否则 `管理员` |
| **👤 普通成员·有自定义头衔** | 普通群友且 `custom_title` 非空 | ✅ | ⚪ 官方质感灰 (`#aaaaaa` / `#8e8e93`) | 该 `custom_title` |
| **👤 普通成员·无任何头衔** | 普通群友且无头衔 | ❌ **不绘制** | — | — |

### 3. 标签提取优先级与实现
```python
msg_sender_tag = getattr(reply_msg, "sender_tag", None) if reply_msg else None
msg_author_sig = getattr(reply_msg, "author_signature", None) if reply_msg else None
custom_title = getattr(member, "custom_title", None) or msg_sender_tag or msg_author_sig

tag_obj = None
if is_creator:
    tag_obj = {"text": custom_title or "群主", "isAdmin": True, "isCreator": True}
elif is_admin:
    tag_obj = {"text": custom_title or "管理员", "isAdmin": True, "isCreator": False}
elif custom_title:
    # 普通成员仅在确实带有自定义头衔/标签时才绘制，绝不自造 "群员"
    tag_obj = {"text": custom_title, "isAdmin": False, "isCreator": False}
# 其余情况 tag_obj 保持 None —— 渲染器不画标签，即为期望行为

# user_id 为 0 / get_chat_member 抛异常时同理：有 sender_tag 才用，否则 None
```

---

## 三、 会员专属 Emoji 状态与局部划选文字引用

### 1. Telegram Premium 会员状态图标 (Emoji Status)
- **痛点**：普通 Telegram Bot API 接收到的消息 `User` 对象仅包含 `is_premium: True`，根本不包含 `emoji_status`！
- **解决方案**：调用 `await bot.get_chat(user_id)` 获取 FullChat 对象，从中提取：
  - `user_chat.emoji_status_custom_emoji_id`（会员名字后专属 Emoji 状态 ID）；
  - `user_chat.accent_color_id`（会员专属彩色名字配色）；
  - 将 `emoji_status_id` 填入 `from.emoji_status`，quote-api 会自动调取 `getCustomEmojiStickers` 提取官方超清材质并精准绘制在用户昵称后方；
  - 配合 10 分钟 TTL 内存缓存，彻底避免频繁请求 Telegram API。

### 2. 划选局部文字引用制作名言 (TextQuote / msg.quote)
- **机制**：群友在 Telegram 客户端划选某一条长发言中的某一部分文字并点击「Quote / 引用回复」时，Telegram 会在消息对象中挂载 `msg.quote` (`TextQuote`)；
- **提取顺序**：
  ```python
  if getattr(msg, "quote", None) and getattr(msg.quote, "text", None) and msg.quote.text.strip():
      target_text = msg.quote.text.strip()
      target_entities = serialize_ptb_entities(getattr(msg.quote, "entities", None))
  else:
      target_text = reply_target.text or reply_target.caption or "[媒体消息]"
      target_entities = serialize_ptb_entities(reply_target.entities or reply_target.caption_entities)
  ```
- **效果**：群友只要长按划选其中的金句发 `/q`，Bot 只制作那一句金句，绝不把整篇发言全部塞入贴纸。

### 3. 贴纸直接发送不带回复锚点
- 发送生成的 WebP 贴纸或专属贴纸包卡片时，**严禁传入 `reply_to_message_id`**；
- 贴图应直接作为独立表情泡泡发在群聊末尾，视觉感干净整洁。

---

## 四、 私聊指令安全隔离与防爆破架构 (Private Chat Security & Anti-Exploit)

### 1. 作用域菜单精准隔离 (Scope Menu Isolation)
- **普通陌生人私聊 (`BotCommandScopeAllPrivateChats`)**：
  严格只注册唯一的 `[BotCommand("help", "📖 查看使用指南")]`，对外部隐藏全部群聊、管理、设置及运维指令。
- **拥有者私聊 (`BotCommandScopeChat(chat_id=OWNER_ID)`)**：
  展示全套控制台：`/help`, `/settings`, `/auth`, `/unauth`, `/groups`, `/addvip`, `/delvip`, `/viplist`。

### 2. 私聊指令执行拦截与垃圾消息防刷
- 陌生人尝试手打任何管理指令（如 `/auth`, `/settings`, `/addvip`），在 Handler 顶部直接以 `if not is_owner(user.id): return` 丢弃；
- 陌生人在私聊中发送的非指令普通消息，Bot 直接丢弃不予回显，杜绝被黑客用脚本发送海量消息造成 Bot 频繁调用 API 回复从而耗尽 Telegram 频控额度。

### 3. 六重安全防爆破体系
1. **零公网端口暴露**：采用 Long Polling 协议主动建立出网连接，主机无需开放任何 WebHook 端口，扫描器完全无法探测；
2. **64 位加密 UID**：MTProto 协议级签名验证 `from_user.id`，数学上不可伪造；
3. **未授权群组静默沙盒**：未通过 `/auth` 授权的群聊完全不处理任何业务，绝不出网、绝不调用大模型；
4. **RAM 环形缓冲区硬顶**：`collections.deque(maxlen=3000)` 常驻内存，无磁盘写放大风险，绝不发生 OOM；
5. **TPM / Token 熔断限流**：普通群友单次总结硬顶 500 条，单群互斥并发锁；
6. **代理专线内部回环**：中继与专线代理严格绑定 `127.0.0.1`，仅限本地进程通信。
