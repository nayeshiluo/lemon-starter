# 自建群聊 Bot 的 LLM 兜底链与安全失败提示

## 适用范围与授权

本参考只针对自己调用模型 API 的 Bot，不替代 Hermes 网关路由。先只读核对目标实例、时间、当前源码与脱敏错误；不要为了排障改模型、发群消息、重启服务或读取整份配置。
配置兜底链、消耗模型额度的探测和真实消息验收须在相应授权内进行。以下是供集成审查的纯函数示例，不是现行生产代码，也不自动联网。

## 1. 排查和降级边界

- 区分指令接收、鉴权、检索、模型请求与发送阶段，不能把“无回复”一概当成配额耗尽。
- 429 可能是 TPM、RPM、并发或账号/项目配额；同网关不同模型不一定有独立额度，换供应商也不保证可用。
- 从已核实配置生成获批的有序节点，不硬编码旧模型或未经许可的端点。保留权限和数据目的地边界；新的提供商可能接收用户内容，不能擅自加入。
- 为整单设置总时间预算、每节点超时与有限重试；按服务端提示退避。不要为了验证故障而破坏真实节点、清空密钥或改生产配置。
- 日志仅记录受控节点代号、错误类别、HTTP 状态和关联 ID。不得记录上游响应原文、异常原文、完整 URL、认证头、聊天正文或内部推理。

## 2. 仅接受明确的最终答案

正文为空、仅有推理字段、工具调用未结束、输出被截断或响应结构异常时，返回“没有可用最终答案”，由获批的降级/失败流程处理。禁止把 `reasoning_content` 当作正文兜底。

```python
PUBLIC_ERRORS = {
    "rate_limited": "AI 服务暂时不可用（上游限流），请稍后再试。",
    "auth_failed": "AI 服务暂时不可用（认证异常），请联系管理员。",
    "timeout": "AI 服务暂时不可用（请求超时），请稍后再试。",
    "no_final_answer": "AI 暂未返回可用答案，请稍后再试。",
}
GENERIC_ERROR = "AI 服务暂时不可用，请稍后再试。"


def extract_final_text(payload):
    """只读响应字段；不将推理、拒绝、工具调用或截断输出当成最终答案。"""
    if not isinstance(payload, dict):
        return None
    choices = payload.get("choices")
    if not isinstance(choices, list) or not choices:
        return None
    choice = choices[0]
    if not isinstance(choice, dict):
        return None
    if choice.get("finish_reason") not in (None, "stop"):
        return None
    message = choice.get("message")
    if not isinstance(message, dict):
        return None
    if message.get("tool_calls") or message.get("refusal"):
        return None
    content = message.get("content")
    if not isinstance(content, str):
        return None
    return content.strip() or None


def public_failure(kind):
    """只允许受控类别；未知值不回显，HTML 转义不等于脱敏。"""
    if not isinstance(kind, str):
        return GENERIC_ERROR
    return PUBLIC_ERRORS.get(kind, GENERIC_ERROR)
```

这些函数只约束字段与失败提示，不证明最终正文没有隐私或伪装推理。实际发送前仍需按应用上下文检查；不能靠截到第一个 HTML 折叠标签来证明安全。
不同提供商的响应结构须分别验证；不识别的结构保持失败，不能猜字段或把未知字段直接送群。

## 3. 失败可见化

- 调用层只向展示层传受控错误类别；展示层使用 `public_failure(kind)`，不要拼接原始异常、上游错误串或推理字段。
- 已有占位消息时在获批的交互流程内更新一次；无占位时按既有产品规则给出安全失败提示。防止重复发送或重复计费。
- HTML/Markdown 转义只解决格式问题，不替代敏感信息过滤。内部节点信息留在受限且脱敏的运维记录中。

## 4. 验证顺序

1. 先用合成响应离线测试：正常最终答案、仅推理、空正文、异常结构、工具调用、截断、拒绝，以及恶意错误字符串。
2. 用模拟 HTTP/超时验证有限降级、总时限与无静默失败；不得修改生产节点制造故障。
3. 取得相应授权后，使用当前配置做最小真实请求，检查实际路由、返回与投递；不要打印响应正文、密钥或原始错误。
4. 分开报告文档/代码验证、源码部署、进程激活和真实请求验收。未做真实测试就标记“待验证”，不能因离线测试通过宣称线上已修复。
