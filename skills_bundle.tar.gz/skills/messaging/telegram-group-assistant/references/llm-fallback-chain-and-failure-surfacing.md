# 自建群聊 Bot 的 LLM 多级兜底链与失败可见化

适用：任何**自己写代码调用大模型**的 Bot（不经过 Hermes 网关的路由层）。
典型触发场景：群友发 `/ai` 或 `/sum`，Bot 群里「毫无反应」，日志里是一个 429 / 401 / 超时。

---

## 1. 症状与第一性排查顺序

用户描述永远是「Bot 没反应」。**不要先去改 prompt 或调参**，按这个顺序查：

```bash
# ① 日志里搜 LLM 相关报错（Bot 自己的 logger 名）
journalctl -u <bot-service> --since "30 minutes ago" --no-pager | grep -iE "error|429|quota|exhaust"

# ② 如果是走本地网关，再看网关自己的日志
journalctl -u <gateway-service> --since "30 minutes ago" --no-pager | grep -iE "429|quota"

# ③ 直接对端点发最小请求，确认是「节点挂了」还是「代码挂了」
curl -s -X POST <BASE_URL>/chat/completions \
  -H "Authorization: Bearer $KEY" -H "Content-Type: application/json" \
  -d '{"model":"<MODEL>","messages":[{"role":"user","content":"回复OK"}],"max_tokens":20}'
```

本次实测抓到的原始证据：

```
[ERROR] services.ai_service: LLM API error (429):
{ "error": { "code": 429,
             "message": "Resource has been exhausted (e.g. check quota).",
             "status": "RESOURCE_EXHAUSTED" } }
```

→ 指令**已经正常触发**，是上游**模型配额耗尽**；而旧代码拿到 `None` 后 `return`，群里静默 → 用户以为死机。

**两个缺陷是叠加的，缺一不可修。**只修兜底链，下次别的节点挂了照样静默；只修提示，用户仍然拿不到答案。

---

## 2. 缺陷一：单点依赖 → 多级自动降级链

关键认知：**同一网关下的不同模型算不同节点**。429 是**模型级/账号配额**级别的，实测同一网关的
`gemini-3.8-flash-high` 与 `claude-sonnet-4-6` 会**同时**返回 429，所以必须跨提供商（跨 base_url）配兜底。

### 可复用骨架

```python
import os, re, aiohttp, logging
from typing import List, Dict, Optional, Tuple

logger = logging.getLogger(__name__)

# 端点与密钥一律从环境变量读，空密钥的节点自动跳过（不要把密钥写死进仓库）
LLM_CHAIN: List[Dict[str, str]] = [
    {"name": "反重力·Gemini3.8", "url": os.getenv("LLM_GATEWAY_URL", "http://127.0.0.1:8317/v1/chat/completions"),
     "key": os.getenv("ANTIGRAVITY_API_KEY", ""), "model": "gemini-3.8-flash-high"},
    {"name": "反重力·Claude",    "url": os.getenv("LLM_GATEWAY_URL", "http://127.0.0.1:8317/v1/chat/completions"),
     "key": os.getenv("ANTIGRAVITY_API_KEY", ""), "model": "claude-sonnet-4-6"},
    {"name": "日日新·DeepSeek",  "url": os.getenv("SENSENOVA_URL", "https://token.sensenova.cn/v1/chat/completions"),
     "key": os.getenv("HERMES_CUSTOM_TOKEN_SENSENOVA_CN_API_KEY", ""), "model": "deepseek-v4-flash"},
]

async def _call_llm(system_prompt: str, user_prompt: str,
                    max_tokens: int = 1500, temperature: float = 0.4
                    ) -> Tuple[Optional[str], Optional[str]]:
    """返回 (内容, 错误描述)。成功时错误为 None；全败时内容为 None 并给出可读原因。"""
    last_err = None
    for idx, node in enumerate(LLM_CHAIN):
        if not node.get("key") or not node.get("url"):
            continue                      # 未配置的节点直接跳过
        payload = {
            "model": node["model"],
            "messages": [{"role": "system", "content": system_prompt},
                         {"role": "user",   "content": user_prompt}],
            "max_tokens": max_tokens,
            "temperature": temperature,
        }
        headers = {"Authorization": f"Bearer {node['key']}",
                   "Content-Type": "application/json"}
        try:
            async with aiohttp.ClientSession() as s:
                async with s.post(node["url"], json=payload, headers=headers,
                                  timeout=aiohttp.ClientTimeout(total=70)) as resp:
                    if resp.status == 200:
                        data = await resp.json()
                        choices = data.get("choices", [])
                        if choices:
                            msg = choices[0].get("message", {}) or {}
                            content = (msg.get("content") or "").strip()
                            # 坑：部分中转在 max_tokens 偏小时把正文放进 reasoning_content
                            if not content:
                                content = (msg.get("reasoning_content") or "").strip()
                            if content:
                                if idx > 0:
                                    logger.info(f"LLM 已降级到兜底节点: {node['name']} ({node['model']})")
                                return content, None
                            last_err = f"{node['name']} 返回内容为空"
                    else:
                        err_txt = (await resp.text())[:200]
                        logger.warning(f"LLM node [{node['name']}] HTTP {resp.status}: {err_txt}")
                        if resp.status == 429:
                            last_err = f"{node['name']} 配额已耗尽 (429)"
                        elif resp.status in (401, 403):
                            last_err = f"{node['name']} 鉴权失败 ({resp.status})"
                        else:
                            last_err = f"{node['name']} 接口异常 ({resp.status})"
        except Exception as e:
            logger.warning(f"LLM node [{node['name']}] exception: {e}")
            last_err = f"{node['name']} 连接异常"

    return None, (last_err or "全部模型节点均不可用")
```

### 设计要点
- **顺序有意为之**：把「质量最好但配额紧」的放前面，「稳定兜底」的放最后。降级是有损的，值得记日志。
- **错误分类再上抛**：429 / 401 / 超时的语义完全不同，分开描述用户和运维才看得懂。
- **超时给足**：兜底链是串行尝试，单节点 70s 上限、多层叠加后仍要小于平台侧的整体容忍度。
- **返回元组而不是裸 `None`**：调用方必须拿到失败原因，否则又退化成静默。

---

## 3. 缺陷二：静默失败 → 失败可见化

兜底链全挂时**必须让用户看到原因**。推荐「限时自毁提示」，既不脏版面又给出确定性反馈：

```python
# handlers/messages.py —— AI 问答
answer, ai_err = await ask_ai(full_prompt, user_name=user_display)
if not answer:
    await send_temp_tip(
        context.bot, chat.id,
        f"⚠️ AI 服务暂时不可用：<i>{html.escape(str(ai_err))}</i>\n"
        f"请稍后重试，或联系管理员检查模型配额～",
        delay=12,
    )
    return
```

```python
# handlers/commands.py —— 群聊总结（原地编辑占位消息，不要另发）
summary_html, sum_err = await summarize_messages(chat_id, chat_title, desc, messages)
if not summary_html:
    await status_msg.edit_text(
        f"❌ 总结生成失败：{html.escape(str(sum_err))}\n请稍后重试，或联系管理员检查模型配额。"
    )
    return
```

要点：
- 提示里**带上具体原因**（「配额已耗尽 (429)」而不是「失败了」），运维一眼定位。
- 一律 `html.escape()`，错误串可能含 `<`、`&`。
- 用自毁提示（5~12s）而非常驻消息，保持群聊版面干净——这与本项目既有的「幽灵指令」交互规范一致。
- 占位消息已存在时用 `edit_text` 更新，不要再发第二条。

---

## 4. 端点可用性漂移（实测记录，非永久结论）

配置里写了 ≠ 现在能用。排障时用最小请求逐个探测（`max_tokens: 20`）。

| 端点 | 本次实测结果 |
|---|---|
| `http://127.0.0.1:8317/v1`（反重力） | `/v1/models` 返回 200，但 `chat/completions` 对 **所有** 模型返回 429 RESOURCE_EXHAUSTED（账号配额耗尽） |
| `https://token.sensenova.cn/v1`（日日新） | ✅ 正常返回正文 |
| `https://open.bigmodel.cn/api/paas/v4`（智谱） | ❌ `{"code":"1113","message":"余额不足或无可用资源包,请充值。"}` |
| `https://sharellm.cn/v1` | ❌ `404 page not found` |

结论：**兜底链要至少有一个「已实测连通」的节点**，否则等于没有兜底。别把上面的可用/不可用当成长期事实——每次接手先探测。

---

## 5. 验收清单

修完后必须实际跑一遍（不能只看代码）：

```bash
# ① 用真实故障节点的场景验证降级生效
python3 -c "
import asyncio, sys; sys.path.insert(0, '<bot_dir>')
from services.ai_service import ask_ai
ans, err = asyncio.run(ask_ai('用一句话解释什么是反代', user_name='测试'))
print('err:', err); print('content:', (ans or '')[:200])
"
# 期望输出：先打印 429 warning 两行（主/备节点），最后产出完整正文，err 为 None
```

```
# 实际通过时的日志长相
LLM node [反重力·Gemini3.8] HTTP 429: {...RESOURCE_EXHAUSTED...}
LLM node [反重力·Claude]   HTTP 429: {...RESOURCE_EXHAUSTED...}
LLM 已降级到兜底节点: 日日新·DeepSeek (deepseek-v4-flash)
err: None
content: <details>
<summary>💡 核心解答</summary>
• 反向代理就是给服务器当"前台接待"…
</details>
```

- [ ] 降级日志出现，说明链真的在走而不是跳过
- [ ] 返回内容非空且格式正确（折叠卡片未被破坏）
- [ ] 人为把整条链全打断，确认群里会收到带原因的提示，而不是静默
