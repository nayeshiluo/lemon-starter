# 群聊总结防冲突与双模解析规范

## 1. 群内防 Bot 冲突设计
在 Telegram 群聊中，大量 Bot 默认监听 `/summary`、`/sum`、`/ai` 等通用斜杠指令。若直接在群内输入斜杠指令，极易导致多个机器人同时响应抢答。

### 隔离方案
1. **前缀符号隔离（人形 UserBot 专属）**：
   - 使用中英文逗号/句号前缀：`,sum`、`，总结`、`,ai`、`。总结`；
   - 普通 Bot 仅监听 `/` 和 `!`，对 `,` 天然免疫，100% 避免抢答冲突。
2. **定向指令与作用域控制**：
   - 官方 Bot 使用 `/summary@bot_username` 形式，明确指定仅本 Bot 响应；
   - 菜单命令精简，仅暴露必要指令。

---

## 2. 条数与时间双模解析器标准实现

```python
import re
from datetime import datetime, timezone, timedelta

def parse_summary_target(arg_str: str) -> dict:
    arg = (arg_str or "").strip().lower()
    if not arg:
        return {"type": "count", "value": 80, "desc": "近 80 条发言"}
    
    # 1. 条数解析
    m_count = re.match(r"^(\d+)\s*(?:条|条消息|msgs?)?$", arg)
    if m_count:
        val = max(15, min(int(m_count.group(1)), 400))
        return {"type": "count", "value": val, "desc": f"近 {val} 条发言"}

    # 2. 时间解析
    now = datetime.now(timezone.utc)
    if arg in ("今日", "今天", "today"):
        beijing_tz = timezone(timedelta(hours=8))
        now_bj = datetime.now(beijing_tz)
        today_start_bj = now_bj.replace(hour=0, minute=0, second=0, microsecond=0)
        cutoff = today_start_bj.astimezone(timezone.utc)
        return {"type": "time", "cutoff": cutoff, "desc": "今日至今"}
    if arg in ("半小时", "30m", "30min", "30分钟"):
        cutoff = now - timedelta(minutes=30)
        return {"type": "time", "cutoff": cutoff, "desc": "近 30 分钟"}
    
    m_h = re.match(r"^(\d+(?:\.\d+)?)\s*(?:h|hr|hrs|小时|个半小时)?$", arg)
    if m_h:
        hrs = float(m_h.group(1))
        hrs = min(hrs, 48.0)
        cutoff = now - timedelta(hours=hrs)
        h_str = f"{hrs:g}"
        return {"type": "time", "cutoff": cutoff, "desc": f"近 {h_str} 小时"}

    m_m = re.match(r"^(\d+)\s*(?:m|min|mins|分钟)$", arg)
    if m_m:
        mins = min(int(m_m.group(1)), 2880)
        cutoff = now - timedelta(minutes=mins)
        return {"type": "time", "cutoff": cutoff, "desc": f"近 {mins} 分钟"}

    m_d = re.match(r"^(\d+)\s*(?:d|day|days|天)$", arg)
    if m_d:
        days = min(int(m_d.group(1)), 7)
        cutoff = now - timedelta(days=days)
        return {"type": "time", "cutoff": cutoff, "desc": f"近 {days} 天"}

    return {"type": "count", "value": 80, "desc": "近 80 条发言"}
```

---

## 3. Telethon 与 HTML 超链接渲染规范
1. **折叠块**：Telethon 使用 `<blockquote expandable><b>{Emoji} {标题}</b>\n\n• {事实要点}</blockquote>`。
2. **超链接转换**：模型输出的 Markdown 链接 `[来源](url)` 必须转换为 HTML `<a href="url">来源</a>`：
   ```python
   summary_html = re.sub(r'\[来源(?:\d+)?\]\((https?://[^\s\)]+)\)', r'<a href="\1">来源</a>', summary_html)
   ```

---

## 4. 跨进程 IPC 安全通信（原子写入防竞态）
在 UserBot 与外部 Bot/面板通信时，直接 `open(file, "w")` 会导致读取端偶发 `JSONDecodeError (Expecting value)`。必须采用原子落盘：
```python
tmp_file = f"{file_path}.tmp"
with open(tmp_file, "w", encoding="utf-8") as f:
    json.dump(data, f, ensure_ascii=False)
os.replace(tmp_file, file_path)
```
