# 群聊 Bot 触发与权限：源码级判据

配套 SKILL.md §8.5「五层定位法」。这里放源码逻辑与可直接复用的探针，供深挖时对照。

## 1. AstrBot 唤醒判定（`core/pipeline/waking_check/stage.py`，v4.29.3）

```python
# 角色判定：只和发送者 ID 比对
for admin_id in self.ctx.astrbot_config["admins_id"]:
    if str(event.get_sender_id()) == admin_id:
        event.role = "admin"
        break

# 前缀唤醒
for wake_prefix in wake_prefixes:            # 顶层 wake_prefix 是列表
    if message_str.startswith(wake_prefix):
        if (not event.is_private_chat()
                and isinstance(messages[0], At)
                and str(messages[0].qq) not in (str(event.get_self_id()), "all")):
            break                            # 第一个消息段 @ 了别人 → 不唤醒
        is_wake = True

# 无前缀时：@bot / AtAll / 引用 bot
if not is_wake:
    for message in messages:
        if ((isinstance(message, At) and str(message.qq) == str(event.get_self_id()))
                or (isinstance(message, AtAll) and not self.ignore_at_all)
                or (isinstance(message, Reply)
                    and str(message.sender_id) == str(event.get_self_id()))):
            is_wake = True
            break
    if event.is_private_chat() and not self.friend_message_needs_wake_prefix:
        is_wake = True                       # 私聊无条件唤醒
```

要点：
- `admins_id` 里的群 ID **永远匹配不到**任何 `sender_id`，是无效配置。
- 顶层 `wake_prefix`（列表）与 `provider_settings.wake_prefix`（字符串）是两个独立开关。
- `ignore_at_all: false`（默认）意味着 **@全体成员会唤醒 bot**，人多时容易被误触发。

## 2. 白名单判定（`core/pipeline/whitelist_check/stage.py`）

```python
if (event.unified_msg_origin not in self.whitelist
        and str(event.get_group_id()).strip() not in self.whitelist):
    logger.info(f"Session ID {event.unified_msg_origin} is not in the session allowlist ...")
    event.stop_event()
```

- 判 `group_id` → **群 ID 进白名单 = 全群放行**。
- `enable_id_white_list: false` 或白名单为空 → 不检查。
- `wl_ignore_admin_on_group` / `wl_ignore_admin_on_friend`：管理员跳过白名单。
- `webchat` 平台豁免。

## 3. 探针脚本（只读，token 不落命令行）

```python
import json, urllib.request
cfg = json.load(open("/opt/astrbot/data/cmd_config.json", encoding="utf-8-sig"))
tok = next(p["telegram_token"] for p in cfg["platform"] if p.get("type") == "telegram")

def api(method, **payload):
    req = urllib.request.Request(
        "https://api.telegram.org/bot" + tok + "/" + method,
        data=json.dumps(payload).encode() if payload else None,
        headers={"Content-Type": "application/json"},
    )
    return json.load(urllib.request.urlopen(req, timeout=20))

print(api("getMe")["result"]["can_read_all_group_messages"])   # 隐私模式：True=已关
print(api("getChat", chat_id=CHAT_ID)["result"]["title"])
print(api("getChatMember", chat_id=CHAT_ID, user_id=BOT_ID)["result"]["status"])
print(api("getMyCommands")["result"])                            # 默认菜单
print(api("getMyCommands", scope={"type": "chat", "chat_id": UID})["result"])
```

## 4. 指令权限清单（面板 API）

```python
items = get("/api/v1/commands", tok)["data"]["items"]
# 字段：effective_command / original_command / permission / plugin / enabled / description
```

`permission` 四种：`everyone`（群友可用）、`admin`（仅 `admins_id`）、`member`（仅非管理员）、`shared_group_admin`（仅群管理员，如 `/new` `/reset`）。

## 5. 日志判据速查

| 日志片段 | 含义 |
|---|---|
| `[Core] [INFO] [core.event_bus:117]: [default] [telegram-main(telegram)] 名/UID: 内容` | 消息进入事件总线（**私聊也会出现在这里**） |
| `has no speech-to-text provider configured` | 语音消息 + 无 STT，直接跳过 |
| `消息内容为空 ... 拒绝存储` | 表情/贴纸/语音，插件侧空内容 |
| `is not in the session allowlist` | 群 ID 不在白名单 |
| `Telegram Platform Adapter is running.` | 适配器起来了（不代表能唤醒） |

## 6. 已知实例

- 「大肥鱼」= `@dafeiyu120_bot`，AstrBot on diaomao，群 `人🐔局（执着白嫖）` `<PRIVATE_IDENTIFIER>`（bot 为管理员）
- 数据根 `/opt/astrbot`，`astrbot.service`，面板 `6185`，反代 `https://astrbot.<PRIVATE_IDENTIFIER>:8443`
- 插件：`get_px`（搜图+签到）、`listen_music`（B站听歌）、`matsuko_cover`（AI翻唱）、`qq_group_daily_analysis`（群分析/群漫画）、`parser`（链接解析）、`apis`
- 该机**没有 `sqlite3` CLI**，查插件库用 `python3 -c "import sqlite3; ..."`
