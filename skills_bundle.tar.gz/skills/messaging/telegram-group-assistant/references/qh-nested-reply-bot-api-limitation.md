# Telegram Bot API 中 `qh` 二级引用嵌套剥离陷阱与内存回复链索引解决方案

## 1. 现象与底层根因 (Root Cause Analysis)

### 故障现象
群友或管理员长按回复一条发言（消息 B，该消息本身回复了消息 A）发送 `/qh`，期望生成带有上级发言引用盒的“双层嵌套引用气泡”；但 Bot 实际仅生成了消息 B 单独一条发言的气泡，丢失了被引用的上文消息 A。

### 官方协议底层死穴 (The Telegram Bot API Limitation)
在 Telegram 官方 Bot API 规范中，关于 `Message` 对象的 `reply_to_message` 字段有硬性说明：
> **`reply_to_message: Message, optional`**  
> *"For replies in the same chat and message thread, the original message. Note that the Message object in this field will not contain further reply_to_message fields even if it itself is a reply."*

- **机制解析**：
  1. Telegram 服务器为了防止深层嵌套数据包膨胀与循环引用，**强制对 `reply_to_message` 内部的对象剥离其自身的 `reply_to_message` 属性（直接置为 `None`）**。
  2. 当用户回复消息 B 发送 `/qh` 时，`update.message.reply_to_message` 是消息 B；
  3. 若代码直接读取 `reply_target.reply_to_message`，得到的结果**永远是 `None`**！
  4. Telegram Bot API 又**完全没有提供类似 `getMessage(chat_id, message_id)` 的被动查消息接口**。
- **与人型 (UserBot / Telethon) 的本质差异**：
  人型走的是 MTProto 客户端协议，随时可通过 `await msg.get_reply_message()` 发起底层 RPC (`GetMessagesRequest`) 按消息 ID 拉取历史；而 Bot API 无法做到。

---

## 2. 四重链式回复提取解决方案 (Four-Layer Fallback Architecture)

为了在 Bot API 限制下 100% 稳定生成 `qh` 嵌套引用气泡，采用以下链式解析策略：

### 核心架构图
```
用户回复消息 B 发送 /qh
  │
  ├─► [1. 内存回复链索引 (Layer 1 - 主力)] ──► 找到消息 B 当时绑定的父级消息 A (昵称、文字、格式)
  │                                           │ (命中率 > 95%)
  │                                           ▼
  ├─► [2. 原生 TextQuote 提取 (Layer 2)] ────► 命中：从 reply_target.quote 提取被引用片段
  │                                           │
  ├─► [3. 前置紧邻消息探测 (Layer 3)] ────────► 兜底：从内存队列取紧邻上条发言作为对话上下文
  │                                           │
  └─► 装配 replyMessage 字典 ──────────────────► 送入 quote-api 生成原生彩色引用细线气泡
```

---

## 3. 代码实现规范

### 1. 消息入库时主动构建回复链 (`database.py`)
```python
MESSAGE_META_CACHE: Dict[tuple, Dict[str, Any]] = {}
MESSAGE_ORDER: Dict[int, deque] = {}  # chat_id -> deque of message_ids (maxlen=3000)

def record_chat_message(
    chat_id: int,
    message_id: int,
    user_id: int,
    user_name: str,
    text: str,
    entities: Optional[list] = None,
    reply_to_info: Optional[dict] = None
):
    if not text:
        return
    if chat_id not in MESSAGE_ORDER:
        MESSAGE_ORDER[chat_id] = deque(maxlen=3000)

    key = (chat_id, message_id)
    if key not in MESSAGE_META_CACHE:
        # ⚠️ 必须显式淘汰：deque(maxlen=3000) 只会丢 order 里的 id，
        # 不删 dict 就会让 MESSAGE_META_CACHE 无限膨胀（长期运行缓慢吃内存）。
        order = MESSAGE_ORDER[chat_id]
        if len(order) >= 3000:
            evicted = order[0]
            MESSAGE_META_CACHE.pop((chat_id, evicted), None)
        order.append(message_id)

    MESSAGE_META_CACHE[key] = {
        "message_id": message_id,
        "user_id": user_id,
        "user_name": user_name,
        "text": text.strip(),
        "entities": entities or [],
        "reply_to": reply_to_info,  # 记录父消息信息
        "created_at": time.time()
    }

def get_message_reply_info(chat_id: int, message_id: int) -> Optional[dict]:
    meta = MESSAGE_META_CACHE.get((chat_id, message_id))
    if meta and meta.get("reply_to"):
        return meta["reply_to"]
    return None

def get_messages_ending_at(chat_id: int, message_id: int, count: int) -> List[dict]:
    """提取以 message_id 为终点（含）的连续 count 条消息，供 `q N` 合并成长贴纸"""
    if count <= 1:
        return []
    order = MESSAGE_ORDER.get(chat_id)
    if not order:
        return []
    ids = [m_id for m_id in list(order) if m_id <= message_id]
    if not ids:
        return []
    res = []
    for m_id in ids[-count:]:
        meta = MESSAGE_META_CACHE.get((chat_id, m_id))
        if meta:
            res.append(meta)
    return res

def get_preceding_message(chat_id: int, message_id: int) -> Optional[dict]:
    order = MESSAGE_ORDER.get(chat_id)
    if not order:
        return None
    ids = list(order)
    smaller = [m_id for m_id in ids if m_id < message_id]
    if smaller:
        return MESSAGE_META_CACHE.get((chat_id, smaller[-1]))
    return None
```

### 2. 消息监听器实时抓取 (`handlers/messages.py`)
群内任意消息到来时，由于该消息在当前 Update 中属于 **顶层消息**，其 `msg.reply_to_message` 是完整包含作者与文字的：
```python
# 实时记录本群消息链与回复父级索引（专供 qh 跨层级深度还原）
reply_to_meta = None
if msg.reply_to_message:
    p = msg.reply_to_message
    p_sender = p.from_user
    p_text = p.text or p.caption or ("[贴纸]" if p.sticker else "[媒体]")
    reply_to_meta = {
        "name": p_sender.full_name if p_sender else "群友",
        "text": p_text,
        "chatId": p_sender.id if p_sender else 0,
        "entities": serialize_ptb_entities(p.entities or p.caption_entities)
    }
    record_chat_message(
        chat_id=chat.id,
        message_id=p.message_id,
        user_id=p_sender.id if p_sender else 0,
        user_name=p_sender.full_name if p_sender else "群友",
        text=p_text,
        entities=reply_to_meta["entities"]
    )

record_chat_message(
    chat_id=chat.id,
    message_id=msg.message_id,
    user_id=user.id,
    user_name=user.full_name,
    text=raw_text or ("[贴纸]" if msg.sticker else "[媒体]"),
    entities=serialize_ptb_entities(msg.entities or msg.caption_entities),
    reply_to_info=reply_to_meta
)
```

### 3. `qh` 触发时的四重装配 (`process_quote`)
```python
reply_obj = None

# 路径 A: 检查 reply_target 自身的 reply_to_message (极少数情况)
parent_msg = getattr(reply_target, "reply_to_message", None)
if parent_msg:
    p_sender = parent_msg.from_user
    reply_obj = {
        "name": p_sender.full_name if p_sender else "群友",
        "text": parent_msg.text or parent_msg.caption or "[媒体]",
        "chatId": p_sender.id if p_sender else 0,
        "entities": serialize_ptb_entities(parent_msg.entities or parent_msg.caption_entities)
    }

# 路径 B: 从内存索引中查取父级
if not reply_obj:
    cached_parent = get_message_reply_info(chat.id, reply_target.message_id)
    if cached_parent:
        reply_obj = cached_parent

# 路径 C: Telegram 7.0+ 原生 quote / external_reply
if not reply_obj and getattr(reply_target, "quote", None) and getattr(reply_target.quote, "text", None):
    p_name = "群友"
    p_id = 0
    if getattr(reply_target, "external_reply", None):
        er = reply_target.external_reply
        if getattr(er, "origin", None):
            orig = er.origin
            p_name = getattr(orig, "sender_user_name", None) or getattr(orig, "author_signature", None) or "群友"
            if getattr(orig, "sender_user", None):
                p_name = orig.sender_user.full_name
                p_id = orig.sender_user.id
    reply_obj = {
        "name": p_name,
        "text": reply_target.quote.text,
        "chatId": p_id,
        "entities": serialize_ptb_entities(getattr(reply_target.quote, "entities", None))
    }

# 路径 D: 明确发了 qh，但以上均未命中，提取群内紧邻的上一条发言作为上下文
if not reply_obj and cmd_lower.startswith("qh"):
    prev = get_preceding_message(chat.id, reply_target.message_id)
    if prev:
        reply_obj = {
            "name": prev.get("user_name", "群友"),
            "text": prev.get("text", "..."),
            "chatId": prev.get("user_id", 0),
            "entities": prev.get("entities", [])
        }

if reply_obj:
    msg_item["replyMessage"] = reply_obj
```

---

## 4. quote-api 渲染视觉对比

| 模式 | Payload 结构 | 客户端呈现效果 |
|---|---|---|
| **`qh` 嵌套引用气泡** | 单条 `msg_item` 携带 `replyMessage: {name, text, chatId}` | 单张气泡上方带有**彩色引用细竖线、被引用者昵称与发言片段**，下方紧接回复正文 |
| **`q 2` 双人上下对话** | `messages` 数组包含两条独立的 `msg_item` | 垂直堆叠的**两张独立气泡**（上为提问/原发言，下为回答/回复） |
