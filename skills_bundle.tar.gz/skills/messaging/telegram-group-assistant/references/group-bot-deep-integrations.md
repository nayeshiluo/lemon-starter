# Telegram 独立全能群聊助手深度集成与排障手册

## 1. 群专属贴纸包独立隔离与点击唤起规范 (Per-Group Sticker Set & Deep Linking)
- **痛点**：若按个人用户 ID 生成贴纸包，多群金句混在一起；且 Telegram 要求创建贴纸包的 `user_id` 必须此前私聊过 Bot，普通群友触发 `qs` 易报 `PEER_ID_INVALID` 或 `User not found`。
- **命名规范**：
  - 群贴纸包 Short Name 格式：`g_{clean_chat_id}_by_{bot_username}`（移除群 ID 的 `-100` 或 `-`，以英文字母 `g_` 开头，仅含字母数字下划线，以 `_by_<bot_username>` 结尾）。
  - 标题格式：`{chat_title} 的名言集`。
  - 持有人指定：将 `createNewStickerSet` 和 `addStickerToSet` 的 `user_id` 统一指定为机器人拥有者（Owner ID）。由于拥有者此前已与 Bot 建立了私聊会话，群内任何管理员执行 `qs` 时均可 100% 成功建包和追加，免除群友私聊 `/start` 的前置要求。
- **点击唤起整包直链避坑 (Deep Linking)**：
  - 调用 `addStickerToSet` 返回成功后，若直接发送内存 WebP（`InputFile(io.BytesIO(bytes))`），Telegram 仅将其作为独立无归属静态贴纸渲染，用户点击贴纸无法唤出专属贴纸包；
  - **正解**：追加成功后，调用 `s_set = await bot.get_sticker_set(pack_name)`，取出最新的 `s_set.stickers[-1].file_id` 发送；群友点击贴纸即可原地弹窗呼出本群专属名言贴纸包并带“添加贴纸”按钮。
- **PTB 22.x 参数废弃排障**：
  - `python-telegram-bot>=21.0` 的 `create_new_sticker_set` 已**移除外层的 `sticker_format` 关键字参数**；
  - 格式统一在 `InputSticker(sticker=..., emoji_list=[...], format="static")` 内部声明。传入 `sticker_format="static"` 会直接抛出：`TypeError: ExtBot.create_new_sticker_set() got an unexpected keyword argument 'sticker_format'`。

---

## 2. Bot API 10.1 原生小三角折叠卡片（sendRichMessage 核心协议）
- **核心差异**：
  - 标准 `sendMessage` / `editMessageText`（`parse_mode="HTML"`）**绝对不支持 `<details>` 标签**，传入直接抛出 `Bad Request: can't parse entities: Unsupported start tag "details"`；
  - 只有 MTProto 个人协议（UserBot）使用 `<blockquote expandable>` 呈现折叠，但带浅灰底色与左侧粗竖线；
  - **Bot 官方极简小三角卡片**：必须调用 Bot API 10.1 原生富文本管道：
    ```python
    # 初始发送：
    await bot.do_api_request("sendRichMessage", api_kwargs={
        "chat_id": chat_id,
        "rich_message": {"markdown": "<details>\n<summary>Emoji 标题</summary>\n\n• 内容 [来源](url)\n</details>"}
    })
    # 原位编辑（从状态文本更新为总结卡片）：
    await bot.do_api_request("editMessageText", api_kwargs={
        "chat_id": chat_id,
        "message_id": status_msg_id,
        "rich_message": {"markdown": full_markdown}
    })
    ```
- **超长拆包 (Auto-Chunking)**：
  Telegram 存在单条 4096 字符硬上限。总结输出时按 `</details>\n\n` 边界智能切分为 ≤3800 字符的多段 Payload，首段编辑 `status_msg`，后续段落顺序调用 `sendRichMessage` 追发，保证 100% 稳定交付。

---

## 3. 全主流短视频跨平台解析与 0 服务器出网流量架构
- **支持平台**：抖音、TikTok、快手、小红书、皮皮虾、Twitter/X、Bilibili、YouTube。
- **零出网架构设计**：
  - 调用 `bot.send_video(chat_id, video=video_url)` 时直接传入视频 CDN 外部直链；
  - 视频由 Telegram 全球数据中心（Telegram DC）直连视频源 CDN 拉取并分发；
  - 机器人宿主服务器仅发起 2~3 个轻量 JSON 接口请求（单次约 10~30KB）用于提取直链，完全不占用云服务器的视频下载与出网带宽，彻底守住每月免费出网额度。
- **海外机房 IP 风控注意**：
  - YouTube 与 Bilibili 针对海外云机房 IP（如 AWS）存在严格的 Bot 防护或 HTTP 412 拦截，需结合住宅 IP / NAT 小鸡做代理中转；
  - 抖音、快手、皮皮虾、小红书、Twitter/X 经由 ParseHub 移动端逆向接口可直接免 Cookie 稳定解析。

---

## 4. 群成员风控禁言与解禁 (/mute & /unmute)
- **权限判定**：仅允许群主（`creator`）、管理员（`administrator`）、Owner 及授权 VIP 执行；
- **防背刺安全红线**：严禁禁言 Owner 和群管理员；
- **双模目标解析**：
  1. 长按回复目标消息执行；
  2. 参数解析 `@username` 或数字 ID（通过数据库历史发言用户映射表动态解析对应 `user_id`）；
- **自然时间窗口归一化**：
  - `10m` / `15分钟` -> 秒
  - `2h` / `1.5小时` -> 秒
  - `1d` / `3天` -> 秒
  - `永久` / `forever` -> 365 天
- **Telegram 限制调用**：
  ```python
  await bot.restrict_chat_member(
      chat_id=chat_id,
      user_id=target_user_id,
      permissions=ChatPermissions(can_send_messages=False, ...),
      until_date=int(time.time() + duration_seconds)
  )
  ```
