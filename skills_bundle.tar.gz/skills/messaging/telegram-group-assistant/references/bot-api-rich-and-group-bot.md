# Telegram Bot API 10.1 原生小三角折叠卡片与独立群聊助理实战

## 1. 原生折叠卡片双轨渲染与关键避坑 (sendRichMessage vs sendMessage)

在开发 Telegram 机器人（群聊总结、AI 问答）时，折叠呈现分为两大体系：

### 体系 A：官方机器人 Bot API 10.1 原生小三角折叠卡片 (`<details><summary>`)
- **呈现样式**：极简纯净的原生小三角折叠卡片，展开无灰色背景、无左侧引用竖线，质感最轻盈高级。
- **致命陷阱（HTML 400 报错）**：
  在 `sendMessage` 中传 `parse_mode="HTML"` 时，Telegram Bot API 会报错：
  `Bad Request: can't parse entities: Unsupported start tag "details" at byte offset 0`。
  普通 `sendMessage` 的 HTML 解析器仅支持基础实体（`b`, `i`, `code`, `pre`, `blockquote`），不支持 `<details>`！
- **正确调用方式**：
  必须通过 Bot API 10.1 的原生富文本接口 `sendRichMessage` 或 `editMessageText`（传 `rich_message` 参数）：
  ```python
  # 初始发送：
  await bot.do_api_request("sendRichMessage", api_kwargs={
      "chat_id": chat_id,
      "rich_message": {"markdown": "<details>\n<summary>💡 核心结论</summary>\n\n• 内容...\n</details>"}
  })
  
  # 进度流编辑：
  await bot.do_api_request("editMessageText", api_kwargs={
      "chat_id": chat_id,
      "message_id": status_msg_id,
      "rich_message": {"markdown": full_markdown}
  })
  ```

### 体系 B：MTProto 人型协议（Telethon / UserBot）
- 普通真人号通过 Telethon 只能发送 `<blockquote expandable>`，客户端呈现为带浅灰色底纹背景和引用竖线的引用展开块。

---

## 2. AI 问答卡片化与引用回复 (/ai) 机制

- **排版对齐总结标准**：
  回答按结构提炼为 2~3 个 `<details><summary>` 原生小三角卡片：
  - `💡 核心结论与速览`
  - `⚙️ 深度原理解析 / 关键步骤`
  - `📋 建议与避坑指南`
- **长按引用回复触发**：
  群友长按回复某条消息发 `/ai` 或 `ai`（亦可追加追问）：
  1. 0.1 秒秒删群友的 `/ai` 指令；
  2. 提取被引用的消息文本与原作者作为问题；
  3. 调用大模型生成结构化卡片；
  4. 通过 `sendRichMessage` 并携带 `reply_parameters={"message_id": reply_target.message_id}` 精准回传。

---

## 3. 贴纸包创建关键避坑 (python-telegram-bot v22)

- **参数变动陷阱**：
  在 PTB 21/22 中调用 `bot.create_new_sticker_set` 时，不要传递 `sticker_format` 关键字参数，否则抛出：
  `TypeError: ExtBot.create_new_sticker_set() got an unexpected keyword argument 'sticker_format'`。
- **规范调用**：
  贴纸格式应定义在 `InputSticker` 内部：
  ```python
  from telegram import InputSticker
  item = InputSticker(sticker=io.BytesIO(webp_bytes), emoji_list=["💬"], format="static")
  await bot.create_new_sticker_set(
      user_id=user_id,
      name=f"q_{user_id}_by_{bot_username}",
      title=f"{user_name}的名言集",
      stickers=[item]
  )
  ```

---

## 4. 群聊 Q 图贴纸专属底色隔离 (/color)

- **群独立配置**：
  每个群在配置表中独立维护 `group_quote_colors[str(chat_id)]`，绝不修改全局底色。
- **高颜值预设色板**：
  - 💖 猛男芭比粉：`#FF1493`
  - 💜 魅惑梦幻紫：`#7B1FA2`
  - ⚫ 极夜纯黑（默认）：`#000000`
  - ⚪ 经典纯白：`#FFFFFF`
  - 🌌 暗夜紫黑：`#1b1429`
  - 🌃 电报深蓝：`#18222d`
  - 🌑 现代深灰：`#2b2d30`
  - 🪐 蓝调夜空：`#242f3d`
- 通过 Telegram Inline Keyboard 实现点选即时生效，仅管理员/特权用户可操作。
