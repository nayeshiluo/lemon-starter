# Telegram 独立群聊助理实战：贴纸包绑定、多平台视频直传、群规风控与内存优化

本文档沉淀自 `@yecaodi_bot`（群霸智能助手）独立群聊 Bot 实战落地过程中的核心架构、交互细节与关键技术排坑。

---

## 1. 贴纸包 API 联动与高质感链接卡片 (Sticker Pack Linking & Inline Buttons)

### 1.1 `qs` 贴纸收录的真实业务语义（爸爸明确纠正）
- **核心语义区分**：
  - `q`：将群友的文字发言**转成名言气泡贴纸**；
  - `qs`：**将现成的素材（贴纸/图片）收录进专属贴纸包**！
- **多分支处理逻辑**：
  1. **回复现有贴纸**：通过 `bot.get_file(st.file_id)` 下载原始 WebP 字节，若尺寸超过 512px 通过 Pillow 进行抗锯齿缩放（`Image.Resampling.LANCZOS`），原汁原味录入贴纸包；
  2. **回复图片/照片**：下载原图并等比缩放规范化为 512px WebP；
  3. **回复文字发言**：调用本地 `quote-api` 渲染名言气泡后录入。

### 1.2 PTB 22.x 建包参数避坑
在 `python-telegram-bot` v21/v22+ 中：
- `Bot.create_new_sticker_set()` 彻底废除 `sticker_format` 关键字参数；
- 贴纸格式必须封装在单个 `InputSticker(..., format="static")` 内部，外层若再传会报 `TypeError`。

### 1.3 贴纸包链接卡片与内联添加按钮（对齐截图标准）
贴纸追加进群专属贴纸包（`g_{clean_chat_id}_by_{bot_username}`）成功后：
1. **原位发出贴纸**：优先使用云端返回的最新 `latest_sticker.file_id`，保证客户端可交互；
2. **发出链接卡片与 InlineButton**：
   ```python
   keyboard = InlineKeyboardMarkup([[
       InlineKeyboardButton(text="📦 查看/添加本群贴纸包 →", url=res_url)
   ]])
   await context.bot.send_message(
       chat_id=chat.id,
       text=(
           f"✅ <b>已收录进【{html.escape(chat_title)}】名言集！</b>\n\n"
           f"🔗 <b>贴纸包链接：</b>\n{res_url}"
       ),
       reply_markup=keyboard,
       parse_mode=ParseMode.HTML,
       disable_web_page_preview=False,
       reply_to_message_id=reply_target.message_id
   )
   ```
   Telegram 客户端会同时渲染贴纸包元数据预览卡片与底部的直达添加按钮，交互体验拉满。

---

## 2. 视频分享链接交互与零流量分层架构

### 2.1 用户发言保留红线（爸爸明确纠正）
- **绝不删除**：群友在群里粘贴的视频分享消息（抖音、B站、TikTok、小红书等），**原消息 100% 完整保留在群聊中**，禁止调用 `delete_message`；
- **引用回复发出**：Bot 将解析出的视频/图集以 `reply_to_message_id=msg.message_id` 的形式发出，形成清晰的「用户发链接 -> Bot 紧接着回复播放原片」的阅读链路。

### 2.2 多平台视频交付链路
1. **抖音/快手/小红书/微博**：
   - 优先通过 `parsehub` 提取无水印 CDN 直链；
   - 调用 `bot.send_video(video=url)`，Telegram 官方数据中心直接连接 CDN 下载，**服务器出网流量 0 KB**；
   - 若个别视频 CDN 限制直连，自动降级为流式缓冲后上传。
2. **哔哩哔哩 (B站)**：
   - `b23.tv` / `BV` 号经 `curl_cffi` + `wbi` 混音签名 + `X-BILI-SEC-TOKEN` 时序解析出直链；
   - 流式拉取（带 Referer）至内存 `io.BytesIO`，调用 `send_video` 秒级上传。
3. **TikTok**：
   - 短链展开后由 `yt-dlp --impersonate chrome` 本地原生解密并下载 mp4；
   - 读取内存字节上传，杜绝因 CDN 防盗链或 IP 风控导致的 403。

---

## 3. 极速内存环形缓冲区设计（总结防卡顿规范）

### 3.1 痛点与顾虑
群聊中消息极其高频，若每条群友发言都实时执行 SQLite `INSERT` 与日志写入：
- 长期运行导致数据库文件无限膨胀；
- 频繁的磁盘 I/O 会严重拖慢 Bot 的事件循环，导致响应指令出现卡顿或丢消息。

### 3.2 内存环形队列（Ring Buffer）实现
```python
from collections import deque
from typing import Dict

# 每个群独立维护固定容量内存队列（默认 3000 条）
MEMORY_CACHE: Dict[int, deque] = {}

def save_message(chat_id: int, message_id: int, user_id: int, user_name: str, text: str):
    if not text or not text.strip():
        return
    if chat_id not in MEMORY_CACHE:
        MEMORY_CACHE[chat_id] = deque(maxlen=3000)
    MEMORY_CACHE[chat_id].append({
        "message_id": message_id,
        "user_id": user_id,
        "user_name": user_name,
        "text": text.strip(),
        "created_at": time.time()
    })
```
- **核心优势**：
  1. 平时发言仅在 Python 内存列表追加一条纯文本对象，单次耗时 `< 1 微秒`；
  2. 磁盘 I/O 为 0，大模型 Token 开销为 0；
  3. 仅在群友触发 `/sum` 或 `总结` 的瞬间，从内存列表极速切片送给大模型生成卡片，彻底免除卡顿风险。

---

## 4. 群独立贴图底色定制 (/color)

- **群物理隔离**：每个群拥有独立的配置项 `group_quote_colors["<chat_id>"]`，A 群改色绝不影响 B 群；
- **内置特色预设**：
  - `💖 猛男芭比粉 (#FF1493)`
  - `💜 魅惑梦幻紫 (#7B1FA2)`
  - `⚫ 极夜纯黑 (#000000)`（默认）
  - `⚪ 经典纯白 (#FFFFFF)`
  - `🌃 电报深蓝 (#18222d)`
- **双模配置**：
  - `/color` 唤出带有 ✅ 激活标记的 8 色内联按钮面板，点按即切；
  - 文本快捷指令：`/color 芭比粉`、`/color 紫色`、`/color #FF1493` 快速设定。

---

## 5. 双模群聊成员禁言与解禁风控系统 (/mute & /unmute)

- **权限主体铁律（爸爸明确纠正）**：
  严格限定**仅限以下三类身份有权触发禁言/解禁**：
  1. 👑 **机器人拥有者（爸爸 / Owner ID）**
  2. 🏠 **本群群主（Chat Creator / `ChatMemberStatus.OWNER`）**
  3. ⭐ **拥有者指定人员（通过 `/addvip` 授权的 VIP 用户）**
  ❌ **普通群管理员（Ordinary Administrator）严格无权使用禁言指令**，越权调用将受到友好拦截提醒；普通群友发送一律秒删拦截。
- **豁免与防背刺保护**：
  - 绝对禁止禁言机器人拥有者（爸爸）；
  - 绝对禁止禁言拥有者指定的特权人员（`/addvip`）；
  - 绝对禁止禁言本群群主。
- **双模触发**：长按回复违规发言发 `/mute 10m`，或直接发 `/mute @用户名 1小时`；
- **自然时间智能解析**：支持 `m/分`, `h/小时`, `d/天`, `永久`；
- **解禁机制**：回复发 `/unmute` 或发 `/unmute @用户名` 瞬间解封。
