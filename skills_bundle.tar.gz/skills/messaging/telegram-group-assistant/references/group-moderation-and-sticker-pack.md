# Telegram 独立群聊助理实战：贴纸包绑定、多平台视频直传、群规风控与内存优化

本文档沉淀自 `@yecaodi_bot`（群霸智能助手）独立群聊 Bot 实战落地过程中的核心架构、交互细节与关键技术排坑。

---

## 1. 贴纸包 API 联动、删除与多卷自动扩容 (Sticker Pack Linking, Deletion & Auto-Volumes)

### 1.1 `qs` 贴纸收录的真实业务语义（爸爸明确纠正）
- **核心语义区分**：
  - `q`：将群友的文字发言**转成名言气泡贴纸**；
  - `qs`：**将现成的素材（贴纸/图片）收录进专属贴纸包**！
- **多分支处理逻辑**：
  1. **回复现有贴纸**：通过 `bot.get_file(st.file_id)` 下载原始 WebP 字节，若尺寸超过 512px 通过 Pillow 进行抗锯齿缩放（`Image.Resampling.LANCZOS`），原汁原味录入贴纸包；
  2. **回复图片/照片**：下载原图并等比缩放规范化为 512px WebP；
  3. **回复文字发言**：调用本地 `quote-api` 渲染名言气泡后录入。

### 1.2 PTB 22.x 建包参数避坑
在 `python-telegram-bot` v21/v22+ 中：
- `Bot.create_new_sticker_set()` 彻底废除 `sticker_format` 关键字参数；
- 贴纸格式必须封装在单个 `InputSticker(..., format="static")` 内部，外层若再传会报 `TypeError`。

### 1.3 贴纸包链接卡片与内联添加按钮（对齐截图标准）
贴纸追加进群专属贴纸包（`g_{clean_chat_id}_by_{bot_username}`）成功后：
1. **原位发出贴纸**：优先使用云端返回的最新 `latest_sticker.file_id`，保证客户端可交互；
2. **发出链接卡片与 InlineButton**：
   ```python
   keyboard = InlineKeyboardMarkup([[
       InlineKeyboardButton(text="📦 查看/添加本群贴纸包 →", url=res_url)
   ]])
   await context.bot.send_message(
       chat_id=chat.id,
       text=(
           f"✅ <b>已收录进【{html.escape(chat_title)}】名言集！</b>\n\n"
           f"🔗 <b>贴纸包链接：</b>\n{res_url}"
       ),
       reply_markup=keyboard,
       parse_mode=ParseMode.HTML,
       disable_web_page_preview=False
   )
   ```
   Telegram 客户端会同时渲染贴纸包元数据预览卡片与底部的直达添加按钮，交互体验拉满。
   ⚠️ **不要传 `reply_to_message_id`**（爸爸明确纠正）：贴纸与贴纸包卡片都应像真人一样直接落到群聊末尾，挂回复锚点会让版面显得冗余。详见 `references/per-group-feature-toggles-and-tag-enrichment.md` §3.3。

### 1.4 `qd` 贴纸精准删除指令（爸爸明确要求）
- **业务场景**：群里收录了重复、过时或误操作的贴图，需要从贴纸包中精准注销剔除；
- **交互规范**：
  - **长按/右键回复**需要删除的那张贴纸消息，发送 `/qd` 或 `qd`；
  - **秒删触发指令**（幽灵模式无痕执行）；
  - 调用官方 API `await bot.delete_sticker_from_set(sticker=st_file_id)`；
  - 成功后自动删除群聊中被回复的那张贴图消息，并弹出 5 秒自毁确认卡片；
  - 若回复的贴图非本 Bot 维护的贴纸包，捕获 `BadRequest` 并提示“该贴图不属于本群贴纸包，无法删除”。
- **权限白名单（仅四类人员可用）**：
  1. 👑 机器人拥有者（爸爸）
  2. 🏠 本群群主（Creator / Group Owner）
  3. ⭐ 拥有者指定特权人员（`/addvip`）
  4. 👮 本群管理员（Administrator）
  *(普通群友发送一律秒删拦截并提示无权操作)*。

### 1.5 贴纸包 120 张上限与全自动滚动分卷（Vol.2, Vol.3...）扩容引擎
- **Telegram 官方硬限制**：每个静态贴纸包最多容纳 **120 张**贴纸，满额后再调 `addStickerToSet` 会直接抛出 `STICKERS_TOO_MUCH` 异常并阻断入库；
- **滚动分卷自动建包算法**：
  1. **第 1 卷**：`g_{clean_id}_by_{bot_username}`，标题：`【群名】的名言集`；
  2. **感知与扩容**：每次执行 `qs` 前检查当前卷张数，若 `>= 120`，自动探测并切换到下一个卷号；
  3. **第 2 卷**：`g_{clean_id}_2_by_{bot_username}`，标题：`【群名】名言集 Vol.2`；
  4. **后续依次类推**：自动新建 `Vol.3`、`Vol.4`……容量物理无上限；
  5. 每次 `qs` 成功后发出的链接和 Inline 按钮，**精准绑定当前最新一卷的链接**，群友一键添加最新卷。

### 1.6 Telegram Premium 会员名字 Emoji 状态图标与彩色名字规范（爸爸明确纠正）
- **核心诉求**：贴纸中用户名字右侧佩戴的 Telegram Premium 专属动态/静态状态图标（Emoji Status），以及会员专属彩色昵称；
- **Bot API 避坑（关键）**：
  - 普通 `User` 或 `Message.from_user` **绝对不携带 `emoji_status`**！
  - **必须调用 `await bot.get_chat(user_id)`** 获取完整的 `ChatFullInfo`；
  - 提取其中的 `chat.emoji_status_custom_emoji_id`（状态图标的文档 ID）与 `chat.accent_color_id`（会员彩色名字色号）；
  - 构造 `from` 对象：
    ```json
    {
      "id": user_id,
      "name": user_name,
      "emoji_status": "6100538209702257662",
      "color_id": 0
    }
    ```
  - quote-api 会自动调取官方 `getCustomEmojiStickers` 获取矢量素材，并在群友名字右侧 1:1 绘制状态图标；
  - **10 分钟内存缓存**：将 `emoji_status_id`、`color_id` 与头像缓存 10 分钟，兼顾超高保真与毫秒级出图。

### 1.7 身份头衔彩色标签（群主紫、管理绿、头衔灰）规范
底层 quote-api 渲染引擎已内置完整的 Telegram 原生色值，传递 `senderTag` 即可触发：
- **👑 群主 (Creator / Owner)**：`{"text": custom_title or "群主", "isAdmin": True, "isCreator": True}` → 渲染为官方**高贵梦幻紫 (`#b18fff`)**；
- **👮 管理员 (Admin)**：`{"text": custom_title or "管理员", "isAdmin": True, "isCreator": False}` → 渲染为官方**清爽亮绿 (`#5ec26f`)**；
- **👤 成员自定义头衔 (Custom Rank)**：`{"text": custom_title, "isAdmin": False, "isCreator": False}` → 渲染为官方**质感中灰 (`#aaaaaa`)**。
- ⚠️ **宁缺毋滥（爸爸明确纠正）**：普通群成员**没有任何头衔时就直接不传 `senderTag`**，引擎会留空不绘制 —— 这是 Telegram 原生行为，是正确结果。**严禁凭空塞一个 `[群员]` 兜底**（原话："没有标签的群成员 你是不是都给他编辑群员了 为什么 没有就没有就行了 不要添加额外的"）。取值顺序 `member.custom_title` → `reply_msg.sender_tag` → `reply_msg.author_signature`，三者皆空且非管理 → `tag_obj = None`。

### 1.8 二级引用气泡 (Nested Quote Reply) 与真实头像注入
- **嵌套引用还原**：只要被制作贴纸的消息本身是在回复别人的发言，就提取父级消息的作者名、发言摘要及富文本实体（Bold, Italic, custom_emoji 等），注入 `replyMessage`，生成带有彩色细线和上一级发言人名的精美引用气泡；
  ⚠️ **不要指望 `reply_target.reply_to_message`**——Bot API 会强制把 `reply_to_message` 内部对象的 `reply_to_message` 剥离为 `None`，直接读它永远是空，`qh` 会静默退化成单人气泡（用户会报「qh 只做了当条发言」）。必须改用**内存回复链索引 + 四路兜底**，完整方案见 `references/qh-nested-reply-bot-api-limitation.md`；
- **`q N` 多条连续发言合并（方向语义见下，别搞反）**：用同一个消息链索引提取连续发言，逐条重建气泡后一次渲染成一张长贴纸。两条已被用户当面纠正过的坑：
  - ⚠️ **别只解析 `count` 却忘了真的用它**（曾被报「q 2 还是只做一条」）；
  - ⚠️ **方向：正数向下、负数向上**（曾被报「你这个数值是向上提取发言的吧，我希望改成向下提取发言」）：
    - `q 3` = 以被回复消息为**起点向下**顺延取 3 条（含自身），时间正序；
    - `q -3` = 以被回复消息为**终点向上**回溯取 3 条（含自身），时间正序；
    - 正则须接受负号 `(?:\s+(-?\d+))?$`，取值后夹到 `±20`；任一方向取不满时向反方向补齐。
- **被引用的贴纸/图片要"复原"，不能只看成 `[贴纸]`**（爸爸明确要求："能直接复原出贴图本身吗？动图的话抓一个定格就可以了"）：
  - 渲染时给气泡注入 `msg.media = {"url": "data:image/png;base64,..."}` + `msg.mediaType = "photo"`，`text` 留空即可，引擎凭 name + media 也能出气泡；
  - **动图/视频贴纸的定格帧零依赖解法**：`Sticker.thumbnail`（旧名 `.thumb`）的 `file_id` 对静态 WebP、Lottie `.tgs`、视频 `.webm` **三种贴纸都返回一张静态预览图**，直接当定格首帧用，**不需要 ffmpeg / rlottie**；静态贴纸用 `sticker.file_id` 原图更清晰；
  - `qh` 的上级引用气泡也带缩略图：给 `replyMessage` 加 `{"media": {"fileId": "<thumb_file_id>"}}`；
  - **配套零流量红线**：消息入库路径只记 `file_id` 字符串（零下载），**渲染贴纸那一刻才 `download_to_memory`**。别在平时的记录逻辑里下载图片，否则群里刷贴纸会持续吃 AWS 出网流量。
- **高保真头像注入**：先通过 `bot.get_user_profile_photos(limit=1)` 下载最高清头像转为 Base64，以 `from.photo.url = "data:image/jpeg;base64,..."` 形式注入，彻底突破 Telegram 隐私屏蔽无头像的痛点。

---

## 2. 视频分享链接交互与零流量分层架构

### 2.1 用户发言保留红线（爸爸明确纠正）
- **绝不删除**：群友在群里粘贴的视频分享消息（抖音、B站、TikTok、小红书等），**原消息 100% 完整保留在群聊中**，禁止调用 `delete_message`；
- **引用回复发出**：Bot 将解析出的视频/图集以 `reply_to_message_id=msg.message_id` 的形式发出，形成清晰的「用户发链接 -> Bot 紧接着回复播放原片」的阅读链路。

### 2.2 多平台视频交付链路与容错避坑
1. **抖音/快手/小红书/微博**：
   - 优先通过 `parsehub` 提取无水印 CDN 直链；
   - 调用 `bot.send_video(video=url)`，Telegram 官方数据中心直接连接 CDN 下载，**服务器出网流量 0 KB**；
   - 若个别视频 CDN 限制直连，自动降级为流式缓冲后上传。
2. **哔哩哔哩 (B站)**：
   - `b23.tv` / `BV` 号经 `curl_cffi` + `wbi` 混音签名 + `X-BILI-SEC-TOKEN` 时序解析出直链；
   - **Range 4MB 分片并发断点容错**：海外 Akamai CDN 单流直接拉取极易出现 `curl: (18) partial file` 断流。必须通过 HTTP Range 拆分成 4MB 小块分片下载，单片设 4 次重试，拼合后以 `send_video(video=buf)` 秒级直传。
3. **TikTok**：
   - 针对 `@username/video/...` 链接，正则提取必须使用 `[^\s\u4e00-\u9fa5<>"'\(\)]+`（切勿使用普通字符集导致截断 `@` 漏判）；
   - 双轨中继：直连被海外机房 IP 拦截时，自动秒切美国 RackNerd 专线 SOCKS5 代理（本地 `127.0.0.1:1081` 永久保活）；
   - 针对微短剧等付费/私密视频（`playAddr` 为空），捕获 `No video formats found` 并直接回复提示用户，严禁静默退出；
   - 收到链接后 0.3 秒内立即以引用形式回复 `⏳ 正在提取解析视频，请稍候...`，发送成功后自动销毁提示。

---

## 3. 极速内存环形缓冲区设计（总结防卡顿规范）

### 3.1 痛点与顾虑
群聊中消息极其高频，若每条群友发言都实时执行 SQLite `INSERT` 与日志写入：
- 长期运行导致数据库文件无限膨胀；
- 频繁的磁盘 I/O 会严重拖慢 Bot 的事件循环，导致响应指令出现卡顿或丢消息。

### 3.2 内存环形队列（Ring Buffer）实现
```python
from collections import deque
from typing import Dict

# 每个群独立维护固定容量内存队列（默认 3000 条）
MEMORY_CACHE: Dict[int, deque] = {}

def save_message(chat_id: int, message_id: int, user_id: int, user_name: str, text: str):
    if not text or not text.strip():
        return
    if chat_id not in MEMORY_CACHE:
        MEMORY_CACHE[chat_id] = deque(maxlen=3000)
    MEMORY_CACHE[chat_id].append({
        "message_id": message_id,
        "user_id": user_id,
        "user_name": user_name,
        "text": text.strip(),
        "created_at": time.time()
    })
```
- **核心优势**：
  1. 平时发言仅在 Python 内存列表追加一条纯文本对象，单次耗时 `< 1 微秒`；
  2. 磁盘 I/O 为 0，大模型 Token 开销为 0；
  3. 仅在群友触发 `/sum` 或 `总结` 的瞬间，从内存列表极速切片送给大模型生成卡片，彻底免除卡顿风险。

---

## 4. 群独立贴图底色定制 (/color)

- **群物理隔离**：每个群拥有独立的配置项 `group_quote_colors["<chat_id>"]`，A 群改色绝不影响 B 群；
- **内置特色预设**：
  - `💖 猛男芭比粉 (#FF1493)`
  - `💜 魅惑梦幻紫 (#7B1FA2)`
  - `⚫ 极夜纯黑 (#000000)`（默认）
  - `⚪ 经典纯白 (#FFFFFF)`
  - `🌃 电报深蓝 (#18222d)`
- **双模配置**：
  - `/color` 唤出带有 ✅ 激活标记的 8 色内联按钮面板，点按即切；
  - 文本快捷指令：`/color 芭比粉`、`/color 紫色`、`/color #FF1493` 快速设定。

---

## 5. 双模群聊成员禁言与解禁风控系统 (/mute & /unmute)

- **权限主体铁律（爸爸明确纠正）**：
  严格限定**仅限以下三类身份有权触发禁言/解禁**：
  1. 👑 **机器人拥有者（爸爸 / Owner ID）**
  2. 🏠 **本群群主（Chat Creator / `ChatMemberStatus.OWNER`）**
  3. ⭐ **拥有者指定人员（通过 `/addvip` 授权的 VIP 用户）**
  ❌ **普通群管理员（Ordinary Administrator）严格无权使用禁言指令**，越权调用将受到友好拦截提醒；普通群友发送一律秒删拦截。
- **豁免与防背刺保护**：
  - 绝对禁止禁言机器人拥有者（爸爸）；
  - 绝对禁止禁言拥有者指定的特权人员（`/addvip`）；
  - 绝对禁止禁言本群群主。
- **双模触发**：长按回复违规发言发 `/mute 10m`，或直接发 `/mute @用户名 1小时`；
- **自然时间智能解析**：支持 `m/分`, `h/小时`, `d/天`, `永久`；
- **解禁机制**：回复发 `/unmute` 或发 `/unmute @用户名` 瞬间解封。

---

## 6. 群聊分级指令菜单与多层作用域隔离规范 (Hierarchical Command Scopes)

### 6.1 业务诉求（爸爸明确规则）
在群聊中输入 `/` 时，**全群只有拥有者（爸爸）一人能看到全量 15 条完整管理控制台指令**，其他人只能看到其所属权限内的精简指令，彻底杜绝指令越权与视觉杂乱。

### 6.2 Telegram 官方作用域链优先级解析
Telegram Bot API 判定命令菜单的展示优先级为：
1. `BotCommandScopeChatMember(chat_id, user_id)`（最高优先级，精准针对某个群里的某个人）
2. `BotCommandScopeChatAdministrators(chat_id)`（某个群的管理员）
3. `BotCommandScopeAllChatAdministrators()`（所有群的管理员）
4. `BotCommandScopeAllGroupChats()`（所有群的普通群成员）
5. `BotCommandScopeDefault()`（兜底默认）

### 6.3 严格按角色下发的三层菜单矩阵
1. **普通群友 (`BotCommandScopeAllGroupChats()`)**：
   仅下发 4 条日常群聊指令：
   - `/help` - 📖 查看群聊使用指南
   - `/sum` - 📋 智能总结发言
   - `/ai` - 🤖 AI 智能问答
   - `/q` - 💬 制作名言气泡贴纸
2. **普通管理员 (`BotCommandScopeAllChatAdministrators()`)**：
   下发 7 条管理指令（加上贴纸入库、贴纸删除与底色定制，**不含禁言与授权**）：
   - `/help`, `/sum`, `/ai`, `/q`, `/qs`, `/qd`, `/color`
3. **本群群主与 VIP 特权人员 (`BotCommandScopeChatMember(chat_id, uid)`)**：
   下发 10 条指令（额外解锁成员违规禁言风控与本群功能开关）：
   - `/help`, `/sum`, `/ai`, `/q`, `/qs`, `/qd`, `/color`, `/settings`, `/mute`, `/unmute`
4. **机器人拥有者（爸爸）(`BotCommandScopeChatMember(chat_id, OWNER_ID)`)**：
   **在所有授权群聊中独享全套 16 条完整控制台**：
   - `/help`, `/sum`, `/ai`, `/q`, `/qs`, `/qd`, `/color`, `/settings`, `/mute`, `/unmute`, `/auth`, `/unauth`, `/addvip`, `/delvip`, `/viplist`, `/groups`
   - 私聊作用域 (`BotCommandScopeChat(OWNER_ID)`) 额外 + `/settings`（跨群遥控开关大盘）；陌生人私聊仅 `/help`。
5. **动态热刷新机制**：
   每次执行 `/auth` 授权新群或执行 `/addvip` 绑定特权人员时，自动调取 `set_my_commands` 为对应群聊与用户实时刷入私有作用域，免去重启等待。
