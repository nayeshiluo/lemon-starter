# 多平台分享链接解析：实测路径、投递方式与防盗链排坑

> 适用场景：群聊机器人自动识别群友粘贴的短视频/图集分享链接并投递回群。
> 本文沉淀自实战全链路验证结果；未打通或不建议的方案明确标注。

---

## 0. 核心交互红线与用户规则（爸爸明确纠正）

1. **视频链接的发言严禁删除**：
   群友粘贴视频分享链接（抖音、B站、TikTok、快手、小红书等）时，**该发言 100% 完整保留在群聊中**，切勿调用 `delete_message`；
2. **即时状态反馈（绝不能静默无响应）**：
   检测到视频分享链接后，Bot 必须在 **0.3 秒内立即以引用形式回复状态提示**（`⏳ 正在提取解析视频，请稍候...`）；
   - 解析并发送成功后，自动调用 `status_tip.delete()` 销毁该提示；
   - 若解析失败或受限，原地编辑提示明确说明原因（如“该内容为付费微短剧/私密限制”），并于 8 秒后自动销毁；
   - 彻底避免下载或解析耗时 20~30 秒导致群友误判为“Bot 卡死没反应”；
3. **引用回复投递**：
   解析出的视频/图集必须附带 `reply_to_message_id=msg.message_id`，以回复原链接发言的形式发出，保持上下文秩序清晰；
4. **URL 提取正则避坑（必须包含 `@` 与参数）**：
   - 常见失误：使用 `[a-zA-Z0-9_\-\.\/\?&=%]+` 匹配路径，漏掉 `@` 导致所有形如 `tiktok.com/@user/video/...` 的链接直接返回空，Bot 看起来毫无反应；
   - 标准正则：`r"https?://(?:[a-zA-Z0-9_\-]+\.)?(?:douyin\.com|iesdouyin\.com|tiktok\.com|kuaishou\.com|xiaohongshu\.com|xhslink\.com|pipix\.com|twitter\.com|x\.com|weibo\.com|weibo\.cn|bilibili\.com|b23\.tv|bili2233\.cn|youtube\.com|youtu\.be)/[^\s\u4e00-\u9fa5<>\"\'\(\)]+"`；
5. **第一步永远是先确认素材本身是否存在与权限状态**：
   - 用户分享的 TikTok 短链（`/t/`）、B站短链（`b23.tv`）经常出现**源视频已被作者删除、封禁、或为付费短剧**的情况；
   - **TikTok 存活与权限判定**：
     - 请求 `https://www.tiktok.com/player/api/v1/items?item_ids=<id>`，返回 `{"code":"ok"}` = 存活；`{"code":"nil_core_data"}` = **已删除/私密**；
     - 若 yt-dlp 报 `No video formats found` 且网页数据中 `playAddr: ""`、`height: 0`，通常为 **TikTok 官方付费微短剧（Drama 剧集）或仅限手机 App 内观看**，平台根本未向 Web 端下发媒体流；
   - **通用诊断**：用一个已知长期存在的测试样本（如 scout2015）试跑，若样本成功，证明代码环境全通，是用户链接指向的源素材本身受限。

---

## 1. 平台实测路径矩阵与交付方式

| 平台 | 解析引擎 | 视频投递方式 | 实测状态 |
|---|---|---|---|
| **抖音** `douyin.com` / `iesdouyin.com` | `parsehub` | 直接传 CDN URL（Telegram DC 直取，0 服务器流量） | ✅ 1080P 秒级直推 |
| **哔哩哔哩** `bilibili.com` / `b23.tv` | curl_cffi + wbi 签名 + 视频页 cookie | 内存流式拉取（带 Referer）→ `send_video(video=buf)` | ✅ 24MB 视频 26s 全通 (msg 9) |
| **TikTok** `tiktok.com` / `vm.tiktok.com` | `yt-dlp --impersonate chrome` | 原生下载 mp4 字节流 → `send_video(video=buf)` | ✅ 2MB 视频 1.8s 全通 (msg 10) |
| **快手 / 小红书 / 微博 / 皮皮虾** | `parsehub` | 视频传 URL；图集传 `InputMediaPhoto` 组 | ✅ ParseHub 内置支持 |
| **YouTube** | yt-dlp | 需 JS 运行时（deno）+ 账号 cookies | ❌ 机房 IP 易受阻，优先级后置 |

---

## 2. 哔哩哔哩：海外机房 IP 攻坚与投递（✅ 全链路验证通过）

B站对海外机房 IP（如 AWS 新加坡/美西等）实施了严格防护，必须按照严格时序攻破：

| 防护层 | 典型报错 | 核心解决方案 |
|---|---|---|
| ① TLS/IP 指纹风控 | `HTTP 412 Precondition Failed` | 必须使用 `curl_cffi` 模拟 Chrome 真实指纹（yt-dlp / requests 会直接被拦截） |
| ② 接口签名 | `wbi/view` 与 `playurl` 报签名错误 | 实现官方混音键表（64 位置换）+ `wts/w_rid` MD5 签名 |
| ③ Cookie 时序陷阱 | `playurl` 必返 412（无直链） | **必须先访问视频页获取 `X-BILI-SEC-TOKEN`**，顺序不可乱 |
| ④ CDN 防盗链 | 直接给 Telegram URL 报 `403` / `Wrong type` | 见下方 2.2 投递规范 |

### 2.1 签名与 Cookie 时序规范
```python
session = creq.Session(impersonate="chrome")
# 1. 访问首页拿到基础 buvid3
session.get("https://www.bilibili.com/", timeout=20)
# 2. 访问视频页拿关键 X-BILI-SEC-TOKEN（即便这步返回 412 也已写入 cookie）
session.get(f"https://www.bilibili.com/video/{bvid}/", headers={"Referer": "https://www.bilibili.com/"}, timeout=20)
# 3. 访问 nav 接口提取 wbi keys (img_key, sub_key)
nav = session.get("https://api.bilibili.com/x/web-interface/nav", headers={"Referer": "https://www.bilibili.com/"}, timeout=20).json()
# 4. wbi/view 提取 cid
# 5. player/playurl（旧版）或 player/wbi/playurl 获取 durl[0].url
```

### 2.2 Telegram 投递避坑：Telegram Bot API URL 校验限制与 Range 分片下载
- **陷阱 1（URL 协议拦截）**：Telegram Bot API 的 `send_video(video=<url>)` **强校验 URL 协议与格式**。若传入原生 IP + 非标端口（如 `http://198.44.46.38:8899/?u=...`），Telegram 不会向目标发起任何请求，而是直接秒报：
  `telegram.error.BadRequest: Wrong type of the web page content`。
- **陷阱 2（单连接海外 CDN 断流）**：直接单流 `iter_content` 拉取 B站 Akamai 直链大视频（>20MB）时，跨国 TCP 容易被对端主动重置，抛出：
  `curl_cffi.curl.CurlError: (18) end of response with XXXXX bytes missing`。
- **最佳投递实现（HTTP Range 4MB 分片容错下载 + 上传）**：
  先用 `Range: bytes=0-0` 请求探测直链的 `Content-Range` 总字节数，然后按 4MB 分片循环拉取，每个分片自带 4 次独立重试，拼接进 `io.BytesIO` 后调用 `send_video`：
  ```python
  def _download_range_chunks(url: str, referer: str = "https://www.bilibili.com/", chunk_size: int = 4 * 1024 * 1024) -> Optional[bytes]:
      s = creq.Session(impersonate="chrome")
      h = s.get(url, headers={"Referer": referer, "Range": "bytes=0-0"}, timeout=20)
      cr = h.headers.get("content-range")
      total = int(cr.split("/")[-1]) if cr else None
      buf = io.BytesIO()
      start = 0
      while total and start < total:
          end = min(start + chunk_size - 1, total - 1)
          for attempt in range(4):
              try:
                  r = s.get(url, headers={"Referer": referer, "Range": f"bytes={start}-{end}"}, timeout=30)
                  if r.status_code in (200, 206):
                      buf.write(r.content)
                      start = end + 1
                      break
              except Exception:
                  time.sleep(1.0)
          else:
              return None
      return buf.getvalue()
  ```
  实测速度：AWS 新加坡拉取 24.9MB B站视频，Range 分片并发重试 100% 稳定交付，无任何断流。

---

## 3. TikTok：JS Challenge 与本地原生提取（✅ 全链路验证通过）

### 3.1 为什么直接抓取与第三方公共接口容易崩？
- **ParseHub 崩溃**：ParseHub 的 TikTok 模块依赖从网页提取 `__UNIVERSAL_DATA_FOR_REHYDRATION__`，未登录状态下 TikTok 官方已不再在 HTML 中注入 `playAddr` 字段（返回空或 10204），导致 ParseHub 抛出 `无法从页面提取`；
- **第三方公共 API（TikWM / Savetik 等）**：频繁遭遇 Cloudflare 403 阻断或限流，极不稳定；
- **CDN 直链带签名绑定**：TikTok 视频直链强校验客户端网络指纹与 IP，将 URL 直接扔给 Telegram 会触发 403。

### 3.2 终极稳定解法：yt-dlp + curl_cffi 原生 Impersonate 与双轨美国专线中继
安装依赖：
```bash
uv pip install curl_cffi
```
执行提取并下载（双轨自愈策略）：
- **第一轨（直连）**：优先使用本地网络直连解析；
- **第二轨（专线代理自愈）**：若遇 `blocked from accessing this post`、`unable to extract universal data` 或超时，自动无缝重试挂载美国专线（如 RackNerd SOCKS5 `rn-tunnel.service`，监听 `127.0.0.1:1081`），瞬间突破机房 IP 拦截：
```python
cmd = [
    ytdlp_path,
    "--impersonate", "chrome",
    "--no-warnings",
    "--no-playlist",
    "-f", "b[ext=mp4]/best",
    "--write-info-json",
    "-o", out_tmpl,
]
if use_proxy:
    cmd.extend(["--proxy", "socks5h://127.0.0.1:1081"])
cmd.append(expanded_url)
proc = await asyncio.create_subprocess_exec(*cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
```
- **核心优势**：
  1. `yt-dlp` 内置 TikTok JS Challenge 求解器，配合 `curl_cffi` 能够完全模拟真实浏览器通过滑块与指纹校验；
  2. 自动下载为标准的 H.264/MP4 视频文件；
  3. 读取文件字节注入 `io.BytesIO` 后调用 `send_video`，100% 成功交付；
  4. 若遇平台付费短剧或受限内容（`No video formats found`），返回结构化错误提示反馈用户，绝不静默假死。
