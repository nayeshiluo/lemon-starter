# state.db 损坏恢复

当 Hermes `state.db`（SQLite）损坏时，`session_search` 和群聊总结查询会失败。使用 SQLite 的 `.recover` 命令可以挽救大部分数据。

## 诊断

```bash
# 检查状态
sqlite3 ~/.hermes/state.db "PRAGMA integrity_check;"
# 输出: "database disk image is malformed" 或大量 btree 错误 → 损坏
```

## 恢复步骤

```bash
cd ~/.hermes

# 1. 列出所有备份文件
ls -la state.db*

# 2. 尝试用 .recover 恢复
# 注意：--ignore-freelist 跳过有问题的空闲列表页
sqlite3 state.db ".recover --ignore-freelist" 2>/dev/null \
  | grep -v "sqlite_sequence\|CREATE TABLE.*already exists\|CREATE INDEX.*already exists" \
  | sqlite3 state.db.recovered

# 3. 验证恢复结果
sqlite3 state.db.recovered "PRAGMA integrity_check;"
# 期望输出: "ok"

# 4. 替换损坏的数据库（可选，先备份原文件）
cp state.db state.db.corrupted-$(date +%Y%m%d_%H%M%S)
mv state.db.recovered state.db
```

## 关键点

- `.recover --ignore-freelist` 比纯 `.recover` 更宽容，跳过损坏的 freelist 页
- 重建时 `CREATE TABLE/INDEX already exists` 是正常错误，用 `grep -v` 过滤即可
- `sqlite_sequence` 是内部表名，`.recover` 输出中会出现，grep 过滤掉
- 恢复后的数据库通过 `PRAGMA integrity_check` 即为可用，但丢失的数据量取决于损坏程度
- 备份文件（`state.db.bak-*`）也可能同样损坏，优先尝试最新的

## 为什么损坏

常见原因：
- 网关在写入时异常退出（被 kill、OOM、磁盘满）
- WAL 文件与主数据库不同步
- 磁盘 I/O 错误（AWS EBS 瞬态问题）

## 替代方案 A：使用 state_recovered.db（当 .recover 已执行过）

如果 `~/.hermes/state_recovered.db` 存在且 `PRAGMA integrity_check` 返回 `ok`，可以直接用它作为只读查询的来源，无需再次执行 `.recover`：

```python
import sqlite3, time, re

# 优先尝试 state_recovered.db（可能是上一次恢复的结果）
db_path = '/home/ubuntu/.hermes/state_recovered.db'
if not sqlite3.connect(db_path).execute("PRAGMA integrity_check").fetchone()[0] == 'ok':
    # 回退到 state.db
    db_path = '/home/ubuntu/.hermes/state.db'
```

注意：`state_recovered.db` 是只读快照，不会自动更新。网关运行时写入的新数据不会出现在其中。它只适合读取历史数据，不适合做定时任务等需要最新数据的场景。

## 替代方案 B：从 request_dump JSON 文件恢复上下文

当 `state.db` 和 `state_recovered.db` 都不可用时，`~/.hermes/sessions/request_dump_*.json` 文件记录了完整的 API 请求/响应链路，包括：
- 完整系统提示词
- 用户消息（含所有上下文）
- 助手的推理过程（reasoning_content）
- 工具调用定义、参数和结果
- 触发错误时的完整载荷

**寻找正确的 dump 文件：**
dump 文件名格式为 `request_dump_<session_id>_<timestamp>.json`。session_id 可从日志或 `sessions` 表获取。示例：
```
request_dump_20260813_035904_4c765b7c_20260814_091541_822500.json
                              ↑ 时间戳                 ↑ 微秒
```

**使用 read_file 读取（安全，不触发网关保护）：**
```python
# 在 execute_code 中可用
from hermes_tools import read_file, search_files

# 查找特定 session 的 dump 文件
results = search_files(
    pattern='request_dump_<session_id>*',
    path='~/.hermes/sessions/',
    target='files'
)

# 读取 dump 文件内容
content = read_file(results['matches'][0]['path'], limit=100)
```

**解析 dump 文件结构：**
```json
{
  "timestamp": "2026-08-14T09:15:41.822465",
  "session_id": "20260813_035904_4c765b7c",
  "reason": "non_retryable_client_error|max_retries_exhausted",
  "request": {
    "method": "POST",
    "url": "...",
    "body": {
      "model": "deepseek-v4-flash",
      "messages": [
        {"role": "system", "content": "..."},
        {"role": "user", "content": "..."},
        {"role": "assistant", "content": "...", "reasoning_content": "...", "tool_calls": [...]},
        {"role": "tool", "name": "...", "content": "..."}
      ]
    }
  }
}
```

**注意：**
- dump 文件在 gateway 运行期间也**可读**（read_file 工具不受网关保护机制阻挡）
- 但不建议在 `execute_code` 中直接用 `json.loads`——dump 文件内容可能很大（>100KB），read_file 的分页读取更安全
- dump 文件可能包含 API key 等敏感信息，不要在回复中直接输出
- dump 文件是按请求触发的，不是每个请求都有 dump（只有出错/超时时触发）
- 同一 session 可能有多个 dump 文件，按时间戳取最新

## 在群聊总结中使用恢复后的数据库

```python
import sqlite3, time, re

# 优先尝试恢复后的数据库
db_path = '/home/ubuntu/.hermes/state_recovered.db'
try:
    conn = sqlite3.connect(db_path)
    ok = conn.execute("PRAGMA integrity_check").fetchone()[0]
    if ok != 'ok':
        db_path = '/home/ubuntu/.hermes/state.db'
except:
    db_path = '/home/ubuntu/.hermes/state.db'

chat_id = '-1004495899387'  # 替换为实际群 ID
now = time.time()
two_hours_ago = now - 2 * 3600

conn = sqlite3.connect(db_path)
cur = conn.cursor()

# 先查会话
cur.execute("""
    SELECT id, session_key, message_count, last_activity_at 
    FROM sessions WHERE chat_id=? ORDER BY last_activity_at DESC
""", (chat_id,))
sessions = cur.fetchall()

if sessions:
    sid = sessions[0][0]
    # 查时间窗口内的用户消息
    cur.execute("""
        SELECT timestamp, content, observed
        FROM messages
        WHERE session_id=? AND timestamp > ? AND role='user'
        ORDER BY id
    """, (sid, two_hours_ago))
    msgs = cur.fetchall()
    # 解析 [发送者|user_id] 前缀
    for ts, content, observed in msgs:
        m = re.match(r'^\[([^\]]+)\]', content or '')
        name = m.group(1).split('|')[0] if m else '?'
        body = content[m.end():].strip() if m else (content or '')
        # ...
```