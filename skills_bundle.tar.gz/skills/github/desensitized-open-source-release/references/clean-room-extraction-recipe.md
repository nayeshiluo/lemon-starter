# 实例：群霸「总结 + 日报」脱敏开源（2026-11）

从生产仓 `~/lemon-group-bot`（群霸双 Bot，含贴纸/点歌/面板，3000+ 行 handlers）抽出总结与日报子系统，
产出独立仓库 `nayeshiluo/tg-summary-bot`（24 个文件，MIT）。

## 边界判定（只抽这两个功能）

读 import 闭包后保留：

| 文件 | 职责 |
|---|---|
| `bot.py` | 轮询入口、handler 注册、指令菜单 |
| `config.py` | 环境变量 + `state.json` 原子读写（无任何默认 ID） |
| `storage.py` | 单文件 SQLite（WAL），消息存取与清理 |
| `args.py` | `/sum` `/autosum` `/autodaily` 参数解析 |
| `summarize.py` | 取数后的清洗、来源归一、日报归属校验、分片 |
| `scheduler.py` | 槽位判定、重试、定时循环 |
| `prompts.py` | 总结 / 日报提示词（原文照抄保质量） |
| `services/llm.py` | 多节点兜底、熔断、超时预算 |
| `services/rich.py` | 富文本清洗 + HTML 降级 |
| `services/delivery.py` | 投递与「结果不确定不重发」 |
| `handlers/messages.py` | 群消息采集 |
| `handlers/commands.py` | 指令与面板 |

切掉：贴纸（`q`/`qs`/`qd`）、点歌、`/settings` 全量功能矩阵、多 Bot 分实例（`BOT_ID`）、
`summary_claims` 持久化 claim + heartbeat（新项目简化为进程内重试状态）、`blocking_io`。

## 关键改写决策

1. **`config_{BOT_ID}.json` → 单 `state.json`**：只服务一个 bot 身份，去掉多 bot 键。
2. **双写内存 deque + SQLite → 纯 SQLite**：`UNIQUE(chat_id, message_id)` 取代 `(bot_id, chat_id, message_id)`。
3. **保留原生富文本通道**：`bot.do_api_request("sendRichMessage", api_kwargs={"chat_id":…, "rich_message": {"markdown": chunk}})` 才有真 `<details>`；`<blockquote expandable>` 只是降级。
4. **模糊投递不重发**：`BadRequest` 是 PTB `NetworkError` 子类，但它代表「确定被拒」→ 降级 HTML；
   `NetworkError`/超时代表「可能已送达」→ 抛 `DeliveryUncertain`，定时任务记 `uncertain` 且禁止补发。
5. **日报归属是硬闸门**：每个话题恰好一条 `[来源]`，`msg_id` 必须在本窗口存在，纯媒体源拒绝，
   标题+正文所有数字必须是「源消息 ∪ 直接父消息」数字的子集；否则回退原文摘要或丢条。
6. **槽位幂等**：`daily:YYYY-MM-DD_HH:MM` 与 `interval:<秒>:<bucket>`，bucket 由 `last_run_timestamp + 秒` 推出，桶不匹配即作废，防重启重复发。

## 验证网

- `tests/test_offline.py`：45 项。含参数解析边界、富文本转义与 `<details>`→`<blockquote>` 降级、
  `send_rich_or_html` 的三条投递分支（BadRequest 降级 / NetworkError 抛 uncertain / 分片中途失败）、
  槽位 due 判定（已跑过跳过、跨过时间点触发、过期槽位不补）。
- `scripts/selftest.py`：本地 `HTTPServer` 假 LLM，夹具故意塞 `msg_id 999`（编造来源）和「88 倍」（无据数字），
  断言这两条被丢弃，并检查 `#总结`/`#日报` 标签、无思考残留、条目数 3~8。

## 实际命令

```bash
# 扫描（先删运行期文件）
rm -f data/messages.db data/state.json
find . -name __pycache__ -type d -prune -exec rm -rf {} +
.venv/bin/python scripts/verify_desensitization.py . --private-file /tmp/sb_private.json

# 提交与推送
git init -q -b main && git add -A && git commit -m "feat: ..."
git remote add origin user@example.com:nayeshiluo/tg-summary-bot.git

# 远端已有 Initial commit → rebase，README 冲突取本地版
git fetch origin main
git rebase origin/main
git checkout --ours README.md && git add README.md
GIT_EDITOR=true git rebase --continue     # 否则报 Terminal is dumb, but EDITOR unset
git push -u origin main

# 克隆回验
git clone -q user@example.com:nayeshiluo/tg-summary-bot.git /tmp/clone-check
cd /tmp/clone-check && python3 -m venv .venv && .venv/bin/pip install -q -r requirements.txt
.venv/bin/python -m unittest discover -s tests -q
.venv/bin/python scripts/selftest.py
```

## 教训

- 第一版占位 Token 写成 `<YOUR_TELEGRAM_TOKEN>`，形状像真 token，改成 `REPLACE_WITH_YOUR_TOKEN`。
- `git rebase --continue` 在非交互环境必须先设 `GIT_EDITOR=true`，否则卡在提交信息编辑。
- 建仓需要 API token；本次 `~/.hermes/.env` 里的 `GITHUB_TOKEN` 已 401，SSH 仍可推。
  正确做法：先 `curl -H "Authorization: token $T" https://api.github.com/user` 实测，不通就请用户建空仓，
  不要反复重试或改去装 `gh`。
