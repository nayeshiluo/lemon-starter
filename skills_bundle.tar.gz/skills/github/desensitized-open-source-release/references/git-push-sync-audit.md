# Bit 仓库同步状态审计与安全推送

面向「用户问『这些项目都上传 GitHub 了吗』」和「批量推本地提交」两类任务。
只读审计优先；推送属于外部副作用，先扫描后执行。

> 本文所有示例用占位符，**不要写入真实凭据、群 ID、私有域名或主机名**。

## 一、先定方向（最容易出错的一步）

```bash
git -C <repo> fetch origin          # 本地 origin ref 常常过期，不 fetch 结论必错
git -C <repo> status -sb | head -1  # 唯一无歧义的口径
git -C <repo> rev-list --left-right --count origin/main...HEAD
```

`rev-list --left-right --count A...B` 输出为 `A独有 \t B独有`：

| 输出 | 含义 | 该做什么 |
|---|---|---|
| `7\t0` | **本地落后 7** | `git merge --ff-only origin/main` |
| `0\t5` | **本地待推 5** | 扫描后 push |
| `1\t1` | 分叉 | rebase 后 push（见三） |

**实测踩坑**：把 `7\t0` 读成「领先 7」，向用户报了相反的同步方向。写进任何报告前，
都用 `status -sb` 的 `[ahead N, behind M]` 复核一次。

`git status -sb` 只报 `## main` 而没有 upstream，说明该分支**没设远端跟踪**，
既不是「已同步」也不是「已推送」——要显式 `git branch -u origin/main` 或单独判断。

## 二、判定可见性（决定能否携带业务标识）

匿名查询即可，不需要 token：

```bash
curl -s -o /dev/null -w '%{http_code}' https://api.github.com/repos/<owner>/<repo>
# 200 = 公开可读；404 = 私有或不存在
```

- **公开仓库**：除凭据外还要扫群/频道 ID、内部域名、主机别名、真实用户 ID。
- **私有仓库**：凭据仍然要扫（用户的规则是凭据永不硬编码上云），业务 ID 风险较低。

注意 404 有两种可能（私有 / 不存在），需要结合 `git ls-remote` 是否成功来区分。

## 三、最高危：本地落后时推送会把已删除的凭据重新推上去

**真实事故形态**：本地 HEAD 的历史里 `.env.example` 含真实 API 凭据字面量；
远端早已有一个「移除真实凭据」的清理提交。此时本地若还有自己的新提交，
直接 push 会被 non-fast-forward 挡下（运气），而 rebase 后推——如果只 rebase 不看内容——
可能把旧真值重新带回可达历史。

固定流程：

```bash
git fetch origin
git log --oneline HEAD..origin/main                    # 远端多了什么，通常就有脱敏修复
git log --oneline -S'<真值片段>' -- .env.example        # 真值出现在哪些提交
git bundle create /tmp/<repo>-before-$(date +%s).bundle --all   # 历史操作前必备安全网
git rebase --autostash origin/main                     # 工作区脏时用 autostash
git show HEAD:.env.example | grep -E 'API|TOKEN|SECRET' # 逐字确认已变占位符
git push origin main
```

要点：

- `--autostash` 结束时输出 `Applied autostash`，本地未提交改动会回来，不需要手工 stash。
- `.gitignore` 冲突几乎总是两侧各加了不同规则 → **两边都保留**，不要 `--ours/--theirs` 二选一。
- 若 rebase 后 `git log -S` 仍能在 `HEAD` 可达历史里找到真值，说明清理提交没被包含，
  停下来重新确认 base，不要继续推。
- `git bundle create --all` 后用 `git bundle verify <file>` 确认 `records a complete history`。

## 四、扫描范围是「未推送的 diff」，不是全仓库

```bash
git diff origin/main..HEAD | grep -nEi \
 '(sk-[A-Za-z0-9]{16,}|ghp_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{20,}|AKIA[0-9A-Z]{16}|xox[baprs]-[A-Za-z0-9-]{10,}|[0-9]{8,10}:AA[A-Za-z0-9_-]{30,}|-----BEGIN (RSA |EC |OPENSSH )?PRIVATE KEY-----|BOT_TOKEN\s*=\s*[0-9]{6,}|CONFIG_MASTER_KEY\s*=\s*[0-9a-f]{32,})'
```

**判定规则——命中不等于泄露**：

| 形态 | 判定 |
|---|---|
| `os.environ.get("CONFIG_MASTER_KEY")` | 安全，是键名 |
| 注释/文档里的键名 | 安全 |
| `<PRIVATE_IDENTIFIER>`、`example.com`、`127.0.0.1` | 安全，是占位符 |
| `.env.example` 里 40 字符 `API_HASH` 字面量 | **泄露** |

`.env.example` 是头号漏点：它不像 `.env` 那样被 ignore，却常被当成模板塞进真值。
压缩包类提交要解开再判：`tar tzf x.tgz` 列敏感文件名 → `tar xzf` 抽读，
不能只看文件名就放行（也可能相反：文件名敏感但内容已脱敏）。

## 五、验收：远端 HEAD，而不是 push 输出

```bash
l=$(git rev-parse HEAD | cut -c1-8)
r=$(git ls-remote origin refs/heads/main | cut -c1-8)
[ "$l" = "$r" ] && echo MATCH || echo MISMATCH
```

全部仓库 `MATCH` 才能说同步成功。`->` 行只代表请求发出。

## 六、环境与授权边界

- HTTPS remote 依赖 `gh` credential helper 但 `gh` 未安装 → `fatal: could not read Username`。
  改 SSH：`git remote set-url origin user@example.com:<owner>/<repo>.git`。
- **SSH 能推已有仓库，不能建新仓库**；建仓需要 API token。
- token 返回 401 即为失效：不要反复重试、不要装 `gh`、不要翻历史备份找旧 token。
  改为「归档进已有私有仓库 + bundle 双备份」，并把缺口如实告知用户。
- 无独立分发仓库的项目，遵循目标仓 `SYNC_POLICY.md`：私有镜像必须同窗更新、不得滞后。
  归档时给全补丁（相对上游基线的完整版 + 相对当前上游的增量版）、版本锚点、
  回滚镜像 ID，**不含 data/、.env、数据库、compose 里的明文密钥**。

## 七、报告口径

- 区分「远端有最新代码（正常）」「本地有提交未推（待推）」「本地落后（该拉）」三种状态，
  不要用一个「没上传」概括。
- 先给结论表，再给风险项（凭据、公开仓库、未提交改动数量），最后给下一步选择。
- 自己读反过方向、判断错过的，直接在报告里认，不要让用户依赖错误结论。
