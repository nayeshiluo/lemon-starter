# 整批纳管无版本控制目录 → 私有镜像（2026-11-06 实测）

配套 SKILL.md §9。场景：本机二十几个源码目录从没进过 git，按 `SYNC_POLICY`
（无独立分发仓库的项目必须进私有镜像）统一纳管。比单项目脱敏多两道工序：
**先分类**，再脱敏。

## 第 0 步：目录四分类

```bash
# 收集已镜像名单：tr 必须加，ls 输出带换行会让后续 case 匹配永远失败
MIRRORED=""
for m in */; do
  m="${m%/}"
  [ -d "$m/projects" ] && MIRRORED="$MIRRORED $(ls "$m/projects" 2>/dev/null | tr '\n' ' ')"
done

for d in */; do
  d="${d%/}"
  # worktree / submodule 的 .git 是文件不是目录，-d 会漏判
  git -C "$d" rev-parse --git-dir >/dev/null 2>&1 && continue
  n=$(find "$d" -maxdepth 1 -type f \( -name '*.py' -o -name '*.js' -o -name '*.go' \
        -o -name 'package.json' -o -name 'pyproject.toml' \) 2>/dev/null | wc -l)
  [ "$n" -eq 0 ] && continue
  case " $MIRRORED " in
    *" $d "*) echo "[已镜像] $d" ;;
    *)        echo "[真孤儿] $d  $n 个源文件" ;;
  esac
done
```

本次实测 24 个候选里：8 个已镜像、16 个真孤儿、其中 4 个是产物/依赖目录 ——
最终真正纳入 12 个。

**判据坑：** `lemon-emby-bot-pr1-view/.git` 只有 75 字节、内容是 `gitdir: ...`，
`[ -d .git ]` 判 false 于是误报成孤儿。**判断「是不是 git 仓库」一律用
`rev-parse --git-dir`，不要看 `.git` 是文件还是目录。**

## 第 1 步：rsync 白名单式排除

```bash
EXCL=(--exclude=.venv --exclude=venv --exclude=env --exclude=node_modules
      --exclude=__pycache__ --exclude='*.pyc' --exclude=.git
      --exclude='*.session' --exclude='*.session-journal' --exclude='*.log'
      --exclude='*.zip' --exclude='*.tar.gz')

rsync -a "${EXCL[@]}" "${extra[@]}" "$SRC/$name/" "$DST/$name/"
```

按项目追加的 `extra` 示例：

- `--exclude='settings.json'`（含 bot token + owner_id）
- `--exclude='bindings.json' --exclude='snapshot.json'`（CF Worker 绑定，含 API token）
- `--exclude='backups' --exclude='dist' --exclude='build'`
- `--exclude='*.lock' --exclude='*.json'`（只留脚本，状态文件不留）

**`cp -a` 不要用**：它会连 `.venv`、`node_modules`、`dist` 一起搬。本次 12 个目录
源侧 280M+ 依赖与产物被挡在门外，净入 **24M / 251 文件**。

**产物目录单独判断**：`covers/`（123M 封面）、`ocr_output/`（13M）看着像资产，
其实是可再生派生物，进仓库只会让每次 clone 变慢 —— 不纳入，在索引里写明原因。

## 第 2 步：凭据四分类（本次血案）

**事故复盘**：截断输出里出现 `471e...` 开头的串，据此写
`471e[0-9A-Za-z_-]{20,}` 去"清理"，**一次删掉 19 个正常部署脚本**
（`deploy_b.py`、`opt1_placement.py`、`d1.py`、`final_admin.py` …）。
真相是 `471eb899…` 是 **Cloudflare Account ID**，正则宽到把同前缀的无关文件全吃了。

| 类型 | 真实例子 | 处置 |
|---|---|---|
| 真密钥 | `cfut_…`、`sk-…`、`ghp_…`、`BEGIN PRIVATE KEY` | 改读环境变量 |
| 资源标识 | CF Account ID / Zone ID / D1 database ID | 改读环境变量 |
| 完整性校验 | `hashlib.md5(code) == '32hex'`、`SHA256SUMS` | **保留** |
| 本地路径 | `KEY = "/home/ubuntu/.ssh/<name>"` | 保留（路径 ≠ 内容） |

32 位 hex 尤其容易误判：本次全目录 9 处命中，**4 处是 md5 校验、1 处是
`h == '32hex'` 形式的哈希比对、只有 Zone ID 需要处理**。按上下文定性，不按形状。

三条铁律：

1. **正则锚定完整凭据格式**（`cfut_[A-Za-z0-9_-]{20,}`），
   禁止「前缀 + 任意字符」——`471e[0-9A-Za-z_-]{20,}` 就是反面教材。
2. **先出 dry-run 报告再改文件**：打印「文件:行号 + 分类 + 值长度」，人看过再动手。
3. **删错了立刻从源 rsync 恢复**。恢复幂等、修补不幂等；本次就是 rsync 重铺
   `cf-audit` 后重做的。

## 第 3 步：脱敏保留可运行性

含 token 的脚本是可复用资产，**删掉等于自断工具**。改成环境变量：

```python
# ① 变量赋值
DEPLOY_TOKEN = os.environ.get('CF_API_TOKEN', '')
# ② 内联 Bearer 字面量
headers = {'Authorization': f'Bearer {DEPLOY_TOKEN}'}
# ③ 字典 key 里嵌的 token 前缀片段（作者常拿 token 前 7 位当标记）
TOKENS = {'main': os.environ.get('CF_API_TOKEN',''),
          'worker': os.environ.get('CF_API_TOKEN','')}     # 原为 'main(nV1nKWV)'
# ④ 账号/区域/库标识
ACCT = os.environ.get('CF_ACCOUNT_ID', '')
ZONE = os.environ.get('CF_ZONE_ID', '')
DB   = os.environ.get('CF_D1_DATABASE_ID', '')
```

收尾三件事：

1. 所有改动文件 `py_compile` / `node --check` 通过；
2. 索引文档写明「运行前置：`export CF_API_TOKEN=...`」；
3. 测试 fixture 的假 token 改成显式假名（`test-admin-token`、`test-only-secret`），
   别留一长串看着像真货的字符。

删掉的文件里如果混了**含真凭据的快照 json**（`bindings.json` / `manifest.json`），
那是合理删除；但要在索引里写明「原文件含 X，未纳入」，否则下次同步又搬回来。

## 第 4 步：索引文档两张表

`projects/ADOPTION-<date>.md`：

| 表 | 列 |
|---|---|
| 已纳入 | 镜像目录 / 源目录 / 内容与文件数 / **排除项及原因** |
| 未纳入 | 目录 / 原因（产物 / 依赖 / 本身是 git 仓库 / 已被既有镜像覆盖） |

缺了「为什么少了几个文件」这一列，下一个人会以为同步漏了，重跑一遍又把凭据带进来。

## 第 5 步：远端浅克隆核验，然后清掉它

本地 `ls` 看到文件 ≠ 远端收到。

```bash
V=$(mktemp -d); cd "$V"
git clone -q --depth 1 user@example.com:<owner>/<repo>.git hop
for d in <纳入的目录名...>; do
  [ -d "hop/projects/$d" ] && echo "OK $d" || echo "MISS $d"
done
grep -rIlE "$PAT" hop/projects/          # 应为空
git -C hop ls-remote origin refs/heads/main | cut -c1-8   # 与本地 HEAD 前 8 位对照
```

验证完**必须删掉这个 clone**：它带完整历史，等于又落了一份凭据副本。
`rm -rf` 会触发审批（"Mass file deletion" 安全扫描），批准后执行，
不要因为被拦就留在原地。

## 提交纪律

- **逐文件显式 `git add`**，不要 `git add -A`：工作区常混着别的项目的历史改动
  （本次 `hermes-ops-private` 有 24 个无关未提交项）。
- 提交前清 `__pycache__`：`find projects -name __pycache__ -type d -exec rm -rf {} +`。
- commit message 写清「多少目录、多少文件、脱敏几处」，方便日后 `git log --stat` 对上。
- 推送后 `git rev-list --left-right --count origin/main...HEAD` 必须是 `0 0`，
  再 `git ls-remote` 核远端 HEAD —— 两项都对才说同步成功。
