---
name: desensitized-open-source-release
description: "Use when 把私有项目脱敏成可公开部署的仓库：清房重写、发布前扫描、克隆回验。"
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux, macos]
metadata:
  hermes:
    tags: [open-source, desensitization, release, git, security]
    related_skills: [github-repo-management, telegram-group-bot-suite, github-auth]
---

# 私有项目脱敏开源发布

把在跑的生产项目里的一个子系统，抽成**别人拿到就能部署**的独立仓库。

## When to Use

- 用户说「脱敏提取」「让别人也能部署」「开源出去」「发个仓库」「做个可复刻版」；
- **用户问「这些项目都正常上传 GitHub 了吗」「帮我推一下」，或要批量核对多仓库同步状态** ——
  走「推送与同步」一节，先只读审计（`scripts/audit-git-sync.sh`）再动手；
- **用户说「这些目录也纳入」「整理一下孤儿项目」，或本机有一批从没进过 git 的源码目录** ——
  走 §9「整批纳管」：先目录四分类，再凭据四分类，详见
  `references/orphan-adoption-credential-taxonomy.md`；
- 生产项目里有真实 Token / 群 ID / 私有域名 / 主机名，要推到公开仓库；
- 需要交付一份「照 README 走就能跑」的独立工程，而不是「我这台机器能跑」。

## 铁律

1. **清房重写，不要复制再删。** 生产仓带 `backups/`、`.bak-*`、`.env`、`data/`、真实默认 ID；复制会把死代码和历史泄漏一起搬走，删也删不干净（git 历史、pyc、日志）。
2. **扫描必须在 `git init` 之前。** 扫描器拒绝 `.git` 目录；顺序反了要么漏扫要么卡死。
3. **发布 ≠ 完成。** 必须从远端**全新克隆**、重建 venv、装依赖、跑测试全绿，才算交付。
4. **只留 `.example`。** `.env`、`*.db`、`state.json`、`llm_endpoints.json` 全进 `.gitignore`，扫描前物理删除。
5. **凭据零默认值。** 生产代码里 `OWNER_ID = "799..."` 这类默认值必须去掉，缺失即启动报错，而不是静默用别人的 ID。

## 步骤

1. **划边界**：只抽子系统，读它的 import 闭包（谁依赖谁），把无关模块（贴纸、点歌、面板）整块切掉。先统计行数，确认规模可控。
2. **清房重写**：按闭包重写，配置全走环境变量；单文件 SQLite + JSON state，不引入外部服务。
3. **造验证网**：离线单测（temp `DATA_DIR`、假 Token）+ 带 mock HTTP server 的端到端 selftest。selftest 必须包含**反例**：编造来源被丢、无据数字被回退——只测正例等于没测。
4. **脱敏扫描**：fail-closed，见下节。
5. **`git init` + 首次提交**（扫描通过后）。
6. **建仓/推仓**：建仓要 API token；只有 SSH key 时**能推不能建**，让用户建好空仓再推。推送到已有 `Initial commit` 的仓库**不要 force push**，走 rebase：

```bash
git fetch origin main && git rebase origin/main
git checkout --ours README.md && git add README.md
GIT_EDITOR=true git rebase --continue   # 不设会报 Terminal is dumb, but EDITOR unset
git push -u origin main
```
7. **克隆回验**：`git clone` 到临时目录 → 新建 venv → `pip install -r requirements.txt` → 单测 + selftest。
8. **交付**：给仓库链接 + 三步配置说明 + 一句「已从远端全新克隆验证过」。

## 脱敏扫描（fail-closed）

用 `telegram-group-bot-suite` 的 `scripts/verify_desensitization.py` 或项目内同款脚本：

```bash
chmod 600 /tmp/private.json          # 必须在被扫目录之外，且 0600
python scripts/verify_desensitization.py . --private-file /tmp/private.json
# 期望 {"status": "SUCCESS", "findings": []}
```

`private.json` 是字符串数组，装**这个项目真实用过的**敏感值：所有者 user id、群 id、私有域名、bot 用户名、主机名/别名、公网 IP、旧项目目录名。少写一项等于漏检。

扫描器额外检查：`.env`/`*.db`/`state.json` 等禁运文件、私钥块、`/home/<user>` 路径、公网 IPv4、`.git` 目录、符号链接。

## Pitfalls

- **占位 Token 长成真 Token 形状**：`<YOUR_USER_IDENTIFIER>:AAExample...`（30+ 位字母数字）会被 token 正则和 GitHub secret scanning 一起命中。用 `<YOUR_USER_IDENTIFIER>:REPLACE_WITH_YOUR_TOKEN` 这种明显不是凭据的写法。
- **`__pycache__` 与运行期 db**：扫描和提交前清掉，否则扫描器报不可读/二进制，或把测试数据带上远端。
- **参考仓的 `.env` 可能只是旧副本**：别读它来「核对」，只读 key 名。所有值从当前环境的实际配置取。
- **Pyright 的 `int(None)` 噪音**不挡发布（测试绿即可），但 Optional 参数用 `or ""` 收口，避免运行时 `None` 拼进 slot 字符串。
- **不要 force push 覆盖用户的 Initial commit**，除非确认仓库是刚建的空仓；正常走 rebase。
- **别在 README 里写自己的真实端点/ID 当示例**，用 `api.example.com` / `<YOUR_USER_IDENTIFIER>`。
- **验证要在远端副本上做**：本地 venv 里通过可能只是路径和缓存凑巧，克隆回验才暴露漏提交的文件（`__init__.py` 缺失、`.example` 没进 git）。
- **先实测凭据再动手**：`curl -o /dev/null -w '%{http_code}' -H "Authorization: token $GITHUB_TOKEN" https://api.github.com/user`，401 就是失效。此时 SSH 仍可能正常（`git ls-remote` 对已存在仓库返回 `Hi <user>`，对不存在的返回 `Repository not found`），但 **SSH 没有建仓能力**：请用户建空仓，别反复重试、别去装 `gh`、别翻历史备份找旧 token——解决不了授权。

## 推送与同步：多仓库批量核对（2026-11-06 实战）

用户问「这些项目都正常上传 GitHub 了吗」、或要你批量推本地提交时，**先定方向、再定可见性、最后扫 diff**，
顺序不能反。完整命令集与实测表格见 `references/git-push-sync-audit.md`，
只读巡检验收脚本见 `scripts/audit-git-sync.sh`。

### 1. ahead/behind 极易读反，报告前必须复核

`git rev-list --left-right --count origin/main...HEAD` 输出 `A\tB`：**左列=本地落后，右列=本地待推**。
本次实测把 `7\t0` 读成「领先 7」，实际是落后 7，差点据此给出相反的同步结论并让用户做错决定。

唯一该写进报告的口径是 `git status -sb` 的第一行（`## main...origin/main [ahead 1, behind 1]`），
且必须先 `git fetch origin`。**落后 N 不等于「没上传」**——那是远端更新、你该拉；
只有 ahead>0 才是「本地提交没推」。

### 2. 最高危：本地落后时推送，会把远端已删除的凭据重新推上去

实测 `lemon-userbot`：本地 HEAD 仍含真实 `TG_API_ID`/`TG_API_HASH`，而远端早已有
`Remove real Telegram credentials from sample configuration` 这个清理提交。直接推等于把删掉的密钥再公开一次。

固定流程（**不能用 force push 绕过**）：

```bash
git fetch origin
git log --oneline HEAD..origin/main                 # 远端多了什么（很可能就是脱敏修复）
git log --oneline -S'<真值片段>' -- .env.example     # 真值在哪些提交里出现过
git bundle create /tmp/<repo>-before.bundle --all    # 重写历史前的安全网
git rebase --autostash origin/main                   # 工作区脏时必须 autostash
git show HEAD:.env.example | grep -E 'TG_API|TOKEN'  # 确认已脱敏再推
git push origin main
```

`.gitignore` 冲突几乎总是「两侧各加了不同规则」，**两边都保留**，不要二选一。

### 3. 公开 / 私有一句话判定，决定能否推业务 ID

```bash
curl -s -o /dev/null -w '%{http_code}' https://api.github.com/repos/<owner>/<repo>
# 200 = 公开可见；404 = 私有或不存在（匿名查询不需要 token）
```

公开仓库要额外扫群 ID、内部域名、主机名；私有仓库仍要扫凭据（用户规则是永不硬编码）。

### 4. 只扫「未推送的 diff」，不是全仓库

`git diff origin/main..HEAD` 里 `grep` 凭据模式，**`.env.example` 是头号漏点**——
本次它被写入真实 `TG_API_ID` 与 `TG_API_HASH`。注意区分：命中
`os.environ.get("CONFIG_MASTER_KEY")`、注释里的键名、`<PRIVATE_IDENTIFIER>` 占位符都**不是泄露**；
只有字面量真值才算。压缩包（`tar.gz`/bundle）要 `tar tzf` 列名 + 抽读关键文件，不能只看文件名。

### 5. 推送成功的判据是远端 HEAD，不是 `push` 的输出

逐个仓库比对本地 `git rev-parse HEAD` 与 `git ls-remote origin refs/heads/main` 的前 8 位，
**全部 MATCH 才能说同步成功**。`->` 那行只表示请求发出去了。

### 6. 其它实测坑

- remote 是 HTTPS 且依赖 `gh` credential helper，而 `gh` 未安装 → `fatal: could not read Username`。
  改 SSH 即可（SSH key 可用时）：`git remote set-url origin user@example.com:<owner>/<repo>.git`。
- 只有「本地落后、零本地提交」的仓库**不需要推送**，`git merge --ff-only origin/main` 就同步了。
- 无独立分发仓库的项目，按目标仓的 `SYNC_POLICY.md` 归档进私有镜像（附补丁、版本锚点、回滚镜像 ID），
  不要因为建不了新仓就什么都不留。
- 建仓需要的 API token 失效（401）时**不要反复重试、不要装 `gh`、不要翻旧 token**，
  改为归档进已有私有仓库 + 生成 `git bundle` 双备份，并把「建独立仓库差一个 token」如实告诉用户。

### 7. 归档补丁时必须证明「可应用」，否则只是存了一堆死文件

把本地改动归档成 `patches/NN-<file>.patch` 后，**必须真打一遍**才算归档完成。

```bash
V=$(mktemp -d)
git -C <repo> archive <base-commit> | tar -x -C "$V"
cd "$V" && git init -q . && git add -A \
  && git -c user.name=t -c user.email=t@t commit -qm base
for p in <归档目录>/patches/*.patch; do git apply --check "$p" && git apply "$p"; done
```

**坑一：`git apply` 在非 git 目录里必然失败。** 本次直接对 tar 解出的普通目录试打，
10 个补丁 **10/10 报 FAIL**，差点判定补丁损坏；`git init` 之后复验 **10/10 通过**。
目录不是仓库时 `git apply` 报的是环境错误，不是补丁问题，**不要据此写"补丁不可用"**。

**坑二：删除型补丁要单独确认。** `flake.lock` 这类 `D` 操作应用后文件应当消失，
`[ -f flake.lock ] && echo 异常 || echo 符合预期`，别只看 `git apply` 退出码。

**坑三：归档文档里的恢复命令也要当代码验证。** 本次 `manifest.json` 的 `verification`
第一版写了"apply-verified"，而当时验证其实是误判失败；同一份 README 的恢复步骤
把 `test_job_expiry_local.py` 一股脑 `cp` 进 `tests/agent/`（应为 `tests/cron/`）。
**`verification` 字段只能填实测结论**，写之前先跑；恢复命令逐条走一遍再落笔。

### 8. 「当前版本删掉了」≠「历史里没有了」

仓库里常有 `Remove real Telegram credentials` 这类提交，`git show origin/main:.env.example`
看着是干净的空值——但历史对象里还取得到：

```bash
git log --oneline --all -S'<真值片段>'          # 哪些提交引入/删除过它
git grep -q '<真值片段>' $(git rev-list --all) && echo STILL_IN_HISTORY
```

本次实测远端 HEAD 已脱敏，但**至少 5 个历史提交的 `.env.example` 仍带真值，最新一个是 2026-10-04**。
报结论时必须区分三档：HEAD 干净 / 历史仍残留 / 已重写历史清掉。
用户判断"要不要处理"靠的正是这个区别；**不要用"已经修复了"糊过去**。
若仓库判定为私有且用户决定接受残留，如实记录即可，不要擅自 `filter-repo` + force push。

### 9. 整批纳管「无版本控制目录」：先四分类，再凭据四分类

用户说「把这些目录也纳入」「整理一下孤儿项目」时，**不要见到目录就搬**。
两轮分类，顺序不能反：先分目录性质，再分命中字符串性质。

**第一轮：目录四分类**

| 类别 | 判据 | 处置 |
|---|---|---|
| 真孤儿 | 无 `.git`，且目录名不在任何镜像仓 `projects/` 下 | 纳入 |
| 已镜像 | 目录名出现在某仓库 `projects/` 下 | **不动**，否则同一份源出现两处 |
| 产物 | `covers/`、`ocr_output/`、`*_output/`、`dist/`、`build/` | 不纳入 |
| 依赖 | `.venv`、`node_modules` | 必须排除（实测单个 `.venv` 251M） |

两个判据坑：**`[ -d .git ]` 会漏掉 worktree/submodule**（`.git` 是文件，内容 `gitdir: ...`），
一律用 `git -C "$d" rev-parse --git-dir`；**`ls` 输出带换行**，拼进变量做 `case` 匹配永远失败，
必须 `| tr '\n' ' '`。本次因此把一个 worktree 误报成孤儿。

**第二轮：凭据四分类（血案）**

本次从截断输出里看到一个 `471e...` 开头串，据此写了 `471e[0-9A-Za-z_-]{20,}`
去"清理"，**一次删掉 19 个正常部署脚本**——那其实是 Cloudflare Account ID。

| 类型 | 例子 | 处置 |
|---|---|---|
| 真密钥 | `cfut_…`、`sk-…`、`ghp_…`、`BEGIN PRIVATE KEY` | 改读环境变量 |
| 资源标识 | Account ID / Zone ID / D1 database ID | 改读环境变量（不可直接利用，但能定位资源） |
| 完整性校验 | `hashlib.md5(code) == '32hex'`、`SHA256SUMS` | **保留**，不是凭据 |
| 本地路径 | `KEY = "/home/ubuntu/.ssh/<name>"` | 保留，是私钥**路径**不是内容 |

三条铁律：① 正则**锚定完整凭据格式**，禁止「前缀 + 任意字符」；② **先出 dry-run 报告再改文件**；
③ 删错了立刻从源 `rsync` 恢复（幂等），不要反向修补。

**脱敏要保留可运行性**：含 token 的脚本是可复用资产，改成
`os.environ.get('CF_API_TOKEN','')` 而不是删文件；注意**字典 key 里嵌的 token 前缀片段**
（`'main(nV1nKWV)'` → `'main'`，作者常拿 token 前 7 位当标记）。改完全部 `py_compile`。

**收尾必须远端浅克隆核验**，然后**删掉那个 clone**（它带完整历史，等于又落一份凭据）：

```bash
git clone -q --depth 1 user@example.com:<owner>/<repo>.git /tmp/vfy
ls /tmp/vfy/projects/ && grep -rIlE "$PAT" /tmp/vfy/projects/
```

完整配方（rsync 排除清单、索引文档两张表、逐文件 add 纪律）见
`references/orphan-adoption-credential-taxonomy.md`。

- **给技能加 `assets/` 文件时，扩展名必须落在发布白名单里，否则第二天发布任务才开始失败。**
  实测 `public-skills-export/candidate_pipeline.py` 有一句
  `if p.suffix not in TEXT_EXTENSIONS|{'.pdf'} and p.name not in TEXT_NAMES: raise GuardError('unsupported_candidate_file')`，
  白名单是 `.md .json .yaml .yml .py .sh .txt .js .mjs .tex .sty .bst .bib .html .service .timer .conf .ini` + `LICENSE/Makefile`。
  往某个技能塞了 `local-patches-vs-82c3703.patch` 之后，当日 13:30 的核验 job 报 `exit=1` + `unsupported_candidate_file`，
  而前一天还是 success —— **时间差就是排查线索：先看新文件 mtime 是否晚于上次成功的那轮**。
  改法二选一，**先问用户**：① 把该文件排除出公开包（内部 diff 不该公开，推荐）；
  ② 扩建 `TEXT_EXTENSIONS`（等于把它推到 GitHub，需确认不含内网路径/IP/凭据）。
  **排除优先用 `candidate_pipeline.OMIT`，不要用 `SKIP_NAME`**：`OMIT` 是完整路径集合
  （`{'skills/<dir>/assets/<file>'}`），只影响这一个文件；`SKIP_NAME` 是**按文件名全局匹配**，
  同名文件在别的技能里会被一起排掉。而且 `build()` 里 `if n in OMIT: continue` 执行在
  扩展名校验**之前**，所以「扩展名不被接受 + 又不该公开」的文件加一条 `OMIT` 就够，
  完全不碰脱敏闸门。改完同步改 SKILL.md 里指向该文件的引用句（否则公开包出现死引用），
  再跑 `prepare` 验证：第一次产新 candidate、第二次 `NO_CHANGE`，两者都是正向证据。
  **别只看「扫描干净」就决定公开**：实测某 4184 行 `.patch` 用 `inspect_text()` 扫
  findings=0、无 token/私钥/IP/TG 群号，但内容是某成人站镜像改写、CDN Referer 绕法、
  FC2/madouqu 抓取实现 —— 「不含凭据」和「可以公开」是两件事，后者要人读内容判断。
  自查脚本（不跑 pipeline 也能提前发现）：
  ```bash
  python3 - <<'EOF'
  import pathlib,sys; sys.path.insert(0,'/home/ubuntu/bin/public-skills-export')
  from public_skills_guard import TEXT_EXTENSIONS,TEXT_NAMES
  SRC=pathlib.Path('/home/ubuntu/.hermes/skills')
  bad=[str(p.relative_to(SRC)) for p in SRC.rglob('*')
       if p.is_file() and not any(x in rel.parts for rel in [p.relative_to(SRC)]
       for x in {'.git','__pycache__','.curator_backups','.hub'})
       and p.suffix not in TEXT_EXTENSIONS|{'.pdf'} and p.name not in TEXT_NAMES]
  print('BAD',len(bad),*bad,sep='\n')
  EOF
  ```
  更普遍的一条：**任何「每日自查/每日发布」类 job 失败，先查最近 24h 有没有人在 `~/.hermes/skills` 下新增文件**，
  而不是先怀疑 job 本身或网络。

## 验收清单

- [ ] `python -m unittest discover -s tests` 全绿
- [ ] `scripts/selftest.py` 全绿，含反例断言
- [ ] `py_compile` 全部通过
- [ ] 扫描 `{"status":"SUCCESS","findings":[]}`
- [ ] 远端文件列表无 `.env` / `*.db` / `state.json` / 真实端点
- [ ] **fresh clone + fresh venv + 测试全绿**
- [ ] 仓库 public/private 与用户要求一致，默认分支正确

具体到 Telegram 群总结/日报的抽取实例见 `references/clean-room-extraction-recipe.md`。
