---
name: desensitized-open-source-release
description: "Use when 把私有项目脱敏成可公开部署的仓库：清房重写、发布前扫描、克隆回验。"
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux, macos]
metadata:
  hermes:
    tags: [open-source, desensitization, release, git, security]
    related_skills: [github-repo-management, telegram-group-bot-suite, github-auth]
---

# 私有项目脱敏开源发布

把在跑的生产项目里的一个子系统，抽成**别人拿到就能部署**的独立仓库。

## When to Use

- 用户说「脱敏提取」「让别人也能部署」「开源出去」「发个仓库」「做个可复刻版」；
- 生产项目里有真实 Token / 群 ID / 私有域名 / 主机名，要推到公开仓库；
- 需要交付一份「照 README 走就能跑」的独立工程，而不是「我这台机器能跑」。

## 铁律

1. **清房重写，不要复制再删。** 生产仓带 `backups/`、`.bak-*`、`.env`、`data/`、真实默认 ID；复制会把死代码和历史泄漏一起搬走，删也删不干净（git 历史、pyc、日志）。
2. **扫描必须在 `git init` 之前。** 扫描器拒绝 `.git` 目录；顺序反了要么漏扫要么卡死。
3. **发布 ≠ 完成。** 必须从远端**全新克隆**、重建 venv、装依赖、跑测试全绿，才算交付。
4. **只留 `.example`。** `.env`、`*.db`、`state.json`、`llm_endpoints.json` 全进 `.gitignore`，扫描前物理删除。
5. **凭据零默认值。** 生产代码里 `OWNER_ID = "799..."` 这类默认值必须去掉，缺失即启动报错，而不是静默用别人的 ID。

## 步骤

1. **划边界**：只抽子系统，读它的 import 闭包（谁依赖谁），把无关模块（贴纸、点歌、面板）整块切掉。先统计行数，确认规模可控。
2. **清房重写**：按闭包重写，配置全走环境变量；单文件 SQLite + JSON state，不引入外部服务。
3. **造验证网**：离线单测（temp `DATA_DIR`、假 Token）+ 带 mock HTTP server 的端到端 selftest。selftest 必须包含**反例**：编造来源被丢、无据数字被回退——只测正例等于没测。
4. **脱敏扫描**：fail-closed，见下节。
5. **`git init` + 首次提交**（扫描通过后）。
6. **建仓/推仓**：建仓要 API token；只有 SSH key 时**能推不能建**，让用户建好空仓再推。推送到已有 `Initial commit` 的仓库**不要 force push**，走 rebase：

```bash
git fetch origin main && git rebase origin/main
git checkout --ours README.md && git add README.md
GIT_EDITOR=true git rebase --continue   # 不设会报 Terminal is dumb, but EDITOR unset
git push -u origin main
```
7. **克隆回验**：`git clone` 到临时目录 → 新建 venv → `pip install -r requirements.txt` → 单测 + selftest。
8. **交付**：给仓库链接 + 三步配置说明 + 一句「已从远端全新克隆验证过」。

## 脱敏扫描（fail-closed）

用 `telegram-group-bot-suite` 的 `scripts/verify_desensitization.py` 或项目内同款脚本：

```bash
chmod 600 /tmp/private.json          # 必须在被扫目录之外，且 0600
python scripts/verify_desensitization.py . --private-file /tmp/private.json
# 期望 {"status": "SUCCESS", "findings": []}
```

`private.json` 是字符串数组，装**这个项目真实用过的**敏感值：所有者 user id、群 id、私有域名、bot 用户名、主机名/别名、公网 IP、旧项目目录名。少写一项等于漏检。

扫描器额外检查：`.env`/`*.db`/`state.json` 等禁运文件、私钥块、`/home/<user>` 路径、公网 IPv4、`.git` 目录、符号链接。

## Pitfalls

- **占位 Token 长成真 Token 形状**：`<YOUR_USER_IDENTIFIER>:AAExample...`（30+ 位字母数字）会被 token 正则和 GitHub secret scanning 一起命中。用 `<YOUR_USER_IDENTIFIER>:REPLACE_WITH_YOUR_TOKEN` 这种明显不是凭据的写法。
- **`__pycache__` 与运行期 db**：扫描和提交前清掉，否则扫描器报不可读/二进制，或把测试数据带上远端。
- **参考仓的 `.env` 可能只是旧副本**：别读它来「核对」，只读 key 名。所有值从当前环境的实际配置取。
- **Pyright 的 `int(None)` 噪音**不挡发布（测试绿即可），但 Optional 参数用 `or ""` 收口，避免运行时 `None` 拼进 slot 字符串。
- **不要 force push 覆盖用户的 Initial commit**，除非确认仓库是刚建的空仓；正常走 rebase。
- **别在 README 里写自己的真实端点/ID 当示例**，用 `api.example.com` / `<YOUR_USER_IDENTIFIER>`。
- **验证要在远端副本上做**：本地 venv 里通过可能只是路径和缓存凑巧，克隆回验才暴露漏提交的文件（`__init__.py` 缺失、`.example` 没进 git）。
- **先实测凭据再动手**：`curl -o /dev/null -w '%{http_code}' -H "Authorization: token $GITHUB_TOKEN" https://api.github.com/user`，401 就是失效。此时 SSH 仍可能正常（`git ls-remote` 对已存在仓库返回 `Hi <user>`，对不存在的返回 `Repository not found`），但 **SSH 没有建仓能力**：请用户建空仓，别反复重试、别去装 `gh`、别翻历史备份找旧 token——解决不了授权。

## 验收清单

- [ ] `python -m unittest discover -s tests` 全绿
- [ ] `scripts/selftest.py` 全绿，含反例断言
- [ ] `py_compile` 全部通过
- [ ] 扫描 `{"status":"SUCCESS","findings":[]}`
- [ ] 远端文件列表无 `.env` / `*.db` / `state.json` / 真实端点
- [ ] **fresh clone + fresh venv + 测试全绿**
- [ ] 仓库 public/private 与用户要求一致，默认分支正确

具体到 Telegram 群总结/日报的抽取实例见 `references/clean-room-extraction-recipe.md`。
