#!/usr/bin/env bash
# 只读审计：多仓库 Git 同步方向 + 远端可见性 + 未推送 diff 的凭据命中
# 不修改任何仓库、不 fetch 之外不产生副作用、不打印凭据原值。
#
# 用法:
#   bash audit-git-sync.sh                      # 扫 ~ 下一层含 .git 的目录
#   bash audit-git-sync.sh /path/a /path/b      # 指定仓库
#
# 输出三张表：SYNC（方向）/ VISIBILITY（公开或私有）/ SECRETS（命中位置，不含值）

set -uo pipefail
ROOT="${HOME}"

SECRET_RE='(sk-[A-Za-z0-9]{16,}|ghp_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{20,}|AKIA[0-9A-Z]{16}|xox[baprs]-[A-Za-z0-9-]{10,}|[0-9]{8,10}:AA[A-Za-z0-9_-]{30,}|-----BEGIN (RSA |EC |OPENSSH )?PRIVATE KEY-----|BOT_TOKEN[[:space:]]*=[[:space:]]*[0-9]{6,}|CONFIG_MASTER_KEY[[:space:]]*=[[:space:]]*[0-9a-f]{32,}|api[_-]?key[[:space:]]*[:=][[:space:]]*["'"'"']?[A-Za-z0-9]{20,})'

repos=()
if [ "$#" -gt 0 ]; then
  for r in "$@"; do [ -d "$r/.git" ] && repos+=("$r"); done
else
  while IFS= read -r d; do repos+=("$(dirname "$d")"); done < <(find "$ROOT" -maxdepth 2 -name .git -type d 2>/dev/null | sort)
fi

if [ "${#repos[@]}" -eq 0 ]; then echo "no git repos found"; exit 0; fi

echo "=========== SYNC (LEFT=behind local, RIGHT=ahead local) ==========="
printf '%-30s %-10s %-12s %-8s %s\n' REPO BRANCH AHEAD/BEHIND DIRTY REMOTE_HEAD
for r in "${repos[@]}"; do
  b=$(git -C "$r" rev-parse --abbrev-ref HEAD 2>/dev/null) || continue
  git -C "$r" fetch -q origin 2>/dev/null
  if git -C "$r" rev-parse --verify "origin/$b" >/dev/null 2>&1; then
    ab=$(git -C "$r" rev-list --left-right --count "origin/$b...HEAD" 2>/dev/null | tr '\t' '/')
    rh=$(git -C "$r" rev-parse "origin/$b" 2>/dev/null | cut -c1-8)
  else
    ab="no-upstream"; rh="-"
  fi
  dirty=$(git -C "$r" status --porcelain 2>/dev/null | wc -l)
  printf '%-30s %-10s %-12s %-8s %s\n' "$(basename "$r")" "$b" "$ab" "$dirty" "$rh"
done

echo
echo "=========== VISIBILITY (200=public, 404=private/absent) ==========="
for r in "${repos[@]}"; do
  url=$(git -C "$r" remote get-url origin 2>/dev/null) || continue
  slug=$(printf '%s' "$url" | sed -E 's#(git@github\.com:|https://github\.com/)##; s#\.git$##')
  case "$slug" in
    github.com*|*/*)
      code=$(curl -s -o /dev/null -w '%{http_code}' --max-time 8 "https://api.github.com/repos/$slug")
      case "$code" in
        200) vis="PUBLIC" ;;
        404) vis="private-or-absent" ;;
        *)   vis="unknown($code)" ;;
      esac
      printf '%-30s %-40s %s\n' "$(basename "$r")" "$slug" "$vis"
      ;;
  esac
done

echo
echo "=========== SECRETS in unpushed diff (path:line only) ==========="
for r in "${repos[@]}"; do
  b=$(git -C "$r" rev-parse --abbrev-ref HEAD 2>/dev/null) || continue
  base="origin/$b"
  git -C "$r" rev-parse --verify "$base" >/dev/null 2>&1 || continue
  hits=$(git -C "$r" diff "$base"..HEAD 2>/dev/null | grep -nEi "$SECRET_RE" | wc -l)
  if [ "$hits" -gt 0 ]; then
    printf '%-30s %s hits  <-- 人工确认是键名还是真值\n' "$(basename "$r")" "$hits"
    git -C "$r" diff --name-only "$base"..HEAD 2>/dev/null | grep -iE '\.env|secret|credential|\.pem$|\.key$|token|password' | sed 's/^/    suspicious file: /'
  fi
done
echo "(未列出的仓库 = 无命中)"

echo
echo "=========== push landed? compare local HEAD vs ls-remote ==========="
for r in "${repos[@]}"; do
  b=$(git -C "$r" rev-parse --abbrev-ref HEAD 2>/dev/null) || continue
  l=$(git -C "$r" rev-parse HEAD 2>/dev/null | cut -c1-8)
  rr=$(git -C "$r" ls-remote origin "refs/heads/$b" 2>/dev/null | cut -c1-8)
  [ -z "$rr" ] && continue
  [ "$l" = "$rr" ] && st=MATCH || st=MISMATCH
  printf '%-30s %-8s %-10s %s\n' "$(basename "$r")" "$b" "$l" "$st"
done
