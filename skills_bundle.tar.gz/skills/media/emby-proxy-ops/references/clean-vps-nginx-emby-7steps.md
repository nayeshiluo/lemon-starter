# 全新 VPS Nginx 反代 Emby：7 步落地 SOP

> 适用于刚开通的 Ubuntu / Debian VPS，无需部署 Docker/代理，纯 Nginx 极简直代加速。

---

## 访问链路与标准规划

```text
电视 / 手机客户端 (http://VPS公网IP:18096)
   ↓
VPS 公网 IP:18096 (或多服端口 18097 / 18098 ...)
   ↓
Nginx 反向代理 (WebSocket + 无缓冲 + 长连接 + SNI)
   ↓
原始上游 Emby 媒体服 (https://emby.example.com)
```

---

## 7 步落地标准流程

### 第 1 步：SSH 登录 VPS
```bash
ssh root@你的VPS公网IP
```

### 第 2 步：前置上游连通性自测
```bash
curl -I --connect-timeout 10 https://你的Emby地址
# 若上游带特殊端口：
curl -I --connect-timeout 10 https://你的Emby地址:8443
```
> 必须返回 HTTP 状态码（200 / 302 / 401 / 403 等）。若超时/拒绝连接则说明 VPS 到上游不通，先排查网络。

### 第 3 步：安装并启动 Nginx
```bash
apt update && apt install -y nginx
systemctl enable --now nginx
systemctl is-active nginx # 确认返回 active
```

### 第 4 步：写入标准 Emby 反代配置
检查端口占用并写入配置：
```bash
ss -lntp | grep ':18096 '
```
写入配置（以端口 `18096` 为例）：
```bash
tee /etc/nginx/conf.d/emby.conf >/dev/null <<'EOF'
server {
    listen 18096;
    server_name _;

    location / {
        proxy_pass https://你的Emby地址;
        proxy_http_version 1.1;

        proxy_set_header Host $proxy_host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;

        # WebSocket 支持
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";

        # SNI 握手支持
        proxy_ssl_server_name on;

        # 超时设置（流媒体长连接防断流）
        proxy_connect_timeout 15s;
        proxy_send_timeout 3600s;
        proxy_read_timeout 3600s;

        # 关闭缓冲随下随播
        proxy_buffering off;
    }
}
EOF
```

### 第 5 步：检查语法并热重载
```bash
nginx -t
systemctl reload nginx
ss -lntp | grep ':18096 ' # 确认处于 LISTEN 状态
```

### 第 6 步：本地回环测试
```bash
curl -I --connect-timeout 10 http://127.0.0.1:18096
```

### 第 7 步：开放防火墙与安全组
- **UFW 防火墙**（若 active）：`ufw allow 18096/tcp`
- **云服务商安全组**（AWS EC2 / 阿里云 / 腾讯云等）：入方向放行 TCP `18096`（`0.0.0.0/0`）。

---

## 一条命令快速验收
```bash
nginx -t && systemctl reload nginx && ss -lntp | grep ':18096 ' && curl -I --connect-timeout 10 http://127.0.0.1:18096
```

---

## 单机多 Emby 端口矩阵配置
若需在一台 VPS 上加速多个 Emby 服，采用独立文件按端口隔离：
- `18096` -> 第一个 Emby (`/etc/nginx/conf.d/emby-18096.conf`)
- `18097` -> 第二个 Emby (`/etc/nginx/conf.d/emby-18097.conf`)
- `18098` -> 第三个 Emby (`/etc/nginx/conf.d/emby-18098.conf`)

只需修改各配置文件中的 `listen <端口>;` 与 `proxy_pass <上游地址>;`，然后执行 `nginx -t && systemctl reload nginx`。

---

## 3 步排障闭环法
1. **502 Bad Gateway**：运行 `curl -I --connect-timeout 10 https://上游地址`，定位 VPS 与上游网络握手问题。
2. **本机通但公网不通**：运行 `curl -I http://127.0.0.1:18096` 正常时，排查 UFW 防火墙与云控制台安全组入站规则。
3. **查日志**：`tail -n 30 /var/log/nginx/error.log` 精准定位错误，避免拉取过长无用日志。
