# EMOS 上传器并发分片改造（实现 + 验证 + 上线）

配套：`references/multi-node-upload-cluster-planning.md` §4.1/§4.2（为什么必须先并发化）、
`scripts/verify_emos_parallel_upload.py`（离线验证夹具）、
`references/emos-uploader-identify-fix.md`（识别与命名问题）。

## 一、实测收益（2026-10-23，VPS-LA，303.4MB / 31 片）

| 配置 | 耗时 | 吞吐 |
|---|---|---|
| 串行 `workers=1` | 37.9s | **8.01 MB/s** |
| 并发 `workers=5` | 10.1s | **29.96 MB/s** |
| 提升 | | **3.74x** |

链路带宽实测 31.9 MB/s → **并发 5 已跑满，加线程无收益**（默认 5，上限 8）。

⚠️ **修正规划文档里的 3.0 MB/s**：那个数是「跑到 90s 被 kill」的中途快照，含进程启动、
识别、presign 等固定开销。**干净跑完的串行基线是 8.01 MB/s**。引用时用这个数，
否则会高估并发收益（3.0→30 是 10x 的错觉，真实是 3.74x）。

换算体感：300MB 单集 38s→10s；20GB 4K 约 43min→11min。

## 二、三个必须守住的不变量（改错任何一个都会静默出错）

`presign` 一次返回**全部**分片的独立 URL，R2/S3 multipart 语义允许乱序并发 PUT，
所以并发本身是安全的。真正的风险在收尾：

1. **`parts` 必须按 `number` 显式排序**
   并发完成顺序不确定，乱序提交给 `/complete` 会让合并失败或产出错位文件。
   串行版天然有序，所以这行代码在串行版本里不存在——改造时极易漏掉。
   ```python
   parts.sort(key=lambda p: p["number"])
   ```

2. **每个线程自己 `open` + `seek` 读分片**
   共享一个文件句柄会让多线程争抢读取偏移，直接导致**串片**（分片内容互相污染）。
   etag 还是对的、字节数还是对的，只有内容错了——这是最阴的一种失败。
   ```python
   def _put_part(n):
       off = (n - 1) * part_size
       ln = min(part_size, file_size - off)
       with open(local_path, "rb") as fh:      # 每片自己开
           fh.seek(off)
           chunk = fh.read(ln)
       if len(chunk) != ln:
           raise Exception(f"分片 {n} 读取不完整: {len(chunk)}/{ln}")
   ```

3. **每线程独立 `requests.Session`（thread-local）**
   `Session` 不保证并发安全。API 调用用主 session，分片 PUT 用线程本地 session。
   ```python
   _tls = threading.local()
   def _part_session():
       s = getattr(_tls, "sess", None)
       if s is None:
           s = get_http_session(); _tls.sess = s
       return s
   ```

## 三、并发控制与失败语义

- 并发数：`int(os.environ.get("EMOS_UPLOAD_WORKERS", "5"))`，再 `min(workers, total_parts, 8)`。
  **必须同时夹 `total_parts`**，否则 1 片的小文件也开 5 个线程。
- 保留原有的单分片 5 次指数退避重试（`2*attempt`），不要因为改成并发就丢掉。
- **fail-fast**：任一分片 `fut.result()` 抛异常即 `pool.shutdown(wait=False, cancel_futures=True)`
  并 re-raise，不空转剩余分片。`cancel_futures` 需要 Python ≥ 3.9（实测 3.11/3.12 均可）。
- 进度回调：多线程下用 `threading.Lock` 保护累加器，按**实际完成字节**累加，
  不要用 `part_num * part_size`（乱序时会跳变、末片会算多）。
- 外层原有 `try/except` 里的 `abort` 回滚必须保留：并发失败后仍要清理 R2 侧未合并分片。

## 四、验证顺序（先离线，再线上测速，最后冒烟）

### 4.1 离线正确性（必做，不碰生产）

```bash
python3 scripts/verify_emos_parallel_upload.py /root emos_uploader
```

夹具在本地起模拟 EMOS API，跑**真实** `upload_to_emos()`，覆盖三组用例：
串行基线 / 并发+故意乱序完成（第 1 片最慢）/ 单分片彻底失败。断言 parts 有序、
etag 对应、末片为余数、总字节吻合、**内容未串片**、失败时 fail-fast。

夹具只 mock 网络、不 mock 分片逻辑，所以能真的抓到「共享句柄串片」「漏排序」这两个 bug。

### 4.2 线上真实测速（不污染影视库的正确做法）

规划文档 §4.2 警告过「传一半 kill 会烧掉该资源一周额度」。**正确的测速姿势是
跑完整流程后 abort**：拿 token → presign → 并发 PUT → **不调 `/complete`** →
调 `DELETE /api/upload/multipart/{file_id}/abort` 清理。

这样能量到真实 R2 吞吐（含 TLS 与签名开销），平台侧不留已入库记录，也不占用该资源的
一周额度。本次串行/并发两组数据都是这样测出来的，两次都确认 `已 abort 清理`。

⚠️ `file_name` 用带时间戳的假名（`speedtest_<tag>_<ts>.mkv`），避免撞上真实资源的判重。

### 4.3 生产冒烟

拿一个**本周已传过**的文件跑一次，确认返回 `DUPLICATE!` + `exit=3` 且不崩。
这验证了改造没破坏识别/令牌/判重的前段，且不会产生新上传。

## 五、上线部署流程（生产副本与本机副本凭据形态不同时）

常见形态：**生产副本硬编码 TOKEN，仓库副本走环境变量**。直接 `scp` 覆盖会把凭据冲掉。
本次两份文件 md5 不同但只有 2 行差异（`TOKEN` / `TMDB_API_KEY`）。

规程：

1. **备份生产**：`cp -a /root/emos_uploader.py /root/emos_uploader.py.bak-serial-$(date +%Y%m%d-%H%M%S)`
2. **传输新版到 /tmp**，用 Python 正则把旧文件的两行凭据**原样注入**新文件
   （不要手抄凭据，不要用 sed 处理含特殊字符的 token）
3. **差异自证**：`diff` 只应出现并发改造与 import；再单独 `diff` 凭据行确认
   `TOKEN`/`TMDB_API_KEY`/`BASE_URL` 三行**完全一致**，打印「凭据行完全一致 ✓」
4. `python3 -m py_compile` 通过后才 `cp` 到位
5. 冒烟（§4.3）通过才算上线

汇报时必须给出：改前/改后实测吞吐表、三个不变量的处理说明、备份文件路径、冒烟结果。

## 六、断点续传是另一件事（别混进并发改造）

并发化只解决「快」，不解决「断了重来」。`--resume` 需要记录 `file_id` + 已完成分片
到本地状态文件，并且 presign URL 有有效期、重跑要重新 presign 剩余分片。

**先并发、后 resume**，两件事分开验收。沙箱机（8 小时窗口）才强制要求 resume；
大带宽 VPS 上大文件 11 分钟就传完，优先级低。
