# Read-only AST audit for obfuscated Worker proxy paths

Use this when the requested change targets a specific hot path in a minified/obfuscated Worker and the source must not be altered during analysis.

## Parse and establish stable offsets

Use Node with the system Acorn module if available, and parse the entire file before drawing conclusions:

```js
const fs = require('fs');
const acorn = require('/usr/share/nodejs/acorn');
const source = fs.readFileSync(target, 'utf8');
const ast = acorn.parse(source, {
  ecmaVersion: 'latest',
  sourceType: 'module',
  ranges: true,
  locations: true
});
```

Acorn `start`/`end` offsets are JavaScript string (UTF-16 code-unit) offsets, with `end` exclusive. They are not byte offsets when non-ASCII text occurs earlier in the file. Report both the range and `loc` when precision matters. Preserve the exact source during audit; do not format or rewrite a draft merely to make it readable.

## Identify the implementation, not just the callsite

A `MemberExpression` matching `__lemonOriginal.fetch` tells where a wrapper delegates; it does not necessarily identify the proxy implementation. Walk ancestors to its enclosing function and inspect the declaration. Then separately locate the `__lemonOriginal` object and the `Property` whose key is `fetch`; inspect whether its value is a `FunctionExpression`/method and report that function boundary. This avoids confusing a late-added page/HTML wrapper with the original route handler.

Useful AST node filters:

- Member callsite: `MemberExpression`, object identifier `__lemonOriginal`, property `fetch`.
- Actual object method: `Property` whose key is `fetch`, inside the `__lemonOriginal` object initializer; report the property's value function range.
- Structural hot path: `TryStatement`, `ForStatement`, `NewExpression` for `Request`/`Response`, and `ReturnStatement`. Use parent/ancestor structure and focused source slices, not raw keyword-counting alone.

A compact recursive AST walker should skip metadata fields (`loc`, `start`, `end`, `range`) to avoid redundant traversal. For each located node, retain the parent chain so that similarly named nested helpers are not mistaken for the route handler.

## Trace and report proxy control flow

Within the real route `fetch` method, establish these landmarks from AST boundaries and a short source slice around each:

1. Request URL parsing and route/node dispatch.
2. Database route lookup and early error returns (missing DB, schema/query failure, missing route).
3. Body buffering/replay initialization, if present.
4. Outer route/node loop and inner candidate/upstream loop, including the exact `new Request(...)` and `await fetch(...)` try/catch.
5. Status-based retry/continue and success assignment/breaks.
6. No-success response.
7. Redirect status block and Location rewriting.
8. Any conditional response-body rewrites that return early.
9. Normal final `new Response(upstream.body, ...)` and outer catch/error response.

Explain only what the visible expressions prove. If obfuscated decoder calls conceal string values, label inferred statuses/routes cautiously and cite the numeric literals or source-level visible condition. Distinguish asynchronous DB work scheduled with `waitUntil` from awaited DB route reads; timing placement differs.

## How to isolate a VM test

Prefer extracting only the AST-bounded method/function (or wrapping its body) rather than evaluating the entire Worker module. A focused harness can provide:

- Runtime web globals: `URL`, `Request`, `Headers`, `Response` (and any stream/FormData globals actually used on the chosen branch).
- Deterministic `fetch` stub returning controlled status, headers, body, or throwing in a chosen attempt.
- Minimal request and environment objects, including a fake DB with `prepare`/`bind`/`first`/`all`/`run` only as required by the branch.
- Helper functions/constants referenced by the selected path, stubbed explicitly; do not silently replace production logic whose behavior is under test.
- Optional `ctx.waitUntil` collector for background tasks.

Test at least the chosen path's successful upstream, retry/alternate target, redirect, DB error/early return, and outer fetch exception as applicable. Assert exact fetch call order/count, constructed Request details, and final Response status/headers/body. Keep the harness ephemeral for read-only audits unless file creation is explicitly authorized.

## Pitfalls

- A global text search for `fetch(` mixes proxy fetches with unrelated telemetry/API calls and embedded HTML strings.
- A match for `__lemonOriginal.fetch` can be only a wrapper delegating to the original implementation.
- A broad object/function range may include helpers or nested closures; report the exact method value and separately bound loops/try statements.
- In a one-line bundle, Acorn line/column locations are coarse; offsets and stable source anchors are more useful.
- Do not claim a complete independent VM test is ready until all free identifiers for the selected branch have been enumerated or stubbed. AST discovery is not runtime validation.
