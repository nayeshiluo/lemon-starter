# Read-only post-upgrade acceptance and proxy hot-path review

Use this reference when accepting a MakkaPakka/Worker upgrade in front of EMOS, especially when asked to distinguish real media data from compatibility values or inspect repeated D1 schema work on proxy requests. It records the reusable procedure and the limits discovered during one 3.4.24 acceptance; it is not proof of current production state.

## Read-only acceptance sequence

1. **Establish what endpoint is actually serving.** Read `System/Info/Public` through the production route and record status plus non-secret identity/version fields. Treat an EMOS-specific identity (for example `ServerName=emos`, `Id=emya`) as a custom middleware, not a native Emby server; do not assume native Emby endpoint semantics.
2. **Use only an authorized, normal Emby login path.** Use an existing authorized Emby user credential/session supplied for this purpose. Keep usernames, passwords, bearer tokens, cookies, and returned session tokens out of terminal output, logs, notes, and the report. A site's API/sign-in bearer token is not evidence of an Emby media-server login and must not be silently substituted. Never probe passwords, reset credentials, or rotate keys. If no usable authorized Emby login is available, stop before authenticated checks and report them as unverified.
3. **After successful authentication, validate three separate capabilities:**
   - media search: issue a narrow read-only search and confirm a valid response with results/empty-result semantics;
   - media-library list: read the library/folders endpoint and record names/types and server-reported totals, not just HTTP 200;
   - counts: read the count endpoint while authenticated and retain the exact payload for comparison.
4. **Compare the client-facing count response against the authenticated upstream response and the deployed Nginx/Worker code.** Identical hard-coded JSON returned by a proxy `return 200` or Worker response is compatibility placeholder data, not a live upstream count. Do not label it a real count, even if it is plausible or nonzero. Compare category semantics before summing fields; `ItemCount` may intentionally exclude music/collections or be an unrelated compatibility field.
5. **Prove runtime provenance.** A repository file, deployment report, or passing synthetic test is not itself proof of the active production configuration or real playback. When authorized/read-only access permits, inspect active Worker version/deployment metadata and the live Nginx configuration. Clearly separate: source reviewed, deployment record, public endpoint response, authenticated API behavior, and real-player playback. If a source host/runtime cannot be inspected, say production runtime linkage is unverified.
6. **Protect streaming behavior in the audit.** Review existing auth checks, D1 node selection, path rewriting, `Range`/`If-Range` forwarding, `206`/`Content-Range` preservation, redirect handling, and buffering separately. Do not propose removing or caching live auth/node lookup as a shortcut to schema optimization.

## Real playback startup latency diagnosis (read-only first)

Use one actual player playback as the sample. Do not infer startup latency from `System/Info/Public`, anonymous probes, or isolated synthetic proxy timing. Do not repeatedly call protected PlaybackInfo/media endpoints when no valid authorized Emby session exists; use request/log records emitted by the user's next real playback instead.

Correlate the same playback across player, Worker, EMOS/origin, and Nginx where applicable. Prefer a short-lived random trace/request ID if every relevant hop can preserve it; otherwise use a narrowly bounded UTC window plus method/path class, status, and byte counts, and disclose the weaker correlation. Measure separate stages: (1) PlaybackInfo request/response, (2) each playback URL redirect and final destination response, (3) video request to first byte, and (4) subsequent transfer duration/bytes. Also capture retries, repeated/overlapping requests, alternate-line attempts and their timeout duration. Never log Range values, media identifiers, full paths/query strings, signed URLs, cookies, authorization headers, or tokens; record only whether Range is present.

For each event retain UTC timestamp, trace ID, stage/hop, elapsed milliseconds, HTTP status, retry index, and response byte count; for streaming, separately record first-byte and transfer-complete timing. Do not conflate upstream response time, Worker duration, and player-observed startup time. Attribute the dominant delay only when same-playback evidence supports it; separate verified measurements from inference and missing logs.

Inspect Worker placement configuration separately from request-level execution/colo evidence: configured Smart Placement alone does not prove where a particular request ran or that scheduling caused latency. Inspect active Nginx config on its actual host/container before claiming buffering or timeout settings; local saved config is only a candidate. If Worker Tail/analytics or origin logs are unavailable, state that and offer a minimal temporary redacted timing plan rather than substituting a public endpoint benchmark. Preserve live auth, dynamic node reads, Range/If-Range forwarding, 206/Content-Range, and streaming in any proposed optimization; never cache credentials or signed playback URLs.

## Repeated schema checks in the proxy hot path

When reviewing minified/obfuscated Workers, decode and inspect the actual proxy dispatch branch, not only the migration strings or admin API. Count unique fields and call sites separately: an upgrade may have many migration checks across import/admin/proxy branches, while a request entering the proxy branch may retry a smaller set on every request.

A reviewed 3.4.24 proxy branch performed seven `ALTER TABLE routes ADD COLUMN` attempts per proxy request for `custom_ip`, `redirect_direct`, `redirect_rules`, `node_user`, `node_pass`, `emos_id`, and `emos_name`. The statements were wrapped in ignored-error catches, so an already-present field still caused repeated D1 work and swallowed the duplicate-column error. Treat this as a finding about that reviewed artifact only; verify the live artifact before attributing it to production.

### Minimal optimization proposal

Preferred: apply a versioned, idempotent D1 schema migration once through the deployment/migration workflow, verify all required columns, then remove the schema-alter attempts from the per-request proxy path. Keep the per-request auth decision, route/prefix lookup, and node credentials read live from D1. Preserve request/response streaming semantics unchanged.

If schema migration cannot be performed outside the Worker, use a per-isolate single-flight initialization promise so concurrent first requests share one schema check; do not run the checks after every request. This is a fallback, not a substitute for validating schema compatibility across isolates/deployments. Do not cache the auth outcome or node record as part of this change.

### Production-read / backup gate before changing the Worker

1. Pull the active Worker module from the Cloudflare API and hash it; compare against the proposed artifact before editing. A local candidate or an earlier deployment report is not proof of the current active code.
2. Before any write, snapshot the active module, bindings, settings/placement, and schedules. Keep the backup in a restricted directory, record hashes, and never print secret binding values. If the D1 connection is available, inspect only schema metadata first (for example `sqlite_master` and `pragma_table_info('routes')`) to confirm every target column exists; do not run `ALTER`, data exports, or other writes merely to check presence. A metadata-only schema snapshot is not a backup of table data.
3. If the fields are already present, do not perform a production migration. Keep the existing production snapshot as the rollback source and require a separate rollback readiness check before publishing code.
4. Stop if the active artifact cannot be fetched, the D1 schema query fails, or there is no complete recovery snapshot. Never substitute local staging files or prior snapshot metadata for live production evidence.

### Single-flight promise semantics and isolation tests

- Store a module-scope Promise before yielding so concurrent first requests in the same isolate await the same initialization. Keep it after success; on failure clear it only if it is still the Promise that failed, then rethrow so the current request fails and a later request can retry.
- Preserve existing best-effort behavior only for known duplicate-column/already-exists errors. Do not broadly swallow D1 errors: permission, binding, transient service, and SQL failures must reject initialization rather than mark the isolate initialized.
- Exercise the actual Worker module with an isolated D1 shim: (a) assert one set of schema checks across simultaneous first requests; (b) inject a one-time DB failure and assert the next request retries; (c) mutate a route and auth/session value after warm-up and prove the next request uses current values; (d) assert `Range`/`If-Range`, status `206`, `Content-Range`, and body streaming remain unchanged; (e) compare fixed compatibility responses byte-for-byte if they are out of scope.
- Run a before/after timing comparison on the same request sequence and label artificial D1 latency as a simulation, not a production latency measurement. Count D1 schema statements separately from per-request route reads; the intended change removes repeated schema attempts, not live node lookup or authentication.

Acceptance for the optimization should compare D1 schema-query/ALTER counts before and after on the same synthetic or staging request set; assert that auth still rejects unauthorized requests, nodes are selected from current D1 data, and Range requests still reach the mock/live upstream with `206` and `Content-Range` preserved. Do not run a production migration or code deploy without explicit change authorization.

## Reporting format

Lead with the result and separate:
- **Verified:** exact endpoint response or source/runtime evidence observed during this run.
- **Placeholder:** fixed proxy payload/value that is not live media-library data.
- **Unverified:** any authenticated or runtime check blocked by missing authorization or inaccessible runtime.
- **Proposed only:** changes not made; list minimal scope and invariants preserved.

State explicitly that no production files, bindings, credentials, or services were changed when the task was read-only. Never include passwords, tokens, cookies, private IDs, or secret headers in the report.

## Deploying a per-isolate schema single-flight change

For a narrow Worker hot-path optimization that replaces repeated idempotent D1 schema attempts with one isolate-shared initialization Promise, follow this order:

1. **Prove deployment target and preimage.** Read the active Worker module through the Cloudflare script endpoint and hash it. Compare it to the intended source artifact before editing. Do not trust a local candidate filename or old deployment record as proof of current production code.
2. **Back up before deployment.** Save the exact active module, current bindings response, Worker settings, schedules, and a schema-only D1 snapshot (for example, `sqlite_master` plus `pragma_table_info`). Keep the backup directory restricted. If this change does not write D1, a read-only schema snapshot is the relevant schema recovery evidence; do not initiate a D1 export that may suspend queries unless a data-changing migration requires it.
3. **Verify schema first.** Query production D1 `routes` metadata read-only and confirm every expected field is present before relying on removal of per-request `ALTER TABLE` attempts. Do not print route rows or secrets.
4. **Implement single-flight semantics.** Use one module-scope Promise per isolate. Concurrent first requests await the same Promise; retain it after success. If initialization fails, clear the cached Promise and rethrow so a later request can retry. Preserve tolerated duplicate-column behavior, but do not swallow unrelated D1 failures. Keep live authorization and per-request route/node reads outside this Promise.
5. **Test a local/staging twin before production.** Compare old and new Worker against the same isolated D1 fixture and request set. Count `ALTER` calls and route SELECTs separately. Test concurrent first requests, transient failure then retry, route updates observed by the next request, per-request auth headers, and Range/206/Content-Range/body pass-through. Label simulated latency as simulated; it is not a production latency guarantee.
6. **Upload metadata with all existing bindings.** The Workers multipart upload requires a metadata part. For an update, include the full existing binding set, including D1, and preserve public settings. API GET responses redact secret binding values; use only the protected authoritative local source to restore them. A successful HTTP upload is insufficient: incomplete metadata can be accepted while dropping bindings.
7. **Verify immediately; roll back on mismatch.** Re-fetch the live module and check its hash. Compare binding names/types (including D1), settings, and schedules to the pre-change snapshot. If any binding is missing or runtime checks regress, restore the exact pre-change module and complete metadata/bindings, then verify the restored module hash and binding inventory before continuing.
8. **Separate deployment from playback acceptance.** A deployed hash, passing synthetic proxy tests, and a live node-list check do not prove real-player startup/seek. Keep that acceptance pending until a player has exercised playback and seeking in production.

### Known deployment safety pitfall

Do not upload a Worker with metadata that omits `bindings`, or try a module-only multipart update when the endpoint requires metadata. In a tested update, the API accepted the upload but only three secret bindings remained; immediate detection, restoration from the predeploy snapshot, and readback verification were essential. The safer update includes `main_module`, full unchanged bindings, unchanged runtime settings, and the Worker module. Verify the active hash and binding inventory before declaring success.
