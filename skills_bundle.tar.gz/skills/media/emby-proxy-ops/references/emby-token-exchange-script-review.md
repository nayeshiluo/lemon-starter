# Emby Token Exchange 验证脚本：只读解释要点

遇到群聊转发的“普通账号换管理员 Token”脚本，先读取附件源码，不运行、不向线上服务器发送登录或探测请求。向用户说明三个阶段：普通账号密码经 `/Users/AuthenticateByName` 获取普通 Token；携带该 Token 访问 `/Connect/Exchange`；用返回的 Token 和 `LocalUserId` 访问 `/Users/{id}` 并查看 `Policy.IsAdministrator`。这是脚本想测试的授权边界，不等于漏洞存在。

审阅重点：
- 是否核对新旧 Token 和用户 ID 的实际归属；仅有 `IsAdministrator=True` 或打印“成功”不一定证明跨账号越权。
- 登录失败、响应非 JSON、缺少 Token/ID、HTTP 非 200 后是否明确停止；只打印警告又继续可能导致异常或误判。
- Token 是否原样输出到控制台或日志；`input()` 输入密码是否明文显示；是否使用 HTTPS，重定向是否可能把凭据带到非预期主机。
- 原生 Emby 与 EMOS/其他自研网关 API 行为不可互推；版本、补丁、反代路径也会影响结论。

答复用简明中文：是什么、代码确实做了什么、哪些仍未验证、凭据保护。仅在用户拥有或获授权的服务器上、明确要求时再讨论实际测试；不要将脚本运行意图写成漏洞已实证。