# Emby 直连规则管理门户（Loon / Shadowrocket 策略管理）

## 背景与定位
用户称「批量设置 Loon 直连规则的网站」或「Emby 直连规则管理」，并非部署在迁移后的主力机（naye），也不是独立域名前端，而是部署在 **vps-la (<PRIVATE_IDENTIFIER>)** 上的自研轻量 Web 管理门户。

> ⚠️ **搜索起点纠偏**：这类站最容易在「主力机迁移后打不开」的语境里被误判为迁移丢失。**不要先在 naye 上全盘 grep**。
> 先登 `vps-la` 跑 `systemctl list-units | grep -E 'rules|portal'`，一次就能命中。本次实战在 naye 上白跑了十几轮文件/会话/CF Worker 检索，真正答案在 vps-la 的 `/opt/emby-rules-*/`。

## 运行架构

### 1. 反向代理层
- vps-la 宿主机 **Docker 容器 `lemon-monitor-proxy`（nginx:alpine，`network=host`）**，监听 `2096`（SSL）与 `2083`（CPA 用），server_name `la.<PRIVATE_IDENTIFIER>`。
- 配置文件：`/home/ubuntu/docker-nodes/monitor-proxy/nginx.conf`（宿主机路径；容器内路径不同，`nginx -T` 在宿主机不可用）。
- ⚠️ 该 nginx 的 `2096` server block 里同时挂了 **两套 rules 门户 + CPA 管理路由**，用 `# BEGIN/END emby friend portal` 注释分段。改配置务必按段操作。

### 2. 后端服务 (Systemd，均在 vps-la)
| 实例 | 服务名 | 监听 | 目录 | 环境文件 | 数据文件 |
|---|---|---|---|---|---|
| 爸爸自用 | `emby-rules-portal.service` | `127.0.0.1:39087` | `/opt/emby-rules-portal/` | `portal.env` | `data/emby-direct.list` |
| 朋友专用 | `emby-rules-friend.service` | `127.0.0.1:39088` | `/opt/emby-rules-friend/` | `portal.env` | `data/emby-direct.list` |

- 后端是纯 stdlib `ThreadingHTTPServer`（`app.py`），Token 由 `portal.env` 的 `ADMIN_TOKEN` / `SUB_TOKEN` 注入。
- 支持路由：`/healthz`、`<admin_base>/`、`<admin_base>/api/rules|add|delete`、`/rules-sub/<SUB_TOKEN>/emby-direct.list`、`/rules-sub/<SUB_TOKEN>/emby-v6-host.plugin`。
- 另有 `emby-v6-host-sync.timer`（5 分钟）刷新 Loon Emby IPv6 Host 插件。

## 访问与订阅 URL 规则

1. **管理后台必须以末尾斜杠 `/` 结尾** —— `location ^~ /rules-admin/<ADMIN_TOKEN>/`。省略尾部 `/` 会 301/302 跳到带斜杠版本（5fa6 配了 302，ec13 由 nginx 自动 301），跟随后正常；**但某些客户端不跟随重定向，会表现为「打不开」**，对外发链接一律带 `/`。
2. **订阅文件必须带文件名**：`/rules-sub/<SUB_TOKEN>/emby-direct.list`。直接访问 `/rules-sub/<SUB_TOKEN>/` 返回 404（这是正常的，不是故障）。
3. **`/loon-sub/<TOKEN>/` 在 39087/39088 上不存在**（404），别误判为服务挂了。

## ⚠️ 头号故障：非标端口被中间设备劫持（Akamai 错误页）

### 症状指纹（一眼定性）
用户手机截图出现：
- 报错域 **`errors.edgesuite.net`** —— 这是 **Akamai** 的通用错误页，**既不是 Cloudflare 也不是源站**；
- 错误 URL 形如 **`http://[No Host]/rules-admin/...`** —— 协议退化成明文 `http`，且 Host 头在中间设备处丢失。

**判读**：这是运营商/中间代理对「非标端口 + HTTP 明文」的拦截页，**不是服务器故障，也不是用户开了代理软件**。

> 🔴 **本次实战教训**：先猜「你开着 Loon 吧，关掉再试」被用户直接否掉（"我没有用loon"），且换端口前第二次仍报同样页面。
> **不要在没有证据时把故障归因到用户客户端软件**。`[No Host]` 这个特征已经足够指向网络中间设备，直接按端口问题处理。

### 三步定性（必须做完再改）
```bash
# ① 多视角证明服务端 OK（本机 / 香港 / 洛杉矶 都通 = 源站无问题）
curl -s -m 12 -o /dev/null -w "local:%{http_code}\n" "https://la.<PRIVATE_IDENTIFIER>:2096/rules-admin/$TOK/"
ssh vps-hk   "curl -s -m 12 -o /dev/null -w 'hk:%{http_code}\n' 'https://la.<PRIVATE_IDENTIFIER>:2096/rules-admin/$TOK/'"
# ② 确认 DNS 正常且走 CF 代理
#    la.<PRIVATE_IDENTIFIER> A <PRIVATE_IDENTIFIER> proxied=true，公网解析为 <YOUR_SERVER_IP> / <YOUR_SERVER_IP>
# ③ 复现明文 HTTP 到 CF 边缘 → 应得到 400 + Server: cloudflare
```
若 ①②③ 全部正常而用户仍打不开 ⇒ 结论只能是「用户侧网络阻断该端口」，唯一可靠解法是把入口搬到 **标准 443**。

### 根治方案（已实战验证，2026-10-27 上线）
**Cloudflare Tunnel + 独立子域走 443**，不动 nginx、不动 xray、不动现有 CPA/代理节点。

新增入口：`https://rules.<PRIVATE_IDENTIFIER>/...`（标准 443，无端口号）。

#### 落地方案四步
```python
# ① 建 tunnel（config_src=cloudflare → 配置存 CF 侧，本地只需 token）
POST /accounts/{acct}/cfd_tunnel
     {"name": "lemon-rules-la-<date>", "config_src": "cloudflare"}
# → 返回 result.id 与 result.token

# ② 配 ingress：把 443 请求按原 Host 语义回源到本机 2096 的 nginx
PUT /accounts/{acct}/cfd_tunnel/{id}/configurations
{
  "config": {"ingress": [
    {"hostname": "rules.<PRIVATE_IDENTIFIER>",
     "service": "https://127.0.0.1:2096",
     "originRequest": {"noTLSVerify": true, "httpHostHeader": "la.<PRIVATE_IDENTIFIER>"}},
    {"service": "http_status:404"}
  ]}
}
# 关键：httpHostHeader 必须改回 nginx 的 server_name，否则 2096 命中不到正确 server block
#       noTLSVerify=true 因为 2096 是自签证书（CN=la.<PRIVATE_IDENTIFIER>）

# ③ DNS：CNAME 指向 tunnel
POST /zones/{zid}/dns_records
     {"type":"CNAME","name":"rules.<PRIVATE_IDENTIFIER>",
      "content":"<tunnel-id>.cfargotunnel.com","proxied":true,"ttl":1}

# ④ 源站装 cloudflared 并常驻
```

#### cloudflared 部署（⚠️ 有一个必踩的坑）
```bash
curl -sL -o /tmp/cloudflared https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64
sudo install -m 755 /tmp/cloudflared /usr/local/bin/cloudflared
sudo mkdir -p /etc/cloudflared && sudo chmod 700 /etc/cloudflared
# token 是 base64 JSON 字符串，写入 env 文件
sudo sh -c 'echo "TUNNEL_TOKEN=<token>" > /etc/cloudflared/env && chmod 600 /etc/cloudflared/env'
```
```ini
# /etc/systemd/system/lemon-rules-tunnel.service
[Unit]
Description=Cloudflare Tunnel for Emby rules portal (443)
After=network-online.target docker.service
Wants=network-online.target

[Service]
Type=notify
EnvironmentFile=/etc/cloudflared/env
ExecStart=/usr/local/bin/cloudflared --no-autoupdate tunnel run
Restart=always
RestartSec=5
TimeoutStartSec=40

[Install]
WantedBy=multi-user.target
```

> 🔴 **坑：token ≠ credentials-file**。`cfd_tunnel` API 返回的 `token` 是 **base64 编码的 JSON 字符串**，只能配合 `TUNNEL_TOKEN` 环境变量 + `tunnel run` 使用。
> 写成 `--config /etc/cloudflared/config.yml` + `credentials-file:` 会失败 —— 那需要的是 `{"AccountTag","TunnelID","TunnelSecret"}` 结构的 JSON 文件，不是这个 token。

#### 验收清单
```bash
systemctl is-active lemon-rules-tunnel            # active
journalctl -u lemon-rules-tunnel | grep 'Registered tunnel connection'   # 多区域 lax01/lax10/lax13
curl -s -m 20 -o /dev/null -w "%{http_code}\n" "https://rules.<PRIVATE_IDENTIFIER>/rules-admin/$TOK/"
curl -s "https://rules.<PRIVATE_IDENTIFIER>/rules-admin/$TOK/api/rules" | head -c 200   # 规则 JSON 正常
curl -sk -o /dev/null -w "%{http_code}\n" "https://la.<PRIVATE_IDENTIFIER>:2096/rules-admin/$TOK/"  # 旧入口仍 200
```
实测结果：管理页 200 / 7168 字节、页面标题 `Emby 直连规则管理`、朋友 10 条规则 API 正常、香港视角 200（0.63s）、旧 2096 入口未破坏。

### 为什么不用其他方案
| 方案 | 否决理由 |
|---|---|
| CF Origin Rules 改回源端口 | 当前 `CF_API_TOKEN` 对 `zones/{zid}/rulesets` 返回 `10000 Authentication error`，无 Rules 权限 |
| CF Worker 反代 | `zones/{zid}/workers/routes` 返回 `No access to the specified resource`，无法绑路由；Workers Scripts 列表虽可读 |
| 在 origin 443 直接加 nginx | 443 被 `lemon-xray` 的 VLESS Reality 占用（`*:443`），且该 inbound **无 fallbacks 配置**，不能共存 |
| 换成 2053/8443 等其他 CF 端口 | 仍是非标端口，用户侧阻断风险不变 |

### 附带发现的 CF Token 权限矩阵（同一账号多 Token 互补，别用单一 403 下结论）
| 端点 | 结果 |
|---|---|
| `GET /accounts/{a}/workers/scripts` | ✅ 可读 |
| `GET /accounts/{a}/cfd_tunnel` | ✅ 可读，**且可创建/改配置** |
| `POST /accounts/{a}/cfd_tunnel` | ✅ 成功 |
| `GET /accounts/{a}/cfd_tunnel/{id}/configurations` PUT | ✅ 成功 |
| `GET /zones/{z}/dns_records` (<PRIVATE_IDENTIFIER>) | ✅ 可读可写 |
| `GET /zones/{z}/workers/routes` | ❌ No access to the specified resource |
| `GET /zones/{z}/rulesets` | ❌ 10000 Authentication error |
| `GET /zones/{z}/settings/ssl` | ❌ 403 |
| `GET /zones/{z}/dns_records`（其他 4 个 zone） | ❌ 403（token 仅限 <PRIVATE_IDENTIFIER>） |

## 多客户端规则格式输出（Loon / Surge / Quantumult X / Clash）

用户要求「让圈叉、Surge 等代理软件也能用」时改这里。核心是**存储与渲染分离**。

### 1. 数据文件只存规范化规则，不带策略
`data/emby-direct.list` 里是裸规则，策略在渲染时按客户端注入：
```
DOMAIN-SUFFIX,cfcdn.longemby.com
IP-CIDR,<YOUR_SERVER_IP>/32
IP-CIDR6,2001:db8::1/128
```
这样一份数据可同时喂给所有客户端，新增格式不必迁移数据。

### 2. 各客户端渲染语法（实测输出，逐字符核对）
| slug | 文件名 | 输出 |
|---|---|---|
| loon | `emby-direct.list` | `DOMAIN-SUFFIX,cfcdn.longemby.com`（**裸规则，保持原样**） |
| surge | `emby-direct-surge.list` | `DOMAIN-SUFFIX,cfcdn.longemby.com,DIRECT`<br>`IP-CIDR,<YOUR_SERVER_IP>/32,DIRECT,no-resolve` |
| qx | `emby-direct-qx.list` | `host-suffix, cfcdn.longemby.com, direct`<br>`ip-cidr, <YOUR_SERVER_IP>/32, direct, no-resolve`<br>`ip6-cidr, 2001:db8::1/128, direct, no-resolve` |
| clash | `emby-direct-clash.yaml` | `payload:` 下 `  - DOMAIN-SUFFIX,xxx` / `  - IP-CIDR,x/32,no-resolve` |

硬要点：
- **Loon / 小火箭必须保持裸规则字节不变**。写成 `,DIRECT` 语法上合法，但会改变已订阅用户的现有行为，属无收益破坏 —— 策略留给挂载规则集时选 DIRECT。
- QX 的大小写与空格是硬要求：`host-suffix, <域>, direct` 全小写、逗号后一个空格；IPv6 是 `ip6-cidr`，**不是** `ip-cidr6`。
- Clash 系（Clash / Stash / Mihomo）走 `rule-provider` + `behavior: classical`，payload 里的 IP 规则必须带 `no-resolve`。
- 内容类型：Clash 用 `application/yaml; charset=utf-8`，其余 `text/plain; charset=utf-8`。

### 3. 路由设计（前缀 + 查表）
```python
SUBSET_FILES = {filename: (slug, ctype) for slug, filename, _l, _h in FORMAT_SPECS}
sub_prefix = f"/rules-sub/{SUB_TOKEN}/"
elif path.startswith(sub_prefix):
    spec = SUBSET_FILES.get(path[len(sub_prefix):])
    if spec is None: 404
```
⚠️ `emby-v6-host.plugin` 落在同一前缀下，**它的判断必须排在前缀匹配之前**，否则会被当未知文件 404 掉。

### 4. ⚠️ 改 `PUBLIC_BASE_URL` 不会断已订阅用户
`portal.env` 的 `PUBLIC_BASE_URL` **只影响页面展示的订阅地址**，路由是路径匹配、与域名无关。
所以从 `https://la.<PRIVATE_IDENTIFIER>:2096` 改成 `https://rules.<PRIVATE_IDENTIFIER>` 后：老用户 Loon 里已配的 `:2096` 地址继续工作，页面展示的新地址走 443 更适合国内。
**portal 和 friend 两份 `portal.env` 必须一起改**，否则两人看到的地址不一致。

### 5. 上线流程
1. 备份两个目录的 `app.py` 与 `portal.env`（`cp -a ... .bak-<TS>`）；
2. **先离线验证渲染函数**再上传：用假 token 注入环境变量 → `importlib` 加载 `app.py` → 直接调 `render_ruleset(rules, slug)`，四种格式逐行核对；
3. `install -m 640 -o root -g emby-portal`（friend 目录属主组是 `emby-friend`，两处不同）；
4. `systemctl restart emby-rules-portal emby-rules-friend`；
5. 逐格式 curl 验收，并确认旧 `emby-direct.list` 输出**字节未变**（老订阅不能被动到）。

## 其他排障要点

1. **主机归属混淆**：主力机 naye 迁移后容易误以为规则站下线；**先查 vps-la**。
2. **服务存活速查（vps-la）**：
   ```bash
   systemctl status emby-rules-portal emby-rules-friend lemon-rules-tunnel
   ss -lntp | grep -E ':39087|:39088|:2096'
   journalctl -u emby-rules-portal -u emby-rules-friend -n 20 --no-pager
   ```
   后端日志会把 token 打码成 `[REDACTED]`，可放心贴给用户。
3. **别用 `ps aux | grep <pid>` 找进程** —— 会因 `ps` 输出被截断而漏掉；用 `tr '\0' ' ' < /proc/<pid>/cmdline`。
4. **宿主机没有 `dig`**：改用 DoH 验证解析：
   `https://dns.google/resolve?name=<host>&type=A`、`https://dns.alidns.com/resolve?...`。
5. **不要 `grep -rn ... /` 全盘搜** —— 会超时（本次 180s timeout）。限定 `/etc/nginx/ /home/ /opt/ /var/www/`。
