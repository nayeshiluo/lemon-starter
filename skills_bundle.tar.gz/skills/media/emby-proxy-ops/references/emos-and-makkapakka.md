# EMOS 与 MakkaPakka (Update-EmbyProxy) 面板实操运维记录

## 1. EMOS 官方反代规范要点

- **视频服上游**：`https://video.emos.best`，核心接口挂载于 `/emby` 子路径下。
- **音乐服上游**：`https://music.emos.best`，核心接口挂载于 `/rest` 子路径下。
- **强制请求头**：
  - `EMOS-PROXY-ID`: 用户专属 UID（如 `eK981JREMs`）。
  - `EMOS-PROXY-NAME`: 用户专属称号（如 `naye`）。
  - `Host`: 必须设为 `video.emos.best` 或 `music.emos.best`。
- **视频流机制**：
  - 必须支持 `206 Partial Content` 与 `Range` 头部。
  - 必须支持 302 重定向直通（指向 Cloudflare R2 对象存储直链），反代层切忌携带错误 Host 自动跟随 302。

## 2. MakkaPakka 面板 Cloudflare Worker 补丁与部署

- **架构特点**：基于 Cloudflare Worker + D1 数据库，默认按前缀剥离路由。
- **直连 403 播放修复关键**：
  1. 播放器调用 `POST /PlaybackInfo` 时返回相对流媒体路径 `/emby/videos/...`。
  2. 播放内核（AVPlayer/ExoPlayer/VLC）发出的流媒体请求会丢失 `/emos` 前缀直连根域名。
  3. **修复**：Worker 拦截 `PlaybackInfo` 响应，动态将 `"/emby/videos/"` 替换为 `"/emos/emby/videos/"`，并在外层对 `/emby/videos/` 增加兜底识别。
  4. 使用 `redirect: 'manual'`，禁止 Worker 自动跟随，防止将原 Host 传给 R2 存储桶抛出 403。

## 3. Cloudflare API 一键更新 Worker 脚本与自定义域绑定（保留 D1 数据库绑定）

```python
import json, requests

token = "<CF_WORKER_API_TOKEN>"
account_id = "<CF_ACCOUNT_ID>"
zone_id = "<CF_ZONE_ID>"
script_name = "<WORKER_SCRIPT_NAME>"

# 1. 获取原有的 bindings (包含 D1、环境变量等)
bindings_resp = requests.get(
    f"https://api.cloudflare.com/client/v4/accounts/{account_id}/workers/scripts/{script_name}/bindings",
    headers={"Authorization": f"Bearer {token}"}
).json()

metadata = {
    "main_module": "worker.js",
    "bindings": bindings_resp.get("result", []),
    "compatibility_date": "2024-11-12",
    "compatibility_flags": ["nodejs_compat"]
}

files = {
    "metadata": ("metadata.json", json.dumps(metadata), "application/json"),
    "worker.js": ("worker.js", patched_js_code.encode("utf-8"), "application/javascript+module")
}

resp = requests.put(
    f"https://api.cloudflare.com/client/v4/accounts/{account_id}/workers/scripts/{script_name}",
    headers={"Authorization": f"Bearer {token}"},
    files=files
)

# 2. 绑定自定义域名 (Custom Domains)
resp_dom = requests.put(
    f"https://api.cloudflare.com/client/v4/accounts/{account_id}/workers/domains",
    headers={"Authorization": f"Bearer {token}"},
    json={
        "hostname": "yd.586934.xyz",
        "service": script_name,
        "zone_id": zone_id
    }
).json()
```

## 4. Cloudflare Worker 调度模式 (Placement) 与 API 排障

1. **面板提交设置报 `Authentication error`**：
   - 检查 Worker 环境变量（bindings）中的 `CF_API_TOKEN`，必须为具备 Workers 脚本与设置编辑权限的有效 Token。
2. **正确切换 Edge 边缘就近执行模式**：
   - 使用 `PATCH https://api.cloudflare.com/client/v4/accounts/{account_id}/workers/scripts/{script_name}/settings`。
   - `multipart/form-data` 的 part 名称必须为 `settings`（不能为 `metadata`）。
   - 切换为边缘节点模式 Payload：`{"placement": null}`（前端若传 `{"mode": "off"}` 会报 10346 invalid placement mode，Worker 中应自动将其转换为 `null` 提交）。
   - 切换为指定亚太机房 Payload：`{"placement": {"mode": "targeted", "region": "aws:ap-east-1"}}`（香港）或 `aws:ap-southeast-1`（新加坡）。

## 5. Telegram Bot 每日播报无法触发的排障与修复

1. **缺少 Cloudflare Cron Trigger**：
   - 玛卡巴卡面板原版代码中包含 `sendTgStats` 函数与 `scheduled` 事件监听，但默认没有在 Cloudflare 上配置触发计划。
   - **修复命令**：通过 Cloudflare API 为 Worker 添加 Cron Trigger：
     ```bash
     curl -X PUT "https://api.cloudflare.com/client/v4/accounts/{account_id}/workers/scripts/{script_name}/schedules" \
          -H "Authorization: Bearer {token}" \
          -H "Content-Type: application/json" \
          --data '[{"cron": "0 14 * * *"}]'  # UTC 14:00 对应北京时间 22:00
     ```
2. **Telegram 私聊权限机制**：
   - Telegram Bot 无法向未主动发起过对话的用户发送私聊推送。
   - 用户必须在 Telegram 中点击一次 Bot 的 `/start`（如 `@my_emby_zmzfd_bot`），建立有效会话后，每日播报和测试播报即可毫秒级直达。

## 6. 国内直连 500K 速度瓶颈与优选 DNS 极速实操

1. **物理瓶颈机理**：
   - 调度模式（Smart / Edge）仅决定 Worker 在哪个机房执行，无法改变中国电信/联通/移动骨干网对 Cloudflare 默认 Anycast 节点的公网限速（晚高峰高延迟与丢包）。
2. **分运营商优选策略**：
   - **中国电信（CT）**：偏好美西（圣何塞/洛杉矶）及亚太优化段（如 `104.18.185.26`、`104.16.160.25` 等）。
   - **中国移动（CMCC）**：偏好 CMI 优化及欧洲/香港/新加坡直连段（如 `162.159.192.x`、`162.159.193.x`、`104.19.x.x`、`172.67.x.x` 或移动优选 CNAME `cmcc.cf.090227.xyz`）。
   - **极速解决方案**：
     - **方案 A（秒开 4K 原盘）**：播放器挂代理走香港/新加坡/日本节点，延迟骤降至 20~30ms，带宽跑满 50MB/s+。
     - **方案 B（免翻直连优选）**：通过测速筛选出对运营商最友好的 Cloudflare 节点，调用面板 API `POST /api/update-dns`（或直接改写 DNS A 记录）将加速域名（如 `fd.586934.xyz` / `yd.586934.xyz`）静态绑定至对应运营商优选 IP，直连即可拉满带宽。

## 7. Cloudflare 522 报错排查与 Custom Domain 绑定避坑

- **522 Connection timed out 根因**：若在 Cloudflare DNS 列表中存在手动的 `hostname -> 100::` 或其它 AAAA/A 占位记录，但未在 Worker 的 `Custom Domains`（自定义域）中正确激活绑定，Cloudflare Anycast 边缘会将请求路由至不存在的源站服务器引发 522 超时。
- **排查与修复标准流程**：
  1. 删除 DNS 区域内冲突的手动 A/AAAA 占位记录。
  2. 调用 `PUT /accounts/{account_id}/workers/domains` 或在控制台将域名添加至 Worker 的 **Custom Domains**。
  3. Cloudflare 会自动注入受管 AAAA 记录并签发专用 SSL 证书。

## 8. Cloudflare Worker API Token 权限隔离避坑（DNS 更新失败）

- **现象**：面板前端点击“测速与 DNS”或“更新 TOP3 至 DNS”时，页面弹出 `❌ 错误: 获取现有 DNS 记录失败`。
- **根因**：Worker 环境变量 `CF_API_TOKEN` 中配置的 API Token 仅勾选了 Workers 权限（或权限不足），无法调用 `/client/v4/zones/{zone_id}/dns_records` 接口读取和修改 DNS。
- **解决方案**：
  1. 确保用于 Worker bindings 的 `CF_API_TOKEN` 拥有对应 Zone 的 `Zone.DNS:Edit` 权限。
  2. 或在部署 Worker 时注入专门的 DNS 管理 Token（如兼具 DNS 编辑与读取权限的专用 API Token），更新 Worker bindings 后重新部署即可秒级恢复。

## 9. Cloudflare Worker 反代代码混淆与凭证保护规范

在多节点或公开分享反代脚本时，为了防止 EMOS 专属凭证（UID/NAME）及上游直链泄露，必须对部署的 JS 脚本进行混淆：
1. **核心凭据十六进制/Base64 抽取**：将 `EMOS-PROXY-ID`、`EMOS-PROXY-NAME`、`video.emos.best` 等敏感常量抽取并编码。
2. **控制流平坦化与标识符混淆**：打乱 AST 结构并转为十六进制短变量名，防止逆向分析与抓包特征嗅探。
3. **保留兼容性**：混淆配置严禁破坏 `Response` 流式传输（`ReadableStream`）与 206 Partial Content 头部的透传。

## 9. Nginx 路径多重拼接 404 避坑规则

在 VPS Nginx 代理上游时：
```nginx
# 带有 /emby/ 的请求精确转发，避免 proxy_pass 再次重复拼接 /emby 导致 404
location /emby/ {
    proxy_pass https://video.emos.best/emby/;
    proxy_ssl_server_name on;
    proxy_buffering off;
}

# 根路径及未带 /emby/ 的请求自动补全
location / {
    proxy_pass https://video.emos.best/emby/;
    proxy_ssl_server_name on;
    proxy_buffering off;
}
```

## 8. 媒体库数量动态同步（Dynamic Items Counts）机制与防硬编码陷阱

1. **Emby 权限隔离与匿名 0 机制**：
   - 官方 `/emby/Items/Counts` 接口在未携带用户登录态（`X-Emby-Token`）时，出于安全考虑默认返回全 `0`。
   - 当播放器登录后，客户端请求该接口会自动附带有效的 `X-Emby-Token`。
2. **严禁硬编码静态数据**：
   - 若反代层为了在未登录时显示卡片数字而直接 `return 200 '{"MovieCount":...}'` 硬编码假数据，会导致后续用户即便正常登录，也永远无法接收到官方最新的真实数据，官方入库新电影/剧集后数字无法动态增加。
3. **最佳实践**：
   - **动态透传 + 10分钟短缓存**：反代网关对 `/Items/Counts` 开启请求头全量透传（`proxy_pass_request_headers on`），并配置 `proxy_cache_valid 200 10m`。
   - 这样既避免高频刷爆上游网关，又保证官方入库新片后，缓存过期播放器刷新即可自动递增同步最新真实数字。

## 10. Cloudflare Worker 路由与优选域名 Connection Reset (连接被重置) 避坑

- **现象**：在 DNS 中新增了优选加速子域名（如 `yd-fd.586934.xyz`）并绑定优选 IP，但在客户端发起 HTTPS 请求时抛出 `Connection reset` 或 SSL/TLS 握手失败。
- **根因**：Worker 仅通过 Custom Domains 绑定了主面板，未在 Zone 的 **Workers Routes（路由规则）** 中为优选直连域名配置路由通配符（如 `yd-fd.586934.xyz/*`）。Cloudflare Anycast 边缘收到该 SNI 的请求后找不到对应的 Worker 脚本接管，从而直接重置 TCP 连接。
- **解决方案**：
  通过 Cloudflare API 为加速域名添加 Worker Route：
  ```bash
  curl -X POST "https://api.cloudflare.com/client/v4/zones/{zone_id}/workers/routes" \
       -H "Authorization: Bearer {worker_token}" \
       -H "Content-Type: application/json" \
       --data '{"pattern":"yd-fd.586934.xyz/*","script":"<WORKER_SCRIPT_NAME>"}'
  ```

## 11. 测速工具写入杂乱 DNS / IPv6 导致严重降速与启播卡顿排查

- **现象**：在面板执行测速并点击“更新 TOP3 至 DNS”后，播放速度由极速骤降，出现频繁缓冲或启播卡顿数秒。
- **根因**：
  1. 前端测速逻辑若把高丢包 Anycast 节点或 IPv6 慢速节点一起批量写入 A/AAAA 记录，客户端发起分片请求时会在多条记录间轮询，一旦命中劣质 IP 会导致 TCP 拥塞与缓冲。
  2. Worker 调度模式若被固定为指定机房可能导致与国内 CDN 边缘链路不匹配；推荐保持 `Smart` 智能就近调度模式。
- **解决方案**：
  1. 仅保留 2~3 个经过真实验证的对应运营商黄金骨干 IPv4：
     - **电信优选**：`104.18.226.52`、`104.18.185.26`、`172.67.180.1`
     - **移动优选（CMI）**：`162.159.192.1`、`162.159.193.1`、`104.19.24.45`
  2. 严格清除 DNS 中的 AAAA（IPv6）测速冗余记录，保持解析列表精简纯净。
  3. 将 Worker 调度模式设为 Smart 模式：`PATCH /settings` 传入 `{"placement": {"mode": "smart"}}`。

## 13. EMOS 2026 最新 `/emya/video` 视频流路由与 302 R2 透传规范

1. **全新流媒体 API 路由架构**：
   - 官方返回的 `DirectStreamUrl` 为 `/emya/video?server=emos&media_id=...&token=...&time=...&v=...&sign=...`。
   - 播放器发起请求时可能走根路径 `https://<域名>/emya/video?...` 或拼接路径 `https://<域名>/emos/emya/video?...`。
   - 反代网关必须在全局拦截中同时放行 `/emya/` 路由，并向 `https://video.emos.best/emya/video` 注入 `EMOS-PROXY-ID` 与 `EMOS-PROXY-NAME` 请求头。若返回 404，需自适应补全 `/emby/emya/video` 重试。

2. **302 重定向到 R2 存储桶避坑**：
   - 当上游返回 302 时，`Location` 头如果为 `https://<r2-bucket-url>/...` 绝对路径，反代层**必须原样透传**，严禁在前面拼接 `/emos`。
   - 仅当 `Location` 为 `/` 开头的相对路径时，才可补全 `/emos` 前缀。

3. **Shlii 与亚太低延迟 NAT 前置机选型最佳实践**：
   - 选型标准：首选【中国香港 BGP/CMI 直连】（如 Shlii 平台 `HKVIA-电移神机` ID: 771、`HK三网优化大带宽` ID: 532），国内直连延迟 20ms~30ms。
   - 播放器直连代理（分流至香港/新加坡优质专线节点）是达到 0 延迟秒开 4K 的天花板方案。


- **报错根源**：在 Nginx 中，如果 `location` 使用了正则表达式（如 `location ~* ^/(emby/)?Items/Counts$`），`proxy_pass` 后面**严格禁止携带 URI 路径部分**（例如写成 `proxy_pass https://video.emos.best/emby/Items/Counts;` 会导致 Nginx 报 `[emerg] "proxy_pass" cannot have URI part in location given by regular expression` 并直接崩溃退出，引发 Cloudflare 521 Web server is down）。
- **标准写法**：
  ```nginx
  # 方案一：采用精准匹配普通 location（推荐）
  location = /emby/Items/Counts {
      proxy_pass https://video.emos.best/emby/Items/Counts;
      proxy_ssl_server_name on;
  }
  
  # 方案二：正则匹配时 proxy_pass 仅保留协议与域名
  location ~* ^/(emby/)?Items/Counts$ {
      proxy_pass https://video.emos.best;
      proxy_ssl_server_name on;
  }
  ```


