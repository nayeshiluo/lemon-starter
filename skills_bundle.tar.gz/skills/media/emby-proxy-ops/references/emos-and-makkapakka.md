# EMOS 与 MakkaPakka (Update-EmbyProxy) 面板实操运维记录

## 1. EMOS 官方反代规范要点

- **视频服上游**：`https://video.emos.best`，核心接口挂载于 `/emby` 子路径下。
- **音乐服上游**：`https://music.emos.best`，核心接口挂载于 `/rest` 子路径下。
- **强制请求头**：
  - `EMOS-PROXY-ID`: 用户专属 UID（如 `eK981JREMs`）。
  - `EMOS-PROXY-NAME`: 用户专属称号（如 `naye`）。
  - `Host`: 必须设为 `video.emos.best` 或 `music.emos.best`。
- **视频流机制**：
  - 必须支持 `206 Partial Content` 与 `Range` 头部。
  - 必须支持 302 重定向直通（指向 Cloudflare R2 对象存储直链），反代层切忌携带错误 Host 自动跟随 302。

## 2. MakkaPakka 面板 Cloudflare Worker 补丁与部署

- **架构特点**：基于 Cloudflare Worker + D1 数据库，默认按前缀剥离路由。
- **直连 403 播放修复关键**：
  1. 播放器调用 `POST /PlaybackInfo` 时返回相对流媒体路径 `/emby/videos/...`。
  2. 播放内核（AVPlayer/ExoPlayer/VLC）发出的流媒体请求会丢失 `/emos` 前缀直连根域名。
  3. **修复**：Worker 拦截 `PlaybackInfo` 响应，动态将 `"/emby/videos/"` 替换为 `"/emos/emby/videos/"`，并在外层对 `/emby/videos/` 增加兜底识别。
  4. 使用 `redirect: 'manual'`，禁止 Worker 自动跟随，防止将原 Host 传给 R2 存储桶抛出 403。

## 3. Cloudflare API 一键更新 Worker 脚本（保留 D1 数据库绑定）

```python
import json, requests

token = "<CF_WORKER_API_TOKEN>"
account_id = "<CF_ACCOUNT_ID>"
script_name = "<WORKER_SCRIPT_NAME>"

# 获取原有的 bindings (包含 D1、环境变量等)
bindings_resp = requests.get(
    f"https://api.cloudflare.com/client/v4/accounts/{account_id}/workers/scripts/{script_name}/bindings",
    headers={"Authorization": f"Bearer {token}"}
).json()

metadata = {
    "main_module": "worker.js",
    "bindings": bindings_resp.get("result", []),
    "compatibility_date": "2026-07-18"
}

files = {
    "metadata": ("metadata.json", json.dumps(metadata), "application/json"),
    "worker.js": ("worker.js", patched_js_code.encode("utf-8"), "application/javascript+module")
}

resp = requests.put(
    f"https://api.cloudflare.com/client/v4/accounts/{account_id}/workers/scripts/{script_name}",
    headers={"Authorization": f"Bearer {token}"},
    files=files
)
```

## 4. Cloudflare Worker 调度模式 (Placement) 与 API 排障

1. **面板提交设置报 `Authentication error`**：
   - 检查 Worker 环境变量（bindings）中的 `CF_API_TOKEN`，必须为具备 Workers 脚本与设置编辑权限的有效 Token。
2. **正确切换 Edge 边缘就近执行模式**：
   - 使用 `PATCH https://api.cloudflare.com/client/v4/accounts/{account_id}/workers/scripts/{script_name}/settings`。
   - `multipart/form-data` 的 part 名称必须为 `settings`（不能为 `metadata`）。
   - 切换为边缘节点模式 Payload：`{"placement": null}`（前端若传 `{"mode": "off"}` 会报 10346 invalid placement mode，Worker 中应自动将其转换为 `null` 提交）。
   - 切换为指定亚太机房 Payload：`{"placement": {"mode": "targeted", "region": "aws:ap-east-1"}}`（香港）或 `aws:ap-southeast-1`（新加坡）。

## 5. Telegram Bot 每日播报无法触发的排障与修复

1. **缺少 Cloudflare Cron Trigger**：
   - 玛卡巴卡面板原版代码中包含 `sendTgStats` 函数与 `scheduled` 事件监听，但默认没有在 Cloudflare 上配置触发计划。
   - **修复命令**：通过 Cloudflare API 为 Worker 添加 Cron Trigger：
     ```bash
     curl -X PUT "https://api.cloudflare.com/client/v4/accounts/{account_id}/workers/scripts/{script_name}/schedules" \
          -H "Authorization: Bearer {token}" \
          -H "Content-Type: application/json" \
          --data '[{"cron": "0 14 * * *"}]'  # UTC 14:00 对应北京时间 22:00
     ```
2. **Telegram 私聊权限机制**：
   - Telegram Bot 无法向未主动发起过对话的用户发送私聊推送。
   - 用户必须在 Telegram 中点击一次 Bot 的 `/start`（如 `@my_emby_zmzfd_bot`），建立有效会话后，每日播报和测试播报即可毫秒级直达。

## 6. 国内直连 500K 速度瓶颈与优选 DNS 极速实操

1. **物理瓶颈机理**：
   - 调度模式（Smart / Edge）仅决定 Worker 在哪个机房执行，无法改变中国电信/联通/移动骨干网对 Cloudflare 默认 Anycast 节点的公网限速（晚高峰高延迟与丢包）。
2. **极速解决方案**：
   - **方案 A（秒开 4K 原盘）**：播放器挂代理走香港/新加坡/日本节点，延迟骤降至 20~30ms，带宽跑满 50MB/s+。
   - **方案 B（免翻直连优选）**：通过测速筛选出对运营商最友好的 Cloudflare 节点（如电信/亚太优化段 `104.18.185.26`、`104.16.160.25`），调用面板 API `POST /api/update-dns`（或直接改写 DNS A 记录）将加速域名（如 `fd.586934.xyz`）静态绑定至优选 IP，直连即可拉满带宽。

## 7. Nginx 路径多重拼接 404 避坑规则

在 VPS Nginx 代理上游时：
```nginx
# 带有 /emby/ 的请求精确转发，避免 proxy_pass 再次重复拼接 /emby 导致 404
location /emby/ {
    proxy_pass https://video.emos.best/emby/;
    proxy_ssl_server_name on;
    proxy_buffering off;
}

# 根路径及未带 /emby/ 的请求自动补全
location / {
    proxy_pass https://video.emos.best/emby/;
    proxy_ssl_server_name on;
    proxy_buffering off;
}
```

## 8. 媒体库数量动态同步（Dynamic Items Counts）机制与防硬编码陷阱

1. **Emby 权限隔离与匿名 0 机制**：
   - 官方 `/emby/Items/Counts` 接口在未携带用户登录态（`X-Emby-Token`）时，出于安全考虑默认返回全 `0`。
   - 当播放器登录后，客户端请求该接口会自动附带有效的 `X-Emby-Token`。
2. **严禁硬编码静态数据**：
   - 若反代层为了在未登录时显示卡片数字而直接 `return 200 '{"MovieCount":...}'` 硬编码假数据，会导致后续用户即便正常登录，也永远无法接收到官方最新的真实数据，官方入库新电影/剧集后数字无法动态增加。
3. **最佳实践**：
   - **动态透传 + 10分钟短缓存**：反代网关对 `/Items/Counts` 开启请求头全量透传（`proxy_pass_request_headers on`），并配置 `proxy_cache_valid 200 10m`。
   - 这样既避免高频刷爆上游网关，又保证官方入库新片后，缓存过期播放器刷新即可自动递增同步最新真实数字。

## 9. Nginx 正则 Location 与 proxy_pass 语法避坑（防 521 崩溃）

- **报错根源**：在 Nginx 中，如果 `location` 使用了正则表达式（如 `location ~* ^/(emby/)?Items/Counts$`），`proxy_pass` 后面**严格禁止携带 URI 路径部分**（例如写成 `proxy_pass https://video.emos.best/emby/Items/Counts;` 会导致 Nginx 报 `[emerg] "proxy_pass" cannot have URI part in location given by regular expression` 并直接崩溃退出，引发 Cloudflare 521 Web server is down）。
- **标准写法**：
  ```nginx
  # 方案一：采用精准匹配普通 location（推荐）
  location = /emby/Items/Counts {
      proxy_pass https://video.emos.best/emby/Items/Counts;
      proxy_ssl_server_name on;
  }
  
  # 方案二：正则匹配时 proxy_pass 仅保留协议与域名
  location ~* ^/(emby/)?Items/Counts$ {
      proxy_pass https://video.emos.best;
      proxy_ssl_server_name on;
  }
  ```


