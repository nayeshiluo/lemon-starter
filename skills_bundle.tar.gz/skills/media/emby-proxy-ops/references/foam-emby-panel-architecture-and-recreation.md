# Foam / 第三方 Emby 运营管理系统架构解析与自研复刻指南

## 一、 系统定位与背景
圈内常见的第三方 Emby 站点管理面板（如 FoamV1 / FoamV2，Docker 镜像 `ciwei123321/foam`）主要用于解决 Emby 官方后台在多人共享、公益服或商业运营场景下的痛点：
1. **原生权限颗粒度不足**：缺乏自动化到期回收、并发设备限制联动、开号配额管理。
2. **缺乏社交/社群联动**：无法直接与 Telegram Bot、微信等平台打通实现自助开号、签到、积分、查绑。
3. **多服/多节点分发困难**：多台 Emby 实例之间无法统一同步账号与密码。

---

## 二、 Foam 类面板核心底层技术架构拆解

所有 Emby 管理面板本质上均不改变 Emby 媒体流内核，而是作为**业务逻辑中间层（BFF）**对 Emby REST API 进行封装：

### 1. 账号全生命周期管理
* **开号**：`POST /Users/New` 创建基础用户，随后 `POST /Users/{Id}/Policy` 配置权限策略：
  * `EnableUserPreferenceAccess`: 限制修改个人设置
  * `BlockUnratedItems` / `EnableMediaPlayback`: 控制播放权限
  * `SimultaneousStreamLimit`: 限制单账号并发播放流数量
  * `EnabledFolders`: 指定可访问的媒体库白名单（如区分普通库与 18+ 专区）
* **封禁/停权**：定时巡检任务（Cron）比对本地数据库的账号到期时间，到期时调 `POST /Users/{Id}/Policy` 将 `IsDisabled` 设为 `true`，并调用 `POST /Sessions/Logout` 强制踢下线。
* **改密**：`POST /Users/{Id}/Password`。

### 2. 多服集群同步（Multi-Instance Sync）
* 管理层持久化保存各 Emby 节点的 `BaseURL` 与 `api_key`。
* 创建或更新账号时，异步向配置的所有集群节点并行派发 REST 请求，保证账号与密码多节点一致。

### 3. Telegram Bot 联动与运营体系
* **身份绑定**：Telegram User ID 与系统用户 ID 1:1 映射。
* **卡密/兑换码机制**：随机字符串 + 面值/天数，核销后向对应账号增加到期时间戳并调用 API 解禁。
* **活跃与积分**：群内签到增加积分，积分达到阈值自动换取观看时长或兑换更高等级媒体库权限。

### 4. 数据监控与大盘
* **实时播放监控**：轮询 `GET /Sessions`，过滤 `NowPlayingItem`，监控实时在线人数、播放码率、转码状态与客户端设备类型。
* **媒体库统计**：调用 `GET /Items/Counts` 获取全库影片与剧集总数。

---

## 三、 逆向闭源面板（如 Foam Docker 镜像）的可行性与风险

1. **镜像脱壳可行性**：
   * Docker 镜像是标准的分层 rootfs，拉取后可通过 `docker save <image> -o image.tar` 解包，或 `docker run -it --entrypoint sh <image>` 直接提取代码。
   * 若技术栈为 Node.js (NestJS / Vue / React)：代码多为 Webpack/Vite 混淆，路由表、Emby API 请求头与请求体明文基本可见，使用 AST 反混淆工具（如 `webcrack` / `deobfuscator`）可还原核心业务流程。
   * 若技术栈为 Go 二进制：剥离符号表后逆向成本较高，但字符串与网络端点可通过 `strings` 与静态反汇编分析。
2. **最大风险与缺陷**：
   * **云端心跳与授权锁（License Check）**：此类捐赠/商业面板通常强制定期与作者的授权服务器握手。本地去壳 patch 后，一旦作者端点变动或版本更新，维护将陷入无休止的修补循环。
   * **后门与暗桩**：闭源镜像存在未知的远程遥控指令、授权失效自动清空数据库等风险，使用于生产环境可能导致管理员 API Key 或服务器资产泄露。

---

## 四、 推荐路径：自研/轻量级开源替代方案

相比逆向修补，自建控制链路更安全、稳定且完全契合私有基础设施：

### 方案 1：开箱即用开源面板 —— Wizarr
* **架构**：Python / Vue，专为 Plex / Emby / Jellyfin 设计的现代化邀请入库面板。
* **特性**：支持生成单次/多次邀请码、预设用户权限模板（库权限、转码、到期时间）、Webhook 通知、Discord / Telegram 联动，无任何后门与商业限制。

### 方案 2：基于现有 Telegram 运维/群管 Bot 闭环自建（推荐）
直接在现有 Python 异步框架下封装轻量级 `EmbyClient`：
```python
import aiohttp

class EmbyClient:
    def __init__(self, base_url: str, api_key: str):
        self.base_url = base_url.rstrip('/')
        self.headers = {"X-Emby-Token": api_key, "Content-Type": "application/json"}

    async def create_user(self, session: aiohttp.ClientSession, username: str) -> dict:
        url = f"{self.base_url}/Users/New"
        async with session.post(url, json={"Name": username}, headers=self.headers) as resp:
            return await resp.json()

    async def set_policy(self, session: aiohttp.ClientSession, user_id: str, is_disabled: bool, stream_limit: int = 1):
        url = f"{self.base_url}/Users/{user_id}/Policy"
        policy = {
            "IsDisabled": is_disabled,
            "SimultaneousStreamLimit": stream_limit,
            "EnableMediaPlayback": not is_disabled
        }
        async with session.post(url, json=policy, headers=self.headers) as resp:
            return resp.status == 200 or resp.status == 204
```
配合本地 SQLite/PostgreSQL 记录用户过期时间，单机 100 行代码即可安全实现全自动开号、到期断开、多服同步，且与自建反代（如 MakkaPakka / Nginx 网关）无缝联动。
