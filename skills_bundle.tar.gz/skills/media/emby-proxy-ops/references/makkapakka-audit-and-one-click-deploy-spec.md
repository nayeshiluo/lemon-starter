# 玛卡巴卡 (MakkaPakka) 反代面板只读审计与一键部署架构规范

本规范用于对既有 Cloudflare Workers「玛卡巴卡反代面板」进行无损只读审计，以及在规划/制作「一键部署脚本 / 工具」时的架构拆分与避坑指南。

---

## 一、真假双实例测绘 SOP（四维交叉验证）

在实战运维中，管理者常将「电信优化链路」与「移动优化链路」在业务认知上称作“两套面板”，但底层往往存在两种截然不同的架构形态，必须通过 `域名 ➔ Worker ➔ Binding ➔ 源码` 四维验证，严禁仅凭域名或项目名称断言：

1. **维度一：自定义域名与路由绑定验证**
   - 检查 `GET /accounts/{acct}/workers/domains`：获取所有活跃的 Worker Custom Domains，确认各管理二级域名（如 `zjw.xxx` / `yd.xxx`）绑定的真实 `service` 名称。
   - 检查 `GET /zones/{zone}/workers/routes`：确认各运营商优选加速域名（如 `fd.xxx/*` / `yd-fd.xxx/*`）指向的 Worker 脚本。
2. **维度二：D1 数据库与存储绑定验证**
   - 检查 `GET /accounts/{acct}/workers/scripts/{name}/bindings`：提取 D1 绑定的 `database_id`。
   - 若两个访问域名指向的 Worker 具有相同的 `database_id`，则为**单实例多域名双轨模式**；若具有不同的 `database_id`，才是**物理隔离多实例模式**。
3. **维度三：边缘与计划任务验证**
   - 检查 `GET /accounts/{acct}/workers/scripts/{name}/schedules`：确认 Cron Triggers（如 `0 14 * * *` 定时播报）绑定的唯一目标。
4. **维度四：闲置孤儿实例探测**
   - 遍历账号下所有脚本，若存在同类型 Worker（如历史旧版），但未绑定任何 Custom Domains、未在 Zone 配置 Routes、且无 Cron 调度，标记为**历史闲置实例**，避免在迁移与一键部署时误混淆。

---

## 二、一键部署参数矩阵规范

制作一键部署工具（基于 Wrangler CLI 或 API 自动化编排）时，必须严格区分**全域可共用参数**与**单实例必须独立生成参数**：

| 参数类别 | 变量名 / 资源 | 存储类型 | 部署行为准则 |
| :--- | :--- | :--- | :--- |
| **可共用** | `CF_ACCOUNT_ID` | `plain_text` | 账号全局统一，从凭据上下文提取一次。 |
| **可共用** | `CF_ZONE_ID` | `plain_text` | 托管主域名 Zone ID，全域共用。 |
| **可共用** | `CF_API_TOKEN` | `secret_text` | 必须具备 `Zone.DNS:Edit` + `Zone.Analytics:Read` + `Workers:Edit` + `D1:Edit` 四项最小权限。 |
| **可共用** | `TG_BOT_TOKEN` | `secret_text` | 若多实例共享同一管理员播报 Bot，可复用同一 Token。 |
| **可共用** | `TG_CHAT_ID` | `plain_text` | 接收每日播报消息的目标 Chat ID。 |
| **必须独立** | `DB` (`database_id`) | `d1` | **严禁共用**。每个实例必须自动调用 `wrangler d1 create` 生成全新独立数据库，并自动执行 `schema.sql` 建表。 |
| **必须独立** | `CF_WORKER_NAME` | `plain_text` | 部署的 Worker 脚本名称，如 `makkapakka-telecom`、`makkapakka-mobile`。 |
| **必须独立** | `CF_DOMAIN` | `plain_text` | 该实例绑定的主入口域名（如 `zjw.xxx.xyz`），用于前端生成直达反代地址。 |
| **必须独立** | `ADMIN_TOKEN` | `secret_text` | 每个实例初始化时自动生成 24 位以上强随机字符串，严禁使用开源默认弱口令。 |
| **必须独立** | 优选子域与 Routes | DNS/Route | 每个实例按运营商绑定的独立优选域名（A 记录）与 Worker 路由。 |

---

## 三、D1 初始建表 Schema 模板

```sql
-- 1. 反代节点路由表
CREATE TABLE IF NOT EXISTS routes (
    prefix TEXT PRIMARY KEY,
    target TEXT,
    mode TEXT,
    remark TEXT,
    icon TEXT,
    cache_img TEXT DEFAULT 'on',
    sort_order INTEGER DEFAULT 0
);

-- 2. 独立访客与播放日志表
CREATE TABLE IF NOT EXISTS visitor_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    prefix TEXT,
    ip TEXT,
    country TEXT,
    ua TEXT
);
```

---

## 四、构建期代码混淆（AST Obfuscation）安全红线

将源码打包为一键部署制品时，实施混淆必须遵守以下边界条件，防止破坏 Serverless 运行时：

1. **入口函数保护**：
   - 保持顶层 `export default { async fetch, async scheduled }` 原生结构不被篡改或更名。
2. **环境变量与 Bindings 白名单隔离**：
   - 必须将 `env` 访问对象的属性名（`DB`, `ADMIN_TOKEN`, `CF_API_TOKEN`, `CF_ACCOUNT_ID`, `CF_ZONE_ID`, `CF_DOMAIN`, `CF_WORKER_NAME`, `TG_BOT_TOKEN`, `TG_CHAT_ID`）列入混淆器的 `reservedNames` 保留名单。属性名一旦被混淆压缩，将导致运行时解构出 `undefined`。
3. **禁用破坏性防篡改参数**：
   - 严禁启用 `selfDefending: true` 和 `debugProtection: true`，Cloudflare V8 隔离环境对于死循环检测和调用栈重写极为敏感，容易引发运行时直接 `Error: Script execution timed out` 或 1101 崩溃。
4. **前端模板分离构建**：
   - 面板的 `HTML_UI` 模板内包含的大量 DOM ID（如 `logTableBody`, `trafficToday`, `rttValue`）和内联方法，应采用前端无损压缩（HTML Minifier），避免被后端 JS 混淆器误将标签属性识别为标识符破坏页面交互。
