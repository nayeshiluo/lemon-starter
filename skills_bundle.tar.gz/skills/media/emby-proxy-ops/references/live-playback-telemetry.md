# Live playback telemetry: read-only diagnosis and evidence limits

Use this reference when diagnosing slow Emby/EMOS playback while the user is actively playing, especially through SenPlayer, Cloudflare Workers, or a reverse proxy. Goal: correlate one real playback across stages without replaying protected requests, exposing credentials/signed URLs, or claiming measurements that are not present in logs.

## Start with the live sample

1. Acknowledge that playback is happening now and inspect the available event/log sources immediately; avoid asking for more details until the first targeted log check has been attempted.
2. Use only actual runtime logs, supported tail/event streams, or existing access logs. Do not infer startup delay from public health endpoints, node-list calls, API probes, source-code inspection, or synthetic tests.
3. Correlate a single playback using a request/trace ID where available; otherwise use a narrow UTC time window, route/method, status, and byte counts. Never print query strings, auth headers, cookies, session tokens, media IDs, or signed playback URLs.
4. Do not replay PlaybackInfo, video, or other authenticated endpoints to manufacture a sample. If the player is already making requests, observe those logs. If no usable event source exists, state that promptly and give the minimum safe instrumentation needed for the next sample.

## Stage timings to capture

For the same playback, capture separately:

- PlaybackInfo: request start → upstream response headers/body completion (distinguish TTFB from full JSON completion where possible).
- Playback address redirect: each redirect status and elapsed time; record only relative/absolute classification and destination host category, never full Location.
- Video stream: request start → response headers, first body byte, then transfer duration/bytes; capture status and whether a Range request was present, but never record Range values.
- Retries/fallback: attempt number, anonymized route/line label, failure class and elapsed time, including timeout spent on a primary line before fallback.
- Duplicate requests: count identical method + normalized path class within the sample window, excluding query, token, and media identifier.
- Runtime placement and proxy buffering: verify from current deployed settings/configuration, not historical files. Treat configured Smart Placement as configuration evidence only; it does not prove the actual execution location or causality.

Report only durations actually measured and the source that supplied each one. If event ordering cannot reliably associate requests with one playback, mark correlation ambiguous rather than combining them.

## Minimal privacy-preserving instrumentation

If existing logs are insufficient, propose (do not deploy without authorization) a short-lived, narrowly scoped timer that emits: random trace ID, phase, UTC timestamp/duration, status, retry index, byte count, and Range-present boolean. Redact or omit full URLs, query strings, headers, cookies, tokens, signed links, usernames, media IDs, and client IPs. Use a short retention window and remove the instrumentation/logs after the sample. Preserve real-time authorization and node reads; do not cache credentials, auth decisions, session data, or signed playback links. Keep Range/If-Range, 206, Content-Range, redirects, and streaming behavior intact.

## Evidence and reporting discipline

- Separate source-code review, deployment/settings readback, public endpoint probes, authenticated API behavior, runtime request traces, and real-player playback tests.
- A valid HTTP response is not itself a playback timing sample. Do not present public API latency as startup time.
- Distinguish measured stage latency from total user-perceived startup, which depends on the player's own queue/buffer behavior and may need an on-device timestamp or player diagnostics.
- Identify the largest measured stage only when all relevant stage boundaries are observed for the same sample. Otherwise list missing evidence and do not diagnose a bottleneck.
- Read-only inspection remains the default. Before changing production routing, placement, buffering, retries, or timeouts, present evidence and obtain authorization; preserve auth, Range/206, stream-through behavior, and node configuration.

## Verify the live telemetry source before reading “no traffic”

A real player can be actively streaming while the inspected machine has no corresponding log entries: requests may go through a remote Cloudflare Worker, EMOS origin, or another proxy, while local Nginx/Caddy is inactive, unrelated, or configured without access logs. Empty local logs establish only that those local logs contain no event; they do not establish that playback did not occur.

1. Trace the configured player endpoint to the active serving route. Verify service/container/process and effective config, not just a saved config file or old deployment snapshot.
2. Inspect the actual remote telemetry configuration read-only. For Workers, verify `tail_consumers` and supported log delivery; check analytics/logging permissions separately. Do not treat `GET /accounts/{account_id}/workers/scripts/{script_name}/tail` as a live event stream: it may return the Worker script source. Check response content/type before parsing and do not print source or secrets into reports.
3. Correlate a user-confirmed active playback with the live source using a short UTC interval and safe metadata. If no event is available, report “not observable in checked log source” rather than “no traffic”; identify exactly which source is missing/unconfigured.
4. Do not repeatedly replay authenticated endpoints to compensate for absent telemetry. Ask for a narrow route identifier (e.g. carrier/domain label), not credentials, signed URLs, cookies, or tokens, if needed to identify the serving path.

Cloudflare's Tail Worker model requires a configured consumer Worker with a `tail()` handler; the consumer receives execution events after producer invocations. An empty `tail_consumers` list means this mechanism is not configured for that producer. A `200` response alone is not proof of event data; inspect safe metadata and response shape. Official reference: https://developers.cloudflare.com/workers/observability/logs/tail-workers/ (checked 2026-10-19; page states last updated 2026-10-02).

## Correct the report when the first log search used the wrong source

If a user says they are actively playing or asks specifically for EMOS traffic records, acknowledge that the previous empty local-log check did not cover the remote playback path. Re-check one targeted actual source/configuration, then explain the observability gap plainly. Do not imply the user's playback is contradicted by missing local logs.


Cloudflare endpoints that share a `tail`/`tails` name may have different semantics. Validate the exact response content type and payload before treating HTTP 200 as live logs: a multipart response may contain deployed Worker source rather than request events. Do not dump the returned body; classify it by safe metadata (content type, size, event-record presence) and discard it. Analytics permission failures are not evidence of absent traffic.

### Starting a temporary Workers Tail stream (verified API behavior)

For a supported live tail, use the account-scoped endpoint `POST /accounts/{account_id}/workers/scripts/{script_name}/tails` with a JSON body (empty `{}` is accepted in the verified environment). A successful response contains a tail ID, a short-lived WebSocket URL, and expiration. Connect to the returned URL using the `trace-v1` WebSocket subprotocol; omitting it can produce HTTP 406. The stream connection must be kept open while observing.

Important limits: successful tail creation and a WebSocket 101 handshake prove only that a session and transport were established—not that the producer is receiving the target player's requests or that useful events are being delivered. Validate an actual event from the intended host/Worker before saying “采集已就绪” or asking the user to play again. If the stream stays empty, do not infer no traffic: verify the actual player hostname/route and whether it maps to this producer, tail filters/permissions, and event delivery. Avoid repeated test traffic to protected media endpoints. Delete the created tail after the short observation window and securely remove its WebSocket URL; never print the URL or token-like path.

A useful privacy-preserving event observer should parse the request URL only in memory and emit only UTC event time, allowlisted host, method, one of the exact classes `playback_info`, `play_start`, `play_progress`, `play_stop`, `media_stream`, `other`, status, outcome, and colo. Never persist or print raw paths, query strings, headers, cookies, tokens, IPs, media IDs, or redirect Location. Route classification must be verified against the actual deployed dispatch logic and observed route forms; do not infer that all video traffic is `/Videos/`. Account for direct video routes, EMOS-specific `/emya/video` paths, and HLS manifests/segments only when confirmed by the deployed route implementation. If route syntax is obfuscated or cannot be verified without exposing secrets, classify conservatively as `other` and state that media classification is incomplete rather than broadening a vague `stream` regex and claiming coverage. **Do not store raw Tail lines or full event objects in a background process manager's output buffer:** classify inside the reader, emit only allowlisted metadata, and bound/aggregate counts. If the user requests only categories, do not print route-derived guesses. For trustworthy counts, retain aggregate counters by exact category and status; do not manually count a long, truncated transcript or include probes in player-request totals.

Use a two-stage validation before asking the user to replay: first keep a tail open and send one harmless, unauthenticated public health request per candidate entry point; confirm matching host, status, and the `other` classification in the tail. This validates the observer and each tested entry path only. Then keep the tail running and ask for a fresh playback (not playback already in progress, whose periodic progress pings are not startup evidence). Once the user stops/restarts or stops playback, continue observing for a bounded drain period because long-lived streaming invocations may only emit Tail events after completion. Do not label an absent video event as bypassing the Worker until the drain interval passes and the actual player hostname/route is verified. Report probe events separately from player events.

For Tail WebSocket consumption, connect using the returned short-lived URL with subprotocol `trace-v1`; the stream can send text or binary frames, so detect frame type and decode bytes as UTF-8 before JSON parsing. Require an actual event from each probe before saying collection is ready. The Tail API's successful create response and a WebSocket 101 alone prove control-plane/session setup, not event delivery. Do not log the returned stream URL, which may contain a secret-like identifier.

For event payload safety, do not put raw Tail messages into process-manager stdout, transcript logs, or files, even temporarily. Parse each frame in the observer, classify in memory, and emit bounded aggregates or allowlisted structured events only. A later truncation cannot restore privacy once raw payloads were recorded.

Use exact, tested route classifications rather than broad substring guesses. Separate `PlaybackInfo`, playback lifecycle endpoints, direct video, HLS manifests, and HLS segments only when their actual route patterns are verified against deployed code or observed requests. Do not classify every path containing `stream` or `/Items/` as video; artwork, metadata, image, or unrelated API requests can match. Strip query strings before classification and never include route text, IDs, response headers, or redirect Location in diagnostic output. If the production route grammar remains opaque, keep it as `other` and disclose incomplete classification; do not retrofit classifications by exposing past secret-bearing events.

Tail events provide request metadata/status, not reliable application stage durations, body-first-byte time, bytes transferred, or player first-frame time. Long-running streams may emit events only at completion. After playback stop/restart, continue for a bounded drain period; only infer a bypass when the correct hostname/route and a completed drain window are established. Distinguish event time from response-header latency and actual player startup.

Analytics `403` is a permission/API failure for that query, not evidence that traffic is absent. Check the exact documented endpoint and required permission separately; do not keep retrying the same denied request. If no supported stream can produce a verified target event and Analytics is denied, report telemetry as unavailable and stop—do not tell the user to replay repeatedly.

## Preparing a production timing patch (not deployment authorization)

When Tail confirms routing but lacks phase durations, first inspect the actual active proxy dispatch branch and identify precise boundaries: live auth plus per-request node/D1 lookup, each upstream fetch through response headers, redirect/Location handling, and final client response. Do not instrument only an outer fetch wrapper: that cannot reliably isolate these stages. Avoid global `fetch` monkey-patching or replacing/mutating D1 bindings, as concurrent Worker requests can contaminate measurements and alter semantics.

A safe proposal should be default-off and time-limited, emit a random request ID plus a strict allowlist of category, stage durations, and status only, and omit all URL/path/query, headers, cookies, tokens, IPs, media IDs, signed locations, and exception messages. Measure `fetch()` resolution as response-header availability only; it is not the first body byte or player first frame. Do not clone, consume, tee, or buffer a media body for timing. Preserve fresh auth and node reads, Range/If-Range, 206/Content-Range, redirects, and streaming behavior.

For heavily minified/obfuscated Workers, prepare the patch in an isolated Git copy of the exact deployed artifact and test the actual instrumented branch or be explicit that only structural checks were possible. Audit any existing draft before editing: trace the real dispatch branch from request classification through live node lookup, candidate fetch/retry, redirect handling, and every terminal response path. A helper added at file scope or a timer placed only on the apparent happy path can miss local failures, retries, and early returns. A placeholder test that checks helper names, key lists, or the root panel response is not behavioral verification. Require tests for timer disabled/expiry, allowlisted log shape, every-request DB/auth behavior, per-candidate upstream header timing, redirects, 206 semantics, local-vs-upstream status, and no media-body consumption. Review the exact diff and hashes before presenting it as deployable; if stage boundaries cannot be instrumented without broad risky restructuring, stop, restore the exact baseline in the isolated worktree, and report the concrete blocker rather than claiming completion.

Any later deployment remains a separate authorized action: make a timestamped backup of the current Worker and complete bindings/settings/schedules; construct upload metadata from the authoritative, secret-safe local binding source; assert exact binding names/types and D1 presence; deploy only after approval; read back code hash, all bindings/settings/schedules; and use the exact snapshot plus complete metadata for rollback. A source diff or passing isolated test never means production is changed.
