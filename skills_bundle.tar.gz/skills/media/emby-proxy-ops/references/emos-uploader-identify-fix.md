# EMOS 影视识别与直传 R2 故障排查与增强技术细节

## 1. 纯英文 / 罗马音文件名未能自动识别入库问题
### 现象
在将日剧/日漫或外文资源（例如 `Saijo.no.Osewa.S01E09.2026.1080p.LINETV.WEB-DL.H264.AAC-ADWeb.mkv`）自动化推送到 EMOS 平台时，调用 `/root/emos_uploader.py` 报错：
`Exception: EMOS 影视库未能自动识别该资源: <filename>`

### 原因
1. EMOS 官方影视库的 `/api/identify` 与 `/api/video/search` 仅按官方中文译名（如《才女的侍从 在满是高岭之花的贵族学校暗中照顾（毫无生活自理能力的）学院第一大小姐》）建档，并不支持纯罗马音或英文别名。
2. 之前的识别检索仅提取文件名首部英文单词搜索 EMOS，导致返回空列表（total: 0）。

### 解决方案与核心流程
1. **接入 TMDB 自动双语桥接**：
   - 提取文件名中的主体字符串或前 3 个单词。
   - 调用 TMDB API (`/search/multi`，`language=zh-CN`) 查询标准中文译名与 TMDB ID。
   - 从 TMDB 返回结果中提取中文完整标题与冒号/空格前的短标题，插入候选搜索词列表首位。
2. **多级匹配与季集树结构查找**：
   - 通过中文名称检索 EMOS 影视库 `/api/video/search`。
   - 获取目标 `video_id` 后拉取 `/api/video/tree` 逐层查找 Season 与 Episode 节点。
   - 若 EMOS 库内未包含最新季集但有 `tmdb_id`，触发 `/api/video/sync` 增量同步后再匹配。
## 2. 避免英文冠词/虚词检索 TMDB 导致泛匹配（如误识别为《八犬传》、《行尸走肉》）与中转 VPS 磁盘满排查
### 现象
1. 文件名如 `[早春晴朗].The.Early.Spring.2026.S01E13...mkv` 被识别为《THE八犬传》或《八犬传 —东方八犬异闻—》；`[黑猫与魔女的教室]...mp4` 被识别为《行尸走肉》（`The Walking Dead`）。
2. 下载任务下载到一半（如 46.8%）突然挂起卡死，qB 显示 `error` 状态。
3. 大文件上传报错 `Exception: 获取分片预签名 URL 失败: {"message":"number 不能大于 1000。"}`。

### 根因与规避
1. **中转 VPS 磁盘占满排查**：RackNerd VPS 空间有限（如 34GB），若前期大文件（如 11GB《年会不能停》）上传完成后未及时清理，会造成磁盘 100% 打满，导致后续种子下载触发 I/O 写入错误直接挂起。需执行批量清理已完成种子与对应文件释放空间。
2. **中文主名防御性提取**：必须优先提取文件名首部方括号/圆括号内的纯中文核心名（如 `早春晴朗`、`黑猫与魔女的教室`、`金色`），并将其作为主候选词注入搜索列表首位；防止直接将方括号全部作为噪声剔除导致只剩英文原名。
3. **严格过滤英文定冠词/介词**：严禁将 `The`、`A`、`An`、`In`、`El`、`La` 等虚词单独拆词后作为独立词条向 TMDB 检索，避免被泛搜索首项的大片/老番污染。
4. **分片上限 <= 1000**：大文件 (>10GB) 上传必须采用 `part_size = (file_size + 999) // 1000` 动态计算，确保分片数不超过 1000。

## 3. EMOS 超大文件 (>10GB) 上传超时与多线程并发直传 R2 优化

### 现象
发布 11GB+ 4K 原盘大文件（如《年会不能停》2160p 原盘）时，执行报错：
`Command '['sshpass', ... 'python3 /root/emos_uploader.py ...']' timed out after 900 seconds`

### 根因
1. **单线程串行分片吞吐瓶颈**：原脚本采用单线程按 10MB 分片串行上传，11GB+ 文件需进行 1,100+ 次单步 HTTP 请求，网络延时开销大，耗时超过 15 分钟。
2. **调度端硬编码超时限制**：Bot/运维调用端设置了 `timeout=900`（15分钟），触发 `subprocess.TimeoutExpired` 导致任务被强制切断。

### 解决方案
1. **多线程并发直传 R2**：
   - 采用 `concurrent.futures.ThreadPoolExecutor(max_workers=8)` 并发上传各个分片。
   - 使用 `threading.local()` 管理独立的 HTTP 会话（`requests.Session`），防止多线程连接池阻塞与竞争。
2. **大文件动态分片策略**：
   - `<= 1GB`：10MB 分片
   - `1GB ~ 5GB`：16MB 分片
   - `> 5GB`：32MB 分片（11GB 文件仅 ~350 分片，减少 70% 的 HTTP 往返请求）。
   - 保障无论文件多大，分片总数均严格控制在 1000 以内。
3. **分片重试与顺序组装**：
   - 单个分片支持 5 次指数退避重试（1.5s、3s、4.5s...）。
   - 收集所有线程返回的 `(part_num, etag)` 后，按 `number` 正序重排后再调用 `/complete` 提交合并。
4. **提升调度端超时上限**：
   - 将 SSH 远程执行超时从 900s 提升至 3600s（1小时），确保大文件稳定入库。

## 4. 多季剧集（S02/第二季）被硬编码为 S01E... 错误与季数提取修复

### 现象
对于第二季或多季剧集（例如 `[斩神之凡尘神域 第二季].Slay.the.Gods.2026.S02E11...mp4`），在自动化处理或标准重命名中被误判为 `S01E11`（第一季第 11 集），导致 EMOS 关联或 Emby 刮削季集严重错位。

### 根因
1. **季数写死硬编码**：命名格式化逻辑中在提取集数后直接返回 `f"{std_title} S01E{extracted_ep:02d}{ext}"`，忽略了文件名中已有的 `S02` 或 `第二季` 标识。
2. **中文季数未解析**：中文番剧常见 `第二季`、`第2季` 格式，未进行繁简与中文数字（一~十）转阿拉伯数字映射。

### 解决方案与核心正则
1. **动态解析 Season**：
   - 使用正则 `re.search(r'[Ss](\d{1,2})|[第\s](\d{1,2}|[一二三四五六七八九十]+)[季部]', base)`。
   - 结合 `chinese_to_digit` 将汉字季数转为阿拉伯数字。
   - 提取 TMDB 元数据时优先继承 TMDB 返回的 `season` 字段。
2. **标准季集规范组装**：
   - 输出统一规范为 `f"{title} S{season_num:02d}E{extracted_ep:02d}{ext}"`。
3. 支持自定义名称热接管：
   - 当用户在任务运行中途纠正名称时，支持后台监听进程无缝以最新自定义文件名（`custom_filename`）调用远端上传器关联入库。

## 5. EMOS 剧集多集上传被误绑定为第 1 集（S01E01）越界兜底陷阱与修复

### 现象
上传新更新的剧集第 2 集或更高集数（如《灵境行者 S01E02》）时，EMOS 官方 Telegram Bot 推送通知显示“感谢上传媒体文件：#灵境行者 S01E01”，且无论上传多少个不同画质的 E02 文件，全部被堆叠挂载在 S01E01 的媒体列表下。

### 根因
1. **EMOS 站点数据库新集数未录入**：EMOS 站点后台/TODB 尚未录入或同步出该剧的新集数条目，其影视树接口（`/api/video/tree`）返回的 `seasons[0]["episodes"]` 仅包含第 1 集（`episode_number: 1, episode_title: "TBA"`）。
2. **识别器盲目兜底至最后一集（Fallback Bug）**：
   - `identify_video()` 在遍历 `episodes` 时未找到 `episode_number == ep_num`；
   - 脚本旧逻辑存在宽松兜底：`if episodes: latest_ep = episodes[-1]; return latest_ep`；
   - 当库内仅有第 1 集时，最后一集就是第 1 集，导致上传程序把 E02、E03 文件的 `file_id` 强行调用 `/api/upload/video/save` 关联绑定到了第 1 集（`item_id: 1394993`）。

### 解决方案与规范
1. **严格禁止集数越界盲目兜底**：
   - 只要文件名中显式解析出了 `ep_num`（如 2），但当前 EMOS 剧集列表中无对应集数，必须严格拦截并输出提示：
     `EMOS 影视库中 {title} 尚未录入第 {ep_num} 集 (当前仅录入至第 {max_ep} 集)`；
   - 严禁执行 `latest_ep = episodes[-1]` 盲目回退，防止跨集污染与脏数据产生。
2. **清理与重新归位**：
   - 在 EMOS 网页端或通过 API 检查 `video_medias` 列表，解绑误挂在 S01E01 下的第 2 集文件；
   - 待 EMOS 站点录入或同步出对应集数节点后，再触发上传关联。

## 6. TMDB 同名/多词条冲突导致 EMOS 同步建档落空与集数断层

### 现象
剧集上传（如《今日宜偏爱》第 33 集）报错：
`[!] EMOS 影视库中 今日宜偏爱 第 1 季 尚未录入第 33 集 (当前仅录入至第 2 集)`
`[*] EMOS 站内未收录，尝试从 TMDB 同步建档: tmdb_id=335822, type=tv`
`FAIL! EMOS 影视库未能自动识别该资源: 今日宜偏爱 S01E33.mkv`

### 根因与内部机制
1. **TMDB 同名条目分叉**：
   - TMDB 存在两个完全同名的剧集词条：
     - 老条目（如 `tmdb_id=290589`，2024 年，仅建档 2 集）；
     - 新条目（如 `tmdb_id=335822`，2026 年正剧，全 40 集）。
2. **EMOS 站内绑定与集数断层**：
   - EMOS 站内已存在《今日宜偏爱》（`video_id=38574`），但绑定的是老条目 `tmdb_id=290589` / `todb_id=69686`，影视树内仅有第 1~2 集。
   - 上传器在 `video_title` 命中该条目后，检查影视树未发现第 33 集，触发严格越界拦截；
   - 随后尝试调用 EMOS `/api/video/sync` 传入目标真实 `tmdb_id=335822`。但 EMOS 后端依赖的上游 TODB 尚未收录新 `tmdb_id=335822`，导致 `/api/video/sync` 返回空数组 `[]`，建档失败。
3. **排查与应对规范**：
   - 区分是**集数未开放**还是**同名条目绑错/上游 TODB 未收录**：
     - 查询 TMDB API：比对各条目的 `first_air_date`、`number_of_episodes`；
     - 探测 EMOS `/api/video/tree?video_id=<id>` 确认当前站内绑定的 `tmdb_id`；
     - 探测 `PATCH /api/video/sync`：若返回 `[]`，说明上游 TODB 未收录该新 TMDB ID，自动化无法强行建档，严禁死循环调用；
   - **运维处理**：保留本地文件挂起，待站方管理员后台同步/建档，或在 EMOS 网页端手动开辟季集槽位后再行触发上传。

## 7. TMDB 官方译名与 EMOS 站内别名冲突导致识别落空（`?tmdb_id=` 反查穿透最佳实践）

### 现象
资源英文原名为 `Marble Hall Murders`（`tmdb_id=283319`），TMDB 官方中文为《大理石厅谋杀案》，但 EMOS 库内条目以民间译名《翠鸟谋杀案》（`video_id=202962`）建档。上传器调用 `identify_video("大理石厅谋杀案 S01E04.mp4")` 报错：
`FAIL! EMOS 影视库未能自动识别该资源: 大理石厅谋杀案 S01E04.mp4`

### 根因
1. **文本搜索单向盲区**：`emos_uploader.py` 仅使用文本标题（如 `search_queries = ['大理石厅谋杀案', 'Marble Hall Murders']`）请求 `/api/video/search?title=...`。
2. 即使触发了 `/api/video/sync`，由于接口二次检索仍使用 `search_queries` 文本关键词，无法命中站内以另一中文别名录入的影视条目。

### 解决方案与最佳实践
1. **优先启用 TMDB ID 反查穿透**：
   - EMOS 影视搜索接口原生支持 `GET /api/video/search?tmdb_id={target_tmdb_id}`。
   - 当通过 TMDB 成功解析出 `tmdb_id` 后，无论文本搜索是否成功或在触发 `/api/video/sync` 后，直接调用 `/api/video/search?tmdb_id={target_tmdb_id}` 进行反查。
   - 只要 `it.get("tmdb_id") == target_tmdb_id` 且 `video_type` 匹配（如 `tv`），即可彻底穿透中文译名与别名差异，秒级定位站内真实条目与集数树节点。

## 8. 线上部署副本漂移、串行分片吞吐实测与"重复上传"幂等陷阱

> 本节全部数字为 **2026-10-23 21:00–21:35 北京时间** 在真实机器上实测所得，采样口径见各条。别把它当固定成本，换机器/换时段须重测。

### 8.1 先核对线上副本，别信"技能里已修"

- 本参考 §3 记载的多线程并发直传 R2 修复，**并不等于线上机器已经生效**。
- 实测：VPS-LA（<PRIVATE_IDENTIFIER>）上 `/root/emos_uploader.py`（2026-09-28 05:05）仍是**单线程串行**实现——`with open(...) as f:` 循环内 `f.read(part_size)` → 单分片 PUT → 下一片，无 `ThreadPoolExecutor`。
- **规程：动手优化吞吐前，先 `grep -n "ThreadPoolExecutor\|max_workers" <线上上传器路径>` 确认补丁是否已部署**；没 grep 到就是串行，别按技能描述假设已并发。

### 8.2 串行分片的真实吞吐（瓶颈在并发，不在带宽/机器数量）

| 口径 | 实测值 |
|---|---|
| VPS-LA 上行（`speed.cloudflare.com/__up`，10MB） | **31.9 MB/s** |
| VPS-LA 串行上传器实际吞吐（303.4MB / 31 片，90s 传约 270MB） | **≈ 3.0 MB/s** |
| InstaBox 单连接上行 | 5.9 MB/s |
| InstaBox 4 并发合计 | 9.5 MB/s |

结论：串行实现只吃掉了约 **10% 的可用带宽**。同一份代码在单连 5.9 MB/s 的机器上反而比在 31.9 MB/s 的机器上跑得快——**先并发化，再谈加机器**。加节点、加磁盘解决不了这个瓶颈。

### 8.3 中断上传会烧掉该资源一周的上传额度（重要）

- 平台对同资源一周内重复上传返回 `此资源您一周内上传过`，上传器抛 `DuplicateUploadError`，**退出码 3**。
- 实测踩坑：用 `timeout 90` 截断一次上传做"只测前几步"的探活，平台侧已记录该次上传；随后完整重跑立刻被判重复。
- **规程：不要用"传一半就 kill"的方式验证链路。** 探活要么用真实待传且本周未传过的文件，要么只做到 `getUploadToken` 之前（识别 + 令牌获取）就停。已中断的上传需在平台侧确认分片状态，不要盲目重跑。

### 8.4 `/api/identify` 返回 guessit 404 不等于上传链路坏了

- 直连 `POST /api/identify` `{"filename":..., "type":"video"}` 可能返回：
  `{"success":false,"message":"Guessit 解析服务异常 (HTTP 404)"}`——这是平台侧 guessit 解析服务异常。
- 上传器的 `identify_video()` 有 fallback：官方识别失败后走本地 `smart_media_parser` 解析 + `/api/video/search` 站内检索，**照样能识别成功并完成上传**。
- 实测：上述 404 状态下，同一文件仍识别出 `雷霆令 - 第 1 季 - 第 31 集 (item_type: ve, item_id: 3145354)` 并正常分片上传。
- **规程：不要凭一次裸 identify 404 就断言"上传链路当前是坏的"**，必须实际跑一次上传器看完整流程。

### 8.5 `/api/user/info` 不是有效的令牌校验口

- 用 `Authorization: Bearer <token>` 请求 `/api/user/info` 返回 `{"success":false,"message":"emos api 404 :("}`——该路径不存在，**不能据此判定令牌失效**。
- 校验令牌请用真实业务口（`/api/identify` 或直接跑上传器），或看 `getUploadToken` 的返回。

### 8.6 上传是流式读盘，磁盘只受源文件约束

- 上传器 `open(local_path,"rb")` 边读边发，不生成临时副本。
- 因此"上传节点磁盘不够"通常是个伪问题：缺的是**源文件落地空间**，不是上传缓冲。
- 分流原则：源文件在哪台就在哪台传（零搬运）；LA 上已传完的源文件及时清理（34G 盘，71% 已用，实测仅剩 9.3G）。

---

## 9. 并发分片直传 R2 的实测与实现（2026-10-23，已部署）

> 采样时间：2026-10-23 21:35 北京时间，VPS-LA <PRIVATE_IDENTIFIER>，`/root/emos_uploader.py`

### 9.1 并发实测数字

| 场景 | 速度 | 耗时（303MB/31片） |
|---|---|---|
| 串行（workers=1） | 8.01 MB/s | 37.9s |
| 并发（workers=5） | **29.96 MB/s** | **10.1s** |
| 链路上限（cloudflare 10MB 测试） | 31.9 MB/s | — |

结论：5 线程已基本跑满链路带宽，提升 3.74×。再加线程无收益。

### 9.2 实现要点（三个不变量）

presign 一次返回全部分片的独立 URL，R2/S3 multipart 语义允许乱序并发 PUT；合并时按分片号提交。三个必须守住的约束：

1. **parts 按 number 显式排序**：并发完成顺序不确定，乱序提交会让 R2 合并失败。必须 `parts.sort(key=lambda p: p["number"])` 后再调 `/complete`。
2. **每线程独立 open+seek 读分片**：不能共享文件句柄。每个 `_put_part(num)` 自己 `open(local_path,"rb"); fh.seek(offset); fh.read(length)`。
3. **每线程独立 Session**：`requests.Session` 不保证并发安全，用 `threading.local()` 每线程懒建一个。

### 9.3 并发数配置

- 默认 5，通过环境变量 `EMOS_UPLOAD_WORKERS` 调整，上限 8。
- 调度端（`emos_service.execute_remote_vps_emos_upload`）从 `emos_config.json` 的 `upload_config.workers` 读取，注入 `EMOS_UPLOAD_WORKERS={n}` 环境变量到 SSH 远端命令。
- Bot 面板 `emos:upload_cfg` 提供 1/3/5/8 线程切换按钮，即改即生效。

### 9.4 fail-fast 行为

任一分片失败：`concurrent.futures.as_completed()` 上调用 `.result()` 立刻抛出，`_pool.shutdown(wait=False, cancel_futures=True)` 取消剩余未开始的分片，进入 abort 清理路径。不会静默成功。

### 9.5 测速工具

`/root/emos_speedtest.py`（已部署到 LA）：取 token → presign → 并发 PUT → abort 清理，全程不调 complete，不入库，输出单行 JSON。

```bash
python3 /root/emos_speedtest.py --workers=5 --size-mb=200
# 输出示例: {"ok": true, "workers": 5, "mb": 200.0, "parts": 20, "seconds": 7.5, "mbps": 26.66}
```

Bot 里 `emos:speedtest` 回调触发此测试，约 10~40s 返回结果卡片。

---

## 10. 运维 Bot EMOS 面板：上传通道与并发设置按钮

> 适用于 `/home/ubuntu/lemon-ops-bot/` 架构

### 10.1 新增面板结构

```
EMOS 主面板 (m:emos)
  └─ ⚡ 上传通道与并发 (emos:upload_cfg)
       ├─ [1 线程] [3 线程] [✅ 5 线程] [8 线程]  (emos:set_workers:{n})
       ├─ 🚀 实测上传速度 (emos:speedtest)
       └─ « 返回 EMOS 面板 (m:emos)
```

### 10.2 配置存储位置

`/home/ubuntu/lemon-ops-bot/emos_config.json` 的 `upload_config` 节点：

```json
{
  "upload_config": {
    "workers": 5,
    "channel": "zn_r2_upload"
  }
}
```

向后兼容：`load_config()` 对老文件自动补齐 `upload_config`，不覆盖用户已设值。

### 10.3 涉及文件

- `emos_module.py`：常量 `DEFAULT_UPLOAD_WORKERS=5`、`get_upload_cfg_text()`、`get_upload_cfg_keyboard()`、`load_config` 兼容补齐
- `emos_service.py`：三个新回调（`upload_cfg` / `set_workers` / `speedtest`）、`run_remote_speedtest()` 函数、`execute_remote_vps_emos_upload` 注入 `EMOS_UPLOAD_WORKERS`
- `/root/emos_speedtest.py`（LA 端）：独立测速脚本

---

## 11. Cloudreve V3 WebDAV 接入排查备忘（新站 <YOUR_PRIVATE_DOMAIN> / oss-ca.ftp2.eu.org）

> 2026-10-23，状态：**WebDAV 401，未打通**

### 11.1 站点基础信息

| 项 | 值 |
|---|---|
| 前端 | `<YOUR_PRIVATE_DOMAIN>`（Cloudflare 前置） |
| 后端 WebDAV 节点 | `oss-ca.ftp2.eu.org`（openresty，IP <YOUR_SERVER_IP>） |
| WebDAV 路径 | `/dav/`（OPTIONS 200，`DAV: 1, 2`，Allow 完整） |
| 后端框架 | Cloudreve V3（`/api/v3/site/config` 返回 code:0） |
| 登录用户名 | `user@example.com` |

### 11.2 踩坑：Cloudreve WebDAV 密码与登录密码分离

- Cloudreve 的 `/webdav/` 路径返回 200（前端 SPA），`/dav/` 才是真实 WebDAV 端点。
- WebDAV Basic Auth 不接受登录密码，**需在「设置 → WebDAV」单独生成 WebDAV 专用密码**。
- `oss-ca.ftp2.eu.org/dav/` 的 401 响应**不带 `WWW-Authenticate` 头**，不是标准 Basic 失败，是 openresty 后端自定义校验拦截。
- 穷举 24 种易混字符变体（0/O, 1/l/I, 5/S, 8/B）全部 401 → 确认不是字符识别问题，是密码类型不对（登录密码 vs WebDAV 专用密码）。

### 11.3 接入推荐方案（待密码到位）

```bash
# 用 rclone WebDAV remote（支持断点续传 + 校验）
rclone copy /local/file.mkv :webdav:/path/  \
  --webdav-url https://oss-ca.ftp2.eu.org/dav  \
  --webdav-vendor other  \
  --webdav-user "user@example.com"  \
  --webdav-pass "$(rclone obscure '<webdav专用密码>')"
```

失败时再落回 Cloudreve API v3 分片上传适配器。




