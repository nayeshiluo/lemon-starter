# EMOS 影视识别与直传 R2 故障排查与增强技术细节

## 1. 纯英文 / 罗马音文件名未能自动识别入库问题
### 现象
在将日剧/日漫或外文资源（例如 `Saijo.no.Osewa.S01E09.2026.1080p.LINETV.WEB-DL.H264.AAC-ADWeb.mkv`）自动化推送到 EMOS 平台时，调用 `/root/emos_uploader.py` 报错：
`Exception: EMOS 影视库未能自动识别该资源: <filename>`

### 原因
1. EMOS 官方影视库的 `/api/identify` 与 `/api/video/search` 仅按官方中文译名（如《才女的侍从 在满是高岭之花的贵族学校暗中照顾（毫无生活自理能力的）学院第一大小姐》）建档，并不支持纯罗马音或英文别名。
2. 之前的识别检索仅提取文件名首部英文单词搜索 EMOS，导致返回空列表（total: 0）。

### 解决方案与核心流程
1. **接入 TMDB 自动双语桥接**：
   - 提取文件名中的主体字符串或前 3 个单词。
   - 调用 TMDB API (`/search/multi`，`language=zh-CN`) 查询标准中文译名与 TMDB ID。
   - 从 TMDB 返回结果中提取中文完整标题与冒号/空格前的短标题，插入候选搜索词列表首位。
2. **多级匹配与季集树结构查找**：
   - 通过中文名称检索 EMOS 影视库 `/api/video/search`。
   - 获取目标 `video_id` 后拉取 `/api/video/tree` 逐层查找 Season 与 Episode 节点。
   - 若 EMOS 库内未包含最新季集但有 `tmdb_id`，触发 `/api/video/sync` 增量同步后再匹配。
## 2. 避免英文冠词/虚词检索 TMDB 导致泛匹配（如误识别为《行尸走肉》）与分片数硬限制
### 现象
1. 文件名如 `[黑猫与魔女的教室].The.Classroom.of.a.Black.Cat...mp4` 被识别为《行尸走肉》（`The Walking Dead`）。
2. 大文件上传报错 `Exception: 获取分片预签名 URL 失败: {"message":"number 不能大于 1000。"}`。

### 根因与规避
1. **中文提取优先**：先提取方括号/圆括号内的中文名（如 `黑猫与魔女的教室`、`金色`），避免剥离后只剩英文。
2. **过滤泛词**：严禁将 `The`、`A`、`An`、`In` 等单独作为词条去 TMDB 检索，避免返回列表首项的泛大片。
3. **分片上限 <= 1000**：大文件 (>10GB) 上传必须采用 `part_size = (file_size + 999) // 1000` 动态计算，确保分片数不超过 1000。

## 3. EMOS 超大文件 (>10GB) 上传超时与多线程并发直传 R2 优化

### 现象
发布 11GB+ 4K 原盘大文件（如《年会不能停》2160p 原盘）时，执行报错：
`Command '['sshpass', ... 'python3 /root/emos_uploader.py ...']' timed out after 900 seconds`

### 根因
1. **单线程串行分片吞吐瓶颈**：原脚本采用单线程按 10MB 分片串行上传，11GB+ 文件需进行 1,100+ 次单步 HTTP 请求，网络延时开销大，耗时超过 15 分钟。
2. **调度端硬编码超时限制**：Bot/运维调用端设置了 `timeout=900`（15分钟），触发 `subprocess.TimeoutExpired` 导致任务被强制切断。

### 解决方案
1. **多线程并发直传 R2**：
   - 采用 `concurrent.futures.ThreadPoolExecutor(max_workers=8)` 并发上传各个分片。
   - 使用 `threading.local()` 管理独立的 HTTP 会话（`requests.Session`），防止多线程连接池阻塞与竞争。
2. **大文件动态分片策略**：
   - `<= 1GB`：10MB 分片
   - `1GB ~ 5GB`：16MB 分片
   - `> 5GB`：32MB 分片（11GB 文件仅 ~350 分片，减少 70% 的 HTTP 往返请求）。
   - 保障无论文件多大，分片总数均严格控制在 1000 以内。
3. **分片重试与顺序组装**：
   - 单个分片支持 5 次指数退避重试（1.5s、3s、4.5s...）。
   - 收集所有线程返回的 `(part_num, etag)` 后，按 `number` 正序重排后再调用 `/complete` 提交合并。
4. **提升调度端超时上限**：
   - 将 SSH 远程执行超时从 900s 提升至 3600s（1小时），确保大文件稳定入库。

