# EMOS 影视识别与直传 R2 故障排查与增强技术细节

## 1. 纯英文 / 罗马音文件名未能自动识别入库问题
### 现象
在将日剧/日漫或外文资源（例如 `Saijo.no.Osewa.S01E09.2026.1080p.LINETV.WEB-DL.H264.AAC-ADWeb.mkv`）自动化推送到 EMOS 平台时，调用 `/root/emos_uploader.py` 报错：
`Exception: EMOS 影视库未能自动识别该资源: <filename>`

### 原因
1. EMOS 官方影视库的 `/api/identify` 与 `/api/video/search` 仅按官方中文译名（如《才女的侍从 在满是高岭之花的贵族学校暗中照顾（毫无生活自理能力的）学院第一大小姐》）建档，并不支持纯罗马音或英文别名。
2. 之前的识别检索仅提取文件名首部英文单词搜索 EMOS，导致返回空列表（total: 0）。

### 解决方案与核心流程
1. **接入 TMDB 自动双语桥接**：
   - 提取文件名中的主体字符串或前 3 个单词。
   - 调用 TMDB API (`/search/multi`，`language=zh-CN`) 查询标准中文译名与 TMDB ID。
   - 从 TMDB 返回结果中提取中文完整标题与冒号/空格前的短标题，插入候选搜索词列表首位。
2. **多级匹配与季集树结构查找**：
   - 通过中文名称检索 EMOS 影视库 `/api/video/search`。
   - 获取目标 `video_id` 后拉取 `/api/video/tree` 逐层查找 Season 与 Episode 节点。
   - 若 EMOS 库内未包含最新季集但有 `tmdb_id`，触发 `/api/video/sync` 增量同步后再匹配。
3. **透传自定义发布标题**：
   - 主控 Bot 流水线（`emos_service.py`）将规范化重命名后的标题作为参数传递给 VPS 的 `emos_uploader.py`，确保即使原文件名异常也能双重兜底识别。
