# EMOS 影视识别与直传 R2 故障排查与增强技术细节

## 1. 纯英文 / 罗马音文件名未能自动识别入库问题
### 现象
在将日剧/日漫或外文资源（例如 `Saijo.no.Osewa.S01E09.2026.1080p.LINETV.WEB-DL.H264.AAC-ADWeb.mkv`）自动化推送到 EMOS 平台时，调用 `/root/emos_uploader.py` 报错：
`Exception: EMOS 影视库未能自动识别该资源: <filename>`

### 原因
1. EMOS 官方影视库的 `/api/identify` 与 `/api/video/search` 仅按官方中文译名（如《才女的侍从 在满是高岭之花的贵族学校暗中照顾（毫无生活自理能力的）学院第一大小姐》）建档，并不支持纯罗马音或英文别名。
2. 之前的识别检索仅提取文件名首部英文单词搜索 EMOS，导致返回空列表（total: 0）。

### 解决方案与核心流程
1. **接入 TMDB 自动双语桥接**：
   - 提取文件名中的主体字符串或前 3 个单词。
   - 调用 TMDB API (`/search/multi`，`language=zh-CN`) 查询标准中文译名与 TMDB ID。
   - 从 TMDB 返回结果中提取中文完整标题与冒号/空格前的短标题，插入候选搜索词列表首位。
2. **多级匹配与季集树结构查找**：
   - 通过中文名称检索 EMOS 影视库 `/api/video/search`。
   - 获取目标 `video_id` 后拉取 `/api/video/tree` 逐层查找 Season 与 Episode 节点。
   - 若 EMOS 库内未包含最新季集但有 `tmdb_id`，触发 `/api/video/sync` 增量同步后再匹配。
## 2. 避免英文冠词/虚词检索 TMDB 导致泛匹配（如误识别为《八犬传》、《行尸走肉》）与中转 VPS 磁盘满排查
### 现象
1. 文件名如 `[早春晴朗].The.Early.Spring.2026.S01E13...mkv` 被识别为《THE八犬传》或《八犬传 —东方八犬异闻—》；`[黑猫与魔女的教室]...mp4` 被识别为《行尸走肉》（`The Walking Dead`）。
2. 下载任务下载到一半（如 46.8%）突然挂起卡死，qB 显示 `error` 状态。
3. 大文件上传报错 `Exception: 获取分片预签名 URL 失败: {"message":"number 不能大于 1000。"}`。

### 根因与规避
1. **中转 VPS 磁盘占满排查**：RackNerd VPS 空间有限（如 34GB），若前期大文件（如 11GB《年会不能停》）上传完成后未及时清理，会造成磁盘 100% 打满，导致后续种子下载触发 I/O 写入错误直接挂起。需执行批量清理已完成种子与对应文件释放空间。
2. **中文主名防御性提取**：必须优先提取文件名首部方括号/圆括号内的纯中文核心名（如 `早春晴朗`、`黑猫与魔女的教室`、`金色`），并将其作为主候选词注入搜索列表首位；防止直接将方括号全部作为噪声剔除导致只剩英文原名。
3. **严格过滤英文定冠词/介词**：严禁将 `The`、`A`、`An`、`In`、`El`、`La` 等虚词单独拆词后作为独立词条向 TMDB 检索，避免被泛搜索首项的大片/老番污染。
4. **分片上限 <= 1000**：大文件 (>10GB) 上传必须采用 `part_size = (file_size + 999) // 1000` 动态计算，确保分片数不超过 1000。

## 3. EMOS 超大文件 (>10GB) 上传超时与多线程并发直传 R2 优化

### 现象
发布 11GB+ 4K 原盘大文件（如《年会不能停》2160p 原盘）时，执行报错：
`Command '['sshpass', ... 'python3 /root/emos_uploader.py ...']' timed out after 900 seconds`

### 根因
1. **单线程串行分片吞吐瓶颈**：原脚本采用单线程按 10MB 分片串行上传，11GB+ 文件需进行 1,100+ 次单步 HTTP 请求，网络延时开销大，耗时超过 15 分钟。
2. **调度端硬编码超时限制**：Bot/运维调用端设置了 `timeout=900`（15分钟），触发 `subprocess.TimeoutExpired` 导致任务被强制切断。

### 解决方案
1. **多线程并发直传 R2**：
   - 采用 `concurrent.futures.ThreadPoolExecutor(max_workers=8)` 并发上传各个分片。
   - 使用 `threading.local()` 管理独立的 HTTP 会话（`requests.Session`），防止多线程连接池阻塞与竞争。
2. **大文件动态分片策略**：
   - `<= 1GB`：10MB 分片
   - `1GB ~ 5GB`：16MB 分片
   - `> 5GB`：32MB 分片（11GB 文件仅 ~350 分片，减少 70% 的 HTTP 往返请求）。
   - 保障无论文件多大，分片总数均严格控制在 1000 以内。
3. **分片重试与顺序组装**：
   - 单个分片支持 5 次指数退避重试（1.5s、3s、4.5s...）。
   - 收集所有线程返回的 `(part_num, etag)` 后，按 `number` 正序重排后再调用 `/complete` 提交合并。
4. **提升调度端超时上限**：
   - 将 SSH 远程执行超时从 900s 提升至 3600s（1小时），确保大文件稳定入库。

## 4. 多季剧集（S02/第二季）被硬编码为 S01E... 错误与季数提取修复

### 现象
对于第二季或多季剧集（例如 `[斩神之凡尘神域 第二季].Slay.the.Gods.2026.S02E11...mp4`），在自动化处理或标准重命名中被误判为 `S01E11`（第一季第 11 集），导致 EMOS 关联或 Emby 刮削季集严重错位。

### 根因
1. **季数写死硬编码**：命名格式化逻辑中在提取集数后直接返回 `f"{std_title} S01E{extracted_ep:02d}{ext}"`，忽略了文件名中已有的 `S02` 或 `第二季` 标识。
2. **中文季数未解析**：中文番剧常见 `第二季`、`第2季` 格式，未进行繁简与中文数字（一~十）转阿拉伯数字映射。

### 解决方案与核心正则
1. **动态解析 Season**：
   - 使用正则 `re.search(r'[Ss](\d{1,2})|[第\s](\d{1,2}|[一二三四五六七八九十]+)[季部]', base)`。
   - 结合 `chinese_to_digit` 将汉字季数转为阿拉伯数字。
   - 提取 TMDB 元数据时优先继承 TMDB 返回的 `season` 字段。
2. **标准季集规范组装**：
   - 输出统一规范为 `f"{title} S{season_num:02d}E{extracted_ep:02d}{ext}"`。
3. 支持自定义名称热接管：
   - 当用户在任务运行中途纠正名称时，支持后台监听进程无缝以最新自定义文件名（`custom_filename`）调用远端上传器关联入库。

## 5. EMOS 剧集多集上传被误绑定为第 1 集（S01E01）越界兜底陷阱与修复

### 现象
上传新更新的剧集第 2 集或更高集数（如《灵境行者 S01E02》）时，EMOS 官方 Telegram Bot 推送通知显示“感谢上传媒体文件：#灵境行者 S01E01”，且无论上传多少个不同画质的 E02 文件，全部被堆叠挂载在 S01E01 的媒体列表下。

### 根因
1. **EMOS 站点数据库新集数未录入**：EMOS 站点后台/TODB 尚未录入或同步出该剧的新集数条目，其影视树接口（`/api/video/tree`）返回的 `seasons[0]["episodes"]` 仅包含第 1 集（`episode_number: 1, episode_title: "TBA"`）。
2. **识别器盲目兜底至最后一集（Fallback Bug）**：
   - `identify_video()` 在遍历 `episodes` 时未找到 `episode_number == ep_num`；
   - 脚本旧逻辑存在宽松兜底：`if episodes: latest_ep = episodes[-1]; return latest_ep`；
   - 当库内仅有第 1 集时，最后一集就是第 1 集，导致上传程序把 E02、E03 文件的 `file_id` 强行调用 `/api/upload/video/save` 关联绑定到了第 1 集（`item_id: 1394993`）。

### 解决方案与规范
1. **严格禁止集数越界盲目兜底**：
   - 只要文件名中显式解析出了 `ep_num`（如 2），但当前 EMOS 剧集列表中无对应集数，必须严格拦截并输出提示：
     `EMOS 影视库中 {title} 尚未录入第 {ep_num} 集 (当前仅录入至第 {max_ep} 集)`；
   - 严禁执行 `latest_ep = episodes[-1]` 盲目回退，防止跨集污染与脏数据产生。
2. **清理与重新归位**：
   - 在 EMOS 网页端或通过 API 检查 `video_medias` 列表，解绑误挂在 S01E01 下的第 2 集文件；
   - 待 EMOS 站点录入或同步出对应集数节点后，再触发上传关联。

## 6. TMDB 同名/多词条冲突导致 EMOS 同步建档落空与集数断层

### 现象
剧集上传（如《今日宜偏爱》第 33 集）报错：
`[!] EMOS 影视库中 今日宜偏爱 第 1 季 尚未录入第 33 集 (当前仅录入至第 2 集)`
`[*] EMOS 站内未收录，尝试从 TMDB 同步建档: tmdb_id=335822, type=tv`
`FAIL! EMOS 影视库未能自动识别该资源: 今日宜偏爱 S01E33.mkv`

### 根因与内部机制
1. **TMDB 同名条目分叉**：
   - TMDB 存在两个完全同名的剧集词条：
     - 老条目（如 `tmdb_id=290589`，2024 年，仅建档 2 集）；
     - 新条目（如 `tmdb_id=335822`，2026 年正剧，全 40 集）。
2. **EMOS 站内绑定与集数断层**：
   - EMOS 站内已存在《今日宜偏爱》（`video_id=38574`），但绑定的是老条目 `tmdb_id=290589` / `todb_id=69686`，影视树内仅有第 1~2 集。
   - 上传器在 `video_title` 命中该条目后，检查影视树未发现第 33 集，触发严格越界拦截；
   - 随后尝试调用 EMOS `/api/video/sync` 传入目标真实 `tmdb_id=335822`。但 EMOS 后端依赖的上游 TODB 尚未收录新 `tmdb_id=335822`，导致 `/api/video/sync` 返回空数组 `[]`，建档失败。
3. **排查与应对规范**：
   - 区分是**集数未开放**还是**同名条目绑错/上游 TODB 未收录**：
     - 查询 TMDB API：比对各条目的 `first_air_date`、`number_of_episodes`；
     - 探测 EMOS `/api/video/tree?video_id=<id>` 确认当前站内绑定的 `tmdb_id`；
     - 探测 `PATCH /api/video/sync`：若返回 `[]`，说明上游 TODB 未收录该新 TMDB ID，自动化无法强行建档，严禁死循环调用；
   - **运维处理**：保留本地文件挂起，待站方管理员后台同步/建档，或在 EMOS 网页端手动开辟季集槽位后再行触发上传。

## 7. TMDB 官方译名与 EMOS 站内别名冲突导致识别落空（`?tmdb_id=` 反查穿透最佳实践）

### 现象
资源英文原名为 `Marble Hall Murders`（`tmdb_id=283319`），TMDB 官方中文为《大理石厅谋杀案》，但 EMOS 库内条目以民间译名《翠鸟谋杀案》（`video_id=202962`）建档。上传器调用 `identify_video("大理石厅谋杀案 S01E04.mp4")` 报错：
`FAIL! EMOS 影视库未能自动识别该资源: 大理石厅谋杀案 S01E04.mp4`

### 根因
1. **文本搜索单向盲区**：`emos_uploader.py` 仅使用文本标题（如 `search_queries = ['大理石厅谋杀案', 'Marble Hall Murders']`）请求 `/api/video/search?title=...`。
2. 即使触发了 `/api/video/sync`，由于接口二次检索仍使用 `search_queries` 文本关键词，无法命中站内以另一中文别名录入的影视条目。

### 解决方案与最佳实践
1. **优先启用 TMDB ID 反查穿透**：
   - EMOS 影视搜索接口原生支持 `GET /api/video/search?tmdb_id={target_tmdb_id}`。
   - 当通过 TMDB 成功解析出 `tmdb_id` 后，无论文本搜索是否成功或在触发 `/api/video/sync` 后，直接调用 `/api/video/search?tmdb_id={target_tmdb_id}` 进行反查。
   - 只要 `it.get("tmdb_id") == target_tmdb_id` 且 `video_type` 匹配（如 `tv`），即可彻底穿透中文译名与别名差异，秒级定位站内真实条目与集数树节点。




