# 二楼有请 (Lemon 2F): 生产级影视众包入库、二楼币总账与全自动闭环架构设计

## 1. 系统定位与核心原则
针对 Emby 媒体服主“求片繁琐、全靠人工搬运、缺乏社区激励与风控防骗”的痛点，构建基于“众包磁力提交 + 二楼币 (🪙) 经济总账 + TMDB 穿透对账 + qB/FFprobe 自动质检 + 规范化落盘入库 + Telegram Bot 联动”的可长期运行工业级系统。

### 四大铁律底线：
1. **数据库决定最终唯一性**：严禁只依赖 Python 内存 if、Redis 锁或种子 Hash 判定重复；必须通过数据库级 Partial Unique Index 物理拦截。
2. **Emby 真正确认入库后才能 ACCEPTED**：严禁落盘刷新后立即发币，必须进入 `WAITING_EMBY` 轮询确认 TMDB 与季集存在。
3. **ACCEPTED 之后才能结算积分**：任何环节失败均不得发币。
4. **所有发币、扣币、结算必须绝对幂等**：账本 Append-Only + 物理 `idempotency_key` 唯一索引。

---

## 2. 核心数据模型与关系设计 (SQLAlchemy 2.0 Async + Alembic)

### 🗄️ 1. 实体职责拆分
- **`MediaTask`**：作品主体任务（`tmdb_id`, `media_type`, `title`, `year`, `status`）。
- **`TaskItem`**：物理单集条目（电影为 NULL，剧集为精确 `season`, `episode`），支持抢占锁定（`reserved_by`, `reserved_until`）。
- **`Submission` & `SubmissionItem`**：投稿记录与单项质检明细。**支持多集 Torrent 下载后扫描拆分为多个 SubmissionItem 逐集独立质检与入库**。
- **`PointsLedger`**：**二楼币全量收支账本**。记录变动数值、余额快照，强制 `idempotency_key` 唯一键防并发双花。
- **`SignInRecord`**：签到防重表，`UNIQUE(user_id, sign_date)` 防止并发双签。
- **`WantedTask`**：精准悬赏池，按 `(tmdb_id, media_type, season, episode)` 精确匹配，发布时强制 Escrow 扣除/冻结二楼币。

### 🛡️ 2. 数据库级 Partial Unique Indexes 核心防重复方案
解决 PostgreSQL 中 `NULL != NULL` 导致常规 `UNIQUE(task_id, season, episode)` 无法约束电影的缺陷：
```sql
-- 1. 电影唯一 Accepted 约束
CREATE UNIQUE INDEX uq_accepted_movie_item
ON submission_items(task_id)
WHERE status = 'accepted' AND media_type = 'movie';

-- 2. 剧集单集唯一 Accepted 约束
CREATE UNIQUE INDEX uq_accepted_episode_item
ON submission_items(task_id, season, episode)
WHERE status = 'accepted' AND media_type != 'movie';
```

---

## 3. 完整工业级任务流状态机

```text
用户提交磁力
    ↓
TMDB 识别 (支持 URL/ID/名称+年份) & Emby 穿透查重
    ↓
Redis 分布式快速抢占锁 + 数据库建立 TaskItem Reservation
    ↓
提交 qB (分类打标 lemon_2f, 记录 info_hash)
    ↓
[DOWNLOADING] (基于真实时间戳 last_progress_at 判定 15 分钟死种熔断)
    ↓
下载完成 -> 扫描视频流并排除 sample/trailer/extras
    ↓
[INSPECTING] FFprobe 深度指纹质检 (时长 >= 30s, 码率, 4K识别, 编码)
    ↓
[DELIVERING] 规范化落盘 (TMDB 标准命名, 校验同分区硬链接, 失败回退复制)
    ↓
触发 Emby 媒体库全局扫描
    ↓
[WAITING_EMBY] 定时轮询 Emby API
    ↓
真实确认 Emby 库中存在目标 TMDB ID 及季集 (超时 30 分钟)
    ↓
[ACCEPTED] 数据库原子事务更新 TaskItem 状态
    ↓
积分原子结算 (写入 PointsLedger 并检查 idempotency_key)
    ↓
触发关联悬赏结算 (精准匹配单集释放 Escrow)
```

---

## 4. 关键服务与算法设计

### 🔢 1. 缺集计算与区间压缩引擎 (`MissingEpisodeEngine`)
API、Bot、Web 前端必须共用同一套引擎，输入目标集数（如 1-178）与已收录集数列表（如 `[7]`），输出：
- 缺失集数数组：`[1, 2, 3, 4, 5, 6, 8, ..., 178]`
- 友好区间字符串：`"1-6"`, `"8-178"`
- 总体完成率：`0.56%`

### ⏱️ 2. 死种熔断判定算法
严禁依赖 worker 轮询 tick 计数（避免 worker 间隔改变导致死种判定时间漂移）。改为：
```python
if current_speed == 0 and progress < 100.0:
    if (datetime.now(timezone.utc) - last_progress_at).total_seconds() > DEAD_TIMEOUT_SECONDS:
        # 触发死种熔断，取消下载并清理垃圾文件
```

### 🔒 3. Redis 分布式锁与 Lua 释放
加锁携带 UUID Token，释放锁时使用 Lua 脚本比对，防止并发超时后误删他人锁：
```lua
if redis.call("get", KEYS[1]) == ARGV[1] then
    return redis.call("del", KEYS[1])
else
    return 0
end
```

---

## 5. Docker 生产级打包与持久化规范
1. **统一 Package 路径**：Docker build context 设为项目根目录，`COPY backend /app/backend`，启动命令使用 `uvicorn backend.main:app`，杜绝 `ModuleNotFoundError`。
2. **PostgreSQL + Redis 标配**：Compose 默认提供 PostgreSQL 容器持久化卷与 Redis，SQLite 仅作为开发模式 fallback。
3. **Alembic 迁移管理**：启动脚本执行 `alembic upgrade head`，严禁生产依赖破坏性 `create_all/drop`。
