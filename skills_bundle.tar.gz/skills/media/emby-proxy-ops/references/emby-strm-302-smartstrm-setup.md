# Emby + SmartStrm + rclone 302 直链全套配置与避坑指南

用于指导将主流网盘（115、夸克、天翼、WebDAV、OpenList 等）通过 rclone + SmartStrm 生成 STRM 并在 Emby 中实现 302 直链低占用秒开播放。

## 一、 架构原理与核心优势

- **数据流解耦**：
  - **元数据流**：Emby 仅读取本地由 SmartStrm 生成的轻量 `.strm` 文本文件（几十字节），并从 TMDB 抓取海报、演职员与 NFO 元数据。
  - **媒体流**：播放器（SenPlayer、Infuse、VidHub、Emby Web）发起播放请求时，SmartStrm 截获并向客户端返回 `302 Found` 重定向响应，客户端直接连接网盘 CDN 拉取视频流。
- **资源极度省流**：
  - **服务器 CPU/GPU**：不需要进行繁重的转码压制（1~2 核即可支撑海量并发）。
  - **网络出网带宽**：服务器出网流量仅为几 KB 的 HTTP 302 头，彻底杜绝服务器中转流量跑满（完美契合 AWS 100GB/月等限流环境）。
  - **硬件要求基线**：CPU 1核+、内存建议 2GB~4GB（防大库扫描时 OOM）、硬盘 20GB~50GB（主要存放海报元数据缓存）。

---

## 二、 关键配置与死活避坑（核心）

### 1. Emby 媒体库配置（⚠️ 绝对核心：防网盘 API 429 封号）

在 Emby 控制台创建媒体库时：
- **文件夹路径选择**：必须且仅指向 SmartStrm 输出的 `strm` 本地挂载目录。**严禁直接将 rclone 原始网盘大文件挂载目录加入媒体库**。
- **必须全部关闭的高危深度探针功能**：
  - ❌ **提取章节图像 (Extract chapter images)**：必须设为“从不 / Never”。
  - ❌ **提取视频缩略图 (Trickplay / BIF Keyframes)**：必须禁用。
  - ❌ **片头/片尾标记分析 (Marker Detection)**：必须关闭。
  - ❌ **媒体分析探针深度抓取 (Media Info Probe)**：禁用深度探针。
  > **致命坑点**：如果开启上述任何一项，Emby 后台刮削或计划任务会通过 HTTP Range 请求持续不断地下载网盘视频分片进行逐帧画面分析，几分钟内就会拉爆服务器带宽并触发 115 / 夸克 / 阿里云盘的高频下载风控，导致 API 429 报错甚至永久封禁账号！

### 2. Emby 用户播放权限配置（强制 Direct Play）

- 进入 **设置 ➔ 用户 ➔ 目标用户 ➔ 播放 (Playback)**：
  - ❌ 取消勾选 **「允许需要转码的视频播放 (Allow video playback that requires transcoding)」**。
  - ❌ 取消勾选 **「允许需要转换的视频播放 (Allow video playback that requires conversion)」**。
  - ✅ 仅保留 **「允许直接播放 (Direct Play)」** 与 **「允许直接串流 (Direct Stream)」**。
- **原理**：STRM 必须依赖客户端原生解码。如果客户端不支持某种音频/视频编码而触发服务端转码，Emby 会强行通过网络把整部视频流实时拉回服务器进行压制，不仅瞬间吃满 CPU，还会将服务器带宽全部吞噬。

### 3. SmartStrm 端配置

- **存储驱动配置**：接入网盘开放平台 API 或 Cookie / WebDAV / OpenList 端点。
- **任务规划**：
  - 源路径：选择网盘影视根目录（建议已按 TMDB 标准分类命名）。
  - 目标路径：容器内部映射的 `/strm` 目录。
  - 启用 **增量生成** 与 **远端同步删除**（保持 Emby 库与网盘一致）。
- **302 直链 Host 配置**：
  - 配置客户端可访问的 SmartStrm 302 服务 Host（包含内网 IP 或绑定的公网反代域名与端口）。
  - 确保客户端请求播放时重定向解析的 URL 能在播放器本地网络直通网盘 CDN。

### 4. rclone 挂载参数调优（若用于辅助读取原盘结构）

若需要 rclone 辅助挂载网盘目录：
```bash
rclone mount <remote>:<path> /mnt/cloud \
  --vfs-cache-mode off \
  --dir-cache-time 24h \
  --attr-timeout 24h \
  --read-only \
  --allow-other \
  --buffer-size 0M
```
- `--vfs-cache-mode off`：STRM 模式下无需在服务器磁盘缓存几百 GB 的媒体切片。
- `--dir-cache-time 24h`：大幅降低因频繁目录遍历（readdir）触发网盘 API 频控的风险。

---

## 三、 排障与验证 Checklist

1. **测试 302 重定向**：
   ```bash
   # 获取 strm 文件内 URL 并发起请求，检查是否返回 302
   curl -I -s "http://<smartstrm_host>:<port>/..." | grep -E "HTTP|Location"
   ```
   应看到 `HTTP/1.1 302 Found` 以及指向网盘真实 CDN 的 `Location: https://...`。
2. **播放器卡顿/无法起播排查**：
   - 检查客户端（如 SenPlayer / Infuse）网络能否直连网盘 CDN 地址；
   - 若 Emby 前置了 Cloudflare Worker 或 Nginx 反代，检查反代是否设置了 `redirect: manual` / `proxy_redirect off`，防止 302 头被反代层拦截或二次重写成错误地址。
