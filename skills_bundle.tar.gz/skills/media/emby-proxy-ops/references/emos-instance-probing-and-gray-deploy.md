# EMOS 实例行为探测、节点去留判定与 Nginx 灰度上线

本文记录一次「优化 EMOS 反代 + 清理疑似废弃 DNS」实战中被**实测推翻的两条文档结论**，以及由此形成的三个通用方法论。核心教训：
**EMOS 类自研中间层的行为因实例而异，任何路径/前缀/接口语义都必须先探测再改，严禁照抄文档（包括本技能的其它章节）。**

---

## 一、致命前提：EMOS 不是原生 Emby

探测身份的第一条指令：

```bash
curl -s https://<反代>/<前缀>/emby/System/Info/Public
# 自研中间层典型返回：
# {"LocalAddresses":[],"RemoteAddresses":[],"ServerName":"emos","Version":"1.0.0","Id":"emya"}
```

看到 `ServerName=emos` / `Id=emya` / `Version=1.0.0` 就要立刻警惕：这是**套了 Emby API 外壳的自研网关**，
不是真 Emby 服务端。它只实现了播放链路需要的接口子集，很多原生 Emby 语义（权限、统计、路由）
与官方文档不一致。所有基于「Emby 官方行为」的推断在这里都不成立。

---

## 二、被推翻的结论 1：`/emya/` 不一定要剥离 `/emby` 前缀

本技能 SKILL.md 曾写「针对 `/emya/video` 注入精准直通逻辑（**严禁**添加 `/emby` 前缀）」。
照此为 Nginx 增加独立 `location /emya/ { proxy_pass https://video.emos.best; }` 后，回归失败。

### 三路差分诊断（判定 404 是「上游真实答案」还是「路由缺失」）

这是本文最有价值的通用手法。单看一个 404 无法区分二者，必须做三路对照：

```bash
UA="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
Q="/emya/video?server=emos&media_id=test"

# A. 上游直连（带专属鉴权头）—— 标准答案
curl -s -o /tmp/a.out -w "A HTTP:%{http_code} size:%{size_download}\n" \
  -H "User-Agent: $UA" -H "EMOS-PROXY-ID: <UID>" -H "EMOS-PROXY-NAME: <NAME>" \
  "https://video.emos.best$Q"

# B. 经生产反代（当前配置真实行为）
curl -s -o /tmp/b.out -w "B HTTP:%{http_code} size:%{size_download}\n" \
  -H "User-Agent: $UA" "http://127.0.0.1:8096$Q"

# C. 故意拼上 /emby 前缀（模拟「错误」行为）
curl -s -o /tmp/c.out -w "C HTTP:%{http_code} size:%{size_download}\n" \
  -H "User-Agent: $UA" -H "EMOS-PROXY-ID: <UID>" -H "EMOS-PROXY-NAME: <NAME>" \
  "https://video.emos.best/emby$Q"
```

### 实测结果与判读

| 路径 | 结果 | 含义 |
| :--- | :--- | :--- |
| A 上游直连 `/emya/video` | `404`，body 空，`server: cloudflare` | **根本没有这条路由**（CF 边缘就地 404，请求没进应用） |
| B 经反代（拼了 `/emby`） | `401 {"message":"Unauthenticated."}` | 到达应用鉴权层，只是缺 token |
| C 手动拼 `/emby/emya/video` | `401 {"message":"Unauthenticated."}` | 与 B 完全一致 |

**判读规则**：
- `401`/`403` 这类**应用层**响应比 `404` 更「深」—— 说明路由命中了、只是没过鉴权。
- B == C 且都比 A 更深 ⇒ 这个实例的 `/emya` **恰恰需要 `/emby` 前缀**，旧配置（落入 `location /` 被拼 `/emby`）的行为才是对的。
- 空 body + `server: cloudflare` 的 404 是 CF 边缘 404，不是应用 404 —— 这个信号能区分「域名/路由不存在」与「资源不存在」。

**结论**：`/emya/` 前缀策略必须按实例实测。看到 404 不要立刻改路由，先跑三路差分。

---

## 三、被推翻的结论 2：`/Items/Counts` 动态透传对 EMOS 不可行

本技能多处写「**严禁**硬编码静态 Counts，应动态透传 `X-Emby-Token` + 10 分钟缓存」。
这条对**原生 Emby** 成立，对 EMOS 自研中间层不成立。

### 探测方法：带无效/有效 token 各打一次，看是否有区分

```bash
for TOK in "faketoken123" ""; do
  curl -s -H "User-Agent: $UA" \
       -H "EMOS-PROXY-ID: <UID>" -H "EMOS-PROXY-NAME: <NAME>" \
       ${TOK:+-H "X-Emby-Token: $TOK"} \
       "https://video.emos.best/emby/Items/Counts"
done
```

实测两种情况**都返回 200 且全 0**：

```json
{"MovieCount":0,"SeriesCount":0,"EpisodeCount":0,"GameCount":0,"ArtistCount":0,
 "ProgramCount":0,"GameSystemCount":0,"TrailerCount":0,"SongCount":0,"AlbumCount":0,
 "MusicVideoCount":0,"BoxSetCount":0,"BookCount":0,"ItemCount":0}
```

带 token 与不带 token 无差异 ⇒ 上游**根本没实现真实统计**，不是「匿名降级返 0」。
动态透传只会让播放器卡片永远显示 0。

**结论**：对这类实例，静态注入是唯一可行方案。判据是「带 token 与不带 token 的返回是否有差异」——
有差异才值得做动态透传 + 缓存；无差异必须静态兜底。

---

## 四、节点/DNS 去留判定：查清真实承载再动手（防误删）

一条 DNS 记录「看起来像废弃的」不等于它是废弃的。本次 `la.586934.xyz → 198.44.46.38`
不在 Workers Routes 里、直接访问返回 400/404，看着像孤儿记录，实际是**整条 EMOS 链路的承载节点**。

### 判定 SOP（按序执行，任一步确认在用就停手）

1. **读面板真实路由表**（拿到上游 target，而不是猜）：
   ```bash
   curl -s -H "User-Agent: $UA" -H "Cookie: admin_token=<ADMIN_TOKEN>" \
        "https://<面板域名>/api/routes"
   # 关注每个节点的 target / todayReqs / totalReqs / todayBandwidth / last_play
   ```
   本次输出显示 `prefix=emos` 的 `target` 是 `http://vps.zmz110.ccwu.cc:8096`，
   `todayReqs=30`、`todayBandwidth=4.30 GB`、`last_play` 是当天 —— 明显在用。

2. **解析 target 主机名，与「疑似废弃」记录比对 IP**：
   ```bash
   dig +short @1.1.1.1 vps.zmz110.ccwu.cc A     # -> 198.44.46.38
   dig +short @1.1.1.1 la.586934.xyz A          # -> CF 代理 IP（橙云）
   ```
   **关键陷阱**：同一台机器常挂多个域名（一个走 CF 代理给播放器、一个裸解析给面板回源），
   甚至分属不同 zone。只看单个域名会得出「没人用」的错误结论 —— 必须比对**落地 IP**。

3. **登机器看活流量**（最终裁决）：
   ```bash
   docker ps --format 'table {{.Names}}\t{{.Image}}\t{{.Ports}}\t{{.Status}}'
   docker logs <反代容器> --since 72h 2>&1 | grep -oE '^([0-9]{1,3}\.){3}[0-9]{1,3}' \
     | sort | uniq -c | sort -rn | head -20
   docker logs <反代容器> --since 72h 2>&1 | grep -cE '^[0-9]+\.'
   ```
   本次 72h 内 4708 次请求，来源全是 Cloudflare 回源段（`104.2x.x.x`/`172.7x.x.x`/`162.159.x.x`）
   ⇒ 确认是活的主力链路，**严禁删除**。

4. 端口扫描只能作为辅助信号，不能作为判据：`443/2053` 上跑的可能是 xray 而非 Emby，
   `curl` 拿到 400/404 只说明那个端口上的服务不认这个路径，不代表机器闲置。

---

## 五、Nginx 正则 location 的 `proxy_pass` 限制与正确改写

`location ~*` / 命名 location / `if` 块内的 `proxy_pass` **不得携带 URI 路径**，否则：

```
[emerg] "proxy_pass" cannot have URI part in location given by regular expression,
        or inside named location, or inside "if" statement, or inside "limit_except" block
```

这会让容器 nginx 直接起不来（对外表现为 CF 521）。三种正确改写：

```nginx
# 写法 1（推荐）：拆成两个精确 location，覆盖带/不带前缀两种客户端行为
location = /emby/Items/Counts { proxy_pass https://video.emos.best/emby/Items/Counts; }
location = /Items/Counts      { proxy_pass https://video.emos.best/emby/Items/Counts; }

# 写法 2：正则块内只保留协议+域名，路径靠原始 URI 透传
location ~* ^/emby/Items/[^/]+/Images/ {
    proxy_pass https://video.emos.best;      # 无 URI 部分
}

# 写法 3：正则块内需要改路径时，用 rewrite ... break 补前缀
location ~* ^/Items/[^/]+/Images/ {
    rewrite ^(/.*)$ /emby$1 break;
    proxy_pass https://video.emos.best;
}
```

配套的其它实测有效改进（对 EMOS 反代容器）：

```nginx
# WebSocket 正确升级：原配置直接透传 $http_connection，部分客户端会断连
map $http_upgrade $connection_upgrade { default upgrade; '' close; }
proxy_set_header Connection $connection_upgrade;

# 流媒体长拉流：120s 会中途断流
proxy_send_timeout 3600s;
proxy_read_timeout 3600s;

# worker_connections 不要超过容器 ulimit（默认 1024），否则每次启动都刷 warn
worker_connections 1024;
```

---

## 六、容器内 Nginx 灰度上线 + 自动回滚

直接 `cp` 覆盖配置再 reload 是危险操作（配置错 = 播放全断）。标准闭环见
`scripts/nginx-gray-deploy.sh`，要点：

1. **改前先备份**：`cp nginx.conf nginx.conf.bak-$(date +%Y%m%d-%H%M%S)`，脚本自动取最新备份为回滚点。
2. **一次性容器预检**（完全不碰生产）：
   ```bash
   docker run --rm -v /tmp/nginx.new.conf:/etc/nginx/nginx.conf:ro nginx:alpine nginx -t
   ```
3. **⚠️ 关键陷阱**：`nginx -t` 把结果写 **stderr**。写成
   `docker exec c nginx -t 2>/dev/null | grep -q successful` 会**永远失配**，
   导致明明语法正确却触发「校验失败→回滚」的假故障（本次实际踩到，白跑一轮）。
   必须用 `2>&1`：
   ```bash
   if ! docker exec c nginx -t 2>&1 | grep -q successful; then ...回滚...; fi
   ```
4. **上线前先跑一遍基线**，上线后跑同一组断言对比，任一项失败自动 `cp` 回滚 + reload。
5. 缓存生效验证：连打两次同一图片 URL，第二次响应头应出现 `X-Cache-Status: HIT`。

实测该闭环成功在失败时自动回滚，生产未受影响（探活全程 200）。

---

## 七、CF API Token 权限矩阵探测

一个账号下并存多个 Token 时，权限常常互补且「装反」。逐个 Token × 逐个只读端点打一遍，
再下结论，别用单个 Token 的 403 判定「账号没权限」：

| 只读探针端点 | 对应权限域 |
| :--- | :--- |
| `/accounts/{a}/workers/scripts` | Workers Scripts:Read |
| `/zones/{z}/workers/routes` | Workers Routes:Read |
| `/zones/{z}/dns_records?per_page=1` | Zone.DNS:Read |
| `/zones/{z}` | Zone:Read |
| `/zones/{z}/analytics/dashboard` (或 GraphQL) | Zone.Analytics:Read (播报流量统计依赖) |
| `/accounts/{a}` | Account Settings:Read |
| `/user` | User Details:Read |

本次实测：主 Token 有 Workers 全部权限但**无 DNS**；Worker bindings 内嵌的 `CF_API_TOKEN`
**只有 DNS** 而无 Workers —— 恰好装反。

**衍生发现**：因内嵌 Token 无 Workers 权限，面板「更新代码」按钮其实一直是坏的
（`/api/deploy` 依赖 `GET /workers/services/{name}` 与 `/bindings`，实测双双 403）。
排障时若发现某面板功能「从来没人用过」，值得主动验证它依赖的 API 权限是否具备。

修复需用户在 CF 后台手动重签（API 无法自签 Token）。给用户的指引必须具体到勾选项：
`Account → Workers Scripts:Edit` + `Zone → DNS:Edit` + `Zone → Analytics:Read`（每日播报流量统计依赖）+ `Zone → Zone:Read`，
Zone Resources 限定到具体域名。
