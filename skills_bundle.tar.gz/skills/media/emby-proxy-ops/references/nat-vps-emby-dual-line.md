# NAT 小鸡与多节点 Emby/EMOS 双轨独立反代实战指南

## 1. 核心应用场景与双轨独立原则
- **场景**：用户拥有已稳定运行的主力 Emby 反代节点（如美国 VPS / Cloudflare Worker 多节点面板），新购入亚太/香港 NAT 小鸡希望搭建独立的新加速线路，同时绝不修改、覆盖或撤销原有主力节点。
- **客户端体验**：在播放器（SenPlayer / VidHub / Fileball / Emby 官方端）中添加多台独立服务器，实现网络分流与多线路容灾切换。

---

## 2. 线路类型与延迟对比（直连灰云 vs 橙云代理）

| 模式 | 流量链路 | 国内延迟 | 优劣势与适用场景 |
| :--- | :--- | :--- | :--- |
| **方案 A：CF 灰云直连（DNS Only）** | 客户端 ➡️ 香港小鸡 ➡️ EMOS 源站 | **20ms ~ 40ms** | **推荐**。直连享受香港原生低延迟与千兆吞吐，起播秒开；客户端填二级域名隐藏裸 IP。 |
| **方案 B：CF 橙云代理（Proxied）** | 客户端 ➡️ CF Anycast 边缘 ➡️ 香港小鸡 ➡️ EMOS 源站 | **150ms ~ 300ms** | 100% 隐藏小鸡真实 IP，但受 Cloudflare 跨国链路与晚高峰 Anycast 丢包影响，需监听 CF 支持的 HTTPS 端口（如 2053/8443）。 |
| **方案 C：CF Worker 内部节点** | 客户端 ➡️ CF Worker (D1) ➡️ EMOS 源站 | 视优选 IP 决定 | 零 VPS 流量消耗，作为基础保底线路。 |

---

## 3. Alpine Linux NAT 小鸡极简 Nginx 部署模板

适用于 512MB~1GB 内存、OpenRC 系统架构的极轻量容器/LXC 小鸡。

### Nginx 配置 (`/etc/nginx/http.d/emos.conf`):

```nginx
# 50MB 内存轻量图片缓存区 (防止低配小鸡 OOM 与磁盘耗尽)
proxy_cache_path /var/cache/nginx/emos_cache levels=1:2 keys_zone=emos_cache:5m max_size=50m inactive=1d use_temp_path=off;

server {
    listen 8088 default_server;
    listen [::]:8088 default_server;
    listen 8096;
    listen [::]:8096;
    listen 18096;
    listen [::]:18096;

    server_name _;

    client_max_body_size 100M;
    proxy_connect_timeout 15s;
    proxy_send_timeout 3600s;
    proxy_read_timeout 3600s;

    # 1. 拦截媒体库数量，点亮播放器卡片 (同时兼容 /Items/Counts 与 /emby/Items/Counts)
    location ~* ^/(emby/)?Items/Counts$ {
        default_type application/json;
        add_header Content-Type "application/json; charset=utf-8";
        add_header Access-Control-Allow-Origin *;
        add_header Access-Control-Allow-Methods "GET, POST, OPTIONS";
        add_header Access-Control-Allow-Headers "*";
        return 200 '{"MovieCount":18450,"SeriesCount":4120,"EpisodeCount":118600,"SongCount":56800,"AlbumCount":3200,"MusicVideoCount":150,"BoxSetCount":680,"BookCount":0,"ItemCount":141170}';
    }

    # 2. 封面与剧照本地轻量缓存 (毫秒级瀑布流加载)
    location ~* ^/(emby/)?Items/.*/Images/.* {
        proxy_cache emos_cache;
        proxy_cache_valid 200 1d;
        proxy_cache_valid 404 1m;
        proxy_cache_use_stale error timeout updating http_500 http_502 http_503 http_504;
        add_header X-Cache-Status $upstream_cache_status;

        proxy_pass https://video.emos.best;
        proxy_ssl_server_name on;
        proxy_http_version 1.1;
        proxy_redirect off;

        proxy_set_header Host video.emos.best;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_set_header EMOS-PROXY-ID "eK981JREMs";
        proxy_set_header EMOS-PROXY-NAME "naye";
    }

    # 3. 核心 API 与 206 视频流极速直通
    location / {
        proxy_pass https://video.emos.best;
        proxy_ssl_server_name on;
        proxy_http_version 1.1;
        proxy_redirect off;

        # WebSocket 实时通信支持
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection $connection_upgrade;

        proxy_set_header Host video.emos.best;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;

        # 专属身份鉴权头
        proxy_set_header EMOS-PROXY-ID "eK981JREMs";
        proxy_set_header EMOS-PROXY-NAME "naye";

        # 206 Range 分片透传 (随下随播、拖拽不卡)
        proxy_set_header Range $http_range;
        proxy_set_header If-Range $http_if_range;

        # 禁用缓冲
        proxy_buffering off;
        proxy_request_buffering off;
    }
}
```

---

## 4. 关键排障与踩坑索引

1. **NAT 外部映射端口与内网监听端口不一致**：
   - NAT 服务商通常将外部高位端口（如 `34474`）映射到小鸡内网的指定端口（如 `8088` 或内部同名端口）。
   - 在 Nginx 中同时配置 `listen 8088 default_server;` 和 `listen 8096;` 等多个常用端口，避免端口不匹配导致公网连接拒绝。
2. **Nginx 重复 listen 指令报错**：
   - 同一个 server 块中若已指定 `listen 8088 default_server;`，严禁再写一次 `listen 8088 ssl;`，否则会触发 `[emerg] a duplicate listen 0.0.0.0:8088` 崩溃。HTTP 与 HTTPS 应拆分为独立 server 块监听不同端口。
3. **Cloudflare 灰云解析保护**：
   - 建立专属二级域名（如 `hk.586934.xyz -> NAT IP`），关闭小黄云代理（仅 DNS 解析），即可通过 `http://hk.586934.xyz:34474` 直连，避免向使用者直接暴露裸 IP。
