# Cloudflare Worker Upload API: keep bindings, snapshots, and rollback

## Scope and trigger

Use for any Cloudflare Workers Script Upload API (`PUT /accounts/{account_id}/workers/scripts/{script_name}`) workflow that prepares a code-only patch, upgrade, or rollback while preserving existing bindings and runtime configuration. This is deployment engineering; it is separate from authorizing the production write.

## Required sequence

1. **Verify the exact API in current official documentation.** The Cloudflare API reference defines `metadata.keep_bindings` as a list of binding types to keep from `previous_upload`; the multipart metadata page is dated July 3, 2026. This is server-side inheritance, not a serialized secret export. Do not rely on stale assumptions that every secret must be re-uploaded as cleartext. Record the exact official docs URL and retrieval date in the handoff. Confirm in the source that `keep_bindings` is a top-level metadata field, distinct from `bindings`; offline request assembly must therefore omit `metadata.bindings` entirely when retaining existing values.
2. **Inspect actual binding types from a fresh read.** Build `keep_bindings` from the current Worker binding types and ensure every existing type is covered. Fail closed on an unfamiliar type; do not silently drop it. Include at least secret types and resource bindings such as D1 when they exist. Do not include `bindings` with API-redacted values in metadata.
3. **Take a fresh private snapshot before each future deployment.** Capture the exact current Worker module (including original multipart response), bindings API response (names/types; secret_text has no plaintext), Worker settings, and schedules. Store under a unique directory with restrictive directory/file permissions. Hash each artifact and write a manifest. Verify every snapshot component is present and parseable before proceeding.
4. **Preflight against the exact target.** Re-fetch the live Worker and configuration immediately before any future upload. Require the live module hash, binding fingerprints, relevant settings, and schedules to match the fresh snapshot. If anything changed, stop and re-snapshot/re-review. Never use a prior session snapshot as proof of the current production baseline.
5. **Pin the code artifact.** Validate both baseline and candidate SHA-256 before assembling the request. Upload the already reviewed candidate bytes directly; do not invoke a generic lifecycle deployment path that rebuilds or transforms source.
6. **Assemble multipart locally.** Include `main_module`, reviewed module bytes, `keep_bindings`, and relevant top-level settings from the fresh snapshot (compatibility date/flags, placement, usage model, log settings, tags, tail consumers, and limits/observability when applicable). Do not set diagnostic environment variables unless specifically approved; default them off. Parse the resulting multipart back locally and verify exact code bytes, metadata, and absence of a `bindings` array with masked values. This dry run must make zero network writes.
7. **Handle schedules separately.** Cron schedules are managed by a distinct schedules API. Snapshot them independently, and after a future upload reapply the snapshot schedule list through the schedule endpoint, then read it back and compare. Do not assume script upload preserves Cron settings.
8. **Post-write verification is mandatory when separately authorized.** Read back module hash, binding names/types and resource IDs where exposed, settings, and schedules. Never claim success from PUT response alone. If any facet differs, stop and run only the explicit, separately authorized rollback flow.

## Validated implementation pattern

A working offline preparation implementation from a real Worker patch review used a single Python stdlib tool with four isolated operations: `snapshot`, `dry-run`, `verify`, and explicit-confirmation `upload`. It assembled multipart parts (`metadata` JSON plus the exact module bytes), then parsed the generated multipart body back and asserted byte-identical module content, expected `keep_bindings`, presence of runtime settings, and absence of an explicit `bindings` array. Candidate and rollback dry runs completed with zero network calls. Cron is a separate GET/PUT/GET readback step. This pattern was useful for deployment preparation without executing production writes.

Implementation cautions learned during validation:

- Python `urllib.request.Request` must receive `Content-Type: multipart/form-data; boundary=...` even when the body is already bytes; setting the header only in the JSON-body branch produces an invalid/mislabelled multipart request.
- When parsing Cloudflare's downloaded GET multipart response, the MIME part's `name` was `worker.js` (not a filename); select by the part name and verify its hash against the separately extracted source.
- Future fresh snapshots must not be hardwired to the rehearsal snapshot's file hashes or timestamp. Reuse the snapshot routine, and treat the old snapshot only as an offline fixture.
- Snapshot API `secret_text` readback has no secret text. Trust `keep_bindings` only after official documentation and type coverage review; check for unknown types and fail closed.
- Settings and Cron restore are separate concerns: include applicable settings in upload metadata, then PUT schedules and read them back. Clearly document the partial-write failure window: if script upload succeeds but schedules restoration fails, the command must stop and direct the operator to the snapshot rollback path.
- If account/worker identifiers are only available as plain-text values in a protected prior snapshot, never print them in reports. Use them internally or accept them as local environment inputs; do not invent credential-manager commands that have not been verified.



Rollback uses the source and configuration from the deployment's immediately preceding fresh snapshot, not a historical backup. The rollback upload must itself use the applicable `keep_bindings` set from the current/previous upload so secret bindings remain inherited rather than being reconstructed from redacted API output. Restore snapshot settings in upload metadata and Cron schedules via their separate API. Verify all readbacks, including the prior module hash, before declaring rollback complete. A rollback script must refuse unknown current code/config states rather than overwriting unrelated intervening changes.

## Safety and reporting

- Separate preparation/dry-run commands from write commands. A preparation request does not grant deployment permission.
- Require explicit confirmation gates for any live upload; never execute them when the user said “prepare, do not deploy.”
- Never print tokens, plaintext secrets, raw request bodies, or snapshot payloads. Sanitize errors and reports.
- Report UTC retrieval/sample times, exact code hashes, what was read, which official docs were verified, and whether any network write occurred.
- Keep the artifact-specific candidate hash and snapshot path in the handoff rather than baking them into this reusable class-level reference.

## Official references

- Multipart upload metadata: https://developers.cloudflare.com/workers/configuration/multipart-upload-metadata/
- Upload Worker Module API: https://developers.cloudflare.com/api/resources/workers/subresources/scripts/methods/update/
- Cron schedules GET/PUT are separate endpoints under `/accounts/{account_id}/workers/scripts/{script_name}/schedules`.
