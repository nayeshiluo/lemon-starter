# 低配/廉价 VPS（2C/2G/小硬盘）自建 Emby 专属小服可行性审计与避坑规范

用于评估在资源受限（如 2 核 CPU、2GB 物理内存、15GB~30GB 剩余硬盘、海外普通线路）的轻量 VPS 上搭建个人/亲友 Emby 专属小服的可行性与核心落地防爆准则。

---

## 一、 可行性评估决策树（四项硬核指标）

| 审计维度 | 临界红线 | 风险与后果 | 达标与破局方案 |
| :--- | :--- | :--- | :--- |
| **内存 (RAM)** | 物理内存 < 1.5GB（无 Swap） | Emby 基于 .NET 运行时，启动常驻 500MB~800MB，库扫描高峰达 1.2GB~1.5GB。内存耗尽触发 Linux OOM Killer，直接击杀 Emby 或同机关键守护进程（qB、代理等） | 物理内存 ≥ 2GB，且**必须配置 2GB~5GB Swap** 充当缓冲垫。禁止在 <1.5GB 且无 Swap 的纯小鸡上跑服务端。 |
| **可用磁盘** | 根目录剩余空间 < 10GB | 即使视频文件存网盘，Emby 的海报、演职员信息、NFO 与数据库索引（`data/` 目录）也会随剧集增长。若默认开启截图，几百部片子即撑爆根分区导致系统只读死锁 | 剩余空间建议 ≥ 15GB。**必须且立即物理关闭 BIF / 章节缩略图提取**（详见下文设置）。 |
| **出网月流量** | 出网流量 < 500GB/月（如 AWS 100GB） | 1080p 视频每小时消耗 1.5GB~4GB，4K 原盘每小时消耗 15GB~40GB。串流中转几天内耗尽免费额度，导致天价账单 | 出网流量需 ≥ 3TB/月（如廉价美机 5TB 配额）；或**必须采用 302 重定向架构**（客户端直连 GDrive/网盘 CDN，服务器 0 流量消耗）。 |
| **算力与转码** | 共享 vCPU、无核显/独显 (No GPU) | CPU 软解压制 1080p 高码率视频瞬间打满 100% CPU，机房触发风控停机，同机服务全部卡死 | **彻底关闭服务端转码**，强制 Direct Play（原画直解）。要求客户端使用具备本地硬件强解能力的播放器（SenPlayer / Infuse / VidHub）。 |

---

## 二、 关键配置：防爆磁盘与防爆 CPU 四大铁律

### 1. 物理斩断 BIF / 缩略图（防爆 15GB 磁盘）
在 Emby 管理员控制台 ➔ **媒体库 (Library)** ➔ 每一个库的高级设置：
- ❌ **提取视频缩略图 (Extract video images)**：设为 **【从不 / Never】**。
- ❌ **章节图像提取 (Chapter images)**：设为 **【从不 / Never】**。
- ❌ **保存插图到媒体文件夹**：取消勾选（避免向云盘回写产生 IO 错误）。
- ❌ **标记检测 (Marker Detection)**：设为 **【从不 / Never】**。
- 💡 *效果*：仅保留文字元数据和单张主海报，每部影视仅占几百 KB 空间，15GB 硬盘足以收录 5,000+ 部影视剧。

### 2. 用户权限剥离转码（防爆 CPU 2 核算力）
在 Emby 管理员控制台 ➔ **用户 (Users)** ➔ 点击对应账号（含管理员自身与好友）➔ **播放 (Playback)**：
- ❌ 取消勾选 **「允许需要转码的视频播放」**。
- ❌ 取消勾选 **「允许需要转换的视频播放」**。
- ❌ 取消勾选 **「允许媒体转换」**。
- ✅ 仅勾选 **「允许直接播放 (Direct Play)」** 与 **「允许直接串流 (Direct Stream)」**。
- 💡 *播放端要求*：统一使用原生硬解播放器（iOS/Mac/AppleTV: **SenPlayer**、**Infuse**、**VidHub**；PC: **恒星播放器**、**PotPlayer**），依靠终端本地 SOC 芯片解码。

### 3. Google Drive (GDrive) 配合 Rclone 挂载调优（防小内存与小磁盘崩溃）
在小内存小硬盘机器上挂载 GDrive，严禁使用全量缓存（`--vfs-cache-mode full` 会瞬间把 15GB 硬盘当作下载缓存塞满）：
```bash
# 推荐轻量挂载参数（内存占用极低，零额外磁盘占用）
rclone mount gdrive:/Media /mnt/gdrive \
  --allow-other \
  --read-only \
  --vfs-cache-mode off \
  --dir-cache-time 72h \
  --attr-timeout 72h \
  --buffer-size 16M \
  --vfs-read-ahead 32M \
  --drive-chunk-size 16M \
  --no-modtime \
  --log-level NOTICE \
  --log-file /var/log/rclone-mount.log &
```
- `--vfs-cache-mode off`：不占本地硬盘空间，视频流随取随放。
- `--buffer-size 16M`：单流预读缓存限制为 16MB，防多个并发流吃尽 2GB 物理内存。
- `--dir-cache-time 72h`：目录树缓存 72 小时，防止频繁刮削触发 Google API 10 QPS 频控或 403 封禁。

---

## 三、 跨洋网络晚高峰体验优化

美西便宜小鸡（如 RackNerd 洛杉矶）晚高峰直连国内三大运营商（尤其是电信和移动）通常存在丢包和抖动：
1. **客户端走节点（最推荐、零成本）**：
   - 播放器（如 SenPlayer）中配置走现有的优质香港/新加坡代理节点，或软路由代理规则放行 Emby 域名。
   - 客户端经由亚太低延迟链路拉取 VPS 视频流，延迟从 220ms 降至 30ms，起播秒开、拖拽无感。
2. **配合前置 Cloudflare Worker / 302 分流**：
   - 若配置了 Emby 302 插件，播放时服务端将视频地址重定向至 Google 官方 CDN 直链，客户端直连 Google 节点播放，不走 VPS 带宽。

---

## 四、 内容定位版本答案：为什么「动漫追番 + 点播剧」最适合小服？

在 2C/2G 算力受限、本地磁盘仅剩 15G 左右、挂载 5TB 云盘（如 GDrive）的场景下，**严禁收录 4K 蓝光原盘/单片 40G 电影**（易触发转码、极吃带宽、几部就占满空间）。**「新番动漫连载 + 热门点播剧集」是最佳黄金组合**：

### 1. 为什么是最佳组合？
- **天然免转码（Direct Play 成功率 99.9%）**：
  - 动漫（Baha/巴哈、Web-DL 1080p）与国产/美剧网剧几乎全为标准 H.264/HEVC + AAC，编码标准化极高。
  - 手机/平板/Apple TV（SenPlayer / Infuse）本地硬件硬解无压力，服务端 CPU 占用近乎为 0。
- **5TB 空间容量收益最大化**：
  - **新番动漫**：单集 24 分钟约 400MB~800MB。5TB 可容纳 **8,000 ~ 10,000 集**（相当于 700+ 部整季新番）。
  - **点播电视剧**：单集 45 分钟约 1GB~1.5GB。5TB 可容纳 **3,500 ~ 4,500 集**。
- **保护 15GB 本地硬盘不被撑爆**：
  - 电视剧和番剧按季/集组织，海报复用率极高（一季复用一张海报与背景），配合关闭 BIF 缩略图，一万集番剧的元数据在本地仅占 **1GB~2GB** 缓存。

### 2. 自动化入库与追更双引擎流水线
- **动漫追番引擎（自动连载）**：
  - 监听动漫频道（如 `@dmhyshare`）或配置 Mikan（蜜柑计划）/ 动漫花园 RSS 订阅；
  - 触发新番自动下发 qB 离线拉取；
  - 经 `smart_media_parser` + `tmdb_helper` 强行清洗为 TMDB 规范格式（如 `Anime/鬼灭之刃 (2019) [tmdbid=85937]/Season 04/鬼灭之刃 - S04E01.mkv`）；
  - 同步推送到 GDrive 5T 对应目录，自动触发 Emby 局部库扫描。
- **点播剧引擎（按需入库）**：
  - 借助众包系统（`lemon-2f`）或运维 Bot 的 `/find` 点播接口；
  - 用户发起点播 ➔ 检索磁力/网盘 ➔ 离线下载与 FFprobe 质检 ➔ 强制规范命名 ➔ 传 GDrive ➔ Emby 上架通知。

---

## 五、 端到端开服四阶段标准落地 SOP（用户纠偏：开服 ≠ 个人客户端连接）

> ⚠️ **核心准则**：用户提出“开服”时，绝不能只给个人播放器（如 SenPlayer）填地址扫码的简单指引，而必须提供并执行涵盖「域名网络 -> 存储服务 -> 自动化片源 -> 用户开号与权限运维」的完整工业级服主交付全流程。

### 阶段一：域名通道与安全反代（门面与 IP 隐匿）
1. **子域名解析**：分配专属子域名（如 `emby.domain.com`），在 Cloudflare 开启 CDN 代理（橙色小云朵），100% 隐匿 VPS 真实公网 IP。
2. **反代与 SSL**：
   - 使用 Nginx / Caddy 申请 SSL 证书并强制 HTTPS（443 或 CF 允许的 HTTPS 端口如 2053/8443）。
   - 必须配置 WebSocket 支持（`Upgrade $http_upgrade`、`Connection $connection_upgrade`），防止客户端播放状态与进度断联。

### 阶段二：底层存储挂载与 Docker 服务部署（地基）
1. **端口冲突排查与避让**：
   - 部署前必查 `ss -tulnp | grep :8096`。若 8096 已被既有反代（如 `lemon-emos-proxy`）占用，Emby 容器必须映射到独立端口（如 `8097:8096`），再由 Nginx 反代转发。
2. **FUSE 挂载驱动与权限自检（Rclone 必备）**：
   - 检查内核字符设备：`ls -la /dev/fuse`（必须为 `crw-rw-rw-` 权限），若权限不足或文件缺失会导致 rclone mount 报 `fusermount: failed to open /dev/fuse: Permission denied`。
   - 检查挂载工具：`which fusermount fusermount3`，若缺失则执行 `apt-get install -y fuse3`。
3. **Google OAuth 客户端真实性穿透预检（发给用户前必测）**：
   - 在引导用户授权前，必须用代码发起探活请求：`requests.get(auth_url, allow_redirects=False)`，确认返回 `HTTP 302` 重定向至 Google 官方登录流，断言排除 `disabled_client`、`deleted_client` 与 `redirect_uri_mismatch` 错误。
4. **Docker Compose 规范**：
   - 缺失 `docker-compose` 时，安装官方二进制到 `/usr/local/bin/docker-compose` 并软链到 `/usr/local/lib/docker/cli-plugins/docker-compose`。
3. **轻量 Compose 编排模板**：
   ```yaml
   services:
     emby:
       image: emby/embyserver:latest
       container_name: emby-server
       environment:
         - PUID=0
         - PGID=0
         - TZ=Asia/Shanghai
       volumes:
         - /root/emby-server/config:/config
         - /mnt/gdrive/Anime:/media/anime:ro
         - /mnt/gdrive/TV:/media/tv:ro
       ports:
         - "8097:8096"
       restart: unless-stopped
   ```
4. **服务级防爆铁律（启动后首要执行）**：
   - 后台关闭用户视频转码（Direct Play 原画直推）。
   - 媒体库高级设置彻底禁用章节缩略图/BIF 提取。

### 阶段三：自动化追番与点播入库流水线（片源生命线）
1. **动漫追番**：Mikan RSS / 动漫花园 ➔ qBittorrent 异步下载 ➔ TMDB 规范重命名洗名 ➔ 推送 GDrive 5T ➔ 调用 Emby API 局部刷新。
2. **点播剧集**：Telegram Bot `/find` 或众包 Web 面板点播 ➔ 磁力离线 ➔ 规范归档 ➔ 入库。

### 阶段四：服主后台与用户开号运维（对外交付）
1. **权限模板规范**：
   - 管理员账号仅限服主掌控。
   - 普通用户权限：仅开放对应媒体库；**必须取消勾选“允许转码”**与**“允许删除媒体”**；**限制并发播放设备数（1~2 台）**防止一人开号全家挤爆网络。
2. **开号渠道**：
   - 手动模式：Emby 控制台 `用户 ➔ 添加用户`。
   - 自动模式：通过 Telegram Bot 生成激活码或自动发号绑定。
3. **开服交付卡片**：
   - 提供给用户的标准交付格式：服务器名称、HTTPS 域名地址、端口、推荐客户端清单（iOS/Mac/ATV: SenPlayer/Infuse/VidHub，安卓: SenPlayer/官方端，PC: 浏览器/网页端/恒星播放器）。

