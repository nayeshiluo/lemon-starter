# 多节点上传集群规划与第三方众包上传站接入

适用场景：需要把 EMOS / Cloudreve 系等「众包上传赚积分」平台的视频上传递交，分散到多台机器（大带宽 VPS + 免费云沙箱 + 控制面机器）执行时的选型、分流与探测方法。

## 一、先测三个数，再谈分工

不要凭机器规格猜谁能扛上传。**上行带宽、磁盘余量、可用窗口**这三个数决定分工，测法如下（只读、无需真实上传到目标站）：

```bash
# 下行
curl -s -o /dev/null -w "down %{speed_download} B/s\n" --max-time 40 \
  "https://speed.cloudflare.com/__down?bytes=<YOUR_USER_IDENTIFIER>"

# 上行（单连接）
head -c <YOUR_USER_IDENTIFIER> /dev/zero > /tmp/u.bin
curl -s -o /dev/null -w "up %{speed_upload} B/s\n" --max-time 60 \
  -X POST --data-binary @/tmp/u.bin https://speed.cloudflare.com/__up

# 上行（4 并发，用来区分「单连接限速」和「总带宽限速」）
for i in 1 2 3 4; do curl -s -o /dev/null -w "t$i %{speed_upload}\n" --max-time 60 \
  -X POST --data-binary @/tmp/u.bin https://speed.cloudflare.com/__up & done; wait
```

判读：
- 4 并发合计 ≈ 单连接 × 4 → 单连接限速，多线程分片能提速，适合大文件。
- 4 并发合计 ≈ 单连接 × 1.5 → 总带宽限速，加线程无意义，只能靠机器数量堆。

2026-10 实测参考（同一时段、同一测速端点）：

| 节点 | 上行 | 磁盘可用 | 结论 |
|---|---|---|---|
| RackNerd 类美西 VPS（2G/34G） | 31.9 MB/s | 9.3G | 上传主力 |
| InstaBox 免费沙箱（4C/8G/20G） | 单连 5.9，4 并发合计 9.5 MB/s | 18G | 总带宽限速，只适合小文件批量与预处理 |
| AWS 小实例（1.9G/24G，100GB 月出网） | — | 5.2G | **绝不承载上传数据面** |

## 二、分流规则模板

| 条件 | 执行节点 |
|---|---|
| 单文件 ≥ 1.5GB（电影/4K/原盘） | 大带宽 VPS |
| 单文件 < 1.5GB（短剧/单集/动漫） | 沙箱机 |
| 批量小文件（≥20 个） | 沙箱机 |
| 预计耗时 > 5 小时 | 强制大带宽 VPS（避开沙箱窗口） |
| 需 ffprobe 质检/改名/切广告 | 沙箱机先做，再按大小分流 |

**去重铁律**：EMOS 对同资源一周内重复上传返回业务错误（上传器抛 `DuplicateUploadError`），两个节点抢同一资源是纯浪费。队列必须按资源指纹去重，不是按平台。

## 三、源文件来源是隐藏成本

沙箱机要传的文件从哪来，比带宽更影响成本：

1. **推荐**：沙箱只处理它自己采集/转码产出的文件 → 零额外流量。
2. 沙箱挂 qB，同一种子双端各自下载 → 零搬运，但 PT 站点计双份下载量。
3. 从 VPS rsync 拉 → 消耗 VPS 出网流量，且 VPS 磁盘通常很紧，大文件拉不动。避免。

## 四、免费云沙箱的硬限制必须写进设计

InstaBox 免费档：闲置 30 分钟自动暂停、单次运行 **8 小时**上限、到点冷却约 10 分钟，8 小时坎只有付费档能绕。

推论（强制）：
- 单任务预计 > 5 小时一律不给沙箱。
- 沙箱上的上传必须支持**断点续传**：分片进度落盘，进程重启后从最后一个完成分片继续。
- 任务状态必须落在控制面（队列表），不能只存在沙箱内存里 —— 沙箱一暂停，内存状态全丢。

现有 `emos_uploader.py` 是串行分片、无 resume，派给沙箱前必须先补 `--resume`。

### 4.1 先核对线上副本，别信"技能里已修"（实测教训）

- 参考 `emos-uploader-identify-fix.md` §3 记载的「8 线程并发直传 R2」修复，**不等于线上机器已生效**。
- 实测：VPS-LA 上 `/root/emos_uploader.py`（2026-09-28）仍是**单线程串行**——`with open(...) as f:` 循环内 `f.read(part_size)` → 单分片 PUT → 下一片，无 `ThreadPoolExecutor`。
- **规程：优化吞吐前先 `grep -n "ThreadPoolExecutor\|max_workers" <线上上传器路径>`**，没命中就是串行，别按技能描述假设已并发。

### 4.2 串行实现只吃掉约 10% 带宽（瓶颈在并发，不在机器数量）

| 口径 | 实测（2026-10-23 21:00–21:35 CST） |
|---|---|
| VPS-LA 上行 | 31.9 MB/s |
| VPS-LA 串行上传器实际吞吐（303.4MB / 31 片，跑到 90s 被 kill 的中途快照） | ≈ 3.0 MB/s |
| VPS-LA 串行上传器**干净跑完**（同文件，完整 abort 流程） | **8.01 MB/s** |
| VPS-LA 并发 5 线程（同文件） | **29.96 MB/s（3.74x，已跑满链路）** |

⚠️ **引用时用 8.01 而不是 3.0**：3.0 含进程启动/识别/presign 的固定开销，拿它算收益会得出
「10x」的错觉，真实并发收益是 3.74x。实现与验证细节见 `references/emos-uploader-parallel-partition.md`。

推论：同一份串行代码在单连 5.9 MB/s 的沙箱上反而比在 31.9 MB/s 的 VPS 上跑得快。**先并发化，再谈加机器**；加节点、加磁盘都解决不了这个瓶颈。

⚠️ **不要用"传一半就 kill"的方式探活**：中断的上传平台侧已记录，随后完整重跑立刻被判 `一周内上传过`（`DuplicateUploadError`，退出码 3），白白烧掉该资源一周的额度。探活要么用真实待传且本周未传过的文件，要么只做到 `getUploadToken` 之前就停。
**测吞吐的正确姿势是「跑完再 abort」**：presign → 并发 PUT 全部分片 → **不调 `/complete`** → `DELETE /api/upload/multipart/{file_id}/abort`。能拿到真实 R2 吞吐且平台侧不留已入库记录、不占一周额度。见 `references/emos-uploader-parallel-partition.md` §4.2。

⚠️ `/api/user/info` 不是有效令牌校验口（返回 `emos api 404 :(`），不能据此判令牌失效；用 `/api/identify` 或直接跑上传器。

⚠️ `/api/identify` 单独调用可能返回 `Guessit 解析服务异常 (HTTP 404)`，这是平台侧 guessit 异常，**不代表上传链路坏了**——上传器有本地 `smart_media_parser` + 站内检索 fallback，实测仍能正常识别并完成上传。必须实际跑一次上传器看完整流程再下判断。

⚠️ 上传是 `open(local_path,"rb")` 流式读盘，不生成临时副本。所以"上传节点磁盘不够"通常是伪问题：缺的是**源文件落地空间**，不是上传缓冲。源文件在哪台就在哪台传（零搬运）。


## 五、第三方众包上传站接入：先认平台，再谈自动化

### 5.1 Cloudreve 系指纹（2026-10 实测）

```bash
curl -s https://<站点>/api/v3/site/config   # 返回 {"code":0,"data":{...}} → Cloudreve V3 系
curl -s https://<站点>/api/v4/site/config   # 404 → 确认不是 V4
```

`data` 里会出现 `registerEnabled`、`loginCaptcha`、`authn`、`emailActive`、`user`（Go 风格 `user_name` / `created_at` 字段）。看到这些就是 Cloudreve 系（或兼容其 v3 API 的自研后端）。

### 5.2 端点真假判别（重要陷阱）

| 路径 | 无凭据响应 | 判读 |
|---|---|---|
| `/dav`、`/dav/` | 403（openresty/nginx 页） | WebDAV 路由存在但被前置 nginx 拦截或未启用 |
| `/webdav`、`/webdav/` | **200 + `content-type: text/html` + SPA 外壳** | **前端路由兜底，不是 WebDAV 端点**，别当成功 |
| `/docs` | 200 + 同一个 SPA 外壳 | 同上，SPA 路由兜底 |

判别方法：对同一路径打 `OPTIONS` 与 `PROPFIND`。真正 WebDAV 会返回 `DAV:` 响应头与 XML 多状态体；返回 HTML 的一定是 SPA 兜底。

### 5.3 WebDAV 密码与登录密码分离

Cloudreve 的 WebDAV 用**独立密码**（用户在「设置 → WebDAV」里生成），拿网页登录密码做 Basic Auth 必然失败/403。规划阶段就要向用户要这个独立密码，不要指望登录密码能直接挂 rclone。

站点页脚若写「WebDAV 账号请登录后自行添加」，说明功能存在但需用户手动开通，属于**待用户操作**的前置条件，不是技术障碍。

#### WebDAV 可能根本不在主域（实测：ZZMUPER / <YOUR_PRIVATE_DOMAIN>，2026-10-23）

平台「连接 → WebDAV 账号管理」页给出的地址是**独立主机**：

```
https://oss-ca.ftp2.eu.org/dav     （解析 <YOUR_SERVER_IP>，openresty）
用户名：主站邮箱      密码：该 WebDAV 账号的密码（页面按备注名创建）
```

存活判定（已验证）：

```
OPTIONS /dav/  → 200
Allow: OPTIONS, GET, HEAD, PUT, DELETE, MKCOL, COPY, MOVE, PROPFIND, PROPPATCH, LOCK, UNLOCK
Dav: 1, 2
Ms-Authored-Via: DAV
```

**判活必须用 `OPTIONS` + `Dav:` 头，不要用 `PROPFIND` 的 401 下结论。**

⚠️ **缺 `WWW-Authenticate` 的 401 是"自定义校验"，不是"服务挂了"**：该端点任何带 Basic 认证的 `PROPFIND`/`GET`/`PUT` 都返回 **401 + 空 body + 无 `WWW-Authenticate`**。这属于 openresty 前置自定义鉴权，标准 Basic 语义在这里不成立，因此 `--anyauth` / Digest 也救不回来。

⚠️ **截图里的密码不要靠视觉 OCR + 变体穷举**：本次对截图密码做了 `0/O`、`1/l/I`、`5/S`、`8/B` 全组合 24 次穷举，全部 401，纯属浪费请求。正确做法是让用户点页面上的「复制」按钮把**文本**发过来，或让用户重新生成一次密码。OCR 只用于确认字段结构，不用于取密码值。


### 5.4 登录接口字段与失败判读

Cloudreve v3 登录：`POST /api/v3/user/session`，字段 `userName` + `Password`（大写 P）。

- `{"code":40001,"msg":"Email format error"}` → 后端只接受邮箱格式的用户名。
- `{"code":40001,"msg":"Email cannot be empty"}` → 字段名用错了（比如传了 `email`）。
- `{"code":40020,"msg":"Wrong password or email address"}` → 格式通过但账号/密码不匹配。

拿到 40020 时，用 2~5 个邮箱变体（`user@site`、`user@example.com`、裸用户名等）一次性批量试完，仍失败就**如实报告 40020 并请用户确认密码是否已改**，不要反复猜、也不要把它说成"站点故障"。众包站的账号常是"初始密码"，用户很可能已经改过。

## 六、EMOS 上传器调用链（复用参考）

`upload_to_emos(local_path, custom_filename)` 四步：

1. `identify_video(filename)` → 拿 `item_type` / `item_id`（识别失败直接抛错，不允许跳过）。
2. `POST {BASE}/api/upload/getUploadToken`，body 含 `file_storage: "zn_r2_upload"`，返回 `file_id` 与 `multipart_size.min/max`。
3. `POST {BASE}/api/upload/multipart/{file_id}/presign`，body `{"number": total_parts}` → 分片预签名 URL 列表。
4. 逐片 PUT 到预签名 URL，最后 merge（`abort` 用于失败回滚）。

分片大小策略：默认 10MB，`total_parts > 5000` 时按 `(size+4999)//5000` 放大，并夹在 `min/max` 之间。

错误分类要点：`一周内上传过` / `重复` 属幂等重复，应跳过而非重试；`422 暂无存储空间` 是 `file_storage` 传错或配额耗尽，不要当网络故障重试。

## 八、运维 Bot 上传通道设置面板（lemon-ops-bot 架构）

上传并发数通过 Bot 面板管理，不需要 SSH 登机器改配置。

### 8.1 配置路径

`/home/ubuntu/lemon-ops-bot/emos_config.json`，`upload_config` 节点：

```json
{ "upload_config": { "workers": 5, "channel": "zn_r2_upload" } }
```

`load_config()` 向后兼容自动补齐，老文件不会崩。

### 8.2 面板结构

```
EMOS 主面板 (m:emos)
  └─ ⚡ 上传通道与并发 (emos:upload_cfg)
       ├─ [1 线程] [3 线程] [✅ 5 线程] [8 线程]  (emos:set_workers:{n})
       ├─ 🚀 实测上传速度 (emos:speedtest)
       └─ « 返回 EMOS 面板
```

点按钮即写入配置，下次上传自动使用新并发数。`emos:speedtest` 触发 `/root/emos_speedtest.py` 在 LA 测速 200MB，全程 abort 不入库，约 10~40s 返回速度卡片。

### 8.3 调度端注入方式

`emos_service.execute_remote_vps_emos_upload()` 从配置读 workers，注入为 SSH 远端命令环境变量：

```python
exec_cmd = f"EMOS_UPLOAD_WORKERS={_workers} python3 /root/emos_uploader.py ..."
```

上传器代码本身从 `os.environ.get("EMOS_UPLOAD_WORKERS", "5")` 读取，不改文件、只改环境变量，两边完全解耦。


规划类任务交付时给：实测基线表（带采样时间与时区）、分工结论、待用户确认项、落地步骤、风险红线。**把"需要用户提供的东西"单独列成一节**，不要混在技术方案里，用户才能一眼看到卡在哪。
