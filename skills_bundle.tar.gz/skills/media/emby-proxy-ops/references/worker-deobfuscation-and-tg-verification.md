# 混淆 Worker 反编译审计 + Telegram 播报链路硬证据验证

面向玛卡巴卡 / MakkaPakka 这类**已被 javascript-obfuscator 混淆**的生产 Worker：
如何在不上传任何新代码的前提下读懂它、定位故障、修复后拿到可证伪的验证证据。

---

## 一、拉取真实生产代码（避开 10405 陷阱）

`GET /accounts/{acct}/workers/scripts/{name}/content` 对 API Token 鉴权方式返回：

```json
{"success":false,"errors":[{"code":10405,"message":"Method not allowed for this authentication scheme"}]}
```

改用**不带 `/content`** 的端点，返回 `multipart/form-data`：

```bash
curl -s "https://api.cloudflare.com/client/v4/accounts/$ACCT/workers/scripts/$NAME" \
     -H "Authorization: Bearer $WORKERS_EDIT_TOKEN" -o raw.multipart
```

剥出 JS 本体：

```python
import re
raw = open('raw.multipart','rb').read()
m = re.search(rb'name="worker\.js"\r\n\r\n(.*?)\r\n--[0-9a-f]{20,}', raw, re.S) \
    or re.search(rb'name="worker\.js"\r\n\r\n(.*)', raw, re.S)
open('prod_worker.js','wb').write(m.group(1))
```

**第一件事永远是 md5 三方比对**（生产 vs `*.backup.js` vs `patched_*.js`），
再统计关键补丁标记计数。标记计数为 0 = 该补丁从未上线，别信本地文件名。

```python
for k in ['EMOS-PROXY-ID','video.emos.best','PlaybackInfo','Items/Counts','redirect']:
    print(k, prod.count(k), patched.count(k))
```

共同前缀/后缀扫描能精确定位「patched 比 prod 多出的那一段」：

```python
p = 0
while p < min(len(a),len(b)) and a[p]==b[p]: p += 1
s = 0
while s < min(len(a),len(b))-p and a[-1-s]==b[-1-s]: s += 1
# a[p:len(a)-s] 与 b[p:len(b)-s] 即两边各自独有段
```

---

## 二、反混淆：还原字符串表（关键，别硬啃 XOR）

混淆形态特征：`_0x91cc67(645630^645120)` —— 解码器别名 + XOR 索引。

### 1. 找出解码器与字符串表

用括号配平抓完整函数体（正则抓不全，函数体内有嵌套 `{}`）：

```javascript
function grabFn(name) {
  const key = 'function ' + name + '(';
  const i = src.indexOf(key);
  let depth = 0, started = false;
  for (let j = i; j < src.length; j++) {
    if (src[j] === '{') { depth++; started = true; }
    else if (src[j] === '}') { depth--; if (started && depth === 0) return src.slice(i, j+1); }
  }
}
```

枚举 `function (_0x[0-9a-f]+)\s*\(` 找出所有候选。实测本 Worker 有**两套**表+解码器
（`_0x2559`/`_0x42aa` 是 12 条的诱饵表，真表是 `_0x3e56`/`_0x4c6f`，330 条、181KB）。
别在小表上浪费时间，按 `table fn len` 挑最大的那个。

### 2. ⚠️ 必须先执行 rotation IIFE，否则解码全是乱码

javascript-obfuscator 生成的 `(function(a,b){...while(true){...shift/push...}})(_0xTABLE, 0x8b29f);`
会在运行时**旋转字符串表到正确顺序**。跳过它直接调解码器，会拿到 `"has"`、`"MediaStreams"`
这种张冠李戴的结果（本次第一版脚本就踩了，替换出 916 处全是错的）。

正确姿势 —— 把「表函数 + 解码器 + rotation IIFE」一起塞进同一个 `new Function` 作用域执行：

```javascript
const iifes = [];
const re = /\(function\(_0x[0-9a-f]+,_0x[0-9a-f]+\)\{/g;
let m;
while ((m = re.exec(src)) !== null) {
  let depth = 0, end = -1;
  for (let j = m.index; j < src.length; j++) {
    if (src[j] === '(') depth++;
    else if (src[j] === ')') { depth--; if (depth === 0) { end = j; break; } }
  }
  const call = src.slice(end+1, end+60).match(/^\((_0x[0-9a-f]+),(0x[0-9a-f]+|\d+)\)/);
  if (call) iifes.push(src.slice(m.index, end+1+call[0].length) + ';');
}
const parts = [grabFn('_0x3e56'), grabFn('_0x4c6f'), ...iifes];
const R = new Function(parts.join('\n') + '\nreturn {d:_0x4c6f};')();
```

### 3. 探测真实 offset（别去解析源码里的减法常量）

暴力扫索引反查已知字符串，比解析 `_0x - (206701^206822)` 可靠：

```javascript
for (let i = 0; i < 3000; i++) {
  const v = R.d(i);
  if (v === 'plain_text') console.log('plain_text @', i);
  if (v === 'https://api.telegram.org/bot') console.log('tg @', i);
}
```

### 4. 全量替换 + 转义还原

递归解析 `const A = B;` 别名链拿到全部解码器别名（本次 34 个），只替换命中别名的调用：

```javascript
out = src.replace(/(_0x[0-9a-f]+)\((\d+)\^(\d+)\)/g, (full, fn, a, b) => {
  if (!fnRoot.has(fn)) return full;
  const v = R.d(parseInt(a) ^ parseInt(b));
  return typeof v === 'string' ? JSON.stringify(v) : full;
});
out = out.replace(/\\u([0-9a-fA-F]{4})/g, (m,h) => {
  const c = String.fromCharCode(parseInt(h,16));
  return (c === '"' || c === '\\' || c === '\n' || c === '\r') ? m : c;   // 别破坏字符串边界
});
out = out.replace(/"((?:[^"\\]|\\.)*)"\.split\(""\)\.reverse\(\)\.join\(""\)/g,
                  (m,s) => JSON.stringify([...s].reverse().join('')));
out = out.replace(/\((\d+)\^(\d+)\)/g, (m,a,b) => String(parseInt(a)^parseInt(b)));
```

**成功判据**：替换数百处且 `失败 0 处`，且抽查段落语义自洽（能读出 `"plain_text"`、
`"secret_text"`、`"main_module"`、`"push"` 这类合理标识符）。若读出 emoji 文案当属性名，
说明表没转对，回到步骤 2。

---

## 三、玛卡巴卡面板已知内部结构（本次反混淆所得）

- 路由清单：`/api/deploy`、`/api/tg-webhook`、`/api/routes/import`、`/api/get-custom-api-ips`
- `scheduled` 入口：`env.TG_BOT_TOKEN && env.TG_CHAT_ID && env.DB && ctx.waitUntil(sendTgStats(env, env.TG_CHAT_ID))`
- `tg-webhook` 触发条件（很关键）：仅当 `body.message.text === "/stats"` 才调 `sendTgStats(env, body.message.chat.id)`，
  且**总是返回 200 "OK"**（连解析异常也返回 OK）—— 所以 HTTP 200 不代表播报成功，必须另找证据。
- 播报文案：`📊 *今日观看情况播报*`，含双面板播放次数、最多地区、今日最爱、`getCFTraffic` 的日/周/月流量、流量之王，`parse_mode: Markdown`
- `sendTgStats` 全程包在 `try/catch` 里，失败只 `console.error('TG Send Error:', e)` —— **这就是"静默失败"的机制**
- `/api/deploy` bindings 收集循环（故障根源）：

```javascript
const arr = [];
for (const k in env) {
  typeof env[k] === 'string' && arr.push({name: k, type: 'plain_text', text: env[k]});
}
// 再 GET /bindings，把 type 不是 plain_text/secret_text/inherited 的（即 D1 等）追加回去
```

无脱敏检测 → 只要变量是 `plain_text`，`8921369747:***` 就会被原样写回生产。

---

## 四、修复后的硬证据验证（核心方法论）

### 反面教材：这些都不算证据

- ❌ 本地脚本用备份里的真实 Token 发送成功 → 证明的是**备份 Token 有效**，不是生产已修复
- ❌ 部署 API 返回 `success: true` → 只证明 CF 接受了这次 PUT
- ❌ `POST /api/tg-webhook` 返回 200 OK → 该端点无条件返回 OK

### 正解：两段式

**第 1 段 —— 逼生产环境自己动手**

灌一个伪造的 Telegram update 打生产端点，让 Worker 用**它自己 env 里的** Token 去发消息：

```python
payload = {'update_id': int(time.time()),
           'message': {'message_id': 999001,
                       'from': {'id': CHAT_ID, 'is_bot': False, 'first_name': 'x'},
                       'chat': {'id': CHAT_ID, 'type': 'private'},
                       'date': int(time.time()), 'text': '/stats'}}
req = urllib.request.Request(f'https://{HOST}/api/tg-webhook',
        data=json.dumps(payload).encode(), method='POST',
        headers={'Content-Type': 'application/json',
                 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
                               'AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'})
```

⚠️ **必须带浏览器 UA**：空 UA 会被 Cloudflare BIC 拦成 `403 error code: 1010`，
与面板配置无关（Telegram 官方 webhook 自带 UA 所以不受影响，别误判为面板故障）。

**第 2 段 —— 探测 message_id 是否真的新增**

webhook 模式下 `getUpdates` 不可用（会与 webhook 冲突），改用 `editMessageReplyMarkup` 侧信道：

```python
def probe(mid):
    data = urllib.parse.urlencode({'chat_id': CHAT, 'message_id': mid}).encode()
    try:
        urllib.request.urlopen(urllib.request.Request(
            f'https://api.telegram.org/bot{TG}/editMessageReplyMarkup', data=data), timeout=20)
        return 'EXISTS'
    except urllib.error.HTTPError as e:
        d = json.loads(e.read().decode()).get('description','')
        if 'not modified' in d: return 'EXISTS'   # 消息在，只是没改动
        if 'not found'    in d: return 'ABSENT'   # 消息不存在
        return 'OTHER: ' + d
```

扫一段连续 ID，看到「已知基线之后新增了 N 条 EXISTS，再往后是 ABSENT」即证明生产真发出了 N 条。
本次实测：基线 38（本地代发）之后 39、40 为 EXISTS、41+ 为 ABSENT ⇒ 生产 Worker 自己发出了 2 条播报。

副产物：`getWebhookInfo` 能确认 webhook URL、`pending_update_count`、`last_error_message`，
但**没有** `last_error_message` 字段不代表没出错（sendMessage 失败不算 webhook 投递失败）。

---

## 五、离线单测补丁逻辑（改混淆代码前的必要保险）

不要把补丁直接推上生产再看效果。把补丁逻辑连同解码器 stub 抽到独立 `.js` 里跑用例：

```javascript
const _0x91cc67 = (n) => ({[415663^414993]:'string',
                           [470489^470032]:'plain_text',
                           [876146^876455]:'push'}[n]);
// ... 粘贴补丁后的收集循环 ...
// 用例：健康 env 分类正确 / 脱敏值必须 throw / 含单个星号的合法值不误杀 / D1 对象不被当字符串收集
```

同时对整份补丁文件跑 `node --check`，并做锚点计数回归
（`/api/deploy`、`sendTgStats`、`async'scheduled'`、`secret_text` 数量不得减少）。

---

## 六、复盘：本次故障完整时间线

1. 2026-09-02 12:03 一次热更新把 CF API 返回的脱敏 bindings 原样回写 → `TG_BOT_TOKEN = 8921369747:***`
2. Cron `0 14 * * *`（北京 22:00）每天准点执行 `sendTgStats`
3. `fetch('https://api.telegram.org/bot8921369747:***/sendMessage')` → 404
4. `catch` 只打 console.error → 用户侧完全静默，「没报错但收不到」
5. 修复：真实 Token 回写 + 三项敏感变量升 `secret_text` + `ADMIN_TOKEN` 从 `0618`（4 位数字）换成 20 位随机串
6. 验证：webhook 灌注 → message_id 39/40 新增 → 确认生产链路恢复

顺带查出的账号级问题（非本次故障，但值得收窄）：
主 Token 只有 `Workers:Edit` 无 DNS 权限，而 Worker bindings 内嵌的 `CF_API_TOKEN`
反而握有整个 Zone 的 `Zone.DNS:Edit` —— 权限装反且以明文存在于 env 里。
排障时对每个已知 Token 逐个试探同一接口，别用单一 Token 的 403 判定「账号没权限」。
