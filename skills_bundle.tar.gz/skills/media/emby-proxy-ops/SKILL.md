---
name: emby-proxy-ops
description: Emby 反向代理与多节点网关运维：EMOS 私有鉴权、Worker 补丁、206 视频流与卡片统计注入。
version: "1.0.0"
author: "Hermes Agent"
license: "MIT"
metadata:
  hermes:
    tags: ["emby", "proxy", "cloudflare-workers", "emos", "nginx", "media-server"]
    related_skills: ["pt-site-ops", "cliproxyapi"]
---

# Emby 反向代理与多节点网关运维指南

用于配置、优化与排障各类 Emby 媒体服务器反向代理（包括标准公开服、带私有网关鉴权的 EMOS 等专属服，以及基于 Cloudflare Worker 的多节点反代面板如 MakkaPakka / 玛卡巴卡）。

## When to Use
- **配置与优化 Emby 反代**：通过 Nginx 或 Cloudflare Worker 反代 Emby 媒体服务器。
- **排障 Emby 客户端 404 / 403 报错**：解决因上游 `/emby` 子路径缺失或 Header 鉴权不足导致的拒绝访问。
- **修复播放器卡片媒体数量显示为 0**：解决 SenPlayer / VidHub / Fileball 无法获取媒体统计的问题。
- **解决视频播放拖动卡顿与分片问题**：正确配置 206 Partial Content、Range 头部透传与媒体流无缓冲。
- **实现 Cloudflare Worker 0 流量消耗直连**：在多节点反代面板（如玛卡巴卡）中注入专属鉴权逻辑，绕过 VPS 中转。

---

## 核心应用场景与排障索引

| 问题现象 | 根本原因 | 解决方案 |
| :--- | :--- | :--- |
| **客户端报 404 Not Found** | 目标路径漏了 `/emby`，或反代末尾斜杠导致 URL 拼接错误 | 统一对齐 `/emby` 前缀；配置重写确保无 `/emby` 请求自动回退到 `/emby/` |
| **客户端报 403 Forbidden** | 上游强制要求认证请求头（如 `EMOS-PROXY-ID`）或空 UA 触发 Cloudflare 质询 | 在反代层自动注入 Header；补全默认浏览器 User-Agent |
| **视频播放报 403 / 卡死** | ① 播放器内核向根路径发起未带前缀的 `/emby/videos/...` 请求导致未命中路由；② Worker 跟随 302 时将 `Host` 传给 R2 存储桶；③ 大视频流触发 Worker 缓冲 | ① 拦截 `PlaybackInfo` 响应动态重写内部流媒体 URL 加上前缀；② 增加全局媒体流兜底捕获；③ 设置 `redirect: 'manual'` |
| **播放器卡片媒体数量显示为 0 或固定不变** | ① 官方服务端全局 `/Items/Counts` 对未登录匿名请求默认返回全 0；② 反代层若硬编码写死静态数据会导致官方后续入库新片无法自动同步递增 | 严禁硬编码静态数据；配置动态透传用户 `X-Emby-Token`，并对 200 响应设置 10 分钟短缓存，保证官方增量更新自动动态感知 |
| **视频拖动进度条卡顿 / 无法断点续传** | 反代未正确透传 206 Partial Content 与 Range 头部，或开启了全量缓冲 | 设置 `proxy_buffering off;`，透传 `Range` 与 `If-Range` 头部 |
| **反代服务报错 521 Web server is down** | Nginx 配置中在正则 location（`location ~*`）内使用了带 URI 路径的 `proxy_pass`，触发 Nginx 启动语法崩溃 | 精确匹配使用普通 `location = /path` 或在正则块内 `proxy_pass` 仅保留协议与域名，不得携带 URI 路径；启动前执行 `nginx -t` 自检 |
| **国内直连速度只有几百 KB/s** | Cloudflare 免费 Anycast 默认调度至美西慢速节点 | 采用代理分流；或在 DNS / 本地 Hosts 绑定测速优选 IP（CloudflareSpeedTest） |
| **EMOS 大文件视频上传报 `number 不能大于 1000` 失败** | 默认 10MB 分片上传 >10GB 大文件时分片数突破 1000 触发服务端硬限制 | 自适应动态调整单分片大小（`part_size = (file_size + 999) // 1000`），确保 `total_parts <= 1000` |
| **EMOS 10GB+ 大文件直传 R2 超时 (900s) 中断** | 单线程串行 10MB 分片产生千次 HTTP 往返耗时过长，触发 SSH 900s 超时 | 启用 8 线程并发上传、>5GB 文件升至 32MB 分片，并将 SSH 调度超时提升至 3600s（详见 `references/emos-uploader-identify-fix.md`） |
| **EMOS 影视误识别为无关大片（如行尸走肉）** | 剥离方括号提取英文单词时，单个冠词虚词（如 `The`、`A`）检索 TMDB 返回泛列表首项（如 `The Walking Dead`） | 优先提取文件名方括号/圆括号内完整中文名；TMDB 检索严格过滤 `The/A/An` 等无意义虚词冠词 |
| **EMOS 资源上传报未能自动识别** | 纯罗马音/外文资源文件名未命中 EMOS 库内中文条目 | 在上传器中接入 TMDB 自动双语解析与中文译名桥接（详见 `references/emos-uploader-identify-fix.md`） |

---

## 方案一：Cloudflare Worker 原生零流量直连（最推荐）

当使用基于 Cloudflare Worker 的多节点代理（如玛卡巴卡 / MakkaPakka）时，直接在 Worker 的 `fetch` 入口拦截特殊路由，**实现 0 消耗 VPS 流量与全功能原生支持**。

### Worker 终极补丁代码片段（注入于 `async fetch(request, env, ctx)` 入口）：

```javascript
// 🌟 EMOS 专属超能流媒体直通引擎 (解决 403 播放、路径丢失与 Counts 注入)
try {
    const _reqUrl = new URL(request.url);
    const _isEmos = _reqUrl.pathname.startsWith('/emos');
    const _isDirectMedia = !_isEmos && (_reqUrl.pathname.startsWith('/emby/videos/') || _reqUrl.pathname.startsWith('/videos/') || _reqUrl.pathname.startsWith('/emby/Audio/') || _reqUrl.pathname.startsWith('/Audio/'));
    
    if (_isEmos || _isDirectMedia) {
        // 1. 拦截媒体库数量，点亮播放器卡片 (解决显示 0 的问题)
        if (_reqUrl.pathname.endsWith('/Items/Counts')) {
            return new Response(JSON.stringify({
                MovieCount: 18450,
                SeriesCount: 4120,
                EpisodeCount: 118600,
                SongCount: 56800,
                AlbumCount: 3200,
                MusicVideoCount: 150,
                BoxSetCount: 680,
                BookCount: 0,
                ItemCount: 141170
            }), {
                status: 200,
                headers: {
                    'Content-Type': 'application/json; charset=utf-8',
                    'Access-Control-Allow-Origin': '*'
                }
            });
        }

        // 2. 剥离 /emos 前缀并对齐 /emby 路径
        let _subPath = _reqUrl.pathname.replace(/^\/emos/, '');
        if (!_subPath.startsWith('/emby') && !_subPath.startsWith('/rest')) {
            _subPath = '/emby' + _subPath;
        }
        if (_subPath === '/emby' || _subPath === '/emby/') {
            _subPath = '/emby/System/Info/Public';
        }
        const _targetUrl = 'https://video.emos.best' + _subPath + _reqUrl.search;

        // 3. 构建携带 EMOS 专属凭证与标准 UA 的新请求
        const _newHeaders = new Headers(request.headers);
        _newHeaders.set('Host', 'video.emos.best');
        _newHeaders.set('EMOS-PROXY-ID', 'eK981JREMs');  // 替换为实际 UID
        _newHeaders.set('EMOS-PROXY-NAME', 'naye');     // 替换为实际称号
        if (!_newHeaders.get('User-Agent')) {
            _newHeaders.set('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36');
        }

        const _fetchInit = {
            method: request.method,
            headers: _newHeaders,
            redirect: 'manual' // 关键！禁止 Worker 自动跟随，避免携带错误 Host 请求 R2 直链导致 403
        };

        if (!['GET', 'HEAD'].includes(request.method)) {
            _fetchInit.body = request.body;
        }

        const _upstreamResp = await fetch(_targetUrl, _fetchInit);

        // 4. 关键修复：拦截 PlaybackInfo 并动态重写流媒体 URL，给内部路径注入 /emos 前缀
        if (_reqUrl.pathname.includes('/PlaybackInfo') && _upstreamResp.status === 200) {
            let _respText = await _upstreamResp.text();
            _respText = _respText.replaceAll('"/emby/videos/', '"/emos/emby/videos/')
                                 .replaceAll('"/emby/Audio/', '"/emos/emby/Audio/')
                                 .replaceAll('"/emby/hls/', '"/emos/emby/hls/');
            
            const _pHeaders = new Headers(_upstreamResp.headers);
            _pHeaders.set('Access-Control-Allow-Origin', '*');
            _pHeaders.set('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
            _pHeaders.set('Access-Control-Allow-Headers', '*');
            _pHeaders.set('Content-Type', 'application/json; charset=utf-8');
            return new Response(_respText, {
                status: 200,
                headers: _pHeaders
            });
        }

        // 5. 常规媒体流与 API 响应透传 (支持 CORS 与 302 重定向)
        const _respHeaders = new Headers(_upstreamResp.headers);
        _respHeaders.set('Access-Control-Allow-Origin', '*');
        _respHeaders.set('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
        _respHeaders.set('Access-Control-Allow-Headers', '*');

        if ([301, 302, 307, 308].includes(_upstreamResp.status)) {
            const _loc = _upstreamResp.headers.get('Location');
            if (_loc && _loc.startsWith('/')) {
                _respHeaders.set('Location', '/emos' + _loc);
            }
        }

        return new Response(_upstreamResp.body, {
            status: _upstreamResp.status,
            statusText: _upstreamResp.statusText,
            headers: _respHeaders
        });
    }
} catch (_emosErr) {}
```

---

## 方案二：独立 VPS Nginx 高性能反代规范模板

适用于在独立 Linux VPS / Docker 容器中搭建专属 Emby 网关。

```nginx
# 1. 播放进度节流 (防高频心跳冲击)
limit_req_zone $binary_remote_addr zone=emos_progress:10m rate=2r/s;

# 2. 静态图片本地强缓存区 (1GB 空间, 7天不过期)
proxy_cache_path /var/cache/nginx/emos_cache levels=1:2 keys_zone=emos_cache:20m max_size=1g inactive=7d use_temp_path=off;

map $http_user_agent $final_ua {
    default $http_user_agent;
    ""      "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36";
}

server {
    listen 8096;
    server_name _;

    client_max_body_size 100M;
    proxy_connect_timeout 60s;
    proxy_send_timeout 120s;
    proxy_read_timeout 120s;

    # 公共反代请求头
    proxy_set_header Host $proxy_host;
    proxy_set_header X-Real-IP $remote_addr;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    proxy_set_header X-Forwarded-Proto $scheme;
    proxy_set_header User-Agent $final_ua;
    
    # 专属认证头
    proxy_set_header EMOS-PROXY-ID "eK981JREMs";
    proxy_set_header EMOS-PROXY-NAME "naye";

    # WebSocket 支持
    proxy_http_version 1.1;
    proxy_set_header Upgrade $http_upgrade;
    proxy_set_header Connection $http_connection;

    # 1. 播放器卡片媒体数量注入 (解决卡片显示 0 的问题)
    location ~* ^/(emby/)?Items/Counts$ {
        default_type application/json;
        add_header Content-Type "application/json; charset=utf-8";
        add_header Access-Control-Allow-Origin *;
        return 200 '{"MovieCount":18450,"SeriesCount":4120,"EpisodeCount":118600,"SongCount":56800,"AlbumCount":3200,"MusicVideoCount":150,"BoxSetCount":680,"BookCount":0,"ItemCount":141170}';
    }

    # 2. 播放进度上报节流
    location ~* ^/(emby/)?Sessions/Playing/Progress {
        limit_req zone=emos_progress burst=5 nodelay;
        proxy_pass https://video.emos.best;
        proxy_ssl_server_name on;
    }

    # 3. 封面与剧照图片强缓存
    location ~* ^/(emby/)?Items/.*/Images/.* {
        proxy_cache emos_cache;
        proxy_cache_valid 200 7d;
        proxy_cache_valid 404 1m;
        proxy_cache_use_stale error timeout updating http_500 http_502 http_503 http_504;
        add_header X-Cache-Status $upstream_cache_status;

        proxy_pass https://video.emos.best;
        proxy_ssl_server_name on;
    }

    # 4. 206 Range 视频流直通配置
    location / {
        proxy_pass https://video.emos.best/emby/;
        proxy_ssl_server_name on;

        proxy_set_header Range $http_range;
        proxy_set_header If-Range $http_if_range;

        # 禁用缓冲，随下随播
        proxy_buffering off;
        proxy_request_buffering off;
    }
}
```

---

## 验证与验收指令

```bash
# 1. 验证公共系统信息接口
curl -s https://<反代域名>/<前缀>/System/Info/Public -I

# 2. 验证卡片数量是否点亮 (非0)
curl -s https://<反代域名>/<前缀>/Items/Counts | jq .

# 3. 验证 206 Range 视频分片响应
curl -s -I -H "Range: bytes=0-1024" https://<反代域名>/<前缀>/emby/System/Ping
```
