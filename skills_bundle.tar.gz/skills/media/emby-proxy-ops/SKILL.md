---
name: emby-proxy-ops
description: Emby 反向代理与多节点网关运维：EMOS 私有鉴权、Worker 补丁、206 视频流与卡片统计注入。
version: "1.0.0"
author: "Hermes Agent"
license: "MIT"
metadata:
  hermes:
    tags: ["emby", "proxy", "cloudflare-workers", "emos", "nginx", "media-server"]
    related_skills: ["pt-site-ops", "cliproxyapi"]
---

# Emby 反向代理与多节点网关运维指南

用于配置、优化与排障各类 Emby 媒体服务器反向代理（包括标准公开服、带私有网关鉴权的 EMOS 等专属服，以及基于 Cloudflare Worker 的多节点反代面板如 MakkaPakka / 玛卡巴卡）。

## When to Use
- **配置与优化 Emby 反代**：通过 Nginx 或 Cloudflare Worker 反代 Emby 媒体服务器。
- **排障 Emby 客户端 404 / 403 报错**：解决因上游 `/emby` 子路径缺失或 Header 鉴权不足导致的拒绝访问。
- **修复播放器卡片媒体数量显示为 0**：解决 SenPlayer / VidHub / Fileball 无法获取媒体统计的问题。
- **解决视频播放拖动卡顿与分片问题**：正确配置 206 Partial Content、Range 头部透传与媒体流无缓冲。
- **实现 Cloudflare Worker 0 流量消耗直连**：在多节点反代面板（如玛卡巴卡）中注入专属鉴权逻辑，绕过 VPS 中转。

---

## 核心应用场景与排障索引

| 问题现象 | 根本原因 | 解决方案 |
| :--- | :--- | :--- |
| **客户端报 404 Not Found** | 目标路径漏了 `/emby`，或反代末尾斜杠导致 URL 拼接错误 | 统一对齐 `/emby` 前缀；配置重写确保无 `/emby` 请求自动回退到 `/emby/` |
| **客户端报 403 Forbidden** | ① 上游强制要求认证请求头（如 `EMOS-PROXY-ID`）或空 UA 触发 Cloudflare 质询；② 自定义 Worker 入口硬编码写死单一账号凭据导致流媒体请求与客户端真实 Session 冲突 | 在反代层动态透传客户端 Header；对于多节点/多用户面板（如 MakkaPakka），采用 D1 原生动态代理路由，严禁写死静态账号凭据 |
| **视频播放报 403 / 404 / 卡死** | ① EMOS 最新 2026 流媒体 API 架构采用了 `/emya/video?server=emos&media_id=...` 独立视频流路径，反代层若未捕获或错误拼接 `/emby` 会返回 `404: Node not found`；② 播放器内核向根路径发起未带前缀的 `/emby/videos/...` 或大小写不一致的 `/Videos/...` 请求导致未命中鉴权；③ Worker 跟随 302 时将 `Host` 传给 R2 存储桶抛出 403；④ 302 重定向到 R2 绝对链接时错误拼接了 `/emos` 前缀导致 R2 签名失效报错 403 | ① 针对 `/emya/video` 注入精准直通逻辑（严禁添加 `/emby` 前缀，直接对齐 `https://video.emos.best/emya/video` 并透传 EMOS-PROXY-ID/NAME）；② 拦截 `PlaybackInfo` 响应并对所有音视频路径（`/Videos/`、`/videos/`、`/emya/`、`/Audio/`、`/audio/`、`/hls/`）强制重写注入前缀；③ 在 Worker 入口做全局流媒体兜底捕获；④ 设置 `redirect: 'manual'` 透传 302 直链，仅当 Location 为相对路径时拼接前缀，绝对路径原样透传 |
| **播放器卡片媒体数量显示为 0 或固定不变** | ① 官方服务端全局 `/Items/Counts` 对未登录匿名请求默认返回全 0；② 反代层若硬编码写死静态数据会导致官方后续入库新片无法自动同步递增 | 严禁硬编码静态数据；配置动态透传用户 `X-Emby-Token`，并对 200 响应设置 10 分钟短缓存，保证官方增量更新自动动态感知 |
| **视频拖动进度条卡顿 / 无法断点续传** | 反代未正确透传 206 Partial Content 与 Range 头部，或开启了全量缓冲 | 设置 `proxy_buffering off;`，透传 `Range` 与 `If-Range` 头部 |
| **Telegram 定时播报/通知静默失败（无报错但收不到消息）** | 从 Cloudflare API（`workers/scripts/.../bindings`）拉取环境变量时，Cloudflare 默认对敏感 Token（如 `TG_BOT_TOKEN`）进行了星号脱敏（如 `8921369747:***`），若在后续更新 Worker 时直接将该 bindings 结构重新上传，会将脱敏字符串写入生产环境，导致发向 Telegram API 报 404/401 失败 | 严禁直接使用 Cloudflare API 返回的脱敏 bindings 重新部署；更新 Worker 时必须显式传入完整的原始密钥，或在自动化脚本中增加脱敏检测防护（`if '***' in token: raise Error`） |
| **反代服务报错 521 Web server is down** | Nginx 配置中在正则 location（`location ~*`）内使用了带 URI 路径的 `proxy_pass`，触发 Nginx 启动语法崩溃 | 精确匹配使用普通 `location = /path` 或在正则块内 `proxy_pass` 仅保留协议与域名，不得携带 URI 路径；启动前执行 `nginx -t` 自检 |
| **普通非优化/绕美 NAT 小鸡直连 Emby 严重卡顿与起播延迟高** | 小鸡虽然国际下行大，但回国路由未走 CN2 GIA/CMI 直连，回国往返绕美（延迟 200ms+），导致 PlaybackInfo 握手、海报瀑布流与起播前摇极慢（即使视频流走 R2 308 直链） | ① 播放端坚决保留 Cloudflare Worker 优选双轨（电信/移动优选 IP 直连，延迟 30~50ms）；② 非优化大带宽小鸡仅用于后台重流量任务（TG 爬虫、PT/EMOS 上传做种、S5 打手），严禁直接用作 Emby 客户端直连节点 |
| **NAT 小鸡非标端口直连报 530 Direct IP access not allowed** | 域名在 Cloudflare 开启了橙色小云朵（已代理 / Proxied），但客户端访问的是非标准 Web 端口（如 NAT 映射的 300xx/344xx），触发 CF Anycast 边缘网关拦截 | 在 Cloudflare DNS 中将该子域名切换为【仅 DNS / DNS only ☁️（灰色云朵）】，直连小鸡 NAT 端口享受原生低延迟；或改用 Cloudflare 官方支持的 HTTPS 端口（2053/8443） |
| **Worker 自定义域名报 522 Connection timed out** | DNS 中存在手动的占位解析记录（如手动配置的 `AAAA 100::` 或源站 A 记录）导致请求未被正确接入 Worker 处理管线 | 删除冲突的手动 DNS 记录，改在 Worker 后台的 `Custom Domains`（自定义域）中统一绑定，由 Cloudflare 自动生成管线映射与证书 |
| **优选直连加速域名报 Connection Reset (连接被重置)** | 加速域名（如 `yd-fd.586934.xyz`）仅在 DNS 配置了 A 记录，缺少 Cloudflare Zone 级的 Worker 路由规则 | 在 Cloudflare Zone 的 `Workers Routes` 中添加 `yd-fd.586934.xyz/* -> <Worker名称>` 确保边缘正确分发 |
| **反代服务报错 521 Web server is down** | ① Nginx 配置中在正则 location 内使用了带 URI 路径的 `proxy_pass` 触发语法崩溃；② 部署官方原版 Worker 覆盖了包含上游 Header（如 `EMOS-PROXY-ID`/`NAME`）的自定义流媒体补丁引擎导致回源鉴权失败 | ① 正则块内 `proxy_pass` 仅保留协议与域名；② 确保在 Worker 的 `fetch` 入口保留 EMOS 专属直通引擎注入 |
| **Cloudflare Worker 调度模式导致启播延迟与慢速** | Worker 调度模式被锁死在跨洋机房，或测速工具批量写入包含高丢包/IPv6 慢速节点 | ① 将 Worker 设置为 `smart` 智能自适应调度；② 清理 DNS AAAA 慢速记录，只保留经校验的精选骨干 IP；③ 极速秒开最佳实践：播放器直接走亚太（香港/新加坡）代理分流 |
| **播放器连接报 400 Bad Request** | 客户端默认开启 HTTPS 请求未配置 SSL 的 HTTP 端口（如 2052） | 在 VPS Nginx 部署自签名/受信任 SSL 证书并在 Cloudflare HTTPS 支持端口（如 `2053` / `8443`）监听，客户端统一使用 `https://<域名>:2053` 连接 |
| **切换反代地址或日常观影报 403 / 401 报错** | 客户端本地持久化缓存了已失效的旧 Session / X-Emby-Token，或与当前反代网关 Session 不匹配 | 引导客户端退出当前登录/删除失效服务器，重新输入用户名密码登录生成全新有效 Session Token 即可秒级恢复 |
| **第三方服（如可乐服 Cola 等）通过 Worker 反代播放报 403 Forbidden** | ① 上游 302 直链防盗链签名绑定了发起 PlaybackInfo 时的客户端 IP（绑定了 Cloudflare 机房 IP），播放器本地网络下载时 IP 不一致被源站拒绝；② SenPlayer/AVPlayer 播放内核请求相对媒体路径时丢失了子路径节点前缀（如 `/kl`）触发 404/路由异常 | ① 在播放器（SenPlayer / VidHub）中关闭该服的「302 / 直链播放」，切换为「服务端代理 / 直通中转」；② 第三方带 IP 绑定防盗链的 302 公益服建议直接使用官方原版直连地址或专线代理播放（详见 `references/emos-and-makkapakka.md`） |
| **国内直连速度慢 / 启播延迟高** | ① 测速工具写入了大量含丢包/高延迟的杂乱 Anycast 节点；② Worker 调度跨洋；③ 境外 Anycast 晚高峰限速 | ① 清理 DNS 冗余记录，锁定优质骨干 IP；② 将 Worker 调度模式（Smart Placement）指定至亚太香港 `aws:ap-east-1`；③ 终极方案：使用独立 VPS（如 RackNerd）开启本地 2GB 内存强缓存与 `proxy_buffering off` 极速直通 |
| **EMOS 大文件视频上传报 `number 不能大于 1000` 失败** | 默认 10MB 分片上传 >10GB 大文件时分片数突破 1000 触发服务端硬限制 | 自适应动态调整单分片大小（`part_size = (file_size + 999) // 1000`），确保 `total_parts <= 1000` |
| **EMOS 10GB+ 大文件直传 R2 超时 (900s) 中断** | 单线程串行 10MB 分片产生千次 HTTP 往返耗时过长，触发 SSH 900s 超时 | 启用 8 线程并发上传、>5GB 文件升至 32MB 分片，并将 SSH 调度超时提升至 3600s（详见 `references/emos-uploader-identify-fix.md`） |
| **EMOS 影视误识别为无关大片/老番（如《八犬传》、《行尸走肉》）** | ① 剥离方括号提取英文单词时，单个冠词虚词（如 `The`、`A`）检索 TMDB 返回泛列表首项（如 `The Walking Dead`、`THE八犬传`）；② 中转 VPS 磁盘满导致 qB 报错挂起，旧缓存文件未自动清理 | ① 优先提取文件名方括号/圆括号内完整中文主名；TMDB 检索严格过滤 `The/A/An` 等虚词；② 定期/传前检查 VPS 磁盘并清理已上传完成的历史旧种子（详见 `references/emos-uploader-identify-fix.md`） |
| **多季剧集（第二季/S02）命名被写死为 S01E... 导致刮削错位** | 自动化命名与转存逻辑中季数硬编码或未解析中文季数 | 采用动态正则解析季数（支持中文数字转换），规范输出 `S{season:02d}E{ep:02d}` 格式（详见 `references/emos-uploader-identify-fix.md`） |
| **Emby/Foam 众包积分入库系统设计与防刷风控** | 众包求片容易被利用并发双花、5秒假视频、死种或垃圾大文件塞爆磁盘 | 部署六重安全风控体系（TMDB 季集互斥锁、FFprobe 深度质检、后置原子结算、磁盘15%熔断）（详见 `references/lemon-emos-crowdsource-architecture.md`） |
| **EMOS 资源上传报未能自动识别** | 纯罗马音/外文资源文件名未命中 EMOS 库内中文条目 | 在上传器中接入 TMDB 自动双语解析与中文译名桥接（详见 `references/emos-uploader-identify-fix.md`） |

---

## 方案一：Cloudflare Worker 原生零流量直连（最推荐）

当使用基于 Cloudflare Worker 的多节点代理（如玛卡巴卡 / MakkaPakka）时，直接在 Worker 的 `fetch` 入口拦截特殊路由，**实现 0 消耗 VPS 流量与全功能原生支持**。

### 移动 (CMCC) 优选与代码混淆机制
1. **中国移动 (CMCC) 优选特性**：
   - 移动骨干网对 Cloudflare 官方移动友好段（如 `104.16.160.25`、`104.19.24.45`、`162.159.192.x`、`162.159.193.x`）直连延迟与丢包率极低。
   - 当在 Cloudflare 上配置优选 DNS（泛解析或固定 A 记录如 `fd.586934.xyz`）时，客户端可直接通过移动优选 IP 建立 TLS/SNI 连接访问 Worker。
2. **生产环境代码混淆最佳实践**：
   - 在部署前对上游目标地址、专属鉴权请求头（`EMOS-PROXY-ID`/`NAME`）、`/Items/Counts` 拦截与 `PlaybackInfo` 重写逻辑进行变量混淆与十六进制字符串转义（如 `\x75\x72\x6c`、`\x2f\x65\x6d\x6f\x73`），防止明文泄露关键鉴权凭证。

### Worker 终极补丁代码片段（注入于 `async fetch(request, env, ctx)` 入口）：

```javascript
// 🌟 EMOS 专属超能流媒体直通引擎 (解决 403 播放、路径丢失与 Counts 注入)
try {
    const _reqUrl = new URL(request.url);
    const _isEmos = _reqUrl.pathname.startsWith('/emos');
    const _isDirectMedia = !_isEmos && (_reqUrl.pathname.startsWith('/emby/videos/') || _reqUrl.pathname.startsWith('/videos/') || _reqUrl.pathname.startsWith('/emby/Audio/') || _reqUrl.pathname.startsWith('/Audio/'));
    
    if (_isEmos || _isDirectMedia) {
        // 1. 拦截媒体库数量，点亮播放器卡片 (解决显示 0 的问题)
        if (_reqUrl.pathname.endsWith('/Items/Counts')) {
            return new Response(JSON.stringify({
                MovieCount: 18450,
                SeriesCount: 4120,
                EpisodeCount: 118600,
                SongCount: 56800,
                AlbumCount: 3200,
                MusicVideoCount: 150,
                BoxSetCount: 680,
                BookCount: 0,
                ItemCount: 141170
            }), {
                status: 200,
                headers: {
                    'Content-Type': 'application/json; charset=utf-8',
                    'Access-Control-Allow-Origin': '*'
                }
            });
        }

        // 2. 剥离 /emos 前缀并对齐 /emby 路径
        let _subPath = _reqUrl.pathname.replace(/^\/emos/, '');
        if (!_subPath.startsWith('/emby') && !_subPath.startsWith('/rest')) {
            _subPath = '/emby' + _subPath;
        }
        if (_subPath === '/emby' || _subPath === '/emby/') {
            _subPath = '/emby/System/Info/Public';
        }
        const _targetUrl = 'https://video.emos.best' + _subPath + _reqUrl.search;

        // 3. 构建携带 EMOS 专属凭证与标准 UA 的新请求
        const _newHeaders = new Headers(request.headers);
        _newHeaders.set('Host', 'video.emos.best');
        _newHeaders.set('EMOS-PROXY-ID', 'eK981JREMs');  // 替换为实际 UID
        _newHeaders.set('EMOS-PROXY-NAME', 'naye');     // 替换为实际称号
        if (!_newHeaders.get('User-Agent')) {
            _newHeaders.set('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36');
        }

        const _fetchInit = {
            method: request.method,
            headers: _newHeaders,
            redirect: 'manual' // 关键！禁止 Worker 自动跟随，避免携带错误 Host 请求 R2 直链导致 403
        };

        if (!['GET', 'HEAD'].includes(request.method)) {
            _fetchInit.body = request.body;
        }

        const _upstreamResp = await fetch(_targetUrl, _fetchInit);

        // 4. 关键修复：拦截 PlaybackInfo 并动态重写流媒体 URL，给内部路径注入 /emos 前缀
        if (_reqUrl.pathname.includes('/PlaybackInfo') && _upstreamResp.status === 200) {
            let _respText = await _upstreamResp.text();
            _respText = _respText.replaceAll('"/emby/videos/', '"/emos/emby/videos/')
                                 .replaceAll('"/emby/Audio/', '"/emos/emby/Audio/')
                                 .replaceAll('"/emby/hls/', '"/emos/emby/hls/');
            
            const _pHeaders = new Headers(_upstreamResp.headers);
            _pHeaders.set('Access-Control-Allow-Origin', '*');
            _pHeaders.set('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
            _pHeaders.set('Access-Control-Allow-Headers', '*');
            _pHeaders.set('Content-Type', 'application/json; charset=utf-8');
            return new Response(_respText, {
                status: 200,
                headers: _pHeaders
            });
        }

        // 5. 常规媒体流与 API 响应透传 (支持 CORS 与 302 重定向)
        const _respHeaders = new Headers(_upstreamResp.headers);
        _respHeaders.set('Access-Control-Allow-Origin', '*');
        _respHeaders.set('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
        _respHeaders.set('Access-Control-Allow-Headers', '*');

        if ([301, 302, 307, 308].includes(_upstreamResp.status)) {
            const _loc = _upstreamResp.headers.get('Location');
            if (_loc && _loc.startsWith('/')) {
                _respHeaders.set('Location', '/emos' + _loc);
            }
        }

        return new Response(_upstreamResp.body, {
            status: _upstreamResp.status,
            statusText: _upstreamResp.statusText,
            headers: _respHeaders
        });
    }
} catch (_emosErr) {}
```

---

## 方案二：独立 VPS Nginx 高性能反代规范模板

适用于在独立 Linux VPS / Docker 容器中搭建专属 Emby 网关。

```nginx
# 1. 播放进度节流 (防高频心跳冲击)
limit_req_zone $binary_remote_addr zone=emos_progress:10m rate=2r/s;

# 2. 静态图片本地强缓存区 (1GB 空间, 7天不过期)
proxy_cache_path /var/cache/nginx/emos_cache levels=1:2 keys_zone=emos_cache:20m max_size=1g inactive=7d use_temp_path=off;

map $http_user_agent $final_ua {
    default $http_user_agent;
    ""      "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36";
}

server {
    listen 8096;
    server_name _;

    client_max_body_size 100M;
    proxy_connect_timeout 60s;
    proxy_send_timeout 120s;
    proxy_read_timeout 120s;

    # 公共反代请求头
    proxy_set_header Host $proxy_host;
    proxy_set_header X-Real-IP $remote_addr;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    proxy_set_header X-Forwarded-Proto $scheme;
    proxy_set_header User-Agent $final_ua;
    
    # 专属认证头
    proxy_set_header EMOS-PROXY-ID "eK981JREMs";
    proxy_set_header EMOS-PROXY-NAME "naye";

    # WebSocket 支持
    proxy_http_version 1.1;
    proxy_set_header Upgrade $http_upgrade;
    proxy_set_header Connection $http_connection;

    # 1. 播放器卡片媒体数量注入 (解决卡片显示 0 的问题)
    location ~* ^/(emby/)?Items/Counts$ {
        default_type application/json;
        add_header Content-Type "application/json; charset=utf-8";
        add_header Access-Control-Allow-Origin *;
        return 200 '{"MovieCount":18450,"SeriesCount":4120,"EpisodeCount":118600,"SongCount":56800,"AlbumCount":3200,"MusicVideoCount":150,"BoxSetCount":680,"BookCount":0,"ItemCount":141170}';
    }

    # 2. 播放进度上报节流
    location ~* ^/(emby/)?Sessions/Playing/Progress {
        limit_req zone=emos_progress burst=5 nodelay;
        proxy_pass https://video.emos.best;
        proxy_ssl_server_name on;
    }

    # 3. 封面与剧照图片强缓存
    location ~* ^/(emby/)?Items/.*/Images/.* {
        proxy_cache emos_cache;
        proxy_cache_valid 200 7d;
        proxy_cache_valid 404 1m;
        proxy_cache_use_stale error timeout updating http_500 http_502 http_503 http_504;
        add_header X-Cache-Status $upstream_cache_status;

        proxy_pass https://video.emos.best;
        proxy_ssl_server_name on;
    }

    # 4. 206 Range 视频流直通配置
    location / {
        proxy_pass https://video.emos.best/emby/;
        proxy_ssl_server_name on;

        proxy_set_header Range $http_range;
        proxy_set_header If-Range $http_if_range;

        # 禁用缓冲，随下随播
        proxy_buffering off;
        proxy_request_buffering off;
    }
}
```

---

## 方案三：全新 VPS 极简 Nginx 直代 7 步落地 SOP（多端口矩阵与 NAT 小鸡直连）

适用于刚开通的全新 Ubuntu/Debian/Alpine VPS 或 NAT 落地小鸡，无需 Docker 或代理，直接跑原生 Nginx 反代加速 Emby/EMOS，与现有美国 VPS / CF Worker 双轨并存。详见 `references/clean-vps-nginx-emby-7steps.md` 与 `references/nat-vps-emby-dual-line.md`。

### 1. 标准极简单服配置 (`/etc/nginx/conf.d/emby.conf` 或 Alpine `/etc/nginx/http.d/emos.conf`)
```nginx
# 极简轻量缓存区 (适用 512M/1G 内存 NAT 小鸡，防爆内存与磁盘)
proxy_cache_path /var/cache/nginx/emos_cache levels=1:2 keys_zone=emos_cache:5m max_size=50m inactive=1d use_temp_path=off;

server {
    listen 18096; # 或 NAT 外部映射端口如 34474
    listen [::]:18096;
    server_name _;

    client_max_body_size 100M;
    proxy_connect_timeout 15s;
    proxy_send_timeout 3600s;
    proxy_read_timeout 3600s;

    # 1. 播放器卡片媒体数量注入 (双路径兼容 /Items/Counts 与 /emby/Items/Counts)
    location ~* ^/(emby/)?Items/Counts$ {
        default_type application/json;
        add_header Content-Type "application/json; charset=utf-8";
        add_header Access-Control-Allow-Origin *;
        add_header Access-Control-Allow-Methods "GET, POST, OPTIONS";
        add_header Access-Control-Allow-Headers "*";
        return 200 '{"MovieCount":18450,"SeriesCount":4120,"EpisodeCount":118600,"SongCount":56800,"AlbumCount":3200,"MusicVideoCount":150,"BoxSetCount":680,"BookCount":0,"ItemCount":141170}';
    }

    # 2. 封面与剧照图片轻量本地缓存 (毫秒级瀑布流加载)
    location ~* ^/(emby/)?Items/.*/Images/.* {
        proxy_cache emos_cache;
        proxy_cache_valid 200 1d;
        proxy_cache_valid 404 1m;
        proxy_cache_use_stale error timeout updating http_500 http_502 http_503 http_504;
        add_header X-Cache-Status $upstream_cache_status;

        proxy_pass https://video.emos.best;
        proxy_ssl_server_name on;
        proxy_http_version 1.1;
        proxy_redirect off;

        proxy_set_header Host video.emos.best;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_set_header EMOS-PROXY-ID "eK981JREMs";
        proxy_set_header EMOS-PROXY-NAME "naye";
    }

    # 3. 核心 API 与 206 视频流极速直通
    location / {
        proxy_pass https://video.emos.best;
        proxy_ssl_server_name on;
        proxy_http_version 1.1;
        proxy_redirect off;

        # WebSocket 实时通信支持
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection $connection_upgrade;

        proxy_set_header Host video.emos.best;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;

        # 专属身份鉴权头
        proxy_set_header EMOS-PROXY-ID "eK981JREMs";
        proxy_set_header EMOS-PROXY-NAME "naye";

        # 206 Range 分片透传 (随下随播、拖拽不卡)
        proxy_set_header Range $http_range;
        proxy_set_header If-Range $http_if_range;

        # 禁用缓冲
        proxy_buffering off;
        proxy_request_buffering off;
    }
}
```

### 2. 一键极速验收闭环指令
```bash
nginx -t && systemctl reload nginx && ss -lntp | grep ':18096 ' && curl -I --connect-timeout 10 http://127.0.0.1:18096
```

### 3. 多 Emby 多端口矩阵扩展
- `18096` -> Emby 服 A (`/etc/nginx/conf.d/emby-18096.conf`)
- `18097` -> Emby 服 B (`/etc/nginx/conf.d/emby-18097.conf`)
- `18098` -> Emby 服 C (`/etc/nginx/conf.d/emby-18098.conf`)

### 4. 极速 3 步排障索引
1. **502 Bad Gateway**：`curl -I --connect-timeout 10 https://你的Emby地址`（排查 VPS 到上游）。
2. **本机通但公网打不开**：`curl -I http://127.0.0.1:18096` 正常时排查 UFW 防火墙与云厂商安全组（EC2 SG 等）。
3. **查 Nginx 错误日志**：`tail -n 30 /var/log/nginx/error.log`。

---

## 验证与验收指令

```bash
# 1. 验证公共系统信息接口
curl -s https://<反代域名>/<前缀>/System/Info/Public -I

# 2. 验证卡片数量是否点亮 (非0)
curl -s https://<反代域名>/<前缀>/Items/Counts | jq .

# 3. 验证 206 Range 视频分片响应
curl -s -I -H "Range: bytes=0-1024" https://<反代域名>/<前缀>/emby/System/Ping
```

---

## 避坑与运维准则 (MakkaPakka & Cloudflare 双轨)

1. **多节点/多链路独立共存准则（严禁覆盖或撤销已有主力节点）**：
   - 当引入新机型/新地区节点（如新增香港 NAT 小鸡）时，必须以**“新增独立链路/独立二级域名”**形式落地，绝不修改、覆盖或撤换原有的主力反代链路（如已有美国 VPS、原面板直连）。
   - 播放器客户端支持添加多个独立服务器，双轨/多轨并行可实现多网络容灾与灵活切换。
2. **NAT 小鸡反代源站真实 IP 隐匿规范（Cloudflare CDN 代理）**：
   - 严禁在客户端直连中暴露小鸡真实公网 IP。
   - 隐匿方案：配置专属二级域名（如 `hk.domain.com`）解析至小鸡 IP，并在 Cloudflare 开启代理（橙色小云朵）；由于 Cloudflare 免费版只代理标准 HTTPS 端口（如 `443`, `2053`, `2083`, `2087`, `2096`, `8443`），在 NAT 小鸡上可通过对应映射端口监听，客户端连接 `https://hk.domain.com:<CF支持端口>`，实现 100% 隐藏真实 IP + 全网 CDN 加速。
3. **Alpine Linux (OpenRC) 极轻量 NAT 小鸡环境极速部署**：
   - Alpine 下使用 `apk add nginx`，配置文件置于 `/etc/nginx/http.d/*.conf`。
   - 内存占用极低（<15MB），非常适合 512MB~1GB 内存的低配小鸡，配合 `proxy_buffering off` 即可提供高达千兆的流媒体转发吞吐。
4. **EMOS 架构与视频直链重定向（308/302 直通 R2 存储桶）**：
   - 真实架构为 `Worker 反代面板 ➡️ VPS Nginx 容器 ➡️ EMOS 官方`。
   - EMOS 官方 PlaybackInfo 返回视频直链（如 `/emos/emya/video?server=emos&media_id=...`），请求后会 308/302 重定向至 R2 存储桶直链（如 `https://emoss.eeew.eu.org/...`）。
   - **核心避坑**：
     ① VPS Nginx 必须配置 `proxy_redirect off;`，严禁二次拼接 `/emos/` 导致路径损坏报错 5XX/404。
     ② Worker 端代理外部真实 CDN 直链时，必须剥离 `Host`、`EMOS-PROXY-ID` 与 `EMOS-PROXY-NAME`，防止 R2 存储桶抛出 403/502。
2. **403 播放拒绝规避与最新流媒体路由**：
   - EMOS 最新 2026 流媒体 API 架构采用了 `/emya/video?server=emos&media_id=...` 独立视频流路径，反代层必须同时捕获并放行 `/emya/`，严禁遗漏。
   - `PlaybackInfo` 重写流媒体路径时，若 302 重定向返回的是指向 R2 对象存储的绝对直链（`https://...`），严禁拼接 `/emos` 前缀，必须保持原样透传防止 R2 鉴权签名失效报错 403。
   - 对于基于 D1 动态路由的面板（如 MakkaPakka），严禁在 Worker 入口将所有流量劫持为单一写死的账号请求头，必须采用 D1 原生动态代理以保证客户端真实 Session/Token 正常握手。
3. **API Token 权限隔离**：
   - 部署 Worker / 绑定 Custom Domains 需要 `Workers:Edit` 权限 Token。
   - 面板内部“测速与 DNS”模块修改 A 记录需要 `Zone.DNS:Edit` 权限 Token。bindings 中的 `CF_API_TOKEN` 必须配置具备对应 DNS 权限的 Token 避免报获取 DNS 失败。
4. **分流加速 DNS 维护**：
   - 电信优选域名（如 `fd.586934.xyz`）：优选 `104.18.226.52`、`104.18.185.26`、`172.67.180.1`。
   - 移动优选域名（如 `yd-fd.586934.xyz`）：优选 CMI 黄金段 `162.159.192.1`、`162.159.193.1`、`104.19.24.45`。
   - 避免在测速后写入大量含丢包/高延迟的杂乱 Anycast 节点，保持 DNS A 记录精简。
5. **Worker 路由与优选域名 Connection Reset 规避**：
   - 在 DNS 中新增优选子域名时，必须在 Cloudflare Zone 的 `Workers Routes` 中添加对应的 `*.domain.com/* -> Worker` 规则，否则 Anycast 边缘找不到接管 Worker 会直接重置 TCP 连接。
6. **Cloudflare 隐藏真实 VPS 源站 IP 与端口映射（HTTPS 2053）**：
   - 使用 VPS Nginx 进行流媒体与内存加速时，若不希望暴露 VPS 真实公网 IP，可在 Cloudflare 将域名开启代理（小黄云 `proxied: true`）。
   - 播放器客户端默认偏好 HTTPS，Nginx 必须配置 SSL 证书并在 Cloudflare 允许的 HTTPS 端口（如 `2053` 或 `8443`）监听，客户端统一填入 `https://vps.586934.xyz:2053`，实现全网三大运营商智能 CDN 调度并 100% 隐匿源站 IP。
7. **播放器 Session 切换机制**：
   - 当服务端反代地址或端口变更后，若客户端提示 `Expired`（过期），要求用户退出账号并重新输入密码登录即可完成握手。
8. **专属小鸡 / 亚太 VPS 前置机极致加速选型与架构**：
   - **核心原理**：国内到香港/新加坡物理延迟仅 15ms~30ms，小鸡到 Cloudflare R2 存储桶 1ms~2ms 内网互联。
   - **选购要点**：认准【中国香港 CMI / BGP 优化】（如 HostYun EQ-CMI、ByteVirt NAT、Shlii 等），配置只需 1核 512MB/1GB 即可跑满 4K。
   - **隐私保护**：通过专属域名（如 `emby.domain.com`）绑定并配置 Let's Encrypt / 自签名 SSL，配合 Nginx UA/Path 白名单隐藏源站特征。
   - **Shlii (shlii.io) 选型实战**：首选 `HKVIA-电移神机`（ID: 771，电信移动双网优化）、`HK三网优化大带宽`（ID: 532）或 `HK 狗妈奶爸 1`（ID: 1），提供极低延迟与大带宽。
9. **启播速度天花板最佳实践（代理分流 vs 直连）**：
   - 对于支持代理的客户端/软路由，直接将 Emby 域名（如 `zjw.586934.xyz` / `emos.best`）分流至优质香港/新加坡专线节点，往返握手延迟降至 20ms~30ms，无需自建小鸡即可实现 4K 原画秒开。
10. **Cloudflare Worker Bindings 环境变量星号脱敏覆写风险**：
   - **问题现象**：定时 Cron 触发器执行正常，但 Telegram 每日播报或 Webhook 通知突然静默失败。
   - **根本原因**：通过 Cloudflare REST API 读取已部署 Worker 的 `bindings` 时，Cloudflare 针对所有 `plain_text` 或敏感变量自动返回截断/脱敏值（如 `8921369747:***`）。若后续发布脚本或热更新代码时直接读取该 JSON 并作为 `metadata.bindings` 上传，会将带星号的无效 Token 永久写回生产环境，导致调用 `https://api.telegram.org/bot<TOKEN>/sendMessage` 返回 404/401。
   - **防范规范**：
     ① 环境变量配置文件（如 `.env` / 本地真实 JSON）必须作为唯一的权威凭证源，严禁将 Cloudflare API 导出的 bindings 反向导入生产发布管线；
     ② 部署脚本中增加强校验：`assert '***' not in token, 'Error: Masked token detected in bindings!'`。

