---
name: emby-proxy-ops
description: Emby 反向代理与多节点网关运维：EMOS 私有鉴权、Worker 补丁、206 视频流与卡片统计注入。
version: "1.0.0"
author: "Hermes Agent"
license: "MIT"
metadata:
  hermes:
    tags: ["emby", "proxy", "cloudflare-workers", "emos", "nginx", "media-server"]
    related_skills: ["pt-site-ops", "cliproxyapi"]
---

# Emby 反向代理与多节点网关运维指南

用于配置、优化与排障各类 Emby 媒体服务器反向代理（包括标准公开服、带私有网关鉴权的 EMOS 等专属服，以及基于 Cloudflare Worker 的多节点反代面板如 MakkaPakka / 玛卡巴卡）。

## 当前部署拓扑档案（基线，变更后须同步本表）

| 项 | 值 |
|---|---|
| 面板 | MakkaPakka / 玛卡巴卡 |
| 电信优选域名 | `<PRIVATE_IDENTIFIER>` |
| 移动优选域名 | `<PRIVATE_IDENTIFIER>` |
| Worker 名 | `mute-king-08a5` |
| Worker cron | `0 14 * * *` |
| Worker 凭据类型 | 全部 `secret_text`；本机副本 `/home/ubuntu/cf-worker-backup/bindings.json` |
| 上游中转 | 经 LA VPS 中转 `video.emos.best` |
| 香港加速节点 | Hytron NAT（`vps-hk`），独立加速节点 |
| 港 NAT 端口映射 | SSH 30023、SOCKS5 30033、TG-MTProto 30034、哪吒 34474（详见 `references/nat-vps-emby-dual-line.md`） |
| 直连规则门户入口 | **`https://rules.<PRIVATE_IDENTIFIER>/...`（标准 443，CF Tunnel `lemon-rules-la-*`）**；旧入口 `la.<PRIVATE_IDENTIFIER>:2096` 保留可用 |
| 规则门户后端 | vps-la `/opt/emby-rules-{portal,friend}/`，`127.0.0.1:39087` / `:39088`；订阅出 **Loon / Surge / QX / Clash** 四格式（`/rules-sub/<SUB_TOKEN>/<file>`），见 `references/emby-direct-rules-portal-ops.md` |

> 维护原则：拓扑事实以本表 + `references/` 为准，不要在会话记忆里维护第二份；改动拓扑后先更新本表再动配置。

## 凭据复用与只读准备原则

- 用户要求继续快照或部署准备时，先核对已授权的本机凭据来源，不因脚本要求的环境变量未设置就要求用户新建或重发 Token。`CF_DEPLOY_TOKEN` 等名称只是脚本输入约定，不代表一种新的凭据。
- **【已验证】** `/home/ubuntu/cf-worker-backup/bindings.json` 的 `CF_API_TOKEN` 字段（`plain_text` 类型）可在同一 Python 进程内读取并传给 snapshot/upload 例程，无需用户重新提供或 export。`os.environ` 为空不等于凭据缺失，正确顺序：① 检查 `bindings.json` 对应字段非空且非脱敏占位值 → ② 同进程内使用 → ③ 进程结束后清除。三步均失败才向用户求助。
- **⚠️ 常见错误：** 检查 `os.environ` 为空就直接告知用户"需要提供 Token"，这是错的，会造成不必要的打扰和等待。
- 定向检查已知项目配置或受保护备份，只输出凭据是否存在、字段名及类型；不打印值，不递归扫描整个主目录。历史备份中的凭据可能已失效，存在不等于可用，更不能把 API 脱敏占位值当作令牌。
- 优先在同一短生命周期进程内读取已有凭据并传给只读快照例程，不把秘密放进命令行、聊天或日志。用户在另一 SSH shell 中 export 的变量不会自动进入已运行的代理工具进程；不要让用户仅 export 后回报“已注入”就假定可见。
- 以目标 Worker 的实际 GET 请求验证所需读取权限；成功只证明该读取操作可用，不证明拥有部署权限。遇到明确权限拒绝停止重复尝试，报告缺失范围。
- 准备阶段可在请求函数边界强制只允许 GET；离线组包阶段强制禁止全部网络调用。新鲜快照须重新验证哈希与私有权限，再分别验证候选和回滚组包。严格区分只读准备完成与生产部署完成。

## When to Use
- **排查「我之前弄的 XX 网站打不开了」（自建小门户/规则管理页）**：先按站点归属分流，别默认它跟主力机一起迁移了。Emby 直连规则门户在 **vps-la** `/opt/emby-rules-{portal,friend}/`（39087/39088），全套地址/Token/排障见 `references/emby-direct-rules-portal-ops.md`。
- **给规则门户增加其他客户端格式（Loon / Surge / Quantumult X / Clash）**：数据层只存裸规则、渲染层按客户端注入策略；**Loon 输出必须保持字节不变**（老订阅不能动）。四种格式的逐字符语法（QX 的 `host-suffix` 小写 + `ip6-cidr`、Clash 的 `rule-provider` classical + `no-resolve`）、路由查表设计与上线流程见 `references/emby-direct-rules-portal-ops.md` §多客户端规则格式输出。
- **手机打开报 `errors.edgesuite.net` / `http://[No Host]/...`**：这是 Akamai 通用错误页，说明请求以**明文 HTTP + 丢失 Host** 撞上了运营商/中间设备，**不是源站故障，也不是用户开了代理软件**。根因是 **CF 非标端口（2096 等）被国内网络阻断**，唯一可靠解法是把入口搬到标准 443（Cloudflare Tunnel + 独立子域，不动 nginx/xray）。完整落地与踩坑见 `references/emby-direct-rules-portal-ops.md`。
- **解释 Emby 鉴权/越权验证脚本**：只读审阅实际代码，区分脚本意图与可证实结果；默认不对真实服执行探测。详见 `references/emby-token-exchange-script-review.md`。
- **配置与优化 Emby 反代**：通过 Nginx 或 Cloudflare Worker 反代 Emby 媒体服务器。
- **排障 Emby 客户端 404 / 403 报错**：解决因上游 `/emby` 子路径缺失或 Header 鉴权不足导致的拒绝访问。
- **修复播放器卡片媒体数量显示为 0**：解决 SenPlayer / VidHub / Fileball 无法获取媒体统计的问题。
- **解决视频播放拖动卡顿与分片问题**：正确配置 206 Partial Content、Range 头部透传与媒体流无缓冲。
- **实现 Cloudflare Worker 0 流量消耗直连**：在多节点反代面板（如玛卡巴卡）中注入专属鉴权逻辑，绕过 VPS 中转。
- **审计/排障已混淆的生产 Worker**：拉取真实生产代码、还原混淆字符串表读懂内部逻辑、md5 三方比对确认补丁是否真的上线 —— 见 `references/worker-deobfuscation-and-tg-verification.md`。
- **只读 AST 定位混淆 Worker 的代理热路径**：用 Acorn 节点范围区分外层 wrapper 与对象内真实 `fetch` 方法，定位 Request/DB、重试循环、redirect 和最终 Response；详见 `references/obfuscated-worker-ast-audit.md`。先从线上只读拉取当前 multipart Worker 源码，记 UTC 时间与 SHA-256；用同哈希 artifact 做 AST/锚点分析。不要把外层 HTML wrapper 当实际代理入口。审查包应列明在线源码、历史对照、未完成草稿的来源，提供实际 diff/测试命令/依赖，并排除 bindings、数据库和凭据；硬编码秘密扫描若未命中，不做无必要源码替换。
- **Cloudflare Worker Upload API 的安全补丁部署准备（可延伸到升级/回滚）**：单独创建快照、组包、离线 multipart 往返校验和回滚流程，不调用会重建代码的生命周期 deploy 脚本；文档、脚本与验证须按 `references/cloudflare-worker-keep-bindings-deploy.md` 执行。重点：先读当前官方 Upload API 对 `metadata.keep_bindings` 的定义；只把当前存在且 API 支持的 binding type 放进 keep list，包含 `secret_text`、D1 等；绝不把 bindings API 脱敏响应当成待上传的明文配置。fresh snapshot 必须记录 Worker 源码、bindings 名称/类型、settings、Cron schedules，并设私有权限；上传前重新比对源码哈希和配置基线。设置如 Cron 需通过独立 API 快照/恢复。默认把任何诊断开关保持关闭。离线解析 multipart，证明模块字节、metadata、`keep_bindings` 与配置均符合预期；该验证不等于生产上传。
- **玛卡巴卡面板只读审计与一键部署规划**：真假双实例（单 Worker 多域名双轨 vs 物理多实例）四维交叉验证、D1/Bindings 独立与共用划分、构建期 AST 混淆安全红线 —— 详见 `references/makkapakka-audit-and-one-click-deploy-spec.md`。
- **修复 Telegram 定时播报静默失败**：脱敏 Token 覆写排查、`secret_text` 根治、以及「逼生产环境自证」的硬证据验证法 —— 见同一份 reference；安全重部署直接跑 `scripts/redeploy_worker_bindings.py`。
- **改动 EMOS/自研中间层反代前的行为探测**：`/emya/` 前缀策略、`/Items/Counts` 能否动态透传、疑似废弃 DNS/节点的去留判定、CF Token 权限矩阵 —— **改配置前必读** `references/emos-instance-probing-and-gray-deploy.md`。
- **MakkaPakka/EMOS 升级后的只读验收与 Worker 热路径审计**：验证授权登录后的搜索、媒体库列表与 Counts，区分固定兼容占位值和真实数据；解码审查每请求重复的 D1 schema 检查，并提出保留实时鉴权、节点读取及 Range/206 的最小优化 —— 详见 `references/readonly-acceptance-and-schema-hotpath.md`。
- **正在真实播放时诊断启播慢/EMOS 流量**：先确认播放实际经过的线上链路和当前有效日志源，再关联真实请求；区分本机日志为空与远端没有流量。分阶段量 PlaybackInfo、重定向、首字节、传输、重试/重复请求；不得用普通接口探测替代实际启播耗时。Cloudflare Worker 的 `/tail` GET 可能返回 Worker 源码，并非事件流；核对 `tail_consumers` 与受支持的事件采集路径。日志不足时报告具体观测缺口并提出最小脱敏计时方案，不得重放受保护请求或暴露签名链接 —— 详见 `references/live-playback-telemetry.md`。**⚠️ 实战教训：media_direct=0 不等于无播放，很可能是视频流走 VPS 直连绕过了 Worker——此时 Worker 日志只能看到 PlaybackInfo 和进度汇报，媒体字节完全不经过 Worker，启播慢的根因在 VPS 中转链路而非 Worker 代码。确认中转节点地理位置是首要诊断步骤。302 直连只适用于 Emby 服务器由自己控制的场景；第三方 EMOS 服不适用（会暴露目标 IP 且无法控制）。**
- **容器内 Nginx 配置灰度上线**：备份 → 一次性容器预检 → 基线 → reload → 回归 → 失败自动回滚，直接跑 `scripts/nginx-gray-deploy.sh`（先 `--dry` 预检）。
- **低配/廉价 VPS 自建 Emby 专属小服可行性与防爆审计**：内存 <2G、磁盘 <20G、月流量受限（AWS 100G vs 美机 5TB）等条件下的选型底线、防爆磁盘（BIF/缩略图全禁）、防爆 CPU（转码全禁/客户端硬解）与 GDrive/Rclone 调优 —— 详见 `references/low-spec-vps-emby-hosting-checklist.md`。
- **Foam 类闭源 Emby 运营管理系统逆向评估与自研复刻**：解构 Docker 镜像脱壳与 License 锁风险，基于 Emby REST API（用户生命周期/库权限/到期巡检/多服同步）与 Telegram Bot 闭环自建专属运营体系 —— 详见 `references/foam-emby-panel-architecture-and-recreation.md`。
- **规划多节点上传集群 / 接入第三方众包上传站（Cloudreve 系）**：先把「上行带宽、磁盘余量、可用窗口」三个数实测出来再谈分工，别凭机器规格猜；含 Cloudflare 测速端点与单连/多并发限速判别、Cloudreve 端点真假判别（`/webdav` 返回 200 + HTML 是 SPA 兜底，不是 WebDAV）、WebDAV 独立密码坑、免费沙箱 8 小时窗口对断点续传的强制要求 —— 见 `references/multi-node-upload-cluster-planning.md`。
- **上传吞吐上不去 / 怀疑机器不够用**：先 `grep ThreadPoolExecutor` 核对**线上副本**是否已并发化（技能里记载的修复 ≠ 已部署）；实测串行分片只有 8.01 MB/s（链路 31.9 MB/s），**先并发化再谈加机器**。另含「中断上传会烧掉该资源一周额度」「`/api/identify` 的 guessit 404 不代表链路坏」「上传流式读盘不占缓冲盘」四条硬坑 —— 见 `references/multi-node-upload-cluster-planning.md` §4.1/§4.2 与 `references/emos-uploader-identify-fix.md` §8。
- **动手把 EMOS 上传器改成并发分片（含验证与上线）**：三个必守不变量（`parts` 按 number 显式排序、每线程自己 open+seek 防串片、每线程独立 Session）、fail-fast 与进度锁、离线验证夹具、**不污染库的测速法（跑完 abort 而非中途 kill）**、以及「生产副本硬编码凭据 / 仓库副本走环境变量」时的凭据注入式部署 —— 见 `references/emos-uploader-parallel-partition.md`，验证直接跑 `scripts/verify_emos_parallel_upload.py`。实测 5 并发 29.96 MB/s（3.74x，已跑满 31.9 MB/s 链路），默认 5 上限 8，再加线程无收益。
- **Telegram Bot 运维面板新增上传通道设置页**（`lemon-ops-bot`架构）：设置页模式（线程数选择 + 实测测速按钮），配置写入 `emos_config.json` 的 `upload_config` 节点，调度端自动读配置注入 `EMOS_UPLOAD_WORKERS` 环境变量。部署详见 `references/emos-uploader-identify-fix.md` §10；测速脚本 `/root/emos_speedtest.py`（abort 不入库）。
- **Cloudreve V3 WebDAV 独立密码坑**：新站 `<YOUR_PRIVATE_DOMAIN>` / `oss-ca.ftp2.eu.org/dav/`，WebDAV Basic Auth 不接受登录密码，需在「设置→WebDAV」单独生成 WebDAV 专用密码。401 响应不带 `WWW-Authenticate` 头（openresty 后端自定义拦截），字符穷举无效。接通后推荐 `rclone :webdav:` 方式（断点续传 + 校验）。详见 `references/emos-uploader-identify-fix.md` §11。

> ⚠️ **本技能的路径/前缀/接口结论均为「某实例实测值」，不是通用规范。** EMOS 类自研中间层
> （`System/Info/Public` 返回 `ServerName=emos, Id=emya, Version=1.0.0`）只实现了 Emby API 子集，
> 行为因实例而异且与官方 Emby 语义不一致。**动手改配置前先按 reference 跑探测，实测优先于本文任何断言。**

---

## 核心应用场景与排障索引

| 问题现象 | 根本原因 | 解决方案 |
| :--- | :--- | :--- |
| **面板报 `⚠️ 读取失败: Can't find variable: Sortable` (或节点列表全变红报错)** | 前端依赖 `cdn.jsdelivr.net` 加载 Sortable.js / Chart.js，国内网络遭遇 DNS 污染或阻断导致 `Sortable` 未定义；`load()` 渲染后直接调用 `Sortable.create()` 抛错触发外层 catch 抹除已渲染节点 | ① 在前端调用前增加防御判空：`typeof Sortable !== 'undefined'` 与 `typeof Chart !== 'undefined'`，确保 CDN 异常时优雅降级（仅禁用拖拽排序/图表），绝不阻塞节点展示与配置；② 静态资源改用国内镜像（如 BootCDN）并配 `cdnjs` / `jsdelivr` 多源降级容灾 |
| **客户端报 404 Not Found** | 目标路径漏了 `/emby`，或反代末尾斜杠导致 URL 拼接错误 | 统一对齐 `/emby` 前缀；配置重写确保无 `/emby` 请求自动回退到 `/emby/` |
| **客户端报 403 Forbidden** | ① 上游强制要求认证请求头（如 `EMOS-PROXY-ID`）或空 UA 触发 Cloudflare 质询；② 自定义 Worker 入口硬编码写死单一账号凭据导致流媒体请求与客户端真实 Session 冲突 | 在反代层动态透传客户端 Header；对于多节点/多用户面板（如 MakkaPakka），采用 D1 原生动态代理路由，严禁写死静态账号凭据 |
| **视频播放报 403 / 404 / 卡死** | ① EMOS 最新 2026 流媒体 API 架构采用了 `/emya/video?server=emos&media_id=...` 独立视频流路径，反代层若未捕获或错误拼接 `/emby` 会返回 `404: Node not found`；② 播放器内核向根路径发起未带前缀的 `/emby/videos/...` 或大小写不一致的 `/Videos/...` 请求导致未命中鉴权；③ Worker 跟随 302 时将 `Host` 传给 R2 存储桶抛出 403；④ 302 重定向到 R2 绝对链接时错误拼接了 `/emos` 前缀导致 R2 签名失效报错 403 | ① `/emya/video` 的前缀策略**必须实测判定，严禁照抄**：部分实例需剥离前缀直连 `https://video.emos.best/emya/video`，另一些实例（自研中间层）**恰恰需要保留 `/emby` 前缀**，剥离后 404。用三路差分诊断（上游直连 vs 经反代 vs 故意拼前缀）定位，详见 `references/emos-instance-probing-and-gray-deploy.md`；② 拦截 `PlaybackInfo` 响应并对所有音视频路径（`/Videos/`、`/videos/`、`/emya/`、`/Audio/`、`/audio/`、`/hls/`）强制重写注入前缀；③ 在 Worker 入口做全局流媒体兜底捕获；④ 设置 `redirect: 'manual'` 透传 302 直链，仅当 Location 为相对路径时拼接前缀，绝对路径原样透传 |
| **404 分不清是「上游真实答案」还是「反代路由缺失」** | 单个 404 无法区分二者，凭它改路由极易改错方向（本次照文档剥离 `/emya` 前缀反而把通的链路改坏） | 三路差分：A=上游直连 / B=经生产反代 / C=故意拼前缀。判读：`401`/`403` 比 `404` 更「深」（说明命中路由只是没过鉴权）；B==C 且都比 A 深 ⇒ 该实例需要前缀；空 body + `server: cloudflare` 的 404 是 CF 边缘 404（路由不存在），非应用 404（资源不存在） |
| **播放器卡片媒体数量显示为 0 或固定不变** | ① 原生 Emby 的 `/Items/Counts` 对未登录匿名请求默认返回全 0；② 反代层硬编码静态数据会导致官方入库新片无法同步递增 | **先探测再决策**：带无效 token 与不带 token 各打一次 `/emby/Items/Counts`，**有差异**才做动态透传 `X-Emby-Token` + 10 分钟短缓存；**无差异（都返全 0）** 说明上游根本没实现统计（EMOS 自研中间层实测如此），此时动态透传只会让卡片永远为 0，**必须静态注入兜底**。判据与实测数据见 `references/emos-instance-probing-and-gray-deploy.md` |
| **疑似废弃的 DNS 记录 / 闲置节点，想清理** | 一条记录不在 Workers Routes 里、直连返回 400/404，看着像孤儿，实际可能是整条链路的承载节点（同机常挂多域名：一个走 CF 代理给播放器、一个裸解析给面板回源，甚至跨 zone） | 三步查清再动手：① 读面板 `/api/routes` 拿真实 target 与 `todayReqs`/`todayBandwidth`/`last_play`；② `dig` 解析 target 主机名，与疑似记录**比对落地 IP**（别只看域名）；③ 登机器 `docker ps` + `docker logs --since 72h` 统计来源 IP 与请求数。端口扫描只能作辅助，不能作判据 |
| **改 nginx 配置后容器起不来 / CF 521** | `location ~*`、命名 location、`if` 块内的 `proxy_pass` **不得携带 URI 路径**，否则 `[emerg] "proxy_pass" cannot have URI part...` 直接崩 | 三种正确改写：① 拆成 `location = /path` 精确匹配（覆盖带/不带前缀两种客户端行为）；② 正则块内 `proxy_pass` 只留协议+域名；③ 正则块内需改路径时用 `rewrite ^(/.*)$ /emby$1 break;`。上线一律走 `scripts/nginx-gray-deploy.sh` 灰度闭环 |
| **`nginx -t` 明明成功，脚本却判定失败并触发回滚** | `nginx -t` 把结果写 **stderr**，写成 `2>/dev/null \| grep -q successful` 会永远失配，造成「假故障→假回滚」白跑一轮 | 校验必须 `docker exec c nginx -t 2>&1 \| grep -q successful`。同理任何解析 nginx/命令行工具自检输出的脚本都要确认流向 |
| **视频拖动进度条卡顿 / 无法断点续传** | 反代未正确透传 206 Partial Content 与 Range 头部，或开启了全量缓冲 | 设置 `proxy_buffering off;`，透传 `Range` 与 `If-Range` 头部 |
| **Telegram 定时播报/通知静默失败（无报错但收不到消息）** | ① 从 Cloudflare API（`workers/scripts/.../bindings`）拉取环境变量时敏感 Token（如 `TG_BOT_TOKEN`）被星号脱敏（如 `<YOUR_USER_IDENTIFIER>:***`）并回写，导致调用 TG API 报 404/401 失败；② **Cloudflare 边缘 Cron Trigger 平台级偶发漏调度**（配置完好但在预定时刻完全没有触发调度） | ① 先用 Cloudflare GraphQL API 查 `workersInvocationsScheduled` 确认当天是否有触发记录（若无记录则为边缘漏调度，配置本身完好，切勿盲改代码）；② 若有调度但报错，用 Workers `/tails` API + Python `websockets`（必须带 `subprotocols=['trace-v1']`）抓实时日志定位未捕获异常；③ 针对脱敏覆写，把敏感变量转为 `secret_text` 根治，详见 `references/worker-deobfuscation-and-tg-verification.md` |
| **修好 Token 后无法确认播报是否真的恢复（webhook 模式下 `getUpdates` 不可用）** | 本地脚本用真实 Token 代发成功 ≠ 生产 Worker 修好了：二者是不同执行主体，不能互相作为修复证据 | 两段式硬证据验证：① 向生产端点 `POST /api/tg-webhook` 灌入伪造的 `/stats` 指令 update，逼生产环境用**它自己的** env Token 去发消息；② 用 `editMessageReplyMarkup` 探测 message_id 存在性（`message is not modified`=存在 / `message to edit not found`=不存在），确认新消息 ID 真实出现。详见 `references/worker-deobfuscation-and-tg-verification.md` |
| **`GET /workers/scripts/{name}/content` 报 `10405 Method not allowed for this authentication scheme`** | 该 `/content` 子路径对 API Token（非 Global API Key）鉴权方式不开放 | 改用 `GET /accounts/{acct}/workers/scripts/{name}`（不带 `/content`），返回 `multipart/form-data`，用正则 `name="worker\.js"\r\n\r\n(.*?)\r\n--[0-9a-f]{20,}` 剥出真实生产代码 |
| **本地以为「补丁已上线」，实际生产跑的是原版** | 部署脚本失败或被后续原版发布覆盖后未做二次校验，本地 `patched_*.js` 与生产早已分叉 | 每次排障第一步先拉生产代码做 **md5 三方比对**（生产 vs `*.backup.js` vs `patched_*.js`），并统计关键补丁标记出现次数（`EMOS-PROXY-ID`/`PlaybackInfo`/`Items/Counts`/`redirect:manual`）；标记计数为 0 即补丁未上线 |
| **面板「测速与 DNS」功能正常，但自己手上的主 API Token 查 DNS 报 `Authentication error`** | 一个账号下常并存多个 Token 且权限互补装反：主 Token 只有 `Workers:Edit` 无 DNS 权限，Worker bindings 内嵌的 `CF_API_TOKEN` 反而握有 `Zone.DNS:Edit` | 排障时对每个已知 Token **逐个试探同一接口**再下结论，别用单一 Token 的 403 判定「账号没权限」；长期应收窄内嵌的大权限 Token |
| **每日播报/stats「实际流量消耗」报 `Actor ... does not have permission '...zone.analytics.read'`** | Worker 内嵌的 `CF_API_TOKEN` 缺少 `Zone -> Analytics:Read` 权限，导致统计脚本查 Cloudflare GraphQL/流量分析接口被拒 | 反代与视频播放完全正常（不受影响）；在 CF 控制台编辑该 API Token，追加 `Zone (区域) -> Analytics (分析) -> Read (读取)` 并限定该域名 Zone ID，无需重启秒级生效 |
| **Python/curl 直连 CF 反代域名报 `403 error code: 1010`** | 空 UA 或非浏览器 UA 触发 Cloudflare Browser Integrity Check，与反代配置无关 | 请求头补标准浏览器 `User-Agent` 即恢复 200。注意这**不影响** Telegram 官方 webhook（自带 UA），排障时勿误判为面板故障 |
| **反代服务报错 521 Web server is down** | Nginx 配置中在正则 location（`location ~*`）内使用了带 URI 路径的 `proxy_pass`，触发 Nginx 启动语法崩溃 | 精确匹配使用普通 `location = /path` 或在正则块内 `proxy_pass` 仅保留协议与域名，不得携带 URI 路径；启动前执行 `nginx -t` 自检 |
| **普通非优化/绕美 NAT 小鸡直连 Emby 严重卡顿与起播延迟高** | 小鸡虽然国际下行大，但回国路由未走 CN2 GIA/CMI 直连，回国往返绕美（延迟 200ms+），导致 PlaybackInfo 握手、海报瀑布流与起播前摇极慢（即使视频流走 R2 308 直链） | ① 播放端坚决保留 Cloudflare Worker 优选双轨（电信/移动优选 IP 直连，延迟 30~50ms）；② 非优化大带宽小鸡仅用于后台重流量任务（TG 爬虫、PT/EMOS 上传做种、S5 打手），严禁直接用作 Emby 客户端直连节点 |
| **NAT 小鸡非标端口直连报 530 Direct IP access not allowed** | 域名在 Cloudflare 开启了橙色小云朵（已代理 / Proxied），但客户端访问的是非标准 Web 端口（如 NAT 映射的 300xx/344xx），触发 CF Anycast 边缘网关拦截 | 在 Cloudflare DNS 中将该子域名切换为【仅 DNS / DNS only ☁️（灰色云朵）】，直连小鸡 NAT 端口享受原生低延迟；或改用 Cloudflare 官方支持的 HTTPS 端口（2053/8443） |
| **手机/国内网络打开自建小门户报 `errors.edgesuite.net`，URL 显示 `http://[No Host]/...`** | 这是 **Akamai** 的通用错误页（非 CF、非源站）。请求被运营商/中间设备按**明文 HTTP + 丢 Host** 拦截。根因是站点挂在 **CF 非标端口（2096/2053/8443 等）**，国内蜂窝网络与部分宽带给这些端口做 QoS/劫持。**不是源站挂了，也不是用户开了代理软件 —— 不要先怪用户客户端** | ① 先用多视角（本机/香港/洛杉矶）curl 证明源站 200，锁定是用户侧端口阻断；② 根治：**Cloudflare Tunnel + 独立子域走标准 443**，`originRequest.httpHostHeader` 改回原 nginx `server_name`、`noTLSVerify:true` 兼容自签证书；不动 nginx/xray/现有节点。完整 API 步骤与 `TUNNEL_TOKEN` 踩坑见 `references/emby-direct-rules-portal-ops.md` |
| **Worker 自定义域名报 522 Connection timed out** | DNS 中存在手动的占位解析记录（如手动配置的 `AAAA 2001:db8::1` 或源站 A 记录）导致请求未被正确接入 Worker 处理管线 | 删除冲突的手动 DNS 记录，改在 Worker 后台的 `Custom Domains`（自定义域）中统一绑定，由 Cloudflare 自动生成管线映射与证书 |
| **优选直连加速域名报 Connection Reset (连接被重置)** | 加速域名（如 `<PRIVATE_IDENTIFIER>`）仅在 DNS 配置了 A 记录，缺少 Cloudflare Zone 级的 Worker 路由规则 | 在 Cloudflare Zone 的 `Workers Routes` 中添加 `<PRIVATE_IDENTIFIER>/* -> <Worker名称>` 确保边缘正确分发 |
| **反代服务报错 521 Web server is down** | ① Nginx 配置中在正则 location 内使用了带 URI 路径的 `proxy_pass` 触发语法崩溃；② 部署官方原版 Worker 覆盖了包含上游 Header（如 `EMOS-PROXY-ID`/`NAME`）的自定义流媒体补丁引擎导致回源鉴权失败 | ① 正则块内 `proxy_pass` 仅保留协议与域名；② 确保在 Worker 的 `fetch` 入口保留 EMOS 专属直通引擎注入 |
| **Cloudflare Worker 调度模式导致启播延迟与慢速** | Worker 调度模式被锁死在跨洋机房，或测速工具批量写入包含高丢包/IPv6 慢速节点 | ① 将 Worker 设置为 `smart` 智能自适应调度；② 清理 DNS AAAA 慢速记录，只保留经校验的精选骨干 IP；③ 极速秒开最佳实践：播放器直接走亚太（香港/新加坡）代理分流 |
| **播放器连接报 400 Bad Request** | 客户端默认开启 HTTPS 请求未配置 SSL 的 HTTP 端口（如 2052） | 在 VPS Nginx 部署自签名/受信任 SSL 证书并在 Cloudflare HTTPS 支持端口（如 `2053` / `8443`）监听，客户端统一使用 `https://<域名>:2053` 连接 |
| **切换反代地址或日常观影报 403 / 401 报错** | 客户端本地持久化缓存了已失效的旧 Session / X-Emby-Token，或与当前反代网关 Session 不匹配 | 引导客户端退出当前登录/删除失效服务器，重新输入用户名密码登录生成全新有效 Session Token 即可秒级恢复 |
| **第三方服（如可乐服 Cola 等）通过 Worker 反代播放报 403 Forbidden** | ① 上游 302 直链防盗链签名绑定了发起 PlaybackInfo 时的客户端 IP（绑定了 Cloudflare 机房 IP），播放器本地网络下载时 IP 不一致被源站拒绝；② SenPlayer/AVPlayer 播放内核请求相对媒体路径时丢失了子路径节点前缀（如 `/kl`）触发 404/路由异常 | ① 在播放器（SenPlayer / VidHub）中关闭该服的「302 / 直链播放」，切换为「服务端代理 / 直通中转」；② 第三方带 IP 绑定防盗链的 302 公益服建议直接使用官方原版直连地址或专线代理播放（详见 `references/emos-and-makkapakka.md`） |
| **国内直连速度慢 / 启播延迟高** | ① 测速工具写入了大量含丢包/高延迟的杂乱 Anycast 节点；② Worker 调度跨洋；③ 境外 Anycast 晚高峰限速 | ① 清理 DNS 冗余记录，锁定优质骨干 IP；② 将 Worker 调度模式（Smart Placement）指定至亚太香港 `aws:ap-east-1`；③ 终极方案：使用独立 VPS（如 RackNerd）开启本地 2GB 内存强缓存与 `proxy_buffering off` 极速直通 |
| **EMOS 大文件视频上传报 `number 不能大于 1000` 失败** | 默认 10MB 分片上传 >10GB 大文件时分片数突破 1000 触发服务端硬限制 | 自适应动态调整单分片大小（`part_size = (file_size + 999) // 1000`），确保 `total_parts <= 1000` |
| **EMOS 10GB+ 大文件直传 R2 超时 (900s) 中断** | 单线程串行 10MB 分片产生千次 HTTP 往返耗时过长，触发 SSH 900s 超时 | 启用 8 线程并发上传、>5GB 文件升至 32MB 分片，并将 SSH 调度超时提升至 3600s（详见 `references/emos-uploader-identify-fix.md`） |
| **EMOS 影视误识别为无关大片/老番（如《八犬传》、《行尸走肉》）** | ① 剥离方括号提取英文单词时，单个冠词虚词（如 `The`、`A`）检索 TMDB 返回泛列表首项（如 `The Walking Dead`、`THE八犬传`）；② 中转 VPS 磁盘满导致 qB 报错挂起，旧缓存文件未自动清理 | ① 优先提取文件名方括号/圆括号内完整中文主名；TMDB 检索严格过滤 `The/A/An` 等虚词；② 定期/传前检查 VPS 磁盘并清理已上传完成的历史旧种子（详见 `references/emos-uploader-identify-fix.md`） |
| **多季剧集（第二季/S02）命名被写死为 S01E... 导致刮削错位** | 自动化命名与转存逻辑中季数硬编码或未解析中文季数 | 采用动态正则解析季数（支持中文数字转换），规范输出 `S{season:02d}E{ep:02d}` 格式（详见 `references/emos-uploader-identify-fix.md`） |
| **EMOS 剧集上传 E02/E03 被误挂载为 S01E01** | EMOS 库内未开辟新集数槽位时，上传器识别逻辑盲目兜底绑定至已录入最后一集（S01E01） | 严格禁止集数越界盲目回退，显式集数不匹配时拦截报错，待库内开辟槽位后再上传（详见 `references/emos-uploader-identify-fix.md`） |
| **Emby/Foam 众包积分入库系统设计与防刷风控** | 众包求片容易被利用并发双花、5秒假视频、死种或垃圾大文件塞爆磁盘 | 部署六重安全风控体系（TMDB 季集互斥锁、FFprobe 深度质检、后置原子结算、磁盘15%熔断）（详见 `references/lemon-emos-crowdsource-architecture.md`） |
| **EMOS 资源上传报未能自动识别** | 纯罗马音/外文资源文件名未命中 EMOS 库内中文条目 | 在上传器中接入 TMDB 自动双语解析与中文译名桥接（详见 `references/emos-uploader-identify-fix.md`） |

---

## 方案一：Cloudflare Worker 原生零流量直连（最推荐）

当使用基于 Cloudflare Worker 的多节点代理（如玛卡巴卡 / MakkaPakka）时，直接在 Worker 的 `fetch` 入口拦截特殊路由，**实现 0 消耗 VPS 流量与全功能原生支持**。

### 移动 (CMCC) 优选与代码混淆机制
1. **中国移动 (CMCC) 优选特性**：
   - 移动骨干网对 Cloudflare 官方移动友好段（如 `<YOUR_SERVER_IP>`、`<YOUR_SERVER_IP>`、`162.159.192.x`、`162.159.193.x`）直连延迟与丢包率极低。
   - 当在 Cloudflare 上配置优选 DNS（泛解析或固定 A 记录如 `<PRIVATE_IDENTIFIER>`）时，客户端可直接通过移动优选 IP 建立 TLS/SNI 连接访问 Worker。
2. **生产环境代码混淆最佳实践**：
   - 在部署前对上游目标地址、专属鉴权请求头（`EMOS-PROXY-ID`/`NAME`）、`/Items/Counts` 拦截与 `PlaybackInfo` 重写逻辑进行变量混淆与十六进制字符串转义（如 `\x75\x72\x6c`、`\x2f\x65\x6d\x6f\x73`），防止明文泄露关键鉴权凭证。

### Worker 终极补丁代码片段（注入于 `async fetch(request, env, ctx)` 入口）：

```javascript
// 🌟 EMOS 专属超能流媒体直通引擎 (解决 403 播放、路径丢失与 Counts 注入)
try {
    const _reqUrl = new URL(request.url);
    const _isEmos = _reqUrl.pathname.startsWith('/emos');
    const _isDirectMedia = !_isEmos && (_reqUrl.pathname.startsWith('/emby/videos/') || _reqUrl.pathname.startsWith('/videos/') || _reqUrl.pathname.startsWith('/emby/Audio/') || _reqUrl.pathname.startsWith('/Audio/'));
    
    if (_isEmos || _isDirectMedia) {
        // 1. 拦截媒体库数量，点亮播放器卡片 (解决显示 0 的问题)
        if (_reqUrl.pathname.endsWith('/Items/Counts')) {
            return new Response(JSON.stringify({
                MovieCount: 18450,
                SeriesCount: 4120,
                EpisodeCount: 118600,
                SongCount: 56800,
                AlbumCount: 3200,
                MusicVideoCount: 150,
                BoxSetCount: 680,
                BookCount: 0,
                ItemCount: 141170
            }), {
                status: 200,
                headers: {
                    'Content-Type': 'application/json; charset=utf-8',
                    'Access-Control-Allow-Origin': '*'
                }
            });
        }

        // 2. 剥离 /emos 前缀并对齐 /emby 路径
        let _subPath = _reqUrl.pathname.replace(/^\/emos/, '');
        if (!_subPath.startsWith('/emby') && !_subPath.startsWith('/rest')) {
            _subPath = '/emby' + _subPath;
        }
        if (_subPath === '/emby' || _subPath === '/emby/') {
            _subPath = '/emby/System/Info/Public';
        }
        const _targetUrl = 'https://video.emos.best' + _subPath + _reqUrl.search;

        // 3. 构建携带 EMOS 专属凭证与标准 UA 的新请求
        const _newHeaders = new Headers(request.headers);
        _newHeaders.set('Host', 'video.emos.best');
        _newHeaders.set('EMOS-PROXY-ID', 'eK981JREMs');  // 替换为实际 UID
        _newHeaders.set('EMOS-PROXY-NAME', 'naye');     // 替换为实际称号
        if (!_newHeaders.get('User-Agent')) {
            _newHeaders.set('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/<YOUR_SERVER_IP> Safari/537.36');
        }

        const _fetchInit = {
            method: request.method,
            headers: _newHeaders,
            redirect: 'manual' // 关键！禁止 Worker 自动跟随，避免携带错误 Host 请求 R2 直链导致 403
        };

        if (!['GET', 'HEAD'].includes(request.method)) {
            _fetchInit.body = request.body;
        }

        const _upstreamResp = await fetch(_targetUrl, _fetchInit);

        // 4. 关键修复：拦截 PlaybackInfo 并动态重写流媒体 URL，给内部路径注入 /emos 前缀
        if (_reqUrl.pathname.includes('/PlaybackInfo') && _upstreamResp.status === 200) {
            let _respText = await _upstreamResp.text();
            _respText = _respText.replaceAll('"/emby/videos/', '"/emos/emby/videos/')
                                 .replaceAll('"/emby/Audio/', '"/emos/emby/Audio/')
                                 .replaceAll('"/emby/hls/', '"/emos/emby/hls/');
            
            const _pHeaders = new Headers(_upstreamResp.headers);
            _pHeaders.set('Access-Control-Allow-Origin', '*');
            _pHeaders.set('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
            _pHeaders.set('Access-Control-Allow-Headers', '*');
            _pHeaders.set('Content-Type', 'application/json; charset=utf-8');
            return new Response(_respText, {
                status: 200,
                headers: _pHeaders
            });
        }

        // 5. 常规媒体流与 API 响应透传 (支持 CORS 与 302 重定向)
        const _respHeaders = new Headers(_upstreamResp.headers);
        _respHeaders.set('Access-Control-Allow-Origin', '*');
        _respHeaders.set('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
        _respHeaders.set('Access-Control-Allow-Headers', '*');

        if ([301, 302, 307, 308].includes(_upstreamResp.status)) {
            const _loc = _upstreamResp.headers.get('Location');
            if (_loc && _loc.startsWith('/')) {
                _respHeaders.set('Location', '/emos' + _loc);
            }
        }

        return new Response(_upstreamResp.body, {
            status: _upstreamResp.status,
            statusText: _upstreamResp.statusText,
            headers: _respHeaders
        });
    }
} catch (_emosErr) {}
```

---

## 方案二：独立 VPS Nginx 高性能反代规范模板

适用于在独立 Linux VPS / Docker 容器中搭建专属 Emby 网关。

```nginx
# 1. 播放进度节流 (防高频心跳冲击)
limit_req_zone $binary_remote_addr zone=emos_progress:10m rate=2r/s;

# 2. 静态图片本地强缓存区 (1GB 空间, 7天不过期)
proxy_cache_path /var/cache/nginx/emos_cache levels=1:2 keys_zone=emos_cache:20m max_size=1g inactive=7d use_temp_path=off;

map $http_user_agent $final_ua {
    default $http_user_agent;
    ""      "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/<YOUR_SERVER_IP> Safari/537.36";
}

server {
    listen 8096;
    server_name _;

    client_max_body_size 100M;
    proxy_connect_timeout 60s;
    proxy_send_timeout 120s;
    proxy_read_timeout 120s;

    # 公共反代请求头
    proxy_set_header Host $proxy_host;
    proxy_set_header X-Real-IP $remote_addr;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    proxy_set_header X-Forwarded-Proto $scheme;
    proxy_set_header User-Agent $final_ua;
    
    # 专属认证头
    proxy_set_header EMOS-PROXY-ID "eK981JREMs";
    proxy_set_header EMOS-PROXY-NAME "naye";

    # WebSocket 支持
    proxy_http_version 1.1;
    proxy_set_header Upgrade $http_upgrade;
    proxy_set_header Connection $http_connection;

    # 1. 播放器卡片媒体数量注入 (解决卡片显示 0 的问题)
    location ~* ^/(emby/)?Items/Counts$ {
        default_type application/json;
        add_header Content-Type "application/json; charset=utf-8";
        add_header Access-Control-Allow-Origin *;
        return 200 '{"MovieCount":18450,"SeriesCount":4120,"EpisodeCount":118600,"SongCount":56800,"AlbumCount":3200,"MusicVideoCount":150,"BoxSetCount":680,"BookCount":0,"ItemCount":141170}';
    }

    # 2. 播放进度上报节流
    location ~* ^/(emby/)?Sessions/Playing/Progress {
        limit_req zone=emos_progress burst=5 nodelay;
        proxy_pass https://video.emos.best;
        proxy_ssl_server_name on;
    }

    # 3. 封面与剧照图片强缓存
    location ~* ^/(emby/)?Items/.*/Images/.* {
        proxy_cache emos_cache;
        proxy_cache_valid 200 7d;
        proxy_cache_valid 404 1m;
        proxy_cache_use_stale error timeout updating http_500 http_502 http_503 http_504;
        add_header X-Cache-Status $upstream_cache_status;

        proxy_pass https://video.emos.best;
        proxy_ssl_server_name on;
    }

    # 4. 206 Range 视频流直通配置
    location / {
        proxy_pass https://video.emos.best/emby/;
        proxy_ssl_server_name on;

        proxy_set_header Range $http_range;
        proxy_set_header If-Range $http_if_range;

        # 禁用缓冲，随下随播
        proxy_buffering off;
        proxy_request_buffering off;
    }
}
```

---

## 方案三：全新 VPS 极简 Nginx 直代 7 步落地 SOP（多端口矩阵与 NAT 小鸡直连）

适用于刚开通的全新 Ubuntu/Debian/Alpine VPS 或 NAT 落地小鸡，无需 Docker 或代理，直接跑原生 Nginx 反代加速 Emby/EMOS，与现有美国 VPS / CF Worker 双轨并存。详见 `references/clean-vps-nginx-emby-7steps.md` 与 `references/nat-vps-emby-dual-line.md`。

### 1. 标准极简单服配置 (`/etc/nginx/conf.d/emby.conf` 或 Alpine `/etc/nginx/http.d/emos.conf`)
```nginx
# 极简轻量缓存区 (适用 512M/1G 内存 NAT 小鸡，防爆内存与磁盘)
proxy_cache_path /var/cache/nginx/emos_cache levels=1:2 keys_zone=emos_cache:5m max_size=50m inactive=1d use_temp_path=off;

server {
    listen 18096; # 或 NAT 外部映射端口如 34474
    listen [::]:18096;
    server_name _;

    client_max_body_size 100M;
    proxy_connect_timeout 15s;
    proxy_send_timeout 3600s;
    proxy_read_timeout 3600s;

    # 1. 播放器卡片媒体数量注入 (双路径兼容 /Items/Counts 与 /emby/Items/Counts)
    location ~* ^/(emby/)?Items/Counts$ {
        default_type application/json;
        add_header Content-Type "application/json; charset=utf-8";
        add_header Access-Control-Allow-Origin *;
        add_header Access-Control-Allow-Methods "GET, POST, OPTIONS";
        add_header Access-Control-Allow-Headers "*";
        return 200 '{"MovieCount":18450,"SeriesCount":4120,"EpisodeCount":118600,"SongCount":56800,"AlbumCount":3200,"MusicVideoCount":150,"BoxSetCount":680,"BookCount":0,"ItemCount":141170}';
    }

    # 2. 封面与剧照图片轻量本地缓存 (毫秒级瀑布流加载)
    location ~* ^/(emby/)?Items/.*/Images/.* {
        proxy_cache emos_cache;
        proxy_cache_valid 200 1d;
        proxy_cache_valid 404 1m;
        proxy_cache_use_stale error timeout updating http_500 http_502 http_503 http_504;
        add_header X-Cache-Status $upstream_cache_status;

        proxy_pass https://video.emos.best;
        proxy_ssl_server_name on;
        proxy_http_version 1.1;
        proxy_redirect off;

        proxy_set_header Host video.emos.best;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_set_header EMOS-PROXY-ID "eK981JREMs";
        proxy_set_header EMOS-PROXY-NAME "naye";
    }

    # 3. 核心 API 与 206 视频流极速直通
    location / {
        proxy_pass https://video.emos.best;
        proxy_ssl_server_name on;
        proxy_http_version 1.1;
        proxy_redirect off;

        # WebSocket 实时通信支持
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection $connection_upgrade;

        proxy_set_header Host video.emos.best;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;

        # 专属身份鉴权头
        proxy_set_header EMOS-PROXY-ID "eK981JREMs";
        proxy_set_header EMOS-PROXY-NAME "naye";

        # 206 Range 分片透传 (随下随播、拖拽不卡)
        proxy_set_header Range $http_range;
        proxy_set_header If-Range $http_if_range;

        # 禁用缓冲
        proxy_buffering off;
        proxy_request_buffering off;
    }
}
```

### 2. 一键极速验收闭环指令
```bash
nginx -t && systemctl reload nginx && ss -lntp | grep ':18096 ' && curl -I --connect-timeout 10 http://127.0.0.1:18096
```

### 3. 多 Emby 多端口矩阵扩展
- `18096` -> Emby 服 A (`/etc/nginx/conf.d/emby-18096.conf`)
- `18097` -> Emby 服 B (`/etc/nginx/conf.d/emby-18097.conf`)
- `18098` -> Emby 服 C (`/etc/nginx/conf.d/emby-18098.conf`)

### 4. 极速 3 步排障索引
1. **502 Bad Gateway**：`curl -I --connect-timeout 10 https://你的Emby地址`（排查 VPS 到上游）。
2. **本机通但公网打不开**：`curl -I http://127.0.0.1:18096` 正常时排查 UFW 防火墙与云厂商安全组（EC2 SG 等）。
3. **查 Nginx 错误日志**：`tail -n 30 /var/log/nginx/error.log`。

---

## 验证与验收指令

```bash
# 1. 验证公共系统信息接口
curl -s https://<反代域名>/<前缀>/System/Info/Public -I

# 2. 验证卡片数量是否点亮 (非0)
curl -s https://<反代域名>/<前缀>/Items/Counts | jq .

# 3. 验证 206 Range 视频分片响应
curl -s -I -H "Range: bytes=0-1024" https://<反代域名>/<前缀>/emby/System/Ping
```

---

## 避坑与运维准则 (MakkaPakka & Cloudflare 双轨)

1. **多节点/多链路独立共存准则（严禁覆盖或撤销已有主力节点）**：
   - 当引入新机型/新地区节点（如新增香港 NAT 小鸡）时，必须以**“新增独立链路/独立二级域名”**形式落地，绝不修改、覆盖或撤换原有的主力反代链路（如已有美国 VPS、原面板直连）。
   - 播放器客户端支持添加多个独立服务器，双轨/多轨并行可实现多网络容灾与灵活切换。
2. **NAT 小鸡反代源站真实 IP 隐匿规范（Cloudflare CDN 代理）**：
   - 严禁在客户端直连中暴露小鸡真实公网 IP。
   - 隐匿方案：配置专属二级域名（如 `hk.domain.com`）解析至小鸡 IP，并在 Cloudflare 开启代理（橙色小云朵）；由于 Cloudflare 免费版只代理标准 HTTPS 端口（如 `443`, `2053`, `2083`, `2087`, `2096`, `8443`），在 NAT 小鸡上可通过对应映射端口监听，客户端连接 `https://hk.domain.com:<CF支持端口>`，实现 100% 隐藏真实 IP + 全网 CDN 加速。
3. **Alpine Linux (OpenRC) 极轻量 NAT 小鸡环境极速部署**：
   - Alpine 下使用 `apk add nginx`，配置文件置于 `/etc/nginx/http.d/*.conf`。
   - 内存占用极低（<15MB），非常适合 512MB~1GB 内存的低配小鸡，配合 `proxy_buffering off` 即可提供高达千兆的流媒体转发吞吐。
4. **EMOS 架构与视频直链重定向（308/302 直通 R2 存储桶）**：
   - 真实架构为 `Worker 反代面板 ➡️ VPS Nginx 容器 ➡️ EMOS 官方`。
   - EMOS 官方 PlaybackInfo 返回视频直链（如 `/emos/emya/video?server=emos&media_id=...`），请求后会 308/302 重定向至 R2 存储桶直链（如 `https://emoss.eeew.eu.org/...`）。
   - **核心避坑**：
     ① VPS Nginx 必须配置 `proxy_redirect off;`，严禁二次拼接 `/emos/` 导致路径损坏报错 5XX/404。
     ② Worker 端代理外部真实 CDN 直链时，必须剥离 `Host`、`EMOS-PROXY-ID` 与 `EMOS-PROXY-NAME`，防止 R2 存储桶抛出 403/502。
2. **403 播放拒绝规避与最新流媒体路由**：
   - EMOS 2026 流媒体路由为 `/emya/video?server=emos&media_id=...`，反代层必须捕获并放行 `/emya/`，严禁遗漏。
   - ⚠️ **是否需要保留 `/emby` 前缀因实例而异，必须实测，严禁照抄任何文档结论（含本技能）**：部分实例需剥离前缀，部分实例（自研中间层）剥离后直接 404、必须保留前缀。上线前跑三路差分诊断（上游直连 / 经反代 / 故意拼前缀），详见 `references/emos-instance-probing-and-gray-deploy.md`。
   - `PlaybackInfo` 重写流媒体路径时，若 302 重定向返回的是指向 R2 对象存储的绝对直链（`https://...`），严禁拼接 `/emos` 前缀，必须保持原样透传防止 R2 鉴权签名失效报错 403。
   - 对于基于 D1 动态路由的面板（如 MakkaPakka），严禁在 Worker 入口将所有流量劫持为单一写死的账号请求头，必须采用 D1 原生动态代理以保证客户端真实 Session/Token 正常握手。
3. **API Token 权限隔离与权限矩阵探测**：
   - 部署 Worker / 绑定 Custom Domains 需要 `Workers:Edit` 权限 Token；面板「测速与 DNS」模块改 A 记录需要 `Zone.DNS:Edit`；每日播报/监控拉取 CDN 实际流量（GraphQL `httpRequestsAdaptiveGroups`）需要 `Zone.Analytics:Read`。
   - ⚠️ **每日播报 Analytics 权限缺失排障与直达定位**：
     - 若播报报错 `Actor 'com.cloudflare.api.token.<TOKEN_ID>' does not have permission '...zone.analytics.read'`，报错中的 Actor 后缀 `<TOKEN_ID>` 即为该 Token 在 Cloudflare 的唯一 ID。
     - 用户在多 Token 迷失时，直接提供直达编辑 URL：`https://dash.cloudflare.com/profile/api-tokens/<TOKEN_ID>`。
     - 只需补勾「区域 ➡️ 分析 ➡️ 读取 (Zone.Analytics:Read)」并保存，**密钥字符串本身不会变动**，无需重新更新 Worker 环境变量即可秒级生效恢复流量统计。
   - ⚠️ 一个账号下常并存多个 Token 且**权限互补装反**（实测：主 Token 有 Workers 无 DNS，Worker 内嵌 `CF_API_TOKEN` 只有 DNS 无 Workers）。排障时必须**逐个 Token × 逐个只读端点**打一遍再下结论，别用单一 Token 的 403 判定「账号没权限」。探针端点清单见 `references/emos-instance-probing-and-gray-deploy.md`。
   - 衍生检查：若某面板功能「从来没人用过」，主动验证它依赖的 API 权限是否具备 —— 本次发现面板「更新代码」按钮一直是坏的（`/api/deploy` 依赖的 `GET /workers/services/{name}` 与 `/bindings` 双双 403）。
   - Token 只能由用户在 CF 后台手动重签（API 无法自签）。给用户的指引必须具体到勾选项与 Zone Resources 范围。
4. **分流加速 DNS 维护**：
   - 电信优选域名（如 `<PRIVATE_IDENTIFIER>`）：优选 `<YOUR_SERVER_IP>`、`<YOUR_SERVER_IP>`、`<YOUR_SERVER_IP>`。
   - 移动优选域名（如 `<PRIVATE_IDENTIFIER>`）：优选 CMI 黄金段 `<YOUR_SERVER_IP>`、`<YOUR_SERVER_IP>`、`<YOUR_SERVER_IP>`。
   - 避免在测速后写入大量含丢包/高延迟的杂乱 Anycast 节点，保持 DNS A 记录精简。
5. **Worker 路由与优选域名 Connection Reset 规避**：
   - 在 DNS 中新增优选子域名时，必须在 Cloudflare Zone 的 `Workers Routes` 中添加对应的 `*.domain.com/* -> Worker` 规则，否则 Anycast 边缘找不到接管 Worker 会直接重置 TCP 连接。
6. **Cloudflare 隐藏真实 VPS 源站 IP 与端口映射（HTTPS 2053）**：
   - 使用 VPS Nginx 进行流媒体与内存加速时，若不希望暴露 VPS 真实公网 IP，可在 Cloudflare 将域名开启代理（小黄云 `proxied: true`）。
   - 播放器客户端默认偏好 HTTPS，Nginx 必须配置 SSL 证书并在 Cloudflare 允许的 HTTPS 端口（如 `2053` 或 `8443`）监听，客户端统一填入 `https://vps.<PRIVATE_IDENTIFIER>:2053`，实现全网三大运营商智能 CDN 调度并 100% 隐匿源站 IP。
7. **播放器 Session 切换机制**：
   - 当服务端反代地址或端口变更后，若客户端提示 `Expired`（过期），要求用户退出账号并重新输入密码登录即可完成握手。
8. **专属小鸡 / 亚太 VPS 前置机极致加速选型与架构**：
   - **核心原理**：国内到香港/新加坡物理延迟仅 15ms~30ms，小鸡到 Cloudflare R2 存储桶 1ms~2ms 内网互联。
   - **选购要点**：认准【中国香港 CMI / BGP 优化】（如 HostYun EQ-CMI、ByteVirt NAT、Shlii 等），配置只需 1核 512MB/1GB 即可跑满 4K。
   - **隐私保护**：通过专属域名（如 `emby.domain.com`）绑定并配置 Let's Encrypt / 自签名 SSL，配合 Nginx UA/Path 白名单隐藏源站特征。
   - **Shlii (shlii.io) 选型实战**：首选 `HKVIA-电移神机`（ID: 771，电信移动双网优化）、`HK三网优化大带宽`（ID: 532）或 `HK 狗妈奶爸 1`（ID: 1），提供极低延迟与大带宽。
9. **启播速度天花板最佳实践（代理分流 vs 直连）**：
   - 对于支持代理的客户端/软路由，直接将 Emby 域名（如 `zjw.<PRIVATE_IDENTIFIER>` / `emos.best`）分流至优质香港/新加坡专线节点，往返握手延迟降至 20ms~30ms，无需自建小鸡即可实现 4K 原画秒开。
10. **Cloudflare Worker Bindings 环境变量星号脱敏覆写风险**：
   - **问题现象**：定时 Cron 触发器执行正常，但 Telegram 每日播报或 Webhook 通知突然静默失败。
   - **根本原因**：通过 Cloudflare REST API 读取已部署 Worker 的 `bindings` 时，Cloudflare 针对所有 `plain_text` 或敏感变量自动返回截断/脱敏值（如 `<YOUR_USER_IDENTIFIER>:***`）。若后续发布脚本或热更新代码时直接读取该 JSON 并作为 `metadata.bindings` 上传，会将带星号的无效 Token 永久写回生产环境，导致调用 `https://api.telegram.org/bot<TOKEN>/sendMessage` 返回 404/401。
   - **防范规范**：
     ① 环境变量配置文件（如 `.env` / 本地真实 JSON）必须作为唯一的权威凭证源，严禁将 Cloudflare API 导出的 bindings 反向导入生产发布管线；
     ② 部署脚本中增加强校验：`assert '***' not in token, 'Error: Masked token detected in bindings!'`；
     ③ **终极断根**：把敏感变量类型从 `plain_text` 升级为 `secret_text`。Cloudflare 对 `secret_text` 在 API 返回中完全不含 `text` 字段（而非返回星号），面板自更新管线读到的 bindings 里它不存在，自然无法被脱敏值覆写。代码更新时应优先用 `metadata.keep_bindings` 保留线上秘密；只有新增/轮换秘密等明确需要赋值的情况才从本地权威源传入（见第 11 条）。
     ④ **给面板 `/api/deploy` 自更新管线打防护补丁**（玛卡巴卡实战验证）：原版逻辑是 `for(const k in env){ typeof env[k]==='string' && push({name:k, type:'plain_text', text:env[k]}) }`，即无条件把所有字符串 env 打成 `plain_text` 回传——这是故障可无限复现的根源。补丁在循环内插入两道防线：
     ```javascript
     const _LMN_SEC = ['TG_BOT_TOKEN','CF_API_TOKEN','ADMIN_TOKEN'];
     for (const k in env) {
       if (typeof env[k] !== 'string') continue;
       const v = env[k];
       if (v.indexOf('***') !== -1) throw new Error('安全拦截：环境变量 '+k+' 检测到脱敏值(***)，已阻止写入生产。');
       arr.push({ name: k, type: _LMN_SEC.indexOf(k) !== -1 ? 'secret_text' : 'plain_text', text: v });
     }
     ```
     注意混淆脚本中 `'string'` / `'plain_text'` / `'push'` 都是 `_0xXXXX(A^B)` 解码调用，补丁必须保留这些原始解码调用（只替换控制流），否则解码器索引错位导致 Worker 直接崩。

11. **`secret_text` 类型的读写不对称铁律**：
   - `GET /workers/scripts/{name}/bindings` 对 `secret_text` **只返回 `{name, type}`，无 `text` 字段**。
   - 代码更新不必重新获取或重传已有秘密：使用当前官方 Upload API 支持的 `metadata.keep_bindings`，按 binding type 保留线上 `secret_text`（以及需保留的 `plain_text`、`d1` 等）；本次实际部署已验证此路径。只有明确新增/轮换秘密或所用发布路径无法保留绑定时，才从本地权威凭据源显式传入。缺少 `text` 字段不等于秘密为空；不要将脱敏 GET 响应回写。详见 `references/cloudflare-worker-keep-bindings-deploy.md`。
   - 部署脚本必须硬断言变量集合一致：`assert {b['name'] for b in new} == {x['name'] for x in old}`，防止静默丢变量。

12. **Cloudflare BIC 1010 拦截空 UA（排障假故障源）**：
   - 用 `curl`/`urllib` 默认 UA（或空 UA）请求已启用 BIC 的 Worker 域名（如 `<PRIVATE_IDENTIFIER>`）会返回 `403 error code: 1010`，极易被误判为"反代挂了"。
   - 排障时所有 curl/Python 探活必须显式携带标准浏览器 UA。Telegram 官方 webhook 自带 UA 不受影响。

13. **TG 播报修复的硬证据验证法（严禁只凭本地代发就报"搞定"）**：
   - 本地脚本用真实 Token 直发成功，**只能证明 Token 有效，不能证明生产环境已修复**。
   - 正确验证：模拟 Telegram webhook `POST https://<域名>/api/tg-webhook`，body 为 `{"message":{"text":"/stats","chat":{"id":<CHAT_ID>},...}}`（玛卡巴卡面板 `/stats` 指令触发 `sendTgStats`），迫使**生产 Worker 用它自己的 TG_BOT_TOKEN** 去调 sendMessage。
   - 由于 webhook 模式下 `getUpdates` 不可用，用 `editMessageReplyMarkup` 探测 message_id 存在性作为硬证据：不存在返回 `message to edit not found`，存在返回 `message is not modified`。ID 递增即证明生产真的发出了新消息。

14. **PUT /workers/scripts 会静默重置 placement（部署顺序铁律）**：
   - 每次通过 `PUT /accounts/{acct}/workers/scripts/{name}` 上传代码后，`placement` 会被清空回 `{}`，即便 metadata 里没提这个字段。
   - **必须在代码部署完成后再 `PATCH /settings` 设置 `{"placement":{"mode":"smart"}}`**，且部署后要复查一次。实战中曾因先设 smart 再部署代码，导致优化被静默回滚。

15. **`/emya/` 路由是否需要 `/emby` 前缀取决于具体服，必须差分实测而非照抄**：
   - 差分诊断法：① 上游直连 `https://video.emos.best/emya/video?...`；② 经反代（拼了 `/emby`）；③ 手动拼 `https://video.emos.best/emby/emya/video?...`。
   - 若 ② 与 ③ 一致返回 `401 {"message":"Unauthenticated."}` 而 ① 返回 `404` 空 body，说明**该服的 `/emya` 恰恰需要 `/emby` 前缀**（401 已到鉴权层＝路由命中，404 空 body ＝根本无此路由）。此时让 `/emya/` 落入 `location /`（自动补 `/emby/`）才是正确配置，单独加剥离前缀的 `location /emya/` 反而会打断链路。

16. **EMOS 中间层不实现 Items/Counts，静态注入是唯一可行方案**：
   - 实测 `video.emos.best` 的 `ServerName=emos, Id=emya, Version=1.0.0` 是自研中间层而非原生 Emby。`/emby/Items/Counts` 无论携带有效 Token、无效 Token 还是空 Token，**一律返回全 0**。
   - 因此"严禁硬编码、改动态透传"这条通则对 EMOS **不适用**，必须保留静态 JSON 注入才能点亮播放器卡片。判定方法：带 Token 请求上游 Counts，若仍全 0 即为中间层。

17. **Docker 发布端口的防火墙必须写 DOCKER-USER 链，UFW 对其完全无效**：
   - Docker 通过 `docker-proxy` 发布的端口（`docker ps` 里带 `0.0.0.0:PORT->` 的），其 iptables 规则位于 `nat/PREROUTING` + `FORWARD` 链，**绕过 UFW 管辖的 `filter/INPUT` 链**。给这类端口加 UFW 规则等于没加。
   - 正确做法（以 8096 仅放行 Cloudflare 为例）：
     ```bash
     # 白名单逐条插入链首（RETURN 放行）
     for C in $CF_IPV4_CIDRS; do
       iptables -I DOCKER-USER 1 -p tcp -s "$C" --dport 8096 -j RETURN
     done
     iptables -I DOCKER-USER 1 -p tcp -s <YOUR_SERVER_IP>/8   --dport 8096 -j RETURN
     iptables -I DOCKER-USER 1 -p tcp -s <YOUR_SERVER_IP>/12 --dport 8096 -j RETURN
     # 兜底 DROP 追加到链尾
     iptables -A DOCKER-USER -p tcp --dport 8096 -j DROP
     ```
   - **DOCKER-USER 链不会自动持久化**，重启即丢。必须配 systemd oneshot 单元（`After=docker.service`，内含 `sleep 15` 等 Docker 建链）在开机时重放规则，并动态重拉 CF IP 段。
   - 端口归属测绘：`ss -lntp | grep docker-proxy` 出来的是 Docker 端口，其余为宿主机原生端口（UFW 管辖）。
   - 收窄前先做来源审计：解析 nginx 访问日志，统计有多少比例来自 CF IP 段。实战数据 99.22% 来自 CF，剩余 0.78% 为扫描器与本机自检，可安全收窄。
   - **重建容器会重置 Docker 链**，`docker rm && docker run` 后必须复核并重放 DOCKER-USER 规则（`docker restart` 不影响）。

18. **上游 `Cache-Control` 会让 nginx 缓存 403 鉴权失败响应（海报黑图根因）**：
   - **现象**：封面缓存生效后，未登录时的 `403 Forbidden` 被写入缓存并返回 `X-Cache-Status: HIT`，登录后海报仍从缓存拿到 403 变黑图。
   - **根因**：EMOS 上游对 403 图片响应发送了 `Cache-Control: max-age=2678400`（31 天）。nginx **默认尊重上游 Cache-Control**，其优先级高于 `proxy_cache_valid`，所以写 `proxy_cache_valid 401 403 0s` 完全压不住。
   - **正确解法**（两条必须同时用）：
     ```nginx
     # 1) 忽略上游缓存指令，把决定权收回本地
     proxy_ignore_headers Cache-Control Expires Set-Cookie;
     # 2) 仅 200 允许写缓存（http 块内定义 map）
     proxy_no_cache      $skip_cache;
     proxy_cache_bypass  $skip_cache;
     ```
     ```nginx
     map $upstream_status $skip_cache {
         default 1;
         200     0;
         ""      0;   # 缓存命中时 $upstream_status 为空，必须放行
     }
     ```
   - 修完必须清空既有缓存目录（`rm -rf .../emos_cache/*`），否则已污染的 403 条目仍会命中。
   - **验证 200 仍可缓存的探针法**：临时注入一个与封面 location 指令集完全相同、但 `proxy_pass` 指向确定返回 200 的端点（如 `/emby/System/Info/Public`）的 `location = /__cacheprobe`，连打 3 次应看到 `MISS → HIT → HIT`，验证后立即移除。只测 403 不缓存是不够的——很容易把好响应一起禁掉而不自知。

19. **Alpine/musl 容器忽视宿主机无 IPv6，仍解析 AAAA 导致每请求两次无效连接**：
   - **现象**：nginx error.log 大量 `connect() to [2606:4700:...]:443 failed (101: Network unreachable)`，实战 7 天累计 899 次。
   - **注意先量化再决定**：实测该失败为 `errno=101 耗时=0.0001s` **瞬时失败，对起播无可感知影响**，属于日志噪音而非性能问题。不要夸大成"拖慢起播"。
   - `resolver ... ipv6=off` 只作用于 nginx 运行时动态解析，对 `proxy_pass` 里写死域名（启动时由 musl `getaddrinfo` 解析）**无效**。
   - **根治方案**：以 sysctl 禁 IPv6 重建容器，实测 `getent ahosts` 不再返回 AAAA：
     ```bash
     docker run -d --name lemon-emos-proxy --restart always \
       --sysctl net.ipv6.conf.all.disable_ipv6=1 \
       --sysctl net.ipv6.conf.default.disable_ipv6=1 \
       -p 8096:8096 \
       -v .../nginx.conf:/etc/nginx/nginx.conf \
       -v .../cache:/var/cache/nginx/emos_cache \
       nginx:alpine
     ```
   - 决策前先用一次性容器做 A/B 对照验证 sysctl 是否真的生效（musl 有时无视），再动生产：
     `docker run --rm --sysctl net.ipv6.conf.all.disable_ipv6=1 nginx:alpine sh -c 'getent ahosts <域名>'`
     ③ **根治（已实战验证）**：把 `TG_BOT_TOKEN` / `CF_API_TOKEN` / `ADMIN_TOKEN` 等敏感项的 binding 类型从 `plain_text` 升级为 `secret_text`。CF 对 `secret_text` 在 bindings 接口中**只返回 `{name, type}`、完全不返回值**，因此任何「读 bindings 再回写」的管线都不可能再把脱敏值写进生产 —— 从机制上断根，而非依赖脚本自觉。
     ⚠️ 副作用：升级后本地备份的 `bindings.json` 成为该密钥的**唯一可读副本**，CF 侧再也读不回来。务必确认备份完好后再升级。
   - **面板自更新管线（`/api/deploy`）的结构性隐患**：反混淆后可见它无条件把所有 `typeof === 'string'` 的 env 打成 `plain_text` 回传，**没有任何脱敏检测**，这就是故障可反复复现的根源。补丁方向：在 bindings 收集循环内加 `if (v.indexOf('***') !== -1) throw` 硬拦截 + 敏感名单自动归类 `secret_text`。

11. **生产 Worker 变更的安全闸门 SOP（缺一不可，可直接跑 `scripts/redeploy_worker_bindings.py`）**：
   1. 先拉当前 bindings 落盘为 `rollback-bindings-<时间戳>.json`（回滚快照）；
   2. 断言凭证源无 `***`（权威源 = 本地备份，绝不是 CF API 返回值）；
   3. 断言新旧**变量名集合完全相等**，防漏变量导致面板功能静默失效；
   4. 若本次只改变量，断言代码 md5 与生产完全一致（宣称「零代码改动」必须可证）；
   5. 改代码时：锚点命中次数必须 `== 1`（防误替换）+ `node --check` 语法校验 + 关键锚点计数回归（`/api/deploy`、`sendTgStats`、`async'scheduled'` 数量不得减少）+ 离线单测覆盖补丁逻辑；
   6. 部署后复核 bindings 类型、**Cron Trigger 是否仍在**（PUT 脚本会重置未随附的配置）、全链路探活；
   7. 端到端硬证据验证（见排障索引里的 webhook 灌注 + message_id 探测法）。

12. **修复类任务的汇报纪律（爸爸明确要求）**：
   - 「本地脚本代发成功」「部署 API 返回 success」都**不是**故障已修复的证据，必须拿到「生产环境自己产生了预期副作用」的硬证据才能说搞定。
   - 报告结构：先给根因与硬证据，再给改动前后对照表，最后明确区分【已完成/已验证】与【已构建但未部署】—— 未跑完的验证步骤必须如实说明卡在哪一步，严禁把未测代码说成已上线。
   - **文档结论被实测推翻时必须主动、显式地承认**，并说明「实测数据是什么、因此按实测走」，同时立即回patch 本技能对应条目（爸爸认可这种做法，比默默改掉更可信）。切勿为了维持「文档正确」而扭曲实测结果。
   - 涉及用户必须亲自操作的部分（如 CF 后台重签 Token），指引要具体到菜单路径与勾选项，并说明「拿到后交给我，我负责写入并验证从 403 变 200」。

13. **改动生产反代前的强制探测清单（本次实战教训，缺一不可）**：
   1. `curl /emby/System/Info/Public` 确认上游身份 —— 出现 `ServerName=emos, Id=emya, Version=1.0.0` 即为自研中间层，官方 Emby 语义全部不可假设；
   2. 需要改路径/前缀的：先跑三路差分诊断，别凭单个 404 下判断；
   3. 需要改 `/Items/Counts` 的：先测「带 token vs 不带 token 是否有差异」再决定动态/静态；
   4. 想删 DNS 或下线节点的：先读面板 `/api/routes` 真实 target + 比对落地 IP + 登机器看 72h 活流量；
   5. 所有 nginx 变更走 `scripts/nginx-gray-deploy.sh` 灰度闭环（含自动回滚），严禁裸 `cp` + `reload`。

20. **Cloudflare Worker 单点 Cron 漏调度与 EC2 外部看门狗（Watchdog）双轨兜底**：
   - **现象**：Worker 代码、Token 与 Cron 触发器均完好，但偶发某天 22:00（14:00 UTC）完全收不到每日播放播报，GraphQL `workersInvocationsScheduled` 记录缺失。
   - **根因**：Cloudflare 官方对免费/标准版 Worker 的 Cron 实行 Best-Effort 策略，特别是开启 Smart Placement（智能机房调度）重新分析迁移时，单次 Cron 极其容易被边缘调度器漏派发。无重试、无自愈机制。
   - **根治**：部署外部独立看门狗服务（`/home/ubuntu/scripts/makkapakka_daily_watchdog.py`）。每天 21:55 记录私聊最高 `message_id` 基线；22:05 检测是否有新消息产生（若已发则静默退出防重）；若未产生则判定 CF 漏发，立即调用 Webhook 唤醒 Worker 补推并探测新 `message_id` 落地，彻底根治单点 Cron 失效。

21. **MakkaPakka 前端 CDN 依赖失效防御与优雅降级（Sortable / Chart 报错根治）**：
   - **现象**：打开面板显示红色字样 `⚠️ 读取失败: Can't find variable: Sortable`，节点列表全部消失清空。
   - **根因**：原版 HTML 头部硬编码引用 `cdn.jsdelivr.net` 加载 `Sortable.min.js` 与 `Chart.js`。国内部分运营商对 jsdelivr 存在 DNS 污染与握手超时。当脚本加载失败时 `window.Sortable` 为空，`load()` 完成 API 请求并生成 DOM 后执行 `sortableInstance = Sortable.create(...)` 抛出未捕获异常，直接被外层 `catch(err)` 捕获并清空节点卡片容器显示为错误。
   - **根治方案（双重防护）**：
     ① **执行端防御性判空**：用 `if (typeof Sortable !== 'undefined')` 包裹 `sortableInstance` 的销毁与创建，用 `if (typeof Chart !== 'undefined')` 包裹数据大屏图表初始化。即使外部网络全断，核心节点列表与控制台也能 100% 正常显示与操作；
     ② **多源 CDN 降级**：首选国内镜像 BootCDN，后置 inline script 校验并回退到 cdnjs / jsdelivr 兜底。
   - **Worker 热补丁与部署避坑**：
     ① **改写 HTML_UI 免动混淆字符串表**：混淆代码中将 `,HTML_UI=` 替换为 `;let HTML_UI=`，并在 HTML 模板拼接结束的引号后直接追加 `.replace(...)` 链式调用，无损改写 DOM 且不影响已有解码器索引；
     ② **PATCH /settings 报 415 根因**：Cloudflare Workers 的 `/settings` 接口必须用 `multipart/form-data`（part 名称必须为 `name="settings"; filename="settings.json"`，Content-Type 为 `application/json`），发送纯 JSON 会被报 415 Unsupported Media Type；
     ③ **PUT 重置 Placement**：每次上传代码后必须显式重新执行 Smart Placement 补丁，防止优化被静默清空。

22. **MakkaPakka v3.4.36「视频边缘共享缓存」导致能进节点但播放卡死（EDGE_CACHE_VIDEO）**：
   - **现象**：客户端能进节点、能加载海报与列表、点播放后无限缓冲/黑屏/花屏；`routes.last_play` 与 `play_hits` 持续增长（PlaybackInfo 成功），但视频流始终不出画面。升级前同一节点正常 → 高度指向新版新增机制。
   - **根因**：v3.4.36 新增全局开关 `EDGE_CACHE_VIDEO = true`，把 Static 直连视频流（`/videos/{id}/stream?static=true`）放进 Cloudflare 边缘共享缓存。它构造缓存键时**主动删除** `deviceid` / `api_key` / `x-emby-token` / `playsessionid` / `access_token`，且**缓存键不含 `Range`**。播放器是按字节分片请求的（`bytes=0-`、`bytes=1048576-`…），所有分片共用同一条缓存记录 → 第 2 段拿到第 1 段的字节，必然卡死或花屏。旧版 v2.2.2 无此机制，故为升级引入。
   - **判定三步**：① `GET /api/security`（带有效会话 Cookie）看返回里 `edgeCache` 是否为 `true`；② 混淆脚本搜 `EDGE_CACHE_VIDEO` 并确认其分支作用域覆盖 `/videos/`（`_0x3a702d` 排除表含 `m3u8`/`hls` 但**不含** `/videos/`，所以 Static 直连会中招）；③ 对比升级前版本是否根本没有该变量。
   - **修复（免重部署，秒级生效）**：D1 写 `INSERT INTO app_config(key,value) VALUES('edge_cache_video','0') ON CONFLICT(key) DO UPDATE SET value='0'`。代码每次请求实时读该键，改完立即生效，**不要为此重传 Worker 代码**（重传会重置 placement 与 Cron，风险远大于收益）。回滚只需删除该行。
   - **验收**：`/api/security` 返回 `edgeCache:false`；用户真实播放后 `routes.last_play` 时间戳推进、`play_hits` 当小时计数从「多次重试」降为个位数。
   - ⚠️ **假 itemId 探测的误判陷阱**：用不存在的 itemId 请求 `/emos/emby/videos/1/stream.mp4?static=true` 会拿到 `HTTP 404` + body `emos video 404 :(`。该字符串**不在 Worker 代码里**（`t.find('emos video') == -1`），是 EMOS 源站自己返回的 → 说明代理转发链路正常，不能据此判定「Worker 拦了视频」。区分方法：Worker 生成的错误体是短 JSON/纯文本且能在脚本里搜到对应字符串，源站错误体搜不到。
   - **管理 API 认证口径**：`ADMIN_TOKEN` 以 `Authorization: Bearer` 请求 `/api/security` 返回 `401`，但携带面板会话 Cookie 返回 `200`。排障读写配置优先用 Cookie 会话，别用 Bearer 失败就断言 Token 失效。

23. **「帮我规划」类请求的执行顺序（爸爸明确纠正过：能传就直接传，别先写方案）**：
   - 用户说「帮我规划一下」时，**不是**让你先产出一份规划文档。正确顺序是：① 先只读采集三到五个关键实测数（带宽/磁盘/链路是否通/凭据是否有效）→ ② 直接跑一次端到端验证，证明"能做" → ③ 再给结论与分工。
   - 实战教训：本次先写了一份完整的双平台上传集群规划文档，用户回了一句「你能上传不就可以了吗」。**先证明能力，再谈架构。** 规划文档可以作为附带产物落盘，但不能代替实测。
   - 规划类任务的最终回复仍要满足：结论先行、实测基线表带采样时间与时区、把「需要用户提供的东西」单列一节。
   - 实测过程中若发现真实瓶颈与用户假设不同（如"磁盘不够"实为"串行分片浪费带宽"），**必须直接纠正假设**，不要顺着用户的框架继续规划。

24. **Emby 反代节点的公网暴露面审计（用户说「测一下/攻击一下这个域名」时）**：
   - **先过授权闸门**：拒绝攻击行为，确认「自有或已授权」后才做低强度只读（单线程、不爆破、不压测）。
     域名刚注册、全 CF 代理、无 MX 看着像钓鱼站，**不等于不是自有资产** —— 本次实录正是自有 Emby 节点，先问再判。
   - 完整方法与命令见 `selfhosted-service-audit` 的 `references/external-exposure-audit.md`；Emby 侧要点：
   - **全量透传是常态**：根路径 200 + 404 返回 `{"ResponseStatus":{"ErrorCode":"NotFound"}}` ⇒ 反代没做路径白名单，
     `/web/index.html` 与 `/Users/AuthenticateByName` 全部公网直达，必须靠 CF WAF 限速（10 次/分钟/IP）挡爆破。
   - **`/System/Info/Public` 会报出版本、`OS`、`ServerId`**：产品设计不是漏洞，但等于把版本指纹送给攻击者，
     用 WAF 改写响应里的 `Version` 字段掐掉。`ServerId` 跨域名稳定，可用来把多个入口归并到同一源站。
   - **`/Users/Public` 返回 `[]` 是好事**（公开用户列表已禁用）；返回非空数组才是泄露，必须报。
   - **头号真实风险是缺 `Referrer-Policy`**：Emby 支持 `?api_key=` 走 URL 传令牌，令牌会随 `Referer` 泄给第三方域名。
     加 `Referrer-Policy: no-referrer` 即可，零功能影响；再补 `X-Content-Type-Options: nosniff`、
     `X-Frame-Options: SAMEORIGIN`（防后台被 iframe 套壳点击劫持）。CF 默认不注入这些头，必须自己上 Transform Rule。
   - **版本真实性必须核验**：自报版本对 `api.github.com/repos/MediaBrowser/Emby.Releases/releases`。
     本次实测节点自报 `<YOUR_SERVER_IP>`，而官方列表最新稳定是 `<YOUR_SERVER_IP>`（2026-10-20）、beta `<YOUR_SERVER_IP>`，
     **该版本号不在官方发布记录里** ⇒ 口径只能写「无法用官方发布记录核对补丁状态」，
     **不要断言「是破解版」**；此时 CVE 版本区间对比同时失效（`CVE-2025-64113` 影响 `<<YOUR_SERVER_IP>`、
     `CVE-2025-64325` 影响 `<<YOUR_SERVER_IP>`，按号看都在其下但不可当结论）。
   - 改 CF 加头/限速需要带 Rules/Transform 权限的 Token，只读 Token 改不了；没有就让用户在面板点，我们给全规则内容并事后复验响应头。
   - 📌 **待并入拓扑档案**：本次审计的 `c1.thxnk.cc`（`thxnk.cc` zone，通配 `*.c1.thxnk.cc`）尚未确认是否属于
     上文 MakkaPakka 拓扑，**先不写进拓扑表**，待爸爸确认后再补。

