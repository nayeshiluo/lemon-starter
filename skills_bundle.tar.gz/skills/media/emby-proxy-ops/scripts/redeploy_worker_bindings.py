#!/usr/bin/env python3
"""生产 Cloudflare Worker bindings 安全重部署器（零代码改动 / 带回滚快照）

用途：修复被脱敏值污染的 env、把敏感变量升级为 secret_text、轮换口令，
同时保证代码逐字节不变、变量集合不丢、Cron Trigger 不掉。

设计原则（每一条都是踩过的坑）：
  1. 权威凭证源 = 本地备份 JSON，绝不是 CF API 返回值（API 会脱敏成 xxx:***）
  2. 部署前先落盘回滚快照
  3. 断言无 '***'、断言变量名集合完全相等、断言代码 md5 与生产一致
  4. 敏感项一律 secret_text（CF 之后只返回 {name,type}，物理上无法再被脱敏覆写）
  5. 部署后必须复核 bindings 类型 + Cron Trigger 仍在 + 全链路探活

用法：
    先 python3 redeploy_worker_bindings.py --dry-run   # 只做校验不部署
    再 python3 redeploy_worker_bindings.py             # 实际部署

⚠️ 升级为 secret_text 后，本地备份 JSON 成为该密钥的唯一可读副本，先确认备份完好。
"""
import argparse
import datetime
import hashlib
import json
import os
import secrets
import string
import sys
import urllib.error
import urllib.request
import uuid

# ---------------- 按项目改这一段 ----------------
ACCT = os.environ.get('CF_ACCOUNT_ID', '')
SCRIPT = os.environ.get('CF_WORKER_NAME', '')
DEPLOY_TOKEN = os.environ.get('CF_WORKERS_EDIT_TOKEN', '')   # 需 Workers:Edit
BACKUP_JSON = os.environ.get('CF_BINDINGS_BACKUP', '')       # 权威凭证源
PROD_CODE = os.environ.get('CF_PROD_CODE', '')               # 已核对过的生产代码
EXPECT_CODE_MD5 = os.environ.get('CF_PROD_CODE_MD5', '')     # 留空则跳过 md5 断言
WORKDIR = os.environ.get('CF_AUDIT_DIR', '.')

SENSITIVE = {'TG_BOT_TOKEN', 'CF_API_TOKEN', 'ADMIN_TOKEN'}
ROTATE = {'ADMIN_TOKEN'}          # 需要顺手轮换的弱口令；不想轮换就置空 set()
COMPAT_DATE = '2024-11-12'
COMPAT_FLAGS = ['nodejs_compat']
# ------------------------------------------------

API = 'https://api.cloudflare.com/client/v4'


def cf_get(path):
    req = urllib.request.Request(API + path,
                                 headers={'Authorization': f'Bearer {DEPLOY_TOKEN}'})
    return json.load(urllib.request.urlopen(req, timeout=30))


def die(msg):
    print('❌ ' + msg)
    sys.exit(1)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--dry-run', action='store_true', help='只校验不部署')
    args = ap.parse_args()

    for k, v in [('CF_ACCOUNT_ID', ACCT), ('CF_WORKER_NAME', SCRIPT),
                 ('CF_WORKERS_EDIT_TOKEN', DEPLOY_TOKEN),
                 ('CF_BINDINGS_BACKUP', BACKUP_JSON), ('CF_PROD_CODE', PROD_CODE)]:
        if not v:
            die(f'环境变量 {k} 未设置')

    # 0. 回滚快照
    cur = cf_get(f'/accounts/{ACCT}/workers/scripts/{SCRIPT}/bindings')
    if not cur.get('success'):
        die(f'读取当前 bindings 失败: {cur.get("errors")}')
    stamp = datetime.datetime.now().strftime('%Y%m%d-%H%M%S')
    snap = os.path.join(WORKDIR, f'rollback-bindings-{stamp}.json')
    json.dump(cur, open(snap, 'w'), ensure_ascii=False, indent=2)
    print(f'✅ 回滚快照: {snap}')

    cron_before = cf_get(f'/accounts/{ACCT}/workers/scripts/{SCRIPT}/schedules')
    crons = cron_before.get('result', {}).get('schedules', [])
    print(f'   部署前 Cron Trigger: {[c["cron"] for c in crons] or "无"}')

    # 1. 权威凭证源
    bk = json.load(open(BACKUP_JSON))
    items = bk if isinstance(bk, list) else bk.get('result', bk)
    src = {b['name']: b.get('text') for b in items
           if b.get('type') in ('plain_text', 'secret_text') and b.get('text')}

    # 2. 脱敏强校验（技能树铁律）
    for k, v in src.items():
        if not v or '***' in v:
            die(f'备份中 {k} 是脱敏/空值，拒绝部署')
    print(f'✅ 凭证源校验通过（{len(src)} 项，无脱敏值）')

    # 3. 弱口令轮换
    rotated = {}
    alpha = string.ascii_letters + string.digits
    for name in ROTATE:
        newv = 'Lemon' + ''.join(secrets.choice(alpha) for _ in range(15))
        src[name] = newv
        rotated[name] = newv
    if rotated:
        p = os.path.join(WORKDIR, f'rotated-secrets-{stamp}.txt')
        with open(p, 'w') as f:
            for k, v in rotated.items():
                f.write(f'{k}={v}\n')
        os.chmod(p, 0o600)
        print(f'✅ 已轮换 {list(rotated)} -> {p} (600)')

    # 4. 构造 bindings：敏感项 -> secret_text；非字符串绑定（D1/KV/R2）原样保留
    bindings = []
    for name, val in sorted(src.items()):
        bindings.append({'name': name,
                         'type': 'secret_text' if name in SENSITIVE else 'plain_text',
                         'text': val})
    for b in cur['result']:
        if b.get('type') not in ('plain_text', 'secret_text', 'inherited'):
            bindings.append(b)          # D1 / KV / R2 / Queue 等按原样带回

    for b in bindings:
        if '***' in str(b.get('text', '')):
            die('脱敏值混入 bindings，中止')

    old_names = {x['name'] for x in cur['result']}
    new_names = {b['name'] for b in bindings}
    if old_names != new_names:
        die(f'变量集合不一致！丢失={old_names - new_names} 新增={new_names - old_names}')
    n_sec = sum(1 for b in bindings if b['type'] == 'secret_text')
    print(f'✅ bindings 构造完成: {len(bindings)} 项（{n_sec} secret_text），集合与生产一致')

    # 5. 代码逐字节一致
    code = open(PROD_CODE, 'rb').read()
    md5 = hashlib.md5(code).hexdigest()
    if EXPECT_CODE_MD5 and md5 != EXPECT_CODE_MD5:
        die(f'代码 md5 不符: {md5} != {EXPECT_CODE_MD5}')
    print(f'✅ 代码 md5 {md5}（本次零代码改动）')

    if args.dry_run:
        print('\n🧪 dry-run 结束，未部署。')
        return

    # 6. 手工 multipart PUT（compatibility 必须显式带上，否则会被重置）
    metadata = {'main_module': 'worker.js', 'bindings': bindings,
                'compatibility_date': COMPAT_DATE, 'compatibility_flags': COMPAT_FLAGS}
    bound = '----Boundary' + uuid.uuid4().hex

    def part(name, filename, ctype, payload):
        h = (f'--{bound}\r\nContent-Disposition: form-data; name="{name}"; '
             f'filename="{filename}"\r\nContent-Type: {ctype}\r\n\r\n').encode()
        return h + payload + b'\r\n'

    body = part('metadata', 'metadata.json', 'application/json',
                json.dumps(metadata).encode())
    body += part('worker.js', 'worker.js', 'application/javascript+module', code)
    body += f'--{bound}--\r\n'.encode()

    req = urllib.request.Request(
        f'{API}/accounts/{ACCT}/workers/scripts/{SCRIPT}', data=body, method='PUT',
        headers={'Authorization': f'Bearer {DEPLOY_TOKEN}',
                 'Content-Type': f'multipart/form-data; boundary={bound}'})
    try:
        r = json.load(urllib.request.urlopen(req, timeout=120))
    except urllib.error.HTTPError as e:
        r = json.loads(e.read().decode())

    if not r.get('success'):
        die(f'部署失败: {r.get("errors")}  可用快照回滚: {snap}')
    print(f'✅ 部署成功 modified_on={r.get("result", {}).get("modified_on")}')

    # 7. 部署后复核
    after = cf_get(f'/accounts/{ACCT}/workers/scripts/{SCRIPT}/bindings')
    print('\n=== 部署后 bindings ===')
    for b in after.get('result', []):
        shown = b.get('text', '<hidden>')
        print(f'  {b["name"]:18s} {b["type"]:12s} {shown}')
        if '***' in str(b.get('text', '')):
            print(f'  ⚠️ {b["name"]} 仍为脱敏值！')

    cron_after = cf_get(f'/accounts/{ACCT}/workers/scripts/{SCRIPT}/schedules')
    ca = [c['cron'] for c in cron_after.get('result', {}).get('schedules', [])]
    cb = [c['cron'] for c in crons]
    print(f'\nCron Trigger: 前={cb} 后={ca} ' + ('✅' if ca == cb else '⚠️ 变化了，需手工恢复'))

    print('\n下一步：按 references/worker-deobfuscation-and-tg-verification.md '
          '第四节做端到端硬证据验证（webhook 灌注 + message_id 探测）。'
          '部署 API 返回 success 不等于业务已恢复。')


if __name__ == '__main__':
    main()
