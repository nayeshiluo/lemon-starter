#!/usr/bin/env bash
# 容器内 Nginx 配置灰度上线 + 失败自动回滚
#
# 用法（在承载反代的宿主机上执行）：
#   1. 先把新配置上传到 $NEW
#   2. 先跑 --dry 做一次性容器语法预检（完全不碰生产）
#   3. 再不带参数执行，走「基线 -> 应用 -> reload -> 回归 -> 失败自动回滚」闭环
#
#   bash nginx-gray-deploy.sh --dry
#   bash nginx-gray-deploy.sh
#
# 按需修改下面 5 个变量即可复用到任何 nginx 容器反代。

set -u

CONTAINER="${CONTAINER:-lemon-emos-proxy}"
CONF="${CONF:-/home/ubuntu/docker-nodes/emos-proxy/conf/nginx.conf}"
NEW="${NEW:-/tmp/nginx.new.conf}"
PORT="${PORT:-8096}"
IMAGE="${IMAGE:-nginx:alpine}"

UA="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"

# ── 一次性容器语法预检：完全不影响生产 ──────────────────────
if [ "${1:-}" = "--dry" ]; then
  echo "=== 一次性容器语法预检（不碰生产）==="
  docker run --rm -v "$NEW":/etc/nginx/nginx.conf:ro "$IMAGE" nginx -t 2>&1 \
    | grep -E 'emerg|warn|successful'
  exit $?
fi

# ── 备份 / 回滚点 ─────────────────────────────────────────
cp "$CONF" "${CONF}.bak-$(date +%Y%m%d-%H%M%S)" || { echo "备份失败"; exit 1; }
BAK=$(ls -t "${CONF}".bak-* 2>/dev/null | head -1)
echo "回滚点: $BAK"

# ⚠️ 期望码断言。curl 默认 UA 可能被 Cloudflare BIC(1010) 拦，一律带浏览器 UA。
probe() {   # $1=path  $2=期望码  $3=描述
  local code
  code=$(curl -s -o /tmp/p.out --max-time 20 -H "User-Agent: $UA" \
         -w "%{http_code}" "http://127.0.0.1:${PORT}$1")
  printf "  %-46s HTTP:%s" "$3" "$code"
  if [ "$code" = "$2" ]; then echo "  OK"; else echo "  FAIL (期望 $2)"; return 1; fi
}

echo "=== 上线前基线 ==="
probe "/System/Info/Public"      200 "根路径补全 /emby"
probe "/emby/System/Info/Public" 200 "带前缀 /emby/"
probe "/Items/Counts"            200 "Counts"

echo
echo "=== 应用新配置 ==="
cp "$NEW" "$CONF" || { echo "复制失败"; exit 1; }

# ⚠️⚠️ 致命陷阱：nginx -t 把结果写 stderr。
# 写成 `2>/dev/null | grep -q successful` 会永远失配 -> 明明语法正确却触发假回滚。
# 必须用 2>&1。
docker exec "$CONTAINER" nginx -t 2>&1 | grep -E 'emerg|successful'
if ! docker exec "$CONTAINER" nginx -t 2>&1 | grep -q successful; then
  echo "容器内语法检查失败，立即回滚"
  cp "$BAK" "$CONF"; exit 1
fi

docker exec "$CONTAINER" nginx -s reload && echo "reload 完成" && sleep 3

echo
echo "=== 上线后回归 ==="
FAIL=0
probe "/System/Info/Public"      200 "根路径补全 /emby"   || FAIL=1
probe "/emby/System/Info/Public" 200 "带前缀 /emby/"      || FAIL=1
probe "/Items/Counts"            200 "Counts"             || FAIL=1
probe "/emby/Items/Counts"       200 "Counts(带前缀)"     || FAIL=1

# 图片缓存生效验证：连打两次，第二次应 HIT
IMG="/emby/Items/1/Images/Primary"
curl -s -o /dev/null --max-time 20 -H "User-Agent: $UA" "http://127.0.0.1:${PORT}${IMG}"
H=$(curl -s -o /dev/null --max-time 20 -H "User-Agent: $UA" -D /tmp/h.txt \
      "http://127.0.0.1:${PORT}${IMG}"; grep -i '^x-cache-status' /tmp/h.txt | tr -d '\r')
echo "  图片缓存二次请求: ${H:-无 X-Cache-Status 头}"

echo
if [ "$FAIL" = "1" ]; then
  echo "回归存在失败项，执行自动回滚"
  cp "$BAK" "$CONF" && docker exec "$CONTAINER" nginx -s reload && echo "已回滚到 $BAK"
  exit 1
fi
echo "全部回归通过，新配置已生效"
