#!/usr/bin/env python3
"""EMOS/R2 并发分片上传改造的离线验证夹具（不连生产）。

用途：改完 upload_to_emos 的分片循环后，先在本地证明正确性，再上生产。
本地起一个模拟 EMOS API 的 HTTP 服务，把模块级 BASE_URL 指过来，跑**真实**的
upload_to_emos() 代码路径，断言四件事：

  1. parts 按分片号升序连续提交（并发乱序完成也不影响）
  2. etag 与分片号一一对应
  3. 真的发生了并发（同时进行的 PUT > 1）
  4. 分片字节数正确、内容未串片；任一分片彻底失败时 fail-fast 抛异常而非静默成功

用法：
    python3 verify_emos_parallel_upload.py [上传器目录] [上传器模块名]

默认参数适配 /root/emos_uploader.py。上传器依赖 smart_media_parser / tmdb_helper
等兄弟模块，所以要把上传器所在目录加进 sys.path —— 在**上传器本机**跑最省事。

注意：本夹具只 mock 网络，不 mock 分片逻辑，所以能抓到「共享文件句柄导致串片」
「parts 未排序」这类真实 bug。
"""
import hashlib
import importlib
import json
import os
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

UPLOADER_DIR = sys.argv[1] if len(sys.argv) > 1 else "/root"
UPLOADER_MOD = sys.argv[2] if len(sys.argv) > 2 else "emos_uploader"
sys.path.insert(0, UPLOADER_DIR)

PORT = 18099
PART = 10 * 1024 * 1024
FILE_SIZE = 25 * 1024 * 1024 + 12345  # 3 片：10MB / 10MB / 余数（余数片最容易被漏判）
TEST_FILE = "/tmp/_emos_parallel_test.bin"

state = {
    "parts_received": {},   # number -> (len, md5)
    "complete_parts": None,  # complete 收到的 parts 数组
    "concurrent_now": 0,
    "concurrent_max": 0,
    "fail_part": None,
    "delay": {},
}
lock = threading.Lock()


class H(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, *a):
        pass

    def _send(self, code, obj=None, raw=b"", headers=None):
        body = raw if raw else (json.dumps(obj).encode() if obj is not None else b"")
        self.send_response(code)
        for k, v in (headers or {}).items():
            self.send_header(k, v)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        if body:
            self.wfile.write(body)

    def do_POST(self):
        n = int(self.headers.get("Content-Length") or 0)
        body = self.rfile.read(n) if n else b""
        p = self.path
        if p.endswith("/api/upload/getUploadToken"):
            return self._send(200, {"file_id": "F1", "data": {
                "multipart_size": {"min": PART, "max": 5 * 1024 ** 3}}})
        if p.endswith("/presign"):
            total = json.loads(body)["number"]
            return self._send(200, [{"number": i,
                                     "upload_url": f"http://127.0.0.1:{PORT}/put/{i}"}
                                    for i in range(1, total + 1)])
        if p.endswith("/complete"):
            state["complete_parts"] = json.loads(body)["parts"]
            return self._send(200, {"ok": True})
        if p.endswith("/api/upload/video/save"):
            return self._send(200, {"ok": True})
        return self._send(404, {"msg": "no"})

    def do_GET(self):
        if "/api/upload/video/base" in self.path:
            return self._send(200, {"video_medias": [{"id": 1}]})
        return self._send(404, {"msg": "no"})

    def do_DELETE(self):
        return self._send(200, {})

    def do_PUT(self):
        part = int(self.path.rsplit("/", 1)[-1])
        n = int(self.headers.get("Content-Length") or 0)
        data = self.rfile.read(n)
        with lock:
            state["concurrent_now"] += 1
            state["concurrent_max"] = max(state["concurrent_max"], state["concurrent_now"])
        try:
            if state["fail_part"] == part:
                time.sleep(0.05)
                return self._send(500, {"msg": "boom"})
            # 故意让前面的分片最慢、后面的最快，制造完成顺序倒挂
            time.sleep(state["delay"].get(part, 0.05))
            with lock:
                state["parts_received"][part] = (len(data), hashlib.md5(data).hexdigest())
            return self._send(200, raw=b"", headers={"ETag": f'"etag-{part}"'})
        finally:
            with lock:
                state["concurrent_now"] -= 1


def build_file(path):
    with open(path, "wb") as f:
        for i in range(0, FILE_SIZE, 1024 * 1024):
            f.write(bytes([(i // 1024 // 1024) % 256]) * min(1024 * 1024, FILE_SIZE - i))


def run_case(name, workers, fail_part=None, delay=None):
    state["parts_received"] = {}
    state["complete_parts"] = None
    state["concurrent_max"] = 0
    state["concurrent_now"] = 0
    state["fail_part"] = fail_part
    state["delay"] = delay or {}

    os.environ["EMOS_UPLOAD_WORKERS"] = str(workers)
    mod = importlib.reload(importlib.import_module(UPLOADER_MOD))
    mod.BASE_URL = f"http://127.0.0.1:{PORT}"
    mod.identify_video = lambda fn: {
        "success": True, "item_type": "ve", "item_id": 999, "title": "TEST"}

    ok, err = True, None
    t0 = time.time()
    try:
        mod.upload_to_emos(TEST_FILE, custom_filename="TEST.S01E01.mkv")
    except Exception as e:
        ok, err = False, f"{type(e).__name__}: {str(e)[:120]}"
    dur = time.time() - t0

    print(f"\n=== {name} (workers={workers}) ===")
    print(f"  耗时 {dur:.2f}s  并发峰值 {state['concurrent_max']}  成功 {ok}  错误 {err}")
    if not ok:
        return False

    cp = state["complete_parts"] or []
    nums = [p["number"] for p in cp]
    etags_ok = all(p["etag"] == f"etag-{p['number']}" for p in cp)
    sizes = sorted(state["parts_received"].items())
    expect_last = FILE_SIZE - PART * (len(nums) - 1)

    with open(TEST_FILE, "rb") as f:
        content_ok = True
        for num, (ln, md5) in sizes:
            f.seek((num - 1) * PART)
            if hashlib.md5(f.read(ln)).hexdigest() != md5:
                content_ok = False

    checks = {
        "顺序升序连续": nums == list(range(1, len(nums) + 1)),
        "etag 对应": etags_ok,
        "末片为余数": bool(sizes) and sizes[-1][1][0] == expect_last,
        "总字节吻合": sum(s[1][0] for s in sizes) == FILE_SIZE,
        "未串片": content_ok,
    }
    for k, v in checks.items():
        print(f"  {'✓' if v else '✗'} {k}")
    return all(checks.values())


if __name__ == "__main__":
    build_file(TEST_FILE)
    srv = ThreadingHTTPServer(("127.0.0.1", PORT), H)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    time.sleep(0.3)

    results = [
        run_case("串行基线", 1),
        run_case("并发乱序", 5, delay={1: 1.2, 2: 0.6, 3: 0.05}),
        not run_case("分片失败 fail-fast", 4, fail_part=2),  # 必须失败才算通过
    ]
    print("\n" + "=" * 52)
    print(f"总体 {'全部通过' if all(results) else '存在失败项'}  {results}")
    srv.shutdown()
    sys.exit(0 if all(results) else 1)
