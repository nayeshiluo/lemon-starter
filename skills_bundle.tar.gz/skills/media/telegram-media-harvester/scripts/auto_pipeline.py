import sys
import os
import time
import random
import sqlite3
import logging
import asyncio

sys.path.insert(0, '/home/ubuntu/lemon-media-spider')
from spider import DB_PATH, init_db
from lemon_crawler import crawl_and_sync_all
from sync_all_adult import sync_adult_channels
from scheduled_sync_and_clean import sync_and_purify_guangya

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(message)s'
)
logger = logging.getLogger("LemonAutoPipeline")

def run_pipeline():
    logger.info("=" * 60)
    logger.info("🚀 启动【柠檬影视资源全自动增量抓取、云盘入库与净化闭环流水线】")
    logger.info("=" * 60)
    
    # 1. 增量抓取影视、动漫、常规成人
    try:
        logger.info("[1/3] 📡 正在执行常规影视、动漫及基础频道增量爬取...")
        crawl_and_sync_all()
    except Exception as e:
        logger.error(f"[-] 常规频道爬取异常: {e}")

    # 2. 增量抓取 18+ 矩阵频道
    try:
        logger.info("[2/3] 🔞 正在执行 18+ 矩阵频道增量爬取...")
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        loop.run_until_complete(sync_adult_channels())
        loop.close()
    except Exception as e:
        logger.error(f"[-] 18+ 频道爬取异常: {e}")

    # 3. 推送未入库资源至光鸭云盘并执行深度广告净化
    try:
        logger.info("[3/3] ☁️ 正在执行光鸭云盘离线任务下发与全盘净化守护...")
        sync_and_purify_guangya()
    except Exception as e:
        logger.error(f"[-] 光鸭云盘同步与净化异常: {e}")

    logger.info("=" * 60)
    logger.info("✨ 【全自动流水线闭环执行完毕】")
    logger.info("=" * 60)

if __name__ == '__main__':
    run_pipeline()
