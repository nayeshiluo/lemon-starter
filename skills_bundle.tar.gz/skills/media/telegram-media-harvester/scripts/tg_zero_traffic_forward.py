"""
柠檬 TG 零流量极速转发与云库同步模块
原理：直接在 Telegram 云端执行 forward_messages，毫秒级复制消息与视频指针，本地 0 流量消耗。
"""
import sys
import os
import asyncio
import logging
import sqlite3

sys.path.insert(0, '/home/ubuntu/lemon-media-spider')
from isolated_tg import IsolatedTelegramClient

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(message)s'
)
logger = logging.getLogger("LemonZeroTrafficForward")

DB_PATH = '/home/ubuntu/lemon-media-spider/resources.db'

def init_forward_table():
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute('''
        CREATE TABLE IF NOT EXISTS tg_forward_records (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            source_channel TEXT,
            msg_id INTEGER,
            dest_target TEXT,
            forward_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            UNIQUE(source_channel, msg_id, dest_target)
        )
    ''')
    conn.commit()
    conn.close()

async def forward_channel_videos(source_channel_id, dest_target, limit=30):
    """
    零流量转发指定频道最新的带视频/媒体消息到目标（私有频道、Bot、Saved Messages）
    dest_target 可以是频道 ID / username / 'me' (收藏夹) / '@PikPak_Bot'
    """
    init_forward_table()
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    
    forwarded_count = 0
    async with IsolatedTelegramClient(prefix="tg_forward") as client:
        try:
            source_entity = await client.get_entity(source_channel_id)
            dest_entity = await client.get_entity(dest_target)
            logger.info(f"[*] 开始检查源频道 [{source_channel_id}] -> 目标 [{dest_target}] 极速转发...")
            
            messages = await client.get_messages(source_entity, limit=limit)
            for msg in reversed(messages):
                if not msg or not (msg.video or msg.document or msg.media):
                    continue
                
                # 检查是否已转发过
                c.execute('SELECT 1 FROM tg_forward_records WHERE source_channel = ? AND msg_id = ? AND dest_target = ?',
                          (str(source_channel_id), msg.id, str(dest_target)))
                if c.fetchone():
                    continue
                
                # 毫秒级秒转发（TG 云端直接复制，0 本地流量）
                await client.forward_messages(dest_entity, msg)
                c.execute('INSERT OR IGNORE INTO tg_forward_records (source_channel, msg_id, dest_target) VALUES (?, ?, ?)',
                          (str(source_channel_id), msg.id, str(dest_target)))
                conn.commit()
                forwarded_count += 1
                logger.info(f"  [✓] 毫秒级秒转完成: 消息 ID {msg.id}")
                await asyncio.sleep(0.5) # 极轻微避频
                
        except Exception as e:
            logger.error(f"[-] 转发异常: {e}")
        finally:
            conn.close()
            
    logger.info(f"[🎉] 本轮极速秒转完成，共转存 {forwarded_count} 个新视频，本地消耗流量: 0 KB")
    return forwarded_count

if __name__ == '__main__':
    target = sys.argv[1] if len(sys.argv) > 1 else 'me'
    channel = sys.argv[2] if len(sys.argv) > 2 else 'SQDM_A'
    asyncio.run(forward_channel_videos(channel, target, limit=5))
