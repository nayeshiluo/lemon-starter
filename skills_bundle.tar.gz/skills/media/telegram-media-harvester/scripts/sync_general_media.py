import sys
import os
import re
import time
import random
import sqlite3
import logging
import urllib.request
import urllib.parse
from bs4 import BeautifulSoup

sys.path.insert(0, '/home/ubuntu/lemon-media-spider')
from spider import DB_PATH, init_db, parse_magnet_hash, clean_name
from guangya_client import api_request
from update_categories import ensure_all_folders, FOLDER_MAP
from refresh_token import refresh_guangya_token

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(message)s'
)
logger = logging.getLogger("LemonGeneralMediaSync")

CHANNELS = {
    'movie': {
        'username': 'dyttcili',
        'folder_key': 'movie',
        'name': '🎬 电影精选',
        'tag': '电影'
    },
    'tv': {
        'username': 'zhuizhuiju',
        'folder_key': 'tv',
        'name': '📺 剧集更新',
        'tag': '剧集'
    },
    'anime': {
        'username': 'dmhyshare',
        'folder_key': 'anime',
        'name': '🌸 动漫专区',
        'tag': '动漫'
    }
}

def clean_anime_title(raw_text):
    first_line = raw_text.split('\n')[0].strip()
    t = re.sub(r'https?://[^\s]+', '', first_line)
    t = re.sub(r'[\\/:\*\?"<>\|]', ' ', t)
    t = re.sub(r'\s+', ' ', t).strip()
    return t[:90] if len(t) > 90 else t

def clean_media_title(raw_text, category_type):
    if category_type == 'tv':
        t_match = re.search(r'《([^》]+)》', raw_text)
        if t_match:
            title = t_match.group(1).strip()
        else:
            title = raw_text.split('\n')[0].strip()
    elif category_type == 'movie':
        pm_match = re.search(r'片名:\s*([^\n]+)', raw_text)
        ym_match = re.search(r'译名:\s*([^\n]+)', raw_text)
        t_match = re.search(r'《([^》]+)》', raw_text)
        if pm_match:
            title = pm_match.group(1).strip()
        elif t_match:
            title = t_match.group(1).strip()
        elif ym_match:
            title = ym_match.group(1).split('/')[0].strip()
        else:
            title = raw_text.split('\n')[0].strip()
    else: # anime
        title = clean_anime_title(raw_text)

    title = re.sub(r'\[电影天堂[^\]]*\]', '', title)
    title = re.sub(r'www\.[a-zA-Z0-9\.\-_]+', '', title, flags=re.IGNORECASE)
    title = re.sub(r'[《》【】]', ' ', title).strip()
    title = re.sub(r'\s+', ' ', title)
    return title

def scrape_channel_paged(channel_username, category_type, pages=5):
    base_url = f"https://t.me/s/{channel_username}"
    collected = []
    current_url = base_url

    for p in range(pages):
        req = urllib.request.Request(current_url, headers={
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
        })
        try:
            with urllib.request.urlopen(req, timeout=15) as resp:
                html = resp.read().decode('utf-8', errors='ignore')
        except Exception as e:
            logger.warning(f"[-] 抓取 @{channel_username} (第 {p+1} 页) 异常: {e}")
            break

        soup = BeautifulSoup(html, 'html.parser')
        messages = soup.find_all('div', class_='tgme_widget_message_wrap')
        if not messages:
            break

        first_msg_id = None
        page_items = 0
        for wrap in messages:
            msg_div = wrap.find('div', class_='tgme_widget_message')
            if not msg_div:
                continue
            data_post = msg_div.get('data-post', '')
            msg_id = data_post.split('/')[-1] if '/' in data_post else ''
            if not first_msg_id and msg_id:
                first_msg_id = msg_id

            text_div = wrap.find('div', class_='tgme_widget_message_text')
            if not text_div:
                continue
            raw_text = text_div.get_text('\n')

            mag_matches = re.findall(r'(magnet:\?xt=urn:btih:[a-zA-Z0-9]+[^\s\n"\'<>]*)', raw_text, re.IGNORECASE)
            if not mag_matches:
                for a_tag in text_div.find_all('a', href=True):
                    href = a_tag['href']
                    if href.lower().startswith('magnet:'):
                        mag_matches.append(href)

            if not mag_matches:
                continue

            for mag in mag_matches:
                mag = mag.strip()
                mag_hash = parse_magnet_hash(mag)
                if not mag_hash:
                    continue

                year = ""
                y_match = re.search(r'(\b19\d\d|\b20\d\d)年?', raw_text)
                if y_match:
                    year = y_match.group(1)

                rating = ""
                r_match = re.search(r'豆瓣[（\(]([\d\.]+)分[）\)]|([\d\.]+)分', raw_text)
                if r_match:
                    rating = r_match.group(1) or r_match.group(2)

                title = clean_media_title(raw_text, category_type)
                if not title:
                    title = f"未命名_{mag_hash[:8]}"

                year_suffix = f" ({year})" if year and year not in title else ""
                clean_fn = f"{title}{year_suffix}.mp4"

                collected.append({
                    'channel': channel_username,
                    'msg_id': msg_id,
                    'title': title,
                    'year': year,
                    'category_type': category_type,
                    'rating': rating or CHANNELS[category_type]['tag'],
                    'magnet': mag,
                    'magnet_hash': mag_hash,
                    'original_filename': '',
                    'clean_filename': clean_fn
                })
                page_items += 1

        logger.info(f"[+] @{channel_username} 第 {p+1} 页解析完成，发现 {page_items} 条磁力资源")
        
        if first_msg_id:
            current_url = f"{base_url}?before={first_msg_id}"
            time.sleep(1.2)
        else:
            break

    return collected
