import os
import sys
import fcntl
import logging

class ProcessLock:
    """
    基于 fcntl.flock 的单实例进程排他互斥锁：
    防止长耗时转存或爬虫因调度重叠产生并发堆叠、带宽争抢与 Session 冲突。
    """
    def __init__(self, lock_name):
        self.lock_file = f"/tmp/{lock_name}.lock"
        self.fp = None

    def __enter__(self):
        try:
            self.fp = open(self.lock_file, "w")
            fcntl.flock(self.fp.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
            self.fp.write(str(os.getpid()))
            self.fp.flush()
            return self
        except (IOError, BlockingIOError):
            logging.warning(f"⚠️ [互斥锁提示] 上一个任务实例仍未结束 (Lock: {self.lock_file})，本次调度安全跳过，防止冲突。")
            sys.exit(0)

    def __exit__(self, exc_type, exc_val, exc_tb):
        if self.fp:
            try:
                fcntl.flock(self.fp.fileno(), fcntl.LOCK_UN)
                self.fp.close()
                if os.path.exists(self.lock_file):
                    os.remove(self.lock_file)
            except Exception:
                pass
