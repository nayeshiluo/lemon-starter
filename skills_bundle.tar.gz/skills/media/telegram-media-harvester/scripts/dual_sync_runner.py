import sys
import os
import time
import random
import logging
import asyncio

sys.path.insert(0, '/home/ubuntu/lemon-media-spider')
from lifan_channel_sync import run_all_lifan_sync
from ai_short_sync import run_all_ai_sync

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(message)s'
)
logger = logging.getLogger("LemonDualSync")

async def run_full_dual_sync():
    logger.info("=" * 60)
    logger.info("🌸 启动【里番 & AI短剧 双轨云盘（光鸭+Google Drive）慢速转存守护】")
    logger.info("=" * 60)

    # 1. 里番专区双轨转存
    try:
        logger.info("[1/2] 🔞 开始巡检并转存里番频道 (@SQDM_A, @lifankankan)...")
        await run_all_lifan_sync()
    except Exception as e:
        logger.error(f"[-] 里番双轨转存异常: {e}")

    await asyncio.sleep(random.uniform(10.0, 20.0))

    # 2. AI短剧专区双轨转存
    try:
        logger.info("[2/2] 🎬 开始巡检并转存 AI短剧频道 (@YJTJSC, @AIRVIP8, @bjcvnjkm)...")
        await run_all_ai_sync()
    except Exception as e:
        logger.error(f"[-] AI短剧双轨转存异常: {e}")

    logger.info("=" * 60)
    logger.info("✨ 【双轨云盘转存本轮巡检全部完成】")
    logger.info("=" * 60)

if __name__ == '__main__':
    asyncio.run(run_full_dual_sync())
