import urllib.request
import urllib.parse
import re
import sqlite3
from bs4 import BeautifulSoup

def parse_magnet_hash(magnet):
    m = re.search(r'xt=urn:btih:([a-zA-Z0-9]+)', magnet, re.IGNORECASE)
    return m.group(1).upper() if m else None

def clean_filename(title, year, ext=".mp4"):
    clean_t = re.sub(r'[《》\[\]【】\s_]+', ' ', title).strip()
    clean_t = re.sub(r'www\.[a-zA-Z0-9\.\-_]+', '', clean_t, flags=re.IGNORECASE).strip()
    clean_t = re.sub(r'电影天堂', '', clean_t).strip()
    year_str = f" ({year})" if year and year not in clean_t else ""
    return f"{clean_t}{year_str}{ext}"

def scrape_channel(channel_username):
    url = f"https://t.me/s/{channel_username}"
    req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            html = resp.read().decode('utf-8', errors='ignore')
    except Exception as e:
        return []

    soup = BeautifulSoup(html, 'html.parser')
    messages = soup.find_all('div', class_='tgme_widget_message_wrap')
    results = []
    
    for wrap in messages:
        text_div = wrap.find('div', class_='tgme_widget_message_text')
        if not text_div:
            continue
        raw_text = text_div.get_text('\n')
        m_match = re.search(r'(magnet:\?xt=urn:btih:[^\s\n"\'<>]+)', raw_text, re.IGNORECASE)
        if not m_match:
            continue
        magnet = m_match.group(1).strip()
        mag_hash = parse_magnet_hash(magnet)
        if not mag_hash:
            continue
            
        t_match = re.search(r'《([^》]+)》', raw_text)
        title = t_match.group(1).strip() if t_match else raw_text.split('\n')[0].strip()[:50]
        y_match = re.search(r'(\b19\d\d|\b20\d\d)年?', raw_text)
        year = y_match.group(1) if y_match else ""
        
        results.append({
            'channel': channel_username,
            'title': title,
            'year': year,
            'magnet': magnet,
            'magnet_hash': mag_hash,
            'clean_filename': clean_filename(title, year)
        })
    return results
