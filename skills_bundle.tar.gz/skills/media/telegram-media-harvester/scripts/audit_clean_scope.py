"""只读审计：光鸭专区里「现行清理规则会删什么」vs「实际有多少广告垃圾」。

绝不删除任何文件。按分类统计四类：
  junk_non_media          扩展名非媒体/字幕/图片 —— 现行规则唯一会选中的候选
  video_promo_name        文件名带广告关键词的视频 —— 现行规则只计数、明确保留
  video_watermark_prefix  文件名带站点水印前缀的视频 —— 现行规则原样保留
  video_clean             干净正片

用途：判断「清理一直有问题」是规则失效、还是接口字段漏项、还是根本没垃圾。
若 junk_non_media 与 video_promo_name 长期同时为 0，先怀疑 resType/fileId 判定。

用法：
    python audit_clean_scope.py av fuliji
    python audit_clean_scope.py            # 默认只扫 av

注意：单专区 10~45 分钟，全盘可能 75 分钟，放后台跑并落日志。
"""
import collections
import os
import sys

BASE = os.environ.get("LEMON_MEDIA_SPIDER_DIR", "/home/ubuntu/lemon-media-spider")
sys.path.insert(0, BASE)

from guangya_client import check_api_health                      # noqa: E402
from cleanup_preview import ensure_all_folders                   # noqa: E402
from update_categories import FOLDER_MAP                         # noqa: E402
from video_only_cleaner import _list_children, CATEGORIES        # noqa: E402
from media_file_policy import RETAINED_EXTENSIONS, VIDEO_EXTENSIONS  # noqa: E402
from ingest_guard import promotion_reason, strip_site_watermark  # noqa: E402


def walk(folder_id, label, stats, seen, samples, depth=0):
    if not folder_id or str(folder_id) in seen or depth > 64:
        return
    seen.add(str(folder_id))
    for item in _list_children(folder_id, label):
        fid = item.get("fileId") or item.get("id")
        name = str(item.get("fileName") or item.get("name") or "")
        if not fid or not name:
            continue
        if item.get("resType") == 2:
            stats["folders"] += 1
            walk(fid, label + "/" + name, stats, seen, samples, depth + 1)
            continue
        stats["files"] += 1
        ext = os.path.splitext(name.lower())[1]
        marker = promotion_reason(name)
        watermark = strip_site_watermark(name)
        if ext not in RETAINED_EXTENSIONS:
            stats["junk_non_media"] += 1
            samples["junk_non_media"].append(label + "/" + name)
        elif ext in VIDEO_EXTENSIONS and marker:
            stats["video_promo_name"] += 1
            samples["video_promo_name"].append(label + "/" + name)
        elif ext in VIDEO_EXTENSIONS and watermark:
            stats["video_watermark_prefix"] += 1
            samples["video_watermark_prefix"].append(label + "/" + name)
        elif ext not in VIDEO_EXTENSIONS:
            stats["sidecar"] += 1
        else:
            stats["video_clean"] += 1
    seen.remove(str(folder_id))


def main(categories):
    check_api_health()
    folders = ensure_all_folders()
    grand = collections.Counter()
    all_samples = collections.defaultdict(list)
    for key in categories:
        fid = folders.get(key)
        if not fid:
            print("SKIP missing folder:", key)
            continue
        stats = collections.Counter()
        samples = collections.defaultdict(list)
        walk(fid, FOLDER_MAP.get(key, key), stats, set(), samples)
        grand.update(stats)
        for k, v in samples.items():
            all_samples[k].extend(v[:5])
        print("CATEGORY %s %s" % (key, dict(stats)))
    print("TOTAL %s" % dict(grand))
    for k, v in all_samples.items():
        print("SAMPLES %s:" % k)
        for line in v[:10]:
            print("   ", line)


if __name__ == "__main__":
    main(sys.argv[1:] or ["av"])
