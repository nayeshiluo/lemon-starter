#!/usr/bin/env python3
"""光鸭离线任务状态探针（只读 + 可选重推）。

用途：验证「下发」是否真的成功。create_task 返回 taskId 不等于成功，
必须回查 list_task 的 status：2=成功 / 3=失败 / 1=进行中。

用法：
  # 1) 查某个 taskId 的最终状态（轮询，默认 150s）
  python3 probe_offline_task_status.py --task-id 1962795605999857705

  # 2) 重推 DB 里某条资源并跟踪状态（用于复现单文件/多文件种子差异）
  python3 probe_offline_task_status.py --resource-id 17430

  # 3) 列出近 N 小时所有非成功任务，快速看是哪一类在失败
  python3 probe_offline_task_status.py --recent-hours 2

注意：
  - list_task 必须 POST，GET 会 404。
  - 单文件种子（resolve_res 无 subfiles）必须**不带** fileIndexes，
    带 [0] 或 [1] 都会 status=3。本脚本重推时走 add_offline_task 的
    正常门禁路径，可用来验证该行为是否仍然成立。
  - 绝不修改 DB 的 pushed_to_guangya，除非显式传 --mark-pushed。
"""
import argparse
import sqlite3
import sys
import time

sys.path.insert(0, '/home/ubuntu/lemon-media-spider')

import guangya_client as g  # noqa: E402

DB_PATH = '/home/ubuntu/lemon-media-spider/resources.db'
STATUS_LABEL = {1: '进行中', 2: '成功', 3: '失败', 5: '排队/其他'}


def find_task(task_id, max_pages=8, page_size=100):
    """翻页找 taskId，返回 task dict 或 None。"""
    for page in range(max_pages):
        resp = g.api_request('/cloudcollection/v1/list_task', method='POST',
                             data={'page': page, 'pageSize': page_size})
        data = resp.get('data') or {}
        items = data.get('list') or []
        if not items:
            return None
        for it in items:
            if str(it.get('taskId')) == str(task_id):
                return it
        if not data.get('hasMore'):
            return None
    return None


def watch(task_id, timeout=150, interval=20):
    deadline = time.time() + timeout
    last = None
    while time.time() < deadline:
        it = find_task(task_id)
        if it:
            last = it
            st = it.get('status')
            print('  status=%s (%s) %s' % (st, STATUS_LABEL.get(st, '?'),
                                           (it.get('fileName') or '')[:50]))
            if st in (2, 3):
                return it
        else:
            print('  taskId 尚未出现在列表里（可能仍在排队）')
        time.sleep(interval)
    return last


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--task-id')
    ap.add_argument('--resource-id', type=int)
    ap.add_argument('--recent-hours', type=float)
    ap.add_argument('--timeout', type=int, default=150)
    ap.add_argument('--mark-pushed', action='store_true')
    args = ap.parse_args()

    if args.recent_hours:
        cutoff = time.time() - args.recent_hours * 3600
        seen, bad = 0, 0
        for page in range(5):
            resp = g.api_request('/cloudcollection/v1/list_task', method='POST',
                                 data={'page': page, 'pageSize': 100})
            data = resp.get('data') or {}
            items = data.get('list') or []
            if not items:
                break
            for it in items:
                if it.get('createTime', 0) < cutoff:
                    continue
                seen += 1
                if it.get('status') != 2:
                    bad += 1
                    print('status=%s %s %s' % (
                        it.get('status'),
                        time.strftime('%H:%M', time.localtime(it.get('createTime', 0))),
                        (it.get('fileName') or '')[:52]))
        print('近 %sh 任务 %d 条，非成功 %d 条' % (args.recent_hours, seen, bad))
        return

    task_id = args.task_id
    res_id = args.resource_id

    if res_id:
        from update_categories import ensure_all_folders
        conn = sqlite3.connect(DB_PATH)
        row = conn.execute(
            'SELECT id,categories,magnet,clean_filename,magnet_hash '
            'FROM resources WHERE id=?', (res_id,)).fetchone()
        if not row:
            print('DB 里没有 id=%s' % res_id)
            return
        fids = ensure_all_folders()
        fid = fids.get(row[1])
        if not fid:
            print('分类 %r 不在 FOLDER_MAP，拒绝下发（防污染根目录）' % row[1])
            return
        print('重推 id=%s cat=%s %s' % (row[0], row[1], (row[3] or '')[:50]))
        resp = g.add_offline_task(row[2], folder_id=fid, category=row[1],
                                  filename=row[3], magnet_hash=row[4])
        task_id = (resp.get('data') or {}).get('taskId')
        print('taskId=%s' % task_id)
        if task_id and args.mark_pushed:
            conn.execute('UPDATE resources SET pushed_to_guangya=1 WHERE id=?', (res_id,))
            conn.commit()
            print('已标记 pushed_to_guangya=1')
        conn.close()

    if not task_id:
        print('需要 --task-id 或 --resource-id')
        return

    print('跟踪 taskId=%s（最多 %ss）...' % (task_id, args.timeout))
    final = watch(task_id, timeout=args.timeout)
    if final is None:
        print('结论：超时未见该任务，不要报成功')
    elif final.get('status') == 2:
        print('结论：status=2 成功')
    else:
        print('结论：status=%s 非成功，查是否传了 fileIndexes（单文件种子必须不传）'
              % final.get('status'))


if __name__ == '__main__':
    main()
