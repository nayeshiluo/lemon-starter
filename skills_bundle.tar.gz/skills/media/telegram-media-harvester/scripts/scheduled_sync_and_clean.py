import sys
import os
import time
import random
import sqlite3
import logging

sys.path.insert(0, '/home/ubuntu/lemon-media-spider')
from spider import DB_PATH
from guangya_client import api_request
from update_categories import ensure_all_folders, FOLDER_MAP
from refresh_token import refresh_guangya_token
from ultimate_cleaner import run_ultimate_cleaning

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(message)s'
)
logger = logging.getLogger("LemonScheduledSync")

def sync_and_purify_guangya():
    logger.info("=" * 60)
    logger.info("🚀 启动【光鸭云盘定时智能同步与全盘净化守护】...")
    logger.info("=" * 60)
    
    # 1. 确保 Token 可用
    try:
        refresh_guangya_token()
    except Exception as e:
        logger.warning(f"[-] Token 刷新提示: {e}")

    # 2. 获取目标分类目录 ID
    try:
        folder_ids = ensure_all_folders()
    except Exception as e:
        logger.error(f"[-] 获取云盘目录结构失败: {e}")
        return

    # 3. 查询待推送资源
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("""
        SELECT id, channel, title, categories, rating, magnet, clean_filename
        FROM resources
        WHERE pushed_to_guangya = 0 OR pushed_to_guangya IS NULL
        ORDER BY id ASC
    """)
    pending_items = cur.fetchall()
    total_pending = len(pending_items)

    logger.info(f"[*] 发现待同步至云盘的新资源: {total_pending} 条")

    pushed_count = 0
    if total_pending > 0:
        for idx, row in enumerate(pending_items, 1):
            res_id, channel, title, cat_key, rating, magnet, clean_fn = row
            target_fid = folder_ids.get(cat_key, folder_ids.get('root'))
            cat_name = FOLDER_MAP.get(cat_key, "默认专区")

            try:
                res = api_request('/cloudcollection/v1/create_task', method='POST', data={
                    'url': magnet,
                    'parentId': target_fid
                })
                task_id = res.get('data', {}).get('taskId', 'N/A')
                logger.info(f"[{idx:03d}/{total_pending:03d}] [✓] [{cat_name}] 《{clean_fn[:30]}》 -> 任务成功下发 (ID: {task_id})")
                
                cur.execute("UPDATE resources SET pushed_to_guangya = 1 WHERE id = ?", (res_id,))
                conn.commit()
                pushed_count += 1
            except Exception as e:
                logger.error(f"[{idx:03d}/{total_pending:03d}] [-] 《{clean_fn[:30]}》 下发失败: {e}")
                time.sleep(1.0)
            
            # 拟人化安全频控休眠 1.8 ~ 3.5 秒
            sleep_sec = random.uniform(1.8, 3.5)
            time.sleep(sleep_sec)

    conn.close()
    logger.info(f"[🎉] 本批次离线任务推送完成！成功下发: {pushed_count}/{total_pending} 条")

    # 4. 执行全盘深度去杂质、粉碎广告与正片提权净化
    logger.info("[*] 正在执行全盘广告与杂质深度净化...")
    try:
        run_ultimate_cleaning()
    except Exception as e:
        logger.error(f"[-] 全盘净化异常: {e}")

    logger.info("=" * 60)
    logger.info("✨ 本次定时同步与净化守护全部完成！")
    logger.info("=" * 60)

if __name__ == '__main__':
    sync_and_purify_guangya()
