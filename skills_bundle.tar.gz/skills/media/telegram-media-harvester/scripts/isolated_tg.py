import os
import shutil
import uuid
import logging
from telethon import TelegramClient

SESSION_ORIG = '/home/ubuntu/lemon-userbot/lemon_userbot.session'
API_ID = 37863256
API_HASH = '1d853576b83541b22bb79406cb996ac6'

class IsolatedTelegramClient:
    """
    提供只读/无冲突的 Telegram 临时客户端上下文：
    1. 动态生成唯一的临时 session 文件，避免与常驻 UserBot 或其它爬虫进程冲突。
    2. 退出时安全释放连接并彻底销毁临时 session 文件。
    3. 纯只读数据抓取与媒体下载，不注册事件监听，不拦截人形 UserBot 指令。
    """
    def __init__(self, prefix="spider"):
        self.temp_session_name = f"/tmp/{prefix}_{os.getpid()}_{uuid.uuid4().hex[:8]}"
        self.session_file = f"{self.temp_session_name}.session"
        self.client = None

    async def __aenter__(self):
        if not os.path.exists(SESSION_ORIG):
            raise FileNotFoundError(f"主 UserBot Session 不存在: {SESSION_ORIG}")
        
        # 复制独立副本
        shutil.copyfile(SESSION_ORIG, self.session_file)
        self.client = TelegramClient(self.temp_session_name, API_ID, API_HASH)
        await self.client.connect()
        return self.client

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        if self.client:
            try:
                await self.client.disconnect()
            except Exception:
                pass
        
        # 清理临时 session 及其日志文件
        for ext in ['', '.session', '.session-journal']:
            f_path = f"{self.temp_session_name}{ext}"
            if os.path.exists(f_path):
                try:
                    os.remove(f_path)
                except Exception:
                    pass
