# VPS 大流量双轨转存 Worker (Worker Offloading) 架构与部署指南

## 架构背景
在具有免费出网流量限制的宿主机（如 AWS EC2 100GB/月额度）上运行媒体搬运系统时，若直接在宿主机下载几百 MB 至数 GB 的 Telegram 原生视频并上传至 Google Drive 和光鸭云盘，会产生 `200%` 的双向出网流量（下载+上传），极易耗尽配额导致高额扣费。

为实现彻底的流量安全与高吞吐，采用 **Master-Worker（主控-打手）分离架构**：
1. **主控端 (AWS / 宿主机)**：负责轻量爬取、磁力入库、API 调度与 **Telegram 毫秒级零流量秒转发**（`forward_messages`），消耗 0 KB 本地出网流量；
2. **打手端 (VPS Worker, 如 RackNerd 2G/35G/5TB 流量机)**：负责大文件流式下载、本地正则清洗去广告、精准重命名、双轨并发推送到 Google Drive 与光鸭云盘，并自动粉碎本地缓存。

---

## 打手端环境与依赖

打手端常驻服务目录结构：
```text
/opt/lemon-vps-sync-worker/
├── sync_worker.py          # 主转存循环与守护进程
├── gdrive_uploader.py      # Google Drive 上传模块
├── gdrive_token.json       # OAuth 凭据
├── guangya_client.py       # 光鸭云盘 REST API 客户端
├── guangya_uploader.py     # 光鸭 STS/OSS 直传客户端
├── guangya_session.json    # 光鸭 Token 与持久化 Session
├── refresh_token.py        # 光鸭 Token 自动刷新模块
├── update_categories.py    # 专区目录层级映射
├── deploy.sh               # Systemd 一键安装脚本
└── vps_worker.session      # Telethon 专用独立 Session
```

---

## 核心避坑要点 (Critical Pitfalls)

1. **Telethon MTProto 会话防踩踏与 IP 并发锁**：
   - 严禁多个进程同时或从不同公网 IP 复制并使用相同的 `.session` 文件向 MTProto 服务端发起并发握手，否则会触发服务端 `AuthKeyDuplicatedError` 导致 Session 永久失效。
   - 主控端爬虫与转发使用临时 Session 沙盒 (`IsolatedTelegramClient`)；
   - Worker VPS 端使用独立命名的 Session 文件 (`vps_worker.session`)。
2. **相对路径解析与配置注入**：
   - 确保 `TOKEN_PATH`、`SESSION_FILE` 和 `DB_PATH` 均使用 `os.path.dirname(os.path.abspath(__file__))` 动态解析，避免硬编码原宿主机绝对路径。
3. **依赖完整性**：
   - Worker 环境除了 `telethon`、`google-api-python-client` 之外，光鸭 OSS 直传必须安装 `oss2` 依赖。

---

## 部署与常驻

1. 传输到打手 VPS 并执行一键安装：
   ```bash
   tar -xzf lemon-vps-sync-worker.tar.gz -C /opt/
   bash /opt/lemon-vps-sync-worker/deploy.sh
   ```
2. 验证服务运行状态：
   ```bash
   sudo systemctl status lemon-vps-sync.service
   journalctl -u lemon-vps-sync.service -f
   ```
