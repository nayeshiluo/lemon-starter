# VPS 大流量双轨转存 Worker (Worker Offloading) 架构与部署指南

## 架构背景
在具有免费出网流量限制的宿主机（如 AWS EC2 100GB/月额度）上运行媒体搬运系统时，若直接在宿主机下载几百 MB 至数 GB 的 Telegram 原生视频并上传至 Google Drive 和光鸭云盘，会产生 `200%` 的双向出网流量（下载+上传），极易耗尽配额导致高额扣费。

为实现彻底的流量安全与高吞吐，采用 **Master-Worker（主控-打手）分离架构**：
1. **主控端 (AWS / 宿主机)**：负责轻量爬取、磁力入库、API 调度与 **Telegram 毫秒级零流量秒转发**（`forward_messages`），消耗 0 KB 本地出网流量；
2. **打手端 (VPS Worker, 如 RackNerd 2G/35G/5TB 流量机)**：负责大文件流式下载、本地正则清洗去广告、精准重命名、双轨并发推送到 Google Drive 与光鸭云盘，并自动粉碎本地缓存。

---

## 打手端环境与依赖

打手端常驻服务目录结构：
```text
/opt/lemon-vps-sync-worker/
├── sync_worker.py          # 主转存循环与守护进程
├── gdrive_uploader.py      # Google Drive 上传模块
├── gdrive_token.json       # OAuth 凭据
├── guangya_client.py       # 光鸭云盘 REST API 客户端
├── guangya_uploader.py     # 光鸭 STS/OSS 直传客户端
├── guangya_session.json    # 光鸭 Token 与持久化 Session
├── refresh_token.py        # 光鸭 Token 自动刷新模块
├── update_categories.py    # 专区目录层级映射
├── deploy.sh               # Systemd 一键安装脚本
└── vps_worker.session      # Telethon 专用独立 Session
```

---

## 核心避坑要点 (Critical Pitfalls)

1. **Telethon MTProto 会话防踩踏、文件复制陷阱与 IP 并发锁 (AuthKey Multi-IP Duplication Trap)**：
   - **绝对禁止跨 IP 复制 `.session` 数据库文件**：仅仅给文件重命名（如 `cp lemon_userbot.session vps_worker.session`）无法改变内部存储的底层 `auth_key` 实体。Telethon 的 `.session` 数据库记录了首次握手协商出的私有密钥。若两台不同公网 IP 的服务器（如 AWS EC2 与 Los Angeles VPS）同时或交替使用带有相同 `auth_key` 的 Session 连接 Telegram，服务端会立即识别为异地会话劫持/异常并发，抛出 `AuthKeyDuplicatedError: The authorization key (session file) was used under two different IP addresses simultaneously, and can no longer be used.` 并直接**永久吊销**该 Session，导致主控端 Userbot 随之瘫痪。
   - **正确多端隔离解耦方案**：
     - **方案 A（Bot Token 零风险直连 - 强烈推荐）**：Worker VPS 使用专用 Bot Token 启动独立 Telethon 会话（`client.start(bot_token=BOT_TOKEN)`），只要将 Bot 拉入私有专属频道并赋予管理员权限，即可无限制拉取大文件，完全不与真人 Userbot 产生任何 AuthKey 关联，100% 杜绝多 IP 冲突风险。
     - **方案 B（独立终端握手登录与 777000 全自动免打扰配对 - 实战最优解）**：若必须使用 Userbot 身份，Worker VPS 必须通过 `send_code_request` 独立完成握手认证，由 Telegram 服务端为该 VPS 注册专属于该设备的独立 `auth_key_id`。
       - **777000 官方通知中继自动化配对流程**：
         1. Worker VPS 执行脚本发起 `client.send_code_request(phone)` 并暂存 `phone_code_hash`；
         2. 主控端 Userbot 自动监听/读取官方系统账号 `777000`（Telegram Service Notifications）接收到的最新消息，正则捕获 6 位登录码：`re.search(r'Login code:\s*(\d+)', msg.text)`；
         3. 将获取到的动态 Code 自动中继给 Worker VPS，配合 2FA 密码（`client.sign_in(password=pwd)`）完成远端登录；
         4. 两台服务器各自持有专属 `auth_key_id`，在 Telegram 官方设备列表呈现为两个合法并存的 Session，彻底实现全自动化、无人工干预且永不冲突。
   - 主控端爬虫与转发使用临时 Session 沙盒 (`IsolatedTelegramClient`)；严格包裹文件排他互斥锁（`ProcessLock`）。
2. **全量历史回溯与消息游标防漏检 (History Backfill vs Shallow Polling)**：
   - 严禁在 Worker 中使用单一短步长 `client.get_messages(limit=20)` 浅层轮询，否则会遗漏历史消息中积压的几十上百部视频。
   - 必须结合本地 SQLite 数据库（`vps_sync_records`）采用 `client.iter_messages(limit=200)` 进行差异比对（Diff Backfill），按从旧到新的时间顺序完整消费积压队列。
3. **多形态 Telegram 视频消息识别 (Telethon Video vs Document Mime-Type)**：
   - Telegram 视频除了原生的 `msg.video` 外，常以 `msg.media.document` 且 mime-type 为 `video/mp4`、`video/quicktime`、`video/x-matroska` 等形式存在（特别是群/频道间无损转发或相册组形式发送的视频）。必须双重判定 `msg.video or ('video' in getattr(msg.media.document, 'mime_type', ''))`。
4. **视频文件名智能提取与多级降级清洗**：
   - 提取优先级：`msg.file.name` / `DocumentAttributeFilename` ➔ 消息正文首行 ➔ 降级为 `{media_type}_{msg.id}.mp4`。
   - 智能清洗规则：去除 `_watermarked`、广告前缀、`@xxx`、`#标签`、截除过长引流词并限制文件名在 60 字符以内，保持云盘目录整洁规范。
5. **相对路径解析与配置注入**：
   - 确保 `TOKEN_PATH`、`SESSION_FILE` 和 `DB_PATH` 均使用 `os.path.dirname(os.path.abspath(__file__))` 动态解析，避免硬编码原宿主机绝对路径。
6. **依赖完整性**：
   - Worker 环境除了 `telethon`、`google-api-python-client` 之外，光鸭 OSS 直传必须安装 `oss2` 依赖。
7. **多目标云盘转存强解耦容错（防短命 Token 串联拖死主通道）**：
   - **现象**：Worker 进程持续运行且定时汇报看似正常，但光鸭云盘和 Google Drive 长时间断更。
   - **根因**：Worker 将多个云盘上传写在同一个串行 `try` 块内（`下载 -> 传GDrive -> 传光鸭 -> 写入库`）。Google Drive OAuth 在测试模式（Testing）下只有 7 天有效寿命（`refresh_token_expires_in: 604799`），到期后报 `invalid_grant: Token has been expired or revoked.`，抛出异常直接把后续的光鸭云盘上传与数据库成功标记截断，造成无休止的死循环重试。
   - **架构防线**：多存储目标必须**彻底解耦（Decoupled Upload）**，各自包裹独立的 `try...except`，数据库分别持久化 `gdrive_fid` 与 `guangya_fid`。只要任一核心云盘上传成功，即可推进数据库入库，次要目标失败记录错误日志并支持后台异步重试，绝不让第三方 Token 过期破坏主通道转存。
8. **Telethon 媒体下载强制硬超时熔断（防跨 DC 传输死锁挂起）**：
   - **现象**：Worker 服务状态为 `active (running)`，但整整数天不再输出任何应用层巡检和入库日志，`lsof -p <PID>` 显示进程持续死锁占用着一个 0 字节临时文件的写句柄（`w` 模式）。
   - **根因**：Telethon 的 `client.download_media()` 在跨 Telegram 数据中心（如美西 VPS 连接 DC 2）下载大文件或遭遇网络波动时，若未显式包裹超时，底层 socket 会陷入永久死锁无限挂起（Hang 住），不崩溃也不抛错。
   - **架构防线**：
     - 下载操作必须包裹硬超时熔断：`await asyncio.wait_for(client.download_media(...), timeout=300)`；
     - `finally` 块中必须强制销毁 0 字节或未完成的临时文件（`os.remove`），防止文件句柄泄露与磁盘锁死。
9. **海报+无文字视频分开发送模式下的“片名丢失与类型错乱”**：
   - **现象**：Telegram 很多短剧与里番频道（如 `@bjcvnjkm` 蜜桃短剧）采用“一张带片名与集数的海报图片 ➕ 多条无文字视频正片”模式发布。Worker 单条检查视频的 `msg.text`，因无 caption 导致：① 提取不到片名，降级为时间戳（如 `lifan_1788250000.mp4`）；② 没扫到“短剧”关键词，短剧视频被全量误判为里番并错误归档进【🔞 里番专区】。
   - **架构防线**：
     - **来源频道确定性定类**：优先依据 `msg.forward.chat.username`（如 `bjcvnjkm`、`AIRVIP8` 为短剧；`lifankankan`、`SQDM_A` 为里番）精准判定专区，禁止单凭空 caption 猜测；
     - **上下文消息片名回溯**：视频消息无 caption 时，向上/向下邻近关联同批次转发的海报消息提取真正的《片名》与集数。
10. **全量增量游标回溯（防历史断层永久漏扫）**：
    - **现象**：Worker 因故障停机几天恢复后，历史积压的几十上百部视频永远不再被转存。
    - **根因**：`get_messages(limit=20)` 仅浅层扫描最新 20 条。一旦积压消息超过 20 条（如本次积压 271 条），处理完最新 20 条后，中间的 250 多条历史消息将被永久跳过。
    - **架构防线**：必须以数据库已同步的最大 `msg_id` 为基准，采用 `iter_messages(min_id=last_synced_id)` 增量顺序回溯推进，直到清空历史队列。
11. **本地临时缓存路径安全字符转义**：
    - 消息文本中如果包含 URL（如 `https://t.me/...`）或带有 `/`、`\\` 等字符，直接作为文件名拼入本地路径会导致操作系统创建异常嵌套文件夹（如 `https:`）。必须在清洗正则中对 `/`、`\\`、`|`、`:` 进行强制过滤或替换。
12. **Telegram 受保护频道（`noforwards=True`）直拉与保纯防线**：
    - **现象**：类似 `@FC2PPV4K` 等资源频道开启了 `noforwards=True`，主控端执行 `client.forward_messages` 会直接抛出 `ChatForwardsRestrictedError: You can't forward messages from a protected chat` 无法秒转至私有频道。
    - **架构防线**：不可在主控端强行下载中转（会迅速耗尽 AWS 100GB 免费出网）。打手 VPS Worker 直接通过 Session 实体连接源频道并拉取。
    - **保纯门槛与分卷解析**：此类频道常夹杂几 MB 的引流广告与水印视频，必须在 Worker 层加装硬过滤（`size < 100MB` 或 `0 < duration < 60s` 直接跳过）；同时针对 `part1/seg1` 等分卷做规范重命名与番号绑定（如 `[FC2-PPV-XXXXXXX] 标题_part1.mp4`）。

---

## 部署与常驻

1. 传输到打手 VPS 并执行一键安装：
   ```bash
   tar -xzf lemon-vps-sync-worker.tar.gz -C /opt/
   bash /opt/lemon-vps-sync-worker/deploy.sh
   ```
2. 验证服务运行状态：
   ```bash
   sudo systemctl status lemon-vps-sync.service
   journalctl -u lemon-vps-sync.service -f
   ```
