# VPS 大流量双轨转存 Worker (Worker Offloading) 架构与部署指南

## 架构背景
在具有免费出网流量限制的宿主机（如 AWS EC2 100GB/月额度）上运行媒体搬运系统时，若直接在宿主机下载几百 MB 至数 GB 的 Telegram 原生视频并上传至 Google Drive 和光鸭云盘，会产生 `200%` 的双向出网流量（下载+上传），极易耗尽配额导致高额扣费。

为实现彻底的流量安全与高吞吐，采用 **Master-Worker（主控-打手）分离架构**：
1. **主控端 (AWS / 宿主机)**：负责轻量爬取、磁力入库、API 调度与 **Telegram 毫秒级零流量秒转发**（`forward_messages`），消耗 0 KB 本地出网流量；
2. **打手端 (VPS Worker, 如 RackNerd 2G/35G/5TB 流量机)**：负责大文件流式下载、本地正则清洗去广告、精准重命名、双轨并发推送到 Google Drive 与光鸭云盘，并自动粉碎本地缓存。

---

## 打手端环境与依赖

打手端常驻服务目录结构：
```text
/opt/lemon-vps-sync-worker/
├── sync_worker.py          # 主转存循环与守护进程
├── gdrive_uploader.py      # Google Drive 上传模块
├── gdrive_token.json       # OAuth 凭据
├── guangya_client.py       # 光鸭云盘 REST API 客户端
├── guangya_uploader.py     # 光鸭 STS/OSS 直传客户端
├── guangya_session.json    # 光鸭 Token 与持久化 Session
├── refresh_token.py        # 光鸭 Token 自动刷新模块
├── update_categories.py    # 专区目录层级映射
├── deploy.sh               # Systemd 一键安装脚本
└── vps_worker.session      # Telethon 专用独立 Session
```

---

## 核心避坑要点 (Critical Pitfalls)

1. **Telethon MTProto 会话防踩踏、文件复制陷阱与 IP 并发锁 (AuthKey Multi-IP Duplication Trap)**：
   - **绝对禁止跨 IP 复制 `.session` 数据库文件**：仅仅给文件重命名（如 `cp lemon_userbot.session vps_worker.session`）无法改变内部存储的底层 `auth_key` 实体。Telethon 的 `.session` 数据库记录了首次握手协商出的私有密钥。若两台不同公网 IP 的服务器（如 AWS EC2 与 Los Angeles VPS）同时或交替使用带有相同 `auth_key` 的 Session 连接 Telegram，服务端会立即识别为异地会话劫持/异常并发，抛出 `AuthKeyDuplicatedError: The authorization key (session file) was used under two different IP addresses simultaneously, and can no longer be used.` 并直接**永久吊销**该 Session，导致主控端 Userbot 随之瘫痪。
   - **正确多端隔离解耦方案**：
     - **方案 A（Bot Token 零风险直连 - 强烈推荐）**：Worker VPS 使用专用 Bot Token 启动独立 Telethon 会话（`client.start(bot_token=BOT_TOKEN)`），只要将 Bot 拉入私有专属频道并赋予管理员权限，即可无限制拉取大文件，完全不与真人 Userbot 产生任何 AuthKey 关联，100% 杜绝多 IP 冲突风险。
     - **方案 B（独立终端握手登录与 777000 全自动免打扰配对 - 实战最优解）**：若必须使用 Userbot 身份，Worker VPS 必须通过 `send_code_request` 独立完成握手认证，由 Telegram 服务端为该 VPS 注册专属于该设备的独立 `auth_key_id`。
       - **777000 官方通知中继自动化配对流程**：
         1. Worker VPS 执行脚本发起 `client.send_code_request(phone)` 并暂存 `phone_code_hash`；
         2. 主控端 Userbot 自动监听/读取官方系统账号 `777000`（Telegram Service Notifications）接收到的最新消息，正则捕获 6 位登录码：`re.search(r'Login code:\s*(\d+)', msg.text)`；
         3. 将获取到的动态 Code 自动中继给 Worker VPS，配合 2FA 密码（`client.sign_in(password=pwd)`）完成远端登录；
         4. 两台服务器各自持有专属 `auth_key_id`，在 Telegram 官方设备列表呈现为两个合法并存的 Session，彻底实现全自动化、无人工干预且永不冲突。
   - 主控端爬虫与转发使用临时 Session 沙盒 (`IsolatedTelegramClient`)；严格包裹文件排他互斥锁（`ProcessLock`）。
2. **全量历史回溯与消息游标防漏检 (History Backfill vs Shallow Polling)**：
   - 严禁在 Worker 中使用单一短步长 `client.get_messages(limit=20)` 浅层轮询，否则会遗漏历史消息中积压的几十上百部视频。
   - 必须结合本地 SQLite 数据库（`vps_sync_records`）采用 `client.iter_messages(limit=200)` 进行差异比对（Diff Backfill），按从旧到新的时间顺序完整消费积压队列。
3. **多形态 Telegram 视频消息识别 (Telethon Video vs Document Mime-Type)**：
   - Telegram 视频除了原生的 `msg.video` 外，常以 `msg.media.document` 且 mime-type 为 `video/mp4`、`video/quicktime`、`video/x-matroska` 等形式存在（特别是群/频道间无损转发或相册组形式发送的视频）。必须双重判定 `msg.video or ('video' in getattr(msg.media.document, 'mime_type', ''))`。
4. **视频文件名智能提取与多级降级清洗**：
   - 提取优先级：`msg.file.name` / `DocumentAttributeFilename` ➔ 消息正文首行 ➔ 降级为 `{media_type}_{msg.id}.mp4`。
   - 智能清洗规则：去除 `_watermarked`、广告前缀、`@xxx`、`#标签`、截除过长引流词并限制文件名在 60 字符以内，保持云盘目录整洁规范。
5. **相对路径解析与配置注入**：
   - 确保 `TOKEN_PATH`、`SESSION_FILE` 和 `DB_PATH` 均使用 `os.path.dirname(os.path.abspath(__file__))` 动态解析，避免硬编码原宿主机绝对路径。
6. **依赖完整性**：
   - Worker 环境除了 `telethon`、`google-api-python-client` 之外，光鸭 OSS 直传必须安装 `oss2` 依赖。

---

## 部署与常驻

1. 传输到打手 VPS 并执行一键安装：
   ```bash
   tar -xzf lemon-vps-sync-worker.tar.gz -C /opt/
   bash /opt/lemon-vps-sync-worker/deploy.sh
   ```
2. 验证服务运行状态：
   ```bash
   sudo systemctl status lemon-vps-sync.service
   journalctl -u lemon-vps-sync.service -f
   ```
