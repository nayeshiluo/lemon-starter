# 光鸭净化 401 / 长扫描凭证过期 审计与归因

适用：`auto_pipeline.py` → `scheduled_sync_and_clean.py` → `video_only_cleaner.run_video_only_clean()` 报
`cleanup_error: HTTPError` / `HTTP Error 401: Unauthorized` / `ProcessLockBusy` / `LA Guangya authentication unavailable`。

## 一、决定性证据链（已实测有效，按序取）

1. **日志三件套**（AWS 主控 `/home/ubuntu/lemon-media-spider/`）
   - `cron.log`：`MEDIA_SYNC_RESULT` 里的 `pushed / permanent_rejected / failed / provider_353_pending / cleanup_error`
   - `delayed-clean.log`：06:30 与 07:00 两次兜底是否被 `Lock is busy: /tmp/lemon_video_only_sweep.lock` 挡掉
   - 关键时间点：`[*] 正在执行本批目标专区首轮净化...` 的起始时间 vs `首轮目标净化异常` 的结束时间 = 净化实际耗时
2. **解码 token 的真实有效期**（不要只看 `expires_at` 字段，它常是陈旧快照）

```python
import json, base64, datetime
d = json.load(open('/home/ubuntu/lemon-media-spider/guangya_session.json'))
for k, v in d['localStorage'].items():
    if 'credentials' in k:
        val = json.loads(v); t = val['access_token']
        p = t.split('.')[1]; p += '=' * (-len(p) % 4)
        c = json.loads(base64.urlsafe_b64decode(p))
        print('iat', datetime.datetime.utcfromtimestamp(c['iat']),
              'exp', datetime.datetime.utcfromtimestamp(c['exp']))
```

3. **对齐两个时钟**：`exp` 与「净化开始时间 / 净化报错时间」比对。
   实测样本：token `iat 05:26 / exp 07:26`，净化 `06:19 起扫 → 07:26:33 报 401`。
   → 401 不是账号问题，是**扫描跑过了凭证寿命终点**。
4. `ls -l --time-style=full-iso guangya_session.json` 看 mtime 是否被刷新过。mtime 不动 = 整轮没换过凭证。

## 二、根因模型（可直接套用的判定）

- 光鸭 `access_token` 有效期 **2 小时**（`expires_in: 7200`，JWT `exp - iat` 自校验一致）。
- 全量递归净化（`av/fc2/fuliji/tv/adult_general`，9 万+ 文件）实测 **60~75 分钟**。
- 主流水线 06:00 启动时先 `sync_guangya_from_la()`，拿到的往往是凌晨签发的旧 token，起跑即已消耗大半寿命。
- 于是「起跑剩余寿命 + 扫描时长 > 2h」→ 中途 401 是**结构性必然**，不是偶发。
- 401 后的自愈链：`guangya_client.api_request` 捕获 401 → `sync_guangya_from_la.sync()`。
  若 LA 与 AWS 持有**同一份**凭证，sync 打印 `GUANGYA_LA_TO_AWS_ALREADY_CURRENT` 后直接 return，
  `headers["Authorization"]` 仍是过期 token → 第二次请求再 401，且不再被捕获，异常上抛为 `HTTP Error 401: Unauthorized`。
  → 日志里同时出现 `GUANGYA_LA_TO_AWS_ALREADY_CURRENT` 和 401，就是这条死循环的指纹。
- 锁连带效应：主流水线整轮持有 `/tmp/lemon_video_only_sweep.lock`，
  `delayed_clean.py` 的 06:30 / 07:00 兜底全部 `Lock is busy` 跳过 → **当天净化零成功**。
  因此「净化失败」不等于「有兜底」，必须核实兜底是否真跑起来。

## 三、必须区分的失败类别（别混成一个"失败数"）

`MEDIA_SYNC_RESULT` 里数字要拆开读：

| 字段 | 含义 | 处理 |
|---|---|---|
| `pushed` | 离线任务成功下发 | 正常 |
| `permanent_rejected` | 入库门禁判定不可入库 | 不再重试 |
| `provider_353_pending` | 服务端判定文件违规，未到重试上限 | 会再次尝试 |
| `failed` | 其它异常（解析/网络） | 看 `guangya_failure_streaks.reason` |
| `cleanup_error` | 净化阶段异常 | 独立归因，不并入下发失败 |

`permanent_rejected` 的真实构成（2026-10-24 实测 77 条）：
- `no_clean_video_in_torrent` 67 条 — 死种 / 种子内无正片，属资源质量问题
- `torrent_file_list_empty` 10 条 — 种子文件列表为空
- `provider_353_file_violation` 40 条 — 平台内容审查（18+ 磁力），**平台侧硬限制，重试无意义**

判定顺序：先查 `guangya_ingest_rejections` 与 `guangya_failure_streaks` 的 reason 分布，
再决定是"补种"还是"该放弃"。不要把所有拒绝笼统报成"入库失败"。

## 四、待验证的修复方向（本次只审计，未执行、未验收）

以下为设计级建议，落地前须备份、小批量验证：

1. 净化改分页游标续扫；每 N 个目录检查 token 剩余寿命，不足 15 分钟主动刷新，不依赖 401 触发。
2. `ALREADY_CURRENT` 时强制让 LA 先 refresh 再拉取，避免"同一份过期凭证"死循环。
3. 主流水线净化拆成单专区短批次，把锁让给 `delayed_clean`，避免单次占用 67 分钟。
4. 下发前按 hash / 番号去重（实测同一 FC2 番号在一轮内生成两个任务 ID，重复吃离线配额）。

## 五、只读体检顺序（给"看看有没有问题"这类请求）

1. `date -u` + `TZ=Asia/Shanghai date` 取真实采样时间，与指标一起报。
2. `tail -n 120 cron.log` 拿最新 `MEDIA_PIPELINE_RESULT`。
3. 定向 grep 当日错误（按小时前缀 `^2026-10-24 0[6-9]`），不要整份打印 9MB 日志。
4. DB 三查：`resources` 的 `pushed_to_guangya` 分布、按频道 pending 排序、`guangya_failure_streaks` reason 分布。
5. 净化成功率必须回到 `delayed-clean.log` 核实，不能只看主流水线 active。
6. 结论里分开写：已验证事实 / 推断 / 未核实项。
