# 人型号「禁转发频道下载入库」链路排障（TG → 私有频道 → 光鸭）

磁力链路之外的第二条腿：源频道开了 `noforwards` 不能秒转，只能由人型号在打手机上
下载原视频再上传云盘。用户问「视频爬取是不是好久没新的了」时，问的多半是这条腿。

## 拓扑

```
源频道（SQDM_A / lifankankan / AIRVIP8 / bjcvnjkm / FC2PPV4K）
   │  naye: sync_all_media.py 里的 FORWARD_VIDEO_CHANNELS
   │  → tg_zero_traffic_forward.forward_channel_videos()  forward_messages 零流量秒转
   ▼
私有频道 <YOUR_TELEGRAM_GROUP_ID>（🔞 柠檬专属影视库）
   │  vps-la: lemon-vps-sync.service  /opt/lemon-vps-sync-worker/sync_worker.py
   │  每 POLL_SECONDS=60 全量扫，逐条 download_media → 上传光鸭（GDrive 轨已永久关闭）
   ▼
光鸭对应分类目录
```

- 打手机 systemd 单元名是 `lemon-vps-sync.service`（不是 `lemon-media-sync-worker`）。
- worker 跑在 `/opt/lemon-vps-sync-worker/venv/bin/python`，系统 `python3` 缺 `oss2`，
  直接在机器上 `python3 sync_worker.py` 会 `ModuleNotFoundError`；探针一律用 venv 解释器。
- 状态库 `/var/lib/lemon-vps-sync/vps_sync.db`，表 `vps_sync_records`
  （`msg_id, filename, guangya_status, gdrive_status, last_error, retry_count,
  source_channel, updated_at`）。FC2 记录的 `msg_id` 是 `2224956774000000 + msg.id`。

## 逐源对账法（区分「源停更 / 秒转坏了 / worker 坏了」）

两列数据对齐判断，缺一列就会误判：

1. **秒转侧**（naye，`resources.db`）：
   ```sql
   SELECT source_channel, COUNT(*), MAX(forward_time)
   FROM tg_forward_records GROUP BY source_channel ORDER BY 3 DESC;
   ```
2. **源侧**（`IsolatedTelegramClient` 只读，naye 上跑，注意排他锁别和主流水线并发）：
   ```python
   ent = await c.get_entity(ch)
   msgs = await c.get_messages(ent, limit=8)
   print(msgs[0].date, msgs[0].id, len([x for x in msgs if x.video or x.document]))
   ```

判读表：

| 源侧最新消息 | 秒转 max(forward_time) | 结论 |
|---|---|---|
| 今天/几小时内 | 同步到今天 | 健康 |
| 今天 | 停在几天前 | 秒转段坏了（`FORWARD_VIDEO_CHANNELS` 里那一路） |
| 几天前 | 与源对齐 | 源自己停更，不是我们断 |
| `get_entity` 抛 `No user has "X" as username` | 停止 | 源频道已注销/改名，只能换源 |

## 2026-10-29 实测基线

| 源 | 源侧最新 | 状态 |
|---|---|---|
| `SQDM_A`（里番） | 当天 14:02 | 健康，当天上传 8 部 `guangya_status=success` |
| `AIRVIP8`（AI短剧） | 前一天 18:16 | 已跟上 |
| `lifankankan`（里番） | 10-28 01:44 后无 | 源停更 |
| `bjcvnjkm`（AI短剧） | `No user has "bjcvnjkm" as username` | 10-21 起断源，需换源 |
| `FC2PPV4K` | 频道仍在更新 | worker 侧两个 bug 叠加，停摆一个月 |

`bjcvnjkm` 在 `forward_channel_videos` 里只会打一条 `[-] 转发异常: No user has ...`，
`except` 后继续下一个频道，**链路其余部分照常**，不要因为这条 ERROR 判定整条腿坏了。

## FC2PPV4K 停摆的两个叠加根因

### 1. Telethon 版本太旧，整段巡检静默报废

```
[ERROR] FC2PPV4K 频道巡检异常: Could not find a matching Constructor ID for the
TLObject that was supposed to be read with ID d49f34c6.
```

频道里出现新版消息类型，旧 Telethon 反序列化失败，`run_pass` 里 FC2 段的
`except Exception` 只打一条 ERROR 就结束本轮。表现：频道天天更新、DB 停在旧日期、
没有下载记录、服务 `active`。

离线判版本，不连 TG、不碰 session：

```bash
python -c "from telethon.tl.alltlobjects import tlobjects; print(len(tlobjects), 0xd49f34c6 in tlobjects)"
# 1.44.0 → 2462 False
# 1.45.0 → 2523 True
```

修：

```bash
cd /opt/lemon-vps-sync-worker
venv/bin/pip freeze > pip-freeze-backup-$(date +%Y%m%dT%H%M).txt
venv/bin/pip install -q --upgrade telethon==1.45.0
systemctl restart lemon-vps-sync.service
```

同大版本升级，session 与其余依赖实测无冲突。判成功：`journalctl -u lemon-vps-sync |
grep -c "Constructor ID"` 归零。

### 2. `iter_messages(limit=N, reverse=True)` 取最旧 N 条，不是最新 N 条

```python
# 注释写「扫描最新 60 条」，实际取的是频道最早的 60 条
async for msg in client.iter_messages(fc2_entity, limit=60, reverse=True):
```

频道涨到 23831 条后，最旧 60 条早已 `delivery_complete` 为真 → `fc2_messages`
恒空 → 连 `发现待处理正片` 的日志都不打，永久静默空转。改成不带 `reverse` 取最新窗口。

注意区分：专属频道那段 `iter_messages(entity, reverse=True)`（**无 limit**）全量扫
是刻意为之（18+ 深度回溯），每轮约 38 秒、无新内容时不打日志，属正常态，别一起改。

### 3. 最新窗口会一次暴露几十部积压，必须限流

实测最新 60 条里 28 部 ≥100MB，前 12 部合计 10.7GB，而打手机 `/` 常只剩 7GB 左右。
单轮只处理 1 部：

```python
logger.info('FC2PPV4K 频道发现待处理正片 %s 部，本轮处理 1 部', len(fc2_messages))
fc2_messages = fc2_messages[:1]
```

临时文件在 `process_single_video` 的 `finally` 里 `os.remove`，不累积；但仍要
`df -h /` 确认余量够最大单文件（4K 正片见过 1.75GB）。

## 待复核项（2026-10-29 未闭环）

修复后抓取已恢复（日志 `FC2PPV4K 频道发现待处理正片 28 部，本轮处理 1 部`，
msg=23831 233.8MB 下载完成），但该条上传光鸭跑了 12 分钟仍未落地，
`FC2 upload timeout policy ... timeout=900s` 可能已超时。下次接手先查：

```sql
SELECT msg_id, guangya_status, retry_count, last_error, updated_at
FROM vps_sync_records WHERE source_channel='fc2ppv4k' ORDER BY updated_at DESC LIMIT 5;
```

再核对光鸭 FC2 专区 `1938856883252637712` 目录里是否真出现该文件。
「下载完成」和「光鸭落地」是两件事，别只看前者报成功。
