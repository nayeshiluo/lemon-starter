# 光鸭云盘 (GuangyaPan) 原生文件直传与 OSS4/STS 对接指南

在 Telegram 媒体搬运工作流中，针对非磁力资源（原生 Telegram 视频/相册短剧/里番文件），无法直接使用磁力离线接口（`/cloudcollection/v1/create_task`），必须使用光鸭云盘官方的 OSS4 STS 直传通道。

---

## 核心接口与鉴权流程

### 1. 申请上传凭证与预分配 TaskID
- **Endpoint**: `POST https://api.guangyapan.com/userres/v1/get_res_center_token`
- **Headers**:
  - `Authorization: Bearer <access_token>`
  - `Content-Type: application/json`
- **Payload**:
  ```json
  {
    "capacity": 2,
    "name": "目标文件名.mp4",
    "res": {
      "fileSize": 123456789
    },
    "parentId": "目标目录ID"
  }
  ```
- **返回数据结构**:
  ```json
  {
    "msg": "success",
    "data": {
      "taskId": "1939515642643963916",
      "bucketName": "vip-lixian-04",
      "objectPath": "upload_tmp/xxx_TEMP_xxx",
      "region": "cn-shanghai",
      "endPoint": "guangyapan.com",
      "creds": {
        "accessKeyID": "STS.xxx",
        "secretAccessKey": "xxx",
        "sessionToken": "CAISxxx",
        "expiration": "2026-08-26T13:02:01Z"
      }
    }
  }
  ```

---

## 2. 阿里云 OSS 直传实现（Python + oss2）

> **避坑注意**：oss2 的 endpoint 参数必须使用 `https://guangyapan.com`，不可使用包含 bucket 的二级域名，否则会解析失败报错 `NameResolutionError`。大文件（>10MB）推荐使用 `oss2.resumable_upload`。

```python
import os
import time
import oss2
from guangya_client import api_request
from refresh_token import refresh_guangya_token

def upload_file_to_guangya(local_path, filename, parent_id, max_wait_seconds=60):
    file_size = os.path.getsize(local_path)
    
    # 1. 申请凭证
    try:
        res = api_request('/userres/v1/get_res_center_token', method='POST', data={
            'capacity': 2,
            'name': filename,
            'res': {'fileSize': file_size},
            'parentId': parent_id
        })
    except Exception:
        refresh_guangya_token()
        res = api_request('/userres/v1/get_res_center_token', method='POST', data={
            'capacity': 2,
            'name': filename,
            'res': {'fileSize': file_size},
            'parentId': parent_id
        })
        
    data = res.get('data', {})
    task_id = data.get('taskId')
    creds = data.get('creds', {})
    bucket_name = data.get('bucketName')
    object_path = data.get('objectPath')
    endpoint = 'https://guangyapan.com'
    
    # 2. STS 鉴权直传 OSS
    auth = oss2.StsAuth(creds['accessKeyID'], creds['secretAccessKey'], creds['sessionToken'])
    bucket = oss2.Bucket(auth, endpoint, bucket_name)
    
    if file_size > 10 * 1024 * 1024:
        oss2.resumable_upload(bucket, object_path, local_path, multipart_threshold=10*1024*1024, part_size=5*1024*1024)
    else:
        bucket.put_object_from_file(object_path, local_path)
        
    # 3. 轮询云盘任务状态，直到落盘并获取 fileId
    start_t = time.time()
    while time.time() - start_t < max_wait_seconds:
        time.sleep(1.5)
        status_res = api_request('/userres/v1/file/get_info_by_task_id', method='POST', data={'taskId': task_id})
        f_info = status_res.get('data', {})
        if f_info and f_info.get('fileId'):
            return f_info
            
    raise TimeoutError(f"光鸭云盘落盘超时 (TaskID: {task_id})")
```
