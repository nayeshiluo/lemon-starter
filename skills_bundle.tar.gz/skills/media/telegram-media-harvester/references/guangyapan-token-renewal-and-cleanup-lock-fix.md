# 光鸭凭证续期与净化锁修复手册（2026-10 实战，已验证）

针对两类反复发作的故障：**净化/下载 401** 与 **净化锁被独占导致兜底全废**。
本文件记录根因、修复代码骨架与验收命令，均为线上实测通过后的版本。

## 一、401 的两个独立根因（必须分别排查）

### 根因 A：凭证文件属主被 root 刷新改坏（隐蔽、可空转数天）
现象：
- LA（`lemon-vps-sync.service`，以 `lemon-media` 运行）每 60 秒报一次
  `光鸭鉴权预检异常，本轮跳过，禁止下载媒体: HTTP Error 401: Unauthorized`
- 同时用同一份凭证手工打 API 却返回 `200` —— 说明**凭证本身有效，是进程读不到**。

根因链：
1. LA 是唯一 refresh 源，`refresh_token.py` 的 `_atomic_save()` 用
   `tempfile.mkstemp()` + `os.chmod(600)` + `os.replace()`。
2. 一旦这次刷新由 root 触发（AWS 侧 ssh 调起），`os.replace` 后
   `/var/lib/lemon-vps-sync/guangya_credentials.json` 属主变成 `root:root 600`。
3. worker 以 `lemon-media` 运行 → `get_access_token()` 读不到凭证 → 静默 fallback 到
   旧的 `guangya_session.json`（几个月前、早已过期）→ 必然 401 → 触发 refresh →
   又被 root 写回 → **401 死循环**。

判定命令（三条都要看）：
```bash
ls -l /var/lib/lemon-vps-sync/guangya_credentials.json   # 属主是不是 root
sudo -u lemon-media test -r /var/lib/lemon-vps-sync/guangya_credentials.json && echo READABLE || echo NOT_READABLE
sudo journalctl -u lemon-vps-sync.service --since "-15min" --no-pager | grep -c 401
```
> 只看日志会误判成「token 过期/服务端风控」。**必须验证运行用户能否读凭证。**

修复（两层，缺一不可）：
1. 立刻修现场：
```bash
sudo chown lemon-media:lemon-media /var/lib/lemon-vps-sync/guangya_credentials.json
sudo chmod 600 /var/lib/lemon-vps-sync/guangya_credentials.json
sudo systemctl restart lemon-vps-sync.service
```
2. 修代码防复发 —— 原子写盘必须沿用原文件属主：
```python
def _target_owner():
    try:
        st = os.stat(CREDENTIALS_FILE)
        return st.st_uid, st.st_gid
    except OSError:
        st = os.stat(BASE_DIR)
        return st.st_uid, st.st_gid

def _atomic_save(data):
    owner = _target_owner()
    fd, tmp = tempfile.mkstemp(prefix=".guangya_credentials.", dir=BASE_DIR, text=True)
    try:
        with os.fdopen(fd, "w") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
            f.flush(); os.fsync(f.fileno())
        os.chmod(tmp, 0o600)
        try:
            os.chown(tmp, owner[0], owner[1])   # 关键：replace 前改属主
        except PermissionError:
            pass
        os.replace(tmp, CREDENTIALS_FILE)
    finally:
        if os.path.exists(tmp):
            os.remove(tmp)
```

### 根因 B：长扫描跨过 token 寿命（结构性）
- `access_token` 仅 2 小时（`expires_in: 7200`），全量递归净化 9 万+ 文件实测 60~75 分钟。
- 主流水线起跑时从 LA 拉到的常是几小时前签发的旧 token，剩余寿命 + 扫描时长 > 2h → 必然中途 401。

### 401 兜底为什么会变成死循环
`api_request` 401 时 `sync()` 从 LA 拉凭证；但 AWS/LA **共用同一份凭证**，
`sync()` 判定 `GUANGYA_LA_TO_AWS_ALREADY_CURRENT` 直接返回，token 没变，
重试必然再 401 → 整轮报废。日志里 `ALREADY_CURRENT` + 401 同时出现即是此症。

## 二、修复骨架（AWS 侧）

### 1. token 寿命感知 + 主动续期（治根）
```python
TOKEN_REFRESH_MARGIN = 600   # 秒；长扫描任务必须提前续，不能等 401

def token_seconds_left(token=None):
    token = token or get_access_token()
    if not token or token.count(".") != 2:
        return None
    payload = token.split(".")[1]
    payload += "=" * (-len(payload) % 4)
    exp = json.loads(base64.urlsafe_b64decode(payload)).get("exp")
    return int(exp - time.time()) if exp else None

def ensure_fresh_token(margin=TOKEN_REFRESH_MARGIN):
    left = token_seconds_left()
    if left is None or left >= margin:
        return True
    from sync_guangya_from_la import sync, force_refresh
    sync()
    left = token_seconds_left()
    if left is not None and left >= margin:
        return True
    force_refresh()          # LA 返回的还是旧 token 时，强制轮换
    left = token_seconds_left()
    return left is None or left >= margin
```
在 `api_request()` 取 token **之前**无条件调用 `ensure_fresh_token()`。
`token_seconds_left()` 只读文件 + 本地解 JWT，900 次分页请求的额外开销可忽略。

### 2. 401 兜底改成「拿不到新 token 就强制轮换」
```python
except urllib.error.HTTPError as e:
    if e.code == 401:
        sync()
        if token_seconds_left() is None or get_access_token() == token:
            force_refresh()          # 关键：断开 ALREADY_CURRENT 死循环
        fresh = get_access_token()
        if fresh and fresh != token:
            ... 重试一次 ...
        raise RuntimeError("光鸭 401 续期后凭证未更新") from e
    raise
```

### 3. LA 侧强制轮换入口
```python
def force_refresh():
    result = subprocess.run(
        ["ssh", "-o", "BatchMode=yes", "-o", "ConnectTimeout=8", "vps-la",
         "cd /opt/lemon-vps-sync-worker && ./venv/bin/python refresh_token.py"],
        capture_output=True, text=True, timeout=90)
    if result.returncode != 0:
        raise RuntimeError("LA token rotation failed: " + (result.stderr or result.stdout)[-200:])
    sync()
```

## 三、净化锁被独占 → 兜底全废

现象链：
1. 主流水线下发完自己全量净化，独占 `/tmp/lemon_video_only_sweep.lock` 60~75 分钟。
2. 期间 06:30 / 07:00 的 `delayed_clean` 兜底全部 `Lock is busy` 失败退出。
3. 结果：**当天净化零成功**，但两套调度都「配置正常」，只看 cron 列表完全看不出来。

修复（职责切分，不要靠加锁超时糊）：
- 主流水线只下发 + 入队：`sync_and_purify_guangya(defer_cleanup=True)`，
  `stats['cleanup_mode'] = 'queued'`，不再调用 `run_video_only_clean`。
  （`defer_cleanup` 分支里 `merge_queue()` 仍会执行，目标专区照常入队。）
- 净化统一交 `delayed_clean.py` 单专区轮转，cron 提到每 30 分钟：
```cron
*/30 6-23 * * * ... delayed_clean.py            # 单专区轮转
30 23   * * * ... delayed_clean.py --final      # 收尾
```
- 单专区扫描 10~45 分钟 < token 2h，且每轮独立进程重新拉 token，彻底消除跨寿命问题。
- 改 crontab 前先 `crontab -l > /tmp/crontab-backup-$(date +%Y%m%d).txt`，
  改完 `crontab -l | grep -A1 -B1 delayed-clean` 回读确认，并清理孤立注释行。

## 四、验收清单（缺一不算修好）

```bash
# 1. LA 凭证属主 + 运行用户可读
ssh vps-la 'ls -l /var/lib/lemon-vps-sync/guangya_credentials.json; sudo -u lemon-media test -r /var/lib/lemon-vps-sync/guangya_credentials.json && echo OK'
# 2. LA 重启后 5 分钟零 401（只算重启之后的时间窗，别把历史 401 算进去）
ssh vps-la 'sudo journalctl -u lemon-vps-sync.service --since "-5min" --no-pager | grep -cE "401|鉴权预检异常"'
# 3. 主动续期完整路径实测（会真的轮换一次 token，安全幂等）
python3 -c "import guangya_client as g; b=g.get_access_token(); print(g.ensure_fresh_token(999999)); print(b!=g.get_access_token(), g.token_seconds_left()); print(g.check_api_health())"
# 4. 回归测试
python3 -m pytest -q test_media_automation.py test_delayed_clean.py test_targeted_cleanup_safety.py
```
> 测试桩里 `sync_and_purify_guangya` 的 lambda 必须写成 `lambda **kwargs:`，
> 否则新增 `defer_cleanup` 参数会让 `test_pipeline_propagates_cloud_failure` 失败。

## 五、踩坑备忘

- **前台命令超时杀掉长扫描**：`delayed_clean` 单专区 10~45 分钟，前台跑必然被默认 180s
  超时杀掉（进程一起没了，日志只留一行「开始扫」）。长扫描一律
  `background=true` + `notify_on_complete=true`，或交给 cron/flock。
- **别把「历史 401」当「仍在 401」**：`journalctl --since` 的时间窗要从重启时刻算起，
  并核对 PID 是否已换（旧 PID 的日志是重启前残留）。
- **`ALREADY_CURRENT` 不等于凭证健康**：它只表示 AWS 和 LA 两份文件一样，
  两份都过期/都读不到时它照样打印。
- **爬取侧「5 个频道只出 3 行」不是故障**：`crawl_and_sync_all()` 里 2 个 web 频道
  各打一行，3 个 MTProto 频道合并成一行输出。判定前先读代码，别急着当静默吞异常。
- **占位名资源会自然收敛**：`🎬 影片名称：`、纯 `合集`、空文件名会被
  `ingest_guard.placeholder_reason()` 判 `placeholder_name` 并进永久拒绝表，
  下轮自动不再占下发配额，不需要额外清洗脚本。
