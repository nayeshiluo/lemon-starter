# VPS 视频双轨 Worker 恢复检查表

## 1. 只读基线

```bash
systemctl status lemon-vps-sync --no-pager
systemctl show lemon-vps-sync -p MainPID -p ExecMainStartTimestamp
journalctl -u lemon-vps-sync --since '2 hours ago' --no-pager
lsof -p <PID>
df -h
```

远端必须同时记录：Worker PID/启动时间、数据库 `min(msg_id), max(msg_id), count(*)`、源频道真实视频数、目标目录实际文件数、缓存目录文件大小。

## 2. 数据库状态模型

旧模型只有“整条双轨成功才插入一行”，无法断点续传。迁移至少增加：

- `gdrive_status`, `gdrive_fid`
- `guangya_status`, `guangya_fid`
- `last_error`, `retry_count`, `updated_at`
- `source_channel`, `source_msg_id`

主补传查询应以主目标为准，例如：

```sql
WHERE guangya_status IS NULL OR guangya_status != 'success'
```

Google Drive 失败只进入补偿队列，不得让已成功入光鸭的视频重复下载。

## 3. 分阶段恢复

1. 备份源码、DB、Telethon session、云盘凭证，并记录 SHA-256。
2. 本地和远端 `py_compile`。
3. 停服务，清理确认属于 Worker 的 0 字节/孤儿缓存；不要删除正在处理且无法确认归属的文件。
4. 重启后先观察 1 条消息，再观察小批次。
5. 每批都回读 DB、目标目录、日志、PID、缓存目录。
6. 只有主目标成功数持续上升且无卡死，才继续让队列运行。

## 4. 命名与分类

最终文件名必须按 UTF-8 字节限制，而不是仅按 Python 字符数限制；建议短片名加 `__msg<ID>` 唯一后缀。清除 Markdown 链接、URL、频道推广、路径分隔符和控制字符。

分类不能只按频道名：混发频道要结合转发来源、媒体自身文件名、同一来源的邻近标题/海报。历史修正只移动“来源 + 标题/文件名 + 当前目标目录”三重证据明确的文件；DB 更新优先按 `msg_id`，不要按重复文件名批量改。

## 5. 典型真实故障与正确判断

- `active (running)` + 无应用日志 + 0 字节文件句柄：业务假活，常见于 Telethon 跨 DC 下载无超时。
- GDrive `400 invalid_grant / Token has been expired or revoked`：OAuth refresh token 失效；不是“最近无新视频”，也不是光鸭必然失效。
- 光鸭 API 502/404：先记录具体 endpoint 与响应，不能直接断言账号失效；用已知可用的目录列表接口做独立验证。
- `Errno 36 File name too long`：中文文件名必须按 UTF-8 字节截断，并限制最终文件名（含消息 ID 后缀）。
- `database is locked` 或 `AuthKeyDuplicatedError`：不要直接并发打开主 session；使用已授权 session 的只读副本或全局互斥锁，并确认没有第二个 Telethon Worker。

## 6. 完成定义

不能以“服务已启动”作为成功。最低验收条件：

- 源端待处理视频数下降；
- 目标目录实际文件数与名称增加；
- DB 目标状态变为 `success`；
- GDrive 与光鸭状态可分别解释；
- 无新的 0 字节/半成品孤儿缓存；
- Worker 持续产生应用层日志；
- 重启后能从 DB 断点继续而不重复上传已成功目标。
