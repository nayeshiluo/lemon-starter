# Google Drive API 与 Resumable Upload 搬运对接指南

本参考文档总结了在无头 Linux 服务器中通过 Google Drive REST API 实现流式断点续传（Resumable Upload）及 OAuth 认证的要点。

## 1. OAuth 认证与 Token 管理
- **授权 URL 构造 (Offline Access)**：
  ```python
  import urllib.parse
  params = {
      'client_id': CLIENT_ID,
      'redirect_uri': 'http://localhost',
      'response_type': 'code',
      'scope': 'https://www.googleapis.com/auth/drive',
      'access_type': 'offline',
      'prompt': 'consent'
  }
  auth_url = 'https://accounts.google.com/o/oauth2/v2/auth?' + urllib.parse.urlencode(params)
  ```
- **Code 换取 Access/Refresh Token**：
  ```python
  token_url = 'https://oauth2.googleapis.com/token'
  data = urllib.parse.urlencode({
      'code': auth_code,
      'client_id': CLIENT_ID,
      'client_secret': CLIENT_SECRET,
      'redirect_uri': 'http://localhost',
      'grant_type': 'authorization_code'
  }).encode('utf-8')
  ```
- **测试用户 403 避坑**：
  新创建的 GCP OAuth Client 默认处于 Testing 状态，必须在 GCP 控制台「Google Auth Platform」/「OAuth 同意屏幕」->「受众群体」->「测试用户 (Test users)」中添加登录邮箱，否则报错 `403: access_denied`。
- **Google Drive API 启用**：
  首次调用需在 GCP API 库中激活 `Google Drive API`，否则报错 `403: SERVICE_DISABLED`。

## 2. Resumable Upload 断点续传流式上传大文件
```python
import json, urllib.request, os

def upload_file_to_gdrive(local_path, filename, parent_folder_id, access_token):
    file_size = os.path.getsize(local_path)
    metadata = {'name': filename}
    if parent_folder_id:
        metadata['parents'] = [parent_folder_id]
        
    init_url = 'https://www.googleapis.com/upload/drive/v3/files?uploadType=resumable'
    init_req = urllib.request.Request(
        init_url,
        data=json.dumps(metadata).encode('utf-8'),
        headers={
            'Authorization': f'Bearer {access_token}',
            'Content-Type': 'application/json; charset=UTF-8',
            'X-Upload-Content-Type': 'video/mp4',
            'X-Upload-Content-Length': str(file_size)
        }
    )
    with urllib.request.urlopen(init_req) as resp:
        upload_url = resp.headers.get('Location')
        
    with open(local_path, 'rb') as f:
        file_bytes = f.read()
        
    upload_req = urllib.request.Request(
        upload_url,
        data=file_bytes,
        headers={
            'Content-Type': 'video/mp4',
            'Content-Length': str(file_size)
        },
        method='PUT'
    )
    with urllib.request.urlopen(upload_req) as resp:
        return json.loads(resp.read().decode('utf-8'))
```
