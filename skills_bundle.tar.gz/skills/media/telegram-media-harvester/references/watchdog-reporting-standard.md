# 定时任务 Watchdog 与每日运维汇报精炼标准规范 (Watchdog Reporting Standard)

在 Hermes 的定时调度体系中，以 `no_agent=True` 运行的纯脚本型 Watchdog 具有零 Token 消耗、高可靠直推的优势。但在长链路多步骤（爬虫 ➔ 离线 ➔ 全盘去广告 ➔ 规范化重命名）任务中，极易发生标准输出污染与刷屏事故。

## 1. 核心痛点与事故复盘 (Stdout Flooding & Multi-Message Spam)

### 故障机制
- Hermes 调度器对 `no_agent=True` 的任务采取**标准输出原样捕获交付**规则：脚本向 `sys.stdout` 打印的任何字符都会直接通过 Telegram 推送给管理员。
- Telegram 单条文本消息上限为 4096 字符。
- 若脚本在执行底层递归穿透、去广告粉碎、目录提权、TMDB 模糊查询重命名等环节时，大量输出调试排查行（如 `[*] 📝 TMDB规范化: ...`、`[*] 📁 目录: 正在粉碎 N 个垃圾...`），标准输出将迅速膨胀至数万字节。
- **结果**：触发调度器自动多段切分推送，导致连续发出 4~5 条消息（如 `(1/5)` ~ `(5/5)`），形成严重的刷屏轰炸，而用户真正需要审阅的核心汇报反而沉底在最后一条消息末尾。

---

## 2. 治理架构：`LogRedirector` 截流沙箱

将所有第三方模块、子函数及内部清洗打印的 stdout/stderr 全部在运行时截流至本地文件，严格保障只有最终生成的精炼报告能触达真正的控制台 stdout。

```python
import sys

class LogRedirector:
    """
    上下文管理器：将代码块内部的所有 stdout/print 输出重定向至本地明细日志文件。
    保护终端与 Cron 调度器，杜绝过程调试日志污染 Telegram 会话。
    """
    def __init__(self, log_path="/home/ubuntu/lemon-media-spider/sync_details.log"):
        self.log_path = log_path
        self.real_stdout = None
        self.log_file = None

    def __enter__(self):
        self.real_stdout = sys.stdout
        self.log_file = open(self.log_path, 'a', encoding='utf-8')
        sys.stdout = self.log_file
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        if self.real_stdout:
            sys.stdout = self.real_stdout
        if self.log_file:
            try:
                self.log_file.flush()
                self.log_file.close()
            except Exception:
                pass
```

### 业务使用示例
```python
# 1. 漫长清洗与抓取过程包裹在沙箱内
with LogRedirector('/home/ubuntu/lemon-media-spider/sync_details.log'):
    scrape_all()
    run_deep_clean()
    vps_stats = get_vps_sync_stats()

# 2. 沙箱退出后，向真实 stdout 输出最终卡片
print(report_html)
```

---

## 3. 每日汇报重点卡片排版标准 (Daily Summary Card)

用户核心准则：“**报告太长了，挑重点总结就行；每日汇报只报重点**”。
整条报告必须严格控制在 **单条消息内（< 400 字符）**，严禁逐一展开 0 增量的子分类流水账。

### 四要素标准模板
```html
<b>🍋 柠檬每日入库重点简报</b> <code>({YYYY-MM-DD HH:MM} UTC+8)</code>
━━━━━━━━━━━━━━━━━━━━
<b>📊 核心战报</b>
• <b>新增磁力入库：</b> <code>+{total_new}</code> 条 (总库 <code>{total_db}</code> 条)
• <b>原生秒转存：</b> <code>+{total_fwd}</code> 部 (零流量秒转专属私有库)
• <b>光鸭离线下发：</b> <code>{pushed_count}</code> 个任务 (去广告与回收站已清空)
• <b>视频双轨累计：</b> <code>{vps_total}</code> 部 (里番 {lifan} / 短剧 {ai} / FC2 {fc2})

<b>🔍 状态核查与区分</b>
• <b>常规影视：</b> 电影:{status} / 剧集:{status} / 动漫:{status}
• <b>18+专区：</b> {仅罗列有新增项的专区名称+数量，全无时标明"源无更新"}

<b>🛡️ 异常与积压</b>
• <b>失败任务：</b> {fail_cnt} | <b>异常分类跳过：</b> {bad_cat_cnt} | <b>AWS出网流量：</b> 0
• <b>需爸爸处理：</b> {有则具体列出 / 无则明确标明"无 (全链路自动运转正常)"}
━━━━━━━━━━━━━━━━━━━━
<i>💖 重点已提炼完毕，明细日志已留存本地。</i>
```

### 状态真实性核查铁律
- **严禁仅看 `active` 就报正常**：常规影视每日核查必须在代码层面真实区分：
  1. `源频道无新更新`（爬取正常，源头 Telegram 频道未发新帖）；
  2. `抓取/网络失败`（网络超时、BeautifulSoup 解析失败等）；
  3. `入库/数据库异常`（SQLite 写入失败、锁死等）；
  4. `光鸭离线下发失败`（Token 过期、网盘接口 500 等）。
