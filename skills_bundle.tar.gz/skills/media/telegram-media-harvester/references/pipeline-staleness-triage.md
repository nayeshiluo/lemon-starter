# 「好久没有新内容了」链路停更定位（只读取证顺序）

爸爸问「TG 视频爬取下载入库光鸭是不是好久没有新的了」时，不要先看进程 active，按下面顺序取证，
20 分钟内能定位到「源死了 / 源有更新但抓不到 / 下发失败 / 只是节奏未到」四类之一。

## 1. 先分「入库」「下发」「落地」三段，别混成一个数

本机 `/home/ubuntu/lemon-media-spider/resources.db`：

```sql
-- 每日入库量
select date(created_at), count(*) from resources
 where created_at>date('now','-14 day') group by 1 order by 1;
-- 每日 pushed 分布（0=未推送，1=已推送）
select date(created_at), pushed_to_guangya, count(*) from resources
 where created_at>date('now','-14 day') group by 1,2 order by 1;
-- 各频道最后入库（区分常规 movie/tv/anime 与 18+）
select channel, categories, count(*), max(created_at) from resources
 where created_at>=date('now','-7 day') group by 1,2 order by 4 desc;
```

调度节奏（易误判为停更）：
- Hermes cronjob `18+及影视磁力每日12点入库与运维Bot总结`（`sync_all_media.py`，no_agent）北京 12:00 只入库；
- crontab `0 14 * * *` `auto_pipeline.py` 北京 14:00 才下发离线任务。
→ **12:00–14:00 之间看到「今天入库 N 条、pushed=0」是正常节奏，不是卡住。**

## 2. 光鸭侧只读探针

- 离线任务：`POST /cloudcollection/v1/list_task`，body 带 `{"page":0,"pageSize":20}`。
  **GET 会 404**（`guangya_client.list_offline_tasks()` 是无参 GET，直接调用必 404，别据此判定接口下线）。
  返回 `data.list[]` 含 `taskId / fileName / status / createTime / fileId`；`status==2` 为成功入库。
- 文件列表：`POST /userres/v1/file/get_file_list`，`parentId` 空串为根，`page` 从 0 开始。
- **`sortBy=utime&order=desc` 不要信**：实测传了会返回比默认顺序更旧的结果，等于没排序（`orderBy`/`sort` 直接 400）。
  取「某目录真实最新文件」只能**全页扫描求 max(utime)**（`pageSize=200` 翻页）。
  大目录（成人专区 4934 条 ≈ 25 页 × 每页 3~5s）会超时，探针放 `background=true` 或只对可疑专区扫。
- **顶层目录 `utime` ≠ 最新文件时间**：目录 utime 变动可能只是新建/移动子文件夹；
  文件实际在子目录里时，要递归一层或按文件名（如 `__msg3563.mp4`）全页搜索定位。
- 时区对齐：worker/journalctl 是 UTC，光鸭 `utime/createTime` 是 unix 秒（北京显示）。
  `04:04 UTC` 与「光鸭 12:04」是同一条，**别当成两个事件或误判延迟 8 小时**。

## 3. 源频道死活：直接打 t.me/s/ 预览页（最快的判定）

```bash
curl -s -m 25 -A "Mozilla/5.0" "https://t.me/s/<username>" \
  | grep -oE 'datetime="[0-9-]+T[0-9:]+' | tail -3      # 最后发帖时间
curl -s -m 25 -A "Mozilla/5.0" "https://t.me/s/<username>" | grep -c magnet
```

三种结论：
1. **最后 datetime 是几个月/几年前** → 源自己停更，爬虫没问题。实测 `dyttcili`（电影精选）最后 `2024-11-21`，两年前就死了。
2. **datetime 是今天、`magnet` 计数为 0、且页面出现 `Please open Telegram to view this post` + `message_media_not_supported`（多条）** → 频道开了「限制保存内容」，**公开预览拿不到正文**，`scrape_channel_paged` 返回空、被 catch 成「源频道无新更新」，静默零入库数月。实测 `dmhyshare`（动漫专区）今天仍在更新，但自 `08-26` 起零入库。
3. **datetime 新、`tgme_widget_message_text` 块正常且含 magnet** → 源正常，去查 DB/下发（实测 `zhuizhuiju` 正常）。

判定内容保护别只看 `tgme_widget_message_wrap` 数量（三种情况都是 20），要看 `tgme_widget_message_text` 块数与 `magnet` 计数。

## 4. 原生视频双轨（里番/AI短剧）单独看

- vps-la：`ssh vps-la`（Host 别名，root + `~/.ssh/lemon_racknerd_admin`，端口 2222）。
  **`ubuntu@<PRIVATE_IDENTIFIER>` 会 Permission denied，别试。**
- 服务名是 `lemon-vps-sync.service`（TG → GDrive + Guangya），**不是** `lemon-media-sync-worker`（inactive，历史残留）。
- `journalctl -u lemon-vps-sync --since "-3 days" | grep 光鸭云盘上传成功` 能看到逐条 fid；
  源频道是私有中转频道 `<YOUR_TELEGRAM_GROUP_ID>`，目录映射在 `sync_worker.py` 的 `folder_ids`（`lifan` 默认 `1939514048032452671`）。
- GDrive 轨若已永久关闭，日志是 `[⏭️] GDrive 轨已永久关闭，跳过`，不算故障。

## 5. 汇报口径

- 必须分「还在正常跑的」与「真断了的」两栏，写清每条的最后时间点。
- 断因要落到具体一类：源停更 / 内容保护抓不到 / 服务端判违规被拒 / 节奏未到，**不能只说「没新内容」**。
- 积压数要拆：服务端判违规、缺片名、种子无视频等拒收原因分项计数（`guangya_ingest_rejections`），
  不要把「被拒」写成「卡死」。
