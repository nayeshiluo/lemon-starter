# 光鸭云盘 (Guangya Cloud / guangyapan.com) API 规范与实战指南

迅雷旗下 2026 年新上线网盘，主打大容量 (2T~500T)、免登录下载与磁力/离线秒级下载。

## 1. 基础配置信息
- **Web 官网**: `https://www.guangyapan.com`
- **账号中心**: `https://account.guangyapan.com`
- **API 接口**: `https://api.guangyapan.com`
- **客户端 Client ID**: `aMe-8VSlkrbQXpUR`
- **项目 Project ID**: `356jld6jjlbjvygi5v9`

---

## 2. 鉴权与登录机制 (Playwright 无头浏览器短信登录)

由于光鸭云盘的直接账密接口强制校验滑块与设备指纹，且 OAuth 前端页面在公测期可能出现 404，**最佳登录方案为 Playwright 保持长连接代收短信验证码**：

```python
# 1. 打开官网并触发短信验证码
await page.goto("https://www.guangyapan.com/")
await page.locator("text=登录").first.click()
await page.locator("text=短信验证").first.click()
phone_el = page.locator("input[placeholder*='手机']").first
await phone_el.fill(phone)
await page.locator("input[type='checkbox']").first.check(force=True)
await page.locator("text=获取验证码").first.click()

# 2. 保持浏览器打开等待用户回传验证码
code_el = page.locator("input[placeholder*='验证码']").first
await code_el.press_sequentially(sms_code, delay=50)
await page.locator("button:has-text('登 录')").last.click()

# 3. 提取持久化凭证
local_storage = await page.evaluate("() => Object.assign({}, window.localStorage)")
# access_token 位于 local_storage['credentials_aMe-8VSlkrbQXpUR']['access_token']
```

---

## 3. 完整 REST API 参考 (已实测验证)

请求时需带请求头：
```http
Authorization: Bearer <access_token>
Content-Type: application/json
```

### ① 创建离线下载任务 (云添加)
- **Endpoint**: `POST https://api.guangyapan.com/cloudcollection/v1/create_task`
- **Payload**:
  ```json
  {
    "url": "magnet:?xt=urn:btih:...",
    "parent_id": ""
  }
  ```
- **响应**: `{"msg": "success", "data": {"taskId": "...", "url": "..."}}`

### ② 查询离线任务状态
- **Endpoint**: `POST https://api.guangyapan.com/cloudcollection/v1/list_task`
- **Payload**: `{ "page": 1, "pageSize": 10 }`

### ③ 查询网盘文件列表
- **Endpoint**: `POST https://api.guangyapan.com/userres/v1/file/get_file_list`
- **Payload**:
  ```json
  {
    "page": 0,
    "pageSize": 50,
    "parentId": "",
    "needSubFolderStat": true
  }
  ```
- **注意**: 页码 `page` 是从 0 开始；`parentId` 为空字符串代表根目录。

### ④ 文件云端重命名 (去广告清洗)
- **Endpoint**: `POST https://api.guangyapan.com/userres/v1/file/rename`
- **Payload**:
  ```json
  {
    "fileId": "1938831988527509592",
    "newName": "少林五祖 (1974) 蓝光国语中字.mp4"
  }
  ```
- **⚠️ 关键参数避坑**: 参数名必须是 `newName`，使用 `fileName` 会报错 `141: 文件名不能为空`。

### ⑤ 文件夹创建与文件移动归档
- **新建文件夹**: `POST https://api.guangyapan.com/userres/v1/file/create_dir`
  - Payload: `{"dirName": "🌸 动漫专区", "parentId": "<parent_folder_id>"}`
- **移动文件归档**: `POST https://api.guangyapan.com/userres/v1/file/move_file`
  - Payload: `{"fileIds": ["1938831988527509592"], "parentId": "<target_folder_id>"}`
  - **⚠️ 关键参数避坑**: 目标文件夹参数名必须是 `parentId`（不是 `targetParentId`）。

### ⑥ 生成免登录分享链接
- **Endpoint**: `POST https://api.guangyapan.com/userres/v1/share_file`
- **Payload**:
  ```json
  {
    "fileIds": ["1938831988527509592"],
    "title": "少林五祖 (1974) 蓝光国语中字.mp4",
    "validateDuration": 0,
    "shareType": 0,
    "downloadType": 1,
    "maxRestoreCount": 0
  }
  ```
- **响应**:
  ```json
  {
    "msg": "success",
    "data": {
      "shareUrl": "https://www.guangyapan.com/s/1938832331126677598_anBXS8dmlFreweex",
      "shareId": "1938832331126677598"
    }
  }
  ```
