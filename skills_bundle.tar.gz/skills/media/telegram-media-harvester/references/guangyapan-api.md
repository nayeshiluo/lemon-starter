# 光鸭云盘 (Guangya Cloud / guangyapan.com) API 规范与实战指南

迅雷旗下 2026 年新上线网盘，主打大容量 (2T~500T)、免登录下载与磁力/离线秒级下载。

## 1. 基础配置信息
- **Web 官网**: `https://www.guangyapan.com`
- **账号中心**: `https://account.guangyapan.com`
- **API 接口**: `https://api.guangyapan.com`
- **客户端 Client ID**: `aMe-8VSlkrbQXpUR`
- **项目 Project ID**: `356jld6jjlbjvygi5v9`

---

## 2. 鉴权与登录机制 (Playwright 无头浏览器短信登录)

由于光鸭云盘的直接账密接口强制校验滑块与设备指纹，且 OAuth 前端页面在公测期可能出现 404，**最佳登录方案为 Playwright 保持长连接代收短信验证码**：

```python
# 1. 打开官网并触发短信验证码
await page.goto("https://www.guangyapan.com/")
await page.locator("text=登录").first.click()
await page.locator("text=短信验证").first.click()
phone_el = page.locator("input[placeholder*='手机']").first
await phone_el.fill(phone)
await page.locator("input[type='checkbox']").first.check(force=True)
await page.locator("text=获取验证码").first.click()

# 2. 保持浏览器打开等待用户回传验证码
code_el = page.locator("input[placeholder*='验证码']").first
await code_el.press_sequentially(sms_code, delay=50)
await page.locator("button:has-text('登 录')").last.click()

# 3. 提取持久化凭证
local_storage = await page.evaluate("() => Object.assign({}, window.localStorage)")
# access_token 位于 local_storage['credentials_aMe-8VSlkrbQXpUR']['access_token']
```

---

## 3. 完整 REST API 参考 (已实测验证)

请求时需带请求头：
```http
Authorization: Bearer <access_token>
Content-Type: application/json
```

### ① 创建离线下载任务 (云添加)
- **Endpoint**: `POST https://api.guangyapan.com/cloudcollection/v1/create_task`
- **Payload**:
  ```json
  {
    "url": "magnet:?xt=urn:btih:...",
    "parent_id": ""
  }
  ```
- **响应**: `{"msg": "success", "data": {"taskId": "...", "url": "..."}}`

### ② 查询离线任务状态
- **Endpoint**: `POST https://api.guangyapan.com/cloudcollection/v1/list_task`
- **Payload**: `{ "page": 1, "pageSize": 10 }`

### ③ 查询网盘文件列表
- **Endpoint**: `POST https://api.guangyapan.com/userres/v1/file/get_file_list`
- **Payload**:
  ```json
  {
    "page": 0,
    "pageSize": 50,
    "parentId": "",
    "needSubFolderStat": true
  }
  ```
- **注意**: 页码 `page` 是从 0 开始；`parentId` 为空字符串代表根目录。
- **⚠️ 关键类型判断避坑 (resType vs dirType)**:
  - `resType == 2`：**真实文件夹 (Directory/Folder)**
  - `resType == 1`：**真实文件 (File)**
  - 严禁使用 `dirType == 1` 判断文件夹！光鸭返回的普通文件 `dirType` 同样可能为 1。如果误用 `dirType` 会将所有普通视频文件误判为目录递归查询，导致发起数千次无效网络请求并严重超时（300s Timeout）。

### ④ 文件云端重命名 (去广告清洗)
- **Endpoint**: `POST https://api.guangyapan.com/userres/v1/file/rename`
- **Payload**:
  ```json
  {
    "fileId": "1938831988527509592",
    "newName": "少林五祖 (1974) 蓝光国语中字.mp4"
  }
  ```
- **⚠️ 关键参数避坑**: 参数名必须是 `newName`，使用 `fileName` 会报错 `141: 文件名不能为空`。

### ⑤ 文件夹创建与文件移动归档
- **新建文件夹**: `POST https://api.guangyapan.com/userres/v1/file/create_dir`
  - Payload: `{"dirName": "🌸 动漫专区", "parentId": "<parent_folder_id>"}`
- **移动文件归档**: `POST https://api.guangyapan.com/userres/v1/file/move_file`
  - Payload: `{"fileIds": ["1938831988527509592"], "parentId": "<target_folder_id>"}`
  - **⚠️ 关键参数避坑**: 目标文件夹参数名必须是 `parentId`（严禁传 `toParentId` 或 `targetParentId`，若传错服务端会默认移动到根目录 `""` 导致散乱！）。批量移动时单批次建议控制在 50 项以内，并在批次间加入 0.2~0.3s 延时。

### ⑥ 生成免登录分享链接
- **Endpoint**: `POST https://api.guangyapan.com/userres/v1/share_file`
- **Payload**:
  ```json
  {
    "fileIds": ["1938831988527509592"],
    "title": "少林五祖 (1974) 蓝光国语中字.mp4",
    "validateDuration": 0,
    "shareType": 0,
    "downloadType": 1,
    "maxRestoreCount": 0
  }
  ```
- **响应**:
  ```json
  {
    "msg": "success",
    "data": {
      "shareUrl": "https://www.guangyapan.com/s/1938832331126677598_anBXS8dmlFreweex",
      "shareId": "1938832331126677598"
    }
  }
  ```

---

### ⑦ 全盘文件搜索
- **Endpoint**: `POST https://api.guangyapan.com/userres/v1/file/search_files`
- **Payload**:
  ```json
  {
    "name": "996gg",
    "page": 0,
    "pageSize": 100
  }
  ```
- **⚠️ 关键参数避坑**: 参数名必须是 `name`（不是 `keyword` 或 `query`）。

---

### ⑧ 批量删除文件
- **Endpoint**: `POST https://api.guangyapan.com/userres/v1/file/delete_file`
- **Payload**:
  ```json
  {
    "fileIds": ["1938843311290232833", "1938843329711628330"]
  }
  ```

---

### ⑨ 清空回收站
- **Endpoint**: `POST https://api.guangyapan.com/userres/v1/file/clear_recycle_bin`
- **Payload**: `{}`

---

### ⑩ Token 401 自动续期机制 (Token Auto-Refresh)
当 API 请求返回 `401 Unauthorized` 时，无需重新走短信登录，直接使用 `refresh_token` 进行免密续期：
- **Endpoint**: `POST https://account.guangyapan.com/v1/auth/token`
- **Payload**:
  ```json
  {
    "client_id": "aMe-8VSlkrbQXpUR",
    "grant_type": "refresh_token",
    "refresh_token": "<stored_refresh_token>"
  }
  ```
- **响应**: `{"access_token": "...", "refresh_token": "..."}`
- 更新本地 session json 中的 access_token 与 refresh_token 并重发失败请求。

---

### ⑫ 账号空间资产查询与离线配额避坑 (get_assets & Quota Limits)
- **空间与权益查询 Endpoint**: `POST https://api.guangyapan.com/assets/v1/get_assets`
  - Payload: `{}`
  - 返回核心字段：
    - `totalSpaceSize`: 总容量配额（如 `549755813888000` Bytes ≈ 500 TiB）
    - `usedSpaceSize`: 实际私有物理落盘占用（Bytes）
    - `vipStatus` / `svipStatus` / `vipExpireTime`: VIP/SVIP 到期时间戳
  - **⚠️ 避坑**：不要使用 `/drive/v1/about`（该旧接口目前会返回 `502 Bad Gateway`），查询存储必须统一调用 `POST /assets/v1/get_assets`。
- **离线任务 354 频控限制与订阅合集机制**：
  - 光鸭云盘针对每日离线任务设有配额限制，超限时接口返回 `{"code": 354, "msg": "云添加次数超限，下个自然日刷新"}`。
  - 用户转存的第三方挂载/分享合集（如《TOKEN订阅》或《原盘影视53T》等）在未完全物理落盘前属于虚拟目录索引，不计入官方 `usedSpaceSize` 资产统计；只有真正通过离线下载完成落盘的文件才会计入物理容量。

---

### ⑪ 种子捆绑垃圾广告文件防范与自动化清除
磁力下载常捆绑推广视频（如 `18+游戏大全(996gg.cc)-七龍珠H版-三國志H版-三國群淫傳等.mp4`）：
1. 离线完成后调用 `search_files` 搜索广告特征词（`996gg`, `18+游戏大全`, `七龍珠H版` 等）；
2. 收集匹配的 `fileId` 列表，调用 `delete_file` 批量删除；
3. 随后调用 `clear_recycle_bin` 彻底释放云盘空间。
