# 光鸭下发链路：门禁静默失败 / 单文件种子 / 死种饿死队列

2026-10-29 实测，三层缺陷叠加。适用于任何绕过 `guangya_client.add_offline_task()`
手拼 payload 调 `/cloudcollection/v1/create_task` 的旧脚本，以及任何「入库正常但云盘没东西」的排查。

## 症状家族

| 现象 | 真实原因 |
|---|---|
| 日志「光鸭离线下发：`0` 个任务」，DB 却有一堆 `pushed_to_guangya=0` | 门禁拒 + `except: pass` 吞异常 |
| 下发计数正常，但云盘专区一条没多 | 单文件种子传了 `fileIndexes`，任务 `status=3` |
| 新入库资源迟迟轮不到下发 | 历史死种占满 `LIMIT 40` 名额 |

三种都表现为「链路看起来正常」，必须分别取证。

## 层 1：intake 门禁 + 裸 `except: pass`

`guangya_client.api_request()` 对 `create_task` 先 `check_quota()`，再**强制**要求三个下划线字段，缺一个即抛：

```
RuntimeError: Magnet intake rejected: missing controlled category
```

| 字段 | 含义 |
|---|---|
| `_intake_category` | 受控分类 key（必须在 `FOLDER_MAP`），缺失直接拒 |
| `_intake_filename` | 清洗后文件名线索，供门禁判广告/占位名 |
| `_intake_hash` | BTIH，用于 `select_video_indexes` 与去重 |

之后依次 `validate_task_intake()` → `/cloudcollection/v1/resolve_res` → `select_video_indexes()` → `enqueue_cleanup_category()`。

旧写法（`sync_all_media.py` 第 4 段）：

```python
try:
    api_request('/cloudcollection/v1/create_task', method='POST',
                data={'url': mag, 'parentId': fid})   # ← 缺三个 _intake_*
    cur.execute("UPDATE resources SET pushed_to_guangya = 1 WHERE id = ?", (res_id,))
except Exception:
    pass          # ← 每条都被拒，静默跳过，计数恒 0，外层告警也不触发
```

正确形态（用封装，SELECT 时把 `magnet_hash` 一起取出来）：

```python
from guangya_client import add_offline_task
add_offline_task(mag, folder_id=fid, category=cat_key,
                 filename=clean_fn, magnet_hash=mhash)
```

## 层 2：单文件种子不能传 `fileIndexes`

光鸭 `resolve_res` 对**单文件** torrent 只回 `btResInfo.{infoHash,fileName,fileSize}`，
**不给 `subfiles`**；多文件种子才给 `subfiles` + `subfilesNum`。

`select_video_indexes` 原先硬要求 `subfiles` 非空 → 单文件种子一律
`torrent_file_list_empty`。新番单集、单集里番几乎全是单文件种子，等于整类资源全灭。

修 `ingest_guard.select_video_indexes`：`subfiles` 缺失但 `btResInfo.fileName`
是视频扩展名且 `clean_video_name(name=...)` 通过 → 返回 **`None`**（不指定索引），
仍拦广告/非视频单文件。

**关键：`None` ≠ `[]`。** 传 `fileIndexes` 的三种实测结果：

| payload | 结果 |
|---|---|
| `fileIndexes=[0]` | `status=3` 失败 |
| `fileIndexes=[1]` | `status=3` 失败 |
| **不带 `fileIndexes` 键** | **`status=2` 成功** |

所以 `api_request` 里：

```python
if indexes:                       # None 或 [] 都不发这个键
    data["fileIndexes"] = indexes
```

且放行判断要区分语义：

```python
if selected is None:              # 单文件种子，整种子下载
    pass
elif not selected:                # [] = 无可下视频
    raise RuntimeError("Magnet intake rejected: " + reason)
```

多文件种子照旧走 `[0..N-1]`，别因为单文件的问题把索引机制整体拆掉。

## 层 3：历史死种饿死新资源

推送段 `ORDER BY id DESC LIMIT 40`，而 227 条 `fuliji` 死种每轮都被门禁拒、
又永远 `pushed=0`，名额被历史垃圾长期占满，新入库的动漫永远排不上队。

照抄 `backlog_push_runner.py` 的形态：

```sql
SELECT r.id, r.categories, r.magnet, r.clean_filename, r.magnet_hash
FROM resources AS r
LEFT JOIN guangya_ingest_rejections AS g ON g.resource_id = r.id
WHERE (r.pushed_to_guangya = 0 OR r.pushed_to_guangya IS NULL)
  AND g.resource_id IS NULL
ORDER BY r.id DESC LIMIT 40
```

下发异常以 `Magnet intake rejected` 开头时记账（确定性拒绝才记；网络类瞬时错误保持重试）：

```python
cur.execute("INSERT OR IGNORE INTO guangya_ingest_rejections"
            "(resource_id, reason, rejected_at) VALUES (?,?,?)",
            (res_id, str(e)[:200], int(time.time())))
```

## 验收（缺一不可）

1. `create_task` 返回 taskId **不等于**成功。等 100~120s，查
   `POST /cloudcollection/v1/list_task`（GET 会 404）里该 taskId 的 `status`：
   `2`=成功 / `3`=失败 / `1`=进行中。
2. 再查目标专区 `get_file_list` 是否真有文件落地（顶层 `utime` 不可信，按文件名/全页扫）。
3. 报「下发 N 条成功」之前必须完成 1+2，否则就是把失败当成功。

探针脚本：`scripts/probe_offline_task_status.py`（给定 taskId 或「重推 DB 里某条资源」两种模式）。

## 排查顺序（只读，按此序）

1. `SELECT categories, count(*) FROM resources WHERE pushed_to_guangya=0 OR pushed_to_guangya IS NULL GROUP BY 1`
   —— 有积压就不是「没东西可推」。
2. 手跑一条 `add_offline_task()` 看真实返回。抛 `missing controlled category` → 调用方漏字段。
3. 抛 `torrent_file_list_empty` → 层 2（单文件种子）。
4. 返回 taskId 但 `status=3` → 查是否传了 `fileIndexes`。
5. 查调用方是否 `except Exception: pass` —— **所有吞异常的下发点都要改成记日志**。
6. 数 pending 里历史死种占比 → 层 3。

## 状态（2026-10-29 收尾）

- 层 1、层 2、层 3 的代码修复：**已落地**（`guangya_client.py` / `ingest_guard.py` /
  `sync_all_media.py`，均留 `.bak`）。
- 单文件种子探针任务 `1962795605999857705` → **`status=2` 已确认**。
- 动漫专区 `total` 110 → 114，有新条目落地；`anime` 待推送清零。
- 未完成：历史死种批量记账尚未跑满一轮；电影源仍空缺（`movie` 分类 `disabled`）。
