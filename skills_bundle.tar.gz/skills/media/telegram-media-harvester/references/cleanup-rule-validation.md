# 清理规则验伪：为什么「广告清理」会把正片删掉

2026-10-24 在 `lemon-media-spider` 上的实测记录。适用于任何「按文件名判广告/杂质」的清理器，
不限于光鸭。

## 结论先行

「清理一直有问题」在这个项目里不是**漏删**，而是**检测器本身判错**：

| 项 | 实测（`av` + `fuliji` 两专区） |
|---|---|
| 文件夹 | 11,925 |
| 文件总数 | 96,292 |
| 干净正片 | 89,425 |
| 旧规则判为「广告」 | **2,996** |
| 带站点水印前缀 | 3,871 |
| 非媒体杂项（`.txt/.url/.html`） | **0** |

抽样这 2,996 个「广告」，前 10 条全是正片：

```
🔞 成人专区/[231124@RUNBKK] Fitch(FPRE) FHD_Pack x24V/N0 Watermark@R_BKK/user@example.com
🔞 福利姬/[010125@R]SOD(@START) fhd pack x23V/MKV_Pack/user@example.com
```

`FPRE053` / `START001` 是番号，`169bbs.com@` 只是发布站水印前缀。
**按旧规则开 `--apply` 会一次性误删近 3 千个正片。**

## 三个独立缺陷（必须分开查，别混成一个「清理不生效」）

1. **`dry_run` 写死在调用处**
   - `delayed_clean.py:208` → `dry_run=True`
   - `scheduled_sync_and_clean.py:349` → 不传参，走函数默认 `dry_run=True`
   - 日志表现：连续多轮「只读预览完成，未删除文件」，看起来在跑，实际零副作用。
   - 查法：`grep -n "run_video_only_clean(" *.py | grep -v test`，看**调用点**而不是看函数定义。

2. **候选规则只看扩展名**
   `_inventory` 只把「扩展名不在 `RETAINED_EXTENSIONS`」的文件放进 `candidates`；
   带广告词的 `.mp4` 只做 `retained_keyword_matches += 1` 计数。
   而实测非媒体杂项 = 0，所以 `candidates` **必然恒空**，日志里 12 轮全是 `'candidates': []`。

3. **关键词命中 ≠ 垃圾**
   `promotion_reason` 的 `PROMO_MARKERS` 含 `169bbs` / `hhd800` / `thzu` 等**站点水印**，
   于是「带水印前缀的正片」和「站方宣传片」被判成同一类。

## 正确形态：三条分流

```
文件名
 ├─ 命中正片特征（集数 / 清晰度编码 / 番号） ──→ 永不清理
 ├─ 仅带站点水印前缀，剥掉后是正片 ──────────→ 剥名保留，不删文件
 └─ 无正片特征 且 命中强引流词/裸域名 ────────→ 回收站
```

### 判定函数骨架

```python
_EPISODE = re.compile(r"(?<![A-Za-z0-9])(?:S\d{1,2}\s*E\d{1,3}|第\s*\d{1,4}\s*[集话話期]|EP?\s*\d{1,4})(?![0-9])", re.I)
_QUALITY = re.compile(r"(?<![A-Za-z0-9])(?:2160p|1080p|720p|4k|uhd|hdr|hevc|x26[45]|h\.?26[45]|aac|bluray|web-?dl|remux)(?![A-Za-z0-9])", re.I)
# 番号：不加 re.I！否则 abc123 这类广告域名会被当成番号而漏杀
_CODE = re.compile(r"(?<![A-Za-z0-9])(?:[A-Z]{2,6}[-_ ]?\d{2,5}|FC2[-_ ]?PPV[-_ ]?\d{5,8})(?![A-Za-z0-9])")
_PROMO_DOMAIN = re.compile(r"(?:www\.|[A-Za-z0-9\-]{3,}\.(?:com|net|cc|org|xyz|top|vip|me|tv|la|info|club)\b)", re.I)


def looks_like_feature(name):
    text = str(name or "")
    return bool(_EPISODE.search(text) or _QUALITY.search(text) or _CODE.search(text))


def ad_video_reason(*values):
    raw = " ".join(str(v or "") for v in values)
    if not raw.strip():
        return ""
    feature = looks_like_feature(raw)
    if not feature and _PROMO_DOMAIN.search(raw):   # 裸域名：正片极少带
        return "promo_domain"
    if feature:                                      # 正片特征优先放行
        return ""
    normalized = _normalize(raw)
    for marker in AD_VIDEO_MARKERS:                  # 最新地址/扫码/加群/博彩/公告…
        if _normalize(marker) in normalized:
            return marker
    return ""
```

关键取舍：

- **`hhd800.com@ABP-123` 必须放行**（有番号）——所以「域名」判据要让位给「正片特征」。
- **番号正则不能 `re.I`**：`www.abc123.com` 里的 `abc123` 会被 `[A-Z]{2,6}\d{2,5}` 误判成番号，
  导致真正的广告被放过（本次单测就是这么抓出来的）。
- 强引流词表只收「正常影视名几乎不会出现」的词：`最新地址/永久地址/地址发布/发布页/防走丢/
  扫码/二维码/加群/免费看片/点击加入/更多精彩/公告/导航/博彩/澳门荷官/约炮/吃瓜/海角社区`。
  不要放 `合集`、`中文字幕`、`无码` 这类正常标签。

## 只读探针

`scripts/audit_clean_scope.py`：递归统计单专区的四类占比，**绝不删除**。

```bash
python3 audit_clean_scope.py av fuliji | tee audit-clean-scope.log
# 输出形如
# CATEGORY av {'folders': 3537, 'files': 18362, 'video_clean': 15203,
#              'video_promo_name': 2020, 'video_watermark_prefix': 1139}
```

判读：
- `junk_non_media` 为 0 → 候选规则再怎么写都不会有候选，别再怀疑「规则漏了」。
- `video_promo_name` 有值 → 一定抽样看名字，**不要**直接转成删除候选。

耗时参考：`av`（18,362 文件）约 27 分钟，`fuliji`（77,930 文件）约 65 分钟。
长任务必须 `background=true` + `notify_on_complete=true`；前台会在 180s 被连进程一起杀掉，
日志只留一行「开始」，极易误判成卡死。

## 上线纪律

1. 只读统计 → 抽样看真实命中项 → 加白名单 → 单测 → 小分区 `--apply` 验证 → 再放大。
2. 删除一律走**回收站**（`/userres/v1/file/delete_file`），不做永久清空。
   `clear_recycle_bin` 在 `api_request` 里已被显式禁用，不要为了「清干净」去放开它。
3. 单测至少要覆盖：
   - 8 条典型宣传片名 → 必须命中
   - 8 条典型正片名（含 `169bbs.com@` 水印前缀、`FC2PPV-`、`SxxExx`、`第N集`）→ 必须不命中
   - 正片名里混广告词（`ABP-123 最新地址版 1080p.mp4`）→ 必须不命中
   - `None` / 空串 → 返回空，不抛异常

## 附带发现（同一次排障）

- **入口门禁可能已经覆盖，不必重复加规则**：待推送里 42 条 `🎬 影片名称：` 空壳，
  `validate_resource` 已返回 `(False, 'placeholder_name')`，它们根本不会被下发。
  加规则前先拿真实数据跑一遍现有门禁，避免造重复逻辑。
- **`magnet_hash UNIQUE` 保证同一磁力不重复入库**；同一番号出现两次是「同番号两个不同种子」，
  属数据源特性，不要强行合并去重。
