# 清理/净化「一直有问题」的取证与验收

本文只讲**清理动作本身是否真的发生、清理范围是否正确**。
凭证寿命 401、root 属主锁死、扫描锁饥饿这三类通路的根因已写在
`references/guangya-cleanup-token-audit.md` 与
`references/guangyapan-token-renewal-and-cleanup-lock-fix.md`，本文不重复。

**关键区分**：通路修好 ≠ 清理生效。本次会话把 401/锁全部修完并验收通过后，
清理仍然是「一次都没删过」——因为 dry_run 与候选规则两个问题独立存在。
回答用户「清理也一并处理了吗」之前，必须先按下面取证。

## 1. 先确认它到底有没有删过东西

排查顺序（每次都做，不要假设）：

```bash
grep -n "run_video_only_clean(" *.py | grep -v test   # 每个调用点的 dry_run 实参
grep -c "只读预览完成，未删除文件" <clean>.log         # 预览次数
grep -oE "'candidates': \[[^]]*\]" <clean>.log | sort | uniq -c
```

- 函数签名 `def run_video_only_clean(..., *, dry_run=True)` 意味着**不传参就是预览**。
- 实测缺陷：`delayed_clean.py` 硬编码 `dry_run=True`，`scheduled_sync_and_clean.py`
  不传参走默认 `True` → 12 轮历史全部只预览，一次没删。
- 若历史 N 轮 `candidates` 全是 `[]`，结论是**连候选都没识别出来**，
  不是「库里没垃圾」。这两者的处置方向完全相反。

## 2. 再确认候选规则的范围对不对

本次的候选判定只有一条：扩展名不在 `RETAINED_EXTENSIONS` 里才算候选。

后果：
- 只认 `.txt/.url/.html/.exe` 这类非媒体杂项；
- **带广告词的 `.mp4` 只做 `retained_keyword_matches += 1` 计数，明确保留**；
- 带站点水印前缀的视频原样保留。

即「保正片」做了，「清广告」没做。而用户诉求是两者都要
（记忆里的表述是「锁正片粉碎广告」）。判定清理是否达标时，
不能只看「没删错东西」，还要看「该删的删了没」。

`ingest_guard.promotion_reason()` / `strip_site_watermark()` 已经能识别广告特征
（`PROMO_MARKERS`、`AD_TAIL_WORDS`、站点水印正则），**识别能力是有的，
缺的是把它接到候选列表上**。改造时优先复用这两个函数，不要另写一套关键词。

## 3. 用只读探针拿真实占比，再谈方案

`scripts/audit_clean_scope.py` 递归统计单专区四类文件：
`junk_non_media` / `video_promo_name` / `video_watermark_prefix` / `video_clean`。
绝不删除。用法：

```bash
python scripts/audit_clean_scope.py av fuliji > audit-clean-scope-av.log 2>&1
```

单专区 10~45 分钟，全盘可能 75 分钟 → **必须放后台**（前台 600s 上限会被截断，
但进程仍活着，别据此判定"卡住"或重复启动）。

判读：
- `junk_non_media == 0` 且 `video_promo_name == 0` 且总文件数正常
  → 库里确实干净，或 `resType`/`fileId` 字段判定漏项，需要打印原始 item 看字段名。
- `video_promo_name` 明显 > 0 → 证实"广告视频在保留"，方案就是把它接进候选。

## 4. 别急着加新规则：先查门禁是否已覆盖

怀疑「垃圾条目混进来」时，先用现有校验函数对真实行跑一遍：

```python
from ingest_guard import validate_resource
for row in rows:
    print(row[0], validate_resource(dict(title=..., categories=..., magnet=...,
                                         magnet_hash=..., clean_filename=...)))
```

本次 42 条 `🎬 影片名称：` 残渣，实测已被 `placeholder_name` 拦截、不会下发。
**删掉它们副作用大于收益（历史推送记录、重抓回填）→ 结论是保留。**
同理「同一番号被下发两次」：先查 `magnet_hash` 唯一约束是否失效
（本次未失效，是两个不同种子，属数据源特性，不做强合并）。

## 5. 时区：cron 表达式按系统时区解析

AWS 实例系统时区是 `Etc/UTC`（`timedatectl` 可确认）。
写 `*/30 6-23` 是 UTC 06:00-23:00 = **北京 14:00-次日 07:00**，不是北京 06:00。
要北京 06:00-23:00 必须拆成：

```
*/30 22,23 * * *   # 北京 06:00-07:30
*/30 0-15  * * *   # 北京 08:00-23:30
```

改 cron 前先 `timedatectl`，改完 `crontab -l` 回读核对，别凭注释自信。
本项目既有 cron 注释与实际表达式已不一致过（注释写 `1400_BJ`，表达式是 `0 6`）。

## 6. 改调用签名的连带影响

给被 mock 的函数新增关键字参数（如 `sync_and_purify_guangya(defer_cleanup=True)`）后，
测试 stub 若写成 `lambda: {...}` 会 `unexpected keyword argument` 失败，改成 `lambda **kwargs: {...}`。
改完必须跑：

```bash
python -m pytest -q test_media_automation.py test_delayed_clean.py test_targeted_cleanup_safety.py
```

基线：34 passed。

## 7. 验收口径

不要用「服务 active」「进程在跑」「没报错」当验收。用这些：

- `token_seconds_left()` 为正且 `check_api_health()` 为 True；
- LA worker 近 10 分钟 `grep -cE "401|鉴权预检异常"` 为 0，且有真实 TG 连接/下载日志；
- 净化单轮有完整收尾行：`单专区只读复扫完成；候选=0，终态跟踪清理=N，剩余跟踪=M`；
- 凭证文件属主 == 服务运行用户，且轮换一次后仍是该属主（验证 `_atomic_save` 生效）；
- **清理类改动额外要求**：在真实数据上跑出过非空候选，且 `--apply` 路径有明确授权与回滚手段，
  才可以说「清理已生效」。只读预览通过不代表清理可用。
