---
name: telegram-media-harvester
description: Use when scraping Telegram media channels for magnets.
---

# Telegram Media & Magnet Harvester Pipeline

本技能用于从 Telegram 影视/动漫/音乐资源频道与群组中自动化提取磁力链接、元数据清洗、去广告重命名、SQLite 去重持久化以及云盘转存与分发。

## 核心工作流与架构

1. **多源采集 (Public Preview / UserBot MTProto)**
   - 无需登录抓取：通过 `https://t.me/s/{channel_username}` 解析公开频道历史与新帖。
   - 私密频道/实时监听：通过 Telethon UserBot 监听 `events.NewMessage` 触发事件。

2. **多模态元数据提取与正则清洗**
   - **磁力链接提取**：`magnet:\?xt=urn:btih:[a-zA-Z0-9]+`
   - **Hash 提取与归一化**：提取 BTIH 并转为大写 Hex 作为唯一主键（`UNIQUE` 去重）。
   - **文件名与广告清洗**：剔除 `www.xxx.com`、`[电影天堂]`、特殊符号及水印前缀。
   - **影视元数据解析**：片名、年代、地区、分类标签（`#xxx`）、豆瓣评分与链接、集数/字幕类型。

3. **数据持久化 (SQLite)**
   - 存储结构包含：`channel`, `msg_id`, `title`, `year`, `region`, `categories`, `rating`, `douban_url`, `magnet`, `magnet_hash`, `clean_filename`。

4. **自动化云盘离线、四重分类归档、云端改名与分享对接**
   - **七重分类归档架构（核心准则）**：严禁将下载资源直接散乱堆放在网盘根目录。必须自动维护层级目录架构：
     - 📁 `/柠檬影视库/🎬 电影精选`（院线电影、蓝光经典，来源：`@dyttcili` 等）
     - 📁 `/柠檬影视库/📺 剧集更新`（国产/美剧/日韩连载剧，多集自动建剧名子目录，来源：`@zhuizhuiju` 等）
     - 📁 `/柠檬影视库/🌸 动漫专区`（新番动画、动漫剧场版，来源：`@dmhyshare` 等）
     - 📁 `/柠檬影视库/🔞 成人专区`（18+ 成人番号分类，自动按 140+ 女优/演员建立独立专属子目录，来源：`@yuytyu`、`@AV688`）
     - 📁 `/柠檬影视库/🔞 FC2专区`（FC2PPV 原创自拍无码作品，来源：`@NEWFC2`、`@FC2PPV4K` 等；受转发保护频道的视频直拉与番号清洗）
     - 📁 `/柠檬影视库/🔞 福利姬`（Cosplay、私订写真、福利大合辑，来源：`@cili8888`）
     - 📁 `/柠檬影视库/🔞 网红福利`（推特、抖音、探花、门票私拍，来源：`@mrny6969`）
     - 📁 `/柠檬影视库/🔞 里番专区`（18+ 动漫/里番，支持相册组与单集自动规范重命名，来源：`@lifankankan`、`@SQDM_A`）
     - 📁 `/柠檬影视库/🎬 AI短剧`（国产/现代/古风/玄幻 AI 成人短剧与漫剧，相册组智能提取剧名与集数，来源：`@YJTJSC`、`@AIRVIP8`、`@bjcvnjkm`）
     - 📁 `/柠檬影视库/🔞 成人综合`（经典香港三级片、艳情影视、PikPak热播，来源：`@pikpaklove`）
     - **剧集与视频收录准则（用户偏好准则）**：
       - **常规影视剧集仅收录最新剧**：常规影视剧集（电影/连载剧/新番）爬取与转存仅收录当季/当年（最新播出）剧集，历史老剧不主动全量爬取入库，按需精准收录。
       - **🔞 18+ 成人专区严格不设限（深度历史全量回溯铁律）**：18+ 成人专区（里番、AI成人短剧、无码精选、FC2、福利姬、网红私拍等）**严格不适用仅增量准则**！必须通过游标（`sync_cursors` 记录 `oldest_synced_id`）向前深度分页翻查历史消息（Cursor Pagination Backfill），在每轮任务中双向发力（抓最新增量 + 历史持续深挖），直到将历史所有老资源完整搬运入库。
       - **Telegram 媒体组/相册与单集里番解析模式**：对于连载动漫/里番频道（如 `@lifankankan`、`@SQDM_A`），视频常以媒体组或单集视频附带 `#标签 话数 描述` 发送。解析时需支持两套智能归一化策略：
         1. **相册组聚合模式**：按 `grouped_id` 聚合并按文本行切分逐一精准匹配各视频（如 `hanime_bot_xxx.mp4` -> `番剧名称 第01话.mp4`）；
         2. **单集标签与话数提取模式（如 @SQDM_A）**：解析 `#标签 话数` 格式，自动转为 `[主标题] 第XX话 副标题.mp4`，彻底杜绝乱码随机命名。
       - **原生视频多目标搬运与 Google Drive 同步**：支持直接通过 UserBot 流式下载 Telegram 频道原生视频（.mp4/.mkv），清洗命名后推送到光鸭云盘、私有媒体库，或借助 Rclone (`rclone authorize "drive" "scope drive"`) / Drive API / Service Account 同步分流搬运至 Google Drive 等多云盘，处理间隔保持 `15s ~ 30s` 拟人化慢速防风控。
       - **Google Drive Resumable Upload 零内存流式上传铁律（防 2GB 内存 VPS OOM 爆掉）**：在上传几百 MB 至数 GB 的视频大文件至 Google Drive 时，**严禁使用 `f.read()` 一次性全量读入内存**。必须使用 `requests.put(upload_url, data=open(local_path, 'rb'), headers=...)` 直接传递文件对象进行底层流式推流，内存占用恒定 < 5MB，杜绝触发 Linux OOM Killer 导致守护进程被强杀。
       - **Google Drive OAuth 授权与测试用户避坑**：第三方应用在测试模式（Testing）下会报 `403 access_denied`，必须在 GCP 控制台「OAuth 同意屏幕」/「受众群体」->「测试用户 (Test users)」中添加授权邮箱；无头环境优先使用 `rclone authorize` 或生成的本地重定向链接获取 code。
     - **配套脚本与参考**：
       - `references/gdrive-sync.md`：Google Drive OAuth、测试用户授权与 Resumable Upload 流式上传对接指南。
       - `references/watchdog-reporting-standard.md`：定时任务 Watchdog（no_agent=True）标准输出截流沙箱与每日汇报精炼标准指南。
       - `references/vps-worker-offloading.md`：VPS 大流量双轨转存 Worker (Master-Worker 解耦) 架构与部署指南。
       - `references/purify-and-flatten.md`：云端提纯、去杂质、增量巡检视界（max_age_days=3）、TMDB 本地持久化缓存与整目录连根拔起防超时指南。
       - `references/guangyapan-direct-upload.md`：光鸭云盘原生视频 STS 鉴权与 OSS 分片直传对接指南。
       - `scripts/sync_general_media.py`：常规影视（电影/剧集/动漫）分页爬取、标题规范清洗与分批推盘脚本。
       - `scripts/scheduled_sync_and_clean.py`：定时离线推送与全盘递归净化守护。
       - `scripts/isolated_tg.py`：Telethon 临时 Session 隔离沙盒上下文管理器（与主 Userbot 零冲突）。
       - `scripts/tg_zero_traffic_forward.py`：Telegram 零本地流量极速秒转存引擎（直接在 TG 云端秒复制消息指针至私有频道/网盘 Bot，0 字节出网流量消耗）。
       - `scripts/lock_utils.py`：基于 `fcntl.flock` 的单实例排他互斥锁。
     - **三大转存与入库保纯铁律（核心准则）**：
     1. **精确识别核心主视频**：按体积与类型智能锁定正片（> 100MB），自动剔除一切引流短片与无用杂质。
     2. **随意/乱码命名自动溯源重命名**：针对随意命名的文件（如 `VID_xxx`、`489155.com@xxx`），自动关联本地数据库元数据还原为规范中文片名/番号标准格式。
     3. **统一命名、分类打包与媒体库整理**：支持后期全库按 Emby/Plex 媒体库标准批量重构、按女优/系列分类打包或分享。
   - **全层级深度递归提纯、去杂质与目录扁平化（核心准则）**：
     - **全层级穿透扫描**：必须递归穿透 1~5 级任意嵌套目录，彻底扫描并粉碎所有藏在深层的 `.html`、`.txt`、`.url`、`.jpg` 以及 `< 150MB` 的博彩/游戏/直播/引流短视频（如《💥必看福利 给大家推荐一个调教 互相满足的交友圈子》、《社区最新情报》、《台湾美少女直播》）。
     - **广告推广文件夹识别与整层粉碎**：对命名中包含 `u5a5`、`thzu`、`极搜`、`jisou`、`发布页`、`最新地址`、`福利群`、`推荐一个`、`吃瓜资源` 等特征的推广外壳目录，直接执行整层物理销毁，避免广告文件夹残留。
     - **正片去广告重命名**：自动剔除 `489155.com@`、`169bbs.com@`、`hhd800.com@`、`dccdom.com@`、`ddccdom.com@`、`4k2.com@`、`thzu.cc@`、`[ThZu.Cc]`、`-nyap2p.com` 等所有发布站广告前缀与后缀。
     - **目录扁平化提权**：当种子在专区/女优目录下生成了嵌套子目录（如 `渡部穗乃/SNOS-146_4K60FPS/`）时，自动将提纯后的正片提取至上一层主目录，并自动删除多余空嵌套目录。
     - **副本去重**：自动识别并清理重复下载生成的 `(1).mp4` / `(1).mkv` 副本。
     - **个人数据安全锁**：所有清理与递归操作必须严格限制在 `/柠檬影视库/` 内部，严禁触碰网盘根目录的任何其他个人文件夹。
   - **防风控与零风险监听策略（防封号核心准则）**：
     - **主小号严格隔离铁律（防双向与封号底线）**：严禁使用日常沟通的主账号作为 Telethon / 爬虫的会话账号。机房 IP（AWS/独服）登录会使账号被 TG 风控标记为 API 客户端，大幅降低风控容忍阈值。必须使用独立辅助小号承载自动化任务，保障主账号绝不被连带双向或限制。
     - **UserBot 人形与爬虫零冲突沙盒隔离模式 (`IsolatedTelegramClient`)**：
       - 严禁爬虫或转存脚本直接并发打开主 UserBot 的 `.session` 数据库（会报 `sqlite3.OperationalError: database is locked` 或破坏长连接鉴权）。
       - 采用临时 Session 副本机制（见 `scripts/isolated_tg.py`）：爬虫启动时仅动态复制一次性副本至 `/tmp`，退出时自动断开并销毁临时文件。
       - **Telethon `AuthKeyDuplicatedError` 避坑与单例排他锁铁律**：严禁多个进程同时或从不同公网 IP 使用同一份 Session 副本向 MTProto 服务端发起并发握手。一旦被 Telegram 识别为多 IP 并发登录，服务端会直接吊销 Session 抛出 `AuthKeyDuplicatedError: The authorization key was used under two different IP addresses simultaneously`，导致 Session 永久失效需重新验证码登录。必须在所有调用 Telethon 的脚本外层包裹严格的文件排他互斥锁（`ProcessLock`），确保同一时刻全局仅有一个 MTProto 连接。
       - 只读模式执行 `client.get_messages()` 和 `client.download_media()`，绝不注册 `events.NewMessage` 监听器，确保人形（UserBot）指令（专属 Emoji、Q图贴纸、群聊管理等）100% 独占响应。
     - **多任务防踩踏排他锁 (`ProcessLock`) 与自愈防爆**：
       - 为每个周期性任务加装 `fcntl.flock` 文件互斥锁（见 `scripts/lock_utils.py`）。若上一轮大文件转存未完成，下一轮自动安全跳过，防止并发堆叠与带宽争抢。
       - 启动与退出时自动扫描并粉碎临时下载目录的孤儿缓存文件；日志达到 10MB 自动轮转保留最新 2000 行，杜绝磁盘溢出。
     - **只读爬取与双向限制（SpamBlock）认知**：纯读取公开频道（`get_messages`）只会遇到 `FloodWaitError`，绝不会引发禁止私聊陌生人的“双向限制”；双向限制 100% 源于主动私聊非双向好友或在群聊中被举报（Report Spam）。解封需通过 `@SpamBot` 申诉。
     - **零请求被动监听为主（100% 零风控）**：日常依赖 UserBot 的 `events.NewMessage` 原生长连接事件被动接收服务端推送，客户端不产生任何主动轮询，无 API 速率消耗，杜绝风控封号。
     - **极低频低峰期巡检兜底**：定时巡检（Cronjob）频率设置为每日仅在凌晨低峰期（如 05:00）运行 1 次，严禁设置分钟级或小时级高频主动轮询。
     - **增量极小步长与拟人化休眠**：主动巡检时单个频道仅扫描最近 10~15 条增量，严禁大范围历史翻页；每个频道请求之间强制加入 `3.5 ~ 6.0` 秒拟人化随机休眠。
   - **双重全自动入库机制（实时监听 + 定时巡检兜底）**：
     - **实时秒级事件监听**：通过常驻 UserBot 注册 `LemonMagnetListener`，监听纳管频道的 `events.NewMessage`。一旦包含 `magnet:` 链接，秒级提取番号/女优/片名，深度粉碎广告杂质并持久化至 SQLite (`resources.db`)，标记 `pushed_to_guangya = 0`。
     - **两段式定时批处理推盘与净化守护 (Scheduled Batch Push & Purify)**：将“磁力监听入库”与“云盘离线推盘”解耦。通过系统定时任务（如每整点 `0 * * * *` 运行 `auto_pipeline.py` / `scheduled_sync_and_clean.py`），批量拉取待推送记录，以 `1.8 ~ 3.5s` 拟人化频控下发离线任务至对应分类目录，完成后自动标记 `pushed_to_guangya = 1` 并触发全盘递归去杂质（粉碎 .txt/.url/推广短片、扁平化提权、清空回收站）。
     - **全流程自动化闭环流水线与双轨多周期调度（核心准则）**：
       - **轻量磁力入库与全盘净化 (`auto_pipeline.py`)**：每小时整点（`0 * * * *`）执行，负责多频道增量爬取 ➔ SQLite 去重入库 ➔ 批处理推盘下发（1.8~3.5s频控）➔ 全盘深度去杂质与正片扁平化。仅发送 API 指令，出网流量几乎为 0，安全放心。
       - **大文件双轨媒体转存守护 (`dual_sync_runner.py`)**：每 2 小时半点（`30 */2 * * *`）执行，专职负责里番（@SQDM_A、@lifankankan）与 AI短剧（@YJTJSC、@AIRVIP8 等）原生视频的流式下载 ➔ Google Drive & 光鸭云盘双轨同步上传。
       - **出网流量消耗与高危避坑准则（AWS 100GB 免费限额与零流量优化）**：
         1. **直传中转倍率消耗陷阱**：在按量计费或有免费额度限制的 VPS（如 AWS EC2 100GB/月免费 DTO）上，将 Telegram 原生视频先下到本地再推送到 Google Drive 和光鸭云盘，会产生 `200%` 的出网流量（1个 500MB 视频消耗 1GB 扣费出网流量）。一旦全量历史回溯，会迅速跑爆带宽配额导致产生云账单扣费。
         2. **控制面与数据面分离铁律**：AWS EC2 / 主控机只作为控制面（大脑、Bot、API 调度、数据库），月出网流量控制在 5GB 以内；大流量直传/PT 下载做种必须下发给不限流量的 NAT 小鸡或独服（Hetzner/OVH）。
         3. **四维零出网流量优化方案**：
            - **Telegram 消息转发 + AList 挂载（终极 0 流量）**：将视频直接 `client.forward_messages` 到自己的私有频道（毫秒级完成，0 本地流量），再用 AList 挂载 TG 频道供 Emby 流式点播。**避坑**：若源频道开启了防转发保护（`noforwards=True`，如 `@FC2PPV4K`），TG 服务端会拦截直接转发（抛出 `ChatForwardsRestrictedError: You can't forward messages from a protected chat`），此类受保护频道必须交由独立打手小鸡（如 RackNerd）在数据面直接拉取原视频与双轨分流推盘，严禁在主控机下载耗尽 AWS 100GB 免费出网。
            - **独立打手小鸡中转架构（Worker VPS Offloading）**：在有 100GB 免费限额的云主机（如 AWS EC2）上，严禁直接跑大文件中转；将 `lemon-media-spider` 部署在带 20G+ 硬盘和数 TB 流量的便宜小鸡（如 RackNerd 2GB/35GB SSD/5TB 流量款），主控机仅保留控制面，实现出网流量绝对为 0。
            - **三端联动双轨搬运闭环（Master-Worker 架构）**：
              1. **主控控制面 (AWS EC2 / 主机)**：通过 `tg_zero_traffic_forward.py` 将源频道（里番/短剧）视频毫秒级零流量秒转发至私有专属频道（如 `🔞 柠檬专属影视库`），本地消耗 0 流量；
              2. **大流量打手数据面 (Worker VPS, 如 5TB RackNerd)**：常驻 `lemon-media-sync-worker` 从私有频道高速下载视频至本地 `/tmp` 缓存，执行自动正则去广告与规范化重命名；
              3. **双轨同步分发**：Worker VPS 并发将视频推送到 Google Drive（OAuth / Rclone）与光鸭云盘（REST API），上传成功后立即彻底粉碎本地临时文件，释放存储；
              4. **主控监控汇报**：同步完成后记录数据库并向 Telegram 运维 Bot 推送每日归档简报。
            - **网盘官方 TG Bot 直转**：利用 PikPak / 115 的官方 TG 转存 Bot（如 `@PikPak_Bot`）直接转发消息，由网盘服务器在云端直接抓取，完全不走 VPS 流量。
            - **GitHub Actions 无服务器搬运（私有仓库 + 小号）**：利用微软 Azure 不限流量千兆带宽执行轻量视频下载与云盘上传；**注意严禁在 GitHub Actions 上运行 BitTorrent / PT 客户端**（违反 TOS 会被秒封）。
            - **Google Drive 服务端秒克隆**：云端文件移动与归档优先使用 `Files: copy` 或 `rclone --drive-server-side-copy`，实现 0 本地带宽消耗。
       - **架构解耦铁律**：严禁将长耗时的大文件视频下载与高频轻量磁力下发混在单一短周期脚本中，必须分流解耦以避免进程阻塞或超时退出。
       - **Crontab 与 Python 虚拟环境绑定铁律**：在系统 Crontab 配置定时调度时，**严禁使用系统全局 `/usr/bin/python3`**（常因缺失 `bs4`、`telethon`、`cryptography` 等依赖报 `ModuleNotFoundError` 导致任务静默瘫痪）。必须显式指定包含完整依赖的虚拟环境 Python 绝对路径（如 `/home/ubuntu/.hermes/hermes-agent/venv/bin/python3`），并重定向输出至独立日志以便监控。
     - **定时增量巡检兜底 (Watchdog Cronjob) 与每日 12 点精炼重点简报规范（爸爸偏好与防刷屏铁律）**：
       - **定时调度时间**：统一配置在每日中午 **12:00 (UTC+8，即 04:00 UTC)** 运行（`0 4 * * *` 的 `sync_all_media.py`），采用 `no_agent=True` 守护执行。
       - **Hermes Cron 调度器超时误报假象避坑 (Provider Timeout False Flag)**：
         - 当 `no_agent: true` 的脚本任务达到超时保护上限（默认 3600 秒）被系统强杀时，Hermes 调度器（`scheduler.py`）若未打补丁会因捕获到 `timeout` 关键字误报 `provider timeout. Fallback chain was exhausted or unavailable`，极易被误判为大模型 API 或中转站宕机。
         - **排查铁律**：务必先查底层输出日志 `~/.hermes/cron/output/{job_id}/*.md`。若真实报错为 `Script timed out after 3600s`，切勿盲目调整大模型或 API Key，根因是底层 Python 脚本耗时超标。
         - **放宽保护与根治防线**：通过 `hermes config set cron.script_timeout_seconds 7200` 放宽保护阈值；更根本的解法是将全盘全量扫描重构为**增量巡检视界（近 3 天）+ TMDB 本地持久化缓存 + 纯图宣传目录连根拔起**（详见 `references/purify-and-flatten.md`）。
       - **Watchdog Cronjob (`no_agent=True`) 标准输出污染与消息多段切分灾难 (Stdout Flooding & Multi-Message Spam 避坑)**：
         - 在 `no_agent=True` 的定时调度任务中，所有打到 `sys.stdout` 的 `print` 都会被调度器原样捕获并直接推送到 Telegram。
         - 若底层清洗、去广告（`run_deep_clean`）、TMDB 查询等打印了数百行进度日志，会导致标准输出超限被 Telegram 强行切分为多段（如 `(1/5)` ~ `(5/5)`）严重刷屏，核心报告沉底。
         - **治理规范（`LogRedirector` 截流沙箱）**：必须使用日志重定向上下文（`with LogRedirector('/path/to/sync_details.log'):`），将所有去广告、重命名、目录穿透的中间 stdout/stderr 完全沉淀至本地日志文件；主脚本的 `sys.stdout` **只允许且必须输出最终的单条极简汇报卡片**。
       - **每日汇报重点精炼四要素规范 (Daily Summary Card Standard - 极简高信噪比)**：
         - 严格遵守爸爸偏好：“报告太长了，挑重点总结就行；每日汇报只报重点”。卡片必须保持在单条消息内（< 400 字符），严禁输出流水账或展开 0 增量频道。
         - **必须包含的四大核心要素**：
           1. **📊 核心战报**：单行罗列新增磁力入库、原生秒转存、光鸭离线下发任务、VPS 双轨入库累计；
           2. **🔍 状态核查与区分**：常规影视严格区分“源频道无新更新”与“抓取/入库异常”，杜绝只看进程 active；18+专区仅合并展示有新增的专区与条数；
           3. **🛡️ 异常与积压**：失败任务数、非法分类拦截数（防根目录污染）、AWS 出网流量消耗；
           4. **🚨 需爸爸处理**：仅在有阻塞/需人工介入时列出，无则明确标明“无 (全链路自动运转正常)”。
       - **运维 Bot 与调度双轨通知**：汇报卡片同时通过 `send_ops_bot_report()` 直推运维 Bot 并由 Cron 投递到 Telegram 主会话，确保两端数据即时且一致。
   - **光鸭云盘 (guangyapan.com)**：通过 Playwright 长连接代收短信验证码获取 Token，调用全套 REST API 实现秒级离线、新建分类目录、移动归档、`newName` 云端去广告改名与免登录直链生成（详见 `references/guangyapan-api.md`）。
   - **PikPak**：调用 API 创建离线下载任务（秒级离线）并指定目标文件夹。
   - **115 云盘**：调用离线下载接口推入下载队列至指定分类目录。
   - **发布/分享**：根据清洗后的元数据自动生成发帖排版或推送至目标网站/频道。
   - **双轨/多目标转存五大生产级隐患（实测防线详见 `references/vps-worker-offloading.md`）**：
     1. **多目标解耦容错**：GDrive 与光鸭云盘上传必须独立 `try-catch`，杜绝 GDrive 7天测试 Token 到期抛 `invalid_grant` 导致光鸭上传与数据库标记连带被阻断；
     2. **下载硬超时熔断**：`client.download_media` 跨 DC 下载必须包裹 `asyncio.wait_for(timeout=300)`，杜绝 Telethon 底层 socket 死锁导致 Worker 假活挂起数天；
     3. **海报+无字视频分开发送的片名与分类回溯**：短剧频道常以“带名海报+无字视频”发布，Worker 必须依据 `msg.forward.chat.username` 确定性定类，并向上/下邻近海报提取真实《片名》与集数，杜绝退化为时间戳或把短剧错归入里番专区；
     4. **游标增量回溯清空积压**：严禁单一短步长 `limit=20` 导致积压断层漏扫，必须基于 `min_id=last_synced_id` 顺序消费；
     5. **路径安全字符过滤**：强制剥离 `/`、`\`、`|`，防止 URL 片段在本地缓存目录生成畸形嵌套文件夹。

## 生产级视频双轨 Worker 复检与恢复纪律（2026-09 实战补充）

### 必须先核实的事实
- 不要把中转频道消息数当成视频数：先按 `msg.video` 统计，并区分海报/说明消息。
- 以源频道消息 ID 与 Worker 数据库最大已处理 ID 对账，确认真实积压；固定 `limit=20` 会造成窗口饥饿与老任务永久漏扫。
- `systemd active` 只代表进程存在，不代表业务健康。必须同时检查应用层日志、DB 更新时间、临时文件句柄、进程等待状态与最新源消息。
- 失败报告必须来自真实远端 DB/API 回读，不能用历史报告文案替代当前状态。

### 双目标恢复顺序
1. 先为 Worker 源码、同步 DB、Telethon session、云盘凭证做远端独立冷备份并记录 SHA-256。
2. 数据库将 `gdrive_status` 与 `guangya_status` 分离；GDrive `invalid_grant` 不得阻断光鸭主通道。
3. 下载必须 `asyncio.wait_for`，GDrive/光鸭上传也要有独立外层超时；单条失败要落库并跳过，不能拖死队列。
4. 主补传队列只按“光鸭未成功”筛选；GDrive 欠账另建补偿队列，避免已入光鸭的视频重复下载。
5. 每条记录必须有稳定唯一文件名（建议 `安全片名__msg<ID>.ext`），最终名称按 UTF-8 字节限制，不能仅按字符数截断。
6. 每次部署后先只观察 1 条，再观察小批次；确认 DB 状态、云盘文件、缓存清理和进程心跳后才放大批量。

### 分类与命名防线
- 短剧常见“海报/说明带片名 + 后续无字视频”；应结合 `forward.chat.username`、同来源邻近上下文、媒体自身文件名综合判断。
- 频道来源只能作为证据之一：混发频道不可整频道强制归类；明确证据不足时保持原目录。
- 仅对“来源 + 标题/文件名 + 目标目录”三重证据一致的历史文件执行移动；优先按消息 ID 更新 DB，禁止用重复文件名批量更新。
- 上下文提取必须限制为同一转发来源，防止相邻内容串片；推广语、URL、Markdown 链接、`/`、`\\`、`|` 和控制字符必须清除。
- 已成功上传的云端文件不要只改本地 DB 名称；需要云端重命名成功回读后再更新映射，否则宁可保留旧名。

### 失败恢复的真实验收
- 业务恢复的最低证据：源端待处理数下降、目标目录实际文件数/文件名增加、DB 对应目标状态变为 `success`、缓存目录无孤儿 0 字节/半成品、Worker 仍 active 且持续产生日志。
- GDrive 授权失效时必须明确报告“光鸭已补传多少、GDrive 欠账多少”，不能把双轨成功数写成光鸭单轨成功数。
- 修补过程中若发现自己的补丁引入命名、转义、长度或状态一致性回归，应立即停批、清缓存、备份当前 DB、修补后从断点继续；不能带病扩大批次。

配套复检记录与恢复检查表见 `references/vps-worker-recovery-checklist.md`。

## 典型解析模式代码规范

```python
import re, urllib.parse

def parse_magnet(text):
    m = re.search(r'(magnet:\?xt=urn:btih:[^\s\n"\'<>]+)', text, re.IGNORECASE)
    return m.group(1).strip() if m else None

def clean_filename(title, year, ext=".mp4"):
    clean_t = re.sub(r'[《》\[\]【】\s_]+', ' ', title).strip()
    clean_t = re.sub(r'www\.[a-zA-Z0-9\.\-_]+', '', clean_t, flags=re.IGNORECASE).strip()
    clean_t = re.sub(r'电影天堂', '', clean_t).strip()
    year_str = f" ({year})" if year and year not in clean_t else ""
    return f"{clean_t}{year_str}{ext}"
```
