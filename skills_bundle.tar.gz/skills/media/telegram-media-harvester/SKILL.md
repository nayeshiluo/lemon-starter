---
name: telegram-media-harvester
description: Use when scraping Telegram media channels for magnets.
---

# Telegram Media & Magnet Harvester Pipeline

本技能用于从 Telegram 影视/动漫/音乐资源频道与群组中自动化提取磁力链接、元数据清洗、去广告重命名、SQLite 去重持久化以及云盘转存与分发。

## 核心工作流与架构

1. **多源采集 (Public Preview / UserBot MTProto)**
   - 无需登录抓取：通过 `https://t.me/s/{channel_username}` 解析公开频道历史与新帖。
   - 私密频道/实时监听：通过 Telethon UserBot 监听 `events.NewMessage` 触发事件。

2. **多模态元数据提取与正则清洗**
   - **磁力链接提取**：`magnet:\?xt=urn:btih:[a-zA-Z0-9]+`
   - **Hash 提取与归一化**：提取 BTIH 并转为大写 Hex 作为唯一主键（`UNIQUE` 去重）。
   - **文件名与广告清洗**：剔除 `www.xxx.com`、`[电影天堂]`、特殊符号及水印前缀。
   - **影视元数据解析**：片名、年代、地区、分类标签（`#xxx`）、豆瓣评分与链接、集数/字幕类型。

3. **数据持久化 (SQLite)**
   - 存储结构包含：`channel`, `msg_id`, `title`, `year`, `region`, `categories`, `rating`, `douban_url`, `magnet`, `magnet_hash`, `clean_filename`。

4. **自动化云盘离线、四重分类归档、云端改名与分享对接**
   - **四重分类归档架构（核心准则）**：严禁将下载资源直接散乱堆放在网盘根目录。必须自动维护层级目录架构：
     - 📁 `/柠檬影视库/🎬 电影精选`（院线电影、蓝光经典）
     - 📁 `/柠檬影视库/📺 剧集更新`（国产/美剧/日韩连载剧，多集自动建剧名子目录）
     - 📁 `/柠檬影视库/🌸 动漫专区`（新番动画、动漫剧场版）
     - 📁 `/柠檬影视库/🔞 成人专区`（18+ 成人与番号分类）
   - **Telegram 富文本与 Rich Message 解析**：对于使用 Telegram 原生富文本发帖的频道（如 `@dmhyshare`），文本存储在 `m.rich_message` 的 `PageBlockHeading3` 与 `PageBlockDetails` 内，需递归解包提取标题与磁链。
   - **运维 Bot (LemonOps) 交互集成**：支持 `/find <关键词>` 结构化卡片检索与 Inline Keyboard【📥 存入光鸭云盘】一键调用 API 分流转存。
   - **光鸭云盘 (guangyapan.com)**：通过 Playwright 长连接代收短信验证码获取 Token，调用全套 REST API 实现秒级离线、新建分类目录、移动归档、`newName` 云端去广告改名与免登录直链生成（详见 `references/guangyapan-api.md`）。
   - **PikPak**：调用 API 创建离线下载任务（秒级离线）并指定目标文件夹。
   - **115 云盘**：调用离线下载接口推入下载队列至指定分类目录。
   - **发布/分享**：根据清洗后的元数据自动生成发帖排版或推送至目标网站/频道。

## 典型解析模式代码规范

```python
import re, urllib.parse

def parse_magnet(text):
    m = re.search(r'(magnet:\?xt=urn:btih:[^\s\n"\'<>]+)', text, re.IGNORECASE)
    return m.group(1).strip() if m else None

def clean_filename(title, year, ext=".mp4"):
    clean_t = re.sub(r'[《》\[\]【】\s_]+', ' ', title).strip()
    clean_t = re.sub(r'www\.[a-zA-Z0-9\.\-_]+', '', clean_t, flags=re.IGNORECASE).strip()
    clean_t = re.sub(r'电影天堂', '', clean_t).strip()
    year_str = f" ({year})" if year and year not in clean_t else ""
    return f"{clean_t}{year_str}{ext}"
```
