---
name: telegram-media-harvester
description: Use when scraping Telegram media channels for magnets.
---

# Telegram Media & Magnet Harvester Pipeline

本技能用于从 Telegram 影视/动漫/音乐资源频道与群组中自动化提取磁力链接、元数据清洗、去广告重命名、SQLite 去重持久化以及云盘转存与分发。

## 核心工作流与架构

1. **多源采集 (Public Preview / UserBot MTProto)**
   - 无需登录抓取：通过 `https://t.me/s/{channel_username}` 解析公开频道历史与新帖。
   - 私密频道/实时监听：通过 Telethon UserBot 监听 `events.NewMessage` 触发事件。

2. **多模态元数据提取与正则清洗**
   - **磁力链接提取**：`magnet:\?xt=urn:btih:[a-zA-Z0-9]+`
   - **Hash 提取与归一化**：提取 BTIH 并转为大写 Hex 作为唯一主键（`UNIQUE` 去重）。
   - **文件名与广告清洗**：剔除 `www.xxx.com`、`[电影天堂]`、特殊符号及水印前缀。
   - **影视元数据解析**：片名、年代、地区、分类标签（`#xxx`）、豆瓣评分与链接、集数/字幕类型。

3. **数据持久化 (SQLite)**
   - 存储结构包含：`channel`, `msg_id`, `title`, `year`, `region`, `categories`, `rating`, `douban_url`, `magnet`, `magnet_hash`, `clean_filename`。

4. **自动化云盘离线、四重分类归档、云端改名与分享对接**
   - **七重分类归档架构（核心准则）**：严禁将下载资源直接散乱堆放在网盘根目录。必须自动维护层级目录架构：
     - 📁 `/柠檬影视库/🎬 电影精选`（院线电影、蓝光经典，来源：`@dyttcili` 等）
     - 📁 `/柠檬影视库/📺 剧集更新`（国产/美剧/日韩连载剧，多集自动建剧名子目录，来源：`@zhuizhuiju` 等）
     - 📁 `/柠檬影视库/🌸 动漫专区`（新番动画、动漫剧场版，来源：`@dmhyshare` 等）
     - 📁 `/柠檬影视库/🔞 成人专区`（18+ 成人番号分类，自动按 140+ 女优/演员建立独立专属子目录，来源：`@yuytyu`、`@AV688`）
     - 📁 `/柠檬影视库/🔞 FC2专区`（FC2PPV 原创自拍无码作品，来源：`@NEWFC2`）
     - 📁 `/柠檬影视库/🔞 福利姬`（Cosplay、私订写真、福利大合辑，来源：`@cili8888`）
     - 📁 `/柠檬影视库/🔞 网红福利`（推特、抖音、探花、门票私拍，来源：`@mrny6969`）
     - 📁 `/柠檬影视库/🔞 成人综合`（经典香港三级片、艳情影视、PikPak热播，来源：`@pikpaklove`）
     - **三大转存与入库保纯铁律（核心准则）**：
     1. **精确识别核心主视频**：按体积与类型智能锁定正片（> 100MB），自动剔除一切引流短片与无用杂质。
     2. **随意/乱码命名自动溯源重命名**：针对随意命名的文件（如 `VID_xxx`、`489155.com@xxx`），自动关联本地数据库元数据还原为规范中文片名/番号标准格式。
     3. **统一命名、分类打包与媒体库整理**：支持后期全库按 Emby/Plex 媒体库标准批量重构、按女优/系列分类打包或分享。
   - **全层级深度递归提纯、去杂质与目录扁平化（核心准则）**：
     - **全层级穿透扫描**：必须递归穿透 1~5 级任意嵌套目录，彻底扫描并粉碎所有藏在深层的 `.html`、`.txt`、`.url`、`.jpg` 以及 `< 100MB` 的博彩/游戏/直播引流短视频（如《社区最新情报》、《台湾美少女直播》）。
     - **正片去广告重命名**：自动剔除 `489155.com@`、`169bbs.com@`、`hhd800.com@`、`dccdom.com@`、`4k2.com@`、`-nyap2p.com` 等所有发布站广告前缀与后缀。
     - **目录扁平化提权**：当种子在专区/女优目录下生成了嵌套子目录（如 `渡部穗乃/SNOS-146_4K60FPS/`）时，自动将提纯后的正片提取至上一层主目录，并自动删除多余空嵌套目录。
     - **副本去重**：自动识别并清理重复下载生成的 `(1).mp4` / `(1).mkv` 副本。
     - **个人数据安全锁**：所有清理与递归操作必须严格限制在 `/柠檬影视库/` 内部，严禁触碰网盘根目录的任何其他个人文件夹。
   - **防风控与零风险监听策略（防封号核心准则）**：
     - **主小号严格隔离铁律（防双向与封号底线）**：严禁使用日常沟通的主账号作为 Telethon / 爬虫的会话账号。机房 IP（AWS/独服）登录会使账号被 TG 风控标记为 API 客户端，大幅降低风控容忍阈值。必须使用独立辅助小号承载自动化任务，保障主账号绝不被连带双向或限制。
     - **只读爬取与双向限制（SpamBlock）认知**：纯读取公开频道（`get_messages`）只会遇到 `FloodWaitError`，绝不会引发禁止私聊陌生人的“双向限制”；双向限制 100% 源于主动私聊非双向好友或在群聊中被举报（Report Spam）。解封需通过 `@SpamBot` 申诉。
     - **零请求被动监听为主（100% 零风控）**：日常依赖 UserBot 的 `events.NewMessage` 原生长连接事件被动接收服务端推送，客户端不产生任何主动轮询，无 API 速率消耗，杜绝风控封号。
     - **极低频低峰期巡检兜底**：定时巡检（Cronjob）频率设置为每日仅在凌晨低峰期（如 05:00）运行 1 次，严禁设置分钟级或小时级高频主动轮询。
     - **增量极小步长与拟人化休眠**：主动巡检时单个频道仅扫描最近 10~15 条增量，严禁大范围历史翻页；每个频道请求之间强制加入 `3.5 ~ 6.0` 秒拟人化随机休眠。
   - **双重全自动入库机制（实时监听 + 定时巡检兜底）**：
     - **实时秒级事件监听**：通过常驻 UserBot 注册 `LemonMagnetListener`，监听纳管频道的 `events.NewMessage`。一旦包含 `magnet:` 链接，秒级提取番号/女优/片名，深度粉碎广告杂质并持久化至 SQLite (`resources.db`)，标记 `pushed_to_guangya = 0`。
     - **两段式定时批处理推盘与净化守护 (Scheduled Batch Push & Purify)**：将“磁力监听入库”与“云盘离线推盘”解耦。通过系统定时任务（如每整点 `0 * * * *` 运行 `scheduled_sync_and_clean.py`），批量拉取待推送记录，以 `1.8 ~ 3.5s` 拟人化频控下发离线任务至对应分类目录，完成后自动标记 `pushed_to_guangya = 1` 并触发全盘递归去杂质（粉碎 .txt/.url/推广短片、扁平化提权、清空回收站）。
     - **定时增量巡检兜底 (Watchdog Cronjob)**：配置每日凌晨定时静默巡检脚本（如 `0 5 * * *` 的 `sync_all_media.py`），采用 `no_agent=True` 与仅在新增时输出的静默 watchdog 模式，防止网络波动或重启漏检。
   - **光鸭云盘 (guangyapan.com)**：通过 Playwright 长连接代收短信验证码获取 Token，调用全套 REST API 实现秒级离线、新建分类目录、移动归档、`newName` 云端去广告改名与免登录直链生成（详见 `references/guangyapan-api.md`）。
   - **PikPak**：调用 API 创建离线下载任务（秒级离线）并指定目标文件夹。
   - **115 云盘**：调用离线下载接口推入下载队列至指定分类目录。
   - **发布/分享**：根据清洗后的元数据自动生成发帖排版或推送至目标网站/频道。

## 典型解析模式代码规范

```python
import re, urllib.parse

def parse_magnet(text):
    m = re.search(r'(magnet:\?xt=urn:btih:[^\s\n"\'<>]+)', text, re.IGNORECASE)
    return m.group(1).strip() if m else None

def clean_filename(title, year, ext=".mp4"):
    clean_t = re.sub(r'[《》\[\]【】\s_]+', ' ', title).strip()
    clean_t = re.sub(r'www\.[a-zA-Z0-9\.\-_]+', '', clean_t, flags=re.IGNORECASE).strip()
    clean_t = re.sub(r'电影天堂', '', clean_t).strip()
    year_str = f" ({year})" if year and year not in clean_t else ""
    return f"{clean_t}{year_str}{ext}"
```
