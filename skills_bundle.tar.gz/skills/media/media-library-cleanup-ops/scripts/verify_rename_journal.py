"""按剥名回滚日志实地验收：读回云盘，确认新名已落盘、旧名无残留。

日志格式（每行一条 JSON）：
    {"file_id": "...", "path": "专区/子目录/原文件名.mkv",
     "old_name": "原文件名.mkv", "new_name": "新文件名.mkv", "status": "ok"}

用法（在项目目录下，需能 import 该项目的 client / 目录发现模块）：
    python3 verify_rename_journal.py rename-audit-20261024-234459.jsonl 10 [--category av]

判定通过 = new_name 对应的 fileId 等于日志 file_id，且 old_name 不在同目录。
只看 renamed_files 计数不算验收。
"""
import argparse
import json
import sys

sys.path.insert(0, "/home/ubuntu/lemon-media-spider")

from guangya_client import check_api_health          # noqa: E402
from cleanup_preview import ensure_all_folders        # noqa: E402
from update_categories import FOLDER_MAP              # noqa: E402
from video_only_cleaner import _list_children         # noqa: E402


def resolve(root_id, parts, label="walk"):
    """逐层下钻到目标目录，返回 (folder_id, 未匹配的剩余段)。"""
    cur = root_id
    for idx, part in enumerate(parts):
        found = None
        for item in _list_children(cur, label):
            name = str(item.get("fileName") or item.get("name") or "")
            if item.get("resType") == 2 and name == part:
                found = item.get("fileId") or item.get("id")
                break
        if not found:
            return cur, parts[idx:]
        cur = found
    return cur, []


def main(argv=None):
    parser = argparse.ArgumentParser()
    parser.add_argument("journal")
    parser.add_argument("limit", nargs="?", type=int, default=10)
    parser.add_argument("--category", default="av")
    args = parser.parse_args(argv)

    rows = [json.loads(x) for x in open(args.journal, encoding="utf-8") if x.strip()]
    ok_rows = [r for r in rows if r.get("status") == "ok"]
    print("日志记录: 总 %d / 成功 %d" % (len(rows), len(ok_rows)))

    check_api_health()
    folders = ensure_all_folders()
    root = folders.get(args.category)
    if not root:
        raise SystemExit("专区目录不存在: " + args.category)

    checked = passed = 0
    for row in ok_rows[: args.limit]:
        parts = row["path"].split("/")
        folder_id, rest = resolve(root, parts[1:-1])
        if rest:
            print("  [skip] 目录未匹配: %s" % "/".join(rest))
            continue
        names = {}
        for item in _list_children(folder_id, "verify"):
            names[str(item.get("fileName") or item.get("name") or "")] = (
                item.get("fileId") or item.get("id"))
        hit_new = names.get(row["new_name"]) == row["file_id"]
        hit_old = names.get(row["old_name"]) == row["file_id"]
        checked += 1
        passed += 1 if (hit_new and not hit_old) else 0
        print("  %s | 新名=%s 旧名残留=%s | %s -> %s"
              % ("OK  " if (hit_new and not hit_old) else "FAIL",
                 hit_new, hit_old, row["old_name"], row["new_name"]))

    print("\n验收结果: %d/%d 已按新名落盘" % (passed, checked))
    return 0 if checked and passed == checked else 1


if __name__ == "__main__":
    raise SystemExit(main())
