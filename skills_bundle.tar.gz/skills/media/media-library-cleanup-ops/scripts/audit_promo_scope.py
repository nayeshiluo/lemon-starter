"""只读全量审计探针：开删前测算规则误判率。

用途：把云盘某专区递归扫一遍，统计"总数 / 疑似广告 / 水印前缀 / 非媒体杂项"，
并把疑似广告清单落成 JSON，供人工抽样核对 + 后续回滚。

绝不删除、绝不改名。只调列表接口。

用法：
    python audit_promo_scope.py av fuliji          # 只统计
    python audit_promo_scope.py --full av fuliji   # 额外落全量疑似清单 JSON

落地时按目标系统替换 _list_children / ensure_all_folders / 判定函数三处。
"""
import json
import os
import sys

OUT = os.environ.get("AUDIT_OUT", "./audit-promo-full.json")


def walk(folder_id, label, rows, seen, depth=0):
    """递归遍历。seen 防环，depth 防病态嵌套。"""
    if not folder_id or str(folder_id) in seen or depth > 64:
        return
    seen.add(str(folder_id))
    for item in _list_children(folder_id, label):
        fid = item.get("fileId") or item.get("id")
        name = str(item.get("fileName") or item.get("name") or "")
        if not fid or not name:
            continue
        if item.get("resType") == 2:
            walk(fid, label + "/" + name, rows, seen, depth + 1)
            continue
        ext = os.path.splitext(name.lower())[1]
        # 旧规则命中（历史"广告"标记），用于比对误判
        old_marker = promotion_reason(name)
        if not old_marker:
            continue
        rows.append({
            "file_id": fid,
            "path": label + "/" + name,
            "ext": ext,
            "is_video": ext in VIDEO_EXTENSIONS,
            "old_marker": old_marker,
            # 新规则判定：空串 = 保留（正片/仅需剥名），非空 = 疑似广告
            "new_marker": ad_video_reason(name),
            # 剥名结果，用于验证"只是名字脏"还是"真没内容"
            "stripped": strip_site_watermark(name),
        })
    seen.remove(str(folder_id))


def main(categories):
    check_api_health()
    folders = ensure_all_folders()
    rows = []
    for key in categories:
        fid = folders.get(key)
        if not fid:
            continue
        walk(fid, key, rows, set())
        with open(OUT, "w", encoding="utf-8") as fh:
            json.dump(rows, fh, ensure_ascii=False)
        print("after %s: flagged=%d" % (key, len(rows)), flush=True)

    real_ads = [r for r in rows if r["new_marker"]]
    print("TOTAL flagged=%d  real_ads=%d  rename_only=%d"
          % (len(rows), len(real_ads), len(rows) - len(real_ads)))
    # 关键：逐条打印，人工看文件名比看计数可靠
    for r in real_ads[:20]:
        print("  AD:", r["path"][:110], "|", r["new_marker"])


if __name__ == "__main__":
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    main(args or ["av", "fuliji"])
