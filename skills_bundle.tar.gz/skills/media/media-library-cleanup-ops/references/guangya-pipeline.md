# 光鸭 / lemon-media-spider 清理链路实况

AWS 主机 `/home/ubuntu/lemon-media-spider`（**不是 git 仓库**，改动前手动 cp 到 `backups/`）。
主机时区 `Etc/UTC`，crontab 全按 UTC 写，注释里标 BJ（+8）。

## 执行链路（2026-10 实测）

```
crontab
 ├─ 0 6 * * *            auto_pipeline.py            # = BJ 14:00 主流水线
 │                        └ 第3段 sync_and_purify_guangya(defer_cleanup=True)  # 只入队，不扫描
 ├─ */30 22,23 * * *     delayed_clean.py            # = BJ 06:00-07:59
 ├─ */30 0-15  * * *     delayed_clean.py            # = BJ 08:00-23:59
 └─ 30 15    * * *       delayed_clean.py --final    # = BJ 23:30 末轮
                          └ run_video_only_clean(target_categories=[单个专区], dry_run=True,
                                                 apply_rename=args.apply_rename)
```

**历史真相**：`ultimate_cleaner.py`（真删+改名+提权，功能完整）只被 `sync_general_media.py`
和 `crawl_pikpaklove.py` import，而这两个脚本既不在 crontab 也不在 `auto_pipeline.py` 里
→ **从未执行过**。生产实际只跑 `video_only_cleaner`，且 `dry_run=True` 硬编码
（`delayed_clean.py:208`、`scheduled_sync_and_clean.py:349`）→ 清理长期完全空转。

## 关键文件

| 文件 | 职责 |
|---|---|
| `guangya_client.py` | API 客户端；`api_request` 内含入库门禁；`clear_recycle_bin` 与 `create_task` 在此层硬抛错 |
| `video_only_cleaner.py` | **生产清理器**：`_inventory` 分拣、`_recycle_ids` 移回收站、`_rename_ids` 剥名 |
| `ingest_guard.py` | 命名判定：`promotion_reason` / `ad_video_reason` / `looks_like_feature` / `strip_site_watermark` |
| `delayed_clean.py` | 单专区轮转调度，`--category` / `--apply-rename` |
| `scheduled_sync_and_clean.py` | 推送+净化主体，`defer_cleanup` |
| `media_file_policy.py` | `VIDEO_EXTENSIONS` 21 种、`RETAINED_EXTENSIONS` |
| `ultimate_cleaner.py` | 完整版但**未调度**，别误以为在跑 |

## token 机制（踩过 401 报废整轮）

- JWT 有效期 **2 小时**；全量递归 40–90 分钟，不主动续期就会跑到一半过期
- `guangya_session.json` 里的 `expires_at` 字段是陈旧值，**不可用**，只能解 JWT `exp`
- **LA（`ssh vps-la`）是唯一刷新源**：AWS 侧 `refresh_token.py` 首行 `return None` 硬禁用
- `guangya_client.ensure_fresh_token(margin=600)`：剩余 <600s 先 `sync()` 拉，仍不足则
  `force_refresh()` 让 LA 轮换再拉
- LA 侧 `refresh_token.py._atomic_save` 必须 `os.chown` 保持属主 `lemon-media`，
  否则 root 轮换后 worker 读不到 → 每 60 秒 401 空转（曾空转 1 天 12 小时）

## 接口

- 列表：`/userres/v1/file/get_file_list`（`PAGE_SIZE=100`，`READ_RETRIES=3`）
- 移回收站：`/userres/v1/file/delete_file`（≤50 个 fileId/批）
- 改名：`/userres/v1/file/rename`，`data={'fileId':..., 'newName':...}`；`code==160` 表示同名冲突

## 实测数字（2026-10-24，只读审计）

| 专区 | 文件夹 | 文件 | 干净正片 | 旧规则判"广告" | 水印前缀 |
|---|---|---|---|---|---|
| av | 3,537 | 18,362 | 15,203 | 2,020 | 1,139 |
| fuliji | 8,388 | 77,930 | 74,222 | 976 | 2,732 |
| 合计 | 11,925 | 96,292 | 89,425 | 2,996 | 3,871 |

非媒体杂项 = **0**。旧规则标的 2,996 个"广告"抽样 **全是正片**：
`user@example.com`、`hhd800.com@230ORECZ-056.mp4`、`[U6A6.COM]-最新国产网红-落地窗前.mp4`。
收紧规则后只剩 25 条进 review（`[U6A6.COM]-3.mp4`，父目录名带"全网磁力最快更新"，文件只剩编号）。

## 真跑结果（2026-10-24/25，`--apply-rename` 实测）

| 专区 | 文件总数 | 干净正片 | 剥名成功 | 分卷放行 | review | 删除 |
|---|---|---|---|---|---|---|
| av | 18,362 | 12,700 | **3,133 / 3,133** | — | 2,529 | **0** |
| fuliji | 77,930 | 72,315 | **3,486 / 3,486** | 3,551 | 2,129 | **0** |
| 合计 | 96,292 | 85,015 | **6,619** | 3,551 | 4,658 | **0** |

两轮均对账无误差（正片 + 剥名 + review = 总数）。实地回读抽查 10/10、8/8 全部
`新名存在=True / 旧名残留=False`。**被旧规则判成广告的 6,619 个文件全是正片，
真正该删的广告视频为 0** —— 旧规则若真跑起来就是一次性毁 6,619 个正片。

fuliji 全量扫描耗时 1 小时 1 分；剥名约 47 个/分钟（每次 rename ~1.2s 含网络）。

## 分卷放行（第二轮才修对）

第一版用 `is_titled_folder(label.split("/")[-1])` 判直接父目录，结果 fuliji 有 2,529 条
误进 review —— 因为真实结构是 `<完整标题>/V/<分卷>.mp4`，直接父目录是 `V`。

```python
def is_titled_folder(name):        # 父目录本身是完整标题吗
    # 长度 >= 8 且 无裸域名 且 不含 AD_VIDEO_MARKERS
def has_titled_ancestor(label, depth=3):   # 向上找 3 层
    for part in reversed(parts[-depth:]):
        if is_titled_folder(part): return True
```

放行效果：`🔞 福利姬/<长标题>/V/2048.cc-mp4_ (13).mp4` → 分卷正片，保留；
`🔞 成人专区/U6A6.COM_全网磁力最快更新_18369/V/3.mp4` → 父目录是广告页，仍进 review。
`AD_VIDEO_MARKERS` 补了 `全网磁力 / 磁力最快 / 最快更新` 才能拦住后者。

## 批量剥名的回滚

- 每次 rename 追加 `rename-audit-<ts>.jsonl`（`file_id/path/old_name/new_name/status`）
- 回滚：`python3 rename_rollback.py --journal rename-audit-<ts>.jsonl --apply`
  （默认 dry-run；只回滚 `status=="ok"` 的行）
- 验收：`python3 verify_rename.py <journal> <条数> <category>`，逐条进目录查
  `新名存在 && 旧名无残留`

## 队列成员校验

`delayed_clean.py --category X` 要求 X 在 `delayed-clean-targets.json` 的 `categories` 里，
否则 `指定专区不在当前清理队列中: X` 直接退出。专区被上一轮跑完会移出队列。
手工验证前：备份 JSON → 把专区加回 `categories` → 再跑。

## 判定函数要点

`looks_like_feature(name)` 白名单，命中即永不清理：
- `_EPISODE`：`S01E05` / `第12集` / `EP05`
- `_QUALITY`：`2160p|1080p|720p|4k|uhd|hdr|hevc|x264|h264|aac|bluray|web-dl|remux`
- `_CODE`：`[A-Z]{2,6}[-_ ]?\d{2,5}` / `FC2-PPV-\d{5,8}`（**必须区分大小写**，
  加 `re.I` 会把小写普通单词误判成番号）

`ad_video_reason` 顺序：正片特征 → 放行；剥名后仍有 ≥4 字符实质内容 → 放行（交给剥名）；
剩纯域名/空壳 → `promo_domain`；命中 `AD_VIDEO_MARKERS` → 宣传片。

## 入库 guard 拒收 → 不入库 → 无限重下（2026-10-29 实测，vps-la `lemon-vps-sync`）

`ingest_guard.py` 的 `PROMO_MARKERS` 不止用于清理器判「已入库文件要不要删」，**入库链路也会在 insert 之前拿它拒收**。两套用途别混：清理器判的是存量，guard 判的是「准不准进门」。

实测形态（`lemon-vps-sync` → 光鸭，非 media-spider 链路，但共用同一份 `ingest_guard.py`）：

- 文件名 `AI觉醒之拯救潘金莲_短剧视频在线观看_vert;_黄果短剧_md5_016091fd.mp4` 命中 `在线观看`
- 光鸭直传拒收：`光鸭直传只接受经过视频流验证的文件: promotion_marker:在线观看`
- 记录写 `failed`，但 worker **每轮重新「发现待处理」**，重下 126MB 再失败 —— 12 小时 9 次，约 2.9GB 纯浪费 + 54 条错误刷屏

必须同时查的两个配套缺陷：

1. **`retry_count` 可能从来没增长**：upsert 里写了 `retry_count=vps_sync_records.retry_count+1` 不等于生效。判据 `select max(retry_count) from vps_sync_records` —— 实测全表为 0，退避与上限全部形同虚设。
2. **被拒记录可能压根没入库，比写 failed 更糟**：若 guard 在 insert 之前就 return，该 msg 永远不在表里，于是永远「待处理」。判据是拿日志里的 ID 去 `select`：查不到 + 日志反复出现 = 插入前被拒。

**日志 ID 陷阱**：日志打 `db_id=3575`，但真实主键是 2120（3575 是 Telegram msg id）。按日志 ID 查库必然为空，**不要断言「记录丢失」**。正确做法：`select max(id)` 定位范围，再用文件名片段模糊匹配。

修法三条都要，只做一条仍会复发（2026-10-30 已落地并验证）：

1. **剥名优先于拒收**：判 `PROMO_MARKERS` 之前先剥站名水印（`_短剧视频在线观看`、`_vert;_<站名>`、`_md5_<hex>`、`_msg<NNN>`），剥完再判。这两条剥后就是干净正片 `AI觉醒之拯救潘金莲.mp4`、`母子同淫 第8集.mp4`。实现为 `strip_site_watermark()` 插在 `safe_name()` 之后、`upload_file_to_guangya()` 之前。

   正则顺序有讲究，**具体的放前面**，否则被通用规则先吃掉：

   ```python
   SITE_WATERMARK_PATTERNS = (
       r"__msg\d+",
       r"_md5_[0-9a-fA-F]{6,}",
       r"_vert;[-_\s]*[^\s_;]*短剧",
       r"[-_ ]*短剧视频在线观看",     # 必须在「在线观看」之前
       r"[-_ ]*视频在线观看",
       r"[-_ ]*在线观看",
       r"[-_ ]*[-–—]\s*[^\s_]{1,12}短剧(?=$|[-_. ])",
       r"[-_ ]*\[[^\]]{1,12}短剧\]",
   )
   ```

   字符类里 `-` 一律写在开头（`[-_ ]` / `[-_\s]`），写 `[_\- ]*[-–—]` 这种会让 `\-` 紧邻 `\s` 被解析成字符范围，`re.error: bad character range`。

   剥完必须回测**不误伤正常名**：`FC2-PPV-4658002_seg2.mp4`、`某部正常电影.2026.1080p.mkv` 应原样返回。

2. **有界重试**：`failed` 不是终态，主循环要显式加退避与上限，别指望 `failed` 自己停。实测落地方案：`MAX_RETRY=3`、`RETRY_BACKOFF_MINUTES={1:10, 2:60}`，`retry_count>=3` 视为终态封存不再捡。

   ```python
   def should_retry(row):        # row = get_record() 的 7 列 tuple
       if delivery_complete(row): return False
       if not row or len(row) < 7: return True
       if row[2] != 'failed': return True
       retry_count = int(row[5] or 0)      # 必须容错，历史数据可能是 str
       if retry_count >= MAX_RETRY: return False
       wait = RETRY_BACKOFF_MINUTES.get(retry_count, 0)
       if not wait: return True
       last = datetime.strptime(str(row[6]), '%Y-%m-%d %H:%M:%S').replace(tzinfo=timezone.utc)
       return (datetime.now(timezone.utc) - last).total_seconds() >= wait * 60
   ```

3. **`retry_count` 必须真的在涨**：原 `upsert_record` 的 `retry_count=vps_sync_records.retry_count+1` 只在 `ON CONFLICT` 分支触发，而 `not row` 才调 upsert → **冲突分支永不执行，全表恒 0**。正确做法是在 `update_target(..., status='failed')` 里 `retry_count=COALESCE(retry_count,0)+1`。

### 改退避前必须先扩 `get_record` 的列

`get_record()` 原本只 `SELECT id, gdrive_status, guangya_status, filename, media_type`，**没有 `retry_count` 和 `updated_at`**，直接按 `row[5]`/`row[6]` 取会 `IndexError`。必须先扩成 7 列（`RECORD_COLS` 常量），再写闸门；`row[1]`/`row[2]` 语义不变，其他调用点不受影响。

### 验收口径

- 闸门用 8 个状态用例断言，别只看代码：`success` 不重试 / `pending` 重试 / `failed,retry=0` 立即重试 / `retry=1,5min` 不重试 / `retry=1,11min` 重试 / `retry=2,30min` 不重试 / `retry=2,61min` 重试 / `retry=3` 封存
- 入库成功后**回读光鸭目录**核对文件名（`get_file_list` 按 fileId 找 `name`），不要只看日志里的 `[✓] 光鸭云盘上传成功`
- 修完要重置被卡住的行：`UPDATE ... SET guangya_status='pending', retry_count=0, last_error=NULL WHERE msg_id IN (...)`

⚠️ **别看到 `failed` 就以为它停了**。worker 是否尊重 `failed` 状态要单独验证：数同一 ID 的「发现待处理」日志出现次数，不是看 db 状态字段。

⚠️ **`temp_media_cache` 里的大文件不一定是孤儿**。看到 `.msg_<id>.download.mp4` 占 1.4GB 别急着删——先隔 20 秒看两次 `stat` 是否在增长。实测那个「1.48GB 残留」正是 FC2 频道当前在下的文件，删了就是从零重下。真孤儿只出现在**进程被 restart 掐死**的场景（`finally` 里的 `os.remove` 没跑到）。

⚠️ **`last_error` 会被 GDrive 轨覆盖**：`update_target(..., 'gdrive', 'disabled', error='GDrive轨已永久关闭')` 每轮都写 `last_error`，会把真实的光鸭错误冲掉。排查时别拿 `last_error` 当唯一证据，要看 journal 原文。

### 加了闸门之后的三个后续坑（2026-10-30/31 实测）

闸门挡住重试 ≠ 问题结束。这三条都是「修完之后才冒出来的」，且第一条会直接污染日报。

**1. 封存提示每轮刷屏，把日报错误数顶满**

`iter_messages(entity, reverse=True)` 每轮从头遍历整个频道，写成

```python
elif terminal_failed(row):
    logger.warning('终态失败已封存，不再重试 msg=%s retry=%s', msg.id, row[5])
```

就是**每条封存记录每轮打一条**。3 条记录 24 小时刷出 662 行，日报「业务失败 554」几乎全是它，真实故障只有 3 条。

```python
_SEALED_NOTIFIED = set()   # 模块级

elif terminal_failed(row):
    if msg.id not in _SEALED_NOTIFIED:
        _SEALED_NOTIFIED.add(msg.id)
        logger.warning('终态失败已封存，不再重试 msg=%s retry=%s', msg.id, row[5])
```

重启后应只出现一次。**这是加闸门时最容易带出来的副作用：闸门挡住了重试，没挡住遍历时的日志。** 验收方法：重启后 `journalctl --since <启动时间> | grep 封存 | grep -oE "msg=[0-9]+" | sort | uniq -c`，每条都必须是 1。

**2. 历史 `failed` 行 `retry_count=0`，闸门放行它们**

闸门按 `retry_count >= MAX_RETRY` 判终态，但**老记录全是 0**。只要那些 msg 还在频道里，就会被当可重试重新捡起来。实测 5 条 9-25 的 `The file reference has expired` 记录 `retry_count=0`，是定时炸弹。

```sql
UPDATE vps_sync_records SET retry_count=3
 WHERE guangya_status='failed' AND retry_count<3;
```

改前先 `cp -a vps_sync.db vps_sync.db.bak-seal5-<ts>`。改完 `select msg_id,retry_count` 确认全部到 3。

**3. `filename` 列不回写，库名与云端名长期不一致**

上传用的是局部变量 `filename`，成功分支只写 status/fid，`filename` 列还是入库时的原始水印名。光鸭上是干净名、db 里是脏名 → 下次排查看到 db 会以为剥名没生效。成功分支补一句：

```python
conn.execute('UPDATE vps_sync_records SET filename=? WHERE msg_id=?', (filename, db_msg_id))
conn.commit()
logger.info('[✓] 光鸭云盘上传成功: msg=%s fid=%s file=%s', msg.id, fid, filename)
```

日志加 `file=` 字段，回读光鸭 `get_file_list` 时能直接和 db 对账。

### `GetHistoryRequest flood wait` 不是故障，但会进日报「限流」

24h 实测 460 次 `Sleeping for 3s on GetHistoryRequest flood wait`。根因同上：每轮 `iter_messages(reverse=True)` 全量遍历历史，消息越多越慢越容易触发。Telethon 自动退避，INFO 级，业务无影响。

日报把它算进「限流」分类，会造成「限流 90 条」这种虚高。**根治要改成只拉最近 N 条增量，光调退避参数没用**；不动取数逻辑的话，在汇报里明确标注这部分是噪音。

### 改远端 python 不能用 `ssh host '...'` 内嵌引号

`ssh vps-la 'python3 -c "if row[2] != \"failed\": ..."'` 会被剥掉内层单引号，产出 `if row[2] != failed:` —— `py_compile` 照样通过，运行时才 `NameError`。**必须 `write_file` 到本地再 `ssh 'cat > /tmp/x.py' < /tmp/x.py` 传输执行。** 改完一律先 `py_compile` 再重启。

## 锁

`/tmp/lemon_video_only_sweep.lock`（`ProcessLock("lemon_video_only_sweep")`）、
`/tmp/lemon_media_delayed_clean_cron.lock`（flock）、`/tmp/lemon_media_pipeline_cron.lock`。
只读审计探针**不取**扫描锁，与 delayed_clean 并发会互相拖慢数倍，排期要错开。

## 测试

`test_cleaner_classification.py`（8 例分拣）、`test_ad_video_policy.py`（5 例/16 子测）、
`test_titled_folder.py`（10 例父目录/祖先目录放行）、`test_delayed_clean.py`、
`test_media_automation.py`、`test_targeted_cleanup_safety.py`。当前全量 **57 passed**。

给 `run_video_only_clean` 加 kwarg 时两处要同步：
- `test_delayed_clean.py:77` 的 `assert_called_once_with` 要补新参数（如 `apply_rename=False`）
- `test_media_automation.py` 里的 stub 要用 `lambda **kwargs:` 才吃得下新参数

mock 掉 `_rename_ids` 时记得设 `return_value=N`，否则 `renamed_files` 会拿到 MagicMock
导致断言失败（不是逻辑错）。
