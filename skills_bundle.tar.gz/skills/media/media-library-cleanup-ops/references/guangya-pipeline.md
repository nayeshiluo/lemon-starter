# 光鸭 / lemon-media-spider 清理链路实况

AWS 主机 `/home/ubuntu/lemon-media-spider`（**不是 git 仓库**，改动前手动 cp 到 `backups/`）。
主机时区 `Etc/UTC`，crontab 全按 UTC 写，注释里标 BJ（+8）。

## 执行链路（2026-10 实测）

```
crontab
 ├─ 0 6 * * *            auto_pipeline.py            # = BJ 14:00 主流水线
 │                        └ 第3段 sync_and_purify_guangya(defer_cleanup=True)  # 只入队，不扫描
 ├─ */30 22,23 * * *     delayed_clean.py            # = BJ 06:00-07:59
 ├─ */30 0-15  * * *     delayed_clean.py            # = BJ 08:00-23:59
 └─ 30 15    * * *       delayed_clean.py --final    # = BJ 23:30 末轮
                          └ run_video_only_clean(target_categories=[单个专区], dry_run=True,
                                                 apply_rename=args.apply_rename)
```

**历史真相**：`ultimate_cleaner.py`（真删+改名+提权，功能完整）只被 `sync_general_media.py`
和 `crawl_pikpaklove.py` import，而这两个脚本既不在 crontab 也不在 `auto_pipeline.py` 里
→ **从未执行过**。生产实际只跑 `video_only_cleaner`，且 `dry_run=True` 硬编码
（`delayed_clean.py:208`、`scheduled_sync_and_clean.py:349`）→ 清理长期完全空转。

## 关键文件

| 文件 | 职责 |
|---|---|
| `guangya_client.py` | API 客户端；`api_request` 内含入库门禁；`clear_recycle_bin` 与 `create_task` 在此层硬抛错 |
| `video_only_cleaner.py` | **生产清理器**：`_inventory` 分拣、`_recycle_ids` 移回收站、`_rename_ids` 剥名 |
| `ingest_guard.py` | 命名判定：`promotion_reason` / `ad_video_reason` / `looks_like_feature` / `strip_site_watermark` |
| `delayed_clean.py` | 单专区轮转调度，`--category` / `--apply-rename` |
| `scheduled_sync_and_clean.py` | 推送+净化主体，`defer_cleanup` |
| `media_file_policy.py` | `VIDEO_EXTENSIONS` 21 种、`RETAINED_EXTENSIONS` |
| `ultimate_cleaner.py` | 完整版但**未调度**，别误以为在跑 |

## token 机制（踩过 401 报废整轮）

- JWT 有效期 **2 小时**；全量递归 40–90 分钟，不主动续期就会跑到一半过期
- `guangya_session.json` 里的 `expires_at` 字段是陈旧值，**不可用**，只能解 JWT `exp`
- **LA（`ssh vps-la`）是唯一刷新源**：AWS 侧 `refresh_token.py` 首行 `return None` 硬禁用
- `guangya_client.ensure_fresh_token(margin=600)`：剩余 <600s 先 `sync()` 拉，仍不足则
  `force_refresh()` 让 LA 轮换再拉
- LA 侧 `refresh_token.py._atomic_save` 必须 `os.chown` 保持属主 `lemon-media`，
  否则 root 轮换后 worker 读不到 → 每 60 秒 401 空转（曾空转 1 天 12 小时）

## 接口

- 列表：`/userres/v1/file/get_file_list`（`PAGE_SIZE=100`，`READ_RETRIES=3`）
- 移回收站：`/userres/v1/file/delete_file`（≤50 个 fileId/批）
- 改名：`/userres/v1/file/rename`，`data={'fileId':..., 'newName':...}`；`code==160` 表示同名冲突

## 实测数字（2026-10-24，只读审计）

| 专区 | 文件夹 | 文件 | 干净正片 | 旧规则判"广告" | 水印前缀 |
|---|---|---|---|---|---|
| av | 3,537 | 18,362 | 15,203 | 2,020 | 1,139 |
| fuliji | 8,388 | 77,930 | 74,222 | 976 | 2,732 |
| 合计 | 11,925 | 96,292 | 89,425 | 2,996 | 3,871 |

非媒体杂项 = **0**。旧规则标的 2,996 个"广告"抽样 **全是正片**：
`user@example.com`、`hhd800.com@230ORECZ-056.mp4`、`[U6A6.COM]-最新国产网红-落地窗前.mp4`。
收紧规则后只剩 25 条进 review（`[U6A6.COM]-3.mp4`，父目录名带"全网磁力最快更新"，文件只剩编号）。

## 真跑结果（2026-10-24/25，`--apply-rename` 实测）

| 专区 | 文件总数 | 干净正片 | 剥名成功 | 分卷放行 | review | 删除 |
|---|---|---|---|---|---|---|
| av | 18,362 | 12,700 | **3,133 / 3,133** | — | 2,529 | **0** |
| fuliji | 77,930 | 72,315 | **3,486 / 3,486** | 3,551 | 2,129 | **0** |
| 合计 | 96,292 | 85,015 | **6,619** | 3,551 | 4,658 | **0** |

两轮均对账无误差（正片 + 剥名 + review = 总数）。实地回读抽查 10/10、8/8 全部
`新名存在=True / 旧名残留=False`。**被旧规则判成广告的 6,619 个文件全是正片，
真正该删的广告视频为 0** —— 旧规则若真跑起来就是一次性毁 6,619 个正片。

fuliji 全量扫描耗时 1 小时 1 分；剥名约 47 个/分钟（每次 rename ~1.2s 含网络）。

## 分卷放行（第二轮才修对）

第一版用 `is_titled_folder(label.split("/")[-1])` 判直接父目录，结果 fuliji 有 2,529 条
误进 review —— 因为真实结构是 `<完整标题>/V/<分卷>.mp4`，直接父目录是 `V`。

```python
def is_titled_folder(name):        # 父目录本身是完整标题吗
    # 长度 >= 8 且 无裸域名 且 不含 AD_VIDEO_MARKERS
def has_titled_ancestor(label, depth=3):   # 向上找 3 层
    for part in reversed(parts[-depth:]):
        if is_titled_folder(part): return True
```

放行效果：`🔞 福利姬/<长标题>/V/2048.cc-mp4_ (13).mp4` → 分卷正片，保留；
`🔞 成人专区/U6A6.COM_全网磁力最快更新_18369/V/3.mp4` → 父目录是广告页，仍进 review。
`AD_VIDEO_MARKERS` 补了 `全网磁力 / 磁力最快 / 最快更新` 才能拦住后者。

## 批量剥名的回滚

- 每次 rename 追加 `rename-audit-<ts>.jsonl`（`file_id/path/old_name/new_name/status`）
- 回滚：`python3 rename_rollback.py --journal rename-audit-<ts>.jsonl --apply`
  （默认 dry-run；只回滚 `status=="ok"` 的行）
- 验收：`python3 verify_rename.py <journal> <条数> <category>`，逐条进目录查
  `新名存在 && 旧名无残留`

## 队列成员校验

`delayed_clean.py --category X` 要求 X 在 `delayed-clean-targets.json` 的 `categories` 里，
否则 `指定专区不在当前清理队列中: X` 直接退出。专区被上一轮跑完会移出队列。
手工验证前：备份 JSON → 把专区加回 `categories` → 再跑。

## 判定函数要点

`looks_like_feature(name)` 白名单，命中即永不清理：
- `_EPISODE`：`S01E05` / `第12集` / `EP05`
- `_QUALITY`：`2160p|1080p|720p|4k|uhd|hdr|hevc|x264|h264|aac|bluray|web-dl|remux`
- `_CODE`：`[A-Z]{2,6}[-_ ]?\d{2,5}` / `FC2-PPV-\d{5,8}`（**必须区分大小写**，
  加 `re.I` 会把小写普通单词误判成番号）

`ad_video_reason` 顺序：正片特征 → 放行；剥名后仍有 ≥4 字符实质内容 → 放行（交给剥名）；
剩纯域名/空壳 → `promo_domain`；命中 `AD_VIDEO_MARKERS` → 宣传片。

## 锁

`/tmp/lemon_video_only_sweep.lock`（`ProcessLock("lemon_video_only_sweep")`）、
`/tmp/lemon_media_delayed_clean_cron.lock`（flock）、`/tmp/lemon_media_pipeline_cron.lock`。
只读审计探针**不取**扫描锁，与 delayed_clean 并发会互相拖慢数倍，排期要错开。

## 测试

`test_cleaner_classification.py`（8 例分拣）、`test_ad_video_policy.py`（5 例/16 子测）、
`test_titled_folder.py`（10 例父目录/祖先目录放行）、`test_delayed_clean.py`、
`test_media_automation.py`、`test_targeted_cleanup_safety.py`。当前全量 **57 passed**。

给 `run_video_only_clean` 加 kwarg 时两处要同步：
- `test_delayed_clean.py:77` 的 `assert_called_once_with` 要补新参数（如 `apply_rename=False`）
- `test_media_automation.py` 里的 stub 要用 `lambda **kwargs:` 才吃得下新参数

mock 掉 `_rename_ids` 时记得设 `return_value=N`，否则 `renamed_files` 会拿到 MagicMock
导致断言失败（不是逻辑错）。
