# 清理判定正则与实测数据

来源：2026-10-24 光鸭云盘「柠檬影视库」去广告清理审计（AWS 主机，`/home/ubuntu/lemon-media-spider`）。

## 一、实测数字

| 专区 | 文件夹 | 文件 | 干净正片 | 旧规则判"广告" | 带水印前缀 |
|---|---|---|---|---|---|
| av | 3,537 | 18,362 | 15,203 | 2,020 | 1,139 |
| fuliji | 8,388 | 77,930 | 74,222 | 976 | 2,732 |
| 合计 | 11,925 | 96,292 | 89,425 | 2,996 | 3,871 |

**非媒体杂项（`.txt` / `.url` 之类）= 0。**

av 的 2,020 条全量复核结果：

- 命中正片特征（番号/清晰度）→ 保留：450
- 剥名后仍有实质内容 → 只剥名：1,545
- 剥名后只剩编号（如 `[U6A6.COM]-3.mp4` → `3`），父目录名带广告 → 待复核：25
- **确认为广告片：0**

旧规则标记词分布：`u6a6` 1550、`hhd800` 290、`489155.com` 85、`4k2.com` 64、`169bbs.com` 28、`dccdom` 3。

### av 专区实际执行结果（2026-10-25，`--apply-rename`）

| 分拣项 | 数量 |
|---|---|
| 扫描文件总数 | 18,362 |
| 干净正片（原样保留） | 12,700 |
| 水印剥名 | 3,133（成功 3,133/3,133） |
| 待人工复核 | 2,529 |
| 垃圾删除 / 移回收站 | 0 / 0 |

12,700 + 3,133 + 2,529 = 18,362，对账无误差。实地抽查 10/10：新名 fileId 匹配、旧名无残留。

**注意 3,133 ≠ 审计的 2,020**：审计只统计「旧规则命中广告词」的文件，剥名统计的是**所有带站点前缀**的文件（含旧规则没命中的，如 `2048.cc-mp4_ (1).mp4`）。剥名口径应以后者为准。

2,529 条 review 中大部分是**分卷正片误标**（完整标题在父目录名上），说明 review 规则必须先加父目录放行，否则复核列表被噪音占满。

## 二、正片特征白名单（放行优先级最高）

```python
_EPISODE = re.compile(
    r"(?<![A-Za-z0-9])(?:S\d{1,2}\s*E\d{1,3}|第\s*\d{1,4}\s*[集话話期]|EP?\s*\d{1,4})(?![0-9])",
    re.I)
_QUALITY = re.compile(
    r"(?<![A-Za-z0-9])(?:2160p|1080p|720p|4k|uhd|hdr|hevc|x26[45]|h\.?26[45]|aac|bluray|web-?dl|remux)(?![A-Za-z0-9])",
    re.I)
# 番号：大写字母前缀，故意不加 re.I，避免小写单词被误判
_CODE = re.compile(
    r"(?<![A-Za-z0-9])(?:[A-Z]{2,6}[-_ ]?\d{2,5}|FC2[-_ ]?PPV[-_ ]?\d{5,8})(?![A-Za-z0-9])")

def looks_like_feature(name):
    text = str(name or "")
    return bool(_EPISODE.search(text) or _QUALITY.search(text) or _CODE.search(text))
```

`_CODE` 不加 `re.I` 是关键：加了会把 `abc123` 这种小写词当番号，放过真广告。

## 三、强广告词（剥名后仍空壳才算）

```python
AD_VIDEO_MARKERS = (
    "最新地址", "永久地址", "地址发布", "更新地址", "最新网址", "获取地址",
    "发布页", "防走丢", "收藏不迷路", "扫码", "二维码", "加群", "福利群",
    "免费看片", "免費看片", "点击加入", "点击进入", "购买更多", "更多精彩",
    "在线观看", "資源更新", "资源更新", "公告", "导航", "導航", "论坛文宣",
    "論壇文宣", "宣传片", "宣传视频", "博彩", "菠菜", "澳门荷官", "约炮",
    "解压密码", "吃瓜", "海角社区", "茶馆儿", "20年信誉保证",
)
```

## 四、判定函数（顺序即安全边界）

```python
def ad_video_reason(*values):
    raw = " ".join(str(v or "") for v in values)
    if not raw.strip():
        return ""
    if looks_like_feature(raw):          # 1. 正片特征 → 放行
        return ""
    stripped = ""
    for value in values:                 # 2. 逐个尝试剥站点水印
        candidate = strip_site_watermark(str(value or ""))
        if candidate:
            stripped = candidate
            break
    if stripped:
        if looks_like_feature(stripped):
            return ""
        residue = Path(stripped).stem.strip(" -_.@[]()")
        if len(residue) >= 4:            # 剥完还有实质标题 → 只是脏名字
            return ""
    if _PROMO_DOMAIN.search(raw):        # 3. 只剩域名/空壳
        return "promo_domain"
    normalized = _normalize(raw)         # 4. 强广告词
    for marker in AD_VIDEO_MARKERS:
        if _normalize(marker) in normalized:
            return marker
    return ""
```

**反面教材**：早期版本写成「无正片特征 + 命中裸域名 → 判广告」，把 `hhd800.com@230ORECZ-056.mp4` 全判成广告。必须先剥名再看残留。

### 父目录放行（分卷正片）

文件名只剩编号时，唯一能判的依据是父目录名：

```python
def is_titled_folder(name):
    text = str(name or "").strip()
    if len(text) < 8:
        return False
    if _PROMO_DOMAIN.search(text):       # 父目录本身是域名页
        return False
    normalized = _normalize(text)
    for marker in AD_VIDEO_MARKERS:      # 父目录带广告词
        if _normalize(marker) in normalized:
            return False
    return True
```

调用位置：`ad_video_reason(name)` 命中后、写入 review 之前。父目录 `is_titled_folder()` 为真 → 计入 `video_clean` + `volume_in_titled_folder`，不进 review。

强广告词需补 `全网磁力`、`磁力最快`、`最快更新`，否则 `U6A6.COM_全网磁力最快更新_18369` 这类站方广告目录会被当成完整标题放行。

## 五、光鸭 API 要点

| 用途 | 端点 |
|---|---|
| 列目录 | `/userres/v1/file/get_file_list`（分页 100/页，需读全 total） |
| 移入回收站 | `/userres/v1/file/delete_file`（`fileIds` 批量，50/批） |
| 重命名 | `/userres/v1/file/rename`（`fileId` + `newName`，单条） |
| 永久清空回收站 | `/userres/v1/file/clear_recycle_bin` — **客户端显式抛错，禁止调用** |

重命名会遇到同名冲突，返回 `code == 160`，需追加 ` (1)`、` (2)` 重试。

## 六、审计探针写法

只读递归，输出四类计数 + 抽样路径，绝不调删除/改名接口：

```python
def walk(folder_id, label, rows, seen, depth=0):
    if not folder_id or str(folder_id) in seen or depth > 64:
        return
    seen.add(str(folder_id))
    for item in _list_children(folder_id, label):
        if item.get("resType") == 2:
            walk(item["fileId"], label + "/" + item["fileName"], rows, seen, depth + 1)
            continue
        ...  # 统计
    seen.remove(str(folder_id))   # 允许同一目录被不同父级引用，但防环
```

中途把已扫完专区的结果**落盘成 JSON**，这样长时间扫描被中断时不必从头再来。

## 七、token 过期实证

- JWT `iat 05:26 UTC / exp 07:26:23 UTC`
- 清理任务 `06:19:28` 起跑，`07:26:33` 报 `HTTP Error 401` —— **距过期 10 秒**
- 整轮 67 分钟白跑

对策：扫描前解 JWT 算剩余秒数，低于 600 秒主动续期，不要等 401。文件里自带的 `expires_at` 字段可能是陈旧值（实测写着前一天），不可信。
