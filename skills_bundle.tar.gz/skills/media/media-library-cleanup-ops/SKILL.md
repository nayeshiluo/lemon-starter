---
name: media-library-cleanup-ops
description: Use when 清理云盘影视库垃圾/广告文件或批量重命名。先证执行链路，再测误判率，剥名优先于删除。
version: 2.0.0
author: lemon
license: MIT
metadata:
  hermes:
    tags: [media, cleanup, deletion-safety, cloud-drive, guangya, dry-run, rename, audit]
    related_skills: [emos-upload-pipeline, backup-chain-audit, selfhosted-service-audit]
---

# 云盘影视库清理与删除安全

适用于任何「影视库去广告 / 清垃圾 / 批量重命名」任务：光鸭、EMOS、AList、GDrive 挂载盘同理。
核心原则：**删除是最后手段，「清理没生效」往往不是规则问题，而是执行链路根本没接通。**

## When to Use / 触发条件

- 用户说「清理/去广告/垃圾文件处理一直有问题」「广告文件没清掉」「清理好像没生效」
- 用户说「帮我清理广告视频」，要对云盘影视库做批量删除、批量重命名
- 要给云盘（光鸭/Emby 库/AList）加自动去广告、去杂质、规范化重命名
- 要评估一个清理规则能不能开真删（开「真删」开关前的安全评审）
- 清理器有候选、有日志、有统计，但库里文件数量不见少
- 清理日志里长期 `candidates: []`、只有「预览完成」、或计数为 0

## 一、先判空转，再判规则——顺序不能反

「清理不生效」绝大多数不是规则错，是**根本没执行**。按这三层依次排除，每层都要有硬证据：

| 层 | 检查 | 空转特征 |
|---|---|---|
| 1. 执行层 | 所有调用点是否硬编码 `dry_run=True` | `grep -rn "dry_run=True"` 全中；日志每轮都是「预览完成，未删除文件」 |
| 2. 候选层 | 候选判定条件是什么 | 只按扩展名判（非媒体扩展名才算候选），而库里杂项实测为 0 → `candidates` 永远 `[]` |
| 3. 调度层 | **能真删的那个函数到底有没有被调度** | 仓库里有两套清理器，crontab 只跑 dry_run 那套；能真删的 `ultimate_cleaner` 只被两个不在 crontab、不在流水线里的脚本 import → **从未执行过** |

第 3 层最容易漏。诊断动作固定为：

1. `crontab -l | grep -v '^#'` 取真实入口
2. 读入口文件，找到清理调用的那一行
3. `grep -n "dry_run" <cleaner>.py` 看实参
4. 顺着 import 链追到最终函数
5. `grep -rn "<能真删的函数名>" --include=*.py .` 看谁调用它、那些调用者是否在调度里

**别看到函数存在就当它在跑。功能「存在」≠「在跑」，`systemctl active` / 进程存活同样不能证明业务动作发生。**

历史日志的 `candidates: []` 出现次数是最快的空转证据：连续十几轮空，说明判定条件永远不成立，不是「库里很干净」。验收口径是日志里必须出现「删除/改名计数 > 0」的实证。

## 二、用真实数据测误判率，再决定删什么

**绝不允许凭规则名或单元测试就开删。** 必须先做只读全量统计（见 `scripts/audit_promo_scope.py`）：

- 递归遍历目标专区，统计总数 / 疑似广告 / 水印前缀 / 真垃圾
- **抽样人工看文件名**，逐条判断规则判对没有
- 算出「如果按规则执行会删掉多少个真文件」

两次不同批次的实测教训（数字不可混用，分别对应不同专区不同轮次）：

- 某轮：规则把 **2,996 个带站点水印前缀的正片**判成广告
- 另一轮：某专区 18,362 个文件里 **2,020 个**被旧规则标记为「广告」，抽样与全量复核后**真正的广告片为 0**

若直接开删就是一次性毁库。**误判率接近 100% 的规则，在 dry_run 阶段看起来和正常规则一模一样。**

## 三、站点域名前缀 ≠ 广告文件（本类问题最大的坑）

清理器普遍用「广告词命中」判广告，而站点水印是**文件名前缀**，会被一起命中：

```
user@example.com      ← 番号 FPRE053，正片，只是带水印
hhd800.com@230ORECZ-056.mp4     ← 正片
[U6A6.COM]-最新国产网红-落地窗前.mp4  ← 正片
```

判据必须分层，顺序不可调换（宁可漏删，不可误删）：

1. **正片特征白名单优先**：命中番号 / 集数 / 清晰度编码 → 直接放行，永不清理，哪怕名字里混了广告词
2. **剥名后仍有实质内容** → 是「脏名字的正片」，走剥名，不是删除
3. **剥名后只剩编号/空壳 + 父目录名是广告** → 无法判定，进人工复核，不自动删
4. **只剩纯域名 / 命中强引流词** → 才算广告片

域名前缀只能作为「需要剥名」的信号，**不能单独构成广告判定**。正则与实测数据见 `references/cleanup-rule-regex.md`。

## 四、四类分拣模型

一个 inventory 遍历要同时产出四类，不要只产出「候选」：

| 类别 | 判定 | 动作 |
|---|---|---|
| 正片 | 番号 / 集数(S01E05、第12集) / 清晰度编码(1080p、HEVC) | 保留，永不触碰 |
| 水印正片 | 前缀是站点域名，剥掉后有实质内容 | **剥名**（rename），不删 |
| 疑似广告 | 剥名后只剩 `3`、`01` 这类空壳，或纯引流词；父目录带广告词 | 进 `review` 列表，人工确认 |
| 非媒体杂项 | 扩展名不在媒体/字幕/图片白名单 | 删除候选（通常实测为 0） |

任何一类判不准就往保守方向倒。

**关键设计**：`candidates`（删）与 `renames`（改）必须是两个独立列表、两个独立开关。混在一起就会出现「为了去水印而删文件」。能改名解决的绝不动删除——改名可逆、可从审计 JSON 完整回滚；删除不可逆。

## 五、剥名必须自带回滚（强制）

重命名是可逆操作，但前提是你记下了原名。**没有回滚日志的批量改名不要上生产**，哪怕规则测过。

每次 rename 追加写一行 JSONL，文件名带时间戳：

```
rename-audit-<YYYYmmdd-HHMMSS>.jsonl
{"file_id":..., "path":..., "old_name":"user@example.com", "new_name":"FPRE053.FHD.mkv", "status":"ok|failed", "error":...}
```

- 成功和失败**都记**，失败带 `error`，便于区分「没改」和「改错了」
- 每行写完 `flush()`，中途被 kill 也保留已完成部分
- 配套回滚脚本：读 `status=="ok"` 的行，把 `new_name` 换回 `old_name`，默认 dry-run，`--apply` 才执行

回滚脚本要**独立于清理器**（只依赖 client 的 rename 接口），避免「清理器坏了连回滚都跑不了」。

## 六、验收必须回读源，不能信返回值

API 返回 `success` 只代表请求被接受。批量改名/删除后必须**重新列目录核对**：

- 改名：目标目录里 `新名存在 == True` **且** `旧名残留 == False`（两个条件都要查，只查新名会漏掉「改名成副本、原件还在」）
- 删除：确认 fileId 不在原目录列表中
- 抽样 8–12 条即可，但必须是**真实目录读取**，不是重放日志

日志里的 `renamed_files: 3133/3133` 只能证明 API 都返回了成功，不能替代这一步。

## 七、可执行路径的安全闸门

- `dry_run=True` 保持默认，实际删除必须 `dry_run=False` **且**显式传非空分类（`target_categories=None` 直接 raise）
- 改名与删除**分开开关**（`apply_rename` 独立参数），互不绑定
- **先盘后删**：所有目录 inventory 完整结束才允许发第一个 mutation 请求；任何列表页读取失败立即抛 `IncompleteVideoSweep`，不带着残缺清单去删
- 单批次 ≤50 个 fileId，之间 `sleep`，失败必须打印而非静默吞
- 禁止调用永久清空回收站的接口（本项目 `clear_recycle_bin` 已在 client 层硬抛错），只移回收站

## 八、给调度留出锁

全量递归扫描动辄 30–90 分钟。若主流水线独占扫描锁，后续所有补偿轮次会被 flock 挡掉（日志表现为反复 `Lock is busy` / `ProcessLockBusy`）。

- 主流水线只做「入队」（`defer_cleanup=True`），真正扫描交给独立的单专区轮转任务
- 每个轮次独立进程、独立 token，避免长任务跑一半 token 过期整轮报废
- 只读审计探针**不要**和清理任务并发跑同一批目录，会互相拖慢数倍

### 8.1 一个超大专区会吃掉整个轮转窗口（2026-11 实测）

轮转队列里只要有一个「巨无霸」专区，整个调度就被它拖垮，而症状会伪装成锁竞争：

**现象**：每日兜底任务连续 **9 天** `SKIPPED_LOCK / exit 75`；常规轮次也大量跳过；
`automation-observations.py` 里 `delayed-clean` 长期 `RUNNING`。

**先别信「SKIPPED_LOCK = 正常锁竞争」这个默认结论**（本技能坑 17 就是这么写的）。要查两件事：

```bash
# ① 当前持锁进程跑了多久（和调度间隔对比）
ps -eo pid,etime,lstart,cmd | grep delayed_clean | grep -v grep
# ② 它在扫哪个专区、卡在哪个目录
cat /home/ubuntu/.local/state/lemon-media-spider/delayed-clean.json
tail -5 /home/ubuntu/lemon-media-spider/delayed-clean.log
# ③ 队列里到底有几个专区
cat /home/ubuntu/lemon-media-spider/delayed-clean-targets.json | head
```

本次实据：持锁进程 `etime` **1 小时 11 分**，而调度间隔 **30 分钟**；队列只有 3 个专区
（`anime / fuliji / tv`），`fuliji` 顶层 **2984 条、约 1500 个子目录**，光鸭每个目录请求固定
**2–3 秒**，递归下来就是 70 分钟 → 它占掉 1/3 轮次却吃掉 **80% 的窗口**，其余专区和每日兜底全饿死。

**判读要点**：日志长时间只有 2 行（目标专区 + 一次重试）**不代表卡死**——扫描成功不打日志，
递归本身就在正常推进。用 `etime` vs `interval` 比，比看日志可靠。

**三条杠杆，按性价比排序**：

1. **加大分页**，减少每层页数。光鸭单页响应以固定开销为主（`pageSize=100` ≈ 2.0s，
   `pageSize=500` ≈ 2.6s），所以 `PAGE_SIZE 100 → 500` 直接把顶层从 30 页降到 6 页：

   ```python
   # video_only_cleaner.py
   PAGE_SIZE = 500   # 实测 fuliji 顶层 2984 条，16.79s 扫完（原 100 需 30 页）
   ```

   分页正确性靠 `total` 与 `page * PAGE_SIZE` 判断，改 `pageSize` 不影响结果。
   ⚠️ 但对「每个子目录只有 1 页」的递归场景**无效**——时间花在子目录**数量**上，不是页数上。

2. **给超大区单独降频**，让它不占常规轮转。加 `--skip-categories`，常规 cron 排除它：

   ```python
   parser.add_argument("--skip-categories", nargs="*", default=[],
                       help="本轮轮转跳过的专区；超大区由独立低频调度单独覆盖")
   # 仅在未显式 --category 时生效
   skipped = {str(c) for c in args.skip_categories}
   if skipped and args.category is None:
       remaining = [c for c in categories if c not in skipped]
       if not remaining:
           write_state("NO_WORK", final_run=args.final, **cursor); return 0
       categories = remaining
   ```

   然后常规轮转 `--apply-rename --skip-categories fuliji`，另设
   `0 1,5,9,13,17,21 * * * ... --category fuliji`（每 4 小时，共用同一把锁）。
   改完先干跑验证轮转顺序：`choose_category(['anime','tv'], last_category='anime')` → `tv`。

3. **每日兜底任务挪进空窗期**。若常规轮转跑 UTC 6–23，就把 `delayed-clean-final` 从
   `30 23`（和常规轮转同一时刻，**必然撞车**）挪到 `15 0`（UTC 0:15，常规不跑）。

**顺带确认 `--final` 到底干什么**：本项目里它只是 `write_state(final_run=...)` 的一个标记，
**没有实际功能**。所以兜底任务长期跑不成，业务上其实零损失——真正的清理全在常规轮次。
知道这点才能正确告知用户「影响为零」，而不是跟着报警一起紧张。

**改调度前必须**：`crontab -l > /home/ubuntu/crontab.bak-$(date +%Y%m%dT%H%M)`，
用 Python 改行（不要手写整份 crontab），装完 `crontab -l | grep <关键词>` 回读确认。
cron 不能表达 90 分钟间隔，别在这上面绕。

## 九、灰度流程（固定顺序，不跳步）

1. **只读全量审计**：递归统计各专区的 `files / 正片 / 旧规则命中 / 剥名候选`，抽样打印真实路径
2. **抽样人工核对**：把「被判为广告」的样本逐条看，确认是不是正片。这一步直接决定规则对不对
3. **单专区 dry-run**：用真实 API 跑一遍分拣，核对数字与审计一致
4. **单专区 apply**：只开剥名（可逆），不开删除
5. **抽查验收必须读回云盘**：按第五节回滚日志里的 `path` 逐层下钻目录，执行第六节的三项核对。**10/10 通过才算落地**，只报「3133/3133 成功」是不合格的验收
6. 全绿后才考虑删除开关

## 十、坑

1. **只按扩展名判候选** → 云盘里非媒体杂项可能实测为 0，`candidates` 恒空，看起来「清理正常」其实什么都没做。
2. **把域名前缀当广告证据** → 批量误删正片。见第三节。
3. **剥名后为空才算广告**：`[SITE.COM]-3.mp4` 这种父目录名带广告词、文件只剩编号的，归 review，不自动删。
4. **crontab 文件末尾必须有换行**：`crontab /tmp/file` 报 `new file is missing newline before EOF, can't install` 就是缺末尾 `\n`，补上再装。装完必须 `crontab -l` 回读确认。
5. **每 30 分钟的 cron 会抢扫描锁**：手工跑长任务前先临时注释调度行并**备份原 crontab**，跑完立刻恢复。否则 `ProcessLockBusy` 直接把你的进程顶掉，白等一轮。
6. **两个进程同时全量扫同一专区会互相拖慢一倍**：只读探针不占业务锁，会和 cron 轮并发打同一批 API。审计与清理不要并行，先 kill 重复的那个。
7. **长扫描必须处理 token 过期**：全量递归 40~90 分钟，而会话 token 常只有 2 小时。跑一半过期 = 整轮报废（实测 67 分钟白跑，报 401 时距 token 过期只差 10 秒）。扫描前主动续期，不要等 401。
8. **`expires_at` 字段可能是陈旧值**：只信 JWT 里的 `exp`，解出来算剩余秒数。
9. **状态文件要记分拣明细**：只记 `retained_files` 看不出清理干了什么，至少记 `video_clean / rename_files / renamed_files / review_files / junk_files`。
10. **「剥名后过短」不一定是广告，必须看祖先目录**：完整标题常在文件夹名上，文件本身就叫 `1.mp4`、`mp4_ (1).mp4`。用祖先目录名一起判，判据三条全满足才算分卷正片、直接放行：

    - 目录名长度 ≥ 8 字符
    - 目录名不含裸域名（`xxx.com` 这类）
    - 目录名不含强广告词（最新地址/永久地址/全网磁力/磁力最快/最快更新…）

    **只看直接父目录一定漏判**：云盘最常见结构是 `<完整标题>/V/<分卷>.mp4`，中间夹着 `V`、`MKV`、`video` 这类容器目录，直接父目录是 `V`（长度 1），判定必然失败。必须**向上找最近 3 层祖先目录**，任一满足就放行：

    ```python
    def is_titled_folder(name):
        text = str(name or "").strip()
        if len(text) < 8: return False
        if _PROMO_DOMAIN.search(text): return False
        return not any(_normalize(m) in _normalize(text) for m in AD_VIDEO_MARKERS)

    def has_titled_ancestor(label, depth=3):
        parts = [p for p in str(label or "").split("/") if p.strip()]
        return any(is_titled_folder(p) for p in reversed(parts[-depth:]))
    ```

    对比效果：`-牛逼富二代，专玩年轻嫩妹子…/V/2048.cc-mp4_ (1).mp4` → 祖父目录是完整标题，分卷正片放行；`U6A6.COM_全网磁力最快更新_18369/V/3.mp4` → 祖先里没有完整标题，仍进 review。

    **自检方法**：拿规则声称「应放行」的那个真实路径，直接喂给判定函数跑一遍。示例路径判定失败就说明层级没找对——这是最容易在文档里自相矛盾的地方，代码和示例必须对得上。实测某专区 18,362 个文件里 **2,529 个进了 review，其中大部分是这类误标**——review 列表被误标占满就彻底失去人工复核的意义，必须先修放行规则再看 review。

11. **`--category X` 要求专区在清理队列里，不是 bug**：专区被上一轮处理完会自动从 `delayed-clean-targets.json` 的 `categories` 移除，此时手工跑 `--category X` 直接报「指定专区不在当前清理队列中: X」并退出（exit 1）。这是防止对未列入清理范围的专区动手的保护机制。要单独跑某个专区，先备份队列 JSON、把专区加回 `categories`，再执行；跑完让调度自然轮转，不要长期手工塞。

12. **长任务与 cron 抢窗口的完整流程**：`crontab -l > 备份` → 把调度行前缀注释（保留原行内容，便于还原）→ `crontab 新文件` → `crontab -l | grep -c 注释标记` 确认 → 跑任务 → 去掉注释还原 → `diff 备份 当前` 确认只差末尾换行。注释期间自动清理是停的，**跑完必须立刻恢复并回读确认**，别把暂停状态留到下一轮。

13. **改代码不影响正在跑的进程，只有下一轮生效**：Python 已把模块加载进内存，全量扫描跑起来之后再去改判定函数，当前这轮仍用旧规则。发现规则漏洞时：①先改代码补测试；②**不要为修正统计噪音重跑 1 小时全量**——review 列表只是标记、从不删除，数据零风险，等下一轮 cron 自然生效即可；③如果漏洞会导致误删（而不只是误标），才必须 kill 当前轮。判断标准是「会不会产生不可逆动作」，不是「数字好不好看」。

14. **长任务只看进程存活** → 扫描阶段日志可能长时间只有一行；用「已处理/总数 + 速率 + 预计剩余」判断进度，不要用 `ps` 存活当「在正常工作」的证据。

15. **改完就报成功**：必须真跑一轮拿到 `renamed_files` / `recycled_files` 计数才算验收。

16. **测试要断言「不该删的没被删」**，只断言「该删的删了」是半张网。

17. **`exit_code=2` 是「等人工授权」，不是崩溃**。`delayed_clean.py` 发现候选就 `write_state("ACTION_REQUIRED")` 并 `return 2`，这是「删除前须授权」规则的实现。日志侧表现完全正常（`[video-only] 清理完成: {...}` 照常打印），只有 cron 状态文件里是 FAILED：

    ```bash
    cd /home/ubuntu/.local/state/automation-cron && cat delayed-clean.json   # status/exit_code
    ```

    看到 `FAILED / exit_code: 2` 先去日志找 `[dry-run] 垃圾候选:` 那一行，**不要当故障排查**。`SKIPPED_LOCK`（exit 75）是 flock 抢占失败，上一轮没跑完，正常跳过。

18. **名字只剩扩展名的真视频会被判成「非媒体垃圾」，卡住整条清理链**。实例：`🌸 动漫专区/.mkv`（`fid=1939564575395180549`），`delayed-clean` 每 30 分钟报一次 `[dry-run] 垃圾候选: 🌸 动漫专区/.mkv`、恒 `ACTION_REQUIRED`（exit 2），`delayed-clean-final` 连带 `SKIPPED_LOCK`。

    **根因既不是目录、也不是损坏视频**：`os.path.splitext('.mkv')` 返回 `('.mkv', '')` —— 点开头的名字被当成纯隐藏文件名，**扩展名是空字符串**，于是 `ext not in RETAINED_EXTENSIONS` 成立，直接进 `candidates` 判 `non_media`。该文件实际是完好的 301MB MKV：

    ```
    fileName: ".mkv"   fileSize: <YOUR_USER_IDENTIFIER>   mineType: "video/x-matroska"
    resType: 1 (文件)  ext: ".mkv"
    ```

    修法（`video_only_cleaner.py` 的 `_inventory`）：扩展名为空时回退到接口的 `ext` 字段

    ```python
    ext = os.path.splitext(name.lower())[1]
    if not ext:
        ext = str(item.get("ext") or "").lower()
        if not ext.startswith("."):
            ext = "." + ext if ext else ""
    ```

    **元数据字段陷阱（本次踩实）**：别用 `size` / `dir` 判类型，光鸭列表接口给的是 `fileSize` / `resType`（1=文件、2=目录）/ `dirType` / `mineType`。用 `item.get("size")` 和 `item.get("dir")` 取到 `None`，就会把 301MB 正片误判成「空目录」，排查方向整体跑偏。**定性可疑条目时打印完整 JSON，不要只挑两个字段看。**

    处置顺序：①先修判定 bug；②再给文件补可识别名（如 `待认领_301MB_20260825.mkv`）并写 rename 审计日志；③跑单专区复扫验收 `候选=0 / junk_files=0 / exit 0`、`delayed-clean` 转 `SUCCESS_PREVIEW`。**不要删** —— 名字丢失不等于内容垃圾，301MB 的 `video/x-matroska` 该保留待认领。

19. **`delayed_clean.py` 在 naye 本机，不在 vps-la**。它的数据在光鸭云盘，容易误以为跑在光鸭那台。本机跑探针：

    ```python
    import sys, os
    sys.path.insert(0, "/home/ubuntu/lemon-media-spider"); os.chdir("/home/ubuntu/lemon-media-spider")
    from update_categories import ensure_all_folders, FOLDER_MAP
    from video_only_cleaner import _list_children
    ids = ensure_all_folders()
    items = _list_children(ids["anime"], "anime")   # folder_id 例：1938837752998539273
    ```

    注意 `api_request` 的列表接口是 **POST + camelCase**（`parentId` / `pageSize` / `page`），根目录传 `parentId=''` 而不是 `0`；传 `0` 或 GET 会返回 0 项或 404，看起来像「云盘空了」。

## 十二、调度状态 vs 业务状态：别把语义当故障

日报/监控里的「媒体=PARTIAL」由三层流水线合成，清理只是其中一层。判读顺序：

```bash
cd /home/ubuntu/hermes-jobs && /usr/bin/python3 -I automation-observations.py \
 | /usr/bin/python3 -c "import json,sys; d=json.load(sys.stdin); print(json.dumps(d.get('media',{}),ensure_ascii=False,indent=1)); print(json.dumps(d.get('alerts',[]),ensure_ascii=False))"
```

| 层 | PARTIAL 的真实含义 | 是不是故障 |
|---|---|---|
| `auto-pipeline` | 本批磁力下发没全成功 | 看下一层数字 |
| `guangya-sync` | `pushed+blocked+permanent_rejected+failed = total_pending`，被机制拦截的部分算进 PARTIAL | 机制拦截合理，只有 `failed` 是真异常 |
| `delayed-clean` | 有候选等人工确认 | 不是 |

`blocked` / `permanent_rejected` 的常见原因（都是合理拦截，不是 bug）：

- `no_clean_video_in_torrent` — 种子文件索引里没有可识别的干净正片，多V合集（20V/25V/21V）高发
- `placeholder_name` — 文件名是占位符
- `provider_353_pending` — 光鸭服务端判文件违规，到重试上限后永久拦截

**汇报口径**：先给「41/52 成功，11 条里 X 条机制性拦截、Y 条真失败」，再说 PARTIAL 是语义映射。只报「媒体 PARTIAL」等于把语义当故障，会被追问。

**精确判定源（2026-11 定位到行）**：`scheduled_sync_and_clean.py` 收尾处

```python
if stats.get('retry_after'):                 return finish('DEFERRED_QUOTA')
if stats['failed'] or stats.get('cleanup_error'):
                                             return finish('PARTIAL' if pushed_count else 'FAILED')
if stats.get('batch_limited'):               ...
if total_pending and not pushed_count:       return finish('BLOCKED')
return finish('SUCCESS' if total_pending else 'NO_WORK')
```

即 **PARTIAL 只由 `failed` 和 `cleanup_error` 触发**，`blocked` / `permanent_rejected` **完全不参与**
状态判定（实测某轮 `blocked=10` 仍是 SUCCESS）。所以：

- 一天里哪怕只有 **1 条** `failed`，整轮就报 PARTIAL；
- 这条 `failed` 常常是**瞬时网络抖动**（实测：光鸭 API 的
  `<urlopen error _ssl.c:999: The handshake operation timed out>`，单条，其余 59 条全部推送成功）；
- `media-pipeline` 每天只跑一次（`0 14 * * *`），所以这条瞬时失败要等**次日 14:00** 才重试，
  PARTIAL 会挂满一整天。

**判读动作**：先去 `cron.log` 捞当轮 `MEDIA_SYNC_RESULT` 的 `failed` 计数，再
`grep "下发失败" cron.log` 看那一条的异常类型。`handshake timed out` / `URLError` / `TimeoutError`
这类 = 抖动，不是故障；`Magnet intake rejected: xxx` = 机制拦截。**别把「PARTIAL」直接翻译成「媒体链路坏了」**。

### 12.1 采集缺口里的「journal 保留不足 24 小时」：先验测量命令，再决定信不信

日报的「采集缺口」段落常年挂着这条，两种误判方向都很贵：当模板废话忽略，或者拿它去反驳监控报告。

**2026-11 实测纠正**：这条缺口在 `vps-la` 和 `diaomao` 上**长期是假警报**，根因是采集脚本的
测量命令本身写错了，不是主机真的只留 24 小时。修掉后两台机的缺口同时消失，而实际保留是
**14 天 / 39 天**。

```python
# digest.py 旧写法（错）
journalctl -q --no-pager -o json --since @0 -n 1        # 想取最早一条
oldest = json.loads(out)['__REALTIME_TIMESTAMP']/1e6
if oldest > start: gaps.append('journal保留不足24小时...')
```

**`-n 1 --since @0` 的语义随 journalctl 版本变**：同一台 naye 上返回**最早**一条，
vps-la 上返回**最新**一条。后者让 `oldest > start` 永远成立 → 天天误报。这个惯用法不可移植。

正确判据：不看「最早一条是几号」，直接问「窗口起点之前还有没有记录」。

```python
journalctl -q --no-pager -o json --since @0 --until @<窗口起点> -n 1
if rc:                      gaps.append('journal最早留存时间未核实')
elif not out.strip():       gaps.append('journal保留不足24小时，统计仅含留存部分')
```

有输出 = 起点之前有记录 = 覆盖完整；空 = 真的不够。与 journalctl 版本无关。

**判断缺口真假的顺序**：①先独立核实实际最早记录（`journalctl --no-pager -o short-iso | head -1`，
或用上面的 `--until` 探针）→ ②与脚本输出对照 → ③不一致就是脚本 bug，改脚本而不是改主机。
**不要因为「这条缺口天天出现」就默认它成立**，也不要反过来凭一次采样宣布「保留期是 N 天」。

**验证与判读**：

```bash
journalctl --disk-usage
journalctl --no-pager -o short-iso | head -1              # 真实最早一条
cat /etc/systemd/journald.conf.d/*.conf | grep -E 'SystemMaxUse|MaxRetentionSec'
```

**这是滚动窗口，不是配置承诺。** 配置里 `MaxRetentionSec=14day` 只是上限，真正决定能查多久的是 `SystemMaxUse` 除以日增量。

本会话踩实的翻车过程（同一台机，相隔一天，结论相反）：

| 时间 | 最早记录 | 占用 | 当时结论 |
|---|---|---|---|
| 第 1 天 | `2026-10-16` | 427.8M | 「保留 13 天，日报这条是错的」 |
| 第 2 天 | `2026-10-31 23:05` | 438.7M | 「确实不足 24 小时，我昨天判断错了」 |
| 第 3 天（降噪+扩容后） | `2026-10-19` | 436.9M | 「14 天，且脚本 bug 已修」 |

容量几乎没变，写入量把窗口推平了。**据此反驳过监控报告，第二天被数据推翻。**

正确说法是「**截至 <采样时刻>，最早记录 X，占用 Y/上限 Z，日增约 W**」，不是「保留期是 N 天」。
判断够不够用要算 `日增量 × 需要回看天数` 和上限比，**不要看当下最早那条落在哪天**——今天够用明天就轮转掉，是这类问题的标准形态。

**写日志的人是谁**（决定该治哪一处）：

```bash
journalctl --since "-24h" --no-pager -o json | python3 -c "
import json,sys,collections
c=collections.Counter()
for line in sys.stdin:
    try: d=json.loads(line)
    except Exception: continue
    c[d.get('SYSLOG_IDENTIFIER') or d.get('UNIT') or '?']+=1
for k,v in c.most_common(8): print(v,k)"
```

实测大头常是 `sshd` / `systemd-logind` / `sudo`（每次 SSH 会话都记），不是业务进程。所以**别一上来就改业务代码的日志级别**，先看分布。

业务侧典型噪音是 Telethon 每轮建连断连：一天约 2880 行纯 INFO。降级方式：

```python
logging.getLogger('telethon').setLevel(logging.WARNING)   # WARNING 及以上仍保留
```

配合把 `SystemMaxUse` 按 `df` 余量调高（本机 512M → 1536M，盘上还有 7G）。

**验证容量改动，看被改的守护进程自己打印的生效值，不看配置文件**：

```bash
journalctl -u systemd-journald --since "-10min" | grep -i max
# System Journal (...) is 438.7M, max 1.5G, 1.0G free.
```

`systemctl show systemd-journald -p SystemMaxUse` 可能返回空，别把它当「没生效」的证据。

## 十一、汇报口径

用户问「有没有问题」时，不要只报数字，要给**因果链 + 风险量级**：

- 空转层：哪一行硬编码、哪个函数从未被调度
- 误伤层：旧规则会误删多少个正片（给绝对数和占比）
- 已修层：分拣模型、回滚手段、测试条数
- 待验证层：哪些还在跑、预计多久、跑完通知

汇报纪律：

- 结论先行，给**对账数字**：各类之和必须等于总数（如 `干净 72,315 + 剥名 3,486 + 复核 2,129 = 77,930`），对不上就是分拣有漏
- 明确区分「已验证事实」与「未验证/待观察」。单专区单轮跑通 ≠ 端到端跑通
- **不要因为几个单点验证通过就说「以后没问题了」**。要主动列出：哪些专区没跑过、哪条调度没经过一次真实触发、哪个规则改动还没生效到生产
- 长任务给进度数字和预计时间，不要只回「还在跑」

实测数字、正则、样本路径见 `references/cleanup-rule-regex.md`。

## 支持文件

- `scripts/audit_promo_scope.py` — 只读全量审计探针，输出疑似广告/水印前缀清单 JSON，供开删前测算误判率
- `scripts/verify_rename_journal.py` — 按剥名回滚日志读回云盘验收：逐层下钻目录，比对 `new_name` 的 fileId 与 `old_name` 是否残留，输出 N/N 通过率。灰度第 5 步直接用它，别手写
- `references/guangya-pipeline.md` — 光鸭（lemon-media-spider）具体链路：路径、接口、token 机制、实测数字；**另含 `lemon-vps-sync` 入库链路的 guard 拒收 + 有界重试完整修法**（水印剥离正则、退避闸门、`retry_count` 为何恒 0、孤儿缓存误判）
- `references/cleanup-rule-regex.md` — 判定正则、实测分布、样本路径
