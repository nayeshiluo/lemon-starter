#!/usr/bin/env python3
"""lemon-vps-sync 体检：错误分布 / 重试次数 / db 状态 / temp 缓存 / 服务健康。

在 vps-la 上用 worker 自己的 venv 跑（本机没有 sqlite3 命令）：

    ssh vps-la 'cd /opt/lemon-vps-sync-worker && ./venv/bin/python /tmp/collect_sync_health.py'

只读，不改任何状态。
"""
import os
import re
import subprocess
import sys
import sqlite3
from collections import Counter

BASE = "/opt/lemon-vps-sync-worker"
DB = "/var/lib/lemon-vps-sync/vps_sync.db"
TEMP = "/var/lib/lemon-vps-sync/temp_media_cache"
UNIT = "lemon-vps-sync"
SINCE = os.environ.get("SINCE", "-24h")


def sh(cmd):
    try:
        return subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=120).stdout
    except Exception as e:
        return ""


def section(title):
    print("\n" + "=" * 60)
    print(title)
    print("=" * 60)


section("1. 服务健康")
print("active:", sh(f"systemctl is-active {UNIT}").strip())
print("NRestarts:", sh(f"systemctl show {UNIT} -p NRestarts --value").strip())
print("POLL/内存:", sh(f"systemctl show {UNIT} -p MemoryCurrent --value").strip())

section("2. 错误类型分布（去掉 msg id 后聚合）")
log = sh(f'journalctl -u {UNIT} --since "{SINCE}" --no-pager')
fails = re.findall(r"光鸭失败 msg=\d+: (.*)", log)
counter = Counter()
for f in fails:
    key = re.sub(r"TaskID: \d+", "TaskID:<id>", f)[:80]
    counter[key] += 1
if not counter:
    print("(窗口内无光鸭失败)")
for msg, n in counter.most_common(12):
    print(f"{n:5d}  {msg}")

section(f"3. 单条被重试次数（窗口 {SINCE}，含修复前历史）")
print("注意：>3 次不等于闸门失效 —— 修复前的重试会留在窗口里。")
print("      缩小窗口再看：SINCE=-1h ./venv/bin/python collect_sync_health.py")
per_msg = Counter(re.findall(r"光鸭失败 msg=(\d+)", log))
if not per_msg:
    print("(无)")
for mid, n in per_msg.most_common(12):
    flag = "  <== 疑似死循环" if n > 3 else ""
    print(f"msg={mid:>8}  重试 {n} 次{flag}")

section("4. db 状态分布")
if not os.path.exists(DB):
    print("DB 不存在:", DB)
else:
    conn = sqlite3.connect(DB, timeout=30)
    for r in conn.execute(
        "select guangya_status, count(*), max(retry_count) from vps_sync_records group by 1 order by 2 desc"
    ):
        print(f"{str(r[0]):10}  count={r[1]:<6} max_retry={r[2]}")

    print("\n-- 未成功且 retry 最高（最可能卡住）--")
    for r in conn.execute(
        "select msg_id, guangya_status, retry_count, substr(coalesce(last_error,''),1,60), updated_at "
        "from vps_sync_records where guangya_status != 'success' "
        "order by retry_count desc, updated_at desc limit 12"
    ):
        print(r)

    print("\n-- 最近 5 条成功 --")
    for r in conn.execute(
        "select msg_id, guangya_fid, substr(filename,1,50), updated_at "
        "from vps_sync_records where guangya_status='success' "
        "order by updated_at desc limit 5"
    ):
        print(r)
    conn.close()

section("5. temp 缓存（隔 20s 采样判断是孤儿还是在下载）")
def snap():
    out = {}
    if not os.path.isdir(TEMP):
        return out
    for name in os.listdir(TEMP):
        if not name.startswith(".msg_"):
            continue
        p = os.path.join(TEMP, name)
        try:
            out[name] = os.path.getsize(p)
        except OSError:
            pass
    return out

a = snap()
import time

time.sleep(20)
b = snap()
if not a and not b:
    print("(空)")
for name in sorted(set(a) | set(b)):
    s1, s2 = a.get(name, 0), b.get(name, 0)
    if s2 > s1:
        verdict = "下载中 %.1f MB/s" % ((s2 - s1) / 20 / 1024 / 1024)
    elif s2 == s1:
        verdict = "静止（疑似孤儿，删前确认无进程在用）"
    else:
        verdict = "缩小中"
    print(f"{name}  {s2/1024/1024:.1f} MB  {verdict}")

section("6. 磁盘")
print(sh("df -h / | tail -1").strip())

section("判读提示")
print("- 第 3 节 >3 次：先用 SINCE=-1h 缩小窗口，排除修复前历史再判断")
print("- last_error 含 promotion_marker: 前缀 = 本地 PROMO_MARKERS 拦截，不是光鸭拒绝")
print("- 查记录一律用 msg_id，不要用表主键 id（两者不同）")
print("- db 的 filename 列 = 实际上传用的名字；若仍是水印名，说明该记录在 filename 同步补丁之前成功")
