---
name: lemon-vps-sync-ops
description: 光鸭转存 worker 排障：水印拦截、无限重试、媒体 PARTIAL。
version: 1.0.0
author: 柠檬
license: MIT
metadata:
  hermes:
    tags: [guangya, 光鸭, media-sync, telethon, retry, watermark, vps-la]
    related_skills: [emos-upload-pipeline, media-library-cleanup-ops, telegram-media-harvester]
---

# 光鸭转存 Worker 运维（lemon-vps-sync）

## When to Use / 触发条件

- 日报出现「媒体=PARTIAL」或 `vps-la/媒体转存及EMOS` 错误条数偏高
- 光鸭云盘里缺片，但日志看着一直在跑
- `光鸭失败 msg=NNNN` 反复出现同一条
- 要给 worker 加清洗规则、改重试策略、重启它

**不是** `emos-upload-pipeline`：那条是 AWS Bot → vps-la → EMOS 赚胡萝卜；这条是 TG 私有频道 → vps-la → 光鸭云盘（影视库）。

## 一、链路与位置

```
TG 私有频道 <YOUR_TELEGRAM_GROUP_ID> (禁转发)
        ↓ Telethon 拉取
vps-la /opt/lemon-vps-sync-worker/sync_worker.py  (systemd: lemon-vps-sync)
        ↓ 下载到 /var/lib/lemon-vps-sync/temp_media_cache/
        ↓ upload_file_to_guangya()
光鸭云盘 /柠檬影视库/<分类目录>
```

- GDrive 轨**已永久关闭**（2026-09-09 大号被封），日志里 `[⏭️] GDrive 轨已永久关闭` 是正常跳过，不是错误
- 状态库 `/var/lib/lemon-vps-sync/vps_sync.db`（表 `vps_sync_records`）
- 运行用户 `lemon-media`，改文件要 root 或同组
- 源码有大量 `.bak-*`，说明改得频繁 —— 每次改先 `cp -a` 新备份，别覆盖历史

## 二、最重要的两个坑

### 坑 1：光鸭"拒收"其实是本地拦截，不是平台拒绝

`guangya_uploader.py` 第 23 行先跑本地闸门：

```python
allowed, reason = validate_video_file(local_path, filename=filename)
if not allowed:
    raise ValueError("光鸭直传只接受经过视频流验证的文件: " + reason)
```

`ingest_guard.py` 的 `PROMO_MARKERS` 里有 `"在线观看"` 这类**高频出现在正常片名里**的词。短剧源站文件名长这样：

```
AI觉醒之拯救潘金莲_短剧视频在线观看_vert;_黄果短剧_md5_016091fd__msg3575.mp4
母子同淫 第8集在线观看 - 野果短剧_md5_ec91a781__msg3589.mp4
```

含 `在线观看` → 命中 marker → 抛 `promotion_marker:在线观看` → 上传永远不可能成功。

**报错文案「光鸭直传只接受经过视频流验证的文件」极具误导性**，看着像 ffprobe 校验失败或平台侧限制，实际是本地字符串匹配。

判据：`last_error` 里出现 `promotion_marker:` 前缀，就是这条。

**修法（已落地）**：`sync_worker.py` 新增 `strip_site_watermark()`，在 `safe_name()` 之后、进 guard 之前剥水印：

```python
SITE_WATERMARK_PATTERNS = (
    r"__msg\d+",
    r"_md5_[0-9a-fA-F]{6,}",
    r"_vert;[-_\s]*[^\s_;]*短剧",
    r"[-_ ]*短剧视频在线观看",
    r"[-_ ]*视频在线观看",
    r"[-_ ]*在线观看",
    r"[-_ ]*[-–—]\s*[^\s_]{1,12}短剧(?=$|[-_. ])",
    r"[-_ ]*\[[^\]]{1,12}短剧\]",
)

def strip_site_watermark(name):
    """剥除片名里的站点/推广水印，保留正片名；剥空则回退原值。"""
    stem, ext = os.path.splitext(name or '')
    cleaned = stem
    for pattern in SITE_WATERMARK_PATTERNS:
        cleaned = re.sub(pattern, '', cleaned, flags=re.I)
    cleaned = re.sub(r"[-_\s]{2,}", "_", cleaned)
    cleaned = re.sub(r"^[-_\s]+|[-_\s]+$", "", cleaned)
    if len(cleaned) < 2:
        return name
    return cleaned + ext
```

调用点：`base_filename = strip_site_watermark(safe_name(title_source, media_type))`

**关键原则：剥名优先于丢弃。** 这些是正片，水印在文件名上不在画面上，剥掉就入库。只有剥完仍命中 marker 才该判广告。`len(cleaned) < 2` 回退原值，防止把名字剥成空。

改完必须回归：正常文件名不能被误伤。

| 输入 | 期望输出 |
|---|---|
| `FC2-PPV-4658002_seg2.mp4` | 原样 |
| `某部正常电影.2026.1080p.mkv` | 原样 |

### 坑 2：`failed` 无限重试，且 `retry_count` 永远是 0

`run_pass()` 筛待处理用的是：

```python
if not delivery_complete(row):   # delivery_complete 只判 success
    messages.append(msg)
```

→ `failed` 也算"未完成" → 每轮（`POLL_SECONDS=60`）重新下载 + 重新上传，永不停止。实测同一文件 12 小时重试 9 次，白烧 2.9GB 流量、刷 54 条错误日志。

而 `upsert_record` 里的 `retry_count=vps_sync_records.retry_count+1` 只在 `ON CONFLICT` 时生效，实际代码只在 `not row` 时才 insert —— 所以**永远不会走冲突分支，retry_count 恒 0**，既没有退避也没有上限。

**修法（已落地）**：加闸门 `should_retry()`：

```python
MAX_RETRY = 3
RETRY_BACKOFF_MINUTES = {1: 10, 2: 60}

def should_retry(row):
    if delivery_complete(row):
        return False
    if not row or len(row) < 7:
        return True
    if row[2] != 'failed':
        return True
    try:
        retry_count = int(row[5] or 0)
    except (TypeError, ValueError):
        retry_count = 0
    if retry_count >= MAX_RETRY:
        return False
    wait_minutes = RETRY_BACKOFF_MINUTES.get(retry_count, 0)
    if not wait_minutes:
        return True
    try:
        last = datetime.strptime(str(row[6]), '%Y-%m-%d %H:%M:%S').replace(tzinfo=timezone.utc)
    except Exception:
        return True
    return (datetime.now(timezone.utc) - last).total_seconds() >= wait_minutes * 60
```

配套三处：
1. `get_record()` 的 SELECT 从 5 列扩到 7 列（补 `retry_count, updated_at`），否则闸门取不到数据
2. `update_target()` 里 `status == 'failed'` 分支单独 `retry_count=COALESCE(retry_count,0)+1`
3. `run_pass()` 两处 `if not delivery_complete(row)` 全换成 `if should_retry(row)`（主频道 + FC2 频道各一处）

**闸门必须单测**，8 个状态一个不能错（success / pending / failed 各 retry 档位 × 退避前后）。用构造 tuple 测，别只跑线上数据。

## 三、排查命令

```bash
# 服务状态
ssh vps-la 'systemctl is-active lemon-vps-sync; systemctl show lemon-vps-sync -p NRestarts --value'

# 错误归类（先看分布，别看单条）
ssh vps-la 'journalctl -u lemon-vps-sync --since "-24h" --no-pager \
  | grep -oE "光鸭失败 msg=[0-9]+: [^\"]*" | sed -E "s/msg=[0-9]+/msg=ID/" | sort | uniq -c | sort -rn | head'

# 每条被重试了几次（判断是否死循环）
ssh vps-la 'journalctl -u lemon-vps-sync --no-pager \
  | grep -oE "光鸭失败 msg=[0-9]+" | sort | uniq -c | sort -rn | head'

# 库状态（注意用 venv python，本机没有 sqlite3 命令）
ssh vps-la 'cd /opt/lemon-vps-sync-worker && ./venv/bin/python -c "
import sqlite3; c=sqlite3.connect(\"vps_sync.db\")
for r in c.execute(\"select guangya_status,count(*),max(retry_count) from vps_sync_records group by 1\"): print(r)"'
```

### 3.1 db 主键 `id` ≠ Telegram `msg_id`

最容易卡住人的一点。日志里打的 `db_id=3575` **其实是 msg.id**，不是表主键：

```python
db_msg_id = (2224956774000000 + msg.id) if channel_type == 'fc2' else msg.id
logger.info('发现待处理视频 msg=%s db_id=%s ...', msg.id, db_msg_id, ...)
```

所以 `where id in (3575,3589)` 查不到任何东西（真实主键是 2120/2129）。**一律按 `msg_id` 查**：

```sql
select id,msg_id,guangya_status,retry_count,guangya_fid,last_error
from vps_sync_records where msg_id in (3575,3589);
```

FC2 频道的 `msg_id` 是 `2224956774000000 + msg.id`，跟主频道不撞。

### 3.2 temp 缓存：孤儿 vs 正在下载

`/var/lib/lemon-vps-sync/temp_media_cache/.msg_<db_msg_id>.download.mp4`

**别看到大文件就删。** 判断方法：隔 20 秒看两次 `stat -c %s`：

```bash
ssh vps-la 'ls -la /var/lib/lemon-vps-sync/temp_media_cache/.msg_*; sleep 20; ls -la /var/lib/lemon-vps-sync/temp_media_cache/.msg_*'
```

- 大小在涨 → 正在下载，别动（1.48GB 的 FC2 大文件很可能就是当前任务）
- 大小不动且时间戳很旧 → 才是孤儿

`systemctl restart` 会杀掉进程，`finally` 里的清理跑不到，所以 restart 后大概率留孤儿。清之前确认没有同名进程在跑。

## 四、远端改代码的正确姿势

**不要用 `ssh host '... python -c "..." ...'` 内嵌引号写代码。** 外层单引号会把内层单引号剥掉，`row[2] != 'failed'` 变成 `row[2] != failed` —— **语法合法、`py_compile` 通过、运行时才 NameError**。这种炸弹能躲过所有静态检查。

正确做法：本地 `write_file` 写补丁脚本 → `ssh host 'cat > /tmp/patch.py' < /tmp/patch.py` → 远端执行。

补丁脚本里每条替换都做 `assert count == 1`，不匹配就退出，绝不半途写入：

```python
for tag, old, new in edits:
    n = s.count(old)
    if n != 1:
        raise SystemExit("FAIL %s count=%s" % (tag, n))
    s = s.replace(old, new, 1)
open(P, "w", encoding="utf-8").write(s)
```

同理，如果某个替换失败，**整个脚本在 write 之前就退出，文件保持原样** —— 这是故意的，别改成边改边写。

按行号改（`lines[i]` + assert）比整段字符串匹配更稳，中文和转义多的段落用这招。

## 五、验收阶梯

改完不是 `is-active` 就算完：

| 级 | 证据 | 命令 |
|---|---|---|
| 1 | 编译过 | `./venv/bin/python -m py_compile sync_worker.py` |
| 2 | 闸门单测全过 | 构造 tuple 跑 8 个状态用例 |
| 3 | 日志出现干净文件名 | `grep "发现待处理视频"` 看 `file=` 字段水印已剥 |
| 4 | db 状态转 success + 有 fid | `select guangya_status,guangya_fid` |
| 5 | **光鸭目录回读文件名** | 调 `/userres/v1/file/get_file_list` 按 fid 核对 |

第 5 级不能省 —— 上传成功不等于名字对。实测回读确认：

```
1963041354956390442 -> AI觉醒之拯救潘金莲__msg3575.mp4
1963042443290206278 -> 母子同淫 第8集__msg3589.mp4
```

`__msgNNN` 后缀是 worker 自己加的（唯一性），不是水印，保留。

**已经卡死的记录**要手动重置才会被新逻辑重新处理：

```sql
UPDATE vps_sync_records SET guangya_status='pending', retry_count=0,
  last_error=NULL, updated_at=strftime('%Y-%m-%d %H:%M:%S','now')
WHERE msg_id IN (3575,3589);
```

## 六、坑

1. **`光鸭云盘落盘超时 (TaskID: ...)` 是光鸭侧慢，不是网络**。上传 OSS 完成但平台落盘轮询 60s 没拿到 fileId。重试通常能过，别去查本地网络。
2. **`{'status': -2, 'x-oss-request-id': ''}` 是 STS 凭证问题**，走 `refresh_token.py` 刷新，不是文件本身的问题。
3. **`GetFileRequest flood wait` 是正常退避**，INFO 级。日报里那 181 条"限流"大部分是它，不是故障。但它确实会刷屏，压低日志信噪比。
4. **`iter_messages` 遍历全部历史**，所以老记录（如 9-25 的文件引用过期 `The file reference has expired`）会一直被捞。靠 `MAX_RETRY` 自动封存收敛，不用手工清。
5. **下载速度约 0.87~1.0MB/s**（exocf 源），126MB 约 2.5 分钟、194MB 约 4 分钟、1.75GiB 约 30 分钟。别把慢当卡死，看 temp 文件大小是否在涨。
6. **`lemon-vps-sync` 单进程**，restart 前确认没在跑大文件，否则白下几 GB。判断方法：`temp_media_cache` 里有文件且 20 秒采样在涨，就是正在下，等它跑完再重启。
7. **改完 `retry_count` 语义变了**：以前恒 0，现在会增长。如果有别的地方读这个字段做判断，要一起审。
8. **巡检看 24h 窗口会把修复前的重试算进来**，`>3 次` 不等于闸门失效。缩小到 `SINCE=-1h` 再判断，否则会误以为补丁没生效。
9. **db 的 `filename` 列要跟实际上传名一致**。上传用的是局部变量 `filename`，成功时不会自动回写 db —— 已补 `UPDATE ... SET filename=?`。历史上成功的记录若仍是水印名，需手工修一次，否则下次排查看到 db 里的水印名会以为没剥干净。
10. **封存提示不能每轮打**。`iter_messages` 每轮从头遍历整个频道，`elif terminal_failed(row): logger.warning(...)` 会让每条封存记录每轮刷一条 —— 3 条记录 24 小时刷出 662 行，把日报的「业务失败」顶到 554。必须去重：

```python
_SEALED_NOTIFIED = set()   # 模块级

elif terminal_failed(row):
    if msg.id not in _SEALED_NOTIFIED:
        _SEALED_NOTIFIED.add(msg.id)
        logger.warning('终态失败已封存，不再重试 msg=%s retry=%s', msg.id, row[5])
```

重启后应只出现一次。**这是加闸门时最容易带出来的副作用**：闸门挡住了重试，但没挡住遍历时的日志。

11. **`GetHistoryRequest flood wait` 24h 实测 460 次**（Sleeping for 3s）。根因是每轮 `iter_messages(reverse=True)` 全量遍历历史，消息越多越慢越容易触发。它是 INFO 级、Telethon 自动退避，不算故障，但日报的「限流」分类会把它算进去。要真正降下来得改成只拉最近 N 条增量，别只调退避参数。
12. **判断「服务 failed」先看 `Result: exit-code` 和 `status`**。`lemon-music-crawler` 这类 timer 触发的 oneshot 服务，每轮 preflight 失败就退出 21，`systemctl status` 一直显示 failed 但 `累计重启 0` —— 不是崩溃循环，是每轮都失败。看 `journalctl -u <svc> -n 30` 里第一条错误，通常比状态行有用。

## 相关文件

- 源码 `/opt/lemon-vps-sync-worker/sync_worker.py`（约 460 行）
- 闸门 `/opt/lemon-vps-sync-worker/ingest_guard.py` 的 `PROMO_MARKERS`
- 上传 `/opt/lemon-vps-sync-worker/guangya_uploader.py`
- 状态库 `/var/lib/lemon-vps-sync/vps_sync.db`
