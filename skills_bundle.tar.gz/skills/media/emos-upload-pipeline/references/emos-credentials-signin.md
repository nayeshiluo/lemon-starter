# EMOS 登录密钥轮换 + 每日签到

密钥被改（登录密钥 = `Authorization: Bearer <token>`）时，签到和上传都靠同一个 token，必须同步多机。

## token 分布

| 机器 | 文件 | 字段 | 用途 |
|---|---|---|---|
| AWS (lemon-ops-bot) | `/home/ubuntu/lemon-ops-bot/emos_config.json` | `accounts[].token`（naye + momogo 双号） | 每日签到 + identify_video + **上传时注入远端** |
| vps-la (<PRIVATE_IDENTIFIER>) | `/root/emos_uploader.py` | `TOKEN`（现为 `os.environ.get("EMOS_TOKEN","")`） | 上传 `upload_to_emos`（只用 naye 号） |

> **2026-10 起：上传 token 的唯一真源是 AWS 的 `emos_config.json`。**
> `execute_remote_vps_emos_upload()` 读 `accounts[0].token`，以
> `EMOS_TOKEN=<token> EMOS_UPLOAD_WORKERS=<n> python3 /root/emos_uploader.py <path> [name]`
> 的形式注入。远端不再硬编码、**轮换时不用再上 vps-la 改文件**。
> 若哪天又看到远端写死明文 token，说明补丁被回滚，务必改回 env 读取（硬编码那次过期导致整条上传链 401，报错却伪装成"影视库未收录"）。

- token 格式 `<前缀>_<16位>`：naye `6368_*`、momogo `7474_*`。**前缀相同不代表值相同**，只比前缀会误判，要比 sha256 前 8 位。
- user_id 固定：naye `eK981JREMs`、momogo `eO9M6J13Js`。
- AWS 的 `emos_module.py` 用 `os.environ.get("EMOS_TOKEN"/"EMOS_TOKEN_2")` 兜底，但实际生效的是 `emos_config.json` 里 `accounts[]` 的 token（`load_config()` 优先读 json，json 无 `accounts` 才回退 env）。
- vps-la 的 `/home/ubuntu/emos_active_token.txt` 是**另一套** `X-Emby-Token`（`emos_auto_sync.py` 做 Emby 代理元数据同步用，PROXY_ID/PROXY_NAME 也是 naye），与登录密钥无关，别误改。当前该文件为空。

## 验证新密钥（改前先测）

```bash
curl -s -H "Authorization: Bearer <新token>" -H "Accept: application/json" https://emos.club/api/user
# 200 且 username/user_id 对得上即有效
```

## 签到机制与时间边界

- 入口 `emos_module.execute_all_sign_ins(mode)`，按 `accounts[]` 逐个 `PUT /api/user/sign`。
- 定时签到时间 `sign_config.sign_time`（默认 `00:04`，**北京时间 UTC+8**）。系统时钟是 UTC，判"今天"用 `now_bj`（`timezone(timedelta(hours=8))`）。
- 返回语义：`success` 本次签到成功发胡萝卜；`already` 今天已签过（幂等不重复发）；`failed/error` 真失败。

## 重试锁坑（关键）

`main.py` 定时签到触发条件：

```python
current_time_str >= target_time
and sign_cfg.get("last_sign_date") != today_str
and sign_cfg.get('retry_exhausted_date') != today_str
```

失败重试达上限后写 `retry_exhausted_date = today_str`、`last_attempt_status = 'FAILED'`，导致**当天定时签到不再重试**。密钥换新后必须清掉 `retry_exhausted_date`（及 `last_attempt_date` / `last_attempt_status`），否则当天即使密钥已修复也不会自动补签。

## 轮换步骤（实测通过）

1. 备份文件（AWS `emos_config.json`；若远端仍是硬编码版，同时备份 vps-la `/root/emos_uploader.py`）。
2. curl 验证新 token 有效（见上）。
3. AWS：改 `emos_config.json` 两个账号 token；清 retry 锁字段（`retry_exhausted_date` 等）。
4. vps-la：**env 注入版无需任何操作**（token 由 Bot 每次上传时传入）。仅当远端 `grep -n 'TOKEN = "' /root/emos_uploader.py` 还命中明文常量时，才需要改回 `os.environ.get("EMOS_TOKEN", "")`。
5. 验收：bot venv 跑 `emos_module.execute_all_sign_ins()`，确认无 `failed/error`；再跑一次 `identify_video('<剧名> S01E26.mp4')` 确认上传侧识别也通（签到与上传是两条链路，签到通过不代表上传 token 也对）。
6. `systemctl restart lemon-ops.service`，确认 `is-active` + `NRestarts=0`（**restart 前先确认没有在跑的上传**，见 SKILL.md §七.0）。
7. vps-la 上传模块是 import 时才读 token、无长驻进程，无需重启（`lemon-emos-sync` / `lemon-vps-sync` 与登录密钥无关）。
