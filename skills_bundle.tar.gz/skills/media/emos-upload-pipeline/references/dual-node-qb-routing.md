# 双节点 qB 路由：代码骨架与实测数据

来源：2026-10-24 给 `lemon-ops-bot` 加「手动选节点」的实战实现。

## 一、节点登记表

```python
NODES = {
    "la": {
        "api": "http://127.0.0.1:18999/api/v2",   # SSH 隧道 → vps-la:8999
        "origin": "http://127.0.0.1:8999",
        "host": "127.0.0.1:8999",                  # qb HostHeaderValidation 需要
        "cred": Path("/home/ubuntu/.config/lemon-qb-client.json"),
        "save_path": "/home/ubuntu/Downloads",
        "label": "洛杉矶 VPS",
        "remote": False,                            # 文件本机可直读
    },
    "ib": {
        "api": "http://127.0.0.1:18998/api/v2",   # SSH 隧道 → 沙箱:8999
        "origin": "http://127.0.0.1:8999",
        "host": "127.0.0.1:8999",
        "cred": Path("/home/ubuntu/.config/lemon-qb-client-ib.json"),
        "save_path": "/data/downloads",
        "label": "InstaBox 沙箱",
        "remote": True,                             # 需要 rsync 回传
    },
}
DEFAULT_NODE = "la"
```

`remote` 字段是整个流程的分叉点：`True` 表示文件在第三方平台，上传前必须先回传。

## 二、session 缓存必须按节点分 key

原实现是单值缓存，加节点会互相踢掉：

```python
# ❌ 加节点后失效：la 登录会把 ib 的 session 顶掉
_local.cached = (fingerprint, session)

# ✅ 按节点分桶
cache = getattr(_local, "cached", None)
if not isinstance(cache, dict):
    cache = {}
cached = cache.get(node)
...
cache[node] = (fingerprint, session)
_local.cached = cache
```

`SafeSession.__init__(node)` 里把 `self._qb_base = conf["api"]` 存下来，`request()` 用
`url.startswith(self._qb_base + "/")` 做范围校验，`_version()` / `_login()` 都用
`session._qb_base` 而不是模块级常量——否则第二个节点必然被拒。

## 三、版本自适应端点

```python
def _major(node):
    try:
        m = re.match(r"v?(\d+)", get_qb_version(node))
        return int(m.group(1)) if m else 4
    except Exception:
        return 4          # 探测失败按 4.x 处理，保守

def add_paused_param(node, paused):
    key = "stopped" if _major(node) >= 5 else "paused"
    return {key: "true" if paused else "false"}

def resume_path(node):
    return "/torrents/start" if _major(node) >= 5 else "/torrents/resume"

def pause_path(node):
    return "/torrents/stop" if _major(node) >= 5 else "/torrents/pause"
```

实测（沙箱 5.1.0）：

```
/torrents/resume -> 404 'Not Found'
/torrents/pause  -> 404 'Not Found'
/torrents/start  -> 200 ''
/torrents/stop   -> 200 ''
add paused=true  -> state=downloading   （参数被静默忽略）
add stopped=true -> state=stoppedDL     ✅
```

`/torrents/info`、`/files`、`/properties`、`/filePrio`、`/delete`、`/add` 两版通用。

## 四、回传函数（含双保险路径校验）

```python
IB_SANDBOX_ROOT = "/data/downloads"
IB_RELAY_DIR = "/srv/qbupload"

def fetch_from_sandbox(sandbox_path, timeout=7200):
    if not sandbox_path.startswith(IB_SANDBOX_ROOT + "/"):
        raise RuntimeError("sandbox_path_out_of_scope")
    # 关键：前缀检查挡不住 /data/downloads/../etc/x
    if os.path.normpath(sandbox_path) != sandbox_path or ".." in sandbox_path.split("/"):
        raise RuntimeError("sandbox_path_out_of_scope")

    relay_name = f"{int(time.time())}_{os.path.basename(sandbox_path)}"
    rsync_cmd = (
        "rsync -a --partial --inplace "
        '-e "ssh -i $HOME/.ssh/id_qbupload -o BatchMode=yes '
        '-o StrictHostKeyChecking=accept-new -o ConnectTimeout=20" '
        f"{shlex.quote(sandbox_path)} qbupload@{VPS_HOST}:{shlex.quote(relay_name)}"
    )
    cmd = ["ssh", "-o", "BatchMode=yes", "-o", "ConnectTimeout=20",
           "-o", "ServerAliveInterval=30", "instabox-xoel", rsync_cmd]
    proc = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
    if proc.returncode != 0:
        raise RuntimeError(f"sandbox_fetch_failed: {proc.stderr[:300]}")
    return os.path.join(IB_RELAY_DIR, relay_name)
```

`cleanup_relay()` 在上传返回后异步删中继副本（`run_in_executor`，失败静默），避免沙箱反复下载撑爆 vps-la。

## 五、rrsync 服务端配置

```bash
# 专用用户，无 shell
useradd -r -m -d /home/qbupload -s /bin/bash qbupload
install -d -m 750 -o qbupload -g qbupload /srv/qbupload

# 公钥前置强制命令，只允许写 /srv/qbupload
echo 'command="/usr/bin/rrsync -wo /srv/qbupload",restrict ssh-ed25519 AAAA... instabox-qbupload@lemon' \
  > /etc/ssh/keys/qbupload
chmod 644 /etc/ssh/keys/qbupload

# /etc/ssh/sshd_config.d/99-qbupload.conf
Match User qbupload
    AuthorizedKeysFile /etc/ssh/keys/qbupload
    AllowTcpForwarding no
    AllowAgentForwarding no
    PermitTunnel no
    X11Forwarding no
    PermitTTY no
    PasswordAuthentication no
```

注意：`StrictModes` 等全局指令**不能**放进 `Match` 块，会 `sshd -t` 报
`Directive 'StrictModes' is not allowed within a Match block`。
另外 Debian/Ubuntu 的单元名是 `ssh` 不是 `sshd.service`，reload 用 `systemctl reload ssh`。

越界实测：

```
rsync probe.bin qbupload@HOST:probe.bin      → 成功，800 KB/s（2MB 文件）
rsync probe.bin qbupload@HOST:../../etc/evil.bin
  → /usr/bin/rrsync error: do not use .. in arg (anchor the path at the root of your restricted dir)
  → rsync error: ... (code 12)
/etc/evil.bin 未出现 ✅
```

## 六、实测性能基线（2026-10-24）

| 项 | 数据 |
|---|---|
| 沙箱 BT 下载 | 756MB Debian ISO **40 秒**到 97.2%，峰值 **33.6 MB/s** |
| 沙箱 BT 下载 | 1.88GB 剧集 **44 秒**完成（43 MB/s） |
| 沙箱 → vps-la 回传 | 20MB / 5.9s ≈ **3.4 MB/s**（小文件） |
| 沙箱 → vps-la 回传 | 477MB / 106s ≈ **4.5 MB/s** |
| 端到端（下载→回传→上传 477MB） | **100 秒** |

结论：**下载不是瓶颈，回传才是**。沙箱适合单集/短剧，大合集仍应走 LA。

## 七、`/videos` 双节点展示

```python
NODES_ORDER = ("la", "ib")

# fetch_all_videos 内按节点循环，item 增加 node / node_label 字段
items.append({
    "id": f"{node}:{thash}",        # id 加节点前缀，避免两台 hash/orphan 撞车
    "node": node,
    "node_label": conf["label"],
    ...
})

# orphan id 也要带节点前缀
"id": f"{node}:orph_{orphan_idx}"
```

- 按钮前缀 `🇺🇸` / `📦`，用户明确要求"一眼看出在哪台机器"
- 详情页加一行 `🖥 所在节点`
- 删除时按 item 的 node 选 session 和 rm 目标，路径白名单各管各的
- 孤儿探测排除 `temp` / `.cache` / `@eaDir`（qb 临时目录会被误判）

回调解析用 `data.split(":", 2)[-1]` 可以正确保留 `ib:<hash>` 这种带冒号的 id。
