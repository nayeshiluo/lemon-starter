# 上传失败三段归因表 + 留证补丁

用户报「在运维 Bot 上传视频失败」时，先按**卡在哪一段**分流，不要一上来读全量代码。

## 一、三段归因表

| 现象 | 卡在哪 | 先查什么 |
|---|---|---|
| 点了流程按钮立刻弹 `❌ 无法获取种子哈希` | 种子解析段 | 是否依赖外部 CLI 算 infohash；qB 里有无该任务残留 |
| 弹 `❌ 种子内未找到大于 10MB 的有效视频文件` | 种子解析段（竞态） | qB `torrents/files` 是否返回空；任务是否已被删 |
| 下载进度条在跑但 `progress` 不动 | 下载段 | 节点连通、tracker、磁盘 |
| 下载 100% 后失败，qB 任务仍在做种、文件留在 vps-la | **上传段** | vps-la SSH 端口/密钥；EMOS 库里有无该规格 |
| 弹 `FAIL! EMOS 影视库未能自动识别该资源` + 日志有「站内未收录，尝试从 TMDB 同步建档」 | **上传段（凭据）** | 远端 token 是否过期（401），**不是平台没收录** |
| 失败后 journal 里**一个字都没有** | 留证缺失 | 该路径只 `edit_text` 不写日志 |
| 选「第二台/沙箱」节点后立刻失败，日志 `QbAuthError: qb_connection_failed` | **节点连通段**（不是下载/上传段） | 本机隧道端口在不在：`ss -tlnp \| grep 18998`。**别先去查远端机器** |
| 下载已经 100% 却在轮询结束时崩溃，日志 `QbAuthError: qb_connection_failed` | **轮询抖动段**（无重试） | 隧道/网络瞬时超时 4s 导致 `qbs()` 验版本失败；`qbs()` 须加 4 次重试退避 |

**关键判据**：`qB 任务还在 + 本地文件还在 + EMOS 里没有对应规格` = 上传段失败（异常走 except，不清文件不清任务）。若任务被删了，多半是解析段的"无有效视频"分支。

## 二、实测案例（2026-10-27，同一集连续 4 次失败）

两次不同根因，先后暴露：

1. **15:59 两次** —— `Error getting torrent hash: [Errno 2] No such file or directory: 'transmission-show'`
   - 外部 CLI 缺失 → 回退到按文件名模糊匹配 qB
   - 种子文件名 `HDArea_好一个乖乖女_...` vs qB 任务名 `好一个乖乖女.What.a.Good.Girl...`
   - 互不包含 → 10×2s 轮询全落空 → `❌ 无法获取种子哈希`
   - 修法：纯 Python bencode + SHA1（见 SKILL.md 坑 9）

2. **16:16 两次** —— journal 完全静默，但 vps-la 上文件已完整落盘（<YOUR_USER_IDENTIFIER> 字节，与种子一致）
   - 手动跑一次上传立刻暴露：`ssh: connect to host <PRIVATE_IDENTIFIER> port 22: Connection refused`
   - `execute_remote_vps_emos_upload()` 手写 `root@IP` 无 `-p`，而 SSH 已迁 2222
   - `run_remote_speedtest()` 同一处病
   - 修法：统一走 ssh config 别名 `vps-la`

**教训**：第 1 个坑修完就以为"好了"，第 2 个坑藏在更后面。**分段验证**——每修一段就单独跑该段的最小可执行单元（`get_exact_torrent_hash(path)` / `execute_remote_vps_emos_upload(path, name)`），别整条链路一起跑。

3. **16:30 再试** —— SSH 已通、文件在、下载完整，但上传器报：

   ```
   [*] EMOS 站内未收录，尝试从 TMDB 同步建档: tmdb_id=338103, type=tv
   FAIL! EMOS 影视库未能自动识别该资源: 好一个乖乖女 S01E26.mp4
   ```

   - 表面像"平台没收录"，实际 vps-la `/root/emos_uploader.py` 里 `TOKEN = "6368_..."` 是**过期旧值**
   - 判据：远端 token 的 `sha256[:8]`（bfb83905）≠ AWS `emos_config.json` 里 naye token 的（e4d22812）；前缀都是 `6368_`，**只比前缀会漏判**
   - 用远端 token 打 `/api/user` → 401，而 AWS 用新 token 打 → 200，锁定凭据问题
   - 修法：远端改 `os.environ.get("EMOS_TOKEN","")`，Bot 从 `emos_config.json` 注入（见 SKILL.md §八、坑 13）
   - 修完 `identify_video('好一个乖乖女 S01E26.mp4')` → `{'success':True,'item_type':'ve','item_id':3169615}`，补传 58 秒成功、`_verified_medias=2`

**反例提醒**：这轮 `/api/identify` 一直返回 502 `Guessit 解析服务异常 (HTTP 404)`，是 EMOS 平台侧 guessit 挂了，**没有阻塞上传**（本地 parser + 站内检索兜底照样出片）。别把它当成要修的东西。

4. **16:44 换母疑云（选第二台节点）** —— `[pipeline] 任务失败 ...: QbAuthError: qb_connection_failed`

   用户第一句是「我看机器在线啊」，方向完全是错的。实际：

   | 检查项 | 结果 |
   |---|---|
   | 沙箱机器 uptime / `qbittorrent-nox` / 8999 监听 / 磁盘 18% | **全部正常** |
   | 本机 `127.0.0.1:18998` | **没有监听** ← 真凶 |

   - 这条隧道当初是手工 `ssh -N` 起的，无 systemd、无 cron，进程一挂就永久失联
   - 修法：建 `lemon-qb-tunnel-ib.service`（`Restart=always` / `RestartSec=10` / `ExitOnForwardFailure=yes`），顺手把主节点 18999 也收进 `lemon-qb-tunnel-la.service`——同一个雷只拆一半没意义
   - 验收：`systemctl restart` 后 10 秒内端口回来，两节点 API 都 200

   隧道通了之后**还有两个坑在后面**（同一次任务暴露）：

   - `fetch_from_sandbox` 的 rsync `-e "ssh ..."` 没带 `-p 2222`，沙箱侧 `<PRIVATE_IDENTIFIER>:22 → Connection refused`（2222 通）。端口藏在嵌套字符串里，只改外层 ssh 别名不够
   - 第二次调用撞 rrsync 单实例锁：`Another instance of rrsync is already accessing this directory`。这是上次残留，不是配置错；而第一次其实已传完 <YOUR_USER_IDENTIFIER> 字节，只是 stdout 被吞了 —— **判成功看两端 `stat -c %s` 字节数，不看调用方输出**

**教训（比前三条都重要）**：用户说「机器在线」时，在线的是**远端主机**，缺的可能是一整条**本地隧道**。连接类失败永远先 `ss -tlnp` 看本地端口，再谈远端。三次失败的真正教训是同一条：**每次只修好暴露出来的那一段，下一段还埋着**。

5. **17:19 换母疑云（第二台节点已 100% 下载，轮询崩溃）** —— `[pipeline] 任务失败 ...: QbAuthError: qb_connection_failed`

   用户反馈「刚刚测试还是失败了」。查日志发现崩溃点在：
   ```python
   t_info_list = qbs().get(f"{qapi}/torrents/info?hashes={target_hash}").json()
   ```
   - 查沙箱 qB 状态：**种子其实已经 100% 下载完毕**（3.15 GB，`Phony.2026.S01E03.2160p...mp4`）
   - 真凶：`qbs()` 是 `lambda: get_qb_session(node)`，每次调用触发 `_version(session)`（HTTP 请求，timeout=4s）。在长达数分钟的下载轮询循环里，只要 SSH 隧道发生毫秒级网络抖动或超时，就会直接抛出 `QbAuthError`，旧代码**零重试**，当场判死整个任务！
   - 修法：在 `run_pipeline` 内部给 `qbs()` 增加 4 次带 2s 退避的重试机制：
     ```python
     def qbs(_tries: int = 4):
         _last = None
         for _i in range(_tries):
             try:
                 return get_qb_session(node)
             except Exception as _e:
                 _last = _e
                 if _i < _tries - 1:
                     time.sleep(2)
         raise _last if _last is not None else RuntimeError("qb_connection_failed")
     ```
   - 补跑后半程：沙箱已有 100% 完整文件，无需重新下载。直接执行沙箱回传 → vps-la 上传 → EMOS 挂载入库，3.2GB 顺利入库（词条 3197436，胡萝卜到账）。

## 三、留证补丁（必装）

`run_pipeline` 的 except 里加落盘，否则下次还是查不到：

```python
    except Exception as e:
        ACTIVE_TASKS.pop(task_id, None)
        try:
            import traceback
            os.makedirs("/home/ubuntu/lemon-ops-bot/logs", exist_ok=True)
            with open("/home/ubuntu/lemon-ops-bot/logs/emos_pipeline_errors.log", "a", encoding="utf-8") as lf:
                lf.write(f"\n===== {datetime.now().strftime('%F %T')} | {task_id} | {torrent_name} =====\n")
                lf.write(traceback.format_exc())
            print(f"[pipeline] 任务失败 {task_id}: {type(e).__name__}: {e}", file=sys.stderr, flush=True)
        except Exception:
            pass
```

`torrents/add` 返回值检查：

```python
        with open(torrent_path, "rb") as f:
            add_resp = qbs().post(f"{qapi}/torrents/add", files={"torrents": f},
                                  data=add_paused_param(node, True))
        add_text = (add_resp.text or "").strip()
        if add_resp.status_code != 200 or add_text.startswith("Fails"):
            print(f"[pipeline] qB 拒收种子: HTTP {add_resp.status_code} body={add_text[:200]}",
                  file=sys.stderr, flush=True)
```

`torrents/files` 竞态重试：

```python
        files_resp = []
        for _wait in range(10):
            await asyncio.sleep(1.5)
            try:
                files_resp = qbs().get(f"{qapi}/torrents/files?hash={target_hash}").json() or []
            except Exception as fe:
                print(f"[pipeline] 取文件列表失败(重试{_wait+1}/10): {fe}", file=sys.stderr, flush=True)
                files_resp = []
            if isinstance(files_resp, list) and files_resp:
                break
```

## 四、补传（中断后恢复）

文件还在 vps-la 就**不要重新下载**，直接单跑上传：

```python
from emos_service import execute_remote_vps_emos_upload
execute_remote_vps_emos_upload(
    "/home/ubuntu/Downloads/<目录>/<原文件名>.mp4",
    "好一个乖乖女 S01E26.mp4",   # 标准名由 format_video_name_standard 算，别手拼
)
```

注意：`execute_remote_vps_emos_upload` 在 **naye 上执行**，传的是 **vps-la 的绝对路径**（不是本地路径）。跑之前先 `ssh vps-la 'ls -la <路径>'` 确认文件大小与种子一致。

标准名算法（避免手拼错）：

```python
from emos_service import format_video_name_standard
std_name, is_ep = format_video_name_standard("xxx.S01E26.2160p.WEB-DL.mp4", 0, None)
# → "好一个乖乖女 S01E26.mp4", True
```
