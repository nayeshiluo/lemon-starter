---
name: emos-upload-pipeline
description: EMOS 视频入库流水线：多节点下载选路、回传中继、入库核验与跨机排障。
version: 1.0.0
author: 柠檬
license: MIT
metadata:
  hermes:
    tags: [emos, qbittorrent, upload, pipeline, relay, rrsync, verification]
    related_skills: [instabox-node-ops, pt-site-ops, emby-proxy-ops]
---

# EMOS 视频入库流水线

## When to Use / 触发条件

- 运维 Bot 收到种子后要选「在哪台机器下载」
- EMOS 上传"看起来成功"但不确定到底有没有入库
- 给流水线加/换下载节点，或节点上的任务行为异常
- 跨机器任务卡住，要判断卡在**下载 / 回传 / 上传**哪一段
- 要核验胡萝卜积分、清理各节点落地文件

## 一、三段式架构与流量归属

```
TG 种子 → 运维 Bot 选节点 → 目标节点 qb 下载
                              ↓
                   沙箱→vps-la rsync 中继（受限账户）
                              ↓
              vps-la 跑 emos_uploader.py → EMOS / R2
```

**硬约束：EMOS token 只留在 vps-la，绝不落到第三方平台。** 所以上传永远从 vps-la 出，沙箱只负责下载——这条不能为了"省流量"破例。

| 环节 | 走谁的网络 | 占谁的额度 |
|---|---|---|
| BT 下载 | 目标节点自己的网 | 节点 |
| 沙箱 → vps-la 回传 | vps-la **入站** RX | 不计出站 |
| vps-la → EMOS/R2 上传 | **vps-la 出站** TX | 占 vps-la |
| Bot 控制指令 / qb API | AWS | 可忽略 |

**回答"流量是不是还走洛杉矶"时按这张表拆**：上传那段绕不开（token 在 LA），但 BT 下载+做种双向流量确实挪走了——那是 vps-la 流量里最大的一块。

## 二、多节点 qb 路由

每个节点一套独立的东西，**不要共用 session 或凭据**：

| 节点 | 隧道端口 | 凭据文件 | 落地目录 | qb 版本 |
|---|---|---|---|---|
| 洛杉矶 VPS | 18999 | `lemon-qb-client.json` | `/home/ubuntu/Downloads` | 4.6.3 |
| InstaBox 沙箱 | 18998 | `lemon-qb-client-ib.json` | `/data/downloads` | 5.1.0 |

实现要点：

1. `NODES` 字典集中登记 api/origin/cred/save_path/label/remote，禁止散落硬编码
2. session 缓存在 `threading.local` 的 **dict** 里按节点 key 分开（原实现存单值，加节点会互相踢掉）
3. **版本自适应端点**——4.x 用 `resume`/`paused`，5.x 用 `start`/`stopped`，写错是 404 静默失败。细节见 `instabox-node-ops` 的 qB 5.x 章节
4. 路径白名单**按节点**校验，不能只判 `/home/ubuntu/Downloads`
5. 回调里 `emos:node:<la|ib>:<t_key>` 切换节点，待处理任务加 `node` 字段，默认 `la`

完整代码骨架见 `references/dual-node-qb-routing.md`。

## 三、回传中继（受限推回）

沙箱是第三方平台，不能给它 shell。用**专用用户 + rrsync 强制命令**：

```
# /etc/ssh/keys/qbupload 内容（公钥前置强制命令）
command="/usr/bin/rrsync -wo /srv/qbupload",restrict ssh-ed25519 AAAA... instabox-qbupload@lemon
```

配套 `Match User qbupload` 块关掉转发/PTY/密码，`AuthorizedKeysFile` 指到独立目录（不要放 `~/.ssh`，配合 `nologin` 用户更干净）。

**必须实测越界拦截**，别只信配置：

```bash
rsync probe.bin qbupload@HOST:../../etc/evil.bin
# 期望：/usr/bin/rrsync error: do not use .. in arg
```

代码侧也要做双保险：`startswith(ROOT + "/")` **加上** `os.path.normpath(p) == p`，否则 `/data/downloads/../etc/x` 能过前缀检查（会到 rsync 才失败，属于靠运气）。

**实测速率约 3.4~6.5 MB/s**，是整条链最慢的一段：1GB 要 3~5 分钟。几十 G 的合集不要走沙箱。

## 四、入库核验阶梯（最容易误判的地方）

按可信度从高到低：

| 级 | 证据 | 说明 |
|---|---|---|
| 1 | **胡萝卜计数增量** | 唯一硬证据。传前传后各查一次 `/api/user`，+N 就是真入库 |
| 2 | 上传器退出码契约 | `0 + SUCCESS!` 成功；`3 + DUPLICATE!` 幂等跳过（非故障） |
| 3 | 中继目录 mtime + `auth.log` 会话 | 只能证明"回传发生了"，证明不了入库 |
| ❌ | `/api/video/search` 命中数 | **0 命中 ≠ 上传失败**，平台条目名可能与剧名不一致，或未公开 |

**踩过的坑**：搜「嫁金钗」「金钗」都是 0 命中，据此差点判定上传失败；实际平台返回 `DUPLICATE`（一周内已传过），胡萝卜也确认了。**永远用胡萝卜增量定论。**

顺带：`DUPLICATE` 不奖励胡萝卜，所以"胡萝卜没动"既可能是重复、也可能是别的，要结合退出码看。

## 五、跨机排障：把四条独立时间线对齐

任务卡住时不要只看进程 active，按时间戳拼起来：

| 证据源 | 看什么 |
|---|---|
| qb `/torrents/info` | `added_on` / `completion_on` / `state` / `progress` |
| vps-la `/srv/qbupload` | 文件在不在、`stat -c %y` 的 mtime |
| vps-la `journalctl -u ssh` | `Accepted publickey for qbupload from <沙箱IP>` 的 open/close 配对 |
| AWS `ps -eo etime,cmd` | `emos_uploader.py` 进程存活时长 |

实测对上的一个案例：`added_on 09:29:09` → `completion_on 09:29:53`（44 秒下完 1.88GB）→ qbupload 会话开启 → 中继 mtime 落在传输结束那秒 → uploader 进程 etime 1 分钟 → 中继清空 = 全链路走完。

**判读要点**：
- 中继目录 mtime 就是"文件写完/被清理"的时刻，能反推回传耗时
- `session opened` 没有配对的 `closed` 不一定是卡住，先看进程和文件是否还在
- 沙箱侧 `journalctl --user -u qbittorrent` 会暴露 qb 内部错误（比 API 返回值可靠）

## 六、坑

1. **qB 5.x 端点改名**：`resume`/`pause` → `start`/`stop`，`paused` 参数 → `stopped`。旧名 404 且很多调用方不查状态码 → 表现为"按钮点了没反应"。
2. **`max_seeding_time_enabled=True` + `max_seeding_time=0`**：下载完成瞬间停止做种，`seeding_time` 恒 0、state 恒 `stoppedUP`，极易误判成 resume 失败。从零写 `qBittorrent.conf` 时必须显式设成 `False` / `-1`。
3. **`stalledUP` vs `stoppedUP` 一字之差含义相反**：前者在做种，后者被停。判断是否真做种要看 `seeding_time` 两次采样是否递增。
4. **沙箱 8 小时强制暂停**：做种会断，恢复后要手动 `start`。跨暂停点的大文件任务必然中断，发任务前先算时间。
5. **沙箱磁盘 20G**：单集/短剧可以，超大合集不要放。
6. **中继目录必须上传后清理**，否则沙箱反复下载会撑爆 vps-la。
7. **`/videos` 类面板要标节点**：按钮前缀用 🇺🇸 / 📦 区分，详情页显示「所在节点」，否则两台混在一起分不清（用户明确提过"我看不出来哪个对应哪个"）。
8. **孤儿文件探测要排除 `temp`**：qb 的临时目录会被误判成未纳管文件，诱导用户误删。

## 七、修改生产 Bot 的安全流程

`lemon-ops-bot` 不是 git 仓库，改动必须：

1. 备份到 `/home/ubuntu/ops-backups/<主题>-<时间戳>/`
2. 用 `ast.parse` 做语法检查
3. 改完 `systemctl restart lemon-ops.service`，确认 `is-active` + `NRestarts=0`
4. **端到端真跑一次**（mock `status_msg.edit_text` 直接调 `run_pipeline`），不要只做静态验证
5. 改完立即核对其他调用点是否受默认参数影响（`grep -rn` 全项目）

> 注意：patch 工具写 Python 字符串时会把 `\n` 变成字面 `\\n`，改完要 `grep '\\\\n"'` 复核转义层数。

## 相关文件

- `references/dual-node-qb-routing.md` — 双节点 session/端点/白名单的代码骨架与实测数据
