---
name: emos-upload-pipeline
description: EMOS 视频入库流水线：多节点下载选路、回传中继、入库核验与跨机排障。
version: 1.0.0
author: 柠檬
license: MIT
metadata:
  hermes:
    tags: [emos, qbittorrent, upload, pipeline, relay, rrsync, verification]
    related_skills: [instabox-node-ops, pt-site-ops, emby-proxy-ops]
---

# EMOS 视频入库流水线

## When to Use / 触发条件

- 运维 Bot 收到种子后要选「在哪台机器下载」
- EMOS 上传"看起来成功"但不确定到底有没有入库
- 给流水线加/换下载节点，或节点上的任务行为异常
- 跨机器任务卡住，要判断卡在**下载 / 回传 / 上传**哪一段
- 要核验胡萝卜积分、清理各节点落地文件
- EMOS 签到失败 / 登录密钥被改，要同步 token 到多机

## 一、三段式架构与流量归属

```
TG 种子 → 运维 Bot 选节点 → 目标节点 qb 下载
                              ↓
                   沙箱→vps-la rsync 中继（受限账户）
                              ↓
              vps-la 跑 emos_uploader.py → EMOS / R2
```

**硬约束：EMOS token 只留在 vps-la，绝不落到第三方平台。** 所以上传永远从 vps-la 出，沙箱只负责下载——这条不能为了"省流量"破例。

| 环节 | 走谁的网络 | 占谁的额度 |
|---|---|---|
| BT 下载 | 目标节点自己的网 | 节点 |
| 沙箱 → vps-la 回传 | vps-la **入站** RX | 不计出站 |
| vps-la → EMOS/R2 上传 | **vps-la 出站** TX | 占 vps-la |
| Bot 控制指令 / qb API | AWS | 可忽略 |

**回答"流量是不是还走洛杉矶"时按这张表拆**：上传那段绕不开（token 在 LA），但 BT 下载+做种双向流量确实挪走了——那是 vps-la 流量里最大的一块。

## 二、多节点 qb 路由

每个节点一套独立的东西，**不要共用 session 或凭据**：

| 节点 | 隧道端口 | 凭据文件 | 落地目录 | qb 版本 |
|---|---|---|---|---|
| 洛杉矶 VPS | 18999 | `lemon-qb-client.json` | `/home/ubuntu/Downloads` | 4.6.3 |
| InstaBox 沙箱 | 18998 | `lemon-qb-client-ib.json` | `/data/downloads` | 5.1.0 |

实现要点：

1. `NODES` 字典集中登记 api/origin/cred/save_path/label/remote，禁止散落硬编码
2. session 缓存在 `threading.local` 的 **dict** 里按节点 key 分开（原实现存单值，加节点会互相踢掉）
3. **版本自适应端点**——4.x 用 `resume`/`paused`，5.x 用 `start`/`stopped`，写错是 404 静默失败。细节见 `instabox-node-ops` 的 qB 5.x 章节
4. 路径白名单**按节点**校验，不能只判 `/home/ubuntu/Downloads`
5. 回调里 `emos:node:<la|ib>:<t_key>` 切换节点，待处理任务加 `node` 字段，默认 `la`

完整代码骨架见 `references/dual-node-qb-routing.md`。

## 三、回传中继（受限推回）

沙箱是第三方平台，不能给它 shell。用**专用用户 + rrsync 强制命令**：

```
# /etc/ssh/keys/qbupload 内容（公钥前置强制命令）
command="/usr/bin/rrsync -wo /srv/qbupload",restrict ssh-ed25519 AAAA... instabox-qbupload@lemon
```

配套 `Match User qbupload` 块关掉转发/PTY/密码，`AuthorizedKeysFile` 指到独立目录（不要放 `~/.ssh`，配合 `nologin` 用户更干净）。

**必须实测越界拦截**，别只信配置：

```bash
rsync probe.bin qbupload@HOST:../../etc/evil.bin
# 期望：/usr/bin/rrsync error: do not use .. in arg
```

代码侧也要做双保险：`startswith(ROOT + "/")` **加上** `os.path.normpath(p) == p`，否则 `/data/downloads/../etc/x` 能过前缀检查（会到 rsync 才失败，属于靠运气）。

**实测速率约 3.4~6.5 MB/s**，是整条链最慢的一段：1GB 要 3~5 分钟。几十 G 的合集不要走沙箱。

**`fetch_from_sandbox` 的 rsync 必须显式带 `-p 2222`**：vps-la 的 SSH 已迁到 2222，而端口只写在 `-e "ssh ..."` 这个嵌套字符串里——外层 ssh 走别名带端口不代表内层带。实测沙箱侧 `<PRIVATE_IDENTIFIER>:22 → Connection refused`、2222 通，漏了就是整条回传必失败。判断回传是否真成功**看两端 `stat -c %s` 字节数是否一致**，别信调用方的空 stdout。详见 `qbittorrent-remote-ops` 坑 6/7。

## 四、入库核验阶梯（最容易误判的地方）

按可信度从高到低：

| 级 | 证据 | 说明 |
|---|---|---|
| 1 | **胡萝卜计数增量** | 唯一硬证据。传前传后各查一次 `/api/user`，+N 就是真入库 |
| 2 | 上传器退出码契约 | `0 + SUCCESS!` 成功；`3 + DUPLICATE!` 幂等跳过（非故障） |
| 3 | 中继目录 mtime + `auth.log` 会话 | 只能证明"回传发生了"，证明不了入库 |
| ❌ | `/api/video/search` 命中数 | **0 命中 ≠ 上传失败**，平台条目名可能与剧名不一致，或未公开 |

**踩过的坑**：搜「嫁金钗」「金钗」都是 0 命中，据此差点判定上传失败；实际平台返回 `DUPLICATE`（一周内已传过），胡萝卜也确认了。**永远用胡萝卜增量定论。**

顺带：`DUPLICATE` 不奖励胡萝卜，所以"胡萝卜没动"既可能是重复、也可能是别的，要结合退出码看。

### 4.1 精确到「某一集有没有我这个版本」的核验链路

胡萝卜增量是总量证据；要确认**具体某一集是否已有自己的那个规格**（比如 2160p 有没有进去、还是库里只有别人的 1080p），走这条 API 链，全部只读：

```python
# 1) 剧名 → video_id（列表在 items，不是 data/list）
GET /api/video/search?title=<urlquote(剧名)>&page=1&page_size=10
#   → {"items":[{"video_id":208091,"video_type":"tv","tmdb_id":338103,...}]}
#   同名多条目时用 tmdb_id 对齐（2026 版 = 338103）

# 2) video_id → 季集树（注意 episodes 挂在 seasons[0] 下）
GET /api/video/tree?video_id=208091
#   → [{"seasons":[{"episodes":[{"item_type":"ve","item_id":3169615,
#        "episode_title":"第 26 集","episode_number":26,"has_media":true}]}]}]

# 3) 集节点 → 该集所有媒体版本
GET /api/upload/video/base?item_type=ve&item_id=3169615
#   → {"video_medias":[{"media_name":"1080P - h265 - haoio 上传",
#        "media_file_size":<YOUR_USER_IDENTIFIER>,"is_self_upload":false}]}
```

**判读要点**：
- `has_media:true` 只说明"这一集有东西"，**不等于自己传的那个规格进去了** —— 必须看第 3 步的 `media_name` / `media_file_size` / `is_self_upload`
- 1.31GB 的 2160p 原片在库里只看到 62MB 的 1080P，就是**上传没完成**的铁证，比"进程还在不在"可靠
- `/api/video/tree?video_id=<identify 返回的 item_id>` 直接传 identify 的 `item_id` 会返回 `[]` —— identify 返回的是 **`item_type:"ve"` 的集节点 id**，tree 接口要的是**剧集级 `vl` id**。别把两者混用

## 五、跨机排障：把四条独立时间线对齐

任务卡住时不要只看进程 active，按时间戳拼起来：

| 证据源 | 看什么 |
|---|---|
| qb `/torrents/info` | `added_on` / `completion_on` / `state` / `progress` |
| vps-la `/srv/qbupload` | 文件在不在、`stat -c %y` 的 mtime |
| vps-la `journalctl -u ssh` | `Accepted publickey for qbupload from <沙箱IP>` 的 open/close 配对 |
| AWS `ps -eo etime,cmd` | `emos_uploader.py` 进程存活时长 |

实测对上的一个案例：`added_on 09:29:09` → `completion_on 09:29:53`（44 秒下完 1.88GB）→ qbupload 会话开启 → 中继 mtime 落在传输结束那秒 → uploader 进程 etime 1 分钟 → 中继清空 = 全链路走完。

**判读要点**：
- **用户报「失败」但机器看着正常时，先查本地隧道端口，别先查远端**：`ss -tlnp | grep -E "18998|18999"`。次节点隧道曾是手工 `ssh -N` 起的、无 systemd，进程一挂就永久失联，Bot 只报 `QbAuthError: qb_connection_failed`，而远端机器 uptime/qb/磁盘全都正常——「机器在线」证明不了隧道在。现已各自落 `lemon-qb-tunnel-la` / `lemon-qb-tunnel-ib` 两个 systemd unit。
- 中继目录 mtime 就是「文件写完/被清理」的时刻，能反推回传耗时
- `session opened` 没有配对的 `closed` 不一定是卡住，先看进程和文件是否还在
- 沙箱侧 `journalctl --user -u qbittorrent` 会暴露 qb 内部错误（比 API 返回值可靠）

## 六、坑

1. **qB 5.x 端点改名**：`resume`/`pause` → `start`/`stop`，`paused` 参数 → `stopped`。旧名 404 且很多调用方不查状态码 → 表现为"按钮点了没反应"。
2. **`max_seeding_time_enabled=True` + `max_seeding_time=0`**：下载完成瞬间停止做种，`seeding_time` 恒 0、state 恒 `stoppedUP`，极易误判成 resume 失败。从零写 `qBittorrent.conf` 时必须显式设成 `False` / `-1`。
3. **`stalledUP` vs `stoppedUP` 一字之差含义相反**：前者在做种，后者被停。判断是否真做种要看 `seeding_time` 两次采样是否递增。
4. **沙箱 8 小时强制暂停**：做种会断，恢复后要手动 `start`。跨暂停点的大文件任务必然中断，发任务前先算时间。
5. **沙箱磁盘 20G**：单集/短剧可以，超大合集不要放。
6. **中继目录必须上传后清理**，否则沙箱反复下载会撑爆 vps-la。
7. **`/videos` 类面板要标节点**：按钮前缀用 🇺🇸 / 📦 区分，详情页显示「所在节点」，否则两台混在一起分不清（用户明确提过"我看不出来哪个对应哪个"）。
8. **孤儿文件探测要排除 `temp`**：qb 的临时目录会被误判成未纳管文件，诱导用户误删。
9. **种子 Info Hash 解析禁用外部 CLI，用纯 Python Bencode 计算**：`transmission-show` 等外部命令容易因系统未安装直接报 `FileNotFoundError: transmission-show`。若回退到按种子文件名在 qB 列表模糊匹配（`item.get("name") in torrent_name`），会因 PT 站前缀（如 `HDArea_`）与种子内真实单集/文件夹名完全不一致而匹配超时（`❌ 无法获取种子哈希`）。必须用纯 Python 解析 torrent 内 `info` 字典并做 SHA1 计算（见下述实现），零外部依赖且 100% 精确。

```python
import hashlib

def get_exact_torrent_hash(torrent_path: str) -> str:
    \"\"\"纯 Python 解析 bencode 获取 v1 Info Hash，不依赖 transmission-show 等外部 CLI\"\"\"
    try:
        with open(torrent_path, \"rb\") as f:
            data = f.read()
        start = data.find(b\"4:info\")
        if start == -1:
            return None
        start += 6

        def parse_elem(idx: int) -> int:
            if data[idx:idx+1] == b\"i\":
                return data.find(b\"e\", idx) + 1
            elif data[idx:idx+1].isdigit():
                colon = data.find(b\":\", idx)
                l = int(data[idx:colon])
                return colon + 1 + l
            elif data[idx:idx+1] == b\"l\":
                idx += 1
                while data[idx:idx+1] != b\"e\":
                    idx = parse_elem(idx)
                return idx + 1
            elif data[idx:idx+1] == b\"d\":
                idx += 1
                while data[idx:idx+1] != b\"e\":
                    colon = data.find(b\":\", idx)
                    l = int(data[idx:colon])
                    idx = colon + 1 + l
                    idx = parse_elem(idx)
                return idx + 1
            raise ValueError(f\"Invalid bencode at {idx}\")

        end = parse_elem(start)
        return hashlib.sha1(data[start:end]).hexdigest().lower()
    except Exception as e:
        print(f\"[torrent] Info hash parse failed: {e}\", file=sys.stderr)
        return None
```

10. **SSH 端口漂移会让上传整段静默全断**：`execute_remote_vps_emos_upload()` 里手写 `ssh -i <key> ... root@<IP>`，**没带 `-p`**，默认连 22。vps-la 的 SSH 已迁到 **2222**（22 被国内封），于是每次上传都 `ssh: connect to host ... port 22: Connection refused` → `exit 255` → 整条流水线在最后一步炸掉，而下载段完全正常，很容易误判成"种子/命名/EMOS 平台"的问题。**凡是连 vps-la 的代码路径一律走 ssh config 别名 `vps-la`**（别名里已固定 `Port 2222` / `User root` / `IdentityFile`），禁止手写 `user@IP`：

    ```python
    cmd = ["ssh", "-F", "/home/ubuntu/.ssh/config", "-o", "BatchMode=yes",
           "-o", "StrictHostKeyChecking=yes", "-o", "ConnectTimeout=10",
           "-o", "ServerAliveInterval=30", "-o", "ServerAliveCountMax=3",
           "vps-la", exec_cmd]
    ```

    改完记得 `grep -n "root@{VPS_HOST}\|VPS_SSH_KEY"` 扫全项目同类调用点（`run_remote_speedtest` 当时是同一个病）。**端口/密钥一旦改过，任何"以前能用"的硬编码都得重新审。**

11. **失败路径只发 Telegram、不落日志 = 事后无法定位**：`run_pipeline` 的 `except` 原本只 `status_msg.edit_text("❌ 处理失败：...")`，journal 里一个字都没有，用户报"失败了"时只能靠猜。必须同时写 `stderr`（`flush=True`）+ 落盘 `/home/ubuntu/lemon-ops-bot/logs/emos_pipeline_errors.log`（含 `traceback.format_exc()`）。同类静默点：`torrents/add` 的返回值从来不检查，qB 拒收（重复/磁盘/路径）时静默继续，之后只能靠"文件列表为空"这种间接现象反推 —— 要显式判 `status_code != 200 or text.startswith("Fails")` 并打日志。

12. **add 后固定 `sleep(1)` 就取 `torrents/files` 是竞态**：qB 元数据解析不是瞬时的，拿到空列表会被误判成"种子内未找到大于 10MB 的有效视频文件"并**直接删任务退出**。必须重试轮询（10×1.5s），拿到非空列表再判定。

13. **`FAIL! EMOS 影视库未能自动识别该资源` 十次有九次是 token 401，不是平台没收录**。上传器识别失败后会自动走"未收录 → TMDB sync → 再检索"，日志长这样，极具误导性：

    ```
    [*] EMOS 站内未收录，尝试从 TMDB 同步建档: tmdb_id=338103, type=tv
    FAIL! EMOS 影视库未能自动识别该资源: 好一个乖乖女 S01E26.mp4
    ```

    真凶是 vps-la `/root/emos_uploader.py` 里硬编码的旧 token 已过期 → 所有 API 401 → 站内检索、sync 全部失败 → 最终 None。**别信"未收录"这个结论，先验 token。**

    排查顺序（全程只读，不打印明文 token）：
    ```bash
    # 1) 远端脚本里的 token 与 AWS 配置里的 token 是否同一个（比 sha256 前 8 位，不泄漏原文）
    #    AWS:   hashlib.sha256(emos_config["accounts"][0]["token"]).hexdigest()[:8]
    #    vps-la: import emos_uploader; hashlib.sha256(u.TOKEN.encode()).hexdigest()[:8]
    #    不一致 → 就是它

    # 2) 用远端脚本自己的 token 打 /api/user：401 = token 死了，200 = 另找原因
    curl -s -o /dev/null -w '%{http_code}\n' -H "Authorization: Bearer <u.TOKEN>" https://emos.club/api/user

    # 3) 单独验识别链路（远端、注入新 token）
    ssh vps-la "EMOS_TOKEN='<新token>' python3 -c \"import sys;sys.path.insert(0,'/root');import emos_uploader as u;print(u.identify_video('xxx S01E26.mp4'))\""
    #    期望 {'success': True, 'item_type': 've', 'item_id': ...}
    ```

    **注意 `/api/identify` 返回 502 不代表坏了**：body 若是 `{"success":false,"message":"Guessit 解析服务异常 (HTTP 404)"}`，那是 EMOS 平台侧 guessit 挂了，属平台侧。上传器会跳过官方识别、走本地 `smart_media_parser` + 站内检索兜底，**照样能出片**，不要为此去改代码或判定平台不可用。真正要区分的是 **401（凭据）vs 502（平台）**：先打 `/api/user`，200 说明 token 没问题。

14. **下载轮询期间隧道/网络抖动会直接杀死 100% 下载完毕的任务**：
    `run_pipeline` 在等待下载完成的循环中高频调用 `qbs()`，每次调用都会触发 `qb_client.py` 的 `_version(session)`（HTTP 请求，`timeout=4s`）。当节点走远程 SSH 隧道（如沙箱 18998 或跨境 VPS）时，单次偶发网络抖动超时就会抛出 `QbAuthError: qb_connection_failed`。若 `qbs()` 只是简单的 `lambda: get_qb_session(node)` 零重试，整个流水线任务会被当场判死——哪怕此时种子已经在远端 100% 下完！**`qbs()` 必须具备至少 4 次重试与 2 秒退避机制**，避免瞬时网络断连掐死已完成任务。遇到此类中断，先检查远端磁盘；如果文件已经完整落盘，**千万不要让用户重下**，直接用 `fetch_from_sandbox` / `execute_remote_vps_emos_upload` 单跑后半程补传入库。

15. **Telegram 交互中同步调用跨机扫描导致回调超时（Query is too old）**：
    删除视频或管理操作时，若在 callback query 处理函数中同步等待 `fetch_all_videos(force=True)`（实测双节点跨机 SSH `du` 统计需要 13~14 秒），会直接突破 Telegram 的 10 秒回调等待限制，抛出 `BadRequest: Query is too old and response timeout expired`。这会导致用户端看到弹窗失败，界面停留在删除确认页面不动。**交互层必须采用「本地缓存秒级直接剔除 + 立即响应 Telegram 回调与更新界面」，将耗时的跨机全量校准放到后台 daemon 线程异步执行**。

16. **发送种子后卡在「📥 正在接收并解析种子文件...」**：
    在 `handle_emos_document` 收到种子后，原代码直接用裸的 `await status_msg.edit_text(..., parse_mode=ParseMode.MARKDOWN)` 尝试渲染选流程键盘。当种子名称或路径中带有未转义的 Markdown 特殊符号（如 `_`, `*`, `[`, `]` 等）时，Telegram 服务端解析 Markdown 抛错导致编辑失败。由于没有使用带降级保护的 `safe_edit_text`，异常中断会导致消息永久停留在「正在接收并解析种子文件...」而无法挂载按钮。所有动态包含外部文件名的 `edit_text` 必须包裹异常捕获并降级到 `parse_mode=None`。

17. **`qb_connection_failed` 在 4 次重试后仍然失败 = 节点整机不可用，别再当成"网络抖动"**：
    §14 的重试只治瞬时抖动。若 `qbs()` 四轮 8 秒全挂，说明目标节点的 qB 端口**根本没人监听**，此时继续重试、重启 Bot、重启隧道都是空转。典型场景：InstaBox 沙箱运行满 `maxRunMinutes`（480 分钟）被平台强制暂停，隧道 unit 卡在 `activating`、gate 日志刷 `platform=suspended`，任何唤醒在冷却期内都返回 `409 machine_cooldown` —— 冷却实测可达 **2 小时**，只能等。
    **归因三步（全只读，30 秒内出结论）**：
    ```bash
    ss -lntp | grep -E '18998|18999'                 # 1. 本地隧道端口在不在听
    systemctl status lemon-qb-tunnel-ib.service      # 2. activating + "IB_GATE waiting: platform=suspended" 就是平台暂停
    # 3. 读冷却时间（不要假设 10 分钟，实测 2 小时）
    ssh vps-la 'tail -3 /var/log/instabox-lease.log'  # 409 machine_cooldown + retryAfterSeconds
    ```
    **报错必须说人话**：把底层异常翻译成「原因 + 恢复时间 + 替代方案」，否则用户只看到 `❌ 处理失败：qb_connection_failed` 完全无法行动。落地做法是在 `run_pipeline` 里加一个只读预检函数，在 `except` 分支按异常类型换文案：
    ```python
    def _node_down_reason(node: str) -> str:
        """节点 qB 不通时查出可读原因（沙箱休眠/冷却），仅用于报错文案，不阻断流程。"""
        if normalize_node(node) != "ib":
            return ""
        try:
            sys.path.insert(0, "/home/ubuntu/scripts")
            import ib_keepalive
            code, m = ib_keepalive.req("GET", f"/v1/machines/{ib_keepalive.MACHINE_ID}")
            if code != 200 or not isinstance(m, dict) or m.get("state") == "running":
                return ""
            raw = m.get("cooldownUntil")
            if raw:
                until = datetime.fromisoformat(raw.replace("Z", "+00:00")).astimezone(
                    timezone(timedelta(hours=8)))
                return (f"InstaBox 沙箱当前为 {m.get('state')}，平台冷却至 {until:%H:%M}"
                        f"（北京时间），现在下载会失败。请等冷却结束后重发，或改选洛杉矶 VPS 节点。")
            return f"InstaBox 沙箱当前为 {m.get('state')}，暂不可下载。请稍后重发，或改选洛杉矶 VPS 节点。"
        except Exception:
            return ""
    ```
    调用侧（`run_pipeline` 的 `except` 里，按顺序判）：
    ```python
    elif "qb_connection_failed" in str(e):
        reason = _node_down_reason(node)
        await status_msg.edit_text(f"❌ *处理失败*：`{reason or '下载引擎连接失败（节点隧道不通）'}`",
                                   parse_mode=ParseMode.MARKDOWN)
    ```
    要点：① 预检放在**报错路径**而不是流程入口，平台 API 抖动不会挡住正常任务；② 整个函数 `try/except` 兜住并 `return ""`，绝不能让"查原因"本身再抛异常；③ 时间一律换算北京时间，用户要的是"几点能再发"；④ 必须给替代节点，否则用户只能干等。

## 七、修改生产 Bot 的安全流程

`lemon-ops-bot` 不是 git 仓库，改动必须：

0. **restart 前先确认没有在跑的上传** —— `run_pipeline` 是 `asyncio.create_task`，上传子进程是 `ssh → vps-la python3 /root/emos_uploader.py`，全部挂在 Bot 进程树下。此时 `systemctl restart` 会把**正在传输的 1GB+ 上传直接掐死**，而且不报错、不留日志，表现为"文件下好了、qB 还在做种、EMOS 里就是没有"。重启前逐条确认：
   - 本机 `ps aux | grep -E "emos_uploader|ssh -F.*vps-la"` 有没有活的子进程
   - vps-la `ps aux | grep emos_uploader` 有没有远端上传器
   - qB 里有没有 `progress < 1` 或刚 `completion_on` 几分钟内的任务
   有就先等它跑完再重启；已经掐断的，用 `execute_remote_vps_emos_upload(远端绝对路径, 标准名)` 单独补传（文件还在 vps-la 就不用重下）。
1. 备份到 `/home/ubuntu/ops-backups/<主题>-<时间戳>/`
2. 用 `ast.parse` 做语法检查
3. 改完 `systemctl restart lemon-ops.service`，确认 `is-active` + `NRestarts=0`
4. **端到端真跑一次**（mock `status_msg.edit_text` 直接调 `run_pipeline`），不要只做静态验证
5. 改完立即核对其他调用点是否受默认参数影响（`grep -rn` 全项目）

> 注意：patch 工具写 Python 字符串时会把 `\n` 变成字面 `\\n`，改完要 `grep '\\\\n"'` 复核转义层数。

## 八、凭据轮换与每日签到（密钥被改时）

EMOS 登录密钥（`Authorization: Bearer <token>`）换了，签到和上传都会断，必须同步两处：

| 机器 | 文件 | 用途 |
|---|---|---|
| AWS | `/home/ubuntu/lemon-ops-bot/emos_config.json` → `accounts[].token` | 签到（双号 naye/momogo）+ identify + **上传时注入远端** |
| vps-la | **`/root/emos_uploader.py`** 的 `TOKEN` | 上传（只用 naye 号）。已改为 `os.environ.get("EMOS_TOKEN", "")`，由 Bot 注入 |

> ⚠️ 上传真正用的是 vps-la `/root/emos_uploader.py`（SSH 以 root 执行），**不是** vps-la 上的 `emos_module.py`。两处是不同文件，改错地方等于没改。
>
> 2026-10 起远端 token 不再硬编码：`execute_remote_vps_emos_upload()` 从 `emos_config.json` 的 `accounts[0].token` 读出，以 `EMOS_TOKEN=<token> python3 /root/emos_uploader.py ...` 前缀注入。**唯一真源是 AWS 的 `emos_config.json`**，远端不再需要单独轮换。

token 格式 `<前缀>_<16位>`：naye `6368_*`、momogo `7474_*`。改前先 curl 验证新密钥有效：

```bash
curl -s -H "Authorization: Bearer <新token>" https://emos.club/api/user
# 200 且 username/user_id 对得上即有效
```

**重试锁坑**：auto-sign 失败后 `main.py` 会把 `sign_config.retry_exhausted_date` 写成当天，当天定时签到不再重试。改完密钥必须清掉 `retry_exhausted_date`（及 `last_attempt_*`），否则当天不补签。

**验收**：用 bot venv 直接跑 `emos_module.execute_all_sign_ins()`；`already`=今天已签过（非失败）、`success`=补签成功、`failed/error`=真失败。改完 `systemctl restart lemon-ops.service`，确认 `active` + `NRestarts=0`。

细节（多机 token 分布、签到时间边界、retry 逻辑）见 `references/emos-credentials-signin.md`。

## 相关文件

- `references/dual-node-qb-routing.md` — 双节点 session/端点/白名单的代码骨架与实测数据
- `references/emos-credentials-signin.md` — 登录密钥轮换 + 每日签到的多机分布与重试锁
- `references/pipeline-failure-triage.md` — **用户报"上传失败"时的三段归因表**、实测失败案例、留证补丁、中断后补传
