# 视频分享与积分站点自动化接入指南 (Video Reward Sites Automation)

## 1. 架构总览与全自动闭环

对于支持上传视频获取积分/奖励的平台（如 EMOS 等），最佳工程实践是将 **Telegram 运维机器人 + 便宜大流量 VPS 中转 + Google Drive 归档 + 目标站点 API 自动化 + TMDB 权威刮削** 打通成全自动管道，并提供**做种与发布分离的两步式交互**：

```
[Telegram 运维 Bot 接收 .torrent 种子文件]
       │
       ▼
[第一步：选择核心模式]
 ├─ 🚀 【直接上传 EMOS 并删除（即传即删）】：单集下载 ➔ 传 GDrive ➔ 传 EMOS ➔ 挂载校验 ➔ 物理删除每集本地文件，0 占磁盘
 ├─ 🌱 【仅挂机做种（长期保留·不传 EMOS）】：满速下载并在本地硬盘永久做种保号赚魔力值，绝不删除
 └─ 🔄 【做种 + 上传 EMOS（保留做种）】：双重兼顾，既上传赚胡萝卜积分，又在本地永久保留持续做种
       │
       ▼ (若选择上传 EMOS)
[第二步：选择命名策略: 🤖 TMDB 智能自动改名 | ✏️ 手动输入名称 | 📄 保持原名]
       │
       ▼
[精准解析 InfoHash ➔ 提交 RackNerd VPS 的 qBittorrent 极速本地下载]
       │
       ▼
[⚠️ 分布式执行引擎：通过 SSH 触发 VPS 本地 emos_uploader.py 直接直传]
   ┌───┴───────────────────────────────┐
   ▼                                   ▼
[rclone / API 同步至 Google Drive]  [目标网站自动化发布 API (Bearer Token)]
  (目录: /上传文件/ 永久备份)         (TMDB 官方中文刮削 ➔ R2 zn_r2_upload ➔ videoSave ➔ 挂载验证)
                                       │
                                       ▼
                       [Telegram 推送完成通知与积分变动卡片]
```

---

## 2. 目标站点鉴权与双账号签到系统 (以 EMOS 为例)

### 2.1 永久 Token 鉴权 (Bearer Token)
* 在站点个人中心复制用户的持久性 `Token`（格式形如 `6368_xxxxxx`）；
* 后续所有 API 请求统一在 Header 中注入：
  ```python
  headers = {
      "Authorization": f"Bearer {user_token}",
      "Content-Type": "application/json",
      "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
      "Accept": "application/json, text/plain, */*"
  }
  ```

### 2.2 每日自动签到与寄语系统 (三级控制架构)
EMOS 签到接口支持附加 10 字以内的个性化祝福语或打卡寄语：
* **签到状态查询**：`GET https://emos.club/api/sign/check`
  - 返回 `{"is_sign": true|false, "user_id": "..."}`
* **提交签到**：`PUT https://emos.club/api/user/sign?content={寄语}`
  - `content`：URL 编码的字符串（最多 10 字，如 `开心每一天`、`元气满满！`）
* **运维 Bot 控制台三级配置规范**：
  - **一级控制**：`🟢 自动签到开关` 与 `👉 立即手动双号签到`
  - **二级控制**：`🎈 随机寄语模式`（从祝福语库随机抽取） vs `⚡ 普通直接模式`（无寄语打卡）
  - **三级控制**：每日打卡时间选择（预设 `00:05` / `06:00` / `08:00` / `12:00` 或自定义 `HH:MM`）
  - **常驻后台轮询**：每 30 秒比对当前北京时间（UTC+8），到达设定时间且今日未签时，自动为双账号打卡并在 Telegram 发送图文汇报战报。

---

## 3. 影视识别与多级检索/回退模式 (关键避坑)

### 3.1 中文主标题与拼音/英文杂质剥离
* **痛点**：国内压制组（ADWeb / PTerWEB / SharkWEB / HDArea 等）命名普遍格式为 `《中文名》.《Pinyin》.S2026E82.1080p...`。
* **避坑法则**：若直接用点号切分或整段标题检索（如 `爱情保卫战 Ai Qing Bao Wei Zhan`），站点后端将返回 0 命中。必须优先提取连续中文字符作为第一候选词。

```python
# 提取高质量搜索候选词列表
search_queries = []
cn_match = re.search(r"([\u4e00-\u9fa5]+(?:[·\s][\u4e00-\u9fa5]+)*)", raw_head)
if cn_match:
    search_queries.append(cn_match.group(1).strip())
parts = [p.strip() for p in re.split(r"[.\s_]+", raw_head) if p.strip()]
if parts and parts[0] not in search_queries:
    search_queries.append(parts[0])
```

### 3.2 4 位数年份季号（S2026）与集数层级匹配
* 综艺与大型纪录片常见跨年份季（`S2026` 对应 `2026年`），必须同时支持 `S(\d{1,4})` 与普通数字季。
* 当本地剧集树未收录新集时，可调用 `PATCH /api/video/sync` 传递 `{"tmdb_id": tmdb_id, "video_type": "tv"}`，触发服务端实时从 TMDB 刷新最新季集数据。

### 3.3 超前集数安全回退（Fallback）
* 若资源集数超前（例如文件是 `E82`，但 TMDB/EMOS 当前仅录入到 `E63`），安全回退至该季已存在的最新集，避免抛出异常导致整个流水线中断。

---

## 4. EMOS 完整上传与发布 API 协议链 (官方 R2 标准)

EMOS 采用 **智能元数据识别 + Cloudflare R2 zn_r2_upload 分片直传 + 视频落库 + 挂载双重校验** 架构：

### 4.1 步骤一：识别媒体或影视库树状检索回退
1. 首先请求 `/api/identify`：
   ```python
   resp = requests.post("https://emos.club/api/identify", headers=headers, json={"filename": filename, "type": "video"})
   ```
2. 若官方识别返回 502 / 404 / 未匹配，自动触发**影视树回退检索**：
   - 调用 `GET /api/video/search?title={关键词}` 获取 `video_id`；
   - 调用 `GET /api/video/tree?video_id={video_id}` 遍历季集，精准锁定 `item_type: "ve"` 与 `item_id`。

### 4.2 步骤二：申请分片上传 Token (必须指定 `zn_r2_upload`)
```python
resp = requests.post("https://emos.club/api/upload/getUploadToken", headers=headers, json={
    "type": "video",
    "file_type": "video/mp4",
    "file_name": filename,
    "file_size": file_size_bytes,
    "file_storage": "zn_r2_upload"  # ⚠️ 官方强制指定 Zn 存档服 R2 存储桶
})
token_data = resp.json()
file_id = token_data["file_id"]
```

### 4.3 步骤三：预签名分片 URL 并直传 R2 (自适应分片与重试防超时)
```python
# ⚠️ 关键防坑：单片过大（如 50MB+）在跨国网络抖动时极易触发 requests 的 Socket Write Timeout (The write operation timed out)
# 推荐 10MB 分片，并动态平衡分片总数与 min/max 限制
part_size = 10 * 1024 * 1024
if (file_size_bytes + part_size - 1) // part_size > 5000:
    part_size = (file_size_bytes + 4999) // 5000
part_size = max(min_part, min(part_size, max_part))
total_parts = max(1, (file_size_bytes + part_size - 1) // part_size)

presign_resp = session.post(f"https://emos.club/api/upload/multipart/{file_id}/presign", headers=headers, json={
    "number": total_parts
}, timeout=30).json()

url_map = {p["number"]: p["upload_url"] for p in presign_resp if "number" in p}
parts = []

with open(file_path, 'rb') as f:
    for num in range(1, total_parts + 1):
        chunk = f.read(part_size)
        if not chunk:
            break
        upload_url = url_map.get(num)
        
        # ⚠️ 必备：单分片指数退避重试机制 (最多 5 次)，避免网络波动导致全任务崩溃
        etag = None
        for attempt in range(1, 6):
            try:
                put_resp = session.put(upload_url, data=chunk, timeout=(15, 300))
                if put_resp.status_code in [200, 204]:
                    etag = put_resp.headers.get("ETag", "").strip('\"')
                    break
            except Exception as e:
                pass
            if attempt < 5:
                time.sleep(2 * attempt)
                
        if not etag:
            raise Exception(f"分片 {num}/{total_parts} 上传连续 5 次失败，中断任务")
            
        parts.append({"number": num, "etag": etag})
```

### 4.4 步骤四：完成分片合并与正式关联入库
```python
# 1. 合并分片
requests.post(f"https://emos.club/api/upload/multipart/{file_id}/complete", headers=headers, json={
    "parts": parts
})

# 2. 关联落库
save_resp = requests.post("https://emos.club/api/upload/video/save", headers=headers, json={
    "item_type": item_type,
    "item_id": item_id,
    "file_id": file_id
})
```

### 4.5 步骤五：双重挂载确认与防误删熔断保护 (关键铁律)
为彻底杜绝“误报成功却未入库、导致本地源文件被误删”的事故，必须加入二次挂载确认：
```python
# 3. 二次回查挂载状态
base_check = requests.get(f"https://emos.club/api/upload/video/base?item_type={item_type}&item_id={item_id}", headers=headers).json()
medias = base_check.get("video_medias", [])

# ⚠️ 熔断保护铁律：只有当 save_resp 成功 且 回查已挂载时，才允许删除本地即传即删临时文件！
# 若有任何异常，抛出错误并保留本地文件！
```

---

## 5. 分布式架构落地机陷阱与 VPS 远端直传方案 (核心避坑)

### ⚠️ 致命陷阱：跨主机文件路径不一致导致跳过上传
* **故障现象**：控制 Bot 运行在 AWS EC2，下载引擎 qBittorrent 部署在 RackNerd 远端 VPS。当种子下载完成后，控制 Bot 尝试在 AWS EC2 的本地路径 `/home/ubuntu/Downloads` 找文件，由于找不到文件而直接跳过了上传逻辑，误报完成但实际上 EMOS 并未入库、未加胡萝卜积分。
* **标准解决方案**：
  1. 在 RackNerd VPS 部署独立的 `emos_uploader.py` 执行脚本；
  2. 控制 Bot 侦测到 qBittorrent 下载完成后，通过 SSH 远端触发 VPS 上的 `emos_uploader.py '{vps_file_path}'`；
  3. **三大巨大优势**：
     - **0 AWS 出网流量占用**：GB 级别的视频直接从 VPS 直传 Cloudflare R2，完全不消耗 AWS 的 100G 免费额度；
     - **极速并发**：利用 VPS 的 1Gbps 大带宽跑满 R2 上传；
     - **文件强一致**：直传与校验全部在落地机本地完成，确保每一部视频真实入库拿到胡萝卜积分。
