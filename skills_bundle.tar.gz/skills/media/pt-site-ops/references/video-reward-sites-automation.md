# 视频分享与积分站点自动化接入指南 (Video Reward Sites Automation)

## 1. 架构总览与全自动闭环

对于支持上传视频获取积分/奖励的平台（如 EMOS 等），最佳工程实践是将 **Telegram 运维机器人 + 便宜大流量 VPS 中转 + Google Drive 归档 + 目标站点 API 自动化 + TMDB 权威刮削** 打通成全自动管道，并提供**做种与发布分离的两步式交互**：

```
[Telegram 运维 Bot 接收 .torrent 种子文件]
       │
       ▼
[第一步：选择核心模式]
 ├─ 🚀 【直接上传 EMOS 并删除（即传即删）】：单集下载 ➔ 传 GDrive ➔ 传 EMOS ➔ 挂载校验 ➔ 物理删除每集本地文件，0 占磁盘
 ├─ 🌱 【仅挂机做种（长期保留·不传 EMOS）】：满速下载并在本地硬盘永久做种保号赚魔力值，绝不删除
 └─ 🔄 【做种 + 上传 EMOS（保留做种）】：双重兼顾，既上传赚胡萝卜积分，又在本地永久保留持续做种
       │
       ▼ (若选择上传 EMOS)
[第二步：选择命名策略: 🤖 TMDB 智能自动改名 | ✏️ 手动输入名称 | 📄 保持原名]
       │
       ▼
[精准解析 InfoHash ➔ 提交 RackNerd VPS 的 qBittorrent 极速本地下载]
       │
       ▼
[⚠️ 分布式执行引擎：通过 SSH 触发 VPS 本地 emos_uploader.py 直接直传]
   ┌───┴───────────────────────────────┐
   ▼                                   ▼
[rclone / API 同步至 Google Drive]  [目标网站自动化发布 API (Bearer Token)]
  (目录: /上传文件/ 永久备份)         (TMDB 官方中文刮削 ➔ R2 zn_r2_upload ➔ videoSave ➔ 挂载验证)
                                       │
                                       ▼
                       [Telegram 推送完成通知与积分变动卡片]
```

---

## 2. 目标站点鉴权与双账号签到系统 (以 EMOS 为例)

### 2.1 永久 Token 鉴权 (Bearer Token)
* 在站点个人中心复制用户的持久性 `Token`（格式形如 `6368_xxxxxx`）；
* 后续所有 API 请求统一在 Header 中注入：
  ```python
  headers = {
      "Authorization": f"Bearer {user_token}",
      "Content-Type": "application/json",
      "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
      "Accept": "application/json, text/plain, */*"
  }
  ```

### 2.2 每日自动签到与寄语系统 (三级控制架构)
EMOS 签到接口支持附加 10 字以内的个性化祝福语或打卡寄语：
* **签到状态查询**：`GET https://emos.club/api/sign/check`
  - 返回 `{"is_sign": true|false, "user_id": "..."}`
* **提交签到**：`PUT https://emos.club/api/user/sign?content={寄语}`
  - `content`：URL 编码的字符串（最多 10 字，如 `开心每一天`、`元气满满！`）
* **运维 Bot 控制台三级配置规范**：
  - **一级控制**：`🟢 自动签到开关` 与 `👉 立即手动双号签到`
  - **二级控制**：`🎈 随机寄语模式`（从祝福语库随机抽取） vs `⚡ 普通直接模式`（无寄语打卡）
  - **三级控制**：每日打卡时间选择（预设 `00:05` / `06:00` / `08:00` / `12:00` 或自定义 `HH:MM`）
  - **常驻后台轮询**：每 30 秒比对当前北京时间（UTC+8），到达设定时间且今日未签时，自动为双账号打卡并在 Telegram 发送图文汇报战报。

---

## 3. 影视识别与多级检索/回退模式 (关键避坑)

### 3.1 中文主标题与拼音/英文杂质剥离
* **痛点**：国内压制组（ADWeb / PTerWEB / SharkWEB / HDArea 等）命名普遍格式为 `《中文名》.《Pinyin》.S2026E82.1080p...`。
* **避坑法则**：若直接用点号切分或整段标题检索（如 `爱情保卫战 Ai Qing Bao Wei Zhan`），站点后端将返回 0 命中。必须优先提取连续中文字符作为第一候选词。

```python
# 提取高质量搜索候选词列表
search_queries = []
cn_match = re.search(r"([\u4e00-\u9fa5]+(?:[·\s][\u4e00-\u9fa5]+)*)", raw_head)
if cn_match:
    search_queries.append(cn_match.group(1).strip())
parts = [p.strip() for p in re.split(r"[.\s_]+", raw_head) if p.strip()]
if parts and parts[0] not in search_queries:
    search_queries.append(parts[0])
```

### 3.2 4 位数年份季号（S2026）与集数层级匹配
* 综艺与大型纪录片常见跨年份季（`S2026` 对应 `2026年`），必须同时支持 `S(\d{1,4})` 与普通数字季。
* 当本地剧集树未收录新集时，可调用 `PATCH /api/video/sync` 传递 `{"tmdb_id": tmdb_id, "video_type": "tv"}`，触发服务端实时从 TMDB 刷新最新季集数据。

### 3.3 综艺「非标季名」与「加更/会员Plus/特别篇」精准识别避坑 (重要实战经验)
* **痛点现象**：国内综艺在 TMDB 与 EMOS 库中，常使用主题季名（例如《中餐厅》第 10 季命名为 `南洋拾光季`、第 9 季为 `非洲创业季`），且所有「加更版 / 会员Plus版 / 超前企划 / 合伙人手记 / 独家直拍」全部集中收录在 `特别篇`（Season 0）分类下。
* **避坑法则**：
  1. **季名下标映射与主题名兜底**：当文件名带有 `S10` 但剧集树中没有 `\"第10季\"` 纯数字字样时，需先将非特别篇的所有常规季按顺序排列，使用 `seasons[season_num - 1]` 准确反查到当前季的主题名称（如 `南洋拾光季`）；
  2. **加更/Plus版跨季下钻特别篇**：若文件名包含 `加更` / `Plus` / `会员Plus`，优先在 `特别篇` 内根据 **“主题季名 + 第X期/集”** 双重过滤匹配；若特别篇中匹配到该期特别内容，直接绑定并返回对应的 `item_id`，防止误判为未识别或错绑至历史老季；
  3. **正片季集优先匹配**：非加更的正片（如 `S10E11`）则直接在对应主题季的 `episodes` 列表通过集数 `episode_number` 绑定。

### 3.4 超前集数安全回退（Fallback）
* 若资源集数超前（例如文件是 `E82`，但 TMDB/EMOS 当前仅录入到 `E63`），安全回退至该季已存在的最新集，避免抛出异常导致整个流水线中断。

### 3.5 多季剧集 (Season/S02/第二季) 标准解析与防硬编码 S01 避坑 (重要实战避坑)
* **致命误区**：在编写剧集重命名与自动入库逻辑时，很多开发者只使用 `re.search(r'[Ee](\d+)')` 提取集数，然后格式化为 `f"{title} S01E{ep:02d}"`，导致第二季/第三季（如 `S02E11` 或 `第二季第11集`）被错误识别并上传为第一季（`S01E11`），造成媒体库剧集错乱覆盖。
* **正确做法**：
  1. **多级 Season 提取**：优先从文件名或种子名正则匹配阿拉伯数字与中文数字季数（`r'[Ss](\d{1,2})|[第\s](\d{1,2}|[一二三四五六七八九十]+)[季部]'`）；
  2. **TMDB 元数据季数协同**：结合 TMDB 查询返回的 `season` 字段；
  3. **标准格式化**：统一输出为 `f"{title} S{season_num:02d}E{extracted_ep:02d}{ext}"`，确保多季剧集分季精准入库。

### 3.6 运行中流水线更名与无缝守护接管 (实战运维经验)
* **场景**：当任务正在高速下载中（如 40%~60%），用户发现自动命名的标题错误并指定了更正名称。
* **处置流程**：
  1. **下载与控制流解耦**：qBittorrent 运行在落地机独立承载下载，重启控制 Bot 并不会中断已有的下载进度；
  2. **防双重上传冲突 (Race Condition)**：重启 Bot 服务销毁内存中携带旧名称的 pipeline，同时后台启动轻量轮询守护脚本（`watch_and_upload.py`）精准监听该种子的 Hash；
  3. **完成时显式传参直传**：守护脚本检测到下载达 100% 后，以用户确定的 `custom_name` 调用落地机的 `emos_uploader.py '{remote_path}' '{custom_name}'`，实现秒级无缝入库并杜绝旧名误传。

---

## 4. EMOS 完整上传与发布 API 协议链 (官方 R2 标准)

EMOS 采用 **智能元数据识别 + Cloudflare R2 zn_r2_upload 分片直传 + 视频落库 + 挂载双重校验** 架构：

### 4.1 步骤一：识别媒体或影视库树状检索回退
1. 首先请求 `/api/identify`：
   ```python
   resp = requests.post("https://emos.club/api/identify", headers=headers, json={"filename": filename, "type": "video"})
   ```
2. 若官方识别返回 502 / 404 / 未匹配，自动触发**影视树回退检索**：
   - 调用 `GET /api/video/search?title={关键词}` 获取 `video_id`；
   - 调用 `GET /api/video/tree?video_id={video_id}` 遍历季集，精准锁定 `item_type: "ve"` 与 `item_id`。

### 4.2 步骤二：申请分片上传 Token (必须指定 `zn_r2_upload`)
```python
resp = requests.post("https://emos.club/api/upload/getUploadToken", headers=headers, json={"type": "video", "file_type": "video/mp4", "file_name": filename, "file_size": file_size_bytes, "file_storage": "zn_r2_upload"})
token_data = resp.json()
file_id = token_data["file_id"]
```

### 4.3 步骤三：预签名分片 URL 并直传 R2 (自适应分片与重试防超时)
```python
# ⚠️ 关键防坑：单片过大（如 50MB+）在跨国网络抖动时极易触发 requests 的 Socket Write Timeout
part_size = 10 * 1024 * 1024
if (file_size_bytes + part_size - 1) // part_size > 5000:
    part_size = (file_size_bytes + 4999) // 5000
part_size = max(min_part, min(part_size, max_part))
total_parts = max(1, (file_size_bytes + part_size - 1) // part_size)

presign_resp = session.post(f"https://emos.club/api/upload/multipart/{file_id}/presign", headers=headers, json={
    "number": total_parts
}, timeout=30).json()

url_map = {p["number"]: p["upload_url"] for p in presign_resp if "number" in p}
parts = []

with open(file_path, 'rb') as f:
    for num in range(1, total_parts + 1):
        chunk = f.read(part_size)
        if not chunk:
            break
        upload_url = url_map.get(num)
        
        # ⚠️ 必备：单分片指数退避重试机制 (最多 5 次)
        etag = None
        for attempt in range(1, 6):
            try:
                put_resp = session.put(upload_url, data=chunk, timeout=(15, 300))
                if put_resp.status_code in [200, 204]:
                    etag = put_resp.headers.get("ETag", "").strip('\"')
                    break
            except Exception as e:
                pass
            if attempt < 5:
                time.sleep(2 * attempt)
                
        if not etag:
            raise Exception(f"分片 {num}/{total_parts} 上传连续 5 次失败，中断任务")
            
        parts.append({"number": num, "etag": etag})
```

### 4.4 步骤四：完成分片合并与正式关联入库
```python
# 1. 合并分片
requests.post(f"https://emos.club/api/upload/multipart/{file_id}/complete", headers=headers, json={
    "parts": parts
})

# 2. 关联落库
save_resp = requests.post("https://emos.club/api/upload/video/save", headers=headers, json={
    "item_type": item_type,
    "item_id": item_id,
    "file_id": file_id
})
```

### 4.5 步骤五：双重挂载确认与防误删熔断保护 (关键铁律)
为彻底杜绝“误报成功却未入库、导致本地源文件被误删”的事故，必须加入二次挂载确认：
```python
# 3. 二次回查挂载状态
base_check = requests.get(f"https://emos.club/api/upload/video/base?item_type={item_type}&item_id={item_id}", headers=headers).json()
medias = base_check.get("video_medias", [])

# ⚠️ 熔断保护铁律：只有当 save_resp 成功 且 回查已挂载时，才允许删除本地即传即删临时文件！
# 若有任何异常，抛出错误并保留本地文件！
```

---

## 5. 分布式架构落地机陷阱与 VPS 远端直传方案 (核心避坑)

### ⚠️ 致命陷阱：跨主机文件路径不一致导致跳过上传
* **故障现象**：控制 Bot 运行在 AWS EC2，下载引擎 qBittorrent 部署在 RackNerd 远端 VPS。当种子下载完成后，控制 Bot 尝试在 AWS EC2 的本地路径 `/home/ubuntu/Downloads` 找文件，由于找不到文件而直接跳过了上传逻辑，误报完成但实际上 EMOS 并未入库、未加胡萝卜积分。
* **标准解决方案**：
  1. 在 RackNerd VPS 部署独立的 `emos_uploader.py` 执行脚本；
  2. 控制 Bot 侦测到 qBittorrent 下载完成后，通过 SSH 远端触发 VPS 上的 `emos_uploader.py '{vps_file_path}'`；
  3. **三大巨大优势**：
     - **0 AWS 出网流量占用**：GB 级别的视频直接从 VPS 直传 Cloudflare R2，完全不消耗 AWS 的 100G 免费额度；
     - **极速并发**：利用 VPS 的 1Gbps 大带宽跑满 R2 上传；
     - **文件强一致**：直传与校验全部在落地机本地完成，确保每一部视频真实入库拿到胡萝卜积分。

---

## 6. EMOS 视频/音乐反向代理网关部署规范 (Emby & Subsonic Proxy)

为实现国内/外网客户端高速播放并免受上游网络抖动影响，可搭建符合官方规范的七层反向代理网关。

### 6.1 反代架构与头部规范
| 上游服务 | 官方源站域名 | 推荐反代路径 | 必须透传/注入头部 | 关键特性处理 |
| :--- | :--- | :--- | :--- | :--- |
| **视频服 (Emby)** | `https://video.emos.best` | `/emby` | `EMOS-PROXY-ID`, `EMOS-PROXY-NAME`, `X-Forwarded-For` | **HTTP 206 Partial Content**、`Range` 头部、禁用缓冲 |
| **音乐服 (Subsonic)** | `https://music.emos.best` | `/rest` | 同上 | `Range` 音频流透传 |

* **反代面板选型**：
  * ❌ **四层端口转发面板（极光/GOST/Realm 等）**：无法注入 HTTP 请求头与做路径分流，严禁使用；
  * ⚠️ **七层反代面板**：必须支持「自定义 Nginx 代码片段」以实现正则图片缓存与 `limit_req` 节流；
  * ✅ **原生 Docker Nginx / OpenResty**：最稳定可靠的标准方案。

### 6.2 官方标准 Nginx 配置文件模板 (`nginx.conf`，含 HTTP+HTTPS 双协议与智能自适应路由)
```nginx
user nginx;
worker_processes auto;
error_log /var/log/nginx/error.log notice;
pid /var/run/nginx.pid;

events {
    worker_connections 1024;
}

http {
    include /etc/nginx/mime.types;
    default_type application/octet-stream;

    # 1. 进度上报节流 (每秒最多 2 次请求)
    limit_req_zone $binary_remote_addr zone=emos_progress:10m rate=2r/s;

    # 2. 图片与静态数据缓存区 (1GB)
    proxy_cache_path /var/cache/nginx/emos_cache levels=1:2 keys_zone=emos_cache:20m max_size=1g inactive=7d use_temp_path=off;

    # 3. 自动补全 User-Agent（防上游 Cloudflare 5秒盾拦截空 UA / curl）
    map $http_user_agent $final_ua {
        default $http_user_agent;
        ""      "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36";
    }

    server {
        listen 8096;          # HTTP 监听
        listen 8097 ssl;      # HTTPS 监听 (配合 Cloudflare 2053/2096 等端口)
        http2 on;
        server_name _;

        # 自签 SSL 证书 (openssl req -x509 -nodes -days 3650 -newkey rsa:2048 -keyout server.key -out server.crt -subj '/CN=emos.domain.com')
        ssl_certificate /etc/nginx/ssl/server.crt;
        ssl_certificate_key /etc/nginx/ssl/server.key;
        ssl_protocols TLSv1.2 TLSv1.3;
        ssl_ciphers HIGH:!aNULL:!MD5;

        client_max_body_size 100M;
        proxy_connect_timeout 60s;
        proxy_send_timeout 120s;
        proxy_read_timeout 120s;

        # 公共请求头与 EMOS 认证
        proxy_set_header Host $proxy_host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_set_header User-Agent $final_ua;
        
        # ⚠️ 替换为实际用户 UID 与 称号
        proxy_set_header EMOS-PROXY-ID "eABCDEFGHs";
        proxy_set_header EMOS-PROXY-NAME "your_name";

        # WebSocket 支持
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection $http_connection;

        # 1.1 播放进度上报节流 (支持 /emby 前缀与无前缀)
        location ~* ^/(emby/)?Sessions/Playing/Progress {
            limit_req zone=emos_progress burst=5 nodelay;
            proxy_pass https://video.emos.best;
            proxy_ssl_server_name on;
        }

        # 1.2 图片资源强缓存 (7天)
        location ~* ^/(emby/)?Items/.*/Images/.* {
            proxy_cache emos_cache;
            proxy_cache_valid 200 7d;
            proxy_cache_valid 404 1m;
            proxy_cache_use_stale error timeout updating http_500 http_502 http_503 http_504;
            add_header X-Cache-Status $upstream_cache_status;

            proxy_pass https://video.emos.best;
            proxy_ssl_server_name on;
        }

        # 1.3 Ping 接口缓存 (1分钟)
        location ~* ^/(emby/)?System/Ping$ {
            proxy_cache emos_cache;
            proxy_cache_valid 200 1m;
            add_header X-Cache-Status $upstream_cache_status;

            proxy_pass https://video.emos.best;
            proxy_ssl_server_name on;
        }

        # 2. 音乐服反代 (https://music.emos.best)
        location /rest {
            proxy_pass https://music.emos.best;
            proxy_ssl_server_name on;

            proxy_set_header Range $http_range;
            proxy_set_header If-Range $http_if_range;
            proxy_buffering off;
        }

        # 1.4 带有 /emby 前缀的标准反代 (支持 206 Range 与流媒体)
        location /emby/ {
            proxy_pass https://video.emos.best/emby/;
            proxy_ssl_server_name on;

            # 206 Range 支持
            proxy_set_header Range $http_range;
            proxy_set_header If-Range $http_if_range;

            # 媒体流禁用代理缓冲，随下随播，避免拖进度条卡顿
            proxy_buffering off;
            proxy_request_buffering off;
        }

        # 1.5 智能兜底路由：若客户端未加 /emby/ 前缀直接请求根 API，自动代理至上游 /emby/
        location / {
            proxy_pass https://video.emos.best/emby/;
            proxy_ssl_server_name on;

            proxy_set_header Range $http_range;
            proxy_set_header If-Range $http_if_range;
            proxy_buffering off;
            proxy_request_buffering off;
        }
    }
}
```

### 6.3 极速 Docker 启动命令与多端口映射 (支持 HTTP + HTTPS 双协议)
```bash
# 准备自签证书（若未申请商业证书）
mkdir -p /home/ubuntu/docker-nodes/emos-proxy/ssl
openssl req -x509 -nodes -days 3650 -newkey rsa:2048 \
  -keyout /home/ubuntu/docker-nodes/emos-proxy/ssl/server.key \
  -out /home/ubuntu/docker-nodes/emos-proxy/ssl/server.crt \
  -subj '/CN=emos.yourdomain.com'

# 启动容器并映射 HTTP 端口(8096, 8880, 8080) 与 HTTPS 端口(2053, 2083, 2096)
docker run -d \
  --name lemon-emos-proxy \
  --restart unless-stopped \
  -p 8096:8096 \
  -p 8880:8096 \
  -p 8080:8096 \
  -p 2052:8096 \
  -p 2053:8097 \
  -p 2083:8097 \
  -p 2087:8097 \
  -p 2096:8097 \
  -v /home/ubuntu/docker-nodes/emos-proxy/conf/nginx.conf:/etc/nginx/nginx.conf:ro \
  -v /home/ubuntu/docker-nodes/emos-proxy/ssl:/etc/nginx/ssl:ro \
  -v /home/ubuntu/docker-nodes/emos-proxy/cache:/var/cache/nginx/emos_cache \
  nginx:alpine
```

### 6.4 源站 IP 隐私保护与 Cloudflare CDN 零泄漏隐藏实战 (安全核心与 400 避坑)
* **安全痛点**：直接将 VPS 真实 IP:端口暴露给客户端或网络，极易被扫描器探测并遭受攻击。
* **Cloudflare CDN 小黄云（Proxied）隐藏方案**：
  1. **解析与小黄云开启**：通过 Cloudflare API 或控制台创建 A 记录指向 VPS IP，开启 `proxied: true`；外界探测只能获取 Cloudflare 的 Anycast 节点 IP（如 `104.21.x.x`、`172.67.x.x`），彻底隐藏真实 VPS IP。
  2. **Cloudflare CDN 官方开放端口适配**：
     - **HTTP 端口**：`80`, `8080`, `8880`, `2052`, `2082`, `2086`, `2095`（客户端使用 `http://emos.yourdomain.com:8880` 访问）
     - **HTTPS 端口**：`443`, `2053`, `2083`, `2087`, `2096`, `8443`（客户端勾选 SSL 并使用 `https://emos.yourdomain.com:2053` 访问）
  3. **⚠️ 致命踩坑：客户端开启 SSL 连接 8880 报 400 Bad Request**：
     - **故障现象**：Emby 客户端（如 iOS App、Fileball、SenPlayer 等）默认勾选了“使用 SSL”，连接 `emos.domain.com:8880` 时直接提示 `400 Bad Request`。
     - **原因**：8880 是 Cloudflare 的纯 HTTP 端口，接收到 TLS Client Hello 握手包会直接拒绝并返回 400。
     - **解决方案**：在客户端中，若**开启 SSL** 则必须填 HTTPS 专用端口（如 `2053` 或 `2096`）；若**关闭 SSL** 才填 HTTP 端口（如 `8880` 或 `8080`）。
  4. **⚠️ 避坑：客户端路径无 `/emby` 前缀导致 404**：
     - 部分三方播放器请求根目录 API（如 `/System/Info/Public`），通过 Nginx 兜底 `location / { proxy_pass https://video.emos.best/emby/; }` 智能自适应追加前缀，实现免配 Context Path。
  5. **Cloudflare API 自动化创建 DNS 代理记录示例**：
     ```bash
     curl -s -X POST "https://api.cloudflare.com/client/v4/zones/{ZONE_ID}/dns_records" \
          -H "Authorization: Bearer {CF_API_TOKEN}" \
          -H "Content-Type: application/json" \
          --data '{"type":"A","name":"emos.yourdomain.com","content":"{VPS_IP}","ttl":1,"proxied":true}'
     ```

### 6.5 国内直连 Cloudflare CDN 速度慢 (几百 KB/s) 根因与三大提速方案 (优选 IP & 代理分流)
* **速度瓶颈根因**：
  * Cloudflare 免费 Anycast CDN 在国内默认解析到美西节点，跨国延迟 200~300ms 且受晚高峰 163 骨干网 QoS 严重压制，单线程 TCP 直连吞吐常被卡死在 300KB/s~800KB/s。
* **三大加速实战方案**：
  1. **方案一：播放器走代理分流（秒开 4K · 最推荐）**：
     - 在代理客户端（Clash / Surge / Shadowrocket / Loon）或软路由上，将反代域名 `emos.yourdomain.com` 规则指定走 **香港 / 新加坡 / 日本 / 优质美西节点**；
     - 代理节点与 Cloudflare 边缘秒级握手，速度瞬间拉满至 50MB/s~100MB/s+。
  2. **方案二：Cloudflare 优选 IP（免挂代理 · 直连提速）**：
     - **原理**：将反代域名强行解析至当前运营商测速表现最优秀的 Cloudflare CDN 边缘 IP（如香港/圣何塞/法兰克福高带宽节点），绕过劣质 Anycast 调度。
     - **各运营商精选高吞吐节点段**：
       - **电信**：`104.18.43.174`、`104.16.160.25`、`162.159.208.4`
       - **联通**：`172.64.144.82`、`104.18.185.26`、`104.21.224.5`
       - **移动**：`104.16.226.46`、`172.64.32.1`、`141.101.115.1`
     - **落地方法**：
       - *设备本地 Hosts / 路由器 SmartDNS*：添加 `优选IP emos.yourdomain.com`；
       - *代理软件 Hosts 模块*：添加 `'emos.yourdomain.com': '优选IP'`；
       - *极限自测*：运行 `XIU2/CloudflareSpeedTest` 脚本直接测出本地物理宽带第 1 名 IP。
  3. **方案三：优质中转机反代**：
     - 采用带有 CMIN2 / 9929 / CN2 GIA 优化线路的 VPS 或香港/新加坡小鸡作为前置 Nginx 反代入口。

### 6.6 MakkaPakka（玛卡巴卡）Worker 反代面板对接 EMOS 的 404 / 403 根因与中继桥接方案 (实战排障)

* **MakkaPakka 面板架构**：
  * 基于 Cloudflare Worker 的多节点 Emby 代理与智能测速调度面板（前端由 Cookie `admin_token` 认证，管理 API 为 `/api/routes`）。
* **配置 EMOS 报 404 / 403 的根本原因**：
  1. **缺少专属鉴权头（403）**：MakkaPakka 的通用 Worker 代码在向目标转发时，**不会自动注入** EMOS 强制要求的 `EMOS-PROXY-ID` 与 `EMOS-PROXY-NAME`，上游直接拦截；
  2. **根路径 API 缺失（404）**：MakkaPakka 默认去除节点前缀并转发给 `target` 根路径，而 EMOS 的视频 API 全部挂载在 `/emby/...` 路径下，直接请求根路径返回 404。
* **⚠️ Cloudflare Worker 直接对接 VPS 报 1003 错误避坑**：
  * **故障现象**：在 MakkaPakka 面板中将目标直接填为 `http://VPS_IP:8096` 时，请求返回 `HTTP/2 403 error code: 1003`。
  * **原因**：Cloudflare Worker 底层安全限制，禁止通过纯 IP + 非标准端口（如 8096）发起 `fetch()` 请求。
  * **解决方案**：为 VPS 解析一个子域名（例如 `vps.yourdomain.com` -> VPS IP，`proxied: false`），然后在 MakkaPakka 面板中将 target 填为 `http://vps.yourdomain.com:8096`。
* **标准中继桥接架构（既保留面板测速/分发，又完美支持 EMOS）**：
  ```
  [客户端 (Emby / Infuse / 平板 / 电视)]
                 │
                 ▼
  [MakkaPakka Cloudflare Worker 面板 (https://zjw.domain.com/emos)]
                 │ (通过域名解析转发)
                 ▼
  [VPS 专属中继 Nginx (http://vps.domain.com:8096)]
    ├─ 自动注入 EMOS-PROXY-ID: eK981JREMs
    ├─ 自动注入 EMOS-PROXY-NAME: naye
    ├─ 智能自适应补全 /emby 路径
    ├─ 开启 206 Partial Content / Range 流媒体直通
    └─ 开启图片 7 天强缓存与 Ping 缓存
                 │
                 ▼
  [EMOS 官方视频服 (https://video.emos.best/emby/...)] ➔ HTTP 200 OK 顺畅观影
  ```
* **MakkaPakka 面板 API 快速更新节点示例**：
  ```bash
  curl -s -X POST -b "admin_token=YOUR_TOKEN" -H "Content-Type: application/json" \
    -d '{"prefix":"emos","target":"http://vps.yourdomain.com:8096","mode":"off","remark":"emos","icon":"https://emby-icon.vercel.app/icons/Emos.PNG","cache_img":"on","sort_order":0,"oldPrefix":"emos"}' \
    https://your-makkapakka-panel.xyz/api/routes
  ```

### 6.7 Emby 媒体库数量统计与馆藏展示底层原理 (API、播放器卡片点亮与安全风控分析)

* **底层 RESTful API 原理**：
  * **媒体计数总览接口**：`GET /emby/Items/Counts`（携带 `X-Emby-Token` 或有效 Session）：
    ```json
    {
      "MovieCount": 15820,
      "SeriesCount": 3640,
      "EpisodeCount": 98500,
      "SongCount": 45200,
      "AlbumCount": 2800,
      "ItemCount": 163160
    }
    ```
  * **分类视图接口**：`GET /emby/Users/{userId}/Views`（获取所有库分类，如华语电影、动漫、欧美剧集等）。
* **⚠️ 痛点：播放器服务器卡片媒体数量显示为 0 (SenPlayer / Fileball / VidHub)**：
  * **故障现象**：在 Emby 客户端的服务器卡片列表页，左下角的电影小图标和电视剧小图标旁一直显示为 `0`；
  * **根本原因**：EMOS 官方服由于虚拟库权限隔离或未公开全局统计，向 `GET /emby/Items/Counts` 默认返回全 0（`{"MovieCount":0, "SeriesCount":0...}`），播放器拿到全 0 数据包后便在卡片上显示 0；
  * **反代网关数量注入解决方案（Mock Counts 注入）**：
    在反代 Nginx 或 Worker 中拦截 `/(emby/)?Items/Counts` 请求，直接在本地返回准确的媒体统计 JSON：
    ```nginx
    location ~* ^/(emby/)?Items/Counts$ {
        default_type application/json;
        add_header Content-Type "application/json; charset=utf-8";
        add_header Access-Control-Allow-Origin *;
        return 200 '{"MovieCount":18450,"SeriesCount":4120,"EpisodeCount":118600,"SongCount":56800,"AlbumCount":3200,"MusicVideoCount":150,"BoxSetCount":680,"BookCount":0,"ItemCount":141170}';
    }
    ```
    * 播放器刷新列表时即可瞬间点亮显示 `1.8万部电影 / 4,120部剧集`；
    * 且该请求由反代本地直接终结，**不向上游产生任何流量，100% 零风控隐患**。
* **三种主流工程展示实现**：
  1. **反代面板卡片轮询（Meridian / 导航站模式）**：后台定时脚本用 API Key 轮询每个 Emby 节点的 `/Items/Counts`，提取 `MovieCount` 与 `SeriesCount` 渲染至前端节点卡片；
  2. **Nginx / Worker HTML 动态注入（Web 端小药丸）**：在反代返回 `index.html` 时通过 `sub_filter` 动态注入轻量 JS 悬浮组件，直接在网页版右上角显示馆藏量；
  3. **独立实时大屏看板（`/stats` 端点）**：反代服务暴露一个 `/stats` 路由与 `/stats_data.json`，提供深色炫酷 Apple TV 风格的馆藏仪表盘；
  4. **Telegram 运维 Bot 一键查库**：集成 `/emby_stats` 指令，定时拉取所有节点的在线状态与媒体量生成图文报表。
* **⚠️ 账号安全与风控影响深度分析**：
  1. **为什么完全不会对账号造成封号或降权风险？**
     - **客户端标配行为**：任何正规 Emby 客户端（官方 App、Infuse、VidHub、SenPlayer、Web 端）在**每次登录并打开首页的第一秒**，都**必须且一定会原生调用一次** `/emby/Items/Counts` 与 `/emby/Users/{userId}/Views` 以在界面上绘制“电影 (12,000)”、“剧集 (3,500)”的标签徽章。
     - **零侵入静默旁路捕获 / 本地 Mock（最安全机制）**：反代网关在本地直接响应或在客户端正常看片时旁路记录，**完全不向官方发送任何额外的主动爬虫请求**，在官方服务器看来完全正常，100% 零风控隐患。
  2. **多用户共享反代线路的安全性与流量**：
     - **隐私隔离**：反代注入的 `EMOS-PROXY-ID` 仅用于通过官方网关准入；其他人接入后依然需要使用各自独立的 Emby 账号密码登录，**绝对无法窥探主号的密码、观看记录或收藏**；
     - **流量消耗**：视频流经过 VPS 中转时，1080P 电影约 2~3GB/部、4K 约 8~12GB/部，在 5TB 大流量 VPS 上多人日常观影完全绰绰有余。

### 6.8 进阶：纯 Cloudflare Worker 免 VPS 中转方案 (0 消耗服务器流量)

若希望多人使用该线路时**彻底不消耗 VPS 流量与带宽**，可直接将鉴权与路径对齐逻辑注入玛卡巴卡 Worker 源码中：
在 `async fetch(request, env, ctx)` 最开头插入：
```javascript
// 🌟 EMOS 专属原生直连与鉴权拦截 (零 VPS 流量中转)
try {
    const _emosUrl = new URL(request.url);
    if (_emosUrl.pathname.startsWith('/emos')) {
        // 1. 媒体库数量拦截点亮卡片
        if (_emosUrl.pathname.endsWith('/Items/Counts')) {
            return new Response('{"MovieCount":18450,"SeriesCount":4120,"EpisodeCount":118600,"SongCount":56800,"AlbumCount":3200,"MusicVideoCount":150,"BoxSetCount":680,"BookCount":0,"ItemCount":141170}', {
                status: 200,
                headers: {
                    'Content-Type': 'application/json; charset=utf-8',
                    'Access-Control-Allow-Origin': '*'
                }
            });
        }
        // 2. 剥离 /emos 前缀并补全 /emby 路径
        let _subPath = _emosUrl.pathname.replace(/^\/emos/, '');
        if (!_subPath.startsWith('/emby') && !_subPath.startsWith('/rest')) {
            _subPath = '/emby' + _subPath;
        }
        if (_subPath === '/emby' || _subPath === '/emby/') {
            _subPath = '/emby/System/Info/Public';
        }
        const _targetUrl = 'https://video.emos.best' + _subPath + _emosUrl.search;
        
        // 3. 注入官方必需头部
        const _newHeaders = new Headers(request.headers);
        _newHeaders.set('Host', 'video.emos.best');
        _newHeaders.set('EMOS-PROXY-ID', 'eK981JREMs');
        _newHeaders.set('EMOS-PROXY-NAME', 'naye');
        if (!_newHeaders.get('User-Agent')) {
            _newHeaders.set('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36');
        }
        const _newReq = new Request(_targetUrl, {
            method: request.method,
            headers: _newHeaders,
            body: ['GET', 'HEAD'].includes(request.method) ? null : request.body,
            redirect: 'follow'
        });
        return fetch(_newReq);
    }
} catch(_err) {}
```
* **效果**：由 Cloudflare 全球 Anycast 节点直接向 EMOS 官方请求，**完全绕过 VPS，0 消耗 VPS 流量**。
