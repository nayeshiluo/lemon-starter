---
name: pt-site-ops
description: PT 站点运维与新手过关：主流站点特色、考核刷量避坑与 Transmission 客户端部署。
---

# PT 站点运维与新手过关指南 (PT Site Ops)

本技能用于管理国内主流 PT 站点（Private Tracker）、解析各站资源定位、辅助新手考核（下载量/上传量/分享率）快速过关，以及在 Linux 服务器上无头部署与排障轻量 PT 客户端（Transmission / qBittorrent）。

---

## 1. 国内主流 PT / Web 资源站定位对比

| 站点名称 | 官方常用入口 | 核心定位与特色优势 | 推荐订阅与使用场景 |
| :--- | :--- | :--- | :--- |
| **憨憨 (HHanClub)** | `https://hhanclub.top/` | • Web 流媒体与国漫首发秒级更新<br>• Netflix 4K 独家流媒体源 | 国漫连载、国产热播网剧追更 |
| **观众 (Audiences)** | `https://audiences.me/` | • 综合流媒体与动漫分类完备<br>• 压制与 DIY 首发更新神速 | 新番动漫、国漫连载双重订阅 |
| **空岛 (SkyIsland)** | `https://skyisland.top/` | • 电影与电视剧资源库庞大<br>• **站内专人制作人工“去头去尾去广告”纯享版** | 电视剧与电影免广告追剧、NAS 入库 |
| **馒头 (M-Team)** | `https://kp.m-team.cc/`<br>`https://tp.m-team.cc/` | • 圈内巨无霸综合第一大站<br>• 资源体量海量、保种极强、特色区全覆盖 | 冷门补全、高码率原盘、终极兜底 |

---

## 2. PT 新手考核快速过关与避坑铁律

### ⚠️ 避坑一：Free（免费）种子不计真实下载量
* **致命误区**：新手为图省事全下 `Free` / `2XFree` 热门种，结果下载量统计永远为 `0 GB` 导致考核失败。
* **正确做法**：过 **下载量 ≥ 1GB** 任务时，必须挑选 **普通种子（无 Free 标或 50% 标）**，体积选 **1.2 GB ~ 2 GB** 的单集剧集或小电影，下载完成即可稳稳达成 1G 下载指标。

### 🚀 避坑二：如何极速刷满上传量
* 挑选 **首页最新发布（发布仅数分钟）、下载人数（Leech）多、带有 `2XFree` 或 `Free` 标** 的置顶热门大种。
* 挂载在千兆云服务器或 NAS 上，抢占初始做种通道，数分钟内即可刷出 2G~5G 上传。

#### ⚠️ 常见疑问：为什么客户端做种很多，但上传量才几 MB（stalledUP）？
1. **种子过熟、做种者远超下载者（供求失衡）**：
   - 当种子发布已久，下载者（Leechers 仅 1~2 人）而做种者（Seeders 多达十几人）时，由于没有持续的吸血需求，客户端会长期处于 `stalledUP`（等待上传），上传流量几乎停滞。
2. **高速 Seedbox（刷流盒子）网络碾压**：
   - 零星下载者发起连接时，拥有万兆/千兆专线的高速盒子会优先以毫秒级响应并迅速喂饱对方，普通节点仅能传输极少量的协议握手与零星碎片（通常仅数 MB）。
3. **平台上传量口径区分**：
   - **PT Tracker 站点**：统计的是 P2P 协议实际分发给其他 Peer 的网络流量。
   - **视频分享/入库平台（如 EMOS）**：统计的是通过 API 或前端直接上传入库的成片视频物理体积（按实际入库文件大小计算）。

### 📊 避坑三：保持分享率（Ratio）与魔力值安全线
* 新手考核结束通常要求 `Ratio ≥ 1.0`（甚至 1.5）。
* 确保上传量大于下载量（例如下载 1.5GB，上传刷到 3GB+），保种时间尽量拉长以积累魔力值。

---

## 3. Linux 无头客户端配置与排障 (qBittorrent / Transmission)

### 3.1 优先推荐：qBittorrent-nox 无头部署、密码 PBKDF2 安全重置与 Web API 控制
`qbittorrent-nox` 在 Linux 环境中对 PT 协议支持极佳，无 resume 文件权限痛点，自带强劲 Web API：

#### ⚠️ 避坑：PT 站点强制拉黑默认端口 6881 (`Port 6881 is blacklisted` / `stalledDL`)
- **故障现象**：种子下发后进度一直卡在 `0.0%`、状态为 `stalledDL`，Seeds 数量为 0。查看 Tracker 列表时，PT 站 Tracker 状态报 `Port 6881 is blacklisted`。
- **根本原因**：NexusPHP 架构的私有 PT 站（如 HDArea、M-Team 等）为防止公网 DHT 泛洪与版权扫描，**在服务端规则中强制拉黑了默认 BT 端口段（6881~6889）**。
- **解决方案**：
  1. 将监听端口改为非标准高端口（推荐 `51413` 或 `49152+`）：
     - `Session\Port=51413`
     - `Connection\PortRangeMin=51413`
  2. ⚠️ **关键注意**：修改 `qBittorrent.conf` 时，**必须先执行 `killall -9 qbittorrent-nox` 确保进程完全退出**后再修改文件；若进程未彻底终止就修改，qBittorrent 退出时会用内存中的旧配置覆写磁盘文件，导致端口修改失效。
  3. 修改后重启并对所有任务触发 `reannounce`（向 Tracker 重新汇报）。

#### ⚠️ 避坑：Ubuntu 24.04 / qBittorrent 4.6+ 默认密码失效 (Invalid Username or Password) 与 API 403 Forbidden 崩溃
现代版 `qbittorrent-nox` 在首次启动时若未在配置中指定密码哈希，**不再默认使用 `adminadmin`**，而是随机生成单次临时密码并在日志中打印，导致直接输入常用密码报 `Invalid Username or Password`。
同时，外部程序（如 Ops Bot）跨机调用 qB WebUI API 若未做会话登录，服务端会直接返回 `403 Forbidden` 纯文本，导致 Python 的 `resp.json()` 抛出 `JSONDecodeError: Expecting value: line 1 column 1 (char 0)`。
**标准修复方案**：
1. 通过 Python 预先计算 PBKDF2 SHA512 哈希写入 `qBittorrent.conf`，或在 WebUI 开启 `AuthSubnetWhitelist=0.0.0.0/0`；
2. API 调用端封装带登录态的 `requests.Session()`（先调用 `/api/v2/auth/login` 保持 Cookie）。

```python
import hashlib, os, base64

password = b'your_secure_password'
salt = os.urandom(16)
dk = hashlib.pbkdf2_hmac('sha512', password, salt, 100000, dklen=64)
pbkdf2_val = f"@ByteArray({base64.b64encode(salt).decode('ascii')}:{base64.b64encode(dk).decode('ascii')})"
print(pbkdf2_val)
```

写入配置文件：
```ini
[Preferences]
WebUI\Username=admin
WebUI\Password_PBKDF2=@ByteArray(salt_b64:hash_b64)
WebUI\CSRFProtection=false
WebUI\Port=8999
```

#### 标准 Systemd 服务常驻模板 (`/etc/systemd/system/qbittorrent.service`)：
```ini
[Unit]
Description=qBittorrent-nox service
After=network.target

[Service]
Type=simple
User=ubuntu
ExecStart=/usr/bin/qbittorrent-nox --webui-port=8999
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
```

```bash
# 1. 安装
sudo apt-get install -y qbittorrent-nox

# 2. 写入免密本地配置（强制关闭公网 DHT/PeX/LSD，防止 DMCA 投诉，仅绑定本地）
mkdir -p /home/ubuntu/.config/qBittorrent /home/ubuntu/pt_downloads
cat << 'EOF' > /home/ubuntu/.config/qBittorrent/qBittorrent.conf
[BitTorrent]
Session\DefaultSavePath=/home/ubuntu/pt_downloads

[LegalNotice]
Accepted=true

[Preferences]
Downloads\SavePath=/home/ubuntu/pt_downloads
WebUI\AuthSubnetWhitelist=0.0.0.0/0,::/0
WebUI\AuthSubnetWhitelistEnabled=true
WebUI\CSRFProtection=false
WebUI\ClickjackingProtection=false
WebUI\HostHeaderValidation=false
WebUI\LocalHostAuth=false
WebUI\Port=8999
WebUI\UseUPnP=false
EOF

# 3. 后台启动
qbittorrent-nox --webui-port=8999

# 4. 通过 Web API 极速管理（注意：qBittorrent 5.x 状态变更指令要求 POST）
# 添加种子文件：
curl -F "torrents=@/path/to/file.torrent" http://127.0.0.1:8999/api/v2/torrents/add

# 查询任务进度、实时上下行速度与状态：
curl -s http://127.0.0.1:8999/api/v2/torrents/info

# 重新向 Tracker 汇报（POST 请求）：
curl -s -X POST "http://127.0.0.1:8999/api/v2/torrents/reannounce" -d "hashes=<torrent_hash>"

# 停止 / 启动 / 删除任务（POST 请求）：
curl -s -X POST "http://127.0.0.1:8999/api/v2/torrents/stop" -d "hashes=<torrent_hash>"
curl -s -X POST "http://127.0.0.1:8999/api/v2/torrents/start" -d "hashes=<torrent_hash>"
curl -s -X POST "http://127.0.0.1:8999/api/v2/torrents/delete" -d "hashes=<torrent_hash>&deleteFiles=true"
```

### 3.2 云服务器（AWS/Oracle/独服）版权与 DMCA 防护原则
* **公网 BT（高危 DMCA 封机） vs 私有 PT（安全）**：
  * **公网公开 BT（严禁）**：海盗湾/公开磁力通过 DHT/PeX 广播，版权机构爬虫会潜伏在公网 Peer 集群中抓取云主机 IP 发送 DMCA 侵权投诉（Abuse Notice），极易封禁实例；
  * **封闭式私有 PT（安全）**：强制关闭 DHT/PeX/LSD，仅通过专属 Passkey 在邀请制会员间点对点握手，外界爬虫无法探测。
* **安全三要素**：
  1. 客户端设置中彻底禁用 DHT、PeX、LSD；
  2. WebUI 严禁直接无密暴露在公网端口（仅绑定 127.0.0.1 或内网安全白名单）；
  3. 任务完成后及时清理不必要的临时数据。

### 3.2 备用：Transmission-daemon 配置与排障
Transmission-daemon 在非 root 或自定义目录运行时，极易因缺省目录报错 `Unable to save resume file: Permission denied`。必须提前建全目录并赋权：

```bash
# 1. 准备配置目录、数据目录与状态恢复目录
mkdir -p /home/ubuntu/.config/transmission-daemon/{resume,torrents,blocklists}
mkdir -p /home/ubuntu/.local/share/transmission/{resume,torrents,blocklists}
mkdir -p /home/ubuntu/pt_downloads
chmod -R 777 /home/ubuntu/.config/transmission-daemon /home/ubuntu/.local/share/transmission /home/ubuntu/pt_downloads

# 2. 启动 daemon（绑定本地 127.0.0.1，免认证 RPC）
transmission-daemon -g /home/ubuntu/.config/transmission-daemon -w /home/ubuntu/pt_downloads --no-auth --allowed "127.0.0.1" -f
```

### 3.3 Tracker 统计周期说明
* PT 站点后台（个人中心）的数据并非毫秒级同步，通常依据客户端与 Tracker 的 Announce 周期（一般为 15 ~ 30 分钟）进行批量更新。做种后需保持在线等待周期结算。

---

## 4. 魔力值（Bonus/Karma）高效获取与核心用途

### 4.1 魔力值计算底层逻辑（NexusPHP 算法）
$$\text{单种魔力收益} \propto \frac{\text{种子体积 (GB)} \times \text{做种存活时间}}{\sqrt{\text{当前做种人数}}}$$

* **核心规律**：做种人数越少，单人收益越高；冷门大种（1~2人做种）的单人魔力产出呈数十倍放大。
* **边际效益递减**：做种体积从 0 到 1TB~2TB 增长最快，超过 10TB 后增速放缓。500GB~2TB 是投入产出比最高的“黄金区间”。

### 4.2 高效赚取魔力值的四大核心策略
1. **专挑冷门少人大种**：按 Seeders 升序排，选 30G~100G 且只有 1~2 人做种的老原盘/剧集包。
2. **多站辅种（一鱼多吃）**：同一份本地 50G 文件，在 5 个 PT 站导入对应 torrent 快速校验，0 额外存储占用赚 5 份站点魔力。
3. **节假日全站 Free 囤种**：在春节、站庆等全站 100% Free 期间，集中拉取合集长期保种，避免下载量扣费。
4. **长期挂机时间加权**：稳定在线超过 30 天/90 天的种子享有更高的系统单价系数。

### 4.3 魔力值的五大核心王牌用途
1. **兑换真实上传量（拉高分享率）**：下载大片后可用魔力值一键兑换 100GB~1TB 上传量，迅速抹平下载扣费。
2. **购买官方邀请码**：站内闭站期间可用魔力值换取官方邀请名额拉好友入坑。
3. **提升会员等级（终身免考核）**：晋升高级会员（Power User 等）的硬性指标，高等级享免除考核特权。
4. **消除 H&R 违规黄牌（洗白卡）**：下完过早关机误触 H&R 时，可用魔力值购买消除警告，防范封号。
5. **账号休眠封存（长期保号）**：外出或长期无法做种时购买封存，防止系统按僵尸号清理。

---

---

## 5. PT 保种设备与存储选型指南

* **硬件要求核心**：低功耗（5W~15W）、大容量机械存储、支持 7×24 小时开机（对 CPU 与内存几乎无要求）。
* **三大推荐方案**：
  * **超低成本挂机流（几百元）**：闲置笔记本 / N100 迷你小主机 + 外接 2T~4T 移动硬盘，整机功耗 6W~12W，月电费 3~5 元。
  * **家庭全能 NAS（1000~2000元）**：4 盘位小主机 / 飞牛私有云（fnOS）+ Emby / MoviePilot + qBittorrent，兼顾全家 4K 观影与保种。
  * **云端全能私有云（独服）**：Hetzner 拍卖机 / 大带宽独服，PVE 划分 LXC 容器挂 qBittorrent，享受 1Gbps 对称上下行千兆做种。

---

## 6. 存储介质与停机断网常见问题

### 6.1 只能用硬盘吗？云盘可以吗？
* **结论**：极度不推荐直接用云盘（Google Drive / 115 / 阿里云盘）挂载做种。
* **原因**：
  1. **高并发微碎片引发 API 封号/风控（429 Too Many Requests）**：PT 做种向多 Peer 发包时瞬间发起成百上千次随机寻道，极易触发网盘每日配额或直接封禁 API 24 小时。
  2. **网络 I/O 延迟过高**：远高于本地硬盘 1ms 响应，导致 Peer 超时断开、qBittorrent 报错停止。
* **正确分工**：物理硬盘/云主机负责做种赚分，网盘负责冷备份与随身流媒体播放。

### 6.2 关机断网、电脑重启或删除资源会有什么后果？
1. **未下载完关机/重启（断点续传机制）**：
   * **完全无害**：BT/PT 采用分块哈希校验（Piece 校验），已下载部分完好保留在硬盘，重新开机打开软件后**自动断点续传**，绝对不从 0% 重新开始；
   * 若遇异常断电报错，在 qBittorrent 中右键点击种子选择 **“强制校验（Recheck）”** 即可快速扫描修复。
2. **做种期间关机断网**：
   * **收益暂停**：停机期间仅停止计算新魔力值和上传量，**以前赚到的积分和上传量永远保留、绝不倒扣**；
   * 重新开机联网打开软件自动恢复做种计时；
   * **防封底线**：各大 PT 站通常有“连续 30~60 天既不登录网页也不做种则自动封禁”的休眠规则，每隔 2~3 周手机/电脑登录一次即可永久防封。
3. **删除资源**：
   * 已经上传并记录的流量不会被扣回；但删除后无法再继续为该资源做种；
   * **H&R 规则**：下载未完成（0%）或无 H&R 标识的普通种子可随时安全删除；若有 ⏱️ 标识，需保种满 24~72 小时或 Ratio ≥ 1.0 后再删。
4. **极简常驻保号法**：
   * 在本地或服务器常驻保留 1~2 个体积仅 1GB~2GB 的小体积剧集/电影种子（如 1080p 单集），开机自动连上，零空间占用且永保账号活跃。

### 6.3 个人电脑/笔记本本地客户端配置标准
* **官网国内访问障碍**：`qbittorrent.org` 与海外源国内常有 DNS 阻断，建议提供离线 Windows/Mac 预下载安装包。
* **本地必做隐私设置**（`工具 -> 选项 -> BitTorrent`）：
  * ❌ 取消勾选 `启用 DHT (去中心化网络)`
  * ❌ 取消勾选 `启用用户交换 (PeX)`
  * ❌ 取消勾选 `启用本地用户发现 (LSD)`
  * 🔒 勾选 `加密模式: 优先加密 (Prefer encryption)`
* **网盘与做种的物理隔离**：存入 Google Drive / 光鸭盘等云盘的文件属于个人冷备份，不参与 P2P 广播；只有放入本地客户端并加载 `.torrent` 的文件才处于做种状态。

---

## 7. 视频分享与积分站点自动化接入
对于通过上传视频获取积分的平台（如 EMOS 等），支持基于 Telegram 运维 Bot 的“接收种子 -> 本地快下 -> 正则重命名 -> Google Drive 同步 -> API 上传赚积分”全自动工作流。
* 详细鉴权（Token vs OAuth）、大文件分块上传与管道设计请参阅：[references/video-reward-sites-automation.md](references/video-reward-sites-automation.md)。

