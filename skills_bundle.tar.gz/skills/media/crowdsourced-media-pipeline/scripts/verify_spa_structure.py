#!/usr/bin/env python3
"""
单文件 Vue SPA 结构静态校验器。

为什么需要它：在 index.html 里插入新 Tab 面板时，极易把新面板的开标签
插到旧面板的开标签之后，导致某个 <div v-if="..."> 的开标签留在了错误的
父级里。这类错误 diff 看起来完全正常、单测也覆盖不到，只有渲染时才暴露。
"肉眼审 diff 通过"不算验证。

用法:
    python3 verify_spa_structure.py frontend/index.html \
        [--require-export searchError --require-export handleTgBind]

退出码 0 = 全部通过；非 0 = 有问题，输出里会指出行号。
"""
import argparse
import html.parser
import re
import sys


VOID_TAGS = {
    "area", "base", "br", "col", "embed", "hr", "img", "input", "link",
    "meta", "param", "source", "track", "wbr",
}


class TagBalanceChecker(html.parser.HTMLParser):
    """标签配平检查：报告错配与未闭合，并尽力恢复以便一次跑出多个问题。"""

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.stack = []
        self.errors = []

    def handle_starttag(self, tag, attrs):
        if tag not in VOID_TAGS:
            self.stack.append((tag, self.getpos()))

    def handle_startendtag(self, tag, attrs):
        pass  # 自闭合，不入栈

    def handle_endtag(self, tag):
        if tag in VOID_TAGS:
            return
        if not self.stack:
            self.errors.append(f"多余的 </{tag}> at {self.getpos()}")
            return
        top, pos = self.stack[-1]
        if top == tag:
            self.stack.pop()
            return
        self.errors.append(
            f"标签不匹配: 期望 </{top}> (开于 {pos})，实际 </{tag}> at {self.getpos()}"
        )
        # 恢复：向下找到最近的同名开标签并丢弃其上的所有层级
        for i in range(len(self.stack) - 1, -1, -1):
            if self.stack[i][0] == tag:
                del self.stack[i:]
                break


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("path")
    ap.add_argument(
        "--require-export",
        action="append",
        default=[],
        help="必须出现在 setup() return {} 中的标识符，可重复传",
    )
    ap.add_argument(
        "--tab-pattern",
        default=r"currentTab === '([A-Za-z0-9_]+)'",
        help="模板中 Tab 面板条件渲染的正则（默认匹配 currentTab === 'x'）",
    )
    ap.add_argument(
        "--nav-pattern",
        default=r"id:\s*'([A-Za-z0-9_]+)',\s*name:",
        help="导航数组中 Tab 声明的正则",
    )
    args = ap.parse_args()

    src = open(args.path, encoding="utf-8").read()
    failures = []

    # ---- 1. 标签配平 ----
    checker = TagBalanceChecker()
    checker.feed(src)
    print("=== HTML 标签配平 ===")
    if checker.errors:
        for e in checker.errors[:20]:
            print(f"  FAIL {e}")
        failures.extend(checker.errors)
    else:
        print("  OK 无标签错配")
    if checker.stack:
        msg = f"未闭合标签: {checker.stack}"
        print(f"  FAIL {msg}")
        failures.append(msg)
    else:
        print("  OK 所有标签均已闭合")

    # ---- 2. Tab 声明 vs 面板渲染 一一对应 ----
    declared = set(re.findall(args.nav_pattern, src))
    rendered = set(re.findall(args.tab_pattern, src))
    print("\n=== Tab 一致性 ===")
    print(f"  导航声明: {sorted(declared)}")
    print(f"  模板渲染: {sorted(rendered)}")
    missing = declared - rendered
    orphan = rendered - declared
    if missing:
        print(f"  FAIL 声明了但没有对应面板: {sorted(missing)}")
        failures.append(f"tab missing panel: {sorted(missing)}")
    if orphan:
        # 首页这类默认面板可能不在导航里，降级为警告
        print(f"  WARN 有面板但未在导航声明（确认是否为默认面板）: {sorted(orphan)}")
    if not missing:
        print("  OK 每个声明的 Tab 都有对应面板")

    # ---- 3. setup() 导出完整性 ----
    if args.require_export:
        print("\n=== setup() 导出检查 ===")
        try:
            ret_block = src[src.rindex("return {"):]
        except ValueError:
            print("  FAIL 未找到 setup() 的 return {} 块")
            failures.append("no setup return block")
            ret_block = ""
        for name in args.require_export:
            ok = re.search(rf"^\s+{re.escape(name)},\s*$", ret_block, re.M) is not None
            print(f"  {'OK' if ok else 'FAIL'} {name}")
            if not ok:
                # 漏掉导出不会抛错，只是模板里静默失效 —— 最阴的一类 bug
                failures.append(f"not exported from setup(): {name}")

    print()
    if failures:
        print(f"结论: {len(failures)} 项问题，请修复后重跑")
        return 1
    print("结论: 全部通过")
    return 0


if __name__ == "__main__":
    sys.exit(main())
