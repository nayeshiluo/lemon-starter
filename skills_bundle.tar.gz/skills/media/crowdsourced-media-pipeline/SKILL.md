---
name: crowdsourced-media-pipeline
description: Use when building crowdsourced media ingestion systems.
version: 1.0.0
author: Lemon
license: MIT
metadata:
  hermes:
    tags: [media, emby, tmdb, pipeline, qbittorrent, ffprobe, deduplication, points-economy]
    related_skills: [emby-proxy-ops, pt-site-ops, telegram-media-harvester]
---

# 影视众包入库与查重流水线架构规范 (Crowdsourced Media Pipeline)

## When to Use
- 构建或重构基于 Emby / Jellyfin / TMDB 的影视众包入库、任务分发与查重系统；
- 需要在数据库层解决电影（NULL 季集）与剧集多集并发防重复入库冲突；
- 设计基于 qBittorrent 离线下载、FFprobe 视频质检与媒体库自动挂载的状态机；
- 设计高并发防双花、只增 Append-Only 的积分/代币原子流水总账与缺集悬赏池。

---

## 核心架构设计法则

### 1. 数据库决定最终唯一性 (Database-Level Anti-Duplicate)
- **拒绝单纯依赖应用层内存锁或 Python if**：必须通过数据库 Partial Unique Index 作为防并发抢单与重复入库的最终防线。
- **任务主体并发防重**：`media_tasks` 必须具备 `UNIQUE(tmdb_id, media_type)`，杜绝并发生成 Task 100 和 Task 101 绕过电影单次 Accepted 约束。
- **PostgreSQL / SQLite 电影与剧集防重索引**：
  ```sql
  -- 任务主体：同一 TMDB 作品 + 媒体类型 必须全局唯一
  ALTER TABLE media_tasks ADD CONSTRAINT uq_media_task_tmdb_type UNIQUE (tmdb_id, media_type);

  -- 电影：同一任务只能存在一个 ACCEPTED 条目 (规避 PostgreSQL NULL != NULL 问题)
  CREATE UNIQUE INDEX uq_accepted_movie_item 
  ON submission_items(task_id) 
  WHERE status = 'accepted' AND media_type = 'movie';

  -- 剧集：同一 task_id + season + episode 只能存在一个 ACCEPTED 条目
  CREATE UNIQUE INDEX uq_accepted_episode_item 
  ON submission_items(task_id, season, episode) 
  WHERE status = 'accepted' AND media_type != 'movie';
  ```

---

### 2. 状态机严格生命周期 (State Machine Lifecycle)
流水线必须保证单向幂等状态推进：
`PENDING` → `RESERVED` → `DOWNLOADING` → `INSPECTING` → `DELIVERING` → `WAITING_EMBY` → `ACCEPTED`
- **RESERVED**：带有 TTL（例如 2 小时）的任务抢占锁定；
- **DOWNLOADING**：基于真实下载增量与时间戳判断死种熔断，而非依赖轮询 tick 计数；
- **INSPECTING**：自动过滤 `sample/trailer/featurette`，通过 FFprobe 提取真实时长、分辨率、视频流编码与 4K 标志，硬性拦截 `<30s` 假视频骗分；
- **DELIVERING**：优先 Hardlink（自动检查源与目标是否在同一文件系统设备 `st_dev`，跨文件系统平滑降级为 Copy）；
- **WAITING_EMBY**：触发 Emby 媒体库扫描并轮询对账，**只有在 Emby 真实发现目标 TMDB 与季集后，才转为 ACCEPTED**；
- **ACCEPTED**：此时方可触发积分与悬赏结算。

---

### 3. 积分与经济总账强幂等性与零初始余额 (Idempotent Points Ledger & Zero Initial Balance)
- **User.balance 初始必须为 0**：禁止在 User 表默认值或 ORM 构造中预设 `balance=100`。新用户的初始代币、每日签到、投稿奖励必须 100% 严格委托 `PointsService.add_points()` 生成唯一流水，**杜绝在业务代码中额外执行 `user.balance += X` 导致账实不符与双发错账**；
- **Append-Only 只增流水账本**：禁止任何绕过账本直接修改余额的操作；
- **强幂等唯一键**：每一笔加币记录携带 `idempotency_key`（例如 `reward_subitem_{item_id}`），通过唯一索引拦截任何网络重试与 worker 崩溃重跑；
- **并发扣币安全**：使用 `SELECT ... FOR UPDATE` 行级锁确保余额不为负。

---

### 4. 业务逻辑归一化与统一领域服务 (Unified Domain Service)
- **Web API 与 Telegram Bot 必须共用统一的 `SubmissionService`**：严禁 Bot 单独写一套硬编码 `tmdb_id=0` 的粗糙投稿逻辑。Bot 的 `/upload` 必须与 Web 走相同的 TMDB 刮削、Redis 锁预抢占与状态机；
- **Redis 生产严格 Fail-Closed**：在生产环境中，若配置要求 Redis，当 Redis 掉线或加锁异常时，锁获取必须严格返回 `False`，接口直接返回 `503 / 409` 阻断提交，严禁降级放行导致重复离线下载上百 G 大文件。

---

### 5. 悬赏精准匹配与 Escrow 冻结
- **严格匹配元组**：`(tmdb_id, media_type, season, episode)`，严禁仅按 `tmdb_id` 模糊匹配，防止多集剧集串单结算；
- **真实押金冻结**：发布悬赏时立即扣除押金；完工时转给投稿人，取消时原路退回。

---

### 5. 缺集计算与多季区间压缩算法 (Multi-Season Missing Engine)
严禁将所有季度的集数压平计算（避免 S01E01 与 S02E01 混淆），必须以 Season 字典为单位计算：
```python
def calculate_multi_season_missing(season_defs: dict[int, int], accepted_tuples: list[tuple[int, int]]):
    # season_defs: {1: 12, 2: 24}
    # accepted_tuples: [(1, 1), (1, 2), (2, 1)]
    # 输出格式化标准区间: "S01E03-E12、S02E02-E24"
```

- **生产级核对清单**：详细交付验收与测试步骤请参考 [references/production-checklist.md](references/production-checklist.md)。

---

## 避坑指南与生产级防线 (Critical Pitfalls & Traps)

1. **新旧双轨未接通陷阱 (Dual-Track Architecture Trap)**：
   - 重构时切勿只新建 `services/` 或 `models/` 而忘记切断旧的 `main.py`、`routes/` 与 `pipeline.py`。
   - 彻底删除废弃的旧单文件，并在 CI/测试中必须加入 `from backend.main import app` 与 `/api/health` 的完整启动 Smoke Test。
2. **Alembic 容器启动接管与索引漂移 (Alembic Startup Takeover)**：
   - 生产环境中必须由容器入口 `entrypoint.sh` 执行 `alembic upgrade head`，生产代码彻底移除隐式 `create_all()`。
   - 必须确保 Alembic Migration 脚本中显式包含全部 Partial Unique Indexes，运行 `alembic check` 验证零偏差。
3. **集数解析盲区误判 (Episode Mapping Fallback Risk)**：
   - 剧集多文件解析时，若无法从文件名提取集数，**必须标记 `REJECTED_NEEDS_EPISODE_MAPPING` 拦截**，绝不可无脑默认反推为 `S01E01`。
4. **TMDB 请求失败严禁伪造假元数据**：
   - 当 TMDB 临时超时或未命中时，必须 Fail-Closed 阻断任务，严禁默认创建 `total_items_count=1` 的单集假任务。
5. **交付失败与 WAITING_EMBY 严格隔离 (Delivery Failure Isolation)**：
   - 只有物理落盘成功且处于 `waiting_emby` 的条目才允许向 Emby 对账；若条目 `failed/rejected`，即使 Emby 历史库内恰好已存在同名资源，也绝对不可复活或触发发币。
6. **宿主机 vs 容器内部路径隔离与 qB 强制 save_path (Host vs Container Path Mapping & Forced save_path)**：
   - 配置与 Compose 必须区分 `HOST_*`（宿主机挂载点）与 `CONTAINER_*`（程序内部读取路径），防止换路径部署后 `os.path.exists()` 误报文件丢失。
   - 调用 qB WebAPI 添加种子时必须显式传参 `save_path=CONTAINER_DOWNLOAD_PATH`，杜绝依赖 qB 默认分类目录导致的文件落地漂移。
7. **真实就绪度探针与生产安全 Fail-Closed (True Readiness Probe & Security Fail-Closed)**：
   - `/api/health/ready` 必须执行真实数据库 `SELECT 1` 与 Redis PING 探测，数据库异常时严格返回 `503 Service Unavailable`。
   - `APP_ENV=production` 时，只要 `SECRET_KEY` 为空或使用示例占位符，必须无条件抛出异常拒绝启动。
8. **Redis 分布式锁 + 任务预抢占前置阻断 (Pre-Download Concurrency Guard)**：
   - 在将磁力提交至下载器之前，必须先获取 `submit_lock:{tmdb_id}:{media_type}` 并校验任务是否已存在/正在下载。若已有活跃任务，立即返回 HTTP 409 拦截，杜绝多用户并发下载重复百 G 大文件造成带宽与磁盘极大浪费。
10. **SKIP 冲突策略防冒领发币 (SKIP Conflict & Anti-Exploit Guard)**：
    - 当目标目录已存在历史异源文件且配置为 `SKIP` 时，**交付适配器必须返回 `success=False`**，条目直接标记 `failed`，绝不进入 `waiting_emby`。严禁返回 `success=True` 导致历史已有资源被 Emby 扫描后误发币（冒领刷币漏洞）。
11. **同种内同集多画质择优去重 (Intra-Torrent Episode Resolution Deduplication)**：
    - 当一个种子内意外包含同一单集的不同分辨率文件（如 1080p 与 720p）时，质检阶段必须按 `(season, episode)` 进行聚合，优先保留 `4K / 1080p + 最大体积` 的最佳文件，防止同一任务内部产生自碰撞死锁。
12. **前端分页契约与接口错位对齐 (Frontend Pagination & Method Contract)**：
    - 后端统一分页化返回 `{items: [...], total: N}` 后，前端必须解构为 `data.items || []`，禁止直接将分页对象赋值给列表；
    - 确保前端“我的任务/历史”调用正确的 GET 路由（如 `/api/submissions/my`），杜绝误调 POST 投稿端点。
13. **Telegram Bot 回调与悬赏押金退款闭环 (Bot Callbacks & Escrow Refund)**：
    - Bot 必须显式注册 `CallbackQueryHandler` 处理全部 Inline Keyboard 按钮，避免点击无响应；
    - 真实 Escrow 冻结的悬赏必须提供明确的取消与全额退款流（`bounty_refund`），防止用户代币被死锁。
14. **指定单集严格过滤收口 (Target Episode Inspection Filter)**：
    - 当用户指定单集（如 S01E07）投稿时，质检阶段在多文件扫描后必须强行过滤为 `candidates_by_episode = {target_key: candidates[target_key]}`，只为目标单集生成条目并交付发币，**绝对禁止将种子大包中未预占的其他集数顺带入库发币**。
15. **SAVEPOINT 局部事务隔离防护 (Savepoint Isolation in Batch Acceptance)**：
    - 在多集逐项推进 `accepted` 状态时，必须采用 `async with db.begin_nested():` 隔离单项并发 Partial Unique 冲突；
    - 遭遇并发唯一冲突时，只局部回滚该项为 `rejected`（记录 `DUPLICATE_AFTER_DOWNLOAD`），**严禁调用全局 `session.rollback()` 导致同一批次前置已确认单集及其 PointsLedger 流水被连带回滚**。
16. **失败重试物理清理旧执行态与预估/实发奖励解耦 (Clean Execution State on Failed Retries & Reward Decoupling)**：
    - 预估奖励 `estimated_reward_points`（用于展示）与实发奖励 `reward_points`（初始为 0，发币后才累加）必须严格解耦；
    - 复用 `failed/rejected` 历史 Submission 重试时，校验 `reward_points == 0`，并必须物理删除旧 `SubmissionItem` 与重置 `DownloadJob`，杜绝新老批次脏数据叠加。
17. **终态异常即时释放 TaskItem 预占 (Instant Reservation Release on Terminal Failures)**：
    - 遭遇任何终态失败（TMDB 失败、死种、qB 致命错误、质检不符、交付落盘失败、Emby 超时）时，必须即时将目标 `TaskItem` 恢复为 `missing`，无需等待 2 小时 TTL 超时。
18. **Alembic 迁移历史不可变增量版本链 (Immutable Alembic Migration Chain)**：
    - 严禁重写/覆盖 Base Migration！一旦数据库已有部署，后续表结构调整必须通过 `alembic revision --autogenerate` 生成增量 Revision 文件，并带 `alembic check` 验证零偏差，确保老版本数据库执行 `alembic upgrade head` 能平滑无损升级。
19. **公共投稿广场脱敏防泄露 (Public Feed Desensitization)**：
    - 全站公共接口（如 `GET /api/submissions/all`）必须采用专用的 `PublicSubmissionResponse`，**物理剔除 `magnet_uri`, `torrent_hash`, `source_file`, `dest_file`, `error_message`**，防止普通用户抓包盗取其他用户贡献的私密磁力资源。
20. **剧集强校验禁止假全季绕过预占 (Strict Episodic Target Validation)**：
    - 剧集/动漫/综艺投稿在 Schema 校验层必须强制要求 `season >= 0` 与 `episode >= 1`，禁止 `episode=NULL` 假全季整包模式绕过单集预抢占与活跃唯一索引保护。
21. **Emby 最终对账增加 `expected_dest_path` 物理路径严格比对 (Physical File Path Verification)**：
    - 在对账验证时不仅比对 TMDB ID 与季集序号，更进一步比对 Emby 刮削到的文件真实路径/基准名是否等于本次交付落盘的 `expected_dest_path`，从根本上证明确认的是“本次投稿交付的物理文件”，杜绝库中偶然存在的同名旧资源冒领发币。
22. **Alembic 历史数据平滑增量升级三步法 (Safe Incremental Migration Pattern)**：
    - 在已有海量数据的生产表上添加新字段时，严禁直接 `nullable=False`（无默认值会导致升级直接报错中断）；
    - 必须采用安全三步变更：`op.add_column(nullable=True, server_default='0')` → `op.execute(UPDATE existing ...)` → `op.alter_column(nullable=False)`。
23. **统一规范 Canonical TMDB 媒体身份防重 (Canonical TMDB Media Identity)**：
    - 针对 `tv` / `anime` / `variety` 等 TMDB 统一归属于 Series 的剧集类型，任务主体防重必须强制规范化为统一的 `canonical_media_type="tv"`，`category` 仅作为业务分类属性，防止通过切换 `anime/variety` 生成多个独立 Task 绕过防重。
24. **悬赏取消与入库结算悲观行锁互斥 (Pessimistic Locking on Escrow Operations)**：
    - 在悬赏取消退款（`bounty_refund`）与入库发赏（`bounty_claim`）两个并发链路中，对目标 `WantedTask` 必须执行 `SELECT ... FOR UPDATE` 悲观行锁，并在锁内二次校验 `status == 'open'`，防止同一笔押金在并发竞态下发生双重支付。
25. **磁力 Base32 BTIH 自动规范化与种子丢失恢复 (BTIH Normalization & Torrent Recovery)**：
    - 磁力解析时必须将 32 位 Base32 BTIH 统一解码并转换为标准 40 位 Hex 小写，保证数据库防重与下载器索引一致；
    - 下载状态机中若遭遇 qB 种子任务意外丢失超过 3 分钟自动触发重推，超过 10 分钟持续丢失则熔断为 `FAILED_QB_MISSING` 并即时释放锁定的 `TaskItem`。
26. **未实现交付适配器严格 Fail-Closed (Delivery Adapter Fail-Closed)**：
    - 交付工厂方法（如 `get_delivery_adapter()`）在检测到非 `local` 且未实现的适配器配置时（如 `DELIVERY_ADAPTER=guangya`），**必须抛出 `NotImplementedError` 并在启动阶段拒绝服务**，严禁静默偷跑本地落盘假装成功。
27. **失败重试时同步更新 TMDB 身份 (Sync Identity on Failed Retries)**：
    - 当用户对此前失败的任务修正 TMDB ID 并重试时，除了更新 `task_id` 外，必须显式同步更新 `Submission.tmdb_id` 与 `Submission.media_type`，杜绝后续 Delivery 命名与 Emby 对账时 Task 与 Submission 内部身份错位。
28. **悬赏创建必须强制保存 Canonical Media Type (Canonical Type on Bounty Creation)**：
    - 悬赏创建入口必须将 `media_type` 统一转为规范类型（如 `anime/variety -> tv`）持久化至 `WantedTask`，确保后续入库结算时 `exact_bounties` 能够精准匹配。

