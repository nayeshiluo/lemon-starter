---
name: crowdsourced-media-pipeline
description: Use when building crowdsourced media ingestion systems.
version: 1.0.0
author: Lemon
license: MIT
metadata:
  hermes:
    tags: [media, emby, tmdb, pipeline, qbittorrent, ffprobe, deduplication, points-economy]
    related_skills: [emby-proxy-ops, pt-site-ops, telegram-media-harvester]
---

# 影视众包入库与查重流水线架构规范 (Crowdsourced Media Pipeline)

## 爬虫与双轨转存链路六大隐性故障（2026-09-04 ~ 2026-09-14 实测）

### 1. 命名引擎版本脱钩（最危险）

同一份 `smart_media_parser.py` / `tmdb_helper.py` 被 **两个项目各存一份**（`lemon-ops-bot/` 与 `lemon-media-spider/`）。运维 Bot 那边修了 4 个 bug，爬虫这边还是旧版 —— md5 完全不同：

```
爬虫  smart_media_parser 5c5ed09e  tmdb_helper 717db392   ← 旧版
Bot   smart_media_parser cc3a7002  tmdb_helper 8ad449d8   ← 已修
```

爬虫侧旧 `tmdb_helper` 还带着已知失效的 `search/multi?&year=` 写法（TMDB 对 multi 端点不支持 year，会静默返回错误结果）。

**铁律**：命名引擎必须单一真源。改完一边立刻 `cp` 到另一边并 `md5sum` 三方对齐（本地 Bot / 本地爬虫 / VPS）。

### 2. 报告宣称的能力实际不存在

每日汇报里写「光鸭云盘：TMDB 规范化 + 全盘广告粉碎完毕」，但 `grep -rln "api.themoviedb.org" *.py` 只命中 `tmdb_helper.py` 自己 —— **全仓库无任何地方 import 它**，那句话是纯文案。实际只有 `clean_video_or_folder_name()` 做去广告前缀正则清洗。

排查手法：不要相信报告文案，直接 grep 外部 API 域名，再 grep 谁 import 了那个 helper。孤岛模块（无人调用）是这类假象的标志。

接上时必须设两条安全边界：
- **专区白名单**：只对常规影视（电影/剧集/动漫）做 TMDB 规范化。成人/里番/短剧的片名 TMDB 查不到，强行套用会被模糊匹配污染成无关作品。
- **未命中即不改**：TMDB 无结果或相关性不足时返回 `None`，保留去广告后的原名。宁可不改，绝不改错。

### 3. `dict.get(key, root_id)` 兜底污染云盘根目录

```python
# ❌ 原实现：任何非法 categories 都静默落进根目录
fid = folder_ids.get(cat_key, folder_ids.get('root'))

# ✅ 改为硬校验 + 拒绝下发
if cat_key not in set(FOLDER_MAP.keys()):
    logger.warning(f"[!] 跳过 id={res_id}：非法分类 {cat_key!r}，拒绝下发")
    continue
```

实测 38 条记录的 `categories` 被写成了豆瓣类型串（`中国大陆,剧情,汉语普通话`）甚至剧名本身（`紫罗兰永恒花园`）—— 爬虫早期把 `category_type` 字段搞错了。这些全部 `pushed_to_guangya=1`，即都曾按 root 下发过。

**这类 bug 完全静默**：不报错、不进日志，只能靠主动对账发现。配套脚本 `audit_categories.py`（只读审计 + `--fix` 带二次确认修正，按 channel→分类映射反推）。

### 4. 双轨/多目标转存串联木桶效应（次要通道暴毙拖死主通道）

- **现象**：影视/短剧/里番等视频双轨转存长时间断更，但定时通知仍报 OK、私有中转频道也持续有转发消息。
- **根因**：Worker 将多个云盘上传串联在同一个 `try` 块内（`下载 -> 上传 GDrive -> 上传光鸭 -> 入库标记`）。
  Google Drive OAuth Token 在测试模式（Testing）下只有 7 天有效寿命（`refresh_token_expires_in: 604799`），到期报 `invalid_grant: Token has been expired or revoked.`。该异常直接腰斩了后续光鸭云盘的上传与数据库入库标记，导致后续全部消息被堵死，反复重试。
- **排查手法**：
  1. 检查 Worker 同步数据库最大处理 ID（`SELECT max(msg_id) FROM vps_sync_records`）与源频道/中转频道最新消息 ID 比对；
  2. 检查系统日志（`journalctl -u ...`）是否有特定云盘鉴权失效的循环报错。
- **架构防线**：多端/双轨转存必须**完全解耦（Decoupled Fallback）**。
  - 各云盘的上传用独立的 `try...except` 包裹；
  - 数据库记录细化各通道状态（如 `gdrive_status`, `guangya_status`）；
  - 主通道成功即可推进标记并记录对应文件 ID，绝不让次要通道的短期 Token 过期阻断核心业务；
  - Google OAuth 用于生产服务必须发布为 Production 或采用服务账号（Service Account），杜绝 7 天强制过期。

### 5. Telegram 媒体下载无超时死锁挂起（Daemon 假活）

- **现象**：Worker 服务状态为 `active (running)`，无 OOM，但整整数天不再输出正常的轮询入库日志，整条管线停摆。
- **根因**：Telethon 的 `client.download_media()` 在跨 Telegram DC（Data Center）拉取大文件或遭遇网络抖动时，若未显式包裹超时，底层 socket 偶发死锁无限挂起（Hang 住），既不退出也不抛出异常。
- **排查手法**：
  1. `lsof -p <PID>` 检查打开的 FD：若发现有写模式（`w`）的临时媒体文件大小长期停在 0 或固定值，即证实死锁在下载 IO；
  2. 比对日志时间戳：只有 Telethon 内部心跳（如 `Got difference for channel ... updates`），无任何应用层巡检日志。
- **架构防线**：
  - 强制超时熔断：`await asyncio.wait_for(client.download_media(...), timeout=300)`；
  - 临时文件清理保证：`finally` 块必须清理 0 字节与未完成的临时文件；
  - 进程健康心跳（Watchdog）：主循环写入更新戳，看门狗超时自动重启。

## 去重机制（三层，实测健康）

| 层 | 机制 | 水位 |
|---|---|---|
| 磁力 | `resources.magnet_hash` UNIQUE 约束 | 8791 行 / 8791 唯一，重复 0 |
| TG 视频转存 | `is_already_transferred(conn, channel, msg_id)` 前置检查 | 448 条 `tg_` 前缀记录 |
| 零流量秒转 | `tg_forward_records` 三元组 `(source_channel, msg_id, dest_target)` + `INSERT OR IGNORE` | 416 行 |

回溯游标存在 `sync_cursors.oldest_synced_id`（12 个频道），支持 18+ 专区的历史库存持续深挖。

## 多目标 Worker 恢复、补传与分类纠偏

长链路媒体同步必须先压缩上下文并建立可恢复基线：记录源频道、目标目录、数据库水位、真实视频数（与海报/说明消息分开）、服务进程、已知错误和备份哈希。变更前备份 Worker、数据库、Telegram session 与云盘凭证；未完成最终对账不得宣称全部完成。

双轨上传必须目标级解耦：各目标独立状态、文件 ID、错误和重试次数；主补传队列只按主目标未成功筛选，已成功目标不得因另一目标失败而重复下载。下载和每个上传都必须设置硬超时，`systemd active` 必须结合应用日志、数据库水位、PID/WCHAN、`lsof` 与缓存目录判断业务健康。固定最新 N 条不能作为唯一扫描策略，应使用分页/游标回溯。

文件名处理必须优先使用媒体自身文件名；缺失时才使用同一 forward 来源的上下文。先删除 Markdown 链接、URL、推广文本和非法路径字符，再追加稳定消息 ID；最终名称按 UTF-8 字节限制，不按字符数限制。测试长中文、空 caption、重复标题和 0 字节半成品。

分类纠偏坚持证据优先：原始 forward 来源 + caption/同来源上下文 + 云盘现有文件名三重核对；混发频道不得全量搬迁，只移动明确项。云盘移动后按稳定 file ID 回读验证，并按消息 ID 精确更新数据库，禁止按重复文件名批量 UPDATE。详细步骤与验收条件见 `references/media-worker-recovery-checklist.md`。

OAuth Playground 授权时，Desktop 客户端没有重定向 URI字段；需要 Web application 客户端并精确添加 `https://developers.google.com/oauthplayground`。仅有回调 `code` 不算完成，必须兑换后看到 HTTP 200 和 access/refresh token。新 Token 必须与新 Client ID/Secret 成对部署：先验证 Drive `about`、目标目录权限和小文件上传，再启动补偿队列。敏感凭证不进聊天，优先由用户以权限 600 的文件直接放服务器；Testing 同意屏幕可能导致 7 天失效，应按 Google 要求发布 Production。

复杂远程修复遵守“一次只做一步、先执行并回读真实结果再继续”；发现补丁回归立即停批并清理半成品。最终报告明确区分已完成、进行中和阻塞，不以服务 active 或单次 API success 冒充全链路完成。

## 媒体流水线运维汇报与执行纪律（新增）

### 慢速、可观测、可恢复
- Telegram 爬取、下载、上传必须采用慢速拟人化节奏；不要为了追赶积压而并发猛跑。每条任务都必须有超时、重试上限、退避和临时文件清理。
- **任何异常必须主动报告**：禁止只汇报 `systemd active` 或“任务完成”。至少区分：源头无新内容、抓取失败、数据库入库失败、云盘下发失败、下载/上传超时、认证失效、积压数量。
- 多目标同步必须按目标独立记录状态；主通道成功不应被次通道失败阻塞，次通道恢复后走补偿队列。
- 报告默认只给重点：各类新增/成功/失败/积压、首要异常、是否需要用户操作；详细日志和逐频道明细只在用户要求或出现异常时展开。

### 常规影视“无更新”必须三方核验
判断电影/剧集/动漫是否断更，必须同时检查：
1. 源频道实时抓取数量与去重后新增数量；
2. 本地数据库按分类的最新 `created_at` 与新增记录；
3. 云盘对应目录的最新文件时间/数量，以及定时调度和日志最近运行时间。

三方结果要明确区分：源头没新、源头有但已重复、抓取异常、入库异常、云盘下发异常。不能用“进程在线”替代业务验收。

### GDrive OAuth 恢复纪律
- OAuth Playground 换取新凭证后，先用新 Client ID/Secret + Refresh Token 调 token endpoint，再调用 Drive `about` 验证账号和权限，最后做小文件上传并删除测试文件。
- 新客户端若为 Web 类型，回调 URI 必须逐字匹配 `https://developers.google.com/oauthplayground`；Testing 状态可能导致 Refresh Token 约 7 天失效，生产长期运行应改 Production 或采用长期凭证方案。
- 凭证不得在报告或群聊中回显；部署前备份旧凭证并设置 `chmod 600`。

详细的双轨恢复与常规影视核验记录见 [references/media-sync-ops-runbook.md](references/media-sync-ops-runbook.md)。

## When to Use
- 构建或重构基于 Emby / Jellyfin / TMDB 的影视众包入库、任务分发与查重系统；
- 需要在数据库层解决电影（NULL 季集）与剧集多集并发防重复入库冲突；
- 设计基于 qBittorrent 离线下载、FFprobe 视频质检与媒体库自动挂载的状态机；
- 设计高并发防双花、只增 Append-Only 的积分/代币原子流水总账与缺集悬赏池。

---

## 核心架构设计法则

### 1. 数据库决定最终唯一性 (Database-Level Anti-Duplicate)
- **拒绝单纯依赖应用层内存锁或 Python if**：必须通过数据库 Partial Unique Index 作为防并发抢单与重复入库的最终防线。
- **任务主体并发防重**：`media_tasks` 必须具备 `UNIQUE(tmdb_id, media_type)`，杜绝并发生成 Task 100 和 Task 101 绕过电影单次 Accepted 约束。
- **PostgreSQL / SQLite 电影与剧集防重索引**：
  ```sql
  -- 任务主体：同一 TMDB 作品 + 媒体类型 必须全局唯一
  ALTER TABLE media_tasks ADD CONSTRAINT uq_media_task_tmdb_type UNIQUE (tmdb_id, media_type);

  -- 电影：同一任务只能存在一个 ACCEPTED 条目 (规避 PostgreSQL NULL != NULL 问题)
  CREATE UNIQUE INDEX uq_accepted_movie_item 
  ON submission_items(task_id) 
  WHERE status = 'accepted' AND media_type = 'movie';

  -- 剧集：同一 task_id + season + episode 只能存在一个 ACCEPTED 条目
  CREATE UNIQUE INDEX uq_accepted_episode_item 
  ON submission_items(task_id, season, episode) 
  WHERE status = 'accepted' AND media_type != 'movie';
  ```

---

### 2. 状态机严格生命周期 (State Machine Lifecycle)
流水线必须保证单向幂等状态推进：
`PENDING` → `RESERVED` → `DOWNLOADING` → `INSPECTING` → `DELIVERING` → `WAITING_EMBY` → `ACCEPTED`
- **RESERVED**：带有 TTL（例如 2 小时）的任务抢占锁定；
- **DOWNLOADING**：基于真实下载增量与时间戳判断死种熔断，而非依赖轮询 tick 计数；
- **INSPECTING**：自动过滤 `sample/trailer/featurette`，通过 FFprobe 提取真实时长、分辨率、视频流编码与 4K 标志，硬性拦截 `<30s` 假视频骗分；
- **DELIVERING**：优先 Hardlink（自动检查源与目标是否在同一文件系统设备 `st_dev`，跨文件系统平滑降级为 Copy）；
- **WAITING_EMBY**：触发 Emby 媒体库扫描并轮询对账，**只有在 Emby 真实发现目标 TMDB 与季集后，才转为 ACCEPTED**；
- **ACCEPTED**：此时方可触发积分与悬赏结算。

---

### 3. 积分与经济总账强幂等性与零初始余额 (Idempotent Points Ledger & Zero Initial Balance)
- **User.balance 初始必须为 0**：禁止在 User 表默认值或 ORM 构造中预设 `balance=100`。新用户的初始代币、每日签到、投稿奖励必须 100% 严格委托 `PointsService.add_points()` 生成唯一流水，**杜绝在业务代码中额外执行 `user.balance += X` 导致账实不符与双发错账**；
- **Append-Only 只增流水账本**：禁止任何绕过账本直接修改余额的操作；
- **强幂等唯一键**：每一笔加币记录携带 `idempotency_key`（例如 `reward_subitem_{item_id}`），通过唯一索引拦截任何网络重试与 worker 崩溃重跑；
- **并发扣币安全**：使用 `SELECT ... FOR UPDATE` 行级锁确保余额不为负。

---

### 4. 业务逻辑归一化与统一领域服务 (Unified Domain Service)
- **Web API 与 Telegram Bot 必须共用统一的 `SubmissionService`**：严禁 Bot 单独写一套硬编码 `tmdb_id=0` 的粗糙投稿逻辑。Bot 的 `/upload` 必须与 Web 走相同的 TMDB 刮削、Redis 锁预抢占与状态机；
- **Redis 生产严格 Fail-Closed**：在生产环境中，若配置要求 Redis，当 Redis 掉线或加锁异常时，锁获取必须严格返回 `False`，接口直接返回 `503 / 409` 阻断提交，严禁降级放行导致重复离线下载上百 G 大文件。

---

### 5. 悬赏精准匹配与 Escrow 冻结
- **严格匹配元组**：`(tmdb_id, media_type, season, episode)`，严禁仅按 `tmdb_id` 模糊匹配，防止多集剧集串单结算；
- **真实押金冻结**：发布悬赏时立即扣除押金；完工时转给投稿人，取消时原路退回。

---

### 6. 缺集计算与多季区间压缩算法 (Multi-Season Missing Engine)
严禁将所有季度的集数压平计算（避免 S01E01 与 S02E01 混淆），必须以 Season 字典为单位计算：
```python
def calculate_multi_season_missing(season_defs: dict[int, int], accepted_tuples: list[tuple[int, int]]):
    # season_defs: {1: 12, 2: 24}
    # accepted_tuples: [(1, 1), (1, 2), (2, 1)]
    # 输出格式化标准区间: "S01E03-E12、S02E02-E24"
```

---

### 7. 多端统一身份绑定与资产防分裂机制 (Multi-Platform Identity Linking & Anti-Exploit)
- **拒绝多端孤立账户与双份初始代币**：Web 端（Emby 原生鉴权）与 Telegram Bot 若各自创建用户并赠送初始积分，会导致羊毛党利用多端接口无限套取积分，且权益与历史投稿记录断层；
- **单一权威身份原则**：Emby 账号是唯一权威身份，Telegram 只是它的一个接入端。必须彻底删除 `get_or_create_tg_user()` 这类"按 TG ID 建号"的函数 —— 留着它就一定会有某条代码路径调用它。未绑定用户发任何指令（`/start`、`/sign`、`/upload`，**含 Inline Keyboard 回调**）都只返回绑定引导，绝不建号、绝不发币；
- **两阶段安全绑定码体系 (Auth-Link Code)**：
  1. Telegram 用户通过 `/link` 申请一个带 TTL（10 分钟）的 6 位一次性绑定码；
  2. 用户在 Web 端个人中心（已登录 Emby 账号）输入该绑定码；
  3. 系统以数据库事务原子更新 `User.tg_user_id`，将 TG 临时资产/记录无缝合并至 Emby 主账号。

- **绑定码必须落库，不要只放 Redis**：绑定属于账号安全操作，需要持久审计痕迹（谁在何时把哪个 TG 绑到了哪个账号）；且"一次性消费"用数据库唯一约束 + 行锁比 Redis 更可靠。建 `tg_bind_codes` 表，字段 `code / tg_user_id / tg_username / expires_at / consumed_at / consumed_by_user_id`。
- **同一 TG 同时只允许一个未消费码**（防刷码扩大攻击面），用 Partial Unique Index 兜底：
  ```sql
  CREATE UNIQUE INDEX uq_tg_bind_active_code
  ON tg_bind_codes(tg_user_id) WHERE consumed_at IS NULL;
  ```
  重复 `/link` 复用未过期的码；已过期则清理后重新签发。
- **绑定码生成三要素**：① 用 `secrets` 而非 `random`；② 字符集剔除 `0/O/1/I/L` 等易混淆字符（用户要手抄）；③ 兑换时 `strip()` + `upper()` 容错，用户从 TG 复制常带空格与小写。
- **redeem 四重校验（缺一不可，全部在行锁内）**：① 码存在；② 码未消费；③ **当前账号未绑其他 TG**；④ **该 TG 未被他人绑定**。
- **严禁静默改绑 —— 改绑等于账号劫持**。已绑定账号拿到别人的码必须报错拒绝，要换必须先显式解绑。解绑不得触碰余额与流水（账本 Append-Only），绑定/解绑均写 `AuditLog`。
- **三个端点全部强制鉴权**（`status` / `redeem` / `unbind`）：匿名请求绝不允许决定账号归属。回归测试必须逐个断言匿名访问返回 401/403。
- **升级破坏性提示**：切换到此机制后，历史上靠 TG 自动建号的用户会变成"未绑定"，需走一次 `/link`。余额与流水都在原账号上不会丢，但必须提前告知用户，并准备一次性核对脚本列出这批人。

---

### 8. 状态机调度进化：从轮询扫表到事件驱动队列 (Event-Driven & Distributed Work Queue)
- **单进程轮询瓶颈**：单进程定时扫描活跃投稿表（`get_active_submissions`）在任务并发量扩大或网络等待长（如大文件离线、Emby 刮削延迟）时，会导致轮询锁表与推进滞后，且无法横向扩展多 Worker；
- **事件驱动 + 轮询兜底（推荐落地形态，实测唤醒延迟 0.3s vs 轮询平均 7.5s）**：
  - Worker 主循环用 Redis `BRPOP` 阻塞等待唤醒队列，而不是 `asyncio.sleep(N)`。无事件时 BRPOP 自然超时，等价于一次常规轮询节拍 —— 一套代码同时是"睡眠"和"被唤醒"；
  - **必须选 Redis 队列而非 `asyncio.Event`**：后者只在单进程内有效，多副本部署直接失效；
  - 事件源：qBittorrent「Torrent 完成时运行外部程序」调 Webhook、新投稿受理后 `signal_wake()`；
  - Redis 不可用时自动退化为 `asyncio.sleep` 轮询，绝不因缺 Redis 停摆；
  - 自适应间隔：有推进用短间隔（15s）快跟进后续阶段，连续空转数轮放宽到长间隔（60s），降低数据库空转扫表。
  ```python
  class RedisManager:
      WAKE_QUEUE_KEY = "myapp:pipeline:wake"      # key 必须带命名空间，防撞键

      async def signal_wake(self, reason: str) -> bool:
          if not self.client: return False
          try:
              await self.client.lpush(self.WAKE_QUEUE_KEY, reason)
              await self.client.expire(self.WAKE_QUEUE_KEY, 60)   # 防陈旧 token 堆积
              return True
          except Exception:
              return False                          # 静默失败，轮询兜底会接住
  ```
- **⚠️ BRPOP 会被 redis-py 的 socket 读超时误杀（真实踩坑，务必看下一条）**。

#### 8a. redis-py 阻塞命令必须用独立连接（血案）
- **现象**：日志反复 `Timeout reading from <host>`，事件驱动静默退化成纯轮询。功能不坏、任务不丢，但优化目标完全没达成 —— 极易被当成"偶发网络抖动"忽略过去。
- **根因**：`redis.asyncio.from_url()` 不显式传 `socket_timeout` 时，连接实际带着 `orig_socket_timeout=5`（5 秒读超时）。任何等待超过 5 秒的阻塞命令都会被判读超时抛 `TimeoutError`。实测对照：
  | 写法 | `BRPOP(20)` 实际行为 |
  |---|---|
  | `from_url(默认)` | **5.01s 抛 TimeoutError** |
  | `from_url(socket_timeout=None)` | 20.01s 正常等满 |
  | `from_url(socket_timeout=25)` | 20.09s 正常等满 |
- **诊断手法**：`client.connection_pool.connection_kwargs` 里看不到 `socket_timeout` 键不代表没有超时 —— 真正生效的是 `orig_socket_timeout`。直接打印整个 dict 对比默认与显式两种构造。
- **修法：区分两类连接，不要混用一个客户端**（混用做不到既快速失败又能长阻塞）：
  ```python
  FAST_SOCKET_TIMEOUT_SECONDS = 5        # 普通命令：Redis 卡住时快速失败
  MAX_BLOCKING_WAIT_SECONDS   = 300      # 单次 BRPOP 阻塞上限
  BLOCKING_SOCKET_TIMEOUT_MARGIN = 15    # 余量：确保 Redis 先返回、socket 后超时

  self.client = from_url(url, socket_timeout=FAST_SOCKET_TIMEOUT_SECONDS, ...)
  self._blocking_client = from_url(
      url, socket_timeout=MAX_BLOCKING_WAIT_SECONDS + BLOCKING_SOCKET_TIMEOUT_MARGIN, ...)
  ```
  并对调用方传入的等待时长做上限钳制：`wait = max(1, min(int(t), MAX_BLOCKING_WAIT_SECONDS))`，防止配置写大后又超出 socket 读超时。
- **回归断言（纯静态、不需要真 Redis）**：阻塞连接读超时 > 最长阻塞时长；主客户端读超时 < 阻塞级别；配置的轮询间隔 ≤ 阻塞上限；`wait_for_wake` 必须走 `blocking_client`。
- **教训**：这个缺陷单测发现不了（mock 的 Redis 替身没有 socket 层）。**事件驱动这类"延迟优化"必须真机跑一遍并盯日志窗口**，否则你以为优化了、实际一直在走兜底路径。

#### 8b. 多 Worker 并发推进必须加单条独占锁
- 单进程扫全表的实现一旦部署多副本，同一条投稿会被多个 Worker 同时推进 —— 重复 `add_torrent`、重复交付落盘，甚至在 Emby 确认阶段并发发币。
- 每条投稿推进前先抢 `pipeline_advance:{id}` 独占锁，抢不到就跳过交给持有者。**TTL 必须大于单条最慢阶段耗时**（通常是 `inspecting`：多文件 ffprobe），持有者崩溃后锁自动过期不会永久卡死。
- `run_state_machine_cycle()` 改为**返回本轮推进条数**，供调度器决定快跟进还是放宽间隔。
- **Redis 宕机时的日志纪律**：生产 Fail-Closed 停摆是正确取舍（金钱操作宁可停摆不可重复），但**日志绝不能谎报成"另一个 Worker 正在推进"**，否则排障时会把 Redis 宕机误判成正常的多副本竞争。必须先 `ping()` 探测，宕机时打一条独立的 `PIPELINE_HALTED` ERROR 说明"因 Fail-Closed 保护而全部暂停"。

#### 8c. qB 完成 Webhook 的安全与责任边界
- 端点只负责**投递唤醒信号**，绝不在请求线程里跑重活 —— 避免 qB 回调超时把流水线拖垮，也杜绝被刷接口打满 CPU。
- 共享密钥鉴权，用 `secrets.compare_digest` 防时序侧信道。**密钥未配置时直接 503 拒绝（Fail-Closed）**，绝不允许无鉴权的公网端点触发内部流水线。
- 支持 Header 与查询参数两种传密钥方式（qB 的"运行外部程序"配置有时不便加 Header）。
- **唤醒信号投递失败仍返回 200**：轮询兜底会接住该任务，返回 5xx 只会让 qB 反复重试刷日志。
- qB 侧配置：设置 → 下载 → Torrent 完成时运行外部程序
  `curl -s -X POST "http://host:8000/api/webhooks/qb/complete?torrent_hash=%I" -H "X-Webhook-Token: <token>"`

- **生产级核对清单**：详细交付验收与测试步骤请参考 [references/production-checklist.md](references/production-checklist.md)。
- **端到端生产模拟演练**：单测全绿 ≠ 系统可用。改完流水线/积分/删除逻辑后必须另跑一次 16 场景全生命周期演练（含并发双删、目录穿越、越权、全站脱敏），设计规范与三个脚本自身陷阱见 [references/e2e-simulation-drill.md](references/e2e-simulation-drill.md)。
- **字幕轨道、观影日历与社交福利规范**：外挂字幕时间轴质检、Emby 播放行为对账与红包/轮盘代币闭环见 [references/social-economy-and-subtitle-pipeline.md](references/social-economy-and-subtitle-pipeline.md)。
- **单文件 Vue SPA 结构校验器**：改动前端 Tab / ref 后必跑 `scripts/verify_spa_structure.py`（标签配平 + Tab 声明与面板一一对应 + setup() 导出完整性）。用法见脚本 docstring。

---

## 避坑指南与生产级防线 (Critical Pitfalls & Traps)

1. **新旧双轨未接通陷阱 (Dual-Track Architecture Trap)**：
   - 重构时切勿只新建 `services/` 或 `models/` 而忘记切断旧的 `main.py`、`routes/` 与 `pipeline.py`。
   - 彻底删除废弃的旧单文件，并在 CI/测试中必须加入 `from backend.main import app` 与 `/api/health` 的完整启动 Smoke Test。
2. **Alembic 容器启动接管与索引漂移 (Alembic Startup Takeover)**：
   - 生产环境中必须由容器入口 `entrypoint.sh` 执行 `alembic upgrade head`，生产代码彻底移除隐式 `create_all()`。
   - 必须确保 Alembic Migration 脚本中显式包含全部 Partial Unique Indexes，运行 `alembic check` 验证零偏差。
3. **集数解析盲区误判 (Episode Mapping Fallback Risk)**：
   - 剧集多文件解析时，若无法从文件名提取集数，**必须标记 `REJECTED_NEEDS_EPISODE_MAPPING` 拦截**，绝不可无脑默认反推为 `S01E01`。
4. **TMDB 失败必须分类透出，严禁压成一个 `return None`**：
   - Fail-Closed 阻断任务是对的（严禁默认创建 `total_items_count=1` 的单集假任务），但**"拦下来"和"说清为什么"是两件事**；
   - **反模式**：客户端把未配置 key、凭证无效、条目不存在、限流、网络故障全压成 `return None` / `return []`。上游只能报"无法从 TMDB 获取权威元数据，操作已拦截" —— 运维看到这句会去查 TMDB ID 与网络，而真正原因常常是**服务端根本没配 API Key**，错误信息把人指向完全错误的方向。搜索接口更糟：静默返回空列表，用户会以为"TMDB 里没这部剧"，然后一直换关键词白折腾；
   - **正解**：定义错误分类枚举 + 两个语义属性供上游决策：
     ```python
     class TMDBErrorKind(str, Enum):
         NOT_CONFIGURED = "not_configured"   # 未配置凭证（含占位符）
         UNAUTHORIZED   = "unauthorized"     # 401/403 凭证无效
         NOT_FOUND      = "not_found"        # 404 确认无此条目
         RATE_LIMITED   = "rate_limited"     # 429
         UPSTREAM_ERROR = "upstream_error"   # 5xx
         NETWORK_ERROR  = "network_error"    # 超时/DNS/连接失败

     class TMDBError(Exception):
         @property
         def is_config_problem(self) -> bool:   # → 提示管理员，不要怪用户输入
             return self.kind in (NOT_CONFIGURED, UNAUTHORIZED)
         @property
         def is_transient(self) -> bool:        # → 稍后重试，不应把投稿判死
             return self.kind in (RATE_LIMITED, UPSTREAM_ERROR, NETWORK_ERROR)
     ```
   - **HTTP 映射**：`is_config_problem` 或 `is_transient` → 503（含明确原因）；其他上游异常 → 502；`NOT_FOUND` 与参数问题 → 400。前端必须原样透出 `detail`，禁止吞掉非 200 响应；
   - **占位符必须识别为未配置**：`.env.example` 里的 `your_tmdb_api_key_here` 会被当成真 key 发出去，换回一个含义模糊的 401，排查又多绕一圈。用 `any(p in key.lower() for p in ("your_","xxx","change_me","replace"))` 拦掉；
   - **v3 API Key 与 v4 Read Access Token 必须自动识别**：v4 token 是 JWT（`eyJ` 开头、两个点），必须走 `Authorization: Bearer` 且**不得再带 `api_key` 查询参数**，混用一律 401。TMDB 官网现在默认给的就是 v4 token，只支持 v3 的实现会让人以为是 key 申请错了：
     ```python
     @property
     def uses_bearer_token(self) -> bool:
         return self.api_key.startswith("eyJ") and self.api_key.count(".") == 2
     ```
   - **暂时性故障做指数退避重试**（3 次 / 0.5s-1s-2s），凭证问题立即失败不浪费重试。TMDB 偶发 429/5xx/超时很常见，一次抖动就把用户投稿判死不可接受；
   - **日期解析要防脏数据**：`int(release_date.split("-")[0])` 遇到空串或非数字会抛 `ValueError` 打挂整条查询，必须 `if head.isdigit()` 后再转，否则降级为 `year=None`；
   - **`health_check()` 比"key 是否非空"有意义得多**：真实打一次 `/configuration` 探测，返回 `{ok, kind, auth_mode, detail}`，接入 `/health/ready` 与管理面板，让管理员一眼看清是"没配"、"配错"还是"网络不通"（境内服务器连不上 `api.themoviedb.org` 是常见情况，报错要点明可能需要代理）。**该函数被就绪探针调用，任何情况下都不能抛异常**。
5. **交付失败与 WAITING_EMBY 严格隔离 (Delivery Failure Isolation)**：
   - 只有物理落盘成功且处于 `waiting_emby` 的条目才允许向 Emby 对账；若条目 `failed/rejected`，即使 Emby 历史库内恰好已存在同名资源，也绝对不可复活或触发发币。
6. **宿主机 vs 容器内部路径隔离与 qB 强制 save_path (Host vs Container Path Mapping & Forced save_path)**：
   - 配置与 Compose 必须区分 `HOST_*`（宿主机挂载点）与 `CONTAINER_*`（程序内部读取路径），防止换路径部署后 `os.path.exists()` 误报文件丢失。
   - 调用 qB WebAPI 添加种子时必须显式传参 `save_path=CONTAINER_DOWNLOAD_PATH`，杜绝依赖 qB 默认分类目录导致的文件落地漂移。
7. **真实就绪度探针与生产安全 Fail-Closed (True Readiness Probe & Security Fail-Closed)**：
   - `/api/health/ready` 必须执行真实数据库 `SELECT 1` 与 Redis PING 探测，数据库异常时严格返回 `503 Service Unavailable`。
   - `APP_ENV=production` 时，只要 `SECRET_KEY` 为空或使用示例占位符，必须无条件抛出异常拒绝启动。
8. **Redis 分布式锁 + 任务预抢占前置阻断 (Pre-Download Concurrency Guard)**：
   - 在将磁力提交至下载器之前，必须先获取 `submit_lock:{tmdb_id}:{media_type}` 并校验任务是否已存在/正在下载。若已有活跃任务，立即返回 HTTP 409 拦截，杜绝多用户并发下载重复百 G 大文件造成带宽与磁盘极大浪费。
10. **SKIP 冲突策略防冒领发币 (SKIP Conflict & Anti-Exploit Guard)**：
    - 当目标目录已存在历史异源文件且配置为 `SKIP` 时，**交付适配器必须返回 `success=False`**，条目直接标记 `failed`，绝不进入 `waiting_emby`。严禁返回 `success=True` 导致历史已有资源被 Emby 扫描后误发币（冒领刷币漏洞）。
11. **同种内同集多画质择优去重 (Intra-Torrent Episode Resolution Deduplication)**：
    - 当一个种子内意外包含同一单集的不同分辨率文件（如 1080p 与 720p）时，质检阶段必须按 `(season, episode)` 进行聚合，优先保留 `4K / 1080p + 最大体积` 的最佳文件，防止同一任务内部产生自碰撞死锁。
12. **前端分页契约与接口错位对齐 (Frontend Pagination & Method Contract)**：
    - 后端统一分页化返回 `{items: [...], total: N}` 后，前端必须解构为 `data.items || []`，禁止直接将分页对象赋值给列表；
    - 确保前端“我的任务/历史”调用正确的 GET 路由（如 `/api/submissions/my`），杜绝误调 POST 投稿端点。
13. **Telegram Bot 回调与悬赏押金退款闭环 (Bot Callbacks & Escrow Refund)**：
    - Bot 必须显式注册 `CallbackQueryHandler` 处理全部 Inline Keyboard 按钮，避免点击无响应；
    - 真实 Escrow 冻结的悬赏必须提供明确的取消与全额退款流（`bounty_refund`），防止用户代币被死锁。
14. **指定单集严格过滤收口 (Target Episode Inspection Filter)**：
    - 当用户指定单集（如 S01E07）投稿时，质检阶段在多文件扫描后必须强行过滤为 `candidates_by_episode = {target_key: candidates[target_key]}`，只为目标单集生成条目并交付发币，**绝对禁止将种子大包中未预占的其他集数顺带入库发币**。
15. **SAVEPOINT 局部事务隔离防护 (Savepoint Isolation in Batch Acceptance)**：
    - 在多集逐项推进 `accepted` 状态时，必须采用 `async with db.begin_nested():` 隔离单项并发 Partial Unique 冲突；
    - 遭遇并发唯一冲突时，只局部回滚该项为 `rejected`（记录 `DUPLICATE_AFTER_DOWNLOAD`），**严禁调用全局 `session.rollback()` 导致同一批次前置已确认单集及其 PointsLedger 流水被连带回滚**。
16. **失败重试物理清理旧执行态与预估/实发奖励解耦 (Clean Execution State on Failed Retries & Reward Decoupling)**：
    - 预估奖励 `estimated_reward_points`（用于展示）与实发奖励 `reward_points`（初始为 0，发币后才累加）必须严格解耦；
    - 复用 `failed/rejected` 历史 Submission 重试时，校验 `reward_points == 0`，并必须物理删除旧 `SubmissionItem` 与重置 `DownloadJob`，杜绝新老批次脏数据叠加。
17. **终态异常即时释放 TaskItem 预占 (Instant Reservation Release on Terminal Failures)**：
    - 遭遇任何终态失败（TMDB 失败、死种、qB 致命错误、质检不符、交付落盘失败、Emby 超时）时，必须即时将目标 `TaskItem` 恢复为 `missing`，无需等待 2 小时 TTL 超时。
18. **Alembic 迁移历史不可变增量版本链 (Immutable Alembic Migration Chain)**：
    - 严禁重写/覆盖 Base Migration！一旦数据库已有部署，后续表结构调整必须通过 `alembic revision --autogenerate` 生成增量 Revision 文件，并带 `alembic check` 验证零偏差，确保老版本数据库执行 `alembic upgrade head` 能平滑无损升级。
19. **公共投稿广场脱敏防泄露 (Public Feed Desensitization)**：
    - 全站公共接口（如 `GET /api/submissions/all`）必须采用专用的 `PublicSubmissionResponse`，**物理剔除 `magnet_uri`, `torrent_hash`, `source_file`, `dest_file`, `error_message`**，防止普通用户抓包盗取其他用户贡献的私密磁力资源。
20. **剧集强校验禁止假全季绕过预占 (Strict Episodic Target Validation)**：
    - 剧集/动漫/综艺投稿在 Schema 校验层必须强制要求 `season >= 0` 与 `episode >= 1`，禁止 `episode=NULL` 假全季整包模式绕过单集预抢占与活跃唯一索引保护。
21. **Emby 最终对账增加 `expected_dest_path` 物理路径严格比对 (Physical File Path Verification)**：
    - 在对账验证时不仅比对 TMDB ID 与季集序号，更进一步比对 Emby 刮削到的文件真实路径/基准名是否等于本次交付落盘的 `expected_dest_path`，从根本上证明确认的是“本次投稿交付的物理文件”，杜绝库中偶然存在的同名旧资源冒领发币。
22. **Alembic 历史数据平滑增量升级三步法 (Safe Incremental Migration Pattern)**：
    - 在已有海量数据的生产表上添加新字段时，严禁直接 `nullable=False`（无默认值会导致升级直接报错中断）；
    - 必须采用安全三步变更：`op.add_column(nullable=True, server_default='0')` → `op.execute(UPDATE existing ...)` → `op.alter_column(nullable=False)`。
23. **统一规范 Canonical TMDB 媒体身份防重 (Canonical TMDB Media Identity)**：
    - 针对 `tv` / `anime` / `variety` 等 TMDB 统一归属于 Series 的剧集类型，任务主体防重必须强制规范化为统一的 `canonical_media_type="tv"`，`category` 仅作为业务分类属性，防止通过切换 `anime/variety` 生成多个独立 Task 绕过防重。
24. **悬赏取消与入库结算悲观行锁互斥 (Pessimistic Locking on Escrow Operations)**：
    - 在悬赏取消退款（`bounty_refund`）与入库发赏（`bounty_claim`）两个并发链路中，对目标 `WantedTask` 必须执行 `SELECT ... FOR UPDATE` 悲观行锁，并在锁内二次校验状态，防止同一笔押金在并发竞态下发生双重支付；
    - **⚠️ 结算侧与取消侧的可接受状态集合不同，严禁两边都写 `status == 'open'`**：
      - 可结算（发赏）：`IN ('open', 'claimed')` —— `claimed` 表示已认领但尚未交付，真实入库后同样必须发赏；
      - 可取消（退款）：仅 `('open',)` —— 已认领的悬赏不允许发布者单方面撤销。
    - **实战血案**：`repo.find_exact_bounties()` 里写对了 `IN ('open','claimed')`，但 pipeline 结算处另起一条 `select(...).where(status == "open")` 硬编码绕过了它。结果 `claimed` 悬赏在投稿真实入库 `accepted` 后仍停在 `claimed`，**押金既不退给发布者、也不发给投稿人，凭空锁死在系统里**。20 项 Service 单测全绿，完全没发现。
    - **根因是状态字面量分散硬编码**。修法：在 model 层建立单一真源常量，所有结算/取消路径必须引用它，禁止各处自行写字符串：
      ```python
      # models/wanted.py —— 单一真源
      SETTLEABLE_BOUNTY_STATUSES  = ("open", "claimed")   # 可发赏
      CANCELLABLE_BOUNTY_STATUSES = ("open",)             # 可退款

      # repo：结算查询统一入口，带可选行锁
      async def find_exact_bounties(self, tmdb_id, media_type, season, episode,
                                    for_update: bool = False):
          stmt = select(WantedTask).where(
              WantedTask.tmdb_id == tmdb_id,
              WantedTask.media_type == media_type,
              WantedTask.season == season,
              WantedTask.episode == episode,
              WantedTask.status.in_(SETTLEABLE_BOUNTY_STATUSES),
          )
          if for_update:
              stmt = stmt.with_for_update()
          return list((await self.db.execute(stmt)).scalars().all())
      ```
    - **审计手法**：全仓 `grep -rn "status == \"open\"\|status.in_(\[" ` 逐一核对，凡是绕过 repo 统一入口自行拼 where 的地方都是嫌疑点。

24b. **电影悬赏季集必须归一化为 NULL (Movie Bounty NULL Season Normalization)**：
    - 结算侧按 `(tmdb_id, media_type, season, episode)` 精确匹配，电影的季集是 `NULL`（SQL 编译为 `season IS NULL AND episode IS NULL`）；
    - 但 Pydantic Schema 常给 `season: Optional[int] = Field(default=1)` 这类**非 None 默认值**。电影悬赏一旦带着 `season=1` 落库，就与 `IS NULL` 永久错配 —— **押金一扣即永久冻结，且不会报任何错**；
    - 建单入口必须显式归一化，不能依赖调用方传对：
      ```python
      if canonical_media_type == "movie":
          target_season = target_episode = None      # 强制 NULL
      else:
          if req.season is None or req.episode is None:
              raise HTTPException(400, "剧集悬赏必须指定季集")
          target_season, target_episode = req.season, req.episode
      ```
    - 回归断言：`POST /wanted` 建电影悬赏后，响应里 `season is None and episode is None`。
25. **磁力 Base32 BTIH 自动规范化与种子丢失恢复 (BTIH Normalization & Torrent Recovery)**：
    - 磁力解析时必须将 32 位 Base32 BTIH 统一解码并转换为标准 40 位 Hex 小写，保证数据库防重与下载器索引一致；
    - 下载状态机中若遭遇 qB 种子任务意外丢失超过 3 分钟自动触发重推，超过 10 分钟持续丢失则熔断为 `FAILED_QB_MISSING` 并即时释放锁定的 `TaskItem`。
26. **未实现交付适配器严格 Fail-Closed (Delivery Adapter Fail-Closed)**：
    - 交付工厂方法（如 `get_delivery_adapter()`）在检测到非 `local` 且未实现的适配器配置时（如 `DELIVERY_ADAPTER=guangya`），**必须抛出 `NotImplementedError` 并在启动阶段拒绝服务**，严禁静默偷跑本地落盘假装成功。
27. **失败重试时同步更新 TMDB 身份 (Sync Identity on Failed Retries)**：
    - 当用户对此前失败的任务修正 TMDB ID 并重试时，除了更新 `task_id` 外，必须显式同步更新 `Submission.tmdb_id` 与 `Submission.media_type`，杜绝后续 Delivery 命名与 Emby 对账时 Task 与 Submission 内部身份错位。
28. **悬赏创建必须强制保存 Canonical Media Type (Canonical Type on Bounty Creation)**：
    - 悬赏创建入口必须将 `media_type` 统一转为规范类型（如 `anime/variety -> tv`）持久化至 `WantedTask`，确保后续入库结算时 `exact_bounties` 能够精准匹配。
29. **CI 必须包含历史数据平滑升级断言 (Upgrade Existing Database Test)**：
    - 仅对全新空数据库执行 `alembic upgrade head` 无法发现已有数据表添加 `nullable=False`（缺少默认值）导致的生产升级崩溃；
    - CI 必须构建或提供包含已有历史数据的数据库测试分支，实测验证在有既有数据的场景下执行 Migration 是否无损平滑通过。
30. **多端账号资产分裂与羊毛漏洞 (Multi-Platform Asset Splitting & Faucet Exploit)**：
    - 严禁 Telegram Bot 在首次 `/start` 时无脑创建带有初始代币的独立 `User`，否则攻击者可通过切换 TG 账号与 Web 账号无限刷初始积分；
    - Telegram 端必须默认仅作为受限交互界面，强制要求通过 `/link` 绑定码与 Emby 账号原子绑定后才开放积分流转与投稿权益。
31. **测试默认跑在生产语义下（假信号制造机）**：
    - `settings.APP_ENV` 默认值若为 `"production"`，本地不导 `APP_ENV=testing` 直接 `pytest` 会挂掉一批用例 —— 因为生产下 `RedisLock` 是 Fail-Closed 的（无 Redis 则拒绝获取锁）。CI 里导了环境变量所以全绿，本地却红，这种"CI 绿本地红"的假信号会浪费大量排查时间；
    - **修法：把它固定在 `tests/conftest.py`，让测试结果不依赖外部环境变量**：
      ```python
      @pytest.fixture(autouse=True)
      def _force_testing_env(monkeypatch):
          monkeypatch.setattr(settings, "APP_ENV", "testing", raising=False)
          yield
      ```
    - 需要验证生产语义的用例（如 Fail-Closed 停摆）在用例内部再 `monkeypatch` 回 `production` 即可。
32. **前端插入新 Tab 极易嵌套错位，必须用解析器校验而非肉眼看 diff**：
    - 在单文件 Vue（`index.html`）里插入新 Tab 面板时，把新面板的开标签插到了旧面板的开标签之后，导致 `<div v-if="admin">` 的开标签留在 `profile` 面板外面 —— diff 看起来完全正常，页面渲染却错乱；
    - **写完必跑的静态校验脚本**（见 `scripts/verify_spa_structure.py`）：① `html.parser` 子类做标签配平；② 正则比对导航声明的 Tab id 集合与模板 `v-if="currentTab === 'x'"` 集合必须一一对应；③ 断言新增的 ref/函数都出现在 `setup()` 的 `return {}` 里（漏掉不会报错，只是模板里静默失效）；
    - 教训：**"肉眼审 diff 通过"不算验证**。这类结构错误单测覆盖不到，必须有机械校验。

33. **FastAPI 序列化 ORM 对象的 MissingGreenlet 陷阱 (Eager-Load on Serialized Response)**：
    - 当接口声明了包含关系属性的响应模型（例如 `SubmissionResponse` 包含 `items: List[SubmissionItemResponse]`），若端点直接返回刚刚 `db.add()` 或 `create_submission()` 出来的 ORM 实例，FastAPI 在内部将 ORM 转化为 Pydantic 时会同步读取未加载的关系属性 `sub.items`，从而在 async 驱动（aiosqlite/asyncpg）中抛出 `sqlalchemy.exc.MissingGreenlet`，导致接口 500 崩溃；
    - **修法**：在返回之前，必须调用携带 `selectinload(Submission.items)` 的 Repository 方法重新加载完整对象（如 `loaded_sub = await service.sub_repo.get_by_id(sub.id); return loaded_sub or sub`），彻底阻断隐式懒加载。
34. **容器挂载路径在宿主机/测试环境下的写入权限穿透容错 (Container Path Fallback)**：
    - 直接视频文件上传（`upload-file`）通常指定暂存目录为容器内部共享卷 `settings.QB_CONTAINER_DOWNLOAD_PATH/uploads`（例如 `/downloads/lemon_2f/uploads`）；
    - 在宿主机本地跑单测或离线开发时，宿主机根目录下根本没有 `/downloads` 或非 root 用户无权创建，直接 `os.makedirs` 会爆 `PermissionError: [Errno 13]`；
    - **修法**：创建目录必须捕获 `(OSError, PermissionError)` 并自动降级为系统级临时目录（`os.path.join(tempfile.gettempdir(), 'lemon_2f_uploads')`），保证生产环境中享受挂载卷零拷贝、测试与开发环境中环境无关即开即测。
35. **任意原始杂乱文件名强制 TMDB 标准重命名入库闭环**：
    - 用户上传的文件名常常包含乱码广告或随意命名（如 `1.mp4`, `raw_cut.mkv`），若单纯依赖正则从文件名反推集数，会大量误判为集数缺失而被拦截；
    - **正解**：只要用户在提交界面锁定了目标影视与具体季集（`target_season` 与 `target_episode`，或电影类型），质检阶段在检测文件编码合法且通过 FFprobe 后，若单文件无法解析出集数或集数不匹配，**无条件强制将其映射为用户指定的目标季集**，交付层一律忽略原始源文件名，按 TMDB 标准格式创建规范目录与文件名（`Title (Year) [tmdbid=xxx]/Season XX/Title - SxxExx.ext`），彻底实现 100% 规范化入库。
36. **错片下架并发防重复扣罚：原子 CAS 闸门 + 账本 SAVEPOINT 兜底（`FOR UPDATE` 单独用是不够的）**：
    - 扣罚 `idempotency_key` 必须确定性唯一（如 `del_penalty_{sub.id}`），**严禁拼接 `uuid.uuid4()`** —— 否则并发/重试各生成一个新键，3 倍罚金被重复扣成 6 倍、9 倍负债；
    - 惩罚扣除必须 `allow_negative=True`，杜绝用户发币后立刻去商城花光代币逃避惩罚；
    - ⚠️ **`SELECT ... FOR UPDATE` 不能作为唯一防线**（2026-09-04 模拟演练实测打脸）：SQLite 方言直接忽略行锁；即使在 PostgreSQL 上，仅靠行锁也掩盖不了下面这个组合故障。真实症状是**两个并发删除请求：一个 200、一个 500，用户一分未扣**（丢失更新 + 事务被打爆），比"扣两次"更隐蔽；
    - **正解是两层，缺一不可**：
      ```python
      # ① 原子 CAS 状态闸门 —— 跨 PostgreSQL / SQLite 通用，只有 rowcount==1 的那个请求是唯一执行者
      cas = await db.execute(
          sa_update(Submission)
          .where(Submission.id == sid, Submission.status != "deleted")
          .values(status="deleted"))
      if cas.rowcount == 0:                     # 并发对手已抢先完成
          await db.rollback()
          return {"success": True, "points_deducted": 0,
                  "message": "已被并发请求处理下架，本次幂等跳过"}
      await db.flush()
      # 注意：状态已在此处翻转，后续依赖"旧状态"的分支（qB 种子清理判定）
      # 必须提前把 original_status 存下来再用，不能再读 sub.status。

      # ② 账本写入用 SAVEPOINT 兜底幂等键碰撞（add_points / deduct_points 都要）
      original_balance = user.balance
      user.balance -= amount
      try:
          async with self.db.begin_nested():    # SAVEPOINT
              await self.ledger_repo.add_entry(entry)
              await self.db.flush()
      except IntegrityError:                    # 唯一键撞车 = 对手已记账
          user.balance = original_balance       # 回滚本次余额变动
          return await self.ledger_repo.get_by_idempotency_key(idempotency_key)
      ```
    - 没有第 ② 层时，幂等键的 UNIQUE 约束会把 `IntegrityError` 抛穿整个外层事务 → 接口 500 且**一分不扣**；此时先提交的那笔也可能被后到者的旧余额覆盖写回。**唯一键只保证不重复记账，不保证余额正确** —— 余额必须自己回滚。
37. **本地挂载免下载引入必须白名单防目录穿越 (Local Mount Path Traversal Whitelisting)**：
    - 支持本地路径/挂载卷直接引入免下载时（`source_type='local_mount'`），若仅校验 `os.path.exists`，恶意用户可输入 `/etc/shadow` 或系统敏感路径，在交付模式为 `move` 时会篡改系统文件；
    - 必须在 Service 入口将路径归一化为绝对路径（`os.path.abspath`），并与受信任根目录集合（如 `settings.QB_CONTAINER_DOWNLOAD_PATH`、`/downloads`、`/media`、系统临时目录）进行前缀白名单比对，非法路径坚决阻断。
38. **积分经济激励动态多级回退与热配置 (Dynamic Points Rules Multi-Tier Fallback)**：
    - 入库奖励、4K 加成、签到随机区间、连签递增加成、错片自删罚金倍数不能仅硬编码在 `.env`，应建立 `system_settings` 动态表支撑管理方热修改；
    - 必须实现多级回退：`get_points_rules()` 优先读数据库 `system_settings`，未配置时自动降级回退到 `settings`（环境变量默认值）；管理后台保存后向 `AuditLog` 写入审计快照，并立即在全站流水线、签到、撤回等全链路热生效，完全免重启。
39. **众包排行榜跨数据库 GROUP BY 与脏数据剔除 (Leaderboard Cross-DB GROUP BY & Status Sanitization)**：
    - 统计投稿部数榜 (`uploads`) 与赚币贡献榜 (`earned`) 时，PostgreSQL 严格要求 `SELECT` 中的非聚合列（`User.id, User.username, User.role, User.balance`）全部显式进入 `GROUP BY`，杜绝仅按 `User.id` 分组在特定 PG 版本下报错；
    - 过滤条件必须严格锁定 `Submission.status.in_(['accepted', 'partial'])`，彻底剔除 `deleted`、`failed`、`rejected` 等脏数据，保证英雄榜威信与纯净度。
40. **交付新功能必须同步更新 README 与仓库描述（对外文档同步纪律）**：
    - **实际踩坑**：连续 4 个功能提交（查缺大厅、四轨多源接入、强制 TMDB 重命名、排行榜与惩罚闭环）全部代码落地并测试通过，`README.md` 却一字未动 —— 对外简介停留在最初版本，用户自己发现后质问"为什么新功能没写进去"。代码做完了但外界看不见，等于白做；
    - **收尾清单**（功能提交后、推 GitHub 前逐条过）：
      1. `README.md` 特性章节新增条目（含新端点、新枚举值/`source_type` 表格、实际落盘格式示例）；
      2. 架构图补上新增的层（如多源接入层、强制重命名层）；
      3. 测试章节写出**真实可复制的命令**与当前通过数（`pytest tests` + 演练脚本）；
      4. 升级部署步骤补 `alembic upgrade head`（新增迁移时必加）；
      5. `gh repo edit --description "..."` 更新仓库一句话简介，并 `gh repo view --json description` 回读确认；
      6. 路线图更新，把已完成项移出待办。
    - **纪律**：文档提交单独走一个 `docs:` commit，不要混进功能 commit，便于回溯"功能何时对外可见"。

41. **外部借鉴去污染与原生领域契约对齐 (External Brand Decontamination & Domain Mapping)**：
    - 在调研或借鉴外部生态（如开源媒体面板、竞品系统等）优秀玩法时，**绝对禁止在生产代码、表结构、字段名、路由、日志及前端文案中残留任何外部产品代号或专有名词**（如外部品牌名、专用代币名、私有协议代号）；
    - 必须执行领域驱动设计（DDD）严格重构，将其彻底清洗并转换为自身原生统一的契约模型（如「二楼有请 / Lemon 2F」、统一货币「软妹币 🪙」、TMDB 统一身份、赛博暗黑粉紫设计规范）；
    - 代码合入前必须运行敏感词排查：`grep -rnE '外部代号|竞品词' .`，确保自身架构的高纯净度与独立自主性。
42. **重大功能演进的渐进节奏与双重备份基线 (Step-by-Step Cadence & Dual-Layer Backup Baseline)**：
    - 面对多项外部赋能需求，严禁一次性大跃进式批量重构。必须严格遵守**“一次只做一步、每步先汇报真实结果再继续”**的研发纪律；
    - 任何跨版本重大特性开发前，必须坚守双重备份底线：
      ① 物理目录冷备份（完整带时间戳独立归档）；
      ② Git 独立特性分支隔离（主分支 main 保持纯净稳定）；
      ③ 基线测试全绿（全量单测与集成测试通过，确立回归基准线）。未通过真实全量回归验证前，绝不盲目合入主分支。
43. **DateTime 时区感知跨数据库比较陷阱 (Offset-Naive vs Offset-Aware Datetime Trap in Leases/TTL)**：
    - 认领时效独占期（`claim_expires_at`）等字段在持久化到 SQLite 或特定异步驱动（aiosqlite/asyncpg）时，从数据库反序列化出来的 `datetime` 经常丢失 `tzinfo`（变为 offset-naive）；
    - 而系统当前时间通常是 `datetime.now(timezone.utc)`（offset-aware）。直接执行 `if task.claim_expires_at > now:` 会直接抛出 `TypeError: can't compare offset-naive and offset-aware datetimes`，导致认领接口、列表惰性过期检查、取消接口全线 500 崩溃；
    - **正解**：在所有涉及时间比较的 Repository / Route / Service 层，必须封装统一的防御函数：
      ```python
      def ensure_utc(dt: Optional[datetime]) -> Optional[datetime]:
          if dt is None:
              return None
          if dt.tzinfo is None:
              return dt.replace(tzinfo=timezone.utc)
          return dt
      ```
      比较时统一写成 `ensure_utc(task.claim_expires_at) > now`，彻底杜绝跨数据库时区类型崩溃。
44. **众筹加码多次跟投与取消全额退款平账 (Crowdfunding Backer Consolidation on Refund)**：
    - 在多人众筹追加机制中，允许同一用户多次跟投追加资金（如先投 50 币，后续再加 100 币）；
    - 撤销悬赏全额退款时，若直接遍历 `backers` 逐条给用户退款并生成流水，会导致同一用户在同一事务中被多次修改余额并频繁触发流水表行锁争用与幂等键冲突；
    - **正解**：退款时先在内存中按 `user_id` 进行累加汇总（`user_refunds = {b.user_id: sum(points)}`），对每个出资人只生成单笔聚合退款流水（`idempotency_key=f"wanted_refund_{task.id}_{user_id}"`），保证资金一分不少原子全额原路到账，且将事务开销降至最低。
45. **认领幂等与独占租约续期 (Idempotent Lease Claiming & Extension)**：
    - 认领接口若机械判断 `if status == 'claimed': raise HTTPException(400, "已被认领")`，会导致原认领人点击刷新或多次误触时被当成“他人冲突”报错；
    - **正解**：必须区分身份与时效：
      ① 若 `task.claimant_id == current_user.id`：视为本人续期，刷新 `claimed_at` 并将 `claim_expires_at` 顺延 24 小时，提升上传体验；
      ② 若他人认领且未过期：400 阻断并提示保护期倒计时；
      ③ 若他人认领但已过期：直接接盘转移所有权，更新 `claimant_id` 与新租约，无需等待后台定时扫描。
46. **`secrets.compare_digest` 中文字符串 TypeError 崩溃陷阱 (Non-ASCII String Compare Trap)**：
    - 在口令红包或暗号核验中，直接使用 `secrets.compare_digest(provided, expected)` 对含有中文非 ASCII 字符的字符串进行比对时，Python 标准库会直接抛出：
      `TypeError: comparing strings with non-ASCII characters is not supported`，导致接口 500 崩溃；
    - **正解**：必须在传入前显式转为 UTF-8 字节串：
      `secrets.compare_digest(provided.encode('utf-8'), expected.encode('utf-8'))`，兼顾常数时间防时序侧信道攻击与国际化中文字符兼容。
47. **外挂字幕独立轨道与 Fail-Closed 时间轴质检机制 (Subtitle Format & Timeline QC)**：
    - 字幕投稿若仅检查后缀名，恶意或粗心用户会上传纯文本、假空文件骗取系统代币奖励；
    - **正解**：必须设置严格的多层质检：
      ① 大小边界：限制在 100 字节至 50MB 之间；
      ② 多编码探测：顺序尝试 `utf-8-sig`, `utf-8`, `gb18030`, `gbk`, `utf-16` 解码；
      ③ 核心语法特征：SRT 必须校验 `-->` 时间轴；ASS/SSA 必须校验 `[Events]` 或 `Dialogue:`；VTT 必须校验 `WEBVTT` 或 `-->`。不符者直接 Fail-Closed 拦截，不写库不发币。
48. **观影打卡每日防刷唯一约束 (Daily Watch Reward Unique Constraint)**：
    - 用户播放流水是高频上报事件，单纯依赖业务代码 `if not claimed: add_points()` 在用户多个客户端同时结束播放时会产生并发竞态，导致同一天被重复发币；
    - **正解**：建立独立的 `daily_watch_rewards` 台账表，增加数据库物理唯一约束：
      `UniqueConstraint("user_id", "reward_date", name="uq_user_daily_watch_reward")`，并在发放代币时使用带日期的幂等键（`daily_watch_{date}_{user_id}`），彻底杜绝并发刷币。
49. **拼手气红包二倍均值算法与全量兜底平账 (Random RedPacket Two-Times-Average Allocation)**：
    - 拼手气随机分配金额时，若简单 `random.randint(1, remaining)`，大概率导致前几人直接抽光所有代币，后续用户分不到钱（甚至金额为负数）；
    - **正解**：
      ① 必须预留保底：`max_possible = remaining_points - (remaining_count - 1) * 1`；
      ② 二倍均值：上限取 `min(max_possible, max(1, (remaining_points // remaining_count) * 2))`；
      ③ 最后一份兜底：当 `remaining_count == 1` 时，强制把所有剩余金额全额分配给最后一人，并自动翻转状态为 `empty`，确保红包账实 100% 精确对齐。
50. **双轨/多目标转存解耦与短命 Token 木桶陷阱 (Multi-Target Storage Decoupling & Token Lifespan Trap)**：
    - 当系统同时转存到多个目标（如 Google Drive + 光鸭云盘）时，严禁在同一个串行 `try` 块中执行 `upload(A) -> upload(B) -> mark_db()`；
    - 外部凭证（如 Google OAuth Testing 模式）存在 7 天强制过期上限（`refresh_token_expires_in: 604799`），一旦 A 抛出 `invalid_grant`，会导致 B（主通道）与数据库入库标记被永久阻断，每次轮询重复拉取重试造成雪崩；
    - **正解**：各存储目标独立 `try...except`，数据库分别记录各目标上传状态（`target_a_id`, `target_b_id`），核心目标成功即可标记已落盘，次要目标失败记录错误日志并支持后台异步重试，杜绝次要通道暴毙拖死整条流水线。
51. **MTProto/Telethon 媒体下载强制超时熔断与僵尸死锁防范 (Media Download Timeout & Deadlock Prevention)**：
    - Telethon / Pyrogram 在跨 Telegram 数据中心（DC）传输或弱网环境下调用 `download_media()` 时，若未包裹超时，底层 socket 偶发死锁无限挂起（Hang 住），进程保持 `active (running)` 假活，但整条队列永久停摆；
    - **正解**：
      ① 外部必须显式增加硬超时熔断：`await asyncio.wait_for(client.download_media(...), timeout=300)`；
      ② `finally` 块必须物理清理半成品或 0 字节临时写入文件，避免长期占用文件句柄；
      ③ 周期性轮询进程必须写入心跳时间戳，由外部 Watchdog 检测若超过阈值未心跳则自动重启服务。

---

## 进阶治理架构与扩展设计 (Advanced Governance & Extension Architecture)

### 9. 逆向生命周期：错片下架、惩罚性多倍扣分与入库回滚风控 (Resource Revocation & Penalty Governance)
- **风控背景**：众包流水线若仅具备正向发币逻辑，一旦遭遇货不对板、压制损坏、音画不同步或恶意刷分，若无法惩罚并撤回，会导致系统积分经济通胀并严重污染媒体库。
- **用户自查撤回（惩罚倍数，默认 3x）**：
  - 用户发现自己上传的资源有瑕疵可主动申请删除；
  - 自动触发惩罚性扣除：`penalty_amount = item.reward_points * PENALTY_MULTIPLIER`（默认 3 倍，配置项 `SUBMISSION_DELETE_PENALTY_MULTIPLIER`）；
  - 写入 `PointsLedger`（`event_type="submission_delete_penalty"`，必须开启 `allow_negative=True` 允许扣成负数，杜绝用户在发币后立即去商城花光积分逃避惩罚）；
  - 交付层适配器安全物理删除已交付的目标文件并递归清理空目录，随后触发 `emby_client.refresh_library()` 同步下架；
  - 关联 `TaskItem` 立即从 `accepted` 恢复为 `missing`，清空 `accepted_submission_item_id`，重新核算 `MediaTask.accepted_items_count` 并将影视主体回滚为 `missing`，重新开放给全站众包补片。
- **管理方删片与弹性扣分权 (Admin Discretionary Settle)**：
  - 管理员在后台查看已入库资源，提供三档处置决策：
    1. **仅删片不扣分 (`no_deduct`)**：资源本身质量不符但无主观恶意，仅物理清理并重置缺集；
    2. **标准惩罚 (`penalty_multiplier`)**：按系统预设的 N 倍（默认 3 倍）严厉扣除软妹币；
    3. **自由自定义扣分 (`custom`)**：输入任意指定扣除额度（如严重恶意欺诈直接扣除指定大额币）。
  - 审计留痕：`Submission.error_message` 与 `PointsLedger` 记录执行管理员、受罚用户、扣分理由及下架时间戳。
- **部分唯一索引自然解绑**：数据库中活跃投稿的 Partial Unique Index（如 `uq_active_submission_torrent_hash` 与 `uq_active_target_episode_submission`）的过滤条件严禁包含 `deleted`。当标记为 `status='deleted'` 时，该条目自动脱离活跃索引，该季集立即对全网解封，允许正常用户再次投稿。

### 10. 资源引入层多协议抽象 (Multi-Source Ingestion Architecture)
- **超越单一磁力下载**：众包不应将数据输入源硬编码为 `magnet_uri`。
- **抽象接入适配器设计**：
  - `MagnetIngestion`: 磁力链接 -> qBittorrent 离线下载；
  - `CloudPanIngestion`: 光鸭云盘 / 移动云盘 139 / 夸克网盘分享链接 -> 解析提取码 -> 借助对应 API/AList 转存拉取；
  - `DirectUploadIngestion`: 用户直接上传视频文件 -> 前端分片 Chunked/Multipart 上传 -> 后端暂存落盘 -> 直接走 FFprobe 质检；
  - `LocalMountIngestion`: 用户或管理员直选宿主机/挂载卷中已有文件或已有 qB 任务 -> 零网络开销秒级入库。
- **统一交付归一化 (Delivery Normalization)**：
  - 无论源头为何种协议，质检完成后必须全部汇聚到 `BaseDeliveryAdapter`（TMDB 目录命名规范：`Show (Year) [tmdbid=xx]/Season XX/Show - SxxExx.mkv`），抹平输入源差异。

### 11. 全库反向查漏与公共待补大厅机制 (Proactive Catalog Dedup & Missing Board)
- **被动查重 vs 主动查缺**：
  - 被动：用户搜 TMDB ID -> 查 Emby 库内有无单集；
  - 主动：定时 Worker 遍历 Emby 剧集库 -> 读取全部包含 `ProviderIds.Tmdb` 的 Series -> 比对 TMDB 官方季集 -> 汇总生成全站公共「待补缺集大厅」或「断更/缺集排行榜」，引导众包成员集中精力查漏补缺。

### 12. 众筹求片与时效独占认领闭环 (Crowdfunded Bounty & Leased Claiming)
- **从单一悬赏到多人众筹催更**：单一用户发起的求片赏金有限，难以打动压制组与贡献者。应建立「众筹跟投（Urge / Add Bounty）」机制：同一 TMDB 作品或单集允许全站多位想看用户追加软妹币，动态累加总赏金池与“想看人数”热度，热度越高在大厅排位越靠前；
- **租约独占期防撞车 (Leased Claiming)**：压制组认领求片时必须分配时效独占期（如 24 小时 `claim_expires_at`），防止多人重复压制拉取导致带宽与算力碰撞浪费；超时未提交入库，系统定时无损解除认领回滚公海；
- **入库全量原子结算**：投稿经质检并真实入库 `accepted` 时，触发原子清算，将该条求片绑定的所有众筹软妹币总池一次性结算给认领人；撤单时则必须根据众筹账本按出资比例原路全额解冻退款。

### 13. 外挂字幕轻量贡献与自动洗名挂载轨道 (Subtitle Track Architecture)
- **降低贡献门槛**：全站许多冷门生肉影视缺少中文字幕，普通用户没有大宽带和压制环境，但极易贡献字幕；
- **独立外挂字幕质检与交付流**：支持 `.srt`, `.ass`, `.ssa`, `.vtt`，经文本编码探测与时间轴语法校验通过后，按 Emby 官方命名规范（`{title} - S01E01.{language}.default.ext` 或 `{movie} ({year}).{language}.default.ext`）物理落盘至目标媒体库对应 Season / 电影目录；
- **轻量即刻激励**：入库后立即通过总账派发微量代币（如 10 🪙），极大激发普通用户的参与热情。

### 14. 观影足迹打卡与月度日历留存闭环 (Watch Footprint & Calendar Retention)
- **从单纯入库到“看片-赚币-补片”闭环**：通过 Emby 播放事件或定时同步聚合用户的观影流水（播放时长、完播标记、设备标识）；
- **按月赛博日历热力看板**：聚合每日看剧集数、电影部数、观看总时长与本月常看 TOP 5 榜单；
- **每日观影打卡防刷**：设定门槛（如每日看片满 30 分钟）自动派发活跃打卡代币（5 🪙），通过数据库 `UniqueConstraint(user_id, reward_date)` 保证一人一天仅限领取一次。

### 15. 代币社交微循环与福利生态 (RedPacket & Lucky Wheel Economy)
- **代币沉淀与流动性瓶颈**：随着用户贡献与签到增多，仅靠官方商城容易代币沉淀；
- **社交红包广场 (RedPacket Plaza)**：支持拼手气、普通均分与暗号口令红包，发起时原子锁定，高并发领抢走 `SELECT ... FOR UPDATE` 悲观锁；二倍均值算法分配，最后一份全量兜底；
- **赛博幸运轮盘 (Lucky Wheel)**：小额代币单次转动，权重奖池涵盖代币回血、虚拟徽章以及 Emby VIP / 专线加速卡密（系统自动发货），有效回收系统内部代币。


