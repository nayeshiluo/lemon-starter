---
name: crowdsourced-media-pipeline
description: Use when building crowdsourced media ingestion systems.
version: 1.0.0
author: Lemon
license: MIT
metadata:
  hermes:
    tags: [media, emby, tmdb, pipeline, qbittorrent, ffprobe, deduplication, points-economy]
    related_skills: [emby-proxy-ops, pt-site-ops, telegram-media-harvester]
---

# 影视众包入库与查重流水线架构规范 (Crowdsourced Media Pipeline)

## 爬虫入库链路三大隐性故障（2026-09-04 实测）

### 1. 命名引擎版本脱钩（最危险）

同一份 `smart_media_parser.py` / `tmdb_helper.py` 被 **两个项目各存一份**（`lemon-ops-bot/` 与 `lemon-media-spider/`）。运维 Bot 那边修了 4 个 bug，爬虫这边还是旧版 —— md5 完全不同：

```
爬虫  smart_media_parser 5c5ed09e  tmdb_helper 717db392   ← 旧版
Bot   smart_media_parser cc3a7002  tmdb_helper 8ad449d8   ← 已修
```

爬虫侧旧 `tmdb_helper` 还带着已知失效的 `search/multi?&year=` 写法（TMDB 对 multi 端点不支持 year，会静默返回错误结果）。

**铁律**：命名引擎必须单一真源。改完一边立刻 `cp` 到另一边并 `md5sum` 三方对齐（本地 Bot / 本地爬虫 / VPS）。

### 2. 报告宣称的能力实际不存在

每日汇报里写「光鸭云盘：TMDB 规范化 + 全盘广告粉碎完毕」，但 `grep -rln "api.themoviedb.org" *.py` 只命中 `tmdb_helper.py` 自己 —— **全仓库无任何地方 import 它**，那句话是纯文案。实际只有 `clean_video_or_folder_name()` 做去广告前缀正则清洗。

排查手法：不要相信报告文案，直接 grep 外部 API 域名，再 grep 谁 import 了那个 helper。孤岛模块（无人调用）是这类假象的标志。

接上时必须设两条安全边界：
- **专区白名单**：只对常规影视（电影/剧集/动漫）做 TMDB 规范化。成人/里番/短剧的片名 TMDB 查不到，强行套用会被模糊匹配污染成无关作品。
- **未命中即不改**：TMDB 无结果或相关性不足时返回 `None`，保留去广告后的原名。宁可不改，绝不改错。

### 3. `dict.get(key, root_id)` 兜底污染云盘根目录

```python
# ❌ 原实现：任何非法 categories 都静默落进根目录
fid = folder_ids.get(cat_key, folder_ids.get('root'))

# ✅ 改为硬校验 + 拒绝下发
if cat_key not in set(FOLDER_MAP.keys()):
    logger.warning(f"[!] 跳过 id={res_id}：非法分类 {cat_key!r}，拒绝下发")
    continue
```

实测 38 条记录的 `categories` 被写成了豆瓣类型串（`中国大陆,剧情,汉语普通话`）甚至剧名本身（`紫罗兰永恒花园`）—— 爬虫早期把 `category_type` 字段搞错了。这些全部 `pushed_to_guangya=1`，即都曾按 root 下发过。

**这类 bug 完全静默**：不报错、不进日志，只能靠主动对账发现。配套脚本 `audit_categories.py`（只读审计 + `--fix` 带二次确认修正，按 channel→分类映射反推）。

## 去重机制（三层，实测健康）

| 层 | 机制 | 水位 |
|---|---|---|
| 磁力 | `resources.magnet_hash` UNIQUE 约束 | 8791 行 / 8791 唯一，重复 0 |
| TG 视频转存 | `is_already_transferred(conn, channel, msg_id)` 前置检查 | 448 条 `tg_` 前缀记录 |
| 零流量秒转 | `tg_forward_records` 三元组 `(source_channel, msg_id, dest_target)` + `INSERT OR IGNORE` | 416 行 |

回溯游标存在 `sync_cursors.oldest_synced_id`（12 个频道），支持 18+ 专区的历史库存持续深挖。

## When to Use
- 构建或重构基于 Emby / Jellyfin / TMDB 的影视众包入库、任务分发与查重系统；
- 需要在数据库层解决电影（NULL 季集）与剧集多集并发防重复入库冲突；
- 设计基于 qBittorrent 离线下载、FFprobe 视频质检与媒体库自动挂载的状态机；
- 设计高并发防双花、只增 Append-Only 的积分/代币原子流水总账与缺集悬赏池。

---

## 核心架构设计法则

### 1. 数据库决定最终唯一性 (Database-Level Anti-Duplicate)
- **拒绝单纯依赖应用层内存锁或 Python if**：必须通过数据库 Partial Unique Index 作为防并发抢单与重复入库的最终防线。
- **任务主体并发防重**：`media_tasks` 必须具备 `UNIQUE(tmdb_id, media_type)`，杜绝并发生成 Task 100 和 Task 101 绕过电影单次 Accepted 约束。
- **PostgreSQL / SQLite 电影与剧集防重索引**：
  ```sql
  -- 任务主体：同一 TMDB 作品 + 媒体类型 必须全局唯一
  ALTER TABLE media_tasks ADD CONSTRAINT uq_media_task_tmdb_type UNIQUE (tmdb_id, media_type);

  -- 电影：同一任务只能存在一个 ACCEPTED 条目 (规避 PostgreSQL NULL != NULL 问题)
  CREATE UNIQUE INDEX uq_accepted_movie_item 
  ON submission_items(task_id) 
  WHERE status = 'accepted' AND media_type = 'movie';

  -- 剧集：同一 task_id + season + episode 只能存在一个 ACCEPTED 条目
  CREATE UNIQUE INDEX uq_accepted_episode_item 
  ON submission_items(task_id, season, episode) 
  WHERE status = 'accepted' AND media_type != 'movie';
  ```

---

### 2. 状态机严格生命周期 (State Machine Lifecycle)
流水线必须保证单向幂等状态推进：
`PENDING` → `RESERVED` → `DOWNLOADING` → `INSPECTING` → `DELIVERING` → `WAITING_EMBY` → `ACCEPTED`
- **RESERVED**：带有 TTL（例如 2 小时）的任务抢占锁定；
- **DOWNLOADING**：基于真实下载增量与时间戳判断死种熔断，而非依赖轮询 tick 计数；
- **INSPECTING**：自动过滤 `sample/trailer/featurette`，通过 FFprobe 提取真实时长、分辨率、视频流编码与 4K 标志，硬性拦截 `<30s` 假视频骗分；
- **DELIVERING**：优先 Hardlink（自动检查源与目标是否在同一文件系统设备 `st_dev`，跨文件系统平滑降级为 Copy）；
- **WAITING_EMBY**：触发 Emby 媒体库扫描并轮询对账，**只有在 Emby 真实发现目标 TMDB 与季集后，才转为 ACCEPTED**；
- **ACCEPTED**：此时方可触发积分与悬赏结算。

---

### 3. 积分与经济总账强幂等性与零初始余额 (Idempotent Points Ledger & Zero Initial Balance)
- **User.balance 初始必须为 0**：禁止在 User 表默认值或 ORM 构造中预设 `balance=100`。新用户的初始代币、每日签到、投稿奖励必须 100% 严格委托 `PointsService.add_points()` 生成唯一流水，**杜绝在业务代码中额外执行 `user.balance += X` 导致账实不符与双发错账**；
- **Append-Only 只增流水账本**：禁止任何绕过账本直接修改余额的操作；
- **强幂等唯一键**：每一笔加币记录携带 `idempotency_key`（例如 `reward_subitem_{item_id}`），通过唯一索引拦截任何网络重试与 worker 崩溃重跑；
- **并发扣币安全**：使用 `SELECT ... FOR UPDATE` 行级锁确保余额不为负。

---

### 4. 业务逻辑归一化与统一领域服务 (Unified Domain Service)
- **Web API 与 Telegram Bot 必须共用统一的 `SubmissionService`**：严禁 Bot 单独写一套硬编码 `tmdb_id=0` 的粗糙投稿逻辑。Bot 的 `/upload` 必须与 Web 走相同的 TMDB 刮削、Redis 锁预抢占与状态机；
- **Redis 生产严格 Fail-Closed**：在生产环境中，若配置要求 Redis，当 Redis 掉线或加锁异常时，锁获取必须严格返回 `False`，接口直接返回 `503 / 409` 阻断提交，严禁降级放行导致重复离线下载上百 G 大文件。

---

### 5. 悬赏精准匹配与 Escrow 冻结
- **严格匹配元组**：`(tmdb_id, media_type, season, episode)`，严禁仅按 `tmdb_id` 模糊匹配，防止多集剧集串单结算；
- **真实押金冻结**：发布悬赏时立即扣除押金；完工时转给投稿人，取消时原路退回。

---

### 6. 缺集计算与多季区间压缩算法 (Multi-Season Missing Engine)
严禁将所有季度的集数压平计算（避免 S01E01 与 S02E01 混淆），必须以 Season 字典为单位计算：
```python
def calculate_multi_season_missing(season_defs: dict[int, int], accepted_tuples: list[tuple[int, int]]):
    # season_defs: {1: 12, 2: 24}
    # accepted_tuples: [(1, 1), (1, 2), (2, 1)]
    # 输出格式化标准区间: "S01E03-E12、S02E02-E24"
```

---

### 7. 多端统一身份绑定与资产防分裂机制 (Multi-Platform Identity Linking & Anti-Exploit)
- **拒绝多端孤立账户与双份初始代币**：Web 端（Emby 原生鉴权）与 Telegram Bot 若各自创建用户并赠送初始积分，会导致羊毛党利用多端接口无限套取积分，且权益与历史投稿记录断层；
- **单一权威身份原则**：Emby 账号是唯一权威身份，Telegram 只是它的一个接入端。必须彻底删除 `get_or_create_tg_user()` 这类"按 TG ID 建号"的函数 —— 留着它就一定会有某条代码路径调用它。未绑定用户发任何指令（`/start`、`/sign`、`/upload`，**含 Inline Keyboard 回调**）都只返回绑定引导，绝不建号、绝不发币；
- **两阶段安全绑定码体系 (Auth-Link Code)**：
  1. Telegram 用户通过 `/link` 申请一个带 TTL（10 分钟）的 6 位一次性绑定码；
  2. 用户在 Web 端个人中心（已登录 Emby 账号）输入该绑定码；
  3. 系统以数据库事务原子更新 `User.tg_user_id`，将 TG 临时资产/记录无缝合并至 Emby 主账号。

- **绑定码必须落库，不要只放 Redis**：绑定属于账号安全操作，需要持久审计痕迹（谁在何时把哪个 TG 绑到了哪个账号）；且"一次性消费"用数据库唯一约束 + 行锁比 Redis 更可靠。建 `tg_bind_codes` 表，字段 `code / tg_user_id / tg_username / expires_at / consumed_at / consumed_by_user_id`。
- **同一 TG 同时只允许一个未消费码**（防刷码扩大攻击面），用 Partial Unique Index 兜底：
  ```sql
  CREATE UNIQUE INDEX uq_tg_bind_active_code
  ON tg_bind_codes(tg_user_id) WHERE consumed_at IS NULL;
  ```
  重复 `/link` 复用未过期的码；已过期则清理后重新签发。
- **绑定码生成三要素**：① 用 `secrets` 而非 `random`；② 字符集剔除 `0/O/1/I/L` 等易混淆字符（用户要手抄）；③ 兑换时 `strip()` + `upper()` 容错，用户从 TG 复制常带空格与小写。
- **redeem 四重校验（缺一不可，全部在行锁内）**：① 码存在；② 码未消费；③ **当前账号未绑其他 TG**；④ **该 TG 未被他人绑定**。
- **严禁静默改绑 —— 改绑等于账号劫持**。已绑定账号拿到别人的码必须报错拒绝，要换必须先显式解绑。解绑不得触碰余额与流水（账本 Append-Only），绑定/解绑均写 `AuditLog`。
- **三个端点全部强制鉴权**（`status` / `redeem` / `unbind`）：匿名请求绝不允许决定账号归属。回归测试必须逐个断言匿名访问返回 401/403。
- **升级破坏性提示**：切换到此机制后，历史上靠 TG 自动建号的用户会变成"未绑定"，需走一次 `/link`。余额与流水都在原账号上不会丢，但必须提前告知用户，并准备一次性核对脚本列出这批人。

---

### 8. 状态机调度进化：从轮询扫表到事件驱动队列 (Event-Driven & Distributed Work Queue)
- **单进程轮询瓶颈**：单进程定时扫描活跃投稿表（`get_active_submissions`）在任务并发量扩大或网络等待长（如大文件离线、Emby 刮削延迟）时，会导致轮询锁表与推进滞后，且无法横向扩展多 Worker；
- **事件驱动 + 轮询兜底（推荐落地形态，实测唤醒延迟 0.3s vs 轮询平均 7.5s）**：
  - Worker 主循环用 Redis `BRPOP` 阻塞等待唤醒队列，而不是 `asyncio.sleep(N)`。无事件时 BRPOP 自然超时，等价于一次常规轮询节拍 —— 一套代码同时是"睡眠"和"被唤醒"；
  - **必须选 Redis 队列而非 `asyncio.Event`**：后者只在单进程内有效，多副本部署直接失效；
  - 事件源：qBittorrent「Torrent 完成时运行外部程序」调 Webhook、新投稿受理后 `signal_wake()`；
  - Redis 不可用时自动退化为 `asyncio.sleep` 轮询，绝不因缺 Redis 停摆；
  - 自适应间隔：有推进用短间隔（15s）快跟进后续阶段，连续空转数轮放宽到长间隔（60s），降低数据库空转扫表。
  ```python
  class RedisManager:
      WAKE_QUEUE_KEY = "myapp:pipeline:wake"      # key 必须带命名空间，防撞键

      async def signal_wake(self, reason: str) -> bool:
          if not self.client: return False
          try:
              await self.client.lpush(self.WAKE_QUEUE_KEY, reason)
              await self.client.expire(self.WAKE_QUEUE_KEY, 60)   # 防陈旧 token 堆积
              return True
          except Exception:
              return False                          # 静默失败，轮询兜底会接住
  ```
- **⚠️ BRPOP 会被 redis-py 的 socket 读超时误杀（真实踩坑，务必看下一条）**。

#### 8a. redis-py 阻塞命令必须用独立连接（血案）
- **现象**：日志反复 `Timeout reading from <host>`，事件驱动静默退化成纯轮询。功能不坏、任务不丢，但优化目标完全没达成 —— 极易被当成"偶发网络抖动"忽略过去。
- **根因**：`redis.asyncio.from_url()` 不显式传 `socket_timeout` 时，连接实际带着 `orig_socket_timeout=5`（5 秒读超时）。任何等待超过 5 秒的阻塞命令都会被判读超时抛 `TimeoutError`。实测对照：
  | 写法 | `BRPOP(20)` 实际行为 |
  |---|---|
  | `from_url(默认)` | **5.01s 抛 TimeoutError** |
  | `from_url(socket_timeout=None)` | 20.01s 正常等满 |
  | `from_url(socket_timeout=25)` | 20.09s 正常等满 |
- **诊断手法**：`client.connection_pool.connection_kwargs` 里看不到 `socket_timeout` 键不代表没有超时 —— 真正生效的是 `orig_socket_timeout`。直接打印整个 dict 对比默认与显式两种构造。
- **修法：区分两类连接，不要混用一个客户端**（混用做不到既快速失败又能长阻塞）：
  ```python
  FAST_SOCKET_TIMEOUT_SECONDS = 5        # 普通命令：Redis 卡住时快速失败
  MAX_BLOCKING_WAIT_SECONDS   = 300      # 单次 BRPOP 阻塞上限
  BLOCKING_SOCKET_TIMEOUT_MARGIN = 15    # 余量：确保 Redis 先返回、socket 后超时

  self.client = from_url(url, socket_timeout=FAST_SOCKET_TIMEOUT_SECONDS, ...)
  self._blocking_client = from_url(
      url, socket_timeout=MAX_BLOCKING_WAIT_SECONDS + BLOCKING_SOCKET_TIMEOUT_MARGIN, ...)
  ```
  并对调用方传入的等待时长做上限钳制：`wait = max(1, min(int(t), MAX_BLOCKING_WAIT_SECONDS))`，防止配置写大后又超出 socket 读超时。
- **回归断言（纯静态、不需要真 Redis）**：阻塞连接读超时 > 最长阻塞时长；主客户端读超时 < 阻塞级别；配置的轮询间隔 ≤ 阻塞上限；`wait_for_wake` 必须走 `blocking_client`。
- **教训**：这个缺陷单测发现不了（mock 的 Redis 替身没有 socket 层）。**事件驱动这类"延迟优化"必须真机跑一遍并盯日志窗口**，否则你以为优化了、实际一直在走兜底路径。

#### 8b. 多 Worker 并发推进必须加单条独占锁
- 单进程扫全表的实现一旦部署多副本，同一条投稿会被多个 Worker 同时推进 —— 重复 `add_torrent`、重复交付落盘，甚至在 Emby 确认阶段并发发币。
- 每条投稿推进前先抢 `pipeline_advance:{id}` 独占锁，抢不到就跳过交给持有者。**TTL 必须大于单条最慢阶段耗时**（通常是 `inspecting`：多文件 ffprobe），持有者崩溃后锁自动过期不会永久卡死。
- `run_state_machine_cycle()` 改为**返回本轮推进条数**，供调度器决定快跟进还是放宽间隔。
- **Redis 宕机时的日志纪律**：生产 Fail-Closed 停摆是正确取舍（金钱操作宁可停摆不可重复），但**日志绝不能谎报成"另一个 Worker 正在推进"**，否则排障时会把 Redis 宕机误判成正常的多副本竞争。必须先 `ping()` 探测，宕机时打一条独立的 `PIPELINE_HALTED` ERROR 说明"因 Fail-Closed 保护而全部暂停"。

#### 8c. qB 完成 Webhook 的安全与责任边界
- 端点只负责**投递唤醒信号**，绝不在请求线程里跑重活 —— 避免 qB 回调超时把流水线拖垮，也杜绝被刷接口打满 CPU。
- 共享密钥鉴权，用 `secrets.compare_digest` 防时序侧信道。**密钥未配置时直接 503 拒绝（Fail-Closed）**，绝不允许无鉴权的公网端点触发内部流水线。
- 支持 Header 与查询参数两种传密钥方式（qB 的"运行外部程序"配置有时不便加 Header）。
- **唤醒信号投递失败仍返回 200**：轮询兜底会接住该任务，返回 5xx 只会让 qB 反复重试刷日志。
- qB 侧配置：设置 → 下载 → Torrent 完成时运行外部程序
  `curl -s -X POST "http://host:8000/api/webhooks/qb/complete?torrent_hash=%I" -H "X-Webhook-Token: <token>"`

- **生产级核对清单**：详细交付验收与测试步骤请参考 [references/production-checklist.md](references/production-checklist.md)。
- **单文件 Vue SPA 结构校验器**：改动前端 Tab / ref 后必跑 `scripts/verify_spa_structure.py`（标签配平 + Tab 声明与面板一一对应 + setup() 导出完整性）。用法见脚本 docstring。

---

## 避坑指南与生产级防线 (Critical Pitfalls & Traps)

1. **新旧双轨未接通陷阱 (Dual-Track Architecture Trap)**：
   - 重构时切勿只新建 `services/` 或 `models/` 而忘记切断旧的 `main.py`、`routes/` 与 `pipeline.py`。
   - 彻底删除废弃的旧单文件，并在 CI/测试中必须加入 `from backend.main import app` 与 `/api/health` 的完整启动 Smoke Test。
2. **Alembic 容器启动接管与索引漂移 (Alembic Startup Takeover)**：
   - 生产环境中必须由容器入口 `entrypoint.sh` 执行 `alembic upgrade head`，生产代码彻底移除隐式 `create_all()`。
   - 必须确保 Alembic Migration 脚本中显式包含全部 Partial Unique Indexes，运行 `alembic check` 验证零偏差。
3. **集数解析盲区误判 (Episode Mapping Fallback Risk)**：
   - 剧集多文件解析时，若无法从文件名提取集数，**必须标记 `REJECTED_NEEDS_EPISODE_MAPPING` 拦截**，绝不可无脑默认反推为 `S01E01`。
4. **TMDB 失败必须分类透出，严禁压成一个 `return None`**：
   - Fail-Closed 阻断任务是对的（严禁默认创建 `total_items_count=1` 的单集假任务），但**"拦下来"和"说清为什么"是两件事**；
   - **反模式**：客户端把未配置 key、凭证无效、条目不存在、限流、网络故障全压成 `return None` / `return []`。上游只能报"无法从 TMDB 获取权威元数据，操作已拦截" —— 运维看到这句会去查 TMDB ID 与网络，而真正原因常常是**服务端根本没配 API Key**，错误信息把人指向完全错误的方向。搜索接口更糟：静默返回空列表，用户会以为"TMDB 里没这部剧"，然后一直换关键词白折腾；
   - **正解**：定义错误分类枚举 + 两个语义属性供上游决策：
     ```python
     class TMDBErrorKind(str, Enum):
         NOT_CONFIGURED = "not_configured"   # 未配置凭证（含占位符）
         UNAUTHORIZED   = "unauthorized"     # 401/403 凭证无效
         NOT_FOUND      = "not_found"        # 404 确认无此条目
         RATE_LIMITED   = "rate_limited"     # 429
         UPSTREAM_ERROR = "upstream_error"   # 5xx
         NETWORK_ERROR  = "network_error"    # 超时/DNS/连接失败

     class TMDBError(Exception):
         @property
         def is_config_problem(self) -> bool:   # → 提示管理员，不要怪用户输入
             return self.kind in (NOT_CONFIGURED, UNAUTHORIZED)
         @property
         def is_transient(self) -> bool:        # → 稍后重试，不应把投稿判死
             return self.kind in (RATE_LIMITED, UPSTREAM_ERROR, NETWORK_ERROR)
     ```
   - **HTTP 映射**：`is_config_problem` 或 `is_transient` → 503（含明确原因）；其他上游异常 → 502；`NOT_FOUND` 与参数问题 → 400。前端必须原样透出 `detail`，禁止吞掉非 200 响应；
   - **占位符必须识别为未配置**：`.env.example` 里的 `your_tmdb_api_key_here` 会被当成真 key 发出去，换回一个含义模糊的 401，排查又多绕一圈。用 `any(p in key.lower() for p in ("your_","xxx","change_me","replace"))` 拦掉；
   - **v3 API Key 与 v4 Read Access Token 必须自动识别**：v4 token 是 JWT（`eyJ` 开头、两个点），必须走 `Authorization: Bearer` 且**不得再带 `api_key` 查询参数**，混用一律 401。TMDB 官网现在默认给的就是 v4 token，只支持 v3 的实现会让人以为是 key 申请错了：
     ```python
     @property
     def uses_bearer_token(self) -> bool:
         return self.api_key.startswith("eyJ") and self.api_key.count(".") == 2
     ```
   - **暂时性故障做指数退避重试**（3 次 / 0.5s-1s-2s），凭证问题立即失败不浪费重试。TMDB 偶发 429/5xx/超时很常见，一次抖动就把用户投稿判死不可接受；
   - **日期解析要防脏数据**：`int(release_date.split("-")[0])` 遇到空串或非数字会抛 `ValueError` 打挂整条查询，必须 `if head.isdigit()` 后再转，否则降级为 `year=None`；
   - **`health_check()` 比"key 是否非空"有意义得多**：真实打一次 `/configuration` 探测，返回 `{ok, kind, auth_mode, detail}`，接入 `/health/ready` 与管理面板，让管理员一眼看清是"没配"、"配错"还是"网络不通"（境内服务器连不上 `api.themoviedb.org` 是常见情况，报错要点明可能需要代理）。**该函数被就绪探针调用，任何情况下都不能抛异常**。
5. **交付失败与 WAITING_EMBY 严格隔离 (Delivery Failure Isolation)**：
   - 只有物理落盘成功且处于 `waiting_emby` 的条目才允许向 Emby 对账；若条目 `failed/rejected`，即使 Emby 历史库内恰好已存在同名资源，也绝对不可复活或触发发币。
6. **宿主机 vs 容器内部路径隔离与 qB 强制 save_path (Host vs Container Path Mapping & Forced save_path)**：
   - 配置与 Compose 必须区分 `HOST_*`（宿主机挂载点）与 `CONTAINER_*`（程序内部读取路径），防止换路径部署后 `os.path.exists()` 误报文件丢失。
   - 调用 qB WebAPI 添加种子时必须显式传参 `save_path=CONTAINER_DOWNLOAD_PATH`，杜绝依赖 qB 默认分类目录导致的文件落地漂移。
7. **真实就绪度探针与生产安全 Fail-Closed (True Readiness Probe & Security Fail-Closed)**：
   - `/api/health/ready` 必须执行真实数据库 `SELECT 1` 与 Redis PING 探测，数据库异常时严格返回 `503 Service Unavailable`。
   - `APP_ENV=production` 时，只要 `SECRET_KEY` 为空或使用示例占位符，必须无条件抛出异常拒绝启动。
8. **Redis 分布式锁 + 任务预抢占前置阻断 (Pre-Download Concurrency Guard)**：
   - 在将磁力提交至下载器之前，必须先获取 `submit_lock:{tmdb_id}:{media_type}` 并校验任务是否已存在/正在下载。若已有活跃任务，立即返回 HTTP 409 拦截，杜绝多用户并发下载重复百 G 大文件造成带宽与磁盘极大浪费。
10. **SKIP 冲突策略防冒领发币 (SKIP Conflict & Anti-Exploit Guard)**：
    - 当目标目录已存在历史异源文件且配置为 `SKIP` 时，**交付适配器必须返回 `success=False`**，条目直接标记 `failed`，绝不进入 `waiting_emby`。严禁返回 `success=True` 导致历史已有资源被 Emby 扫描后误发币（冒领刷币漏洞）。
11. **同种内同集多画质择优去重 (Intra-Torrent Episode Resolution Deduplication)**：
    - 当一个种子内意外包含同一单集的不同分辨率文件（如 1080p 与 720p）时，质检阶段必须按 `(season, episode)` 进行聚合，优先保留 `4K / 1080p + 最大体积` 的最佳文件，防止同一任务内部产生自碰撞死锁。
12. **前端分页契约与接口错位对齐 (Frontend Pagination & Method Contract)**：
    - 后端统一分页化返回 `{items: [...], total: N}` 后，前端必须解构为 `data.items || []`，禁止直接将分页对象赋值给列表；
    - 确保前端“我的任务/历史”调用正确的 GET 路由（如 `/api/submissions/my`），杜绝误调 POST 投稿端点。
13. **Telegram Bot 回调与悬赏押金退款闭环 (Bot Callbacks & Escrow Refund)**：
    - Bot 必须显式注册 `CallbackQueryHandler` 处理全部 Inline Keyboard 按钮，避免点击无响应；
    - 真实 Escrow 冻结的悬赏必须提供明确的取消与全额退款流（`bounty_refund`），防止用户代币被死锁。
14. **指定单集严格过滤收口 (Target Episode Inspection Filter)**：
    - 当用户指定单集（如 S01E07）投稿时，质检阶段在多文件扫描后必须强行过滤为 `candidates_by_episode = {target_key: candidates[target_key]}`，只为目标单集生成条目并交付发币，**绝对禁止将种子大包中未预占的其他集数顺带入库发币**。
15. **SAVEPOINT 局部事务隔离防护 (Savepoint Isolation in Batch Acceptance)**：
    - 在多集逐项推进 `accepted` 状态时，必须采用 `async with db.begin_nested():` 隔离单项并发 Partial Unique 冲突；
    - 遭遇并发唯一冲突时，只局部回滚该项为 `rejected`（记录 `DUPLICATE_AFTER_DOWNLOAD`），**严禁调用全局 `session.rollback()` 导致同一批次前置已确认单集及其 PointsLedger 流水被连带回滚**。
16. **失败重试物理清理旧执行态与预估/实发奖励解耦 (Clean Execution State on Failed Retries & Reward Decoupling)**：
    - 预估奖励 `estimated_reward_points`（用于展示）与实发奖励 `reward_points`（初始为 0，发币后才累加）必须严格解耦；
    - 复用 `failed/rejected` 历史 Submission 重试时，校验 `reward_points == 0`，并必须物理删除旧 `SubmissionItem` 与重置 `DownloadJob`，杜绝新老批次脏数据叠加。
17. **终态异常即时释放 TaskItem 预占 (Instant Reservation Release on Terminal Failures)**：
    - 遭遇任何终态失败（TMDB 失败、死种、qB 致命错误、质检不符、交付落盘失败、Emby 超时）时，必须即时将目标 `TaskItem` 恢复为 `missing`，无需等待 2 小时 TTL 超时。
18. **Alembic 迁移历史不可变增量版本链 (Immutable Alembic Migration Chain)**：
    - 严禁重写/覆盖 Base Migration！一旦数据库已有部署，后续表结构调整必须通过 `alembic revision --autogenerate` 生成增量 Revision 文件，并带 `alembic check` 验证零偏差，确保老版本数据库执行 `alembic upgrade head` 能平滑无损升级。
19. **公共投稿广场脱敏防泄露 (Public Feed Desensitization)**：
    - 全站公共接口（如 `GET /api/submissions/all`）必须采用专用的 `PublicSubmissionResponse`，**物理剔除 `magnet_uri`, `torrent_hash`, `source_file`, `dest_file`, `error_message`**，防止普通用户抓包盗取其他用户贡献的私密磁力资源。
20. **剧集强校验禁止假全季绕过预占 (Strict Episodic Target Validation)**：
    - 剧集/动漫/综艺投稿在 Schema 校验层必须强制要求 `season >= 0` 与 `episode >= 1`，禁止 `episode=NULL` 假全季整包模式绕过单集预抢占与活跃唯一索引保护。
21. **Emby 最终对账增加 `expected_dest_path` 物理路径严格比对 (Physical File Path Verification)**：
    - 在对账验证时不仅比对 TMDB ID 与季集序号，更进一步比对 Emby 刮削到的文件真实路径/基准名是否等于本次交付落盘的 `expected_dest_path`，从根本上证明确认的是“本次投稿交付的物理文件”，杜绝库中偶然存在的同名旧资源冒领发币。
22. **Alembic 历史数据平滑增量升级三步法 (Safe Incremental Migration Pattern)**：
    - 在已有海量数据的生产表上添加新字段时，严禁直接 `nullable=False`（无默认值会导致升级直接报错中断）；
    - 必须采用安全三步变更：`op.add_column(nullable=True, server_default='0')` → `op.execute(UPDATE existing ...)` → `op.alter_column(nullable=False)`。
23. **统一规范 Canonical TMDB 媒体身份防重 (Canonical TMDB Media Identity)**：
    - 针对 `tv` / `anime` / `variety` 等 TMDB 统一归属于 Series 的剧集类型，任务主体防重必须强制规范化为统一的 `canonical_media_type="tv"`，`category` 仅作为业务分类属性，防止通过切换 `anime/variety` 生成多个独立 Task 绕过防重。
24. **悬赏取消与入库结算悲观行锁互斥 (Pessimistic Locking on Escrow Operations)**：
    - 在悬赏取消退款（`bounty_refund`）与入库发赏（`bounty_claim`）两个并发链路中，对目标 `WantedTask` 必须执行 `SELECT ... FOR UPDATE` 悲观行锁，并在锁内二次校验状态，防止同一笔押金在并发竞态下发生双重支付；
    - **⚠️ 结算侧与取消侧的可接受状态集合不同，严禁两边都写 `status == 'open'`**：
      - 可结算（发赏）：`IN ('open', 'claimed')` —— `claimed` 表示已认领但尚未交付，真实入库后同样必须发赏；
      - 可取消（退款）：仅 `('open',)` —— 已认领的悬赏不允许发布者单方面撤销。
    - **实战血案**：`repo.find_exact_bounties()` 里写对了 `IN ('open','claimed')`，但 pipeline 结算处另起一条 `select(...).where(status == "open")` 硬编码绕过了它。结果 `claimed` 悬赏在投稿真实入库 `accepted` 后仍停在 `claimed`，**押金既不退给发布者、也不发给投稿人，凭空锁死在系统里**。20 项 Service 单测全绿，完全没发现。
    - **根因是状态字面量分散硬编码**。修法：在 model 层建立单一真源常量，所有结算/取消路径必须引用它，禁止各处自行写字符串：
      ```python
      # models/wanted.py —— 单一真源
      SETTLEABLE_BOUNTY_STATUSES  = ("open", "claimed")   # 可发赏
      CANCELLABLE_BOUNTY_STATUSES = ("open",)             # 可退款

      # repo：结算查询统一入口，带可选行锁
      async def find_exact_bounties(self, tmdb_id, media_type, season, episode,
                                    for_update: bool = False):
          stmt = select(WantedTask).where(
              WantedTask.tmdb_id == tmdb_id,
              WantedTask.media_type == media_type,
              WantedTask.season == season,
              WantedTask.episode == episode,
              WantedTask.status.in_(SETTLEABLE_BOUNTY_STATUSES),
          )
          if for_update:
              stmt = stmt.with_for_update()
          return list((await self.db.execute(stmt)).scalars().all())
      ```
    - **审计手法**：全仓 `grep -rn "status == \"open\"\|status.in_(\[" ` 逐一核对，凡是绕过 repo 统一入口自行拼 where 的地方都是嫌疑点。

24b. **电影悬赏季集必须归一化为 NULL (Movie Bounty NULL Season Normalization)**：
    - 结算侧按 `(tmdb_id, media_type, season, episode)` 精确匹配，电影的季集是 `NULL`（SQL 编译为 `season IS NULL AND episode IS NULL`）；
    - 但 Pydantic Schema 常给 `season: Optional[int] = Field(default=1)` 这类**非 None 默认值**。电影悬赏一旦带着 `season=1` 落库，就与 `IS NULL` 永久错配 —— **押金一扣即永久冻结，且不会报任何错**；
    - 建单入口必须显式归一化，不能依赖调用方传对：
      ```python
      if canonical_media_type == "movie":
          target_season = target_episode = None      # 强制 NULL
      else:
          if req.season is None or req.episode is None:
              raise HTTPException(400, "剧集悬赏必须指定季集")
          target_season, target_episode = req.season, req.episode
      ```
    - 回归断言：`POST /wanted` 建电影悬赏后，响应里 `season is None and episode is None`。
25. **磁力 Base32 BTIH 自动规范化与种子丢失恢复 (BTIH Normalization & Torrent Recovery)**：
    - 磁力解析时必须将 32 位 Base32 BTIH 统一解码并转换为标准 40 位 Hex 小写，保证数据库防重与下载器索引一致；
    - 下载状态机中若遭遇 qB 种子任务意外丢失超过 3 分钟自动触发重推，超过 10 分钟持续丢失则熔断为 `FAILED_QB_MISSING` 并即时释放锁定的 `TaskItem`。
26. **未实现交付适配器严格 Fail-Closed (Delivery Adapter Fail-Closed)**：
    - 交付工厂方法（如 `get_delivery_adapter()`）在检测到非 `local` 且未实现的适配器配置时（如 `DELIVERY_ADAPTER=guangya`），**必须抛出 `NotImplementedError` 并在启动阶段拒绝服务**，严禁静默偷跑本地落盘假装成功。
27. **失败重试时同步更新 TMDB 身份 (Sync Identity on Failed Retries)**：
    - 当用户对此前失败的任务修正 TMDB ID 并重试时，除了更新 `task_id` 外，必须显式同步更新 `Submission.tmdb_id` 与 `Submission.media_type`，杜绝后续 Delivery 命名与 Emby 对账时 Task 与 Submission 内部身份错位。
28. **悬赏创建必须强制保存 Canonical Media Type (Canonical Type on Bounty Creation)**：
    - 悬赏创建入口必须将 `media_type` 统一转为规范类型（如 `anime/variety -> tv`）持久化至 `WantedTask`，确保后续入库结算时 `exact_bounties` 能够精准匹配。
29. **CI 必须包含历史数据平滑升级断言 (Upgrade Existing Database Test)**：
    - 仅对全新空数据库执行 `alembic upgrade head` 无法发现已有数据表添加 `nullable=False`（缺少默认值）导致的生产升级崩溃；
    - CI 必须构建或提供包含已有历史数据的数据库测试分支，实测验证在有既有数据的场景下执行 Migration 是否无损平滑通过。
30. **多端账号资产分裂与羊毛漏洞 (Multi-Platform Asset Splitting & Faucet Exploit)**：
    - 严禁 Telegram Bot 在首次 `/start` 时无脑创建带有初始代币的独立 `User`，否则攻击者可通过切换 TG 账号与 Web 账号无限刷初始积分；
    - Telegram 端必须默认仅作为受限交互界面，强制要求通过 `/link` 绑定码与 Emby 账号原子绑定后才开放积分流转与投稿权益。
31. **测试默认跑在生产语义下（假信号制造机）**：
    - `settings.APP_ENV` 默认值若为 `"production"`，本地不导 `APP_ENV=testing` 直接 `pytest` 会挂掉一批用例 —— 因为生产下 `RedisLock` 是 Fail-Closed 的（无 Redis 则拒绝获取锁）。CI 里导了环境变量所以全绿，本地却红，这种"CI 绿本地红"的假信号会浪费大量排查时间；
    - **修法：把它固定在 `tests/conftest.py`，让测试结果不依赖外部环境变量**：
      ```python
      @pytest.fixture(autouse=True)
      def _force_testing_env(monkeypatch):
          monkeypatch.setattr(settings, "APP_ENV", "testing", raising=False)
          yield
      ```
    - 需要验证生产语义的用例（如 Fail-Closed 停摆）在用例内部再 `monkeypatch` 回 `production` 即可。
32. **前端插入新 Tab 极易嵌套错位，必须用解析器校验而非肉眼看 diff**：
    - 在单文件 Vue（`index.html`）里插入新 Tab 面板时，把新面板的开标签插到了旧面板的开标签之后，导致 `<div v-if="admin">` 的开标签留在 `profile` 面板外面 —— diff 看起来完全正常，页面渲染却错乱；
    - **写完必跑的静态校验脚本**（见 `scripts/verify_spa_structure.py`）：① `html.parser` 子类做标签配平；② 正则比对导航声明的 Tab id 集合与模板 `v-if="currentTab === 'x'"` 集合必须一一对应；③ 断言新增的 ref/函数都出现在 `setup()` 的 `return {}` 里（漏掉不会报错，只是模板里静默失效）；
    - 教训：**"肉眼审 diff 通过"不算验证**。这类结构错误单测覆盖不到，必须有机械校验。

