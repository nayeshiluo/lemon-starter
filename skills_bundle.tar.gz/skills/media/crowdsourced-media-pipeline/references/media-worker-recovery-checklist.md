# 多目标媒体 Worker 恢复验收清单

## 变更前
1. 记录源频道、目标目录 ID、数据库 `min/max(msg_id)`、真实视频数与非视频辅助消息数。
2. 备份 Worker 源码、同步 SQLite、Telegram session、各云盘凭证；记录 SHA-256。
3. 确认只有一个 systemd Worker 实例，停止旧实例后清理 0 字节和半成品缓存。

## Worker 设计检查
- 每个目标独立状态：`gdrive_status` / `guangya_status` / file ID / error / retry。
- 主补传队列按主目标未成功筛选；主目标成功后不得因次目标失败而重复下载。
- 下载与每个上传均有硬超时；异常后清理缓存并保留可重试状态。
- 固定最新 N 条不能作为唯一扫描策略；必须分页/游标回溯。
- 最终文件名按 UTF-8 字节数限制，并追加稳定消息 ID；测试中文长名、URL、Markdown、推广语和空 caption。
- 媒体自身文件名优先；相邻上下文只允许同一 forward 来源，禁止频道串片。

## 运行中逐步验收
1. 首轮日志中的待处理数应等于真实未完成视频数，不应把海报计入。
2. 观察一条：GDrive 失败时光鸭仍能成功，数据库呈 `failed/success`。
3. 观察一条：光鸭超时或 502 时 Worker 跳过该条并继续下一条，缓存可清理。
4. 检查 `systemctl active`、应用日志、数据库水位、PID WCHAN、`lsof` 和缓存目录，不能只看 systemd 状态。
5. 每批记录数据库状态分布、成功数量、剩余数量和最新消息 ID。

## 分类纠偏
- 先读取原始 forward 来源、caption、同来源上下文和云盘文件名。
- 混发频道不得按频道全量搬迁；只处理证据明确的文件。
- 云盘移动后必须回读目标目录，按 file ID 验证；数据库按消息 ID 或稳定 file ID 更新，禁止按重复文件名批量更新。
- 不确定的项目保留原目录并生成清单。

## GDrive 重新授权
- Desktop OAuth 客户端没有重定向 URI配置；OAuth Playground 需要 Web application 客户端，并精确添加 `https://developers.google.com/oauthplayground`。
- 回调出现 `code` 不等于完成；必须兑换后看到 HTTP 200 和 access/refresh token。
- 新 Token 必须与新 Client ID/Secret 成对部署；先验证 Drive `about`、目标目录权限和小文件上传，再跑积压补偿。
- Token、refresh token、client secret、完整 OAuth JSON 不进聊天；用户优先以权限 600 的文件直接放服务器。
- 检查 OAuth Consent Screen 是否为 Testing；长期 Worker 应按 Google 当前要求发布 Production，避免 7 天 refresh token 失效。

## 终态验收
- 主目标成功数达到真实视频积压数；
- GDrive 补偿目标全部成功或有明确失败清单；
- 数据库状态与云盘实际目录逐条/按 file ID 对账；
- 临时缓存为空且无 0 字节残留；
- Worker active 且应用层持续输出正常轮询日志；
- 最终报告明确区分“已完成、进行中、阻塞”，绝不以 active 或单次 API success 冒充全链路完成。
