# 影视众包系统生产级自测与交付核对清单 (Production Verification Checklist)

本清单用于指导并验证基于 Emby / TMDB / qBittorrent 的众包入库系统是否达到真正可部署、可持久化、可防刷的生产标准。

---

## 1. 架构与启动闭环 (Architecture & Startup)
- [ ] **单轨收口**：已彻底移除旧的原型单文件（如根目录下残留的 `models.py`, `pipeline.py`, `emby_client.py` 等），主程序 `main.py` 正式接入分层 `services/` 与 `routes/v1/`。
- [ ] **应用级 Smoke Test**：测试套件中包含 `from backend.main import app`，并向 `/api/health` 和 `/api/health/ready` 发起真实 ASGI 请求验证进程存活与外部配置就绪度。
- [ ] **编译无语法/导入错误**：运行 `python3 -m compileall backend` 返回 0 退出码。
- [ ] **测试不依赖外部环境变量**：`tests/conftest.py` 里有 `autouse` fixture 把 `settings.APP_ENV` 钉为 `testing`。不导任何环境变量直接 `pytest` 与 CI 带环境变量跑，结果必须一致（防"CI 绿本地红"假信号）。
- [ ] **前端 SPA 结构机械校验**：改过 Tab / ref 后跑 `scripts/verify_spa_structure.py`，标签配平、Tab 声明与面板一一对应、新增标识符已从 `setup()` 导出 —— 三项全过。肉眼审 diff 不算验证。

---

## 1b. 外部依赖失败可诊断性 (External Dependency Diagnosability)
> 目标：任何一次失败，运维读一眼报错就知道该改配置、该等一会儿、还是该改输入。

- [ ] **TMDB 错误分类透出**：客户端抛带 `kind` 的异常（`not_configured` / `unauthorized` / `not_found` / `rate_limited` / `upstream_error` / `network_error`），不再统一 `return None`。
- [ ] **占位符识别**：`.env.example` 的 `your_xxx_here` 被判为「未配置」，不会被当真凭证发出去换回一个含义模糊的 401。
- [ ] **v3 / v4 凭证格式自动识别**：JWT（`eyJ` 开头两个点）走 `Authorization: Bearer` 且不带 `api_key` 参数；32 位 hex 走查询参数。混用会一律 401。
- [ ] **暂时性故障重试**：429/5xx/超时做 3 次指数退避；凭证问题立即失败不浪费重试。一次网络抖动绝不把用户投稿判死。
- [ ] **HTTP 语义正确**：配置问题与暂时故障 → 503（含原因）；其他上游异常 → 502；条目不存在/参数错 → 400。前端原样透出 `detail`，不吞非 200 响应。
- [ ] **`health_check()` 真实探测**：打一次轻量端点而不是只看 key 非空，返回 `{ok, kind, auth_mode, detail}`，接入 `/health/ready` 与管理面板。该函数被就绪探针调用，任何情况下不得抛异常。
- [ ] **未配置时的端到端复验**：清空 `TMDB_API_KEY` 实跑一次搜索接口，确认返回 503 且 `detail` 明确指出「服务端未配置」，而不是空列表。

---

## 1c. 事件驱动调度真机验收 (Event-Driven Scheduling Live Verification)
> 这一节**必须真机跑**。事件驱动的缺陷单测发现不了（mock 的 Redis 替身没有 socket 层），
> 很容易"以为优化了、实际一直在走轮询兜底路径"。

- [ ] **阻塞命令独立连接**：`BRPOP` 走专用客户端，其 `socket_timeout` > 单次最长阻塞时长；主客户端保持短读超时（Redis 卡住时快速失败）。
- [ ] **BRPOP 实测等满**：真机跑 `BRPOP(8/20/35)`，三次都应等满而非在 ~5s 抛 `TimeoutError`。**redis-py 默认 `orig_socket_timeout=5`，这是最容易踩的坑**。
- [ ] **唤醒延迟亚秒级**：长等待（如 120s）中途投递事件，实测唤醒延迟 < 1s。
- [ ] **服务日志观察窗干净**：真实启动服务并观察至少一个轮询周期，日志里不应出现任何 `wait_for_wake failed` / `Timeout reading from` 告警。
- [ ] **等待时长上限钳制**：配置写成超大值时被钳制到上限，不会超出阻塞连接的 socket 读超时。
- [ ] **多 Worker 独占锁**：单条投稿推进前抢 `pipeline_advance:{id}`，锁被他人持有时本轮跳过且**不调用下载器**。`run_state_machine_cycle()` 返回推进条数。
- [ ] **Redis 宕机日志诚实**：生产 Fail-Closed 停摆时打独立的 `PIPELINE_HALTED` ERROR，**不得**谎报成"另一个 Worker 正在推进"（否则排障会把宕机误判成正常竞争）。
- [ ] **Webhook 鉴权三态**：无密钥 401、错误密钥 401、正确密钥 200；密钥未配置时端点 503 拒绝（Fail-Closed）。用 `secrets.compare_digest` 比对。
- [ ] **Webhook 失败仍 200**：唤醒信号投递失败（Redis 宕机）仍返回 200，靠轮询兜底接住 —— 返回 5xx 只会让 qB 反复重试刷日志。

---

## 1d. Telegram 绑定安全边界 (TG Bind Security)
- [ ] **`get_or_create_tg_user()` 已从全仓移除**：`grep` 确认无残留调用（留着它就一定会有路径调用它）。
- [ ] **未绑定用户全链路拒绝**：`/start`、`/sign`、`/upload` **以及 Inline Keyboard 回调**都只返回绑定引导，不建号不发币。
- [ ] **绑定码落库 + Partial Unique**：`tg_bind_codes` 表存在，`uq_tg_bind_active_code (tg_user_id) WHERE consumed_at IS NULL` 已建。
- [ ] **码生成三要素**：`secrets` 而非 `random`；字符集无 `0/O/1/I/L`；兑换时 `strip()` + `upper()` 容错。
- [ ] **redeem 四重校验（行锁内）**：码存在、码未消费、当前账号未绑其他 TG、该 TG 未被他人绑定。
- [ ] **严禁静默改绑**：已绑定账号拿别人的码必须报错；要换须先显式解绑。
- [ ] **端点强制鉴权**：`status` / `redeem` / `unbind` 三个端点匿名访问均返回 401/403。
- [ ] **绑定解绑不动钱**：前后余额与流水完全一致；两个动作都写 `AuditLog`。
- [ ] **升级影响已评估**：历史靠 TG 自动建号的用户会变"未绑定"，已准备核对脚本列出这批人并提前告知。

---

## 2. 数据库与迁移一致性 (Database & Alembic Migration)
- [ ] **Alembic Schema 零偏差**：运行 `alembic check` 输出 `No new upgrade operations detected.`。
- [ ] **种子 Hash 活跃态唯一防重与重试清理**：`submissions` 表包含 Partial Unique 索引 `uq_active_submission_torrent_hash` (仅约束活跃态与成功态)，允许 `failed/rejected` 任务重试，并在重试时物理删除旧 `SubmissionItem` 彻底重置执行态。
- [ ] **单集预占目标严格过滤收口**：指定目标单集 (如 S01E07) 投稿时，质检阶段强制过滤大包，仅生成目标单集条目并交付发币，绝对排除大包内其他未预占集数。
- [ ] **SAVEPOINT 局部事务回滚隔离**：多集逐项推进 `accepted` 时采用 `async with db.begin_nested():` 隔离单项并发 Partial Unique 冲突，遭遇重复冲突时局部回滚为 `rejected`，绝不牵连前置合法入库项与积分。
- [ ] **SKIP 冲突同源校验防冒领**：目标已存在历史异源文件时，交付适配器必须返回 `success=False` 并标记 `failed`，绝不计为本次交付成果触发发币。
- [ ] **终态失败 TaskItem 即时释放**：遭遇任何终态失败时，即时将目标 `TaskItem` 恢复为 `missing`，无需死等 2 小时 TTL 超时。
- [ ] **Partial Unique Indexes 物理落地**：
  - 电影：`uq_accepted_movie_item` (`task_id` WHERE `status='accepted' AND media_type='movie'`)
  - 剧集：`uq_accepted_episode_item` (`task_id, season, episode` WHERE `status='accepted' AND media_type!='movie'`)
  - 任务项：`uq_task_item_movie` (`task_id` WHERE `season IS NULL AND episode IS NULL`)
  - 任务项：`uq_task_item_episode` (`task_id, season, episode` WHERE `season IS NOT NULL AND episode IS NOT NULL`)
- [ ] **签到防重唯一索引**：`sign_in_records` 包含 `UNIQUE(user_id, sign_date)`，物理拦截并发双签。
- [ ] **流水账本幂等索引**：`points_ledger` 包含 `UNIQUE(idempotency_key)`，彻底杜绝重复发币。
- [ ] **用户初始余额与流水对齐**：`users.balance` 默认必须为 `0`，所有增减通过流水入账，杜绝双重赋值。
- [ ] **历史数据 Migration 升级验证**：CI 中包含旧数据场景下的迁移验证测试，实测旧表新增字段与约束平滑升级，杜绝生产数据库升级报错。

---

## 3. 状态机与风控策略 (State Machine & Risk Control)
- [ ] **业务逻辑归一化**：Web API 与 Telegram Bot 共用同一套 `SubmissionService` 领域服务层，禁止各自分叉。
- [ ] **Redis 生产 Fail-Closed**：生产环境下 Redis 异常时加锁严格返回 `False` 并阻断新提交，杜绝故障期间并发重复下载 100GB 大文件。
- [ ] **Docker 内部网络隔离**：数据库 (Postgres, Redis) 禁止暴露端口到 `0.0.0.0`，全量走 Docker 内网通信。
- [ ] **下载死种熔断**：基于 `downloaded_bytes` 增量与真实时间戳 `now - last_progress_at > DEAD_TORRENT_TIMEOUT_MINUTES * 60` 判定，而非依赖轮询 tick 计数。
- [ ] **FFprobe 深度质检**：
  - 自动过滤 `sample/trailer/extra/featurette`；
  - 提取真实编码、4K 分辨率、码率与时长；
  - 拦截 `<30s` 假视频骗分。
- [ ] **集数解析拦截**：无法从剧集文件名可靠提取 Episode 时，标记 `REJECTED_NEEDS_EPISODE_MAPPING`，严禁无脑默认反推为 `S01E01`。
- [ ] **任务外键保底**：自由投稿提交磁力时，后台先通过 TMDB 查重或自动创建 `MediaTask` 任务主体，严禁填入 `task_id=0` 导致 `ForeignKeyViolation`。
- [ ] **入库与 Emby 确认**：
  - 优先 Hardlink（同分区设备 `st_dev` 校验，不同分区平滑降级为 Copy）；
  - 状态流转至 `WAITING_EMBY` 后轮询 Emby，**直到 Emby 真实刮削出目标 TMDB ID 与单集后，才转为 ACCEPTED**；
  - 生产环境未配置 `EMBY_API_KEY` 时执行 **Fail-Closed** 熔断拒绝发币。

---

## 4. 经济系统原子性 (Points & Bounty Atomic Operations)
- [ ] **行级锁扣款**：扣除代币/积分时使用 `SELECT ... FOR UPDATE`，校验 `balance >= cost`，防止并发超额扣款。
- [ ] **多端绑定防刷 (Auth-Link Code)**：Telegram Bot 不独立生成双份初始经济账户，强制通过带 TTL 的一次性验证码与 Web/Emby 账号完成原子关联合并。
- [ ] **悬赏精准匹配**：严格按 `(tmdb_id, media_type, season, episode)` 四元组匹配，E150 入库成功绝不误结算 E151/E152。
