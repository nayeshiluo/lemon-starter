# 影视众包系统生产级自测与交付核对清单 (Production Verification Checklist)

本清单用于指导并验证基于 Emby / TMDB / qBittorrent 的众包入库系统是否达到真正可部署、可持久化、可防刷的生产标准。

---

## 1. 架构与启动闭环 (Architecture & Startup)
- [ ] **单轨收口**：已彻底移除旧的原型单文件（如根目录下残留的 `models.py`, `pipeline.py`, `emby_client.py` 等），主程序 `main.py` 正式接入分层 `services/` 与 `routes/v1/`。
- [ ] **应用级 Smoke Test**：测试套件中包含 `from backend.main import app`，并向 `/api/health` 和 `/api/health/ready` 发起真实 ASGI 请求验证进程存活与外部配置就绪度。
- [ ] **编译无语法/导入错误**：运行 `python3 -m compileall backend` 返回 0 退出码。

---

## 2. 数据库与迁移一致性 (Database & Alembic Migration)
- [ ] **Alembic Schema 零偏差**：运行 `alembic check` 输出 `No new upgrade operations detected.`。
- [ ] **种子 Hash 活跃态唯一防重与重试清理**：`submissions` 表包含 Partial Unique 索引 `uq_active_submission_torrent_hash` (仅约束活跃态与成功态)，允许 `failed/rejected` 任务重试，并在重试时物理删除旧 `SubmissionItem` 彻底重置执行态。
- [ ] **单集预占目标严格过滤收口**：指定目标单集 (如 S01E07) 投稿时，质检阶段强制过滤大包，仅生成目标单集条目并交付发币，绝对排除大包内其他未预占集数。
- [ ] **SAVEPOINT 局部事务回滚隔离**：多集逐项推进 `accepted` 时采用 `async with db.begin_nested():` 隔离单项并发 Partial Unique 冲突，遭遇重复冲突时局部回滚为 `rejected`，绝不牵连前置合法入库项与积分。
- [ ] **SKIP 冲突同源校验防冒领**：目标已存在历史异源文件时，交付适配器必须返回 `success=False` 并标记 `failed`，绝不计为本次交付成果触发发币。
- [ ] **终态失败 TaskItem 即时释放**：遭遇任何终态失败时，即时将目标 `TaskItem` 恢复为 `missing`，无需死等 2 小时 TTL 超时。
- [ ] **Partial Unique Indexes 物理落地**：
  - 电影：`uq_accepted_movie_item` (`task_id` WHERE `status='accepted' AND media_type='movie'`)
  - 剧集：`uq_accepted_episode_item` (`task_id, season, episode` WHERE `status='accepted' AND media_type!='movie'`)
  - 任务项：`uq_task_item_movie` (`task_id` WHERE `season IS NULL AND episode IS NULL`)
  - 任务项：`uq_task_item_episode` (`task_id, season, episode` WHERE `season IS NOT NULL AND episode IS NOT NULL`)
- [ ] **签到防重唯一索引**：`sign_in_records` 包含 `UNIQUE(user_id, sign_date)`，物理拦截并发双签。
- [ ] **流水账本幂等索引**：`points_ledger` 包含 `UNIQUE(idempotency_key)`，彻底杜绝重复发币。
- [ ] **用户初始余额与流水对齐**：`users.balance` 默认必须为 `0`，所有增减通过流水入账，杜绝双重赋值。

---

## 3. 状态机与风控策略 (State Machine & Risk Control)
- [ ] **业务逻辑归一化**：Web API 与 Telegram Bot 共用同一套 `SubmissionService` 领域服务层，禁止各自分叉。
- [ ] **Redis 生产 Fail-Closed**：生产环境下 Redis 异常时加锁严格返回 `False` 并阻断新提交，杜绝故障期间并发重复下载 100GB 大文件。
- [ ] **Docker 内部网络隔离**：数据库 (Postgres, Redis) 禁止暴露端口到 `0.0.0.0`，全量走 Docker 内网通信。
- [ ] **下载死种熔断**：基于 `downloaded_bytes` 增量与真实时间戳 `now - last_progress_at > DEAD_TORRENT_TIMEOUT_MINUTES * 60` 判定，而非依赖轮询 tick 计数。
- [ ] **FFprobe 深度质检**：
  - 自动过滤 `sample/trailer/extra/featurette`；
  - 提取真实编码、4K 分辨率、码率与时长；
  - 拦截 `<30s` 假视频骗分。
- [ ] **集数解析拦截**：无法从剧集文件名可靠提取 Episode 时，标记 `REJECTED_NEEDS_EPISODE_MAPPING`，严禁无脑默认反推为 `S01E01`。
- [ ] **任务外键保底**：自由投稿提交磁力时，后台先通过 TMDB 查重或自动创建 `MediaTask` 任务主体，严禁填入 `task_id=0` 导致 `ForeignKeyViolation`。
- [ ] **入库与 Emby 确认**：
  - 优先 Hardlink（同分区设备 `st_dev` 校验，不同分区平滑降级为 Copy）；
  - 状态流转至 `WAITING_EMBY` 后轮询 Emby，**直到 Emby 真实刮削出目标 TMDB ID 与单集后，才转为 ACCEPTED**；
  - 生产环境未配置 `EMBY_API_KEY` 时执行 **Fail-Closed** 熔断拒绝发币。

---

## 4. 经济系统原子性 (Points & Bounty Atomic Operations)
- [ ] **行级锁扣款**：扣除代币/积分时使用 `SELECT ... FOR UPDATE`，校验 `balance >= cost`，防止并发超额扣款。
- [ ] **悬赏精准匹配**：严格按 `(tmdb_id, media_type, season, episode)` 四元组匹配，E150 入库成功绝不误结算 E151/E152。
