# 端到端生产模拟演练 (E2E Simulation Drill)

单测全绿 ≠ 系统可用。150 项单测全过的项目，一跑模拟演练立刻暴露高危并发缺陷。
本文是该演练脚本的设计规范与实测结论（2026-09-04，lemon-2f）。

## 为什么单测发现不了

单测通常**每个用例一个干净会话、串行执行、单条记录**，天然规避了：

- 并发竞态（丢失更新、双花、幂等键碰撞）
- 跨端点串联（投稿 → 流水线 → 发币 → 榜单 → 删除的状态传递）
- Mock 语义写反（见下方最大坑）
- 全站响应体脱敏（单测断字段，不扫整个 body）

演练脚本 = **一次进程内跑通全生命周期，每步断言，末尾汇总缺陷清单**。

## 骨架

```python
FINDINGS, PASSES = [], []
def ok(m):  PASSES.append(m);  print(f"  ✅ {m}")
def bug(m): FINDINGS.append(m); print(f"  🐞 缺陷: {m}")

# 结尾必须汇总，不能只打散落日志
print(f"通过项: {len(PASSES)}    发现缺陷: {len(FINDINGS)}")
for i, f in enumerate(FINDINGS, 1): print(f"  {i}. {f}")
```

用 `httpx.ASGITransport(app=app)` + `app.dependency_overrides[get_db]` 打真实
HTTP 路由（含鉴权、Pydantic 校验、响应序列化），不要直接调 service —— 那样绕过了
路由层，MissingGreenlet、响应模型缺字段这类问题全测不出来。

## 三个必踩的脚本自身陷阱

### 1. Mock 语义写反 → 6 个假缺陷（最大时间黑洞）

`emby_client.verify_item_presence` 被简单 mock 成 `return_value=True`，
结果**投稿前查重**也返回 True，所有投稿全被 409 "已在 Emby 库内收录" 拦死。
首轮 6 个"缺陷"全是假的。

这个函数在链路里有**两种语义**，必须按参数分流：

```python
async def verify_presence(tmdb_id, media_type, season=None, episode=None,
                          expected_dest_path=None):
    # 投稿前查重：库里还没有 → False
    # 交付落盘后对账：带 expected_dest_path → True
    return expected_dest_path is not None
```

**通则**：演练前先确认每个被 mock 的外部依赖在链路中被调用了几次、每次期望什么。
固定返回值的 mock 只适合单一语义的依赖。**报出一片缺陷时先怀疑自己的 mock**。

### 2. 内存 SQLite 多会话互不可见

默认 `sqlite+aiosqlite:///:memory:` 每个连接一个独立库，并发双请求各看到空表，
测不出竞态。必须共享同一连接：

```python
from sqlalchemy.pool import StaticPool
create_async_engine("sqlite+aiosqlite:///:memory:",
                    connect_args={"check_same_thread": False, "uri": True},
                    poolclass=StaticPool)
```

### 3. 同一个 AsyncClient 并发两请求不算并发

`asyncio.gather` 里复用一个 client，两请求可能落到同一会话/事务，竞态测不出。
必须开两个独立 `AsyncClient`：

```python
async with httpx.AsyncClient(transport=tr, base_url="http://sim") as c2:
    r1, r2 = await asyncio.gather(
        c.post(f"/api/submissions/{sid}/delete",  headers=H),
        c2.post(f"/api/submissions/{sid}/delete", headers=H),
        return_exceptions=True)   # 必须带，否则一侧异常吞掉另一侧结果
```

判据看**余额差值**，不看状态码：

```python
delta = before - after
if   delta == reward * 3: ok("并发双删仅扣一次")
elif delta == 0:          bug("并发双删未扣分")     # 丢失更新 / 事务被打爆
else:                     bug(f"扣分异常 {delta}")  # 重复扣罚
```

## 16 场景清单（可直接照搬）

| # | 场景 | 关键断言 |
|---|---|---|
| 1 | 公共看板 + 未登录鉴权 | 公开端点 200、私有端点 401 |
| 2 | 磁力投稿 | 受理 200、status=pending、预估奖励正确 |
| 3 | 同单集重复抢单 | 409（Partial Unique Index 生效） |
| 4 | **目录穿越攻击** | `resource_url=/etc/passwd` 必须 ≥400 |
| 5 | 乱名文件本地挂载 | 受理后 status 直接 inspecting（免下载） |
| 6 | 网盘分享投稿 | pan_type 自动识别（quark/yidong/guangya） |
| 7 | 视频直传 | multipart 上传 200、source_type=direct_upload |
| 8 | 查缺补漏大厅 | 缺集区间格式、完成度百分比 |
| 9 | 流水线全状态机推进 | 走到 accepted、实发币>0、**落盘路径 endswith TMDB 规范名且文件真实存在** |
| 10 | 三维度排行榜 | uploads/earned/balance 各自榜首正确 |
| 11 | 商城兑换 | 扣币 + 订单生成 |
| 12 | **越权删他人投稿** | ≥400 |
| 13 | **并发双删** | 余额差值恰好 = reward × 倍数 |
| 14 | 管理员积分自由调控 | 允许穿透为负 |
| 15 | 动态控分热更新 | 改完立刻作用于**新投稿的预估奖励**（不只看回显） |
| 16 | **全站响应脱敏** | 扫整个 body，`magnet_uri/torrent_hash/dest_file/resource_url/share_code` 一个都不能出现 |

场景 9 的推进循环直接调 `pipeline._handle_*`，每步 commit，并设最大轮数防死循环：

```python
for _ in range(6):
    cur = (await s.execute(select(Submission).where(...))).scalar_one()
    if cur.status in ("accepted","partial","failed","rejected","deleted"): break
    if   cur.status in ("pending","reserved"): await pipe._handle_pending(cur)
    elif cur.status == "downloading":          await pipe._handle_downloading(cur)
    elif cur.status == "inspecting":           await pipe._handle_inspecting(cur)
    elif cur.status == "delivering":           await pipe._handle_delivering(cur)
    elif cur.status == "waiting_emby":         await pipe._handle_waiting_emby(cur)
    await s.commit()
```

交付适配器要换成临时目录：
`pipe.delivery_adapter = LocalDeliveryAdapter(movies_root=..., tv_root=..., delivery_mode="copy")`

## 运行

```bash
# 演练脚本放 tests/ 下但不走 pytest（它是脚本不是用例）
PYTHONPATH=. APP_ENV=testing python3 tests/sim_drill.py
```

改完任何流水线/积分/删除逻辑，**单测 + 演练两个都要跑**。
