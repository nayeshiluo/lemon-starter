# EMOS Console (emya.wwzb.de) 架构与众包生态功能矩阵

## 1. 概述与系统定位

EMOS Console (`https://emya.wwzb.de/`) 是 EMOS 影视媒体生态的全功能 Web 控制台（基于 React 18 + Radix UI + Lucide + Sonner + TailwindCSS SPA 架构）。
其所有前端请求统一通过 Bearer Token 鉴权，直接直连官方后端 API 端点 `https://emos.best/api/...`。

## 2. 核心路由与功能全景映射 (28 核心路由)

| 路由路径 | 功能模块 | 对应关键 API 端点 | 业务机制与数据特征 |
| :--- | :--- | :--- | :--- |
| `/dashboard` | 仪表盘与概览 | `/api/user`, `/api/user/stats/video/history` | 用户资产总览、临时播放密码获取、在线观影状态、最近动态 |
| `/video` | 视频总览与片库 | `/api/video/list`, `/api/video/tree` | 20万+条目的影视全库检索、TMDB 对账、剧集季集树形结构 |
| `/video/media` | 媒体资源与外链 | `/api/video/media/list`, `/api/video/media/playUrl` | 物理资源/直链分发、多版本画质管理、资源移动与下架 |
| `/video/subtitle` | 字幕检索与管理 | `/api/video/subtitle/list`, `/rename`, `/delete` | 外挂字幕（SRT/ASS）独立检索、双语/简繁标记、纠错下架 |
| `/video/search` | 视频高级搜索 | `/api/video/search` | 支持按 TMDB ID / 标题 / 分类精准与模糊检索 |
| `/video/record` | 观影记录管理 | `/api/video/record/list`, `/change` | 标记单集/整部影视完成状态、删除个人观影记录 |
| `/video/upload-history` | 投稿上传历史 | `/api/video/list` (filtered) | 个人上传台账、审核状态、资源详情追溯 |
| `/upload` | 分片上传与识别 | `/api/upload/video/base`, TUS / S3 Multipart | 浏览器端季集正则识别、大文件切片并发上传、MD5/ETag校验 |
| `/seek` | 求片悬赏大厅 | `/api/seek`, `/apply`, `/claim`, `/urge`, `/poll` | 多人众筹催更、认领独占期倒计时、悬赏总池结算 |
| `/calendar` | 观影足迹日历 | `/api/user/stats/video/history?dates=...` | 按月日历热力图、单日观影时长/集数统计、本月常看排行 |
| `/proxy` | 反代专线大厅 | 前端测速 Ping/RTT | 官方/自建反代线路管理、延迟测速、一键直连/播放器导入 |
| `/rank` | 综合排行榜 | `/api/rank/carrot`, `/upload`, `/sign`, `/watch` | 萝卜富豪榜（含修仙阶位）、上传量榜、连签榜、观影时长榜 |
| `/carrot` | 萝卜资产与账本 | `/api/carrot/current`, `/history`, `/transfer` | 流水明细（带过期时间 expired_at）、点对点转赠 |
| `/carrot/stats` | 萝卜收益统计 | `/api/carrot/history` | 按月统计收入/支出分布、临期萝卜预警 |
| `/redpacket` | 社区红包系统 | `/api/redPacket/create`, `/receive` | 均分/拼手气/口令红包、自定义封面、倒计时过期 |
| `/lottery` | 社区抽奖活动 | `/api/lottery/create`, `/win`, `/cancel` | 门槛签到天数/付币报名、自动发奖卡密轮盘 |
| `/shop` | 社区商城集市 | `/api/shop/product/list`, `/order/user/*` | 官方商品兑换 + 用户自由开店（C2C 集市模式） |
| `/shop/orders` | 订单履约中心 | `/api/shop/order/user/pay`, `/delivery`, `/urge` | 待支付、待发货、已发货、催发货、交易评价 |
| `/shop/manage` | 店铺管理面板 | `/api/shop/seller/*`, `/product/createOrUpdate` | 开通店铺、商品上下架、库存管理、销售订单处理 |
| `/emya` | 播放设备与会话 | `/api/emya/getLoginPassword`, `/videoLogout` | Emby 在线客户端会话管理、一键强制下线、重置播放密码 |
| `/invite` | 邀请管理 | `/api/invite/*` | 邀请码生成、注册追溯、剩余额度 |
| `/invite/tree` | 邀请族谱树 | D3.js 树状可视化 | 团队/师徒/直邀层级关系拓扑图展示 |
| `/telegram` | TG 绑定与投票 | `/api/telegram/vote/*` | 关联 Telegram 账号（防止分裂）、群组投票联动 |
| `/ban` | 违规封禁管理 | `/api/ban/list`, `/change` | 违规用户封禁、解封理由审计留痕 |

---

## 3. 对影视众包入库系统 (Crowdsourced Media Pipeline) 的高价值机制提炼

### 3.1 众筹式催更悬赏池 (Crowdfunded Seek Bounty)
- **机制原理**：
  1. **发起**：用户 A 针对缺失的单集（`S01E05`）或整季发起求片，出资 50 币。
  2. **加码 (Urge)**：用户 B、C 同样想看，各自追加投入 20 币、30 币。系统动态汇总累积悬赏池为 100 币，并将该剧/该集在求片大厅根据热度提升权重。
  3. **认领锁定期 (Claim & TTL)**：上传者 D 点击「认领」，系统给予 D 一段独占上传时间（如 24 小时，写入 `upload_expired_at`），期间其他人不可重复认领，保障上传者不白费带宽。
  4. **超时与结算**：
     - 若 D 在有效期内上传成功并过质检入库，系统自动将累积的 100 币全额划转给 D。
     - 若 D 超时未上传，任务自动恢复为 `open`，重新退回大厅开放给全站其他用户认领。

### 3.2 独立外挂字幕轨道 (Subtitle Ingestion & Governance)
- **机制原理**：
  1. 许多用户不具备压制和做种上传上百 GB 4K 视频的设备，但具备翻译、校对和搜集外挂字幕（`.ass` / `.srt`）的能力。
  2. 建立独立的字幕上传流水线：用户上传字幕文件 -> 选择/识别 TMDB 季集 -> 标记语言（简中/繁中/双语/特效）-> 自动规范化重命名并落盘到 Emby 对应媒体目录。
  3. 设立轻量级奖励（如 5~15 币），并配合社区纠错（重命名、带原因删除申请），极大盘活非压制组用户的日常参与度。

### 3.3 观影足迹日历与用户粘性闭环 (Watch Footprint Calendar)
- **机制原理**：
  1. 通过接入 Emby 播放事件或定时同步 `PlaybackInfo` / 观影日志，汇总用户每日观影时长（秒级）与播放集数。
  2. 生成按月可视化打卡日历，统计「连续观影天数」、「本月最爱看影视」与「观影排行榜」。
  3. 将观影行为与经济系统联动（如每日观影满一定时长获得连签加成或活跃度奖励），使整个系统从单纯的「贡献者工具」升级为「集观影、补片、消费于一体的社区生态」。
