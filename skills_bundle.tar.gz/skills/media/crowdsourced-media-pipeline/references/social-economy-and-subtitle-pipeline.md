# 外挂字幕轨道、观影足迹日历与社交福利经济技术规范

本文档归纳二楼有请 (Lemon 2F) 在多源众包、字幕质检、Emby 播放行为对账以及代币社交生态中的核心设计模式与生产坑点。

---

## 一、 外挂字幕独立入库轨道 (Subtitle Ingestion Pipeline)

### 1. 业务定位与价值
- 降低入库门槛：用户无需具备压制和上传数十 G 视频的能力，仅需提供几百 KB 的字幕文件即可获得代币激励。
- 自动化质检标准 (Fail-Closed)：
  1. **大小区间**：`100 字节 <= size <= 50MB`，过滤假文件与大尺寸二进制注入；
  2. **文本编码探测**：顺序尝试 `utf-8-sig`, `utf-8`, `gb18030`, `gbk`, `utf-16`, `big5`，避免乱码文件流入；
  3. **语法时间轴特征比对**：
     - `.srt`：必须含有 `-->`；
     - `.ass` / `.ssa`：必须含有 `[Events]` 或 `Dialogue:`；
     - `.vtt`：必须含有 `WEBVTT` 或 `-->`。

### 2. Emby 官方规范洗名与落盘
- **电影**：`{clean_title} ({year}).{language}{tag}.{ext}`，例如 `阿凡达 (2009).zh-CN.default.srt`
- **剧集**：`{clean_title} - S{season:02d}E{episode:02d}.{language}{tag}.{ext}`，例如 `遮天 - S01E03.zh-CN.default.ass`
- **标记位**：`is_default=True` 对应 `.default`，`is_forced=True` 对应 `.forced`。

---

## 二、 Emby 观影足迹与月度日历看板 (Watch Footprint & Retention)

### 1. 观影流水设计
- 记录单次播放：`user_id`, `tmdb_id`, `media_type`, `title`, `season`, `episode`, `playback_seconds`, `is_completed`, `device_name`；
- 日期索引字段：`watched_date` (格式 `YYYY-MM-DD`)，方便月度按日聚合查询；
- 月度日历聚合器：返回每日观看秒数、看剧集数、看片部数、当天片单、月度累计时长及常看榜 TOP 5。

### 2. 每日观影打卡激励防刷
- 每日满 30 分钟（1800 秒）自动派发 5 🪙；
- 数据库物理约束：`UniqueConstraint("user_id", "reward_date", name="uq_user_daily_watch_reward")`；
- 记账幂等键：`daily_watch_{date}_{user_id}`。

---

## 三、 社交福利与代币回收生态 (Social Welfare & Games)

### 1. 红包系统 (RedPacket)
- 支持三类红包：拼手气 (random)、普通均分 (equal)、口令暗号 (password)；
- 发红包时原子冻结；
- 抢红包时使用 `SELECT ... FOR UPDATE` 悲观锁锁定行，杜绝高并发超领；
- **中文口令比对血案**：`secrets.compare_digest` 严禁直接传入非 ASCII 字符串，必须调用 `.encode('utf-8')` 转为 bytes；
- 拼手气二倍均值算法分配，最后一份全量兜底，确保资金 100% 对齐。

### 2. 赛博幸运大轮盘 (Lucky Wheel)
- 每次抽奖消耗 10 🪙，代币回流系统；
- 奖池按权重配置：软妹币大奖、卡密（如 Emby VIP / 专线码，系统自动派发）、赛博徽章；
- 中奖即刻发货，记录流水台账。

---

## 四、 Telegram Bot 端众包与社交交互规范 (Bot Social Integration)

### 1. 统一安全守卫 (Single Gate)
- 所有新增扩展指令（`/wanted`, `/watch`, `/wheel`, `/redpacket`）以及全部 Inline Keyboard 按钮回调必须首先调用 `require_bound_user` 守卫；
- 未绑定 Emby 账号者坚决不发币、不记账、不执行业务逻辑，统一引导前往 Web 端个人中心用 Emby 账号认证。

### 2. 群聊发红包与行内按钮交互 (Group RedPacket Interaction)
- `/redpacket <金额> <份数> [口令]` 指令在群聊中发送时，生成带有 `InlineKeyboardButton("🧧 戳我拆红包！", callback_data="btn_claim_rp:{id}")` 的富文本卡片；
- Callback 交互必须在数据库 `SELECT ... FOR UPDATE` 悲观行锁内原子核销 `packet.remaining_count` 与 `packet.remaining_points`，杜绝群友并发狂点造成透支超领；
- 抢到红包时优先通过 `query.answer(f"🎉 恭喜抢得 {points} 软妹币！", show_alert=True)` 弹窗提示，既不刷屏群聊又能带来极佳的即时满足感。

### 3. 轻量化数据与进度可视化
- `/wanted`：展示前 5 条赏金最高求片，标明季集、众筹人数与赏金总池；
- `/watch`：动态生成文字版 ASCII 进度条（如 `[██████░░░░] 60% 18/30分`），直观反馈当日 30 分钟打卡进度；
- `/wheel`：扣币与抽奖原子执行，中奖卡密直接用 Markdown 代码块回显方便长按复制。

