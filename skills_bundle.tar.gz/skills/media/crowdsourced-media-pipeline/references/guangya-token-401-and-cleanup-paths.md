# 光鸭云盘 401 长扫描失败：根因、改错文件的陷阱与验证法

实测时间：2026-10-24（北京时间）。适用 `lemon-media-spider` 全链路。

## 一、症状

`auto_pipeline.py` 06:00 起跑，06:19 开始首轮净化，跑满 67 分钟后：

```
2026-10-24 07:26:33,233 [ERROR] [-] 首轮目标净化异常: HTTP Error 401: Unauthorized
```

白跑 67 分钟，`av/fc2/fuliji` 三个专区零清理。同一形态自 10-18 起累计 29 次，全部落在 07:00 前后。

## 二、根因：token 生命周期短于扫描时长

光鸭 `access_token` 是 JWT，实测 **有效期正好 120 分钟**。解码即得签发/过期时间，是判断 runway 的第一手证据：

```python
import json, base64, datetime
t = get_access_token()                      # guangya_session.json → localStorage → *credentials* → access_token
p = t.split('.')[1]; p += '=' * (-len(p) % 4)
c = json.loads(base64.urlsafe_b64decode(p))
# claims: iss, sub, aud, exp, iat, at_hash, scope, project_id
print(datetime.datetime.fromtimestamp(c['iat'], tz=...+8), datetime.datetime.fromtimestamp(c['exp'], tz=...+8))
print('有效期分钟', (c['exp'] - c['iat']) / 60)
```

本轮时间线完全对上：token `05:26` 签发 → `07:26` 过期，而净化 `06:19` 起跑时已耗掉 53 分钟，全量递归 9 万+ 文件要 60~75 分钟，**必然跨过过期点**，401 精确落在 `07:26:33`。

关键背景：`TOKEN_REFRESH_MARGIN` / `ensure_fresh_token()` 的提前续期是当天 11:44 才加进去的，**06:19 那轮跑的还是旧代码**，所以整轮没有任何续期日志 —— 不要因为"日志里没有续期记录"就误判续期逻辑失效。

连带伤害：主流水线独占 `/tmp/lemon_video_only_sweep.lock` 67 分钟，`06:30`、`07:00` 两轮 `delayed_clean` 兜底全被 `Lock is busy` 挡掉，当天净化零成功。

## 三、最容易改错的地方：净化根本没用 guangya_client 的 api_request

**这是本类排障最大的陷阱。** 仓库里同时存在两份 `api_request`，走的是完全不同的路径：

| 模块 | api_request 来源 | 特性 |
|---|---|---|
| `video_only_cleaner.py` | `from guangya_client import api_request` | 有 token 预续期、401 强制轮换重试、可真实删除 |
| `ultimate_cleaner.py` | `from cleanup_preview import api_request` | **只读守卫**：仅放行 `get_file_list` / `search`，其余抛 `PreviewOnly` 并打印 `[dry-run] 已阻止变更` |
| `cleanup_preview.py` 自身 | 转发到 `guangya_client.api_request` | 但加了上面那层白名单 |

后果两条：

1. **在 `guangya_client.py` 里修 token 逻辑，对 `ultimate_cleaner` 这条路径完全无效** —— 它压根不经过那套续期。想当然地在 guangya_client 加 margin，会以为修好了其实没有。
2. **`ultimate_cleaner` 的所有 `delete_file` / `rename` / `move_file` 从来没真正执行过**，全被 `cleanup_preview` 的只读白名单拦死。这是 2026-10-10「legacy cleaner 只读化」加固的产物，但 `crawl_pikpaklove.py` 仍把 `clean_directory_deep` 当现役清理器在调，属遗留矛盾。排查"净化没效果"时必须先确认走的是哪一份 api_request，否则会一直往判定逻辑里找错。

排查手法（一条命令定位）：

```bash
grep -n "def api_request\|from cleanup_preview import\|from guangya_client import" \
     ultimate_cleaner.py video_only_cleaner.py cleanup_preview.py
```

## 四、诊断判据：看抛出的异常类型就能区分代码路径

| 日志里的异常 | 说明 |
|---|---|
| 原始 `HTTP Error 401: Unauthorized` | 已经走完 guangya_client 的重试链仍失败（**重试也 401**），不是"没重试" |
| `RuntimeError: 光鸭 401 续期后凭证未更新` | 轮换后读到的 token 与旧 token 相同，轮换没生效 |
| `RuntimeError: 光鸭 401 且续期失败: ...` | 连 `sync()` / `force_refresh()` 都抛了 |
| `PreviewOnly: Legacy cleaner is preview-only; mutation blocked` | 走的是 cleanup_preview 只读守卫，根本没发请求 |

## 五、修复模式（三层，缺一层就还会犯）

### 1. 主流水线不自己跑长净化

`auto_pipeline.py` 用 `sync_and_purify_guangya(defer_cleanup=True)`，净化入队交 `delayed_clean` 分专区轮转。既避免跨 token 过期点，也避免独占扫描锁挡掉后续补偿轮次。

判据：日志文案应为 `[3/3] ...（净化已入队交延迟任务）`。若看到 `[3/3] ...与全盘净化守护`，说明跑的是旧版代码。

### 2. 请求前按 margin 预续期

`TOKEN_REFRESH_MARGIN = 600`，`ensure_fresh_token()` 在每次 `api_request` 前检查剩余时长，不足则从 LA 拉取、必要时 `force_refresh()` 轮换。

### 3. 轮换后的传播窗口 + 明确异常类型

新 token 被服务端接受存在短暂延迟。原实现拿到新 token 立即重试，一旦撞上传播延迟就抛裸 `HTTPError`，整轮报废。正确做法：等几秒取最新 token 再试一次，仍失败才抛可识别的鉴权异常。

```python
TOKEN_PROPAGATION_WAIT = 5

class GuangyaAuthError(RuntimeError):
    """401 survived a forced credential rotation; the sweep must stop."""

# 401 分支内，fresh != token 之后：
try:
    with urllib.request.urlopen(req2, timeout=...) as resp2:
        return finish(json.loads(resp2.read().decode("utf-8")))
except urllib.error.HTTPError as retry_err:
    if retry_err.code != 401:
        raise
    time.sleep(TOKEN_PROPAGATION_WAIT)
    latest = get_access_token()
    if latest and latest != fresh:
        headers["Authorization"] = f"Bearer {latest}"
        with urllib.request.urlopen(req3, timeout=...) as resp3:
            return finish(json.loads(resp3.read().decode("utf-8")))
    raise GuangyaAuthError("强制轮换后新凭证仍被拒 ...") from retry_err
```

**不要**把长扫描里的单页失败改成"跳过继续"：`ultimate_cleaner._list_all` 的 `IncompleteClean` 是安全机制，扫描不完整时继续删除会基于残缺清单做删除决策，比整轮失败危险得多。

## 六、验证法：mock urlopen 跑三个场景

不需要真打接口，替换 `guangya_client.urllib.request.urlopen` 与 `get_access_token` 即可。注意 `ensure_fresh_token()` 先调 `token_seconds_left()` 而非 `get_access_token()`，mock 的读取计数要按真实调用序排（否则会误判走错分支）：

| 场景 | 期望 |
|---|---|
| 原始 401 → 轮换 → 重试成功 | 正常返回，请求 2 次 |
| 原始 401 → 轮换 → 重试仍 401 | 抛 `GuangyaAuthError`，请求 2 次 |
| 原始 401 → 轮换 → 仍 401 → 等 5s 再轮换 → 第三次成功 | 正常返回，请求 3 次 |

配套回归：`pytest test_media_automation.py`（当前 19 passed）、五个生产模块导入、`check_api_health()` 实时探测。

## 七、动这个目录前的撞车核查（血的教训）

`lemon-media-spider` 可能同时有多个 agent 会话在改。本次实操中，`guangya_client.py`(11:44)、`auto_pipeline.py`(11:45)、`sync_guangya_from_la.py`(11:45)、`scheduled_sync_and_clean.py`(11:51) 在另一会话里被改过，而我在不知情的情况下分析了半天"没人修"。

动手前按顺序做三件事：

```bash
# 1. 谁最近被改过
find . -maxdepth 1 -newermt "-60 minutes" -type f -name "*.py" -printf '%TH:%TM %p\n' | sort
# 2. 有没有同目录进程在跑（探针/清理/定时任务）
ps -eo pid,etime,cmd | grep -E "audit_clean_scope|delayed_clean|video_only|auto_pipeline" | grep -v grep
# 3. 别的会话是不是正在做同一件事
#    session_search(query="光鸭 401 token", sort="newest")
```

若发现目标文件 mtime 落在自己操作窗口内但自己没改过 → **先查是谁改的，别当自己改的继续推**。改前一律 `cp` 时间戳备份，改完跑现有测试，并只碰没人接手的文件（本次只动 `guangya_client.py` 的 401 分支，避开 `delayed_clean.py` / `video_only_cleaner.py` / `ultimate_cleaner.py`）。

## 八、汇报纪律

区分「已验证」与「推断」：token 有效期、401 时刻、日志文案、测试结果属已验证；"服务端风控导致"这类没有证据的归因不要写进结论。采样时间必须和指标一起给出，并标明时区换算。
