---
name: emby-server-deploy-ops
description: Use when 评估或部署自建 Emby/Jellyfin 媒体服务器：宿主选型、云盘挂载、转码能力判定。
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [emby, jellyfin, rclone, media-server, transcode, host-sizing]
---

## When to Use

用户问“我这台机器能不能起个 Emby/Jellyfin”“帮我搭个自用小媒体服”，或在已有 Emby 上扩容、换宿主、加云盘。只做反代/水印/统计注入的属 `emby-proxy-ops`，本技能只管**服务端本体与宿主**。

## 核心原则

1. **先判宿主，再谈方案**：不先回答“能/不能”，先实测 CPU、可用内存、swap 占用、系统盘余量、`/dev/dri`。一台跑着代理/反代/隧道的小 VPS 通常已经不是候选。
2. **swap 已吃满 = 内存不足的铁证**：`free -h` 里 `available` 尚可但 swap used 上 GB，说明它长期靠换页活着，再加一个会扫库、会建元数据、会转码的服务必然 OOM。别只看 available。
3. **无硬编就按软转规划**：`lspci | grep -i vga` 出现 `1234:1111`（QXL/虚拟显示）或 `/dev/dri` 只有 `card0` 没有 `renderD*`，就是纯软转。软转只当兜底，播放策略一律“能直连就直连”。
4. **片源不落本地盘**：本地盘只放 `/config` 元数据与 `/cache`；媒体走 rclone 挂云盘。小盘机尤其如此。
5. **真实播放验收**：不看容器 active、不看 8096 有响应，要真开一集看走的是 DirectPlay 还是 Transcode，以及转码耗时。

## 宿主评估（只读，一次跑完）

```bash
nproc; lscpu | grep -iE 'model name|thread|core|socket'
free -h; swapon --show 2>/dev/null || cat /proc/swaps
df -h / ; uptime
ls -l /dev/dri 2>/dev/null; lspci 2>/dev/null | grep -iE 'vga|display'
ss -ltnp | grep -E ':(8096|8097)\b' || echo 端口空闲
docker ps --format '{{.Names}}\t{{.Image}}\t{{.Status}}'
```

判读口径：

| 指标 | 可接受 | 危险 |
| :--- | :--- | :--- |
| 可用内存 | ≥4G 且 swap 基本未用 | <1G 或 swap 已用 1G+ |
| 系统盘余量 | ≥20G（元数据+缓存） | <10G |
| 负载 | load 远小于核数 | 已有服务常驻吃满 |
| 角色 | 独立/以媒体为主 | 反代/代理/网关节点 |

同宿主共存的代理、反代、隧道、监控容器都算它的负载，别当空气。

## 转码能力判定

- 有 `/dev/dri/renderD128` 且属组配好 → 可开 VAAPI/QSV，`--device /dev/dri` 透传。
- 只有 `card0`、lspci 是 `1234:1111` → **无硬编**。按核数估软转上限：EPYC/现代 x86 大致 1 核 ≈ 0.3–0.5 路 1080p 实时转码，6 核留余量后约 2 路 1080p，4K 别承诺。
- 客户端（SenPlayer/Infuse）关掉自动降码率，避免无意触发转码；容器外再卡一道 `max streaming bitrate`。

## 部署骨架

1. 装 rclone（无 `unzip` 的机器用官方 deb，别去编译）：
   ```bash
   curl -s -o /tmp/rclone.deb https://downloads.rclone.org/rclone-current-linux-amd64.deb
   sudo dpkg -i /tmp/rclone.deb || sudo apt-get -f install -y
   ```
2. 云盘授权与挂载：多账号 GDrive 走 `references/gdrive-multi-account-mount.md`，含无头授权拿 code 的两种路径。
3. 挂载单元用 `Type=notify` + `--vfs-cache-mode=full`，`--vfs-cache-max-size` 必须小于宿主机可用内存/盘的较小者，`ExecStop=/bin/fusermount3 -u -z <挂载点>`，`Restart=on-failure`。
4. Emby 容器 remap 到目标端口（`HTTP_PORT=8097` 或 `-p 8097:8096`），`/config` `/cache` 落本地盘，媒体目录以 `rshared` 传入（`--allow-other` 必须开）。
5. 出入网：套已有 Cloudflare 隧道或反代到 8097，别占用 80/443 上已有服务；**不暴露源站 IP**。
6. 库结构：`/mnt/<remote>/动漫追番/{剧名}/Season XX/`、`点播剧集/...`；动漫刮削用 Bangumi(Chobits) 插件。

## 常见陷阱

- 把 Emby 塞进已在跑反代/代理的小 VPS：`available` 看着有几百 M，一扫库就 OOM，还会连带打挂同机的反代与隧道。
- 只看 `free -h` 的 available，不看 swap used。
- 认为“有 /dev/dri 就能硬编”：虚拟显卡也挂 card0。
- `vfs-cache-max-size` 设得比机器还大（如 12G 机设 20G）→ 缓存吃满内存/盘。
- 首次扫库内存峰值远高于空跑（可达 1G+），评估时按峰值留量。
- 只验证容器起来了就报成功，没验证真实播放与直连/转码路径。

## 参考资料

- `references/gdrive-multi-account-mount.md` — 多账号 Google Drive 无头授权、code 回收、rclone 多 remote 挂载与验收。
