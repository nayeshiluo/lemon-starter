# 多账号 Google Drive 挂载 Emby

## 前提核验顺序

1. **先判 client 活不活，再判 token 死没死**。二者不能混：
   - token 刷新返回 `400 invalid_grant` → refresh_token 过期/被吊销，重新授权即可。
   - 授权端点返回 `401 disabled_client` / `deleted_client` → 整个 OAuth 项目被禁，重授权无效。
2. 探测授权端点要**禁用重定向跟随**，否则正常情况也会被 302 到登录页，看不出真实状态：

```python
import urllib.request, urllib.error, urllib.parse
CID = "<client_id>"
url = ("https://accounts.google.com/o/oauth2/auth?client_id=" + urllib.parse.quote(CID)
       + "&redirect_uri=" + urllib.parse.quote("http://127.0.0.1:53682/")
       + "&response_type=code&scope=" + urllib.parse.quote("https://www.googleapis.com/auth/drive")
       + "&access_type=offline&prompt=consent&state=probe")

class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *a, **k): return None

op = urllib.request.build_opener(NoRedirect)
try:
    r = op.open(urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"}), timeout=20)
    print("HTTP", r.status)
except urllib.error.HTTPError as e:
    loc = e.headers.get("Location", ""); body = e.read().decode()[:600]
    print("HTTP", e.code, "->", loc[:80])
    for bad in ("disabled_client", "deleted_client", "invalid_client",
                "unauthorized_client", "redirect_uri_mismatch", "invalid_request"):
        if bad in body or bad in loc:
            print("BAD:", bad)
```

`HTTP 302 -> accounts.google.com/v3/signin/...` = 正常可用。出现任何 `BAD:` 行 = 项目/客户端层面的问题，别再折腾 token。

## 无头服务器拿 code 的两种路径

`rclone authorize "drive" --auth-no-open-browser --drive-scope drive` 会监听 `127.0.0.1:53682` 并打印 `http://127.0.0.1:53682/auth?state=<state>`。**必须用 background 方式启动**（前台会卡住直到超时），随后从日志里读 state。

**路径 A —— SSH 隧道，用户零复制**
```bash
# 用户本机
ssh -L 53682:127.0.0.1:<服务器IP>的53682 ubuntu@<server>
```
把 `https://accounts.google.com/o/oauth2/auth?client_id=202264815644.apps.googleusercontent.com&redirect_uri=http%3A//127.0.0.1%3A53682/&response_type=code&scope=https%3A//www.googleapis.com/auth/drive&access_type=offline&prompt=consent&state=<state>` 给用户点。授权后回调打到本机隧道，rclone 自动收 code。

**路径 B —— 回收 code**
用户直接点同一链接，回调页会“无法访问”，属正常。让用户把地址栏整条 URL 贴回来，从中取 `code=4/0A...`，粘贴给正在等待的 rclone 进程 stdin（`process(action='submit')`），或自己 POST token 端点换 refresh_token。

`202264815644.apps.googleusercontent.com` 是 rclone 自带公开 client（Desktop 类型，redirect `http://127.0.0.1:53682/`），无需自建项目；出现“应用未经验证”走 高级 → 转到 rclone（不安全）即可。

## 多账号 → 多 remote

每个账号独立授权一次，各自 `rclone config create gdriveN drive token='<json>'`，或分别 append 到 `rclone.conf`，权限 `0600`。别把多个号塞同一个 remote。

挂载单元按账号各一份（`rclone-gdrive1.service` …），互不影响：

```ini
[Unit]
Description=Rclone Mount Google Drive N for Emby
After=network-online.target
Wants=network-online.target

[Service]
Type=notify
ExecStart=/usr/bin/rclone mount gdriveN: /mnt/gdriveN \
    --allow-other --vfs-cache-mode=full \
    --vfs-cache-max-size=<小于可用内存与盘余量> --vfs-cache-max-age=24h \
    --buffer-size=32M --dir-cache-time=72h --poll-interval=15s --umask=022
ExecStop=/bin/fusermount3 -u -z /mnt/gdriveN
Restart=on-failure
RestartSec=10

[Install]
WantedBy=multi-user.target
```

## 授权后先做小 probe

别授权完就直接挂 Emby 扫全库。先 `rclone about gdriveN:` 看账号与配额、`rclone lsd gdriveN:` 列目录、上传一个几 MB 文件再删。确认账号没被风控、配额正常，再建库。共享盘（Shared Drive）要在 remote 里带 `--drive-team-drive <id>` 或建独立 remote。
