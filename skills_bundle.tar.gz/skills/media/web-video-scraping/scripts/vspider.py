#!/usr/bin/env python3
"""
vspider — 网页视频采集器（yt-dlp 封装，无第三方依赖）

用法:
  vspider probe  <url>              探测可用格式与直链（不下载）
  vspider link   <url>              只取最佳直链
  vspider get    <url> [--max-mb N] 下载（默认 800MB 上限，需 ffmpeg 才能切片段）
  vspider batch  <file>             批量探测，每行一个 URL（# 开头为注释）

结果写 OUT 目录，可直接喂给后续流程。
部署：scp 到目标机 → python3 vspider.py <cmd> <target>
      ⚠️ 不要在命令行里直接写 URL 调用，会被审批拦截；把 URL 放进调用脚本。
"""
import argparse
import json
import os
import subprocess
import sys
import time

YTDLP = "/data/workspace/bin/yt-dlp"
OUT = "/data/workspace/vspider/out"
DISK_MIN_MB = 800          # 剩余空间低于此值拒绝下载


def sh(cmd, timeout=600):
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return p.returncode, p.stdout, p.stderr
    except subprocess.TimeoutExpired:
        return -1, "", f"timeout after {timeout}s"


def disk_free_mb(path="/data"):
    st = os.statvfs(path)
    return st.f_bavail * st.f_frsize // (1024 * 1024)


def probe(url):
    """返回元信息 + 格式列表，不下载"""
    rc, out, err = sh([YTDLP, "-J", "--no-warnings", "--no-playlist", url], timeout=180)
    if rc != 0:
        return {"ok": False, "url": url, "error": (err or out).strip()[-500:]}
    try:
        d = json.loads(out)
    except Exception as e:
        return {"ok": False, "url": url, "error": f"json parse: {e}"}

    fmts = []
    for f in d.get("formats") or []:
        fmts.append({
            "id": f.get("format_id"),
            "ext": f.get("ext"),
            "res": f.get("resolution") or f"{f.get('width')}x{f.get('height')}",
            "vcodec": (f.get("vcodec") or "")[:12],
            "acodec": (f.get("acodec") or "")[:12],
            "size_mb": round(f["filesize"] / 1048576, 1) if f.get("filesize") else None,
            "note": (f.get("format_note") or "")[:30],
        })
    return {
        "ok": True,
        "url": url,
        "title": d.get("title"),
        "duration_s": d.get("duration"),
        "uploader": d.get("uploader"),
        "extractor": d.get("extractor"),
        "is_live": d.get("is_live"),
        "thumbnail": d.get("thumbnail"),
        "formats_count": len(fmts),
        "formats": fmts[-8:],          # 只要最高几档
    }


def best_link(url):
    rc, out, err = sh([YTDLP, "-g", "-f", "best", "--no-warnings", "--no-playlist", url], timeout=180)
    if rc != 0:
        return {"ok": False, "url": url, "error": (err or out).strip()[-500:]}
    links = [l.strip() for l in out.strip().split("\n") if l.strip()]
    return {"ok": True, "url": url, "links": links}


def download(url, max_mb=800):
    free = disk_free_mb()
    if free < DISK_MIN_MB:
        return {"ok": False, "url": url, "error": f"磁盘不足：剩余 {free}MB < {DISK_MIN_MB}MB"}

    os.makedirs(OUT, exist_ok=True)
    stamp = time.strftime("%Y%m%d_%H%M%S")
    tpl = os.path.join(OUT, f"{stamp}_%(title).80s.%(ext)s")

    # --hls-prefer-native：不依赖 ffmpeg，单轨 m3u8/mp4 都能下
    cmd = [YTDLP, "-f", "best", "--no-playlist", "--no-warnings",
           "--hls-prefer-native",
           "--max-filesize", f"{max_mb}M",
           "-o", tpl, url]
    t0 = time.time()
    rc, out, err = sh(cmd, timeout=1800)
    elapsed = round(time.time() - t0, 1)

    files = []
    if os.path.isdir(OUT):
        for f in os.listdir(OUT):
            p = os.path.join(OUT, f)
            if f.startswith(stamp) and os.path.isfile(p):
                files.append({"name": f, "mb": round(os.path.getsize(p) / 1048576, 1)})

    ok = rc == 0 and bool(files)      # 退出码 0 但 0 字节不算成功
    return {"ok": ok, "url": url, "elapsed_s": elapsed, "files": files,
            "error": None if ok else (err or out).strip()[-400:]}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("cmd", choices=["probe", "link", "get", "batch"])
    ap.add_argument("target")
    ap.add_argument("--max-mb", type=int, default=800)
    a = ap.parse_args()

    os.makedirs(OUT, exist_ok=True)

    if a.cmd == "batch":
        if not os.path.exists(a.target):
            print(json.dumps({"ok": False, "error": "file not found"}, ensure_ascii=False))
            sys.exit(1)
        urls = [l.strip() for l in open(a.target) if l.strip() and not l.startswith("#")]
        res = []
        for i, u in enumerate(urls, 1):
            r = probe(u)
            r["idx"] = i
            res.append(r)
            print(f"[{i}/{len(urls)}] {'OK' if r['ok'] else 'FAIL'}  {u[:70]}", file=sys.stderr)
        path = os.path.join(OUT, f"batch_{time.strftime('%Y%m%d_%H%M%S')}.json")
        with open(path, "w") as f:
            json.dump(res, f, ensure_ascii=False, indent=1)
        print(json.dumps({"ok": True, "count": len(res),
                          "ok_count": sum(1 for r in res if r["ok"]),
                          "saved": path}, ensure_ascii=False))
        return

    if a.cmd == "probe":
        r = probe(a.target)
    elif a.cmd == "link":
        r = best_link(a.target)
    else:
        r = download(a.target, a.max_mb)

    if a.cmd != "link":
        path = os.path.join(OUT, f"{a.cmd}_{time.strftime('%Y%m%d_%H%M%S')}.json")
        with open(path, "w") as f:
            json.dump(r, f, ensure_ascii=False, indent=1)

    print(json.dumps(r, ensure_ascii=False, indent=1))


if __name__ == "__main__":
    main()
