---
name: ctf-crypto-puzzles
version: 1.0.0
author: lemon
license: MIT
description: Use when solving, analyzing, or crafting crypto/CTF puzzles.
tags: [cryptography, ctf, ciphers, cryptojs, aes, brainfuck, decoding]
metadata:
  hermes:
    tags: [cryptography, ctf, ciphers, cryptojs, aes, brainfuck, decoding]
    related_skills: [systematic-debugging]
---

# CTF Crypto Puzzles & Ciphers

Comprehensive guide for analyzing, cracking, and authoring multi-layer cryptographic and encoding puzzles (CTF, web tools, classical & esoteric ciphers).

## When to Use
- Analyzing or decrypting multi-layer strings, Base64/Hex/Binary payloads, or web-tool outputs (e.g. `matools.com`, OpenSSL/CryptoJS `U2FsdGVkX1` formats).
- Diagnosing corrupted, truncated, or incomplete ciphertext blocks.
- Designing engaging cryptographic challenges and puzzle encodings (Brainfuck, Core Values, Morse, AES-CBC).

## 1. Modern Web & Symmetric Ciphers (CryptoJS / OpenSSL)

### Key Header & Format Recognition
- **`U2FsdGVkX1`**: The canonical OpenSSL / CryptoJS magic header (`Salted__` in Base64).
- **Structure**: `8 bytes "Salted__" + 8 bytes Salt + N * Block_Size ciphertext`.
- **Block Sizing**:
  - **AES**: 16-byte block size (Base64 length must be $44, 64, 88, 108, \dots$).
  - **DES / TripleDES / Blowfish**: 8-byte block size.
  - **Stream (RC4, Rabbit)**: arbitrary byte length.

### Fragmented / Truncated Ciphertext Diagnostics
- If Base64 length is not a multiple of 4, or ciphertext byte length is not aligned to block size:
  - Calculate: $\text{missing bytes} = \text{Block Size} - (\text{Ciphertext Bytes} \bmod \text{Block Size})$.
  - Often caused by copy-paste clipping or line wrapping (e.g., 50 chars/line).
  - AES-CBC block independence: earlier 16-byte blocks can still be decrypted with `padding: NoPadding` even if trailing blocks are missing.

---

## 2. Esoteric & Abstract Encodings (Puzzle Crafting)

### A. Core Socialist Values Encoding (核心价值观编码)
Widely recognized in Chinese CTF / puzzle communities. Converts UTF-8 hex into 12 core value tokens.
- **Tokens**: 富强(0), 民主(1), 文明(2), 和谐(3), 自由(4), 平等(5), 公正(6), 法治(7), 爱国(8), 敬业(9), 诚信(10), 友善(11).
- **Online Solvers**: bugku, atoolbox, sym233 core-values-encoder.

### B. Brainfuck Code Generation
Minimalist, visual impact, Turing-complete.
- Run natively in any online BF interpreter to yield plaintext.
- Generator pattern in Python:
  ```python
  def text_to_bf(text):
      out = ""
      for b in text.encode('utf-8'):
          out += "+" * (b // 10) + "[>++++++++++<-]>"
          rem = b % 10
          if rem > 0:
              out += "+" * rem
          out += ".<[-]"
      return out
  ```

### C. Multi-Layer Chaining (Onion Routing)
- Combine: `Plaintext -> AES (key) -> Base64 -> Hex / Binary -> Morse Code / Brainfuck`.

---

## 3. Pitfalls & Anti-Patterns

### ⚠️ Zero-Width Unicode Steganography Failure on Modern Mobile / Chat Apps
- **Pitfall**: Embedding zero-width characters (`\u200b`, `\u200c`, `\u200d`) into text.
- **Why it fails in practice**:
  1. Modern mobile operating systems (iOS / Android) and IME input engines treat zero-width sequences as a single **grapheme cluster** attached to the preceding character. Pressing backspace once deletes the whole cluster, defeating the tactile "deleting invisible characters" effect.
  2. Rich-text chat platforms (Telegram, WeChat, Slack) often normalize or strip zero-width characters during message transmission and clipboard copy.
- **Recommendation**: Avoid zero-width steganography for mobile chat challenges; use explicit encodings (Core Values, Brainfuck, Morse, Hex, Base64/AES) instead.
