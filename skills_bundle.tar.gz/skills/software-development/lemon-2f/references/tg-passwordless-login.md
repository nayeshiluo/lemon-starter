# TG 免密登录体系设计与实现（2026-09-06 提交 cf29bf0）

需求来源：爸爸要让 Emby 群成员凭 TG 身份零密码登录二楼面板（原 Emby 密码穿透
对群友不可行）。EMOS 式 Token 形态参照 emos.club 的 `{uid}_{random}` 风格。

## 双通道登录
1. **个人长期 Token（主）**：Bot 私聊 `/token` 签发 → 面板登录弹窗【Token 速登】
   → `POST /api/auth/token-login` → 换 7 天 JWT 会话。
   - 格式：`f"{user_id}_{secrets.token_hex(32)}"`（约 67 字符，128bit 熵）
   - 存储：DB 只存 `SHA-256(token)`（`User.personal_token_hash`），明文仅签发瞬间返回
   - **滚动语义**：每次 `/token` 重新签发覆盖旧哈希 = 旧 Token 立即失效（查看即重置）
   - 限速：进程内 dict `token_hash -> [fail_ts...]`，5 次失败锁 10 分钟（429）
2. **TG 验证码（次）**：Bot `/login` 发 8 位一次性码 → 面板输入 数字ID/@用户名 + 码
   → `POST /api/auth/tg-login`。
   - 表 `tg_login_codes`：只存 code_hash、TTL 5 分钟、fail_count 5 次即作废、
     消费即毁、同 TG partial unique index 仅 1 个有效码
   - **滚动签发**：每次 /login 删除旧的再插新码（先前"复用旧码"分支返回哈希，
     用户拿到用不了的码——必须删旧发新）
   - 未建档 TG 拒绝签发/登录（防陌生人占码位）

## 群成员自动建档（`provision_tg_user`）
- Bot `/start`：遍历 `TG_ALLOWED_GROUP_IDS` 白名单群，`get_chat_member` 核验
  该用户真实在群里 → 建档 + `INITIAL_USER_COINS`(幂等键 `init_user_{id}` 只发一次)
  + 签发 token → 推送欢迎语含 token
- 提权：`TG_OWNER_ID` → owner；`TG_ADMIN_IDS` → admin；其余 user
- username 生成：优先 tg_username，为空 `tg{id}`，冲突追加数字后缀
- 管理员批量：`POST /api/admin/tg-sync-group {chat_id, user_ids?}`——普通 bot 无法
  枚举群全成员，不传 user_ids 只同步群管理员，其余成员靠 /start 自助；
  bot 未运行 Fail-Closed 503

## 配置项（.env）
```
TG_OWNER_ID=0
TG_ALLOWED_GROUP_IDS=[]   # 逗号分隔群 id，超级群为 -100 开头负数
```

## 迁移
`migrations/versions/20260906_0100_a1b2c3d4e5f6_add_personal_token_and_tg_login_codes.py`
- users 加 `personal_token_hash` / `personal_token_created_at`
- 新表 `tg_login_codes` + partial unique `uq_tg_login_active_code`
  （postgresql_where + sqlite_where 双写）

## 测试
`tests/test_tg_token_login.py` 23 项：格式/哈希/滚动/限速/重放/爆破/过期销毁/
@username 多匹配拒绝/建档幂等/提权/username 冲突后缀/越权 403/bot 缺失 503/
`/link` 静态回归（断言 bot.py 源码无 `tg_first_name`）。