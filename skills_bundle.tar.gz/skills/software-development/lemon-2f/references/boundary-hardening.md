# 边界加固实现细节（2026-09-06，提交 b8d923c #13）

背景：评审指出项目"边界没做好"——防御性边界（限流、容量、上传总量）缺失。
本文件记录 `backend/rate_limit.py` 与上传三重防线的实现，供后续扩展/排障。

## 一、backend/rate_limit.py（进程内滑动窗口守卫，零外部依赖）

### LoginRateGuard（登录暴破守卫）
- 语义：滑动窗口内失败次数达 `MAX_FAILS`(5) → 锁定 `LOCK_SECONDS`(600)。
- 维度：调用方构造 key `f"{username}|{client_ip}"`（auth.py 内联）。
- API：
  - `check(key)` — 放行或抛 `LoginBlocked(retry_after)`（调用方 → 429 + Retry-After 头）；
  - `record_failure(key)` — 仅在最终失败分支调用；
  - `on_success(key)` — 登录成功清零（防合法用户被历史失败误伤）；
  - `reset()` — 测试 fixture 隔离用。
- 多 worker：每个进程独立计数，阈值按单进程最坏情况设偏紧 + DB 层约束兜底。
- 注意：auth.py login 端点的 guard_key 在**密码校验之前**就 check（先拦截再干活）；
  三个成功分支（Emby 穿透成功 / 本地密码 / 开发模式初始体验）都要 on_success。

### BytesWindowLimiter（上传会话字节额度）
- 构造：`(max_bytes, window_seconds)`；`allow(key, add_bytes) -> (ok, remaining)`
- 拒绝时不写入记录；`refund(key, bytes)` 按记录顺序（FIFO）退还，超量自动截断到 0；
- `reset()` 测试隔离。
- 惰性单例：`submissions.py` 的 `get_upload_limiter()`，额度/窗口读 settings；
  测试 monkeypatch settings 后必须 `sub_modules._upload_limiter = None` 强制重建。

## 二、/submissions/upload-file 三重防线（f67 行区）

1. **磁盘水位**：`_check_disk_watermark(upload_dir)` 在 mkdir 后、写盘前调用；
   `shutil.disk_usage` 探测 OSError 时放行（与看板口径一致），HTTPException 上抛。
   配置 `MIN_DISK_FREE_PERCENT`(默认 10.0)。
2. **单文件上限**：写入循环累计 `total_written`，超 `UPLOAD_MAX_FILE_SIZE_MB`(10240)
   → 413，catch HTTPException 分支删除已写文件。
3. **会话额度**：每 4MB chunk `limiter.allow(str(user.id), len(chunk))` 预扣，拒绝即 413
   + 删文件；入库 409 冲突时 `refund(str(user.id), total_written)` 退还。
- 空文件（total_written==0）→ 400，且删除空文件。
- 413 常量兼容：顶层 `try: HTTP_413 = status.HTTP_413_CONTENT_TOO_LARGE
  except AttributeError: HTTP_413 = status.HTTP_413_REQUEST_ENTITY_TOO_LARGE`。

## 三、HTTP 状态码语义
- 429 Too Many Requests（登录限流，带 Retry-After）
- 413 Payload/Content Too Large（单文件/会话超限）
- 507 Insufficient Storage（磁盘水位，FastAPI 提供该常量）

## 四、测试要点（tests/test_boundary_hardening.py，10 项）
- LoginRateGuard 单测：锁定/恢复/成功清零/key 隔离（构造小 MAX_FAILS 实例）
- HTTP 登录暴破：5×401 → 第 6 次 429 + Retry-After 头存在
- 开发模式成功登录（admin/123456）清零失败计数 → 再错不提前 429
- 磁盘 507：monkeypatch `sub_mod.shutil.disk_usage` 返回 free 5%
- 单文件 413：monkeypatch `UPLOAD_MAX_FILE_SIZE_MB=1`，传 2MB BytesIO，
  断言 413 + `/tmp/lemon_2f_uploads/` 无残留
- 非法扩展名 400 回归
- 真实冒烟（uvicorn）：连打 5 次错密码 → 第 6 次 429；小上限起服务传超限 → 413 + 残留 0

## 五、仍待办（P0 路线图）
- 单用户并发预占配额 ≤3
- 通用 API 限流中间件（目前仅登录/上传有守卫）
- Emby Webhook 实时联动 / AList 网盘真实转存 / PT 发种