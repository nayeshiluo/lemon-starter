---
name: lemon-2f
description: 二楼有请(Lemon 2F) 众包影视入库系统开发排障手册。触发"二楼/lemon-2f 项目改动"任务。
version: 1.0.0
author: hermes-curator
license: MIT
metadata:
  hermes:
    tags: [lemon-2f, emby, fastapi, telegram, 众包, 影视]
    related_skills: [github-pr-workflow, hermes-agent-skill-authoring]
---

## When to Use

- 爸爸要求开发/修改/排障/部署 **二楼有请（Lemon 2F）** 的任何功能；
- 在 `/home/ubuntu/lemon-2f` 下写代码、跑测试、改迁移、做前端、推 GitHub 时；
- 涉及该项目的认证、投稿流水线、积分、bot 命令、前端面板的疑问或报错排查。

# 🍋 二楼有请 (Lemon 2F) — 开发/排障/部署手册

GitHub: `nayeshiluo/lemon-2f` · 本地: `/home/ubuntu/lemon-2f`
Emby 众包影视入库系统：TMDB 权威刮削、查缺补漏、四轨多源投稿、强制规范化重命名、软妹币经济、TG 免密登录。

## 技术栈与结构
- **Backend**: FastAPI + SQLAlchemy 2.0 Async + Alembic + Redis(可降级) + python-telegram-bot
- **Frontend**: 单文件 `frontend/index.html`（Vue3 CDN + Tailwind，无构建链）
- **DB 默认**: PostgreSQL(asyncpg)，测试用 SQLite 内存库
- 分层：`backend/routes/v1/`(API) → `services/`(业务) → `repositories/`(数据) → `models/`

## 必用命令（每次改动后执行）
```bash
# 全量测试（必须全绿才算完成；现 214 项）
cd /home/ubuntu/lemon-2f && PYTHONPATH=. APP_ENV=testing python3 -m pytest tests -q
# 端到端演练（25 断言：并发双删/越权/穿越/控分）
PYTHONPATH=. APP_ENV=testing python3 tests/sim_drill.py
# 新迁移真实验证（空 SQLite 跑迁移链，确认新 revision 能落库）
APP_ENV=testing DATABASE_URL="sqlite+aiosqlite:////tmp/x.db" python3 -m alembic upgrade head
```

## ⚠️ 真实验证铁律（爸爸硬性要求："实际验证后再说搞定"）
**ASGI 测试（httpx ASGITransport）不跑 lifespan** —— pipeline worker、Redis 连接、
bot 启动等启动期逻辑全部测不到。新功能必须再起真实 uvicorn 冒烟：
```bash
APP_ENV=testing DATABASE_URL="sqlite+aiosqlite:////tmp/smoke.db" SECRET_KEY=xxx \
  python3 -m uvicorn backend.main:app --port 8787 --log-level warning
```
- **必须先建表再起服务**：`init_db()` 或 `alembic upgrade head`，否则 pipeline worker
  启动即 `no such table` 刷屏（部署顺序依赖，README 要求 compose 后先迁移）。
- 冒烟至少打：前端 `/` 200、登录接口 401/200 语义正确、新端点真实命中。

## 认证矩阵（四通道并存，身份权威：Emby 账号 + TG 身份）
| 通道 | 入口 | 说明 |
|---|---|---|
| Emby 密码穿透 | `POST /auth/login` | Emby User/Auth 校验，自动建档发币 |
| 本地密码 | `POST /auth/login` | password_hash SHA-256+盐 |
| **个人 Token(EMOS 式)** | `POST /auth/token-login` | `{uid}_{64hex}`，Bot `/token` 签发 |
| **TG 验证码** | `POST /auth/tg-login` | 数字ID/@用户名 + Bot `/login` 一次性 8 位码 |

TG 免密登录的完整设计（哈希存储、滚动、限速、防爆破、群成员建档、配置项）见
`references/tg-passwordless-login.md`。

## 边界防线（2026-09 加固，`backend/rate_limit.py`）
- **登录限流**：`LoginRateGuard` 按 `用户名|客户端IP` 维度，5 次失败→锁 10 分钟，HTTP 429 + `Retry-After` 头；登录成功 `on_success` 清零防误伤；`record_failure` 只在最终失败分支调用（Emby 穿透失败/密码错/开发模式兜底失败）。
- **上传三重**（`/submissions/upload-file`）：
  ① 落盘前 `_check_disk_watermark`：free < `MIN_DISK_FREE_PERCENT` → 507 Insufficient Storage；
  ② 单文件上限 `UPLOAD_MAX_FILE_SIZE_MB`(默认10240) → 413 且**立即删除已写分块**；
  ③ 会话额度 `BytesWindowLimiter`：每用户 24h 累计 `UPLOAD_MAX_SESSION_MB`(默认20480)，按 4MB 块预扣，超限 413；入库 409 冲突时 `refund()` 退还，用户不白亏配额。
- 空文件上传 → 400（且清理空文件）。
- 惰性单例模式：`get_upload_limiter()`，测试 monkeypatch settings 后须置 `sub_modules._upload_limiter = None` 重建。

## 坑与教训（本会话实测，改代码前先看）
1. **service 签名改完必须 grep 全部调用点**：历史缺陷——`bot.py cmd_link` 调
   `issue_code(..., tg_first_name=...)`，service 无此参数 → `/link` 一调即 TypeError，
   且测试全绿（无测试走 bot handler 直调路径）。修完加一条静态回归断言锁死。
2. **partial unique index 迁移必须双写 where**：`postgresql_where=` + `sqlite_where=`，
   否则测试库(SQLite)与生产库(PG)行为不一致。
3. **TG 超级群 ID 是负数(-100xxx)**：Pydantic 校验禁止 `gt=0`。
4. **JWT 里的 role 声明不生效**：`require_admin` 从 DB 读 `current_user.role`。
   测试造管理员 token 必须用真实 admin 角色的用户对象，否则拿到 403。
5. **patch 工具改 HTML/Vue 字符串会多层转义**：`\\n` 易打成 `\\\\n`（聊天里显示字面
   `\n`）；改完必须读文件确认。patch 的 old_string 范围不当会误删模板结构（如 div 闭合），
   HTML 模板改动后务必通读受影响区域。
6. **token/登录码敏感操作落审计**：audit_repo.log 记录签发/登录/建档，`expire_on_commit=False`
   下 commit 后对象属性仍可安全访问。
7. **测试基建模式**：每文件自建 env fixture（内存库 + `app.dependency_overrides[get_db]`
   + httpx ASGITransport），参考 `tests/test_tg_token_login.py` 与 `test_tg_bind.py`。
8. **进程内限速指纹跨测试污染**：模块级 dict 计数器（如 token 登录失败锁定）在 fixture
   里必须 clear，否则测试互相干扰。
9. **starlette 413 常量改名**：新版本 `HTTP_413_REQUEST_ENTITY_TOO_LARGE` →
   `HTTP_413_CONTENT_TOO_LARGE`，用 `try/except AttributeError` 兼容双版本。
10. **上传测试断言残留**：413/507 用例须断言 `/tmp/lemon_2f_uploads/` 无残留文件，
    防止"超限但分块已写盘"的静默漏洞；multipart 直传用 `io.BytesIO` 造伪视频即可。
11. **权限测试的 admin 用户**：env fixture 里单独建 `role="admin"` 的用户（如 carol），
    不要复用 alice 并改职权 —— 会破坏普通用户 403 用例的语义。
12. **真实冒烟验证限速**：起 uvicorn 后连打 5 次错密码断言 401→第 6 次 429、
    传超限文件断言 413 且残留 0 —— 这两条是边界功能的真伪验证（ASGI 测试测不到启动态）。

## 交付规范（爸爸偏好）
- 全部输出中文；排障单步只读、报真实结果再继续；错误主动报告禁止静默。
- 完成定义 = 全量测试绿 + 真实服务冒烟绿 + 迁移链验证 + git 提交推送（提交信息带
  feat/fix 前缀 + `(#<PR序号>)`）。
- 前端改动是单文件 HTML，用词保持赛博暗黑粉紫风。

## references/
- `references/tg-passwordless-login.md` — TG 免密登录体系设计与实现细节（2026-09）
- `references/boundary-hardening.md` — 边界加固实现细节：限流守卫 API、上传三重防线、测试要点（2026-09）