---
name: webapp-security-hardening
description: Use when 评审反馈 Web/API"边界没做好"或需给登录/上传/经济接口加固限流防滥用。
---

# Web 应用安全边界审计与加固

## 何时使用
- 用户转达评审意见（"边界没做好"）或要求"继续优化"已有的 Web 项目
- 新增登录、上传、经济结算（抽奖/红包/签到/抢单）类接口需要防滥用
- 审计 FastAPI（或同类 SQLAlchemy+ASGI）项目的权限与资源边界

## 先把边界分四类，再动手
1. **垂直越权**：普通用户干管理员的事（缺 role 守卫）
2. **水平越权**：用户 A 看/删用户 B 的数据（缺 owner 隔离 / IDOR 面）
3. **输入边界**：脏输入、超大文件、畸形参数打爆内存/磁盘
4. **资源边界**：脚本无限刷接口、刷币、囤坑

## 审计清单（grep 找缺口，不靠猜）
- 所有 `@router.(get|post|...)`：写端点有没有 `Depends(require_*)`？公共读流是否用**脱敏 response model**（响应里不得出现 magnet_uri/内部路径/种子哈希）？
- 登录端点（密码/Emby 穿透）：有无失败限流？
- 上传端点：单文件大小上限？磁盘水位检查？校验失败已写分块是否立即清理？
- 高频写接口：频率限制 + 业务唯一约束（DB unique）+ 并发数量配额 三层缺哪个？
- 分页参数：`page_size` 是否封顶（无上限可被用于打爆内存；page=0 在 PG 直接 OFFSET 负数 500）
- 幂等键：**毫秒时间戳做幂等键 = 形同虚设**（只有同毫秒并发才撞），要用确定性业务键（如 `init_user_{id}`、`tg_sign_{uid}_{date}`）

## 已验证的加固模式
### 1. 登录限流（失败计数 + 锁定期）
- 滑动窗口按 `用户名|IP` 计失败；如 5 次/5 分钟 → 锁 10 分钟；**成功立即清零**（防合法用户被历史失败误伤）
- 返回 429 + `Retry-After` 头
### 2. 通用端点限流：FastAPI 依赖工厂
- `RateLimit(max_hits, window)` 返回 `Depends(dependency)`；key = JWT sub（已登录按 uid，只 decode 不查库），匿名按 IP
- **按 uid 不按 IP**：群聊/公司 NAT 共享出口 IP 时互不挤兑
- 端点接入：`_rl: None = wheel_rate` 参数即可；不影响既有路由契约测试
- 阈值按"单进程最坏情况"取偏紧值（多 worker 各自计数，会被放大 N 倍）
### 3. 上传三重边界
- 磁盘水位：落盘前 `shutil.disk_usage(upload_dir)`，free% < 阈值 → **507 Insufficient Storage**
- 单文件上限：流式写入累计，超限 → **413**，且 except 分支立即 `os.remove(已写文件)`（零残留）
- 会话累计：滑动窗口字节额度（每用户 24h），超限 413；**入库失败（409）要 refund 退还已扣额度**，用户不白亏
### 4. 并发预占配额（防抢坑囤积）
- 创建任务入口：`count(status IN active_statuses) >= 阈值` → 拒绝（配额检查必须放在外部依赖调用**之前**）
- 已完成（accepted/failed）不占配额；阈值进 config，测试可 monkeypatch
### 5. 长期凭据（Token / API Key）
- 只存 SHA-256 哈希，明文仅在签发当次返回；再次签发 = 滚动，旧凭据立即失效（哈希被覆盖）
- 展示即重置语义：`/token` 每次返回新值，天然支持"泄露了再刷一个"

## 复验工作流（关键，不能省）
- **ASGI-Transport 测试不跑 lifespan**：后台 worker、中间件装配问题只有真实 uvicorn 才暴露（曾出现测试全绿、真实服务 500）
- 空库启动顺序：**先 `alembic upgrade head`（或 init_db 建表）再启动**，否则后台 worker 一启动就查不存在的表 → 刷屏 "no such table"
- 新迁移必须挂到真实 alembic 链上验证（down_revision 指向当前 head，upgrade 真实跑通）
- 冒烟：登录暴破打 6 次看第 6 次 429；超限文件传完查残留=0；迁移/启动/端点全走真服务（见 scripts/smoke_security_checks.sh）

## 陷阱（本类任务高频坑）
- `pydantic Field(gt=0)` 会拒绝负数 ID —— **TG 超级群 ID 是 -100xxx**，chat_id 不能加 gt=0
- starlette 新版把 413 常量改名 `HTTP_413_CONTENT_TOO_LARGE`：用 try/except 兼容旧常量
- 测试环境绕外部依赖（TMDB/Emby）：**预建 MediaTask/Task 记录**让服务命中 existing 分支，避免触发网络刮削报"未配置 Key"
- 轮盘/抽奖类：EV 为负也挡不住脚本刷卡密/徽章（奖品价值主观），必须给频率限制
- Pyright 对 `backend.*` import 报错是 venv 未接入的类型检查噪音，项目里其他文件同样报，忽略

## 支持文件
- `references/boundary-taxonomy.md` — 四类边界定义 + 审计 grep 命令模板
- `references/lemon-2f-hardening-log.md` — 二楼有请项目三次加固实录（TG 免密登录 / 边界补强 / 限流+配额），含各端点的实际阈值
- `scripts/smoke_security_checks.sh` — 真实服务安全冒烟脚本（登录 429 / 上传 413 / 残留检查）