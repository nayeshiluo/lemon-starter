# 边界四分类与审计 grep 模板

## 四类边界定义
| 类型 | 定义 | 典型翻车点 |
| :--- | :--- | :--- |
| 垂直越权 | 低权限角色执行高权限操作 | 写端点漏 `Depends(require_admin/owner)`；JWT 里宣称 role 但权限检查读的是 DB role |
| 水平越权 | 同级别用户互相操作彼此数据 | 公开详情端点无 owner 校验（IDOR）；列表流未脱敏（泄露他人 magnet/路径/种子 hash） |
| 输入边界 | 脏输入/超大载荷打爆系统 | 上传无大小上限塞满磁盘；page_size 无上限打爆内存；page=0 在 PG 报 OFFSET 负数 |
| 资源边界 | 脚本/并发滥用 | 登录暴破；抽奖/签到/抢单无限刷；单用户囤积大量任务坑位 |

## 审计 grep 命令模板
```bash
# 1. 找出所有路由端点（先看谁没守卫）
grep -rn "@router\.\(get\|post\|put\|delete\|patch\)(" backend/routes/

# 2. 项目里有没有限流实现 / 429
grep -rniE "rate.?limit|slowapi|limiter|throttl|429|MAX_" backend/ --include="*.py" | grep -v test

# 3. 登录端点（密码鉴权处）有没有失败计数
grep -n "authenticate\|/login" backend/routes/v1/auth.py

# 4. 上传端点：大小上限 / 磁盘水位 / 残留清理
grep -n "MAX_\|disk_usage\|os.remove\|1024 \* 1024" backend/routes/v1/*submission*.py

# 5. 公共读流是否用脱敏 model
grep -n "Public.*Response\|model_validate" backend/routes/v1/*.py

# 6. 并发预占/配额
grep -rn "RESERVATION_TTL\|active_count\|MAX_ACTIVE" backend/
```

## 关键洞察（评审语境翻译）
- "边界没做好" 在代码评审里 90% 指：授权隔离 + 输入/资源防御缺口
- 项目把账号隔离/并发双花/目录穿越做硬了，仍可能被吐槽限流与容量边界——这是两类工作，别混为一谈
- JWT 里的 role 声明不可信，权限判定要以 DB 里的用户 role 为准（测试曾因"JWT 写 admin 但 DB 是 user"而 403）