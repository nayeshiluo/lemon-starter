# 二楼有请 (lemon-2f) 安全加固实录 — 三次迭代的落地细节

项目：/home/ubuntu/lemon-2f（FastAPI + SQLAlchemy 2.0 Async + Vue3 单页 + Alembic + TG Bot）

## 第一波：TG 免密登录体系（EMOS 式 Token）
- 个人长期 Token：`{user_id}_{64位hex}`（`secrets.token_hex(32)`），**只存 SHA-256 哈希**，明文仅签发当次返回
- 滚动语义：每次 `/token` 签发新值覆盖旧哈希 → 旧 Token 立即失效；展示即重置
- 双通道登录：
  - `POST /api/auth/token-login {token}` → 换 JWT 会话
  - `POST /api/auth/tg-login {identifier, code}` → TG 数字 ID 或 @用户名 + Bot `/login` 8 位一次性码（TTL 5min，5 次输错作废，同 TG 同时仅 1 个有效码，只存哈希）
- 群成员自动建档：Bot `/start` → `find_allowed_group` 用 `get_chat_member` 核验其在 `TG_ALLOWED_GROUP_IDS` 白名单群 → 建档 + init 币（幂等键只发一次）+ 发 Token；`TG_ADMIN_IDS`/`TG_OWNER_ID` 自动提权
- 管理员批量：`POST /api/admin/tg-sync-group {chat_id, user_ids?}`（不传同步群管理员；普通 bot 无法枚举全群成员，普通成员靠 /start 自助）
- 顺手修的历史 bug：`cmd_link` 传 `issue_code(tg_first_name=...)` 而 service 签名没有该参数 → /link 一调用就 TypeError（已有测试回归锁定：源码不得再含 tg_first_name）

## 第二波：边界加固（登录限流 + 上传三重防线）
- `backend/rate_limit.py`：`LoginRateGuard`（失败 5 次/5 分钟 → 锁 10 分钟，成功清零，429 + Retry-After）+ `BytesWindowLimiter`（会话字节额度 + `refund`）
- `/api/auth/login` 按 `用户名|IP` 限流；上传端点三重边界：磁盘水位 507 / 单文件 413（except 立即删文件零残留）/ 24h 会话额度 413（409 冲突退额度）
- config：`UPLOAD_MAX_FILE_SIZE_MB=10240`、`UPLOAD_MAX_SESSION_MB=20480`、`UPLOAD_SESSION_WINDOW_HOURS=24`

## 第三波：通用端点限流 + 并发预占配额
- `RateLimit(max_hits, window)` 依赖工厂（key = JWT sub 按 uid，匿名按 IP；`dependency.limiter` 暴露给测试调参）
- 端点阈值（按单进程最坏情况取偏紧）：轮盘 5 次/分、抢红包 10 次/分、发红包 3 次/5 分、签到 15 次/分、投稿 10 次/分、直传 5 次/分
- `MAX_ACTIVE_SUBMISSIONS_PER_USER=3`：create_submission 最前面（外部依赖调用之前）count 活跃状态（pending/reserved/downloading/inspecting/delivering/waiting_emby），达到上限拒绝；accepted/failed 不占配额

## 测试与复验要点（本项目实测）
- 测试框架：`sqlite+aiosqlite:///:memory:` + `app.dependency_overrides[get_db]` + `httpx.ASGITransport`；env fixture 提供 user/token/admin token
- **限流测试**：monkeypatch `dep.dependency.limiter.max_hits`（如=2）快速触发 429，无需打满真实阈值
- **配额测试绕 TMDB**：预建 `MediaTask + TaskItem` 记录让 `get_or_create_task_from_tmdb` 命中 existing 分支（TMDB_API_KEY 未配置时直接调用会抛"服务端未配置"）
- **真实冒烟必做**：ASGI 测试不跑 lifespan（worker 不启动、中间件问题不暴露）；曾出现测试 204 全绿但真实 uvicorn 上 token-login 500（审计表写入时 DB 表齐全性/时序问题），只能在真服务上抓出来
- 空库启动顺序：`init_db()` 或 `alembic upgrade head` 先行，否则后台 pipeline worker 一启动即 "no such table: submissions"

## 数量轨迹
150 → 204（TG 登录 23 项）→ 214（边界 10 项）→ 221（限流配额 7 项）全绿。