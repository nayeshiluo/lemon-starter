---
name: worker-observability
description: Use when capturing Cloudflare Worker request logs.
---

# Cloudflare Worker Observability

## When to Use

Use when establishing live Cloudflare Worker log capture, verifying whether a public entry reaches a target Worker, or correlating bounded request events. Pair with the application's own skill for application-specific auth and data handling.

Use this class-level workflow to inspect live Worker requests, diagnose route coverage, and capture bounded, privacy-safe traces. This skill supplements application-specific skills; when working on an application such as Emby/EMOS, also follow that application's auth, privacy, and playback constraints.

## Read-only-first workflow

1. **Identify the exact target.** Confirm Cloudflare account, Worker script name, intended public hostname(s), and UTC/Asia-Shanghai observation window from current evidence. Do not infer that a public health endpoint and a player's protected media requests share the same domain or route.
2. **Separate logging products and permissions.** A Tail session, Workers Logs/Logpush, and Analytics/telemetry queries are distinct interfaces with different permissions and data models. An Analytics `403` means that query was denied; it does not mean no Worker traffic exists. Check current official Cloudflare API/docs before relying on endpoint paths or capabilities.
3. **Create a short-lived Tail using the supported API operation** for the exact script. Keep the returned stream URL private; it is a bearer-like session capability. Store transiently with owner-only file permissions, do not print it, and delete the Tail after capture or when stopping early.
4. **Connect with the Tail protocol, not a generic WebSocket assumption.** Use the `trace-v1` WebSocket subprotocol and send the Tail control frame `{"debug":false}` after connection. Support both text and binary message frames, decode to UTF-8, parse event JSON/arrays, and safely handle malformed/non-event messages.
5. **Validate event delivery before declaring ready.** While the stream is open, issue one benign, unauthenticated request through each intended public entry (for example a public status endpoint) with a random diagnostic marker. Confirm each event in Tail by hostname and response status. If no event appears, investigate account/script target, active Tail inventory, filters, control frame, frame format/decoding, and actual routing. Do not ask the user to repeat a real workflow just to test observability.
6. **Report readiness precisely.** Only after an entry probe is observed, say the capture is ready. State Beijing time, exact validated hostnames, and bounded expiry/window. Distinguish public probe coverage from authenticated/media-route coverage; do not claim the latter without evidence.
7. **Capture only allow-listed metadata.** Prefer event time, hostname, method, normalized route class, status, outcome, colo, and counts. Classify routes locally from the parsed pathname before discarding it; distinguish `PlaybackInfo`, playback progress/control, redirect, and actual media-stream candidates. Do not broadly label every `/Items/` or `/Videos/` path as media bytes: confirm the specific route semantics from the application/router first. Never print full URLs, query strings, headers, cookies, auth values, signed paths, user/media identifiers, or payload bodies. Avoid storing raw Tail frames unless strictly necessary; if briefly retained for decoding, restrict permissions and delete promptly.
8. **Interpret event timing conservatively.** Tail invocation events can show request metadata and response status but are not automatically client-observed latency, video first-byte time, player startup, or first-frame time. Stage timing requires explicit trustworthy instrumentation at the relevant boundaries. Report measured, inferred, and missing evidence separately.
9. **Cleanup and verify.** Stop the stream, delete the specific temporary Tail session, remove local session URL/config files, and read the active Tail list to confirm cleanup. Do not delete unknown pre-existing consumers or alter Worker settings/config as part of read-only observation.

10. **Package evidence only after it is actually built.** For external source review, fetch current deployed code read-only, record UTC retrieval time and SHA-256, verify any local artifact by digest, and label historical/staging copies explicitly. Scan source for hardcoded secrets/private addresses; make a separate sanitized copy only for confirmed findings and provide original plus sanitized hashes and replacement locations. Exclude bindings values, database contents, credentials, cookies, signed URLs, and historical backups. Include exact diffs (not ellipsis placeholders), test commands/dependencies, and fixture caveats. If an archive is requested, create it, inspect its member list, test extraction, calculate its digest, and verify the promised files are inside before reporting a download path.

## Pitfalls

- A GET to a wrong `/tail` path can return unrelated content; do not interpret that response as log output. Use the documented create/list/delete endpoints and inspect content type/shape without printing secrets.
- A `406` at WebSocket upgrade may be due to a missing `trace-v1` subprotocol. A successful create response or HTTP 101 handshake alone is not enough: protocol control frame plus actual probe event is the end-to-end check.
- Empty results may arise from target mismatch, filters, no configured consumer, permissions, incorrect frame handling, or a window mismatch. Do not conclude the user did not make a request.
- Smart Placement configuration is not proof of per-request execution location; use event colo/runtime evidence if available.
- Do not deploy a Tail consumer, enable Logpush, or alter production Worker code/settings without explicit authorization. If code-level timing is required, present the minimal patch, privacy review, verification plan, and rollback first.

## Reference

See `references/cloudflare-tail-validation.md` for the tested API/WebSocket procedure, safe probe checklist, and interpretation boundaries. See `references/emos-active-playback-tail.md` for active-playback polling, route-classification privacy, and lessons from SenPlayer/EMOS observation.
