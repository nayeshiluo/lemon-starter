# Cloudflare Tail validation reference

## Proven operation sequence

For a Worker script, create a Tail with `POST /client/v4/accounts/{account_id}/workers/scripts/{script_name}/tails` and a minimal JSON body. The API returns an ID, a WebSocket URL, and expiry. Treat the URL as a short-lived credential: do not print or persist longer than needed. List active sessions with `GET .../tails`; delete the exact session with `DELETE .../tails/{id}`.

Connect to the returned WebSocket negotiating subprotocol `trace-v1`. Wrangler's protocol sends `{"debug":false}` immediately after open. A bare HTTP 101 is not sufficient: keep the socket open and validate actual event delivery. Decode both text and binary frames and parse the event array; report only allow-listed metadata. Ensure all error and timeout paths close the WebSocket, delete the Tail, and remove the local secret-bearing config.

## End-to-end route proof

While connected, send one benign unauthenticated public endpoint request through every intended hostname, each with an independent random diagnostic marker in a harmless query parameter or header. Do not include credentials, signed media URLs, or private path values. Require a matching Tail event for each host, with expected status. This proves that those specific probe requests reached the target Worker event stream; it does not prove the player's protected playback request uses the same domain or route.

## Event interpretation limits

Tail events can include request/response metadata, outcome, colo and console logs, but a Tail observer may not include video bytes, exact upstream timing, stream first-byte timing, or player rendering/first-frame time. Never derive startup or first-frame latency from the public health probe or a Worker event timestamp alone. Playback-stage timings require existing correlated instrumentation at each hop or explicit approved minimal telemetry.

## Evidence and privacy checklist

- Record observation start/end in UTC and Asia/Shanghai; use the OS clock, not conversational time.
- Record script/account identity from the request target, but never expose account tokens, WebSocket URL, auth headers, cookies, signed URLs, media IDs, or secret path components.
- Summarize counts by hostname, normalized route class, status, outcome, and colo only.
- Distinguish: create permission, WebSocket connection, event receipt, public probe route proof, and protected media-route proof.
- If Analytics is forbidden, report the permission denial separately; it does not imply an absence of traffic.
- On completion, stop the observer, delete the Tail, delete temporary secret-bearing files, and verify no temporary Tail remains.
