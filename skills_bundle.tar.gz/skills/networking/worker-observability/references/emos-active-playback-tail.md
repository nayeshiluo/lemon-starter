# EMOS/SenPlayer playback observation notes

## What the Tail proved in this run

- Tail API create returned a live session; the returned URL was treated as a secret and kept in a mode-0600 temporary file.
- The working WebSocket handshake required `trace-v1`; after connection send `{"debug":false}` as Wrangler does.
- The first observer validated public probes at `zjw`, `yd`, and `yd-fd`. Matching Tail events showed each public probe reached the target Worker. This did not prove that SenPlayer's media route used those same public domains.
- The observer initially timed out after 180 seconds. That is a collection-window limit, not an origin or player failure. If the user already says they are actively playing and asks for correlation, start a new bounded Tail immediately, verify it is connected, and keep it open long enough to observe the current playback. Do not claim the original event was captured when the observer had already exited.
- A subsequent Tail received repeated `POST` playback-progress events from `zjw` at roughly 10-second intervals, plus generic `GET` events. This proved playback-progress signaling reached that Worker. Because the observer discarded paths, the generic GETs could not be classified retrospectively as PlaybackInfo, redirects, or media streams. No playback latency or first-byte metric was available.

## Reliable sequence for an active playback

1. Read the live clock and note the user's stated active-playback time; do not rely on earlier conversational timestamps alone.
2. Create a Tail for the verified account and script. Verify active tail inventory and successful WebSocket connection using `trace-v1`; send the control frame.
3. Start a sufficiently long but bounded observer and keep its process alive. Poll logs while the playback is active rather than waiting until the observer's short timeout has expired.
4. Parse event frames (text or binary) into JSON. Keep the raw pathname only in memory for classification; output only normalized route classes. Never print URL query strings, path components, headers, cookies, signatures, IDs, or payload.
5. Classify exact route groups separately: PlaybackInfo, playback progress/control, redirect, and media-stream candidate. Validate path mapping against the real Worker/router before treating a path as video bytes. Report timestamp, host, method, status, outcome, colo, and event counts only.
6. Tail records invocation events, not client-perceived latency. Do not infer playback startup, video first byte, transfer duration, or first frame from event timestamps. Need boundary instrumentation for those stages.
7. After analysis, terminate the observer, delete only the Tail created for the capture, remove the local stream URL file, and verify no session remains.

## Lessons / limits

- A Worker can produce many event records even when no `tail_consumers` are configured; an on-demand Tail session is distinct from persistent Tail Worker consumers and Logpush.
- A Tail's successful create and WebSocket handshake are not enough. A public probe event establishes only that host/request class; protected media routing needs its own captured event.
- Redacting a pathname before route classification can destroy the evidence needed to differentiate PlaybackInfo from playback-progress reports or stream requests. Classification must happen locally before sanitization.
- Failed or timed-out observers must not be reported as proof that no playback traffic existed. Distinguish observer lifetime/decoding, wrong entry host, and actual absence of captured events.
- If timing code is required in the production Worker, stop before editing: prepare the narrowest proposed patch, explain exact fields collected, preserve auth, Range/206, streaming and node reads, test and rollback steps, and obtain approval.
