# 反重力额度只读巡检（不消耗推理额度）

适用：用户问「额度还剩多少」「有几个账号/额度」「gemini 额度是不是少了」，需要**只看不调模型**地
核对当前 Antigravity 账号池的额度状态。与 `quota-exhaustion-diagnosis.md`（429 耗尽定性）互补：
本文件管「现在还剩多少、有几个」，那个管「为什么用完了、多久恢复」。

## 一键只读查询（首选，别手搓 curl）

运维 Bot 已封装好，直接跑：

```bash
cd /home/ubuntu/lemon-ops-bot && python3 quota_module.py
```

输出每个账号的套餐、模型分组、各额度项剩余百分比 + 重置时间（台北时区，末尾带采样时间戳）。
走的是 CPA 管理接口（`/v0/management/auth-files` + `/v0/management/api-call` 转发 Google 的
`retrieveUserQuotaSummary`），**不调用生成模型，不消耗 Gemini 推理额度**。

依赖：管理密钥文件 `/home/ubuntu/lemon-ops-bot/.cpa_management_key`（脚本自动读取，勿手动传 key）。

## 「额度」是三个不同维度，先跟用户对齐再下结论

用户说「额度有几个」时极容易混淆，务必先确认指哪一层：

| 维度 | 位置 | 现状（截至 2026-10） |
|---|---|---|
| 账号 | `~/.cli-proxy-api/antigravity-<email>.json`，看 `disabled` 字段 | 4 个：zjw100802062 / zhangmuzhi865 / alanhowellhvuvqw9 / mochenzmz |
| 模型分组 | 上游 quota 返回的 `groups[]` | **2026-10-24 起 Summary 只回 `Claude and GPT models` 一组**（Gemini 组消失，见下节） |
| 额度项/bucket | 每组 `buckets[]` | Summary 的 3p 组仍是 `3p-weekly` + `3p-5h` 两项 |

结构在 2026-10-07～10-20 期间是「每账号 2 组 × 2 项」；**2026-10-24 实测已变**，不要再照 2 组报「少了一组」，
也不要反过来当成账号掉权限。若用户说「之前三个现在两个」，先按上表三行对齐维度，再按下面两节分清是上游变更还是解析问题。

## 2026-10-24 实测：Summary 不再返回 Gemini 组（上游变更，非账号权限）

四个账号 × 三个 `retrieveUserQuotaSummary` 域名（daily / daily-sandbox / cloudcode-pa）全部 HTTP 200，
`groups` 均只有 `Claude and GPT models`（`3p-weekly` + `3p-5h`）。即：

- 不是接口选择问题（三域名结果一致），不是 UA/project/账号问题（同 project `aicode-consumers`、四号一致）；
- **`loadCodeAssist` 传 `ideType=GEMINI_CODE_ASSIST` 直接 400**，只有 `ANTIGRAVITY` 被接受，想靠换 IDE 类型拿组走不通；
- Gemini 额度其实还在：换 `POST v1internal:retrieveUserQuota`（body 仅 `{"project": ...}`）返回 16 个模型桶，
  其中 9 个 `gemini-*` 有余额（实测 98.5%～99.96%）；`v1internal:fetchAvailableModels` 同样给 9 个 gemini 模型的
  `quotaInfo.remainingFraction`。两者可交叉验证。

**两套数据的口径差异（不能混用）**：`retrieveUserQuota` 给 Claude/GPT 只报 5h 窗（同一时刻可能显示 100%），
而 weekly 只在 Summary 的 `3p-weekly` 桶里。所以：Claude/GPT 看 Summary，Gemini 看 `retrieveUserQuota`。

**因此「缺少 Gemini」这类完整性告警要按三层定性**：① 账号无权限（`loadCodeAssist` 非 200 / 无 project）
② 上游摘要接口不再给该组（Summary 只有 3p，但 retrieveUserQuota 有 gemini 桶）→ 属展示层问题，不该报账号异常
③ 客户端选源/解析丢组（Summary 里有组但输出没有）。一键取证跑 `scripts/antigravity-quota-probe.py`（只读、不耗额度）。

**运维 Bot 侧的修法（2026-10-24 已实施、已上线验证）** —— `/home/ubuntu/lemon-ops-bot/quota_module.py`：

1. 新增 `MODEL_QUOTA_URLS`（**daily + daily-sandbox 两个域名的 `v1internal:retrieveUserQuota`**，别只写一个）。
2. 新增 `_gemini_group_from_model_quota(auth_index, project)`：筛 `modelId` 含 `gemini` 的桶，取最小
   `remainingFraction` 与对应最早 `resetTime`，合成 `displayName` 形如 `Gemini models（N 个模型取最低）` 的组，
   桶 `window` 标 `per-model`。这样现有 `_format_account()` 一行不改就能渲染出百分比、图标与重置倒计时。
3. `_fetch_one()` 收尾分三支：
   - Summary 已含 Gemini → 原样返回，**不额外调接口**；
   - Summary 有组但缺 Gemini → 补调一次合成组 append 进 `groups`，用**局部布尔 `synthesized`** 决定是否打
     `ℹ️ Gemini 余额取自模型额度接口（摘要接口已不返回该分组）`。不要用 `any(... for g in groups)` 之类的集合推导式
     反复推断来源——第一次写就写成了恒真判断，多绕一轮；
   - Summary 全失败（`best_quota is None`）但模型额度接口能取到 Gemini → 仍然只展示 Gemini 组，不整条报错。
4. 只有两个来源都拿不到 Gemini 才输出 `⚠️ 额度分组不完整：缺少 …（摘要与模型额度接口均未取到）`。
   原来那句「缺少 Gemini（已尝试全部接口）」是**恒假告警**（Summary 已不返回该组），必须删掉，否则会淹没真问题。

**上线与验收（本次实跑顺序，照抄即可）**

```bash
cd /home/ubuntu/lemon-ops-bot
cp -a quota_module.py "quota_module.py.bak-gemini-group-$(date +%Y%m%d-%H%M%S)"   # 1. 备份
python3 -m py_compile quota_module.py                                              # 2. 语法
python3 -c "import quota_module; print(quota_module.get_antigravity_quota_text())" # 3. 直跑看真实输出
sudo -n systemctl restart lemon-ops.service                                        # 4. 重启（unit 在 /etc/systemd/system/，不是 user unit）
systemctl is-active lemon-ops.service; systemctl show lemon-ops -p MainPID          # 5. 确认 PID 已换
journalctl -u lemon-ops --since "3 minutes ago" --no-pager | tail -15              # 6. 守护进程拉起
```

- 第 3 步的验收标准要同时满足两条：**Gemini 组出现且百分比合理**，**Claude/GPT 的 weekly 数值与改动前一致**（证明没破坏原路径）。
- 第 6 步应看到「Telegram 命令菜单设置成功」「EMOS Auto-Sign 守护进程」「音乐库日报守护进程」，缺任何一条都算重启不完整。
- **改完必须同步源码快照**：`/home/ubuntu/hermes-ops-private/projects/lemon-ops-bot/quota_module.py` 是生产代码的
  sanitized 备份（见该目录 `README_SOURCE_BACKUP.md`，不含凭据，可直接 `cp`），改完 `cp` 过去并 `diff -q` 校验。
  不同步的话，以后按快照重部署会静默退回旧逻辑、恒假告警复发。
- 报告口径：5h 窗口的 `resetTime` 会随调用滚动变化（本次 11:30 → 13:08），与 weekly 的固定重置点不是一回事；
  weekly 只剩 0.9% / 0.0% 的号即使 5h 满额也发不出去，别把「5h 100%」讲成「这号还能用」。


## 历史额度快照（对比「之前 vs 现在」）

- `/home/ubuntu/hermes-jobs/jobs/hermes-quota-single-recheck-*/quota-result.txt`
- `/home/ubuntu/hermes-jobs/backups/hermes-request-diagnosis-*/quota-readonly-results.json`

想回答「之前是不是比现在多」，先读这两类快照对齐，别凭记忆猜。

## 坑

- **别手搓 `curl http://127.0.0.1:8317/...` + Authorization 头去查**：带密钥提取逻辑的 curl
  会触发安全层审批超时被 BLOCK。直接跑 `quota_module.py`（脚本自己读管理密钥），只读、干净、不卡审批。
- `disabled: false` 只代表账号在网关里未被禁用，**不代表额度充足**；额度是否健康要看 quota 返回的百分比。
