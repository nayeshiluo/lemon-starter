# 反重力额度只读巡检（不消耗推理额度）

适用：用户问「额度还剩多少」「有几个账号/额度」「gemini 额度是不是少了」，需要**只看不调模型**地
核对当前 Antigravity 账号池的额度状态。与 `quota-exhaustion-diagnosis.md`（429 耗尽定性）互补：
本文件管「现在还剩多少、有几个」，那个管「为什么用完了、多久恢复」。

## 一键只读查询（首选，别手搓 curl）

运维 Bot 已封装好，直接跑：

```bash
cd /home/ubuntu/lemon-ops-bot && python3 quota_module.py
```

输出每个账号的套餐、模型分组、各额度项剩余百分比 + 重置时间（台北时区，末尾带采样时间戳）。
走的是 CPA 管理接口（`/v0/management/auth-files` + `/v0/management/api-call` 转发 Google 的
`retrieveUserQuotaSummary`），**不调用生成模型，不消耗 Gemini 推理额度**。

依赖：管理密钥文件 `/home/ubuntu/lemon-ops-bot/.cpa_management_key`（脚本自动读取，勿手动传 key）。

## 「额度」是三个不同维度，先跟用户对齐再下结论

用户说「额度有几个」时极容易混淆，务必先确认指哪一层：

| 维度 | 位置 | 现状（截至 2026-10） |
|---|---|---|
| 账号 | `~/.cli-proxy-api/antigravity-<email>.json`，看 `disabled` 字段 | 4 个：zjw100802062 / zhangmuzhi865 / alanhowellhvuvqw9 / mochenzmz |
| 模型分组 | 上游 quota 返回的 `groups[]` | 固定 2 组：`Gemini Models` + `Claude and GPT models` |
| 额度项/bucket | 每组 `buckets[]` | 固定 2 项：`weekly`（周）+ `5h`（五小时） |

结构自 2026-10-07 至今未变，一直是「每账号 2 组 × 2 项」。若用户说「之前三个现在两个」，
多半是记忆偏差或看的是另一个面板——先按上表三行对齐维度，别急着找「消失的账号/额度项」。

## 历史额度快照（对比「之前 vs 现在」）

- `/home/ubuntu/hermes-jobs/jobs/hermes-quota-single-recheck-*/quota-result.txt`
- `/home/ubuntu/hermes-jobs/backups/hermes-request-diagnosis-*/quota-readonly-results.json`

想回答「之前是不是比现在多」，先读这两类快照对齐，别凭记忆猜。

## 坑

- **别手搓 `curl http://127.0.0.1:8317/...` + Authorization 头去查**：带密钥提取逻辑的 curl
  会触发安全层审批超时被 BLOCK。直接跑 `quota_module.py`（脚本自己读管理密钥），只读、干净、不卡审批。
- `disabled: false` 只代表账号在网关里未被禁用，**不代表额度充足**；额度是否健康要看 quota 返回的百分比。
