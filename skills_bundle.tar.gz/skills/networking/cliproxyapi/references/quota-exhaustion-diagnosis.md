# 429 配额耗尽：定性、恢复时间推断与静默监控

适用：CLIProxyAPI 网关（默认 8317）对**所有模型**持续返回 429，`systemctl is-active` 仍是 active，
账号 tier 正常、token 未过期、也没有 403 `VALIDATION_REQUIRED`。

这不是部署故障——是**上游配额真的用完了**。别重装、别重授权，先把下面三步跑完。

---

## 1. 先分清「每分钟限流」和「配额墙」（关键第一步）

两种 429 的处置完全不同，**只看错误码分不出来**，必须看时间分布。

从网关 journal 抽出 200/429 的**状态切换点**：

```bash
journalctl -u cliproxyapi --since "26 hours ago" --no-pager \
  | grep -E "127\.0\.0\.1 \| POST" \
  | sed -E 's/.*\[([0-9-]+) ([0-9:]+)\].*[[:space:]]([0-9]{3}) \|[[:space:]]+[0-9.]+s.*/\1 \2 \3/' \
  | awk '{print $1,$2,$3}' | sort > /tmp/llm_calls.txt

python3 - <<'EOF'
from datetime import datetime
rows=[]
for line in open('/tmp/llm_calls.txt'):
    p=line.split()
    if len(p)!=3: continue
    try: dt=datetime.strptime(p[0]+' '+p[1], '%Y-%m-%d %H:%M:%S')
    except: continue
    if p[2] not in ('200','429'): continue
    rows.append((dt,p[2]))
rows.sort()
prev=None
for dt,st in rows:
    if st!=prev:
        print(f"{dt.strftime('%m-%d %H:%M:%S')} UTC  -> {st}")
        prev=st
print("总调用:", len(rows))
EOF
```

判据：

| 形态 | 结论 | 处置 |
|---|---|---|
| 429 出现后 **~15 秒内**又回到 200 | 每分钟限流抖动 | 什么都不用做 |
| 429 出现后**持续全是 429**（再无 200） | **配额墙** | 走下面第 2~4 步 |

记录**首个持续 429 的时间戳**，后面算恢复耗时要用。

---

## 2. 从上游端点名读出「配额周期」

每个失败请求的详细 body 落在 `~/.cli-proxy-api/logs/error-v1-chat-completions-*.log`，
里面有 `=== REQUEST BODY ===`（下游请求）、`=== API REQUEST N ===`（**上游 URL + auth 文件 + 账号**）、
`=== API RESPONSE ===`（上游原始响应）。

```bash
ls -t ~/.cli-proxy-api/logs/error-v1-chat-completions-*.log | head -3
grep -h -A 20 "=== API REQUEST 1 ===" ~/.cli-proxy-api/logs/error-*.log | grep -m3 "Upstream URL\|auth_id\|label"
grep -h -A 8 "=== API RESPONSE ===" ~/.cli-proxy-api/logs/error-*.log | head -20
```

**端点名即配额周期**：Antigravity 走的是
`https://daily-cloudcode-pa.googleapis.com/v1internal:streamGenerateContent`
—— 看到 **`daily-`** 前缀就说明这是**每日配额**，不是分钟级限流。
（对应的 `cloudcode-pa.googleapis.com` 是同族端点。）

---

## 3. 查账号层级（决定配额有多大）

用 auth json 里的 access_token 直接问 Google：

```bash
AT=$(python3 -c "import json;print(json.load(open('$HOME/.cli-proxy-api/antigravity-<email>.json'))['access_token'])")
curl -s -X POST "https://daily-cloudcode-pa.googleapis.com/v1internal:loadCodeAssist" \
  -H "Authorization: Bearer $AT" -H "Content-Type: application/json" \
  -d '{"metadata":{"pluginType":"GEMINI"}}'
```

返回里的 `allowedTiers[].id` 就是层级：

- **`standard-tier`** = Gemini Code Assist 免费标准层 → **每日配额很小，重度使用必爆**；
- Pro / Ultra 层则是另一套配额（社区反馈官方口径「每 5 小时刷新」，但实际常表现为更长窗口）。

`ineligibleTiers` 里还会出现 `UNSUPPORTED_CLIENT` 的迁移提示，那个是**噪音，不影响判断**。

**换算公式（务必算准）**：
Google 每日配额按**太平洋时间午夜**重置。

| 季节 | PT 偏移 | 午夜 = UTC | = 北京时间 |
|---|---|---|---|
| 夏令时 PDT（3~11 月） | UTC-7 | **07:00 UTC** | **15:00** |
| 冬令时 PST | UTC-8 | **08:00 UTC** | **16:00** |

```bash
TZ=America/Los_Angeles date "+PT %F %T"; date -u "+UTC %F %T"; TZ=Asia/Shanghai date "+北京 %F %T"
```

**⚠️ 但不要把「太平洋午夜」当成承诺**：社区实测（Google AI 开发者论坛 + CLIProxyAPI issue #5209）
普遍是 **5～24 小时**才恢复，且**有时只恢复约 20%**，不是满血。
给用户答复时两头都要说：机制上的下一个重置点 + 实测可能的延迟与部分恢复。

---

## 4. 找出「是谁把额度用光的」

免费层最容易的元凶是**Agent 自己**——如果 Hermes 的主 provider 就指向这个网关，
那么 Agent 每轮对话/每次工具调用都是一次请求，一个长会话几百次工具调用就能吃光日配额。

自检：

```bash
grep -h "User-Agent" ~/.cli-proxy-api/logs/*.log | sort | uniq -c | sort -rn | head
# 若某个 error log 里能抓到 Hermes 的完整系统提示词 → Agent 自身正在走这个网关
grep -l "You are Hermes Agent" ~/.cli-proxy-api/logs/*.log | head
```

按小时统计成功调用量，看消耗强度：

```bash
python3 - <<'EOF'
from collections import Counter
rows=[l.split() for l in open('/tmp/llm_calls.txt')]
c=Counter(r[0]+' '+r[1][:2] for r in rows if len(r)==3 and r[2]=='200')
for k in sorted(c): print(k,'->',c[k])
EOF
```

**架构建议（可复用）**：Agent 主模型与「面向用户的 Bot」**不要共用同一个配额池**。
把 Agent 的日常主力切到另一家（按量付费 / 另一中转），把订阅网关的配额**专门留给用户可见的服务**，
两边就不会互相抢额度、也不会出现「Agent 一忙，Bot 就哑火」。

---

## 5. 静默恢复监控（零成本，推荐默认动作）

不要干等，也不要每隔几分钟手动 curl。挂一个 **`no_agent=True` 的 cron 看门狗**：

- 未恢复 → **stdout 为空 = 完全静默**，不打扰用户；
- 恢复 → 打印一条带「实际耗尽时长」的通知，cron 原样投递给用户；
- 用 state 文件记住「已通报」，避免每 10 分钟重复播报。

现成脚本：`scripts/quota-recovery-probe.py`

```bash
export LLM_GATEWAY_URL=http://127.0.0.1:8317/v1/chat/completions
export GATEWAY_API_KEY=<网关 api-keys 里的一把>
python3 scripts/quota-recovery-probe.py     # 未恢复则无输出
```

挂 cron（Hermes）：

```
cronjob(action='create', name='网关额度恢复探测', schedule='every 10m',
        script='quota-recovery-probe.py', no_agent=True, deliver='origin')
```

脚本放 `~/.hermes/scripts/` 下时用相对文件名即可。

---

## 6. 配额耗尽期间，面向上游用户的服务别断

网关拿不到额度时，**下游 Bot 不能跟着哑火**。正确姿势：

1. **多级兜底链**：把 LLM 端点写成有序列表逐个尝试
   （同一网关的**不同模型也算不同节点**，因为 429 常常是模型级配额），
   并优先使用**已实测连通**的节点——不要以为配置里写了就能用
   （实测过 `open.bigmodel.cn` 返回「余额不足或无可用资源包」、`sharellm.cn/v1` 直接 404）。
2. **失败必须用户可见**：拿到 `None` 时发一条**限时自毁提示**把原因带出去，
   **绝不允许静默 `return`** —— 那在用户看来就是「服务死机了」，是最伤体验的反模式。
3. 兜底链的可复用骨架见 `telegram-group-assistant` 技能的
   `references/llm-fallback-chain-and-failure-surfacing.md`。

---

## 验收清单

- [ ] `/tmp/llm_calls.txt` 已生成，明确判定为「配额墙」而非分钟限流
- [ ] 已从 `=== API REQUEST ===` 读出上游端点名（确认含 `daily-`）
- [ ] 已用 `loadCodeAssist` 确认账号 tier（`standard-tier` = 免费层）
- [ ] 已算出下一个重置时刻（UTC 与北京时间都算，注意夏令时）
- [ ] 已查清消耗来源（是否 Agent 自身在走该网关）
- [ ] 静默监控 cron 已挂上并首跑验证（未恢复时**零输出**）
- [ ] 下游服务已切换兜底链，且失败时用户能看到原因
