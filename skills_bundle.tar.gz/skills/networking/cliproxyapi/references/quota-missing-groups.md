# Antigravity 额度分组缺失排查

> ⚠️ **2026-10-24 更新（先读这条）**：下节「cloudcode-pa 返回两组」的样本**已失效**。
> 四个账号 × 三个 Summary 域名全部只返回 `Claude and GPT models` 一组；Gemini 额度仍在，
> 但只由 `v1internal:retrieveUserQuota` / `v1internal:fetchAvailableModels` 按模型暴露。
> 因此看到「缺少 Gemini」**先判是上游摘要接口变更还是客户端丢组**，别直接改面板选源逻辑。
> 取证与修法见 `references/quota-inspection.md` 的「2026-10-24 实测」一节，或跑 `scripts/antigravity-quota-probe.py`。

## 已验证的机制（2026-10-20 样本，不是永久接口保证）

### 本次复盘补充：不要把接口排序当成完整修复
面板前端可能在第一个非空响应处立即返回；把某个接口移到首位只是基于当次样本的缓解，不能保证以后该源一直完整。若用户反馈刷新后仍只有 Claude/GPT，立即撤回“浏览器缓存”的断言，核对当前实际截图/UI、served bundle 与 selection logic；不要让用户反复清缓存，也不要因文件与 HTTP body 一致就声称 UI 已恢复。

同一账号、同一 project 的 `retrieveUserQuotaSummary` 样本：
- daily-cloudcode 主/沙盒端点：HTTP 200，但仅 Claude/GPT。
- `https://cloudcode-pa.googleapis.com/v1internal:retrieveUserQuotaSummary`：HTTP 200，Gemini 与 Claude/GPT 均有 weekly、5h。

当时 CPA 前端遇到首个非空解析结果即返回，因此漏掉 Gemini 整组。机器人模块已有“缺分组继续查询”逻辑，但常驻进程启动早于模块更新，旧进程仍输出缺项结果。

## 复现与证据
1. 读取旧、新截图并列出 `(分组, window)` 差集，不混淆账号数。两项消失可能是一个分组的 weekly 与 5h 同时消失。
2. 通过已授权本地管理链路，对相同账号、项目、body逐个查询候选quota URL。只输出HTTP、分组名、bucket窗口与必要剩余信息；不打印token、项目标识或完整认证响应。
3. 复用既有额度查询模块前先检查当前实现；不假定API、路径和进程状态未变。查询额度无需调用生成模型。
4. 检查是否在首个200/非空响应提前返回，及解析/渲染是否过滤组。区分源JSON、标准化结果、页面state与用户截图。
5. 核对真实systemd unit、进程启动时间、源文件更新时间及导入方式；服务重载后仍须验真实输出。

## CPA面板热修要点
- CPA实测从磁盘 `static/management.html` 提供页面；以实际GET正文核验，而非假设磁盘改动已对用户生效。
- 单纯把一个完整源排第一是临时缓解，不是完整性保证。更稳健逻辑应继续查询，发现含Gemini的结果才选它；若全无Gemini，保留分组最多的有效响应并明确缺项。
- **候选结果必须使用每次函数调用的局部变量**。禁止用 `globalThis` 或模块级字段暂存账号/刷新结果：连续多账号查询可能跨账号污染，刷新间复用陈旧额度。
- 保持候选返回字段与当前 `authIndex` 关联；若包含subscription/server offset，应在最终选定该账号结果时正确补齐。
- 静态bundle混淆时，先备份、唯一定位、小改动；不得猜测插桩点或做宽泛替换。

## 最低行为测试
1. 首个源缺Gemini，后续源含Gemini：必须选择后续完整源。
2. 所有源都无Gemini：返回groups/buckets最多的有效源，且报告仍不完整。
3. 连续查询不同账号：第二账号不能继承第一账号结果。
4. 多次刷新：不得复用前一次的候选结果。
5. 空groups、空buckets、200无效body、非2xx、异常：均按预期继续或给清晰错误。

## 验收、回滚与对用户沟通
- 验收链：各源原始响应 → 选择逻辑行为测试 → 磁盘与HTTP提供bundle一致 → 页面实际状态/用户截图。
- 不能自动验证浏览器时，明确说“服务端已改，用户端尚未确认”；不得把HTTP 200、页面源码更新或服务active单独报成问题修复。
- 若用户反馈仍缺项，应承认未解决并继续检查当前浏览器实际请求与返回，不再次归咎缓存或要求反复强刷。
- 修改前备份，保留清晰回滚。静态补丁可能被CPA升级覆盖；不得顺带动模型路由、授权、凭据或服务配置。

## 本次操作的未完成事项（不可当作解决方案）
本次曾在生产 `management.html` 用脚本替换逻辑，并用 `globalThis.__cpaPartialQuota` 暂存响应；用户随后截图仍只见Claude/GPT的两项额度。上游cloudcode主域当时返回了Gemini，HTTP页面也与磁盘一致，但没有证明浏览器最终选择/渲染正确。该全局暂存有跨账号污染风险。后续维护者应先读取当前线上文件，移除全局状态、改用局部候选并加行为测试，再分别验证服务端与用户界面；不要重复声称已修复。

## 2026-10-20 续查补充（同一问题第二轮）

### 已排除的变量
- **User-Agent 无关**：对同一 authIndex/project 分别用 `antigravity/cli/{1.0.13,1.0.15,1.0.20,1.0.25} (aidev_client; os_type=linux; arch=x86_64)` 请求 `cloudcode-pa`，四次全部返回 `Gemini Models(2) + Claude and GPT models(2)`。所以「面板 UA 版本不同导致上游不给 Gemini」不成立，问题在客户端选源，不在请求形态。
- **project 无关**：凭证里的 `project_id`（本次为 `aicode-consumers`）与 `loadCodeAssist` 解析出的 project 一致，两者分别查询结果相同。
- **账号无关**：四个账号逐个查 `cloudcode-pa` 均返回两组。

### 公网链路核验（只读，证明没有第二个实例）
面板域名经 Cloudflare Named Tunnel 暴露时：
1. `GET /accounts/{account_id}/cfd_tunnel/{tunnel_id}/configurations` → 读 `config.ingress`，确认唯一 hostname 指向 `http://127.0.0.1:8317`（本次即如此），排除「VPS 上另跑一份 CPA」。
2. `GET /accounts/{account_id}/cfd_tunnel/{tunnel_id}` → `status=healthy` 且 `connections` 非空。
3. `GET /accounts/{account_id}/access/apps/{app_id}` + `/policies` → 确认 Access 策略（本次为 owner-only、session 24h）。**owner-only 且无 service token 时，机器侧无法穿过 Access 取页面**；tunnel 级 token 调 zone 级 API 会 403，既查不到也清不了缓存规则。此时不要继续在服务端空转，改用下面的构建标记法把验收交给用户。

### 构建标记法（替代“反复强刷”）
1. 热修后在 `management.html` 的 `<title>` 追加唯一标记（如 `CLI Proxy API Management Center · qfix-20261020`）。
2. 用 `urllib`/`curl` GET `http://127.0.0.1:8317/management.html` 校验 body 里同时存在标记与补丁逻辑。
3. 让用户打开带参数的地址（`?v=<date>`）并**先看标签页标题**：有标记 = 已加载新版；无标记 = 仍吃缓存，换无痕窗口/关标签重开。
4. 标题有标记但仍缺 Gemini → 不是缓存，转向渲染层与请求体排查，不再要求用户清缓存。

### 可执行回归测试
`scripts/test-quota-group-selection.py` 会从线上 HTML 提取选源片段，用 node + 桩响应验证 5 个场景：首个源缺 Gemini、全部源缺 Gemini、仅 Gemini 源可用、空账号不得继承上一账号结果、非 2xx/非法 body 混入。改完 bundle 先跑它，再谈交付；脚本 `SKIP`（退出码 2）说明面板版本变了、锚点需重新定位。


