# CPA 健康告警取证：`cpa_inference` 长期 ACTIVE 的根因定位

适用：运维 Bot 反复推「CPA 推理异常」类告警，但实际业务请求全 200；
或 `ai-model-health.state.json` 里某项 `active: true` 却迟迟不恢复。

## 先分清是"真故障"还是"监控自我污染"

`/home/ubuntu/hermes-jobs/ai-model-healthcheck.py` 有两类完全不同的告警：

| 信号 | 来源 | 含义 |
|------|------|------|
| `model_probe` | `probe_model()` 主动发一次带随机令牌的真实推理 | 链路真的不通/超时 |
| `cpa_inference` | `cpa_events()` **纯统计 journal 里的 4xx/5xx** | 可能是别人（含自己）的探针打出来的 |

告警文案「CPA 推理连接失败或超时」只来自 `model_probe`；
「CPA 过去30分钟内累计推理 HTTP 失败 N 次」来自 `cpa_inference`。
两者别混为一谈——前者是探针超时，后者是日志计数。

## 状态机语义（`advance()`，第 68 行）

- `unhealthy` → `bad += 1`, `good = 0`
- `healthy`   → `good += 1`, `bad = 0`
- 首次告警：`unhealthy and not active and bad >= fail_after`
- 恢复：`not unhealthy and active and good >= recover_after`
- `cpa_inference` 的 `fail_after=1`（出现即报）

**关键推理：`good` 长期为 0 不等于恢复逻辑坏了，而是"每一轮 unhealthy 都为真"**，
即统计窗口内确实一直有失败记录。此时不要动状态机，去数事件。

## 事件统计口径（`cpa_events()`，第 95 行）

```
journalctl -u cliproxyapi.service --since <30分钟前> --no-pager -o cat
```
- 只统计同时含 `POST` 与 `/v1/chat/completions` 的行
- 正则：`\b(?:400|401|403|404|408|409|422|429|5\d\d)\s*\|`
- **注意：401/403 被算进"推理失败"**，而它们本质是鉴权问题
  （另有 `cpa_unauthorized_events()` 专门管 401/403，职责有重叠）

## 典型根因：定时探针用失效 key，每 30 分钟灌一条 401

2026-10-20 实测链条：

1. journal 里 401 出现在 09:31 / 10:01 / 10:31 / 11:01 … 13:31，**间隔精确 30 分钟**
2. 响应时间 **1ms** —— 连鉴权都没过，是无 key 或错 key 的特征
3. 与 Hermes cron job `Gemini主模型额度恢复监控`（`every 30m`，
   `script=gemini_quota_watch.py`，`no_agent=true`）的 `last_run_at` **秒级吻合**
4. 该脚本 `API_KEY` 硬编码了一个**不在 CPA `api-keys` 列表里**的旧 key → 每次 401
5. `cpa_inference` 窗口 30 分钟 + 探针周期 30 分钟 = **窗口内几乎总有 401**，
   `good` 永远归零 → 告警永久 ACTIVE，人怎么看都"修不好"

这类问题最阴的地方：业务流量完全正常，只有监控在自噬。

## 定位手法（按顺序，通常第 4 步就能一击命中）

1. 复现计数：`cpa_events(now-1800)`，确认窗口内失败条数
2. 列出当天 401/403 的**时间点**，看是否等间隔
3. 等间隔 ⇒ 必是定时任务。查 `crontab -l`、`~/.hermes/cron/jobs.json` 的 `schedule`
4. **用该 job 的 `last_run_at` 与日志时间戳做秒级比对** —— 比逐个猜脚本快得多
5. 读该脚本的鉴权来源，确认 key 是否有效

## CPA `api-keys` 是按客户端命名的专用 key

`~/cliproxyapi/config.yaml`：

```yaml
api-keys:
- groups-<hash>
- hermes-<hash>
- telebox-<hash>
- ad-<hash>
- userbot-<hash>
- ops-<hash>
```

- 任一项都是有效 Bearer token，但**语义上应按客户端取用**（运维脚本取 `ops-` 前缀）
- **严禁硬编码**：key 轮换后硬编码值静默失效，唯一表现就是 401，极难发现
- 正确读法（不依赖 yaml 模块，任何 python 都能跑）：扫 `api-keys:` 块，
  优先 `ops-` 前缀，回退列表首项 —— 见 `~/.hermes/scripts/gemini_quota_watch.py`
  的 `load_api_key()`

## 修完必须清理的副作用

`gemini_quota_watch.py` 用 `.gemini_quota_state` 记录上次状态，
只在「上次 quota → 本次 ok」时才输出恢复通知。
长期 401 期间写的是 `down`，修好后第一次成功会被判定为"从不可用变可用"，
**误发一条「✅ Gemini 主模型额度已恢复」**。改完脚本后要把该文件置为 `ok`。

## 已实施的修复（2026-10-20）

- `ai-model-healthcheck.py:328` probe 超时 `17s → 30s`
- `ops-healthcheck.sh:63` 外层 `timeout 40s → 60s`（否则内层放宽会被外层 kill 成漏检）
- `gemini_quota_watch.py` 删除硬编码 key，改为从 CPA 配置读 `ops-` key
- 验证：`check()` 返回 `ok`，journal 对应请求为 `200`
