# 远程 OAuth 登录实操记录（2026-08-15，AWS 无头服务器验证）

## 现场流程
```bash
# 1. 下载最新版（查 releases API 拿资产名，v7.2.132 为例）
curl -sL -o cliproxy.tar.gz https://github.com/router-for-me/CLIProxyAPI/releases/download/v7.2.132/CLIProxyAPI_7.2.132_linux_amd64.tar.gz
tar xzf cliproxy.tar.gz   # 得到单文件 cli-proxy-api (~63MB)

# 2. 生成 API key 并写最小 config.yaml（见 templates/minimal-config.yaml）
openssl rand -hex 16

# 3. 后台启动登录流程（terminal background=true）
./cli-proxy-api -config config.yaml -antigravity-login -no-browser
```

## 登录进程的典型输出（Antigravity/Gemini）
```
================================================================================
  # If using an SSH key (assumes SSH port 22):
  ssh -i <path_to_your_key> -L 51121:127.0.0.1:51121 root@<SERVER_IP> -p 22
  NOTE: If your server's SSH port is not 22, please modify the '-p 22' part.
================================================================================
Visit the following URL to continue authentication:
https://accounts.google.com/o/oauth2/v2/auth?access_type=offline&client_id=...&redirect_uri=http%3A%2F%2Flocalhost%3A51121%2Foauth-callback&...&state=...
Waiting for antigravity authentication callback...
```

要点：
- 回调端口默认 51121（Antigravity），由 `-oauth-callback-port` 可覆盖
- 进程会阻塞等待回调；期间不要重启进程，否则 state/code 失效需重新授权
- 工具自己打印了 SSH 隧道提示 = 官方远程登录姿势

## 两种远程回调解法
1. **SSH 隧道**（官方）：用户本地 `ssh -L 51121:127.0.0.1:51121 <user>@<IP>` 后打开 URL，回调经隧道回传。
2. **URL 桥接**（免隧道）：用户浏览器跳转 localhost:51121 失败后，复制地址栏完整 URL（GET 参数含 code+state）回传；Agent 在服务器执行
   `curl "http://localhost:51121/oauth-callback?code=...&state=..."` 即可喂给监听进程完成登录。

## 账号安全
- 授权 URL / code 是一次性的，务必提醒用户私发（DM），不要发群里
- 用「有订阅的那个 Google 账号」登录，订阅级别决定可用模型档位（免费档无 gemini pro）
- 登录成功后凭证落在 auth-dir（~/.cli-proxy-api），服务重启后仍在，无需重新登录

## 2026-09-10 二次实操复验（v7.2.132，curl 桥接走通）
- 登录进程输出里 `Waiting for antigravity authentication callback...` 与 `Paste the antigravity callback URL (or press Enter to keep waiting):` **同时出现**（HTTP 监听与 stdin 粘贴两个入口并存），所以**优先用 URL 桥接 curl**，无需往后台进程 stdin 粘贴。
- 用户回传的整条回调 URL（含 `state=` `iss=` `code=` `scope=` `authuser=` `prompt=consent`）用**单引号整条**喂给 curl 即可，实测：
```bash
curl -s -m 30 -w "HTTP:%{http_code}\n" \
 'http://localhost:51121/oauth-callback?state=<state>&iss=https://accounts.google.com&code=4/0A...&scope=...&authuser=0&prompt=consent'
# 返回 HTTP:200，响应体：<h1>Login successful</h1><p>You can close this window.</p>
```
  注意 URL 里的 `&` 必须被引号保护，且不要自作主张删参数（原样回传最稳）。
- 登录进程随后打印 `Antigravity authentication successful` / `Using GCP project: <项目>` / `Authenticated as <email>` / `Authentication saved to ...` 后**自行退出**（无需 kill）。
- 常驻服务不用重启：日志出现 `events.go:125 auth file changed (CREATE): antigravity-<email>.json, processing incrementally` 即已热加载；随后 `/v1/models` 立即可用。
- **账号核对**：回调 URL 里的 `authuser=0` 说明浏览器用的是默认登录账号，用户以为的账号未必是实际授权的账号；**一律以落盘文件名里的 email 为准**（`ls -la ~/.cli-proxy-api/`），需要换号就重新生成授权链接并让用户用无痕窗口只登目标账号。
- 若紧接着连打几次 403，再测会变成 503 `auth_unavailable`（凭证被临时隔离），`systemctl restart cliproxyapi` 后单次实测即可看到真实错误。
