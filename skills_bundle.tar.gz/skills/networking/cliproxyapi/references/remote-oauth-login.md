# 远程 OAuth 登录实操记录（2026-08-15，AWS 无头服务器验证）

## 现场流程
```bash
# 1. 下载最新版（查 releases API 拿资产名，v7.2.132 为例）
curl -sL -o cliproxy.tar.gz https://github.com/router-for-me/CLIProxyAPI/releases/download/v7.2.132/CLIProxyAPI_7.2.132_linux_amd64.tar.gz
tar xzf cliproxy.tar.gz   # 得到单文件 cli-proxy-api (~63MB)

# 2. 生成 API key 并写最小 config.yaml（见 templates/minimal-config.yaml）
openssl rand -hex 16

# 3. 后台启动登录流程（terminal background=true）
./cli-proxy-api -config config.yaml -antigravity-login -no-browser
```

## 登录进程的典型输出（Antigravity/Gemini）
```
================================================================================
  # If using an SSH key (assumes SSH port 22):
  ssh -i <path_to_your_key> -L 51121:127.0.0.1:51121 root@<SERVER_IP> -p 22
  NOTE: If your server's SSH port is not 22, please modify the '-p 22' part.
================================================================================
Visit the following URL to continue authentication:
https://accounts.google.com/o/oauth2/v2/auth?access_type=offline&client_id=...&redirect_uri=http%3A%2F%2Flocalhost%3A51121%2Foauth-callback&...&state=...
Waiting for antigravity authentication callback...
```

要点：
- 回调端口默认 51121（Antigravity），由 `-oauth-callback-port` 可覆盖
- 进程会阻塞等待回调；期间不要重启进程，否则 state/code 失效需重新授权
- 工具自己打印了 SSH 隧道提示 = 官方远程登录姿势

## 两种远程回调解法
1. **SSH 隧道**（官方）：用户本地 `ssh -L 51121:127.0.0.1:51121 <user>@<IP>` 后打开 URL，回调经隧道回传。
2. **URL 桥接**（免隧道）：用户浏览器跳转 localhost:51121 失败后，复制地址栏完整 URL（GET 参数含 code+state）回传；Agent 在服务器执行
   `curl "http://localhost:51121/oauth-callback?code=...&state=..."` 即可喂给监听进程完成登录。

## 账号安全
- 授权 URL / code 是一次性的，务必提醒用户私发（DM），不要发群里
- 用「有订阅的那个 Google 账号」登录，订阅级别决定可用模型档位（免费档无 gemini pro）
- 登录成功后凭证落在 auth-dir（~/.cli-proxy-api），服务重启后仍在，无需重新登录
