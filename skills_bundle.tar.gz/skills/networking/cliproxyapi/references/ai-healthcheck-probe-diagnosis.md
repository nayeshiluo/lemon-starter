# AI Healthcheck Probe Diagnosis (ai-model-healthcheck.py)

## Overview
`/home/ubuntu/hermes-jobs/ai-model-healthcheck.py` runs every ~10 minutes via Hermes cron.
It probes the full CPA → upstream Gemini inference path with a random verification token challenge.

## Probe Logic (probe_model)
1. Reads Hermes config to confirm primary provider is `custom:反重力` and extracts the model name
2. Reads CPA `config.yaml` to extract `api-keys[0]`
3. Sends `POST http://127.0.0.1:8317/v1/chat/completions` with:
   - A random `CHECK-<hex>` challenge token in the prompt
   - `max_tokens=80, temperature=0, stream=False`
   - **Timeout: 17 seconds**
4. Expects HTTP 200 AND `content.strip() == challenge` (exact match)
5. Result branches:
   - PASS: HTTP 200 + exact token match
   - FAIL (HTTP error): `urllib.error.HTTPError` → "CPA 推理接口 HTTP <code>"
   - FAIL (timeout/connection): `urllib.error.URLError, TimeoutError, OSError` → "CPA 推理连接失败或超时"
   - FAIL (parse error): `ValueError, KeyError, TypeError` → "CPA 推理返回内容无法解析"

## Alert Escalation Logic (advance)
- Uses `fail_after=2` → needs 2 consecutive FAILs to trigger ALERT
- Uses `recover_after=1` → single PASS clears the alert
- State transitions: OK → ACTIVE (1st fail) → ALERT (2nd fail, sends 🚨 to TG)
- Recovery: ALERT/ACTIVE → RECOVERED (sends ✅ to TG) → OK

## Key Files
- **State**: `/home/ubuntu/hermes-jobs/status/ai-model-health.state.json`
  - `last_probe`: "PASS" | "FAIL" | "SKIP"
  - `probe_latency_ms`: last probe round-trip time
  - `signals.model_probe.{bad,good,active}`: counter and active-alert flag
- **Log**: `/home/ubuntu/hermes-jobs/status/ai-model-health.log`
  - Each line: `AI_MONITOR <ISO_timestamp> status {<all_signals_json>} probe <PASS|FAIL> remote <active|inactive>`
- **Watchdog** (separate): `/home/ubuntu/hermes-jobs/status/ai-monitor-watchdog.log`
  - `AI_WATCHDOG` entries only check CPA process/port health, NOT model inference

## Thinking Model Timeout Pattern (2026-10-20 实测)
- `gemini-3.8-flash-high` produces ~91 reasoning_tokens per probe request
- Normal latency: ~2.5-3.0 seconds
- Under Gemini free-tier load spikes: >17 seconds → timeout → FAIL
- Pattern: intermittent bursts of 2-5 consecutive FAILs, each lasting 10-40 min, then self-recovery
- Observed failure rate: ~24.6% (17 FAIL / 69 total probes in one day)

## Quick Diagnosis Commands
```bash
# Current state
cat /home/ubuntu/hermes-jobs/status/ai-model-health.state.json | python3 -m json.tool

# Recent probe results
grep 'probe FAIL\|probe PASS' /home/ubuntu/hermes-jobs/status/ai-model-health.log | tail -30

# Today's fail rate
grep '2026-10-20' /home/ubuntu/hermes-jobs/status/ai-model-health.log | grep 'probe ' | sed 's/.*probe //' | sed 's/ .*//' | sort | uniq -c

# Manual probe with extended timeout (45s)
python3 -c "
import yaml, json, urllib.request, secrets, time
with open('/home/ubuntu/cliproxyapi/config.yaml') as f:
    cpa = yaml.safe_load(f)
key = cpa['api-keys'][0]
challenge = 'CHECK-' + secrets.token_hex(4)
payload = json.dumps({'model': 'gemini-3.8-flash-high', 'messages': [{'role': 'user', 'content': 'Return only this exact ASCII verification token: ' + challenge}], 'max_tokens': 80, 'temperature': 0, 'stream': False}).encode()
req = urllib.request.Request('http://127.0.0.1:8317/v1/chat/completions', data=payload, headers={'Authorization': 'Bearer ' + key, 'Content-Type': 'application/json'})
start = time.time()
try:
    with urllib.request.urlopen(req, timeout=45) as resp:
        result = json.loads(resp.read(400000))
    content = result.get('choices', [{}])[0].get('message', {}).get('content', '')
    print(f'HTTP {resp.status} | {time.time()-start:.2f}s | match={content.strip()==challenge} | usage={result.get(\"usage\")}')
except Exception as e:
    print(f'Error after {time.time()-start:.2f}s: {e}')
"

# CPA upstream connection check
ss -tnp | grep $(pgrep cli-proxy-api) | grep 443
```

## Distinction: Probe FAIL vs Real CPA Outage
| Signal | Probe Timeout (虚警) | Real CPA Outage |
|--------|----------------------|-----------------|
| `cpa_service` | OK | ALERT |
| `cpa_inference` | OK | ALERT |
| `model_probe` | ALERT | ALERT |
| CPA port 8317 | listening | not listening |
| TCP to Google:443 | established | none |
| Manual test (45s timeout) | PASS | FAIL |
| Hermes actual usage | works (with fallback) | broken |
