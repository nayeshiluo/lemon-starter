# 从归档重建 CLIProxyAPI 网关（2026-09-10 实操，AWS 无头机 ubuntu）

场景：网关此前被整体移除归档（`backups/antigravity-removed-20260909-final/`），
用户要求「把反重力重新接上去，用小号试试」。以下是逐条真实命令与观测结果。

## 1. 侦察（只读，先摸清家底）
```bash
ls -la /home/ubuntu/backups/ | grep -i antigravity
ls -laR /home/ubuntu/backups/antigravity-removed-20260909-final/
systemctl list-units --all | grep -i -E "cliproxy|antigrav"   # 空 = 服务已不存在
ss -tlnp | grep 8317                                          # 空 = 端口无人监听
ls -la /home/ubuntu/.cli-proxy-api/                           # 不存在 = 凭证目录已清
grep -n -iE "provider|base_url|antigravity|8317|gemini" ~/.hermes/config.yaml
```
归档内容结构（可复用取材清单）：
```
cliproxyapi/
  cli-proxy-api          63,464,968B  单文件二进制（v7.2.132, Commit 78f0c407）
  config.yaml            120B  host 127.0.0.1 / port 8317 / auth-dir ~/.cli-proxy-api / api-keys[1]
  APIKEY.txt             明文记录了那把 api key
  cliproxyapi.service    旧 systemd unit
  static/management.html 2.8MB 远程管理面板（本机接入无用）
```
Hermes 侧无残留 provider 条目（`custom_providers` 里没有指向 8317 的项），所以重建是纯新建。

## 2. 复原二进制与服务
```bash
B=/home/ubuntu/backups/antigravity-removed-20260909-final/cliproxyapi
mkdir -p /home/ubuntu/cliproxyapi
cp -a $B/cli-proxy-api $B/config.yaml $B/static /home/ubuntu/cliproxyapi/
chmod +x /home/ubuntu/cliproxyapi/cli-proxy-api
```
**踩到的坑**：归档二进制权限是 `-rw-------`，直接执行会 `Permission denied`；
`chmod +x` 后才打印出 `CLIProxyAPI Version: 7.2.132 ...`。任何"从备份恢复二进制"的场景都要先确认执行位。

**unit 差异**：归档 `cliproxyapi.service` 的 `After/Wants` 只有 `network-online.target systemd-resolved.service`，
缺 `nss-lookup.target` → 等价于把 DNS 抢跑坑一起恢复。重写成：

```ini
[Unit]
Description=CLIProxyAPI - CLI subscription to API gateway
After=network-online.target nss-lookup.target systemd-resolved.service
Wants=network-online.target nss-lookup.target systemd-resolved.service

[Service]
Type=simple
User=ubuntu
WorkingDirectory=/home/ubuntu/cliproxyapi
ExecStart=/home/ubuntu/cliproxyapi/cli-proxy-api -config /home/ubuntu/cliproxyapi/config.yaml
Restart=always
RestartSec=5
LimitNOFILE=65536

[Install]
WantedBy=multi-user.target
```
```bash
sudo cp /tmp/cliproxyapi.service /etc/systemd/system/cliproxyapi.service
sudo systemctl daemon-reload && sudo systemctl enable --now cliproxyapi
```

## 3. 验证（实测的好日志长什么样）
```bash
systemctl is-active cliproxyapi                 # active
ss -tlnp | grep 8317                            # LISTEN 127.0.0.1:8317 users:(("cli-proxy-api",pid=703121))
sudo journalctl -u cliproxyapi -n 25 --no-pager
```
关键成功行（本次全部命中，内存占用仅 ~15.5MB，1.9G 小机毫无压力）：
```
API server started successfully on: 127.0.0.1:8317
[service_lifecycle.go:360] created missing auth directory: /home/ubuntu/.cli-proxy-api
[model_updater.go:137] startup model refresh completed from https://raw.githubusercontent.com/router-for-me/models/refs/heads/main/models.json, changes detected for providers: [claude gemini vertex aistudio codex antigravity]
[codex_client_models_updater.go:63] startup Codex client model refresh completed ... catalog updated
service clients and configuration updated: 0 clients (0 auth entries + ...)
```
历史日志里可见上次落地的账号：`auth file changed (WRITE): antigravity-<YOUR_EMAIL>@gmail.com.json`。

## 4. 登录小号（恢复服务后立刻做）
```bash
cd /home/ubuntu/cliproxyapi
./cli-proxy-api -config config.yaml -antigravity-login -no-browser   # terminal background=true
```
进程 stdout 依次打印：SSH 隧道提示 → 授权 URL → `Waiting for antigravity authentication callback...`
（回调端口默认 51121；`state=<32hex>` 一次性）。

给用户的动作：
1. **无痕窗口**登录小号（否则会自动用浏览器里已登录的大号，白试）；
2. 打开授权 URL，同意后跳到 `localhost:51121/oauth-callback?code=...&state=...`，页面打不开是正常的；
3. 把地址栏完整 URL 复制回来（DM，别发群），Agent 在服务器 `curl "http://localhost:51121/oauth-callback?code=...&state=..."`，
   或用 `process(action='submit')` 把 URL 喂进等待中的登录进程 stdin。

凭证写盘为 `~/.cli-proxy-api/antigravity-<email>.json`，常驻服务文件监控热加载，**无需 restart**。

## 5. 给用户的必要提示（本次开场就说了）
Antigravity 服务条款禁止第三方工具接入，大号此前突封大概率即因此；用小号试 = 风险转移到小号，要提前讲清而非事后解释。
