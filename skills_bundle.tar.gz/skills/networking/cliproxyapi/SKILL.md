---
name: cliproxyapi
description: CLIProxyAPI 部署运维：订阅号转 OpenAI 兼容 API 网关，含无头服务器远程 OAuth 登录。
version: 1.0.0
author: hermes-curator
license: MIT
metadata:
  hermes:
    tags: [proxy, oauth, gemini, grok, subscription, api-gateway]
    related_skills: [hermes-custom-providers, claude-code, codex]
---

## When to Use
- 用户提到 "cli proxy api"、"订阅转 API"、"把 Gemini/Grok 订阅接到编程工具"、"xx 订阅死了换渠道"
- 需要在服务器上把订阅号（OAuth 登录态）变成 OpenAI 兼容 API 给编程工具用

# CLIProxyAPI（订阅转 API 网关）

## 用途
白嫖路线核心工具：把已有的 **Gemini / Grok / ChatGPT / Claude / Kimi 订阅号**（OAuth 登录态）包装成 OpenAI / Claude / Gemini 兼容 API，任何客户端（Claude Code、Codex、OpenCode、Hermes custom provider）都能接入，订阅费当 API 用。
- 官方仓库：https://github.com/router-for-me/CLIProxyAPI（MIT）
- 中文文档：https://help.router-for.me/cn/ （VitePress SPA，正文提取优先 curl GitHub raw 的 README_CN.md）

## 部署（低配服务器无 Docker：直接二进制，推荐）
内存 1.9G 的小机器跑单文件二进制毫无压力，不必装 Docker。
1. 查最新版本与资产：`curl -sL https://api.github.com/repos/router-for-me/CLIProxyAPI/releases/latest`（assets 里有 linux_amd64 / linux_aarch64 / darwin / windows 的 tar.gz/zip）
2. 下载解压对应平台包（linux_amd64 约 63MB，单文件 `cli-proxy-api`）
3. 写最小 `config.yaml`（见 `templates/minimal-config.yaml`）
4. 启动：`./cli-proxy-api -config config.yaml`（后台跑用 terminal background=true）

有 Docker 时：
```bash
docker run -d --name cliproxyapi -p 8317:8317 -p 8085:8085 \
  -v ./config.yaml:/CLIProxyAPI/config.yaml -v ./auths:/root/.cli-proxy-api \
  eceasy/cli-proxy-api:latest
```

## 关键配置
- `port: 8317` — OpenAI 兼容 API 端口
- `auth-dir: "~/.cli-proxy-api"` — OAuth 凭证存放目录
- `api-keys: [...]` — 客户端访问 key，**必设**（公网裸奔保护）
- `remote-management.secret-key` + `allow-remote: true` — 开启 WebUI 管理面板（默认仅 localhost）

## 远程 OAuth 登录（无头服务器关键步骤）
```bash
./cli-proxy-api -config config.yaml -antigravity-login -no-browser
```
`-no-browser` 防止服务器尝试开浏览器。其他 provider 对应 flag：`-claude-login` / `-codex-login` / `-xai-login` / `-kimi-login`。

**核心坑**：OAuth 回调监听在**服务器**的 localhost:51121，但授权发生在**用户本地**浏览器，redirect 到用户本地的 localhost 必然失败。两条解法：
1. **SSH 隧道**（工具自己打印的官方远程方法）：用户本地先 `ssh -L 51121:127.0.0.1:51121 <user>@<服务器IP> -p 22`，再打开授权 URL，回调经隧道回传成功
2. **URL 桥接**（Agent 友好、免隧道）：浏览器跳转失败后，用户把地址栏完整 URL（含 `?code=...&state=...`）复制回传，Agent 在服务器上 `curl "http://localhost:51121/oauth-callback?code=...&state=..."`，监听进程捕获 code 即完成登录

⚠️ 授权链接含一次性 code：提醒用户**私发**，不要发群。

## 验证与工具调用（Function Calling）
- 模型列表：`curl http://localhost:8317/v1/models -H "Authorization: Bearer <APIKEY>"`
- 客户端接入：base_url 指向 `http://<服务器IP>:8317/v1`
- **Agent 编程适配**：Antigravity 账号衍生的 `claude-sonnet-4-6` 与 `claude-opus-4-6-thinking` 原生支持 OpenAI 格式的 `tool_calls`（Function Calling），写代码、调工具的稳定性远优于 `gemini-*-flash`。

## 多账号池与热重载
- 往 `auth-dir`（默认 `~/.cli-proxy-api`）添加多个 OAuth 凭证（例如多个 `antigravity-<email>.json`）即可组成多账号池，自动轮询 / 负载均衡，突破单一账号配额。
- **无需重启服务**：服务内置文件监控（`events.go`），检测到 `auth-dir` 新增凭证（CREATE 事件）会自动增量热重载生效。
- 新增账号操作：直接后台启动临时登录命令 `./cli-proxy-api -config config.yaml -antigravity-login -no-browser`，完成回调 curl 后生成新 json，常驻服务立即感知并加载。

## Pitfalls
- **勿用 ChatGPT Plus / 网页订阅充当高频 Agent 主脑**：网页端转 API（如 ChatGPT Plus $20/月）具有严苛的 3 小时提问频控（40-80 次），而 Hermes/Claude Code 等 Agent 执行单次编码任务即可能触发数十次工具交互，几分钟即可打满配额；且逆向/网页 Session 封号风险极高。高强度 Agent 编码任务优先选按量付费 API 或通过 Antigravity 映射的 Claude 模型。
- AWS 安全组需放行 8317 入站端口
- 管理面板默认禁远程；远程管理必须配 secret-key
- 授权 URL 里的 redirect_uri 是固定 localhost 端口（51121 等），由 `-oauth-callback-port` 可覆盖
- 文档站正文用 curl GitHub raw 拉，别用网页提取器（SPA 无正文）
