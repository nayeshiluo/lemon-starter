---
name: cliproxyapi
description: CLIProxyAPI 部署运维：订阅号转 OpenAI 兼容 API 网关，含无头服务器远程 OAuth 登录。
version: 1.0.0
author: hermes-curator
license: MIT
metadata:
  hermes:
    tags: [proxy, oauth, gemini, grok, subscription, api-gateway]
    related_skills: [hermes-custom-providers, claude-code, codex]
---

## When to Use
- 用户提到 "cli proxy api"、"订阅转 API"、"把 Gemini/Grok 订阅接到编程工具"、"xx 订阅死了换渠道"
- 需要在服务器上把订阅号（OAuth 登录态）变成 OpenAI 兼容 API 给编程工具用
- 网关返回 403 `VALIDATION_REQUIRED` / 503 `auth_unavailable` / **429 `RESOURCE_EXHAUSTED`**，
  或用户问「额度多久恢复」「是不是被封号了」——先按 `references/quota-exhaustion-diagnosis.md`
  分清「分钟限流 / 配额耗尽 / 账号级封禁」再动手，别急着重装或重授权

# CLIProxyAPI（订阅转 API 网关）

## 用途
白嫖路线核心工具：把已有的 **Gemini / Grok / ChatGPT / Claude / Kimi 订阅号**（OAuth 登录态）包装成 OpenAI / Claude / Gemini 兼容 API，任何客户端（Claude Code、Codex、OpenCode、Hermes custom provider）都能接入，订阅费当 API 用。
- 官方仓库：https://github.com/router-for-me/CLIProxyAPI（MIT）
- 中文文档：https://help.router-for.me/cn/ （VitePress SPA，正文提取优先 curl GitHub raw 的 README_CN.md）

## 部署（低配服务器无 Docker：直接二进制，推荐）
内存 1.9G 的小机器跑单文件二进制毫无压力，不必装 Docker。
1. 查最新版本与资产：`curl -sL https://api.github.com/repos/router-for-me/CLIProxyAPI/releases/latest`（assets 里有 linux_amd64 / linux_aarch64 / darwin / windows 的 tar.gz/zip）
2. 下载解压对应平台包（linux_amd64 约 63MB，单文件 `cli-proxy-api`）
3. 写最小 `config.yaml`（见 `templates/minimal-config.yaml`）
4. 启动：`./cli-proxy-api -config config.yaml`（后台跑用 terminal background=true）

有 Docker 时：
```bash
docker run -d --name cliproxyapi -p 8317:8317 -p 8085:8085 \
  -v ./config.yaml:/CLIProxyAPI/config.yaml -v ./auths:/root/.cli-proxy-api \
  eceasy/cli-proxy-api:latest
```

## 关键配置
- `port: 8317` — OpenAI 兼容 API 端口
- `auth-dir: "~/.cli-proxy-api"` — OAuth 凭证存放目录
- `api-keys: [...]` — 客户端访问 key，**必设**（公网裸奔保护）
- `remote-management.secret-key` + `allow-remote: true` — 开启 WebUI 管理面板（默认仅 localhost）

## 远程 OAuth 登录（无头服务器关键步骤）
```bash
./cli-proxy-api -config config.yaml -antigravity-login -no-browser
```
`-no-browser` 防止服务器尝试开浏览器。其他 provider 对应 flag：`-claude-login` / `-codex-login` / `-xai-login` / `-kimi-login`。

**核心坑**：OAuth 回调监听在**服务器**的 localhost:51121，但授权发生在**用户本地**浏览器，redirect 到用户本地的 localhost 必然失败。三条解法：
1. **SSH 隧道**（工具自己打印的官方远程方法）：用户本地先 `ssh -L 51121:127.0.0.1:51121 <user>@<服务器IP> -p 22`，再打开授权 URL，回调经隧道回传成功
2. **URL 桥接**（Agent 友好、免隧道）：浏览器跳转失败后，用户把地址栏完整 URL（含 `?code=...&state=...`）复制回传，Agent 在服务器上 `curl "http://localhost:51121/oauth-callback?code=...&state=..."`，监听进程捕获 code 即完成登录
3. **进程粘贴**（实测最顺，配合 `-oauth-callback-port <port>` 指定端口）：登录进程打印授权 URL 后等待输入，提示 `Paste the antigravity callback URL (or press Enter to keep waiting)`——Agent 直接在后台进程 stdin 里 submit 用户回传的完整回调 URL（`process(action='submit')`），进程捕获后自动完成 token 交换并写入 `auth-dir/antigravity-<email>.json`，打印 `Antigravity authentication successful` 后退出
  - **stdin 可能不可用（2026-09-15 实测）**：后台登录进程若报 `Process stdin not available (non-local backend or stdin closed)`（`process(action='submit')` 直接失败），**别纠结，切方法 2 的 URL 桥接**——直接把用户回传的完整回调 URL 参数拼进 `curl "http://localhost:51121/oauth-callback?<参数>"`，返回 `HTTP 200 <h1>Login successful</h1>` 即完成，进程照常换 token 并退出。两条路殊途同归。

⚠️ 授权链接含一次性 code：提醒用户**私发**，不要发群。
⚠️ 登录成功后必须 `systemctl restart cliproxyapi`（或等热重载）再实测 `POST /v1/chat/completions`，不要用 auth 前的旧 access_token 判断。

## 验证与工具调用（Function Calling）
- 模型列表：`curl http://localhost:8317/v1/models -H "Authorization: Bearer <APIKEY>"`
- 客户端接入：base_url 指向 `http://<服务器IP>:8317/v1`
- **Agent 编程适配**：Antigravity 账号衍生的 `claude-sonnet-4-6` 与 `claude-opus-4-6-thinking` 原生支持 OpenAI 格式的 `tool_calls`（Function Calling），写代码、调工具的稳定性远优于 `gemini-*-flash`。

## 多账号池与热重载
- 往 `auth-dir`（默认 `~/.cli-proxy-api`）添加多个 OAuth 凭证（例如多个 `antigravity-<email>.json`）即可组成多账号池，自动轮询 / 负载均衡，突破单一账号配额。
- **无需重启服务**：服务内置文件监控（`events.go`），检测到 `auth-dir` 新增凭证（CREATE 事件）会自动增量热重载生效。
- 新增账号操作：直接后台启动临时登录命令 `./cli-proxy-api -config config.yaml -antigravity-login -no-browser`，完成回调 curl 后生成新 json，常驻服务立即感知并加载。
- **必须核对「到底授权了哪个号」（2026-09-10 实测踩到）**：Google 回调 URL 会带 `authuser=0`，浏览器往往直接复用默认已登录账号——用户以为登的是小号，实际凭证落在大号上。判据只有一个：auth-dir 里新生成的 `antigravity-<email>.json` 文件名。同名 = 覆盖旧凭证（同一账号重授权）；新名 = 账号池 +1。给用户授权链接时必须写明「**用无痕窗口、窗口内只登目标账号；授权页若显示别的邮箱先点『使用其他账号』**」，并在回调回来后先 `ls ~/.cli-proxy-api/` 核对邮箱再往下测。

## 归档恢复 / 重建部署（省流量）
网关被整体移除后归档在 `backups/<name>-removed-*/`。重建时**直接复用归档二进制，不要重新下载**（单文件 63MB；云端按出网流量计费时这点很关键）：

```bash
B=/home/ubuntu/backups/<archived>/cliproxyapi
mkdir -p /home/ubuntu/cliproxyapi
cp -a $B/cli-proxy-api $B/config.yaml $B/static /home/ubuntu/cliproxyapi/
chmod +x /home/ubuntu/cliproxyapi/cli-proxy-api    # 关键：归档拷贝常丢执行位，否则直接跑 Permission denied
/home/ubuntu/cliproxyapi/cli-proxy-api --help | head -15   # 确认版本与可用 flag
```

- **systemd unit 不要照抄归档里那份**：归档 unit 的 `After/Wants` 往往只有 `network-online.target systemd-resolved.service`，缺 `nss-lookup.target` —— 照抄等于把上面那条 DNS 抢跑坑一起恢复。重写成 `After=network-online.target nss-lookup.target systemd-resolved.service`（`Wants` 同），配 `Restart=always` + `LimitNOFILE=65536`——现成的加固单元文件见 `templates/cliproxyapi.service`，直接 `sudo cp` 到 `/etc/systemd/system/` 即可，别手打。
- **仅本机 Hermes 接入时保持 `host: "127.0.0.1"`**：无需放行 AWS 安全组 8317，也不暴露公网 IP；只有跨机接入才改 `0.0.0.0` + 放行安全组 + 开 remote-management secret-key。
- **重建成功的三条判据（缺一不可，别只看 `is-active`）**：
  1. `systemctl is-active cliproxyapi` = active 且 `ss -tlnp | grep 8317` 有监听；
  2. 日志有 `API server started successfully on: 127.0.0.1:8317`；
  3. 日志有 `startup model refresh completed from https://raw.githubusercontent.com/router-for-me/models/...` —— **没有这条 = 模型目录没拉到**，此后 3 小时内新模型全返 400 `unknown provider`，立刻 `systemctl restart cliproxyapi` 重试，别干等。
- 首启日志 `created missing auth directory: ~/.cli-proxy-api` 是正常现象（凭证目录被归档清空后自动重建），不是报错；`full client load complete - 0 clients (0 auth files ...)` 同理。
- 归档期日志里的 `auth file changed (WRITE): antigravity-<email>.json` 可反查上次登录用的是哪个 Google 账号。
- 服务常驻后再跑登录进程即可：登录进程与常驻服务共用同一 `-config` 与 auth-dir，凭证写盘即被文件监控热加载，**服务不用重启**。
- 完整实操记录（真实命令、日志、踩坑）见 `references/restore-from-archive.md`。

## Pitfalls
- **全新账号登录报 `failed to fetch project ID: no project_id in response`（2026-09-15 实测）**：
  - 症状：OAuth 回调 200 + token 交换成功（日志 `Antigravity: onboarding user with tier: standard-tier`），但登录进程最后一步失败退出，**auth-dir 不新增 json（凭证根本没落盘）**。
  - 根因：Antigravity 项目承载在 Gemini Code Assist 的 Cloud 项目上，**从没用过反重力的全新账号还没被分配 project_id**（`loadCodeAssist` 响应无 `cloudaicompanionProject`，上游 issue #1030）。与「账号被拦」区分：被拦是 403 VALIDATION_REQUIRED（重授权无效）；这是 onboarding 成功但拿不到项目，属未激活态。
  - 解法（社区验证，上游 issue #2047）：让该账号先用 **Gemini Code Assist**（VS Code 扩展/官方入口）登录激活一次，Google 自动给账号建 Cloud 项目，再回 CPA 重新 OAuth 授权即成功；或直接重试一次登录——首次 onboarding 成功本身可能已触发建项目。个别 case 是账号曾被封未申诉所致（issue #4008）。
  - 判定要点：`onboarding user with tier: standard-tier` 出现 ≠ 登录成功，**唯一判据是 auth-dir 新增 `antigravity-<email>.json`**；失败时登录进程输出 `Antigravity authentication failed` 后退出，看该输出比翻日志快。
- **全模型持续 429 `RESOURCE_EXHAUSTED` = 上游配额真的用完（不是部署故障，别重装/重授权）**：
  - 症状：`POST /v1/chat/completions` 对**该账号所有模型**返回
    `{"error":{"code":429,"message":"Resource has been exhausted (e.g. check quota).","status":"RESOURCE_EXHAUSTED"}}`；
    而 `systemctl is-active cliproxyapi` 仍是 active、token 未过期、也没有 403 `VALIDATION_REQUIRED`。
  - **第一步必须分清「每分钟限流抖动」和「配额墙」**：只看错误码分不出来，要看时间分布——
    429 出现后 ~15 秒内又回到 200 的是分钟级抖动（什么都不用做）；
    429 之后**再无 200** 的才是配额墙。
  - **从上游端点名读出配额周期**：失败请求的详细 body 在
    `~/.cli-proxy-api/logs/error-v1-chat-completions-*.log` 里，其中 `=== API REQUEST N ===` 段给出 Upstream URL
    —— 看到 **`daily-cloudcode-pa.googleapis.com`** 的 `daily-` 前缀即**每日配额**。
  - **查账号层级**：用 auth json 的 access_token 打
    `POST https://daily-cloudcode-pa.googleapis.com/v1internal:loadCodeAssist -d '{"metadata":{"pluginType":"GEMINI"}}'`，
    返回 `allowedTiers[].id == "standard-tier"` 就是 **Gemini Code Assist 免费层（日配额很小，重度使用必爆）**
    （同响应里的 `UNSUPPORTED_CLIENT` 迁移提示是噪音，不影响判断）。
  - **重置时刻按太平洋午夜算，注意夏令时**：PDT(3~11月)=UTC-7 → 07:00 UTC = 北京 15:00；
    PST=UTC-8 → 08:00 UTC = 北京 16:00。但社区实测普遍要 **5～24 小时**，且**有时只恢复约 20%**——
    给用户答复时机制点与实测延迟两头都要说，不要把「太平洋午夜」当承诺。
  - **先找「是谁用光的」**：免费层最容易的元凶是 **Agent 自己**。若 Hermes 主 provider 就指向该网关，
    每轮对话/每次工具调用都是一次请求，一个长会话几百次调用就能吃光日配额
    （自检：`grep -l "You are Hermes Agent" ~/.cli-proxy-api/logs/*.log`）。
    **架构建议：Agent 主模型与面向用户的 Bot 不要共用同一配额池**，
    把网关配额专门留给用户可见的服务，否则 Agent 一忙 Bot 就哑火。
  - **别干等，挂静默看门狗**：`scripts/quota-recovery-probe.py`（针对 429 配额耗尽恢复探测，未恢复零输出、恢复才播报、带实际耗尽时长），或 `scripts/antigravity-unban-watchdog.py`（针对小号 403 VALIDATION_REQUIRED 隔离观测，未解封零输出、解封自动回池重启网关并播报），
    配 `cronjob(..., schedule='every 10m', no_agent=True, deliver='origin')`。
  - **下游服务不能跟着哑火**：做多级兜底链（同网关的**不同模型也算不同节点**，429 常是模型级配额），
    且失败时必须发**用户可见**的原因提示——静默 `return` 在用户看来就是「服务死机」。
  - 完整排障流程（状态切换点提取脚本、loadCodeAssist、按小时消耗统计、验收清单）见
    `references/quota-exhaustion-diagnosis.md`。
- **启动期 DNS 抢跑与 3 小时模型目录刷新真空（unknown provider / model_not_found 400）**：
  - CLIProxyAPI 启动时会向 GitHub 远端拉取最新模型目录（`models.json`）以注册 provider（如 Antigravity 映射的 `gemini-3.8-flash-high` 等）。
  - 若系统重启时 `cliproxyapi` 抢先在 `systemd-resolved` 或网络就绪前启动，启动刷新将因 DNS 解析失败（`connection refused`）而静默放弃。
  - **严重陷阱**：其内部的自动重试定时器间隔长达 **3 小时（`interval=3h0m0s`）**。在拉取失败后的 3 小时内，网关对未注册进初始表的新模型全部直接返回 400 `{"error":{"message":"unknown provider for model ...","code":"model_not_found"}}`，直到 3 小时到达后自动刷新才恢复。
  - **加固与排障**：
    1. systemd service 的 `[Unit]` 段必须加入 `After=network-online.target nss-lookup.target systemd-resolved.service`，防止启动并发争抢 DNS。
    2. 若排障发现此报错且日志伴随 `startup model refresh: fetch failed`，无需等待 3 小时，直接 `systemctl restart cliproxyapi`（或 curl 重新触发）即可立即拉取目录恢复正常。
- **勿用 ChatGPT Plus / 网页订阅充当高频 Agent 主脑**：网页端转 API（如 ChatGPT Plus $20/月）具有严苛的 3 小时提问频控（40-80 次），而 Hermes/Claude Code 等 Agent 执行单次编码任务即可能触发数十次工具交互，几分钟即可打满配额；且逆向/网页 Session 封号风险极高。高强度 Agent 编码任务优先选按量付费 API 或通过 Antigravity 映射的 Claude 模型。
- **Gemini 轮次与函数调用结构校验（HTTP 400 触发 Fallback）**：Gemini 上游对多轮历史的角色交替结构要求严苛，若历史中存在未闭合的函数调用、或多模态消息插入破坏了交替，上游抛出 `400: Please ensure that function call turn comes immediately after a user turn or after a function response turn.`。Hermes 会捕获该错误并自动降级激活 `fallback_providers`，单次会话降级不影响全局默认主模型。
- **Antigravity/VALIDATION_REQUIRED 是账号级安全验证，OAuth 重授权无法清除（2026-09 实测）**：
  - 症状：`POST /v1/chat/completions` 返回 403 `PERMISSION_DENIED`，`reason=VALIDATION_REQUIRED`，`domain=cloudcode-pa.googleapis.com`，消息 `Verify your account to continue.`，附 `validation_url`（accounts.google.com/signin/continue?...&plt=...&flowName=GlifWebSignIn）。
  - 根因：Google 账号未完成必要的安全验证（账号级），不是 token/项目/配额问题。access_token 可能明明有效（tokeninfo 通过），但 cloudcode 入口仍拦。
  - **陷阱 1：validation_url 的 `plt` 参数每次上游请求都会重新生成**。若 Agent 会话自身正走该网关（默认模型= gemini-proxy），每回复一次就向网关发请求 → 新生成 plt → 用户正在点的验证链接立即失效 → 用户永远看到「出了点问题，我们无法验证您的信息」。**死循环**。解法：让用户验证前，先把默认模型切离该网关（`hermes config set model.provider nofx` 等），确认无任何进程再打 8317。
  - **陷阱 2：重新 OAuth 授权（-antigravity-login）或搭建 CPA WebUI 面板 ≠ 清除 VALIDATION_REQUIRED**：
    - 实测重新授权拿到全新 token 后调用仍报 403。WebUI 管理面板仅是控制台前端，调用底层与 CLI 完全相同，绝无法绕过上游风控。
    - **解除 VALIDATION_REQUIRED 的四步核验清单（小号/订阅号必做）**：
      1. **基础安全加固**：登录目标 Google 账号进入 `https://myaccount.google.com/security` 绑定手机号、辅助邮箱并开启两步验证（2FA）；
      2. **安全体检消警**：访问 `https://myaccount.google.com/security-checkup`，若有近期异地登录或安全警告，手动确认为“是我本人”，消灭所有黄/红标；
      3. **激活 GCP 服务条款**：访问一次 `https://console.cloud.google.com/`，若弹出服务协议则勾选同意并继续（无需绑定信用卡，打通 Cloud Code 开发者底层权限）；
      4. **无痕环境隔离授权**：授权时务必在全新**无痕/隐身窗口**下打开链接，且窗口内**仅登录该目标账号**，防止多账号 Cookie 串号（避免触发 `authuser=0` 串到大号或大号风控连坐）。完成上述四步后再重新生成 OAuth 授权链接并签发新 token。
  - **2026-09-10 复现 + 一分钟定性手法（别再重装/换号折腾）**：同一账号重授权拿到全新 access/refresh token 后，`claude-sonnet-4-6` 与 `gemini-3.8-flash-high` 依旧 403 `VALIDATION_REQUIRED`。定性只需一步——把本次错误与归档日志对照：`grep -ohE "VALIDATION_REQUIRED|Verify your account|[a-zA-Z0-9._%-]+@gmail\.com" <归档目录>/.cli-proxy-api/logs/*.log | sort | uniq -c`；若错误类型与账号名和上次完全一致，即为**账号级封锁**，与本机部署/端口/模型映射无关，重装、改 callback port、换 provider flag 全是白工。此时只有两条路：用户去补账号安全验证，或改走 AI Studio 官方 key。
- **403 之后的连锁 503 `auth_unavailable: no auth available (providers=antigravity, model=...)` 是假故障（2026-09-10 实测）**：
  - 现象：连续几次 403 之后，网关对该模型改返 503 `{"error":{"message":"auth_unavailable: no auth available (providers=antigravity, model=...)"}}`，但 `~/.cli-proxy-api/antigravity-<email>.json` 里 `disabled` 仍是 `false`，日志也明明写着 `full client load complete - 1 clients (1 auth files ...)`。
  - 根因：调度器把刚失败的凭证**临时隔离**（内存态、不落盘）。不是凭证丢失、不是热重载失败、更不是「需要重新登录」。
  - 处理：`sudo systemctl restart cliproxyapi` 即清，随后**单次**实测即可看到上游真实结果（403 或 200）。切忌把 503 误判成账号池空了而去重跑一遍 OAuth。
  - **封号蔓延警告（重要）**：Google 正在封禁用第三方工具（CLIProxyAPI/OpenCode/OpenClaw 等）走 Antigravity OAuth 的账号——Antigravity 服务条款本身就禁止第三方工具接入（OpenClaw 文档原文：*the Antigravity terms prohibit third-party tools from accessing the service through Antigravity*），且 2026-06-18 起个人账号的 Gemini CLI 登录已终止。**大号突封很可能就是这个原因**。换小号继续走 antigravity 网关 = 小号也危险。
  - **正路**：改用 Google AI Studio 官方 API key（`AIza` 开头），配 OpenAI 兼容原生端点 `https://generativelanguage.googleapis.com/v1beta/openai`（或 hermes 官方 provider），符合 ToS、无封号风险。AI Studio 有地区限制（香港不在支持列表），需换美国/日本/新加坡等节点 + 全局模式 + 无痕窗口领取 key；代理 IP 被标记时换节点后用 `https://ipinfo.io` 确认出口国家。
  - **2026-09-10 实测补充（关键）**：VALIDATION_REQUIRED 的解除权完全在 Google 账号侧，OAuth 只是把账号当前状态签进 token。
    - 账号被 Google 恢复/申诉解封后，**重新 OAuth 授权一次即可通过**：大号 `<YOUR_EMAIL>@gmail.com` 实测 200，`claude-sonnet-4-6` 与 `gemini-3.8-flash-high` 均正常出话，且 OpenAI 格式 `tool_calls` 原生可用（Agent 编程可用）。
    - 账号仍处被拦状态时，再授权**无效**：小号 `<YOUR_EMAIL>@gmail.com` 同日重新授权后仍 403 VALIDATION_REQUIRED（与 2 周前归档日志中完全相同的错误+相同的账号）。
    - 结论：撞到此错先判断「账号本身是否已被恢复」，别反复重授权浪费时间。
    - **当用户询问被拦截账号状态时，必须优先检查 cronjob 是否已有静默看门狗**：切勿未核查直接向用户重复抛出 4 步加固指引（用户往往此前已全量完成并挂载了看门狗）。应优先 `cronjob(action='list')` 检查看门狗运行频次与状态，如实汇报后台真实探测数据。
    - **直连 upstream 探测端点报文格式陷阱（2026-09-14 踩坑修复）**：若编写 Python 看门狗绕过 CLIProxyAPI 直调 `https://daily-cloudcode-pa.googleapis.com/v1internal:generateContent`，切勿使用标准 Gemini 顶层参数（顶层带 `contents` 会返 `400 INVALID_ARGUMENT: Unknown name "contents"`），必须严格按 Cloud Code 内部协议包裹：`{"project": auth.get("project_id", "aicode-consumers"), "model": "gemini-2.5-flash", "request": {"contents": [{"role": "user", "parts": [{"text": "ping"}]}], "generationConfig": {"maxOutputTokens": 5}}}`，否则永远无法触发正确的 200 或 403 权限判定。
  - **多账号池里混入被拦账号会污染排障与单号拨测手法**：坏号会导致请求间歇 403，或本地 503 `auth_unavailable: no auth available (providers=antigravity, model=...)`（网关对连续失败的凭证做**本地隔离**，只重启服务才复位，`disabled` 字段仍是 false）。
    - **生产零停机沙盒隔离拨测法（推荐，严禁在活跃会话时重启生产服务）**：
      若生产网关（8317）正在承载活跃会话/Bot，千万不要在生产 `auth-dir` 里倒腾文件或重启服务。直接拉起临时沙盒：
      1. `mkdir -p /tmp/test_cliproxy/auth`，将待测凭证复制到该目录；
      2. 写入沙盒配置 `/tmp/test_cliproxy/config.yaml`（`port: 8318`，`auth-dir: "/tmp/test_cliproxy/auth"`，独立 api-key）；
      3. 后台启动沙盒实例：`/home/ubuntu/cliproxyapi/cli-proxy-api -config /tmp/test_cliproxy/config.yaml`；
      4. 向 `127.0.0.1:8318` 发起真实推理测试（**注意：仅测 `tokeninfo` 或 `loadCodeAssist` 返回 200 绝不代表可用，Google 的账号级风控只在触发模型推理 `POST /v1/chat/completions` 时才会抛出 `VALIDATION_REQUIRED`**）；
      5. 测完立即终止临时沙盒进程并清理临时目录。生产服务零中断、零污染。
    - **冷态排查**：若无活跃服务，也可将其它 `<type>-<email>.json` 移出 auth-dir → `systemctl restart cliproxyapi` → 测完移回。
  - 排查小技巧：`strings -n 20 <cli-proxy-api二进制> | grep -iE "GOCSPX-|client_secret"` 可提取内置 OAuth client secret；antigravity 的 client_id 形如 `<项目号>-<后缀>.apps.googleusercontent.com`，OAuth token 端点仍是 `https://oauth2.googleapis.com/token`（用错 secret 会得到 `invalid_client`，账号被封的旧 token 刷新会 `invalid_grant`，client 被 Google 全局禁用会 `disabled_client`）。
- 只有跨机接入才需要放行 AWS 安全组 8317 入站端口；本机 Hermes 走 `127.0.0.1` 时保持 `host: "127.0.0.1"`，不必放行也不暴露公网 IP
- 管理面板默认禁远程；远程管理必须配 secret-key
- 授权 URL 里的 redirect_uri 是固定 localhost 端口（51121 等），由 `-oauth-callback-port` 可覆盖
- 文档站正文用 curl GitHub raw 拉，别用网页提取器（SPA 无正文）
