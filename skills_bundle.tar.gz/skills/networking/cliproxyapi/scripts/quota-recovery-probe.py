#!/usr/bin/env python3
"""
OpenAI 兼容网关（CLIProxyAPI 等）配额恢复探测 —— 静默看门狗

行为契约（配合 Hermes cronjob no_agent=True）：
  * 仍未恢复  -> stdout 为空   -> cron 完全静默，不打扰用户
  * 已恢复    -> 打印一条带「实际耗尽时长」的通知 -> cron 原样投递给用户
  * 已通报过  -> 保持静默，避免每轮重复播报

环境变量：
  LLM_GATEWAY_URL   默认 http://127.0.0.1:8317/v1/chat/completions
  GATEWAY_API_KEY   网关 api-keys 里的一把（必填）
  PROBE_MODEL       默认 gemini-3.8-flash-high（换成该账号任一模型均可）
  PROBE_STATE_FILE  默认 ~/.hermes/state/api_quota_probe.json

退出码恒为 0（看门狗不应因探测失败而报错刷屏）。
"""
import json
import os
import time
import urllib.error
import urllib.request

GATEWAY = os.getenv("LLM_GATEWAY_URL", "http://127.0.0.1:8317/v1/chat/completions")
KEY = os.getenv("GATEWAY_API_KEY", os.getenv("ANTIGRAVITY_API_KEY", ""))
MODEL = os.getenv("PROBE_MODEL", "gemini-3.8-flash-high")
STATE_FILE = os.path.expanduser(
    os.getenv("PROBE_STATE_FILE", "~/.hermes/state/api_quota_probe.json")
)


def load_state():
    try:
        with open(STATE_FILE) as f:
            return json.load(f)
    except Exception:
        return {}


def save_state(st):
    try:
        os.makedirs(os.path.dirname(STATE_FILE), exist_ok=True)
        with open(STATE_FILE, "w") as f:
            json.dump(st, f)
    except Exception:
        pass


def probe():
    """返回 (http_status, body)。0 表示连不上。"""
    payload = json.dumps({
        "model": MODEL,
        "messages": [{"role": "user", "content": "ping"}],
        "max_tokens": 5,
    }).encode()
    req = urllib.request.Request(GATEWAY, data=payload, headers={
        "Authorization": f"Bearer {KEY}",
        "Content-Type": "application/json",
    })
    try:
        with urllib.request.urlopen(req, timeout=40) as r:
            return r.status, r.read().decode("utf-8", "ignore")
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode("utf-8", "ignore")
    except Exception as e:
        return 0, str(e)


def fmt_dur(sec):
    sec = int(sec)
    h, m = divmod(sec // 60, 60)
    return f"{h} 小时 {m} 分钟" if h else f"{m} 分钟"


def main():
    if not KEY:
        return  # 没配 key 就不探测，避免刷错误

    st = load_state()
    status, _ = probe()
    now = time.time()

    if status == 200:
        if st.get("notified_recovered"):
            return  # 已通报过，保持静默
        first_exhaust = st.get("first_exhaust_ts")
        dur = f"约 {fmt_dur(now - first_exhaust)}" if first_exhaust else "未知"
        st.update({"notified_recovered": True, "recovered_at": now})
        save_state(st)
        print(
            "🎉 网关额度已恢复！\n"
            "• 探测结果：HTTP 200 正常响应\n"
            f"• 模型：{MODEL}\n"
            f"• 耗尽时长：{dur}\n"
            f"• 恢复时间：{time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(now))}\n"
            "• 下游服务已可切回该网关的主力模型。"
        )
        return

    # 未恢复：记录首次耗尽时间（供恢复时算时长），保持静默
    if not st.get("first_exhaust_ts"):
        st["first_exhaust_ts"] = now
        st["notified_recovered"] = False
    st["last_probe"] = now
    st["last_status"] = status
    save_state(st)


if __name__ == "__main__":
    main()
