#!/usr/bin/env python3
"""
小号反重力解封看门狗：每 10 分钟用 refresh_token 探测 Google Cloud Code 风控状态。
行为契约（配合 Hermes cronjob no_agent=True）：
  * 未解封（403 / 其他） -> 零输出（静默） -> cron 完全静默，不打扰用户
  * 已解封（200 OK）      -> 凭证放回账号池 + 重启网关 + 输出播报 -> cron 原样投递通知
"""
import datetime
import json
import os
import subprocess
import time
import requests

HOLDING_DIR = os.getenv("HOLDING_DIR", "/home/ubuntu/backups/antigravity-holding-20260913")
POOL_DIR = os.getenv("POOL_DIR", "/home/ubuntu/.cli-proxy-api")
AUTH_FILE = os.path.join(HOLDING_DIR, "antigravity-<YOUR_EMAIL>@gmail.com.json")

CLIENT_ID = os.getenv("ANTIGRAVITY_CLIENT_ID", "1071006060591-tmhssin2h21lcre235vtolojh4g403ep.apps.googleusercontent.com")
CLIENT_SECRET = os.getenv("ANTIGRAVITY_CLIENT_SECRET", "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")


def main():
    if not os.path.exists(AUTH_FILE):
        # 凭证已不在 holding（已放回池子），任务完成，静默退出
        return

    try:
        with open(AUTH_FILE) as f:
            auth = json.load(f)
    except Exception:
        return

    access_token = auth.get("access_token", "")
    expired = auth.get("expired", "")
    refresh_token = auth.get("refresh_token", "")

    # token 有效性检查：未过期则直接用，过期则刷新
    need_refresh = True
    if expired:
        try:
            exp = datetime.datetime.strptime(expired, "%Y-%m-%dT%H:%M:%SZ").replace(
                tzinfo=datetime.timezone.utc
            )
            if datetime.datetime.now(datetime.timezone.utc) < exp - datetime.timedelta(seconds=60):
                need_refresh = False
        except Exception:
            need_refresh = True

    if need_refresh:
        try:
            r = requests.post(
                "https://oauth2.googleapis.com/token",
                data={
                    "refresh_token": refresh_token,
                    "client_id": CLIENT_ID,
                    "client_secret": CLIENT_SECRET,
                    "grant_type": "refresh_token",
                },
                timeout=15,
            )
            if r.status_code != 200:
                return  # 刷新失败（如 refresh_token 失效），静默
            data = r.json()
            access_token = data["access_token"]
            auth["access_token"] = access_token
            auth["expired"] = (
                datetime.datetime.utcnow() + datetime.timedelta(seconds=3599)
            ).strftime("%Y-%m-%dT%H:%M:%SZ")
            auth["timestamp"] = int(time.time() * 1000)
            with open(AUTH_FILE, "w") as f:
                json.dump(auth, f)
            os.chmod(AUTH_FILE, 0o600)
        except Exception:
            return

    # 探测 generateContent 端点（VALIDATION_REQUIRED 唯一触发点）
    # 注意：必须带 project 并在 request 嵌套 contents，否则报 400 INVALID_ARGUMENT
    project_id = auth.get("project_id", "aicode-consumers")
    headers = {
        "Authorization": f"Bearer {access_token}",
        "Content-Type": "application/json",
        "User-Agent": "antigravity/hub/2.12.2 darwin/arm64",
    }
    try:
        body = {
            "project": project_id,
            "model": "gemini-2.5-flash",
            "request": {
                "contents": [{"role": "user", "parts": [{"text": "ping"}]}],
                "generationConfig": {"maxOutputTokens": 5},
            },
        }
        r = requests.post(
            "https://daily-cloudcode-pa.googleapis.com/v1internal:generateContent",
            headers=headers,
            json=body,
            timeout=20,
        )
        if r.status_code == 200:
            # ===== 解封！放回账号池并让网关加载 =====
            auth["disabled"] = False
            pool_file = os.path.join(POOL_DIR, os.path.basename(AUTH_FILE))
            with open(pool_file, "w") as f:
                json.dump(auth, f)
            os.chmod(pool_file, 0o600)
            os.remove(AUTH_FILE)
            subprocess.run(["sudo", "systemctl", "restart", "cliproxyapi"], timeout=30)
            time.sleep(3)
            email = auth.get("email", "小号")
            print(f"🎉 小号 {email} 已解除 VALIDATION_REQUIRED 拦截！")
            print("凭证已放回反重力账号池并重启网关，双号负载均衡自动生效。")
        # 403 / 其他状态 = 仍未解封，静默
    except Exception:
        pass


if __name__ == "__main__":
    main()
