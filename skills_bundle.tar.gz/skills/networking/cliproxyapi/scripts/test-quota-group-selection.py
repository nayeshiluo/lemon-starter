#!/usr/bin/env python3
"""CPA 面板「额度分组选源逻辑」回归测试（node + 桩响应，不调用上游、不耗额度）。

背景：CPA 的 static/management.html 是压缩 bundle，Antigravity 额度查询会依次尝试
三个 Google quota 端点。实测只有 cloudcode-pa 会返回 Gemini 分组，另两个只返回
Claude/GPT；旧逻辑「首个非空响应即 return」会静默丢掉 Gemini 整组。

本脚本从线上 HTML 中提取那段选源代码，用桩响应跑 5 个场景：
  1. 首个源缺 Gemini、后续源含 Gemini   -> 必须选到含 Gemini 的完整源
  2. 所有源都缺 Gemini                  -> 必须返回分组最多的有效源，不返回空
  3. 仅 Gemini 源可用                   -> 必须能选到
  4. 上一账号有数据、当前账号所有源都空 -> 必须返回空，不得继承上一账号结果（防全局暂存污染）
  5. 非 2xx 与非法 body 混入            -> 仍能落到有效源，不抛未捕获异常

用法:
  python3 test-quota-group-selection.py [management.html 路径]
退出码: 0 全部通过 / 1 有场景失败 / 2 未能定位选源片段（面板版本变化，需人工重定位）
"""
import json
import os
import subprocess
import sys
import tempfile

DEFAULT_HTML = "/home/ubuntu/cliproxyapi/static/management.html"

# 选源片段的起止锚点（minified bundle 中稳定存在的两处）
START = "let i=JSON.stringify({project:r})"
END = "throw D_(o||t(`common.unknown_error`),c??s)"

HARNESS = r"""
const gg = [`daily`, `sandbox`, `cloudcode`];
let CURRENT = {};
const Rp = { request: async (e) => ({ ...CURRENT[e.url], header: {} }) };
const _v = { get: () => Promise.resolve(null) };
const yO = () => null;
const xg = {};
const vO = () => 0;
const Lp = () => `err`;
const O_ = () => 0;
const D_ = (m, c) => new Error(m);
const t = (k) => k;
const P_ = (u) => (u.groups || []).map((g) => ({ label: g.displayName, buckets: g.buckets || [] }));
const t_ = (b) => { try { return typeof b === `string` ? JSON.parse(b) : b; } catch { return null; } };
let n = `auth1`;
let r = `proj1`;

const runSelection = async () => { __SNIPPET__ };

const ok = (groups) => ({ statusCode: 200, body: JSON.stringify({ groups }) });
const grp = (name, wins) => ({ displayName: name, buckets: wins.map((w) => ({ window: w, remainingFraction: 1 })) });

const CLAUDE_ONLY = [grp(`Claude and GPT models`, [`weekly`, `5h`])];
const BOTH = [grp(`Gemini Models`, [`weekly`, `5h`]), grp(`Claude and GPT models`, [`weekly`, `5h`])];
const GEMINI_ONLY = [grp(`Gemini Models`, [`weekly`, `5h`])];

async function scenario(label, responses, auth, project, expectGemini, expectGroups) {
  CURRENT = responses;
  n = auth;
  r = project;
  let out;
  try {
    out = await runSelection();
  } catch (e) {
    console.log(JSON.stringify({ label, labels: [`THREW: ` + e.message], pass: false }));
    return false;
  }
  const labels = (out && out.groups ? out.groups : []).map((g) => g.label);
  const hasGemini = labels.some((l) => l.toLowerCase().includes(`gemini`));
  const pass = hasGemini === expectGemini && labels.length === expectGroups;
  console.log(JSON.stringify({ label, labels, pass }));
  return pass;
}

(async () => {
  let allPass = true;

  allPass = (await scenario(`first-source-lacks-gemini`,
    { daily: ok(CLAUDE_ONLY), sandbox: ok(CLAUDE_ONLY), cloudcode: ok(BOTH) },
    `authA`, `projA`, true, 2)) && allPass;

  allPass = (await scenario(`no-source-has-gemini`,
    { daily: ok(CLAUDE_ONLY), sandbox: ok(CLAUDE_ONLY), cloudcode: ok(CLAUDE_ONLY) },
    `authB`, `projB`, false, 1)) && allPass;

  allPass = (await scenario(`gemini-only-source`,
    { daily: ok(CLAUDE_ONLY), sandbox: ok(CLAUDE_ONLY), cloudcode: ok(GEMINI_ONLY) },
    `authC`, `projC`, true, 1)) && allPass;

  // 关键：上一账号刚返回过数据，本账号所有源都空 -> 不得复用上一账号结果
  allPass = (await scenario(`empty-account-must-not-inherit-previous`,
    { daily: ok([]), sandbox: ok([]), cloudcode: ok([]) },
    `authD`, `projD`, false, 0)) && allPass;

  allPass = (await scenario(`mixed-http-errors`,
    { daily: { statusCode: 503, body: `{}` }, sandbox: { statusCode: 200, body: `not-json` }, cloudcode: ok(BOTH) },
    `authE`, `projE`, true, 2)) && allPass;

  console.log(`ALL_PASS ${allPass}`);
  process.exit(allPass ? 0 : 1);
})();
"""


def main() -> int:
    path = sys.argv[1] if len(sys.argv) > 1 else DEFAULT_HTML
    if not os.path.exists(path):
        print(f"ERROR 找不到面板文件: {path}")
        return 2
    html = open(path, encoding="utf-8", errors="replace").read()

    if START not in html or END not in html:
        print("SKIP 未能定位选源片段（面板版本可能已变化）。")
        print("     请在 bundle 中搜索 retrieveUserQuotaSummary 附近，重新确定 START/END 锚点后再跑。")
        return 2

    start = html.index(START)
    end = html.index(END, start)
    snippet = html[start:end].strip()
    if not snippet.rstrip().endswith("}"):
        snippet = snippet.rstrip().rstrip(";") + ";"

    js = HARNESS.replace("__SNIPPET__", snippet)
    fd, js_path = tempfile.mkstemp(suffix=".mjs")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(js)
        proc = subprocess.run(["node", js_path], capture_output=True, text=True, timeout=120)
    finally:
        os.unlink(js_path)

    out = (proc.stdout or "").strip()
    for line in out.splitlines():
        if line.startswith("{"):
            try:
                row = json.loads(line)
                print(("PASS " if row.get("pass") else "FAIL ") + row["label"] + " -> " + json.dumps(row["labels"], ensure_ascii=False))
            except json.JSONDecodeError:
                print(line)
        elif line.startswith("ALL_PASS"):
            print(line)
    if proc.returncode != 0 and proc.stderr:
        print("STDERR " + proc.stderr.strip()[-500:])
    return proc.returncode


if __name__ == "__main__":
    sys.exit(main())
