---
name: proxy-subscription-aggregator
description: Use when converting proxy subs or aggregating nodes.
tags: [networking, proxy, subconverter, loon, clash, singbox]
---

# Proxy Subscription Aggregator & Converter Operations

## Overview
This skill covers building, deploying, and maintaining a high-performance proxy subscription aggregation and conversion service supporting Loon, Clash Meta (Mihomo), Sing-box, Surge, Quantumult X, and Shadowrocket.

## Architecture Pattern
A two-tier architecture provides both maximum client compatibility and rich multi-source aggregation:
1. **Conversion Engine Backend (Port 25500)**: Native `subconverter` binary (C++) running locally on `127.0.0.1:25500` for protocol transformation, rule injection (ACL4SSR), and client formatting.
2. **Aggregation & Management Layer (Port 8688)**: FastAPI/Python service managing collections, concurrency-fetching upstream subscriptions, decoding/normalizing base64 node lists, tagging node prefixes (e.g. `[自建HK]`, `[主力机场]`), and exposing permanent dynamic tokenized URLs.

## Implementation Workflow

### 1. Backend Subconverter Deployment
Download the latest prebuilt release binary to avoid heavy compilation:
```bash
mkdir -p /home/ubuntu/lemon-subconverter/bin
cd /home/ubuntu/lemon-subconverter/bin
curl -sL https://github.com/tindy2013/subconverter/releases/download/v0.9.0/subconverter_linux64.tar.gz -o subconverter.tar.gz
tar -xzf subconverter.tar.gz
chmod +x subconverter/subconverter
```

### 2. Upstream Aggregation & Tagging Logic
When aggregating multiple airport subscription URLs and raw single nodes (`vless://`, `vmess://`, `trojan://`, `ss://`, `hy2://`):
- Fetch upstream URLs concurrently using async HTTP client (`httpx`).
- Decode base64 node lists if returned as raw text.
- Inject source prefix remarks into node metadata (for VMess: modify JSON `ps`; for URI schemes: modify `#urlencode(tag)`).
- Re-encode combined node list into a standard base64 payload for the converter engine.

### 3. Client Header & Format Mapping
- **Loon**: Target `loon`, output extension `.conf`.
- **Clash Meta**: Target `clash`, output extension `.yaml`.
- **Sing-box**: Target `singbox`, output extension `.json`.
- **Surge**: Target `surge&ver=4`, output extension `.conf`.
- **Quantumult X**: Target `quanx`, output extension `.conf`.
- **Base64 Raw**: Directly return base64 payload.

## Pitfalls & Best Practices

1. **HTTP Header Non-ASCII Filename Encoding**:
   * *Problem*: Setting `Content-Disposition: attachment; filename="中文名.conf"` raises `UnicodeEncodeError: 'latin-1' codec can't encode characters`.
   * *Fix*: Use RFC 5987 / RFC 6266 encoding:
     ```python
     col_name_ascii = urllib.parse.quote(name)
     headers = {
         "Content-Disposition": f'attachment; filename="lemon_sub_{token}.conf"; filename*=UTF-8\'\'{col_name_ascii}.conf'
     }
     ```
2. **Subconverter 400 "No nodes were found" on Raw Base64**:
   * *Problem*: Passing local `data:text/plain;base64,...` directly to subconverter's `url=` param can fail or be length-truncated.
   * *Fix*: Expose an internal HTTP endpoint (e.g. `/api/raw/{token}`) returning the aggregated base64 text, and pass that internal HTTP URL to subconverter.
3. **Daemonizing Multi-Process Service**:
   * Use a single entry script `main.py` that spawns `subconverter` via `subprocess.Popen` and manages graceful shutdown on `SIGINT`/`SIGTERM` alongside the FastAPI `uvicorn` loop.
4. **Loon VLESS Reality Protocol Compatibility**:
   * *Problem*: Standard `subconverter` (v0.9.0) backend may drop or fail to translate modern VLESS Reality nodes (`flow=xtls-rprx-vision`, `security=reality`, `pbk`, `sid`) into Loon-compatible syntax during conversion.
   * *Fix*: Loon natively supports Reality and Shadowsocks via:
     - **Clipboard Direct Import**: Loon -> Configuration -> Node -> `+` -> Import from Clipboard using standard URI scheme (`vless://...`, `ss://...`).
     - **Native Loon Configuration Syntax**:
       ```ini
       [Proxy]
       Node_Reality = vless, <host>, <port>, "<uuid>", transport=tcp, sni=<sni>, server-cert-fingerprint=chrome, reality=true, public-key="<pbk>", short-id="<sid>", udp=true
       Node_SS = Shadowsocks, <host>, <port>, <cipher>, "<password>", udp=true
       ```
