# Telegram 订阅查询机器人与 Subscription-Userinfo 协议规范

## 1. 协议背景与工作原理
各大机场及节点面板（SSPanel-UIM, V2board, Xboard, 3x-ui, Marzban 等）遵循标准规范，在客户端拉取订阅链接时，于 HTTP Response Header 中返回用量与有效期元数据：

```http
Subscription-Userinfo: upload=1073741824; download=53687091200; total=1073741824000; expire=1780000000
```
部分平台还会附加：
- `profile-update-interval`: 客户端自动刷新周期（小时）
- `profile-web-page-url`: 机场官网地址

## 2. 模拟请求核心要点 (User-Agent 伪装)
绝大多数机场后端对爬虫或裸 `curl` / `python-requests` 做了防御（直接返回 403 或纯文本，不返回头部）。
- **必须设置拟人化/客户端 UA**：
  ```python
  HEADERS = {
      "User-Agent": "ClashforWindows/0.20.39",
      # 或 "Clash.Meta; clash-verge/v1.7.7"
      "Accept": "*/*",
  }
  ```
- **请求方法**：优先 `GET`（部分后端不支持 `HEAD` 返回 Header，或者 `HEAD` 不触发计费插件）。对于大订阅可设置 `stream=True` 只读 Response Header 而不下载整包 body，节省流量。

## 3. 数据解析与换算规范
```python
import re
import time
from datetime import datetime, timezone, timedelta

def parse_sub_info(header_value: str) -> dict:
    # 提取 upload, download, total, expire
    data = {}
    for item in header_value.split(";"):
        if "=" in item:
            k, v = item.strip().split("=", 1)
            try:
                data[k.lower()] = int(v)
            except ValueError:
                pass
    
    upload = data.get("upload", 0)
    download = data.get("download", 0)
    total = data.get("total", 0)
    used = upload + download
    remaining = max(0, total - used)
    expire_ts = data.get("expire", 0)
    
    # 时区转换：强制北京时间 (UTC+8)
    tz_beijing = timezone(timedelta(hours=8))
    expire_str = datetime.fromtimestamp(expire_ts, tz=tz_beijing).strftime("%Y-%m-%d %H:%M:%S") if expire_ts else "长期有效"
    
    # 倒计时
    now_ts = int(time.time())
    days_left = max(0, (expire_ts - now_ts) // 86400) if expire_ts else 9999
    
    # 进度条生成 (10格)
    percent = (used / total) if total > 0 else 0
    filled = int(percent * 10)
    bar = "█" * filled + "░" * (10 - filled)
    
    return {
        "used_gb": round(used / (1024**3), 2),
        "total_gb": round(total / (1024**3), 2),
        "remaining_gb": round(remaining / (1024**3), 2),
        "percent": round(percent * 100, 1),
        "bar": bar,
        "expire_str": expire_str,
        "days_left": days_left
    }
```

## 4. 节点内容解析 (Base64 / YAML)
- 若订阅内容为 Base64 编码，解码后为多行节点 URI (`vmess://`, `vless://`, `ss://`, `trojan://`, `hysteria2://`)。
- 统计协议类型（SS, VMess, VLESS, Trojan, Hy2）及节点总数。
- 节点名称通常包含地区（香港、日本、新加坡、美国），可用正则匹配提取国别并标注 Emoji 国旗。

## 5. 安全脱敏与群聊防盗刷 (Anti-Theft)
- **Token 脱敏**：订阅链接通常包含 `?token=...` 或 `/api/v1/client/subscribe?token=...`，展示时务必脱敏（如 `token=abc12****99`）。
- **群聊消息焚毁**：在 Telegram 群组中，用户发送订阅后，Bot 应提供自动撤回或提示用户撤回原消息，防止订阅被群友盗用。
- **开源生态参考**：
  - `wu-mx/subinfobot` (Go 语言极简版)
  - `0-o0/HelloSub_Bot` (Python/aiogram 卡片展示版)
