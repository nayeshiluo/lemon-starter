# Cloudflare Worker/Pages VLESS 节点与优选 IP/ProxyIP 运维指南

## 核心架构原理
Cloudflare Worker 代理基于 Cloudflare Edge 的 WebSocket 接收客户端加密流量，并通过 `connect()` TCP Socket API 转发至目标服务器或 ProxyIP 中继。

```
[客户端 (Clash/Sing-box/v2rayN/Loon)] 
       │ (TLS+WS, Host/SNI=自定义域名, Address=本地测速优选 IP)
       ▼
[Cloudflare Edge Anycast 节点 (最近/低延迟)]
       │ (Worker 内部 WebSocket 解析与 UUID 校验)
       ▼
[ProxyIP 出口池 或 专属 VPS 落地 (如 198.44.46.38)] 
       │ (规避 Cloudflare 1000 循环阻断与 CAPTCHA，或原生 VPS 出口)
       ▼
[目标网站 (Google / YouTube / 互联网目标)]
```

## 关键配置与陷阱 (Pitfalls)

### 1. 域名阻断与 SNI 重置
- **问题**：直接使用 `*.workers.dev` 或 `*.pages.dev` 官方后缀在境内遭遇大面积 DNS 污染和 SNI 重置阻断。
- **解决**：必须在 Cloudflare Worker 的 `Triggers` -> `Custom Domains` 绑定自定义二级域名（如 `proxy.example.com`）。客户端连接时 `Host` 与 `SNI` 必须严格等于该自定义域名。

### 2. Cloudflare 回源 1000 错误与 ProxyIP 必要性
- **问题**：Cloudflare 默认安全策略禁止 Worker 直接通过 TCP Socket 请求由 Cloudflare 自身 CDN 保护的目标网站（如 OpenAI、各类受 CF 保护的站点），会直接抛出 `Error 1000: DNS points to prohibited IP` 或 500。
- **解决**：在 Worker 代码中配置 `PROXYIP`。当目标流量出站时，强制将 TCP 连接重定向到 ProxyIP 出口进行解包转发。

### 3. 优选 IP (Clean IP) 测速与订阅注入
- **单 IP 静态配置缺陷**：单个 Anycast IP 容易在晚高峰遇到跨国拥塞或丢包。
- **动态订阅池方案**：通过 Worker 的 HTTP 路径（如 `https://自定义域名/UUID`）动态下发 Base64 订阅。
- 节点 URI 格式规范：
  ```text
  vless://<UUID>@<优选IP>:<端口>?encryption=none&security=tls&sni=<自定义域名>&type=ws&host=<自定义域名>&path=%2F#<地区与延迟备注>
  ```
- 测速端口兼容性：常用 TLS 端口包括 `443`、`8443`、`2083`、`2087`、`2096`；非 TLS 端口包括 `80`、`8080`、`8880`、`2052`、`2082`、`2086`、`2095`。

### 4. Cloudflare API 自动化部署权限鉴权排障
- **问题**：使用已有的 Cloudflare API Token 通过 CLI / REST API 部署 Worker 脚本时报 `10000 Authentication error`。
- **原因**：常见 API Token 仅配置了 `Zone: DNS: Edit` 权限（仅可增删改二级域名解析），缺乏账户级的 Worker 管理权限。
- **排障与权限要求**：
  * 自动化部署 Worker 必须申请包含 `Account -> Workers Scripts -> Edit` 权限的 API Token（或使用 Global API Key）。
  * 绑定 Custom Domain 则需额外包含 `Zone -> Workers Routes -> Edit` 与 `Zone -> DNS -> Edit` 权限。

### 5. 100% 终端无头自动化部署与绑定实操 Recipe
1. **上传 ES 模块 Worker 脚本 (`PUT /accounts/{account_id}/workers/scripts/{name}`)**：
   * 采用 `multipart/form-data`，包含 `metadata` (`{"main_module": "worker.js", "compatibility_date": "2024-11-12", "compatibility_flags": ["nodejs_compat"]}`) 和 `worker.js` 代码。
2. **绑定自定义域名 (`PUT /accounts/{account_id}/workers/domains`)**：
   * Payload: `{"hostname": "node.domain.com", "service": "worker_name", "zone_id": "<zone_id>", "environment": "production"}`。
3. **连通性校验与 User-Agent 避坑**：
   * Cloudflare 边缘启用了 Bot Fight Mode 时，裸 Python `urllib` 请求可能会收到 `403 Forbidden`。
   * 测试验证时必须携带常见客户端 User-Agent（如 `ClashMeta/1.18.0` 或浏览器 UA），并模拟 WebSocket 握手请求（带 `Upgrade: websocket` 与 `Sec-WebSocket-Key`）以确认 101 Switching Protocols。

### 6. 数据回传失败（只握手不回传）根因与双向流管道规范
- **现象**：客户端测试延迟或节点连接显示连通，但打开网页或测速时无法加载，上传/下载流量为 0 KB（只连接无法回传）。
- **根因**：
  1. `cloudflare:sockets` 模块必须通过 ES Module 方式严格引入：`import { connect } from 'cloudflare:sockets';`。
  2. VLESS 协议在 WebSocket 建立后，Worker 必须在接收到客户端首个带有目标 Host/Port 的 Payload 并成功连接目标后，向客户端 WebSocket 发送 2 字节响应头 `[0, 0]`。
  3. 未解包 WebSocket Binary Frame / EarlyData 时直接向 TCP socket 写入会导致协议解析错乱，目标服务器直接 RST 连接。
- **最佳实践**：采用生产验证的 `zizifn/edgetunnel` 完整双向流状态机（`handleTCPOutBound` 与 `remoteSocketToWS`），先直连目标，直连无数据响应时再平滑降级至 `PROXYIP` 出口。

### 7. 订阅响应头与客户端流量展示（如 100G 占位符）
- **现象**：客户端导入订阅后显示“剩余 100G / 已用 0G”。
- **原理**：Shadowrocket、Clash 等客户端依据 HTTP 响应头中的 `Subscription-Userinfo: upload=0; download=0; total=107374182400; expire=0` 渲染流量状态条。Cloudflare Worker 实际按请求次数（免费版 100,000 次/天）计费而非按字节限流，该响应头仅用于保证客户端 UI 正常识别与更新。

### 8. Loon / 客户端插件测不出节点网络质量与入口/落地地区不一致解析
- **入口与落地不一致根因**：
  * **入口 (Entry)**：由客户端配置连接的 CDN 优选 IP 决定（如香港 Anycast 节点）。
  * **落地 (Exit)**：由 Cloudflare 骨干网边缘计算调度或配置的 `PROXYIP` 出口所在机房（如美西、新加坡）决定。
- **Loon 测速/质量检测插件失败根因**：
  1. **UDP 协议受限**：Loon 质量插件（STUN、NAT 类型、丢包率）依赖裸 UDP 数据包。Cloudflare Worker 仅支持 TCP 上的 WebSocket 封装，UDP 仅限 53 端口 DNS 转 DoH，其余 UDP 探测直接被 Worker 静默断开。
  2. **0-RTT 早期数据与超时机制**：Loon 快速并发探测超时阈值极短（500ms~1000ms），CF Worker 的多段式路由调度握手偶尔被插件判定为超时。

### 9. CF 优选 CDN 前端 + 独立海外 VPS 原生落地（死机复活与纯净出口混合架构）
- **适用场景**：海外 VPS（如 RackNerd 5TB）被 GFW 阻断 IP/端口，或需要纯净住宅/机房 IP 出口且避免 CF 验证码。
- **实施标准**：
  1. **Cloudflare DNS**：添加二级域名（如 `la.example.com`）指向 VPS 真实 IP，开启**橙色小云朵（`proxied: true`）**。
  2. **VPS 端**：配置 Xray/Sing-box 监听 Cloudflare 支持的 HTTPS 端口（如 `2053`，带自签证书）或 HTTP 端口（如 `2052`），协议为 `VLESS + WebSocket`（Path: `/lemon-vless`）。
  3. **客户端配置**：连接地址（Address）填 CF 优质 Anycast 优选 IP（如香港/美西 86ms），伪装域名（Host/SNI）填 `la.example.com`，端口填 `2053`（TLS=true）。
  4. **效果**：客户端到 CF 走极速 Anycast 光纤，CF 到 VPS 走海外无阻断链路，目标网站识别出的访问者为 VPS 独立原生 IP。

### 10. NAT 小鸡 / 特殊节点在订阅解析中的格式陷阱（SOCKS5 vs Shadowsocks SIP002）
- **陷阱**：裸 SOCKS5 节点（`socks://...`）虽然可直连，但大多数主流订阅客户端（Loon、Clash、Shadowrocket、Sing-box）在拉取 Base64 订阅时，会自动将裸 `socks://` 识别为本地非加密代理而予以过滤忽略。
- **最佳实践**：在 NAT VPS（如 Alpine LXC）上使用 Sing-box / Xray 暴露标准的 **Shadowsocks（SIP002 标准，如 `aes-128-gcm` 或 `2022-blake3-aes-128-gcm`）**，订阅格式输出为：
  ```text
  ss://base64(aes-128-gcm:password)@ip:port#URL_ENCODED_REMARK
  ```
  该格式能被全平台客户端 100% 自动解析并在订阅列表中展示与测速。
