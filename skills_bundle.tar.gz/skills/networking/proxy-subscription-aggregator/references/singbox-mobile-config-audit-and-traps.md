# Sing-box 移动端与透明代理配置审计与避坑指南

本文档总结 Sing-box（1.10+ / 1.14+ 规范）在移动端（Android DSH Mobile / Box4Magisk / iOS 等）及透明代理环境中的核心架构模式、配置审计清单与高频暗坑。

---

## 一、出站组与 Provider 节点展开陷阱

### 1. Selector 漏配 `use_all_providers` 导致子节点消失
* **现象**：在 Web 面板（如 Zashboard / Yacd）或客户端 UI 中打开地区选择器（如 `🇭🇰 HK`、`🇯🇵 JP`），仅能看到嵌套的 `Auto` 组，无法看到并手动挑选该地区的任何单个节点。
* **原因**：Sing-box 中，当出站类型为 `selector` 时，`include` 正则筛选器默认只对当前出站定义的 `outbounds` 列表生效。如果未显式声明 `"use_all_providers": true` 或 `"providers": ["..."]`，Sing-box **不会主动拉取** 订阅源中的节点填入该 Selector。
* **错误写法**：
  ```json
  {
    "type": "selector",
    "tag": "🇭🇰 HK",
    "outbounds": ["🇭🇰 HK Auto"],
    "include": "(?i)(🇭🇰|香港|HK|hk)"
  }
  ```
* **正确写法**：
  ```json
  {
    "type": "selector",
    "tag": "🇭🇰 HK",
    "outbounds": ["🇭🇰 HK Auto"],
    "use_all_providers": true,
    "include": "(?i)(🇭🇰|香港|HK|hk)"
  }
  ```

### 2. 幽灵测速组（Orphan Outbound）白耗电量与带宽
* **现象**：配置中定义了某些高频 `urltest` 组（如 `🛰️ 中转服务`，`interval: 1m`），但在全局出口（如 `📦 ALL`）和全量路由规则（`route.rules`）中均未被引用。
* **危害**：Sing-box 会在后台依照 `interval` 持续对该组内全部节点向目标测速 URL 发起探活连接。手机端在移动网络下会导致持续唤醒、严重增加耗电与后台流量消耗。
* **审计方法**：遍历所有 `outbounds` 的 `tag`，核对是否存在既未出现在任何路由规则 `outbound` 字段、也未嵌套在其他 `selector` / `urltest` 的 `outbounds` 列表中的标签。

---

## 二、DNS 与 Fake-IP 架构设计

### 1. `evaluate` 动作引发的 Fake-IP 延迟退化
* **设计意图**：部分模板为了捕获“不在公共中国大陆域名列表（`cn_domain`）内的冷门国内网站”，会在 DNS 规则中对未命中域名的 `A` / `AAAA` 请求先执行 `action: evaluate, server: PROXY`。如果解析返回的真实 IP 命中 `cn_ip`，则重定向回国内 DNS 解析，否则落入 `fake-ip-resolver`。
* **现实代价**：
  - Fake-IP 的最大优势在于**本地 0ms 合成即时响应**，由核心在后续握手时通过嗅探到的域名向代理节点发起建连。
  - 在 Fake-IP 前置 `evaluate` 会强迫**每一个外网请求都必须先走远程代理节点做一次完整的远程 DNS 解析**。一旦当前代理节点偶发丢包、高延迟或断流，移动端所有应用的域名解析会集体出现明显首包卡顿甚至假死。
* **优化策略**：
  - 移动端日常使用建议优先将 `fake-ip-resolver` 前置给通用规则；对已知特殊直连需求通过 `fakeip_filter`、`private_domain` 及 `cn_domain` 精准白名单分流。

### 2. 公共模板残留硬编码 NextDNS Profile
* **风险**：配置模板直接写死他人私有 NextDNS 配置 ID（例如 `path: "/55eb44"`）。
* **后果**：NextDNS 免费计划每月仅 30 万次请求，超额后会降级甚至阻断；且流量受到他人控制台规则（广告拦截、安全规则、甚至域名黑白名单）的不可控影响。自用配置应替换为官方 DoH（Cloudflare/Google/阿里/DNSPod）或自己的私有 Profile ID。

---

## 三、Android 客户端与沙盒环境路径

### 1. 跨沙盒数据路径导致 `Permission Denied`
* **常见冲突**：日志输出 `log.output` 指向 `app.dsh.mobile`（DSH 客户端），而缓存数据库 `cache_file.path` 指向 `/data/data/com.boxproxy.box/files/box/sing-box/cache.db`（Box4Magisk 路径）。
* **避坑**：
  - 非 Root 环境下，Android 严格隔离各应用私有目录，跨包名写入必然抛出权限异常崩溃。
  - 配置生成或导出时，缓存文件路径建议使用相对于工作目录的相对路径（如 `./cache.db`），或由客户端启动参数统一注入，避免静态写死绝对路径。

### 2. eBPF 内核旁路与国内 IP 绕过
* 配置 `ebpf` 入站时，声明 `bypass_rule_set: ["cn_ip"]` 可以在 Linux 内核层将国内流量直接 bypass，不经过用户态 sing-box 进程，吞吐量高、发热极低。
* 需确保系统内核版本满足 eBPF 要求（通常为 Android GKI 5.10+ / 5.15+），并在 `route.rules` 首部配置 `action: sniff` 与 `hijack-dns`，保证本地 DNS 劫持生效。

---

## 四、应用包名规则（Package Name）与自建服务冲突

* **冲突场景**：在路由规则中使用 `package_name` 对特定 App（如 SenPlayer `com.mountains.hills`、AfuseKt `com.attempt.afusekt` 等）强制绑定分流到代理分组 `📺 Emby`。
* **避坑**：
  - 当使用者搭建有私有反代、自建 Emby 节点或 CDN 优选面板（如 Cloudflare 反代域名）时，该域名的流量不会被识别为国内 IP。
  - 由于 App 包名规则优先级通常高于通用域名规则，该播放器的所有视频播放流会被全量塞进海外代理节点，耗尽机场流量并受限带宽。
  - **规范做法**：必须在 `package_name` 规则**上方**，优先插入自建服务的直连规则（如 `domain_suffix: ["586934.xyz"] -> DIRECT`），确保个人自建媒体流不被应用规则无脑劫持。
