#!/usr/bin/env python3
"""Monitor hub 健康检查（只读）。

用法（在 hub 机上执行，需要读 /opt/monitor/data/monitor.db 的权限）：
    sudo python3 hub_health.py
    ssh vps-la 'sudo python3 -' < scripts/hub_health.py

输出：每台节点的心跳延迟、最新指标、累计流量；以及是否有 node 缺 traffic 行
（缺 traffic 行 = 面板收不到该节点数据，hub 日志会刷 "Query returned no rows"）。
"""
import sqlite3
import sys
import time

DB = "/opt/monitor/data/monitor.db"


def main(db=DB):
    c = sqlite3.connect(db)
    now = int(time.time())
    print(f"采样时间(UTC): {time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime(now))}  epoch={now}")
    print("-" * 78)

    bad = []
    rows = list(c.execute("SELECT id,name,hostname,agent_version FROM node ORDER BY sort,id"))
    for nid, name, hostname, ver in rows:
        ls = c.execute("SELECT last_seen FROM node WHERE id=?", (nid,)).fetchone()[0] or 0
        m = c.execute(
            "SELECT ts,cpu,mem_used FROM metric WHERE node_id=? ORDER BY ts DESC LIMIT 1", (nid,)
        ).fetchone()
        t = c.execute(
            "SELECT boot_id,total_rx,total_tx FROM traffic WHERE node_id=?", (nid,)
        ).fetchone()
        heartbeat = now - int(ls) if ls else -1
        metric_age = now - int(m[0]) if m else -1
        mem_mib = round((m[2] or 0) / 1048576) if m else 0
        rx = round((t[1] or 0) / 1048576) if t else 0
        tx = round((t[2] or 0) / 1048576) if t else 0
        flag = ""
        if not t:
            flag = "  ❌ 缺 traffic 行（数据会被 hub 丢弃）"
            bad.append(name)
        elif heartbeat < 0 or heartbeat > 60:
            flag = "  ⚠️ 心跳超时"
            bad.append(name)
        elif metric_age < 0:
            flag = "  ⚠️ 无指标"
            bad.append(name)
        print(
            f"{name:16s} v{ver:<6s} 心跳 {heartbeat:>5}s前  指标 {metric_age:>4}s前  "
            f"CPU {(m[1] if m else 0):5.1f}%  Mem {mem_mib:>5}MiB  流量↓{rx}MiB ↑{tx}MiB{flag}"
        )

    print("-" * 78)
    print(f"节点数 {len(rows)}，异常 {len(bad)} 台" + (f"：{', '.join(bad)}" if bad else "，全部正常"))
    return 0 if not bad else 1


if __name__ == "__main__":
    sys.exit(main(*sys.argv[1:2]))
