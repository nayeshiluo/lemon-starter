---
name: monitor-hub-ops
description: "自建 Monitor 面板加节点、补 traffic 行与退役。"
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux]
metadata:
  hermes:
    tags: [monitor, monitor-hub, monitor-agent, sqlite, node-onboarding, self-hosted-panel, la-vps]
    related_skills: [nezha-ops, aws-ec2-ops, proxy-node-connectivity]
---

# 自建 Monitor 面板（monitor-hub / monitor-agent）运维手册

## When to Use
- 要给某台机器“加入监控面板 / 加入探针”而这台面板是自建的 **Monitor**（不是哪吒、不是 Komari）；
- 面板显示某节点在线但**没有 CPU/内存/流量曲线**，hub 日志刷 `sent an unusable message: Query returned no rows`；
- 需要给无 root 权限的机器（云沙箱、容器、共享机）装监控 agent；
- 退役/迁移一套监控、避免动错对象。

⚠️ **先确认是哪一套面板**。爸爸环境里曾同时存在两套，节点名完全不同，极易查错对象：
| 面板 | 地址 | 特征 |
|---|---|---|
| **Monitor（唯一在用）** | `https://la.<PRIVATE_IDENTIFIER>:2096` | 自研 hub，Go 二进制，SQLite，节点名如“洛杉矶VPS / AWS / 香港net / 屌毛 VPS” |
| 哪吒 Nezha（已退役） | `<PRIVATE_IDENTIFIER>:34474` | v1 dashboard + nezha-agent，节点名如“🇭🇰 香港 Hytron NAT / 🇺🇸 洛杉矶 RackNerd / 🇸🇬 AWS 主控实例” |

用户说“我的四台机器在探针里”时，先用两边的节点清单对照，别默认是最近提到的那套。

---

## 架构（实测）

```
[洛杉矶 VPS <PRIVATE_IDENTIFIER>]
  ├─ monitor-hub.service   /opt/monitor/monitor-hub
  │    --listen 127.0.0.1:28080 --db /opt/monitor/data/monitor.db --site https://la.<PRIVATE_IDENTIFIER>:2096
  │    User=monitor, ProtectSystem=strict, ReadWritePaths=/opt/monitor/data, MemoryMax=256M
  │    nginx 反代 0.0.0.0:2096 → 127.0.0.1:28080
  └─ monitor-agent.service  /opt/monitor/monitor-agent --interval 2（EnvironmentFile=/opt/monitor/agent.env）

[各节点]  monitor-agent --server https://la.<PRIVATE_IDENTIFIER>:2096 --token <node token> --interval N
```

- hub 二进制里可读到的路由：`/api/agent/ws`、`/api/agent/register`、`/install.sh`、`/agent/{arch}/`、`/api/nodes`、`/api/nodes/{id}/token`、`/api/ws`、`/api/auth/login`、`/api/register-window`、`/api/db/{backup,restore,vacuum}`
- 管理员密码存在 `setting.admin_password_hash`，**argon2id 哈希、不可逆**（不是 bcrypt，别照哪吒的 bcrypt 套路重置）
- `setting.register_key` + `setting.register_until`：注册窗口。`register_until=0` 表示关闭，agent 无法自注册

---

## 数据库表（`/opt/monitor/data/monitor.db`）

| 表 | 关键列 |
|---|---|
| `node` | `id,name,token,sort,public,price,currency,billing_cycle,expires_at,remark,traffic_limit,traffic_mode,traffic_reset_day,hostname,os,kernel,arch,virt,cpu_name,cpu_cores,mem_total,swap_total,disk_total,agent_version,ip,ipv4,ipv6,country,last_seen,notify,down_since,created_at` |
| `traffic` | `node_id,boot_id,last_rx,last_tx,total_rx,total_tx,month_rx,month_tx,month_start,day_rx,day_tx,day_start` |
| `metric` | `node_id,ts,cpu,mem_used,swap_used,disk_used,net_rx,net_tx,tcp,udp,procs` |
| `setting` | `key,value` |
| `ping_task` / `ping_node` / `ping_record` / `session` | 延迟任务与登录会话 |

`node.token`：1.0.0 时代是 **64 位 hex**（`secrets.token_hex(32)`）。库里出现过 43 字符的 `wy_J...`（1.1.0 节点），说明新旧 token 格式不同，生成时沿用 64 hex 最稳。

---

## 加一台新节点：完整顺序（含最关键的坑）

### 坑 0：只插 `node` 行 → 面板永远收不到数据
hub 收到 agent 上报后要按 **`(node_id, boot_id)`** 去 `traffic` 表查行，查不到就丢弃整条消息，日志每 interval 刷一次：

```
WARN monitor_hub::agent_ws: node 5 sent an unusable message: Query returned no rows
```

表现极具误导性：`node` 表里 `hostname/os/cpu_cores/mem_total` 都已被填好（说明 agent 确实连上了、握手成功），但 `last_seen` 一直是 0、`metric` 表零行、面板上看不到这台。

**`boot_id` 的取值规则（已用实机比对验证）**：1.0.0 agent 上报的是机器原始 `/proc/sys/kernel/random/boot_id`
（洛杉矶 VPS 的 boot_id `c5e4424d-…` 与 `traffic` 里 node 1 的 `boot_id` 完全一致）。
1.1.0 节点出现过 `b32e3588-…/914a7c605db06d18` 这种 `boot_id/machine_id` 拼接格式 —— 若目标机 agent 是 1.1.0，先用 `cat /proc/sys/kernel/random/boot_id; cat /etc/machine-id` 两段都取，拼 `/` 试；不确定时优先装与 hub 同版本的 1.0.0。

### 步骤
```bash
# ① 取目标机 boot_id
ssh <target> 'cat /proc/sys/kernel/random/boot_id'

# ② 在 hub 机建 node 行 + 立刻补 traffic 行（token 用 64 hex）
ssh vps-la 'sudo python3 - <<"PY"
import sqlite3,secrets,time
tok=secrets.token_hex(32)
c=sqlite3.connect("/opt/monitor/data/monitor.db")
cur=c.execute("""INSERT INTO node (name,token,sort,public,currency,billing_cycle,notify,created_at)
                 VALUES (?,?,?,?,?,?,?,?)""",
 ("🖥️ 机器名",tok,4,0,"CNY","monthly",1,int(time.time())))
c.execute("""INSERT INTO traffic (node_id,boot_id,last_rx,last_tx,total_rx,total_tx,month_rx,month_tx,month_start,day_rx,day_tx,day_start)
             VALUES (?,?,0,0,0,0,0,0,date(\"now\",\"start of month\"),0,0,date(\"now\"))""",
 (cur.lastrowid, "<boot_id>"))
c.commit(); print("node id", cur.lastrowid, tok)
PY'

# ③ 部署 agent（非 root 机器见下一节），再跑 scripts/hub_health.py 验证
```

`public=0` 对访客隐藏（“屌毛 VPS”就是 `public=0`）；`sort` 决定面板顺序。

---

## 无 root 机器部署 agent（云沙箱 / 容器 / 共享机）

InstaBox 这类沙箱：`sudo` 写入会被安全确认拦，但 `loginctl` 显示 `Linger=yes`、`systemctl --user is-system-running` 为 `running`，用**用户级 systemd** 完全够用：

```bash
mkdir -p ~/monitor-agent && install -m 755 monitor-agent ~/monitor-agent/monitor-agent
printf 'MONITOR_SERVER=https://la.<PRIVATE_IDENTIFIER>:2096\nMONITOR_TOKEN=<token>\n' > ~/monitor-agent/agent.env
chmod 600 ~/monitor-agent/agent.env
printf '#!/bin/sh\nset -a\n. "$HOME/monitor-agent/agent.env"\nset +a\nexec "$HOME/monitor-agent/monitor-agent" --server "$MONITOR_SERVER" --token "$MONITOR_TOKEN" --interval 2\n' > ~/monitor-agent/run.sh
chmod 700 ~/monitor-agent/run.sh
```
`~/.config/systemd/user/monitor-agent.service`：
```ini
[Unit]
Description=Monitor Agent (Lemon panel)
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
WorkingDirectory=%h/monitor-agent
ExecStart=%h/monitor-agent/run.sh
Restart=always
RestartSec=5
StandardOutput=append:%h/monitor-agent/agent.log
StandardError=append:%h/monitor-agent/agent.log

[Install]
WantedBy=default.target
```
```bash
systemctl --user daemon-reload && systemctl --user enable --now monitor-agent
```
token 放 `agent.env`（600）+ `run.sh`（700），**不要写进 unit 文件**（unit 可被任意用户读）。

二进制跨机传输（两台机器之间没有互信时的稳妥做法）：
```bash
ssh hub 'sudo base64 -w0 /opt/monitor/monitor-agent' > /tmp/ma.b64
base64 -d /tmp/ma.b64 > /tmp/monitor-agent && chmod +x /tmp/monitor-agent
scp /tmp/monitor-agent <target>:/tmp/
```

---

## 验证（必须做，别只看 `connected`）

agent 日志只打 `connected` 就代表握手成功，**不代表数据入库**。以 hub 库为准，跑 `scripts/hub_health.py`（放在 hub 机上 `sudo python3` 执行）：
```bash
ssh vps-la 'sudo python3 -' < scripts/hub_health.py
```
合格标准：
- 每台 `last_seen` 距今 < 60 秒；
- `metric` 表有该 node 的最新行（hub 约每 30 秒落一行，不是每 interval 一行，看到 30 秒前的行是正常的）；
- 近 30 秒 `journalctl -u monitor-hub | grep -c unusable` = 0。

---

## 退役 / 迁移

哪吒那类 OpenRC 服务退役（保留数据、可回滚）：
```bash
cd /opt/nezha/dashboard/data && cp -a sqlite.db sqlite.db.bak-retire-$(date +%Y%m%d_%H%M%S)
rc-service nezha-agent stop;  rc-update del nezha-agent default
rc-service nezha-dashboard stop; rc-update del nezha-dashboard default
# 复核：进程 0 / 端口不监听 / rc-update show 无条目 / 外网端口 nc 已关闭
```
- `rc-service <svc> stop` 报 `failed to stop` **不等于没停**：pidfile 残留、进程已退时就会这样。必须再用 `ps` + `ss` 复核，别据此重试或回滚。
- 退役前后都要跑一次 Monitor 面板健康检查，确认被退役机器上的 `monitor-agent` 没被误伤（同一台机可能同时是 Monitor 的节点）。

---

## 通用坑

1. **改数据库的写操作会触发 Hermes 安全确认弹窗**：`sqlite3 INSERT/UPDATE`、`python3 -c` 里执行 INSERT 都会被拦，返回 `BLOCKED: Command timed out without user response`。这不是命令写错，是**等人点「允许」**（约 5 分钟超时）。处理方式：直接告诉用户“弹窗会出现在你那边，请点允许”，然后**原样重发一次**，不要改写成别的实现去绕过（绕过视为规避授权）。只读查询（SELECT / PRAGMA）不会触发。
2. **`pkill -f "<含自身命令行的关键字>"` 会自杀**：`pkill -f "user-data-dir=/tmp/cprof1"` 会匹配到承载该命令的 `bash -c`，整个 SSH 会话被切断、后续命令全不执行（表现为输出为空）。改用精确 PID（`kill <pid>`）或 `pkill -f "[n]ezha-agent"` 括号规避。
3. **Alpine 的 `ps` 不支持 `-o cmd`**，用 `-o args`。
4. **别把“机器在跑”当成“在监控里”**：`diaomao` 那台机器健康运行 6 天，但从未装 agent，所以面板里没有它。判断节点是否接入，看库里 `node` 行 + `last_seen`，不看机器是否在线。
5. **不要用 `updated_at` / `created_at` 判断存活**，唯一可信的是 `last_seen` 与 `metric.ts`。
