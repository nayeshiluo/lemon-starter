#!/usr/bin/env python3
"""
Nezha Probe Status Checker via WebSocket
"""
import sys
import asyncio
import json
from datetime import datetime, timezone

try:
    import websockets
except ImportError:
    print("Error: 'websockets' library is required. Install via pip or run in venv.")
    sys.exit(1)

async def probe_nezha(host="45.196.236.222", port=34474):
    uri = f"ws://{host}:{port}/api/v1/ws/server"
    print(f"Connecting to Nezha WebSocket: {uri} ...")
    try:
        async with websockets.connect(uri, open_timeout=5) as ws:
            msg = await asyncio.wait_for(ws.recv(), timeout=5)
            data = json.loads(msg)
            servers = data.get("servers", [])
            print(f"Found {len(servers)} servers reporting to Dashboard:\n" + "=" * 60)
            now_utc = datetime.now(timezone.utc)
            for s in servers:
                name = s.get("name", "Unknown")
                srv_id = s.get("id")
                last_active_str = s.get("last_active", "")
                state = s.get("state", {})
                cpu = state.get("cpu", 0.0)
                mem = state.get("mem_used", 0) / (1024 * 1024)
                load1 = state.get("load_1", 0.0)
                
                status_icon = "🔴"
                diff_sec = -1
                if last_active_str:
                    try:
                        # ISO 8601 parsing
                        cleaned = last_active_str.split(".")[0] + "Z"
                        dt = datetime.strptime(cleaned, "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=timezone.utc)
                        diff_sec = (now_utc - dt).total_seconds()
                        if diff_sec <= 10:
                            status_icon = "🟢"
                        elif diff_sec <= 60:
                            status_icon = "🟡"
                    except Exception:
                        pass
                
                print(f"{status_icon} [ID: {srv_id}] {name}")
                print(f"   Last Active: {last_active_str} ({diff_sec:.1f}s ago)")
                print(f"   Metrics    : CPU {cpu:.1f}% | Mem {mem:.1f}MB | Load {load1}")
                print("-" * 60)
    except Exception as e:
        print(f"Failed to probe Nezha WebSocket: {e}")
        sys.exit(2)

if __name__ == "__main__":
    h = sys.argv[1] if len(sys.argv) > 1 else "45.196.236.222"
    p = int(sys.argv[2]) if len(sys.argv) > 2 else 34474
    asyncio.run(probe_nezha(h, p))
