---
name: nezha-ops
description: "哪吒探针运维与排障：Dashboard/Agent配置、NAT穿透、Alpine OpenRC自启与WS自检。"
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux]
metadata:
  hermes:
    tags: [nezha, monitoring, probe, alpine, openrc, agent, dashboard, nat-vps]
    related_skills: [aws-ec2-ops, telegram-ops-bot, proxy-node-connectivity]
---

# 哪吒监控探针运维与排障手册 (Nezha Monitoring Ops)

## When to Use
- 哪吒探针面板显示某节点“离线/掉线”或无法上报监控指标；
- 维护部署在 Alpine Linux (LXC) 或 NAT VPS 上的 Nezha Dashboard / Agent；
- 需要无头/脚本化验证哪吒探针面板真实在线状态（通过 WebSocket）；
- 配置 OpenRC 或 Systemd 守护进程、自启动与双重配置兜底。

---

## 核心架构与节点拓扑

```
[🇭🇰 香港 Hytron NAT 小鸡 (Alpine LXC)]
  ├─ Nezha Dashboard (监听 8088，公网映射 34474)
  │    └─ SQLite DB (/opt/nezha/dashboard/data/sqlite.db)
  ├─ 本机 Agent (上报 127.0.0.1:8088，UUID: e3ba469f-...)
  └─ OpenRC 管理 (nezha-dashboard, nezha-agent)

[🇺🇸 洛杉矶 RackNerd (Ubuntu KVM)]
  └─ Nezha Agent (上报 45.196.236.222:34474) ──▶ Systemd 管理

[🇸🇬 AWS 主控实例 (Ubuntu EC2)]
  └─ Nezha Agent (上报 45.196.236.222:34474) ──▶ Systemd 管理
```

---

## 排障标准链路（单步只读先行）

1. **网络连通性只读探测**：
   ```bash
   # 测试 Dashboard 对外通信端口（如 NAT 映射端口 34474）与 SSH (如 30023)
   nc -zv -w 3 <IP> <PORT>
   ping -c 3 -W 2 <IP>
   ```
2. **确认目标机器运行与进程状态**：
   - 检查 uptime 确认是否近期发生过宿主机维护或重启。
   - 检查进程 `ps aux | grep nezha`，区分是 `dashboard` 掉了还是 `agent` 掉了。
3. **检查自启动运行级别**：
   - **Alpine (OpenRC)**：`rc-update show | grep nezha`
   - **Ubuntu/Debian (Systemd)**：`systemctl is-enabled nezha-agent`

---

## Alpine Linux (OpenRC) 核心避坑指南

### 1. `command_args` 空格无引号导致参数丢失与权限拒绝（必踩致命坑）
- **故障现象**：
  OpenRC 启动脚本 `/etc/init.d/nezha-agent` 启动时报错：
  `/usr/libexec/rc/sh/openrc-run.sh: /etc/init.d/nezha-agent: line X: /opt/nezha/agent_config.yml: Permission denied`
  随后 Agent 启动后立即退出，面板显示节点离线。
- **根因机理**：
  OpenRC-run 脚本在 source service 文件时，若写为：
  `command_args=-c /opt/nezha/agent_config.yml`（未加双引号）
  Shell 解析会将第 2 个参数 `/opt/nezha/agent_config.yml` 当作可执行命令去执行，触发 `Permission denied`，导致 `command_args` 变量被置空！
  此时 `supervise-daemon` 启动 Agent 时不带任何参数，Agent 默认去加载同目录下的空模板配置（`client_secret=""`），认证失败退出。
- **正确规范**：
  必须为 `command_args` 及路径加上双引号：
  ```bash
  #!/sbin/openrc-run
  name="nezha-agent"
  supervisor="supervise-daemon"
  command="/opt/nezha/nezha-agent"
  command_args="-c /opt/nezha/agent_config.yml"

  depend() {
      need net
  }
  ```
- **双重兜底准则**：
  无论是否带 `-c` 参数，同时将正确配置同步复制一份到默认路径 `/opt/nezha/config.yml`，即使参数传丢也能作为保底正常工作：
  ```bash
  cp /opt/nezha/agent_config.yml /opt/nezha/config.yml
  ```

### 2. OpenRC 必须显式注册开机自启
- Alpine 不会自动为 `/etc/init.d/` 下的脚本启用开机自启。
- 必须显式执行：
  ```bash
  rc-update add nezha-agent default
  rc-update add nezha-dashboard default
  ```

---

## 哪吒探针 v1 实时状态探测规范 (WebSocket 无头自检)

哪吒 v1/v2 探针面板的服务器列表与实时指标（CPU、内存、网络、活跃时间戳）不依赖 REST API（`/api/v1/server` 通常 401 鉴权拦截），而是通过公开的 **WebSocket 接口** 实时广播。

### 自动化探测脚本（100% 验证节点在线真实证据）
技能内置可直接复用的探针脚本：`scripts/probe_nezha_status.py`（支持 `python3 scripts/probe_nezha_status.py [HOST] [PORT]`，彩色直观输出各节点延迟与指标）。

在主控机也可直接执行单行 Python 脚本快速验证面板全节点健康度：

```python
import asyncio
import websockets
import json

async def check_nezha_nodes(host, port):
    uri = f"ws://{host}:{port}/api/v1/ws/server"
    async with websockets.connect(uri, open_timeout=5) as ws:
        msg = await asyncio.wait_for(ws.recv(), timeout=5)
        data = json.loads(msg)
        for s in data.get("servers", []):
            name = s.get("name")
            last_active = s.get("last_active")
            state = s.get("state", {})
            print(f"[{name}] Last Active: {last_active} | CPU: {state.get('cpu'):.1f}% | Load: {state.get('load_1')}")

asyncio.run(check_nezha_nodes("45.196.236.222", 34474))
```

**判定铁证**：
- `last_active` 时间戳与当前 UTC 时间差距在 1~3 秒以内；
- `state` 字典内能获取到真实的实时 CPU、负载及网速指标。

---

## NAT 小鸡与资源受限环境准则

1. **低内存防 OOM (Out-of-Memory)**：
   - Alpine NAT 小鸡内存极小（常为 128MB ~ 1GB，且带 Swap）。
   - **严禁**在小鸡上用 Python 一次性全量 `read()` 几十 MB 的二进制文件或安装重型分析包，会导致 OOM 退出（Exit Code 255）。
   - 优先通过外部 SSH 只读管道或轻量 shell 工具（`grep`, `head`, `sqlite3` 精确查询）排查。
2. **NAT 端口穿透对应关系**：
   - 始终区分**内网监听端口**与**公网映射端口**。
   - 例：Dashboard 内网监听 `8088`，公网入口为 `34474`。本机 Agent 上报写 `127.0.0.1:8088`，外部节点 Agent 上报写 `<NAT_IP>:34474`。
