---
name: nezha-ops
description: "哪吒探针运维与排障：Dashboard/Agent配置、NAT穿透、Alpine OpenRC自启与WS自检。"
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux]
metadata:
  hermes:
    tags: [nezha, monitoring, probe, alpine, openrc, agent, dashboard, nat-vps]
    related_skills: [aws-ec2-ops, telegram-ops-bot, proxy-node-connectivity]
---

# 哪吒监控探针运维与排障手册 (Nezha Monitoring Ops)

> ⚠️ **先分清两套监控，别查错对象**：爸爸环境里自建 **Monitor 面板**（`https://la.<PRIVATE_IDENTIFIER>:2096`，节点名“洛杉矶VPS / AWS / 香港net / 屌毛 VPS”）才是唯一在用的监控，运维见 `monitor-hub-ops` 技能。
> 哪吒（`<PRIVATE_IDENTIFIER>:34474`，节点名“🇭🇰 香港 Hytron NAT / 🇺🇸 洛杉矶 RackNerd / 🇸🇬 AWS 主控实例”）已于 2026-10-23 按用户要求退役：`rc-service stop` + `rc-update del` 两个服务，`/opt/nezha/` 数据与 `sqlite.db.bak-retire-*` 保留可回滚。
> 用户说“我的机器在探针里”时，**先用两边节点清单对照**再动手（曾因查错面板，把用户说的“四台”当成另一套的三台）。本手册保留用于历史排障或将来重建。

## When to Use
- 哪吒探针面板显示某节点“离线/掉线”或无法上报监控指标；
- 维护部署在 Alpine Linux (LXC) 或 NAT VPS 上的 Nezha Dashboard / Agent；
- 需要无头/脚本化验证哪吒探针面板真实在线状态（通过 WebSocket）；
- 配置 OpenRC 或 Systemd 守护进程、自启动与双重配置兜底。

---

## 核心架构与节点拓扑

```
[🇭🇰 香港 Hytron NAT 小鸡 (Alpine LXC)]
  ├─ Nezha Dashboard (监听 8088，公网映射 34474)
  │    └─ SQLite DB (/opt/nezha/dashboard/data/sqlite.db)
  ├─ 本机 Agent (上报 127.0.0.1:8088，UUID: e3ba469f-...)
  └─ OpenRC 管理 (nezha-dashboard, nezha-agent)

[🇺🇸 洛杉矶 RackNerd (Ubuntu KVM)]
  └─ Nezha Agent (上报 <PRIVATE_IDENTIFIER>:34474) ──▶ Systemd 管理

[🇸🇬 AWS 主控实例 (Ubuntu EC2)]
  └─ Nezha Agent (上报 <PRIVATE_IDENTIFIER>:34474) ──▶ Systemd 管理

[🖥️ InstaBox 代理浏览器沙箱 (Debian 13, 无 root)]
  └─ Nezha Agent (上报 <PRIVATE_IDENTIFIER>:34474) ──▶ systemd --user + Linger
  └─ 接入: ssh -p 2222 ibssh_<token>@ssh.instabox.sh（token 即用户名，免密钥）
  └─ 免费实例闲置 30 分钟 / 运行满 8 小时自动暂停，暂停期面板显示离线属正常
```

---

## 排障标准链路（单步只读先行）

1. **网络连通性只读探测**：
   ```bash
   # 测试 Dashboard 对外通信端口（如 NAT 映射端口 34474）与 SSH (如 30023)
   nc -zv -w 3 <IP> <PORT>
   ping -c 3 -W 2 <IP>
   ```
2. **确认目标机器运行与进程状态**：
   - 检查 uptime 确认是否近期发生过宿主机维护或重启。
   - 检查进程 `ps aux | grep nezha`，区分是 `dashboard` 掉了还是 `agent` 掉了。
3. **检查自启动运行级别**：
   - **Alpine (OpenRC)**：`rc-update show | grep nezha`
   - **Ubuntu/Debian (Systemd)**：`systemctl is-enabled nezha-agent`

---

## Alpine Linux (OpenRC) 核心避坑指南

### 1. `command_args` 空格无引号导致参数丢失与权限拒绝（必踩致命坑）
- **故障现象**：
  OpenRC 启动脚本 `/etc/init.d/nezha-agent` 启动时报错：
  `/usr/libexec/rc/sh/openrc-run.sh: /etc/init.d/nezha-agent: line X: /opt/nezha/agent_config.yml: Permission denied`
  随后 Agent 启动后立即退出，面板显示节点离线。
- **根因机理**：
  OpenRC-run 脚本在 source service 文件时，若写为：
  `command_args=-c /opt/nezha/agent_config.yml`（未加双引号）
  Shell 解析会将第 2 个参数 `/opt/nezha/agent_config.yml` 当作可执行命令去执行，触发 `Permission denied`，导致 `command_args` 变量被置空！
  此时 `supervise-daemon` 启动 Agent 时不带任何参数，Agent 默认去加载同目录下的空模板配置（`client_secret=""`），认证失败退出。
- **正确规范**：
  必须为 `command_args` 及路径加上双引号：
  ```bash
  #!/sbin/openrc-run
  name="nezha-agent"
  supervisor="supervise-daemon"
  command="/opt/nezha/nezha-agent"
  command_args="-c /opt/nezha/agent_config.yml"

  depend() {
      need net
  }
  ```
- **双重兜底准则**：
  无论是否带 `-c` 参数，同时将正确配置同步复制一份到默认路径 `/opt/nezha/config.yml`，即使参数传丢也能作为保底正常工作：
  ```bash
  cp /opt/nezha/agent_config.yml /opt/nezha/config.yml
  ```

### 2. OpenRC 必须显式注册开机自启
- Alpine 不会自动为 `/etc/init.d/` 下的脚本启用开机自启。
- 必须显式执行：
  ```bash
  rc-update add nezha-agent default
  rc-update add nezha-dashboard default
  ```

---

## 哪吒探针 v1 实时状态探测规范 (WebSocket 无头自检)

哪吒 v1/v2 探针面板的服务器列表与实时指标（CPU、内存、网络、活跃时间戳）不依赖 REST API（`/api/v1/server` 通常 401 鉴权拦截），而是通过公开的 **WebSocket 接口** 实时广播。

### 自动化探测脚本（100% 验证节点在线真实证据）
技能内置可直接复用的探针脚本：`scripts/probe_nezha_status.py`（支持 `python3 scripts/probe_nezha_status.py [HOST] [PORT]`，彩色直观输出各节点延迟与指标）。

在主控机也可直接执行单行 Python 脚本快速验证面板全节点健康度：

```python
import asyncio
import websockets
import json

async def check_nezha_nodes(host, port):
    uri = f"ws://{host}:{port}/api/v1/ws/server"
    async with websockets.connect(uri, open_timeout=5) as ws:
        msg = await asyncio.wait_for(ws.recv(), timeout=5)
        data = json.loads(msg)
        for s in data.get("servers", []):
            name = s.get("name")
            last_active = s.get("last_active")
            state = s.get("state", {})
            print(f"[{name}] Last Active: {last_active} | CPU: {state.get('cpu'):.1f}% | Load: {state.get('load_1')}")

asyncio.run(check_nezha_nodes("<PRIVATE_IDENTIFIER>", 34474))
```

**判定铁证**：
- `last_active` 时间戳与当前 UTC 时间差距在 1~3 秒以内；
- `state` 字典内能获取到真实的实时 CPU、负载及网速指标。

---

## 哪吒 v1 关键实测事实（2026-10 复核）

1. **v1 不会自动注册未知 UUID 的 Agent（2026-10 实测纠正）**：Agent 用库里不存在的 `uuid` 连接时，Dashboard 只是接受连接、不建节点、不报错（面板里看不到、`servers` 表不增行）。
   → 因此**必须先有 `servers` 行**：要么在面板“添加节点”生成（新节点默认名字是随机英文名，如 `delicate-osprey`，`display_index=0`），要么直接 INSERT 一行。
   → 探针里出现陌生随机英文名的节点，通常是“面板里新建了但没改名”的节点，不是被入侵。
2. **面板机自己显示离线，先查 Agent 是否根本没装**：实测 `/opt/nezha/` 下只有 `config.yml` 和一个未解压的 `nezha-agent_linux_amd64.zip`、`/etc/init.d/nezha-agent` 不存在、`ps` 无进程 —— 配置全对但程序从没装上，面板只能显示零值离线（`last_active` 为零值时间）。修复就是解压 zip + 写 init 脚本 + 注册自启。
3. **Alpine 上 `ps -eo ... cmd` 不支持**：用 `args` 代替（`ps -eo pid,etime,args`），否则报 `bad -o argument 'cmd'`。
4. **`pkill -f "<关键字>"` 会自杀**：SSH 里执行 `pkill -f "nezha-agent -c ./config.yml"` 会匹配到承载这条命令的 `bash -c` 自身，整个会话被切断、后续命令全不执行（表现为命令返回空）。要么用 PID 杀，要么 `pkill -f "[n]ezha-agent"` 规避。
5. **无 root 权限机器（如 InstaBox 沙箱）用 systemd --user 装 Agent**：先确认 `loginctl show-user <u> | grep Linger` 为 `Linger=yes` 且 `systemctl --user is-system-running` 为 running，然后写 `~/.config/systemd/user/nezha-agent.service`（`ExecStart=%h/...`、`WantedBy=default.target`），`systemctl --user enable --now nezha-agent`。无需 sudo，且带 linger 时重启/暂停恢复后自动拉起。

## 面板改名 / 改属性：改完 DB 必须重启 Dashboard（2026-10-23 实测）

目标：把节点从随机名 `delicate-osprey` 改成规范名、调排序、隐藏给访客。可以直接改 SQLite，但有三条硬约束：

```bash
# 1) 先备份，再改
ssh vps-hk "cp /opt/nezha/dashboard/data/sqlite.db /opt/nezha/dashboard/data/sqlite.db.bak-\$(date +%Y%m%d-%H%M%S)"
ssh vps-hk "sqlite3 /opt/nezha/dashboard/data/sqlite.db \
  \"UPDATE servers SET name='🖥️ InstaBox 代理浏览器', display_index=4, hide_for_guest=1 WHERE id=4;\""
# 2) 必须重启 Dashboard，否则 WS 广播仍是旧值
ssh vps-hk 'rc-service nezha-dashboard restart'
```

1. **`servers` 表没有 `last_active` 列**：在线时间戳只存在 Dashboard 内存里。所以“DB 里改好了”≠“面板已生效”，WS 自检脚本才是唯一验收口径。
2. **改完不重启 Dashboard 完全无效**：WS 广播的名字/排序来自进程内存，DB 只是启动时的加载源。实测改完 name 后探针仍返回旧随机名，重启后才会变。
3. **`user_id` 必须等于管理员账号 id（本面板为 `1`）**：实测自动生成的节点行是 `user_id=0`，而 `users` 表只有 `id=1|admin`。`user_id=0` 的行在 Dashboard 重启后会**从 WS 列表里彻底消失**（不是离线，是根本不广播），DB 里查得到、TCP 连接也在。修法：
   ```sql
   SELECT id,name,user_id FROM servers ORDER BY id;   -- 对照 users 表
   UPDATE servers SET user_id=1 WHERE id=<N>;
   ```
   这条是排查“agent 连着、secret 一致、DB 有行，但面板就是不显示”的**首要嫌疑**，不要先去怀疑网络/MTU/secret。
4. **不要用 `DELETE` + 等自动注册来重建节点**：删行后重启 Agent，Dashboard 不会补建（自动注册只在 uuid 首次出现时触发，连接已在则不重放）。删了就真没了，只能回面板重新添加。

配套排查顺序（从便宜到贵，每步都只读）：
`WS 自检脚本看列不列` → `sqlite 查 user_id/name` → `ss -tn | grep <dashboard_ip>` 看 agent 是否 ESTAB → 比对 `agent_secret_key`(dashboard) 与 `client_secret`(agent) 哈希 → 最后才怀疑链路。

详细实测记录（含各项观测原始值）见 `references/dashboard-db-edits.md`。

## NAT 小鸡与资源受限环境准则

1. **低内存防 OOM (Out-of-Memory)**：
   - Alpine NAT 小鸡内存极小（常为 128MB ~ 1GB，且带 Swap）。
   - **严禁**在小鸡上用 Python 一次性全量 `read()` 几十 MB 的二进制文件或安装重型分析包，会导致 OOM 退出（Exit Code 255）。
   - 优先通过外部 SSH 只读管道或轻量 shell 工具（`grep`, `head`, `sqlite3` 精确查询）排查。
2. **NAT 端口穿透对应关系**：
   - 始终区分**内网监听端口**与**公网映射端口**。
   - 例：Dashboard 内网监听 `8088`，公网入口为 `34474`。本机 Agent 上报写 `127.0.0.1:8088`，外部节点 Agent 上报写 `<NAT_IP>:34474`。
