# Dashboard DB 改动实测记录（2026-10-23，香港 Hytron NAT 面板机）

场景：把 InstaBox 沙箱（探针里叫 `delicate-osprey`）改成规范名并纳入常规巡检。
结论先行：**改名本身没问题，坑在“改完必须重启 Dashboard”和 `user_id=0`**。

## 面板机事实

- Dashboard 内网 `8088`，公网映射 `34474`；进程名是 `dashboard-linux-amd64`（不是 `nezha-dashboard`，`ps | grep nezha-dashboard` 会空手）。
- 由 OpenRC 管：`rc-service nezha-dashboard {status,restart}`。
- **没有日志文件**：`/etc/init.d/nezha-dashboard` 里只有 `command_args`，没配 `output_log`；`/var/log/` 下无 nezha 相关。所以排障别指望日志，靠 WS 自检 + DB + `ss`。
- 配置键是 `agent_secret_key`（不是 `client_secret`）；Agent 侧才叫 `client_secret`。比对要拿这两个字段，直接 grep `client_secret` 会得到空值，误判成“secret 不一致”。

## `servers` 表结构（实测）

```
id, created_at, updated_at, user_id, name, uuid, note, public_note,
display_index, hide_for_guest, enable_d_dns, ddns_profiles_raw, override_ddns_domains_raw
UNIQUE(uuid)
```
**没有 `last_active` 列** —— 在线时间戳纯内存态，重启即丢，所以“DB 里没掉线信息”不代表节点没上报。

## 时间线（观测值，均为实际工具返回）

1. 改名前：`4|delicate-osprey|user_id=0|display_index=0|hide_for_guest=0`，WS 显示在线，CPU 0~1%，Mem 847~858MB。
2. 执行 `UPDATE ... name/display_index/hide_for_guest`，DB 立刻变成 `4|🖥️ InstaBox 代理浏览器|4|1`。
3. **WS 自检仍返回 `delicate-osprey`** → 证明广播走内存，DB 改动未生效。
4. 重启 Dashboard → WS 从 4 台掉成 3 台，ID 4 整行消失（不是显示离线，是不在 `servers` 数组里）。
5. Agent 侧检查全部正常：`systemctl --user is-active` = active、PID 未变、`ss -tn` 有到 `<PRIVATE_IDENTIFIER>:34474` 的 ESTAB（源端口 58276）、从沙箱 `curl http://<PRIVATE_IDENTIFIER>:34474/` 返回 200、TCP 与 MTU 探测（payload 1400）全通、`agent_secret_key` 与 `client_secret` sha256 完全一致（22 字符）。
6. 发现 `user_id=0` 与 `users` 表 `id=1|admin` 不符 → `UPDATE servers SET user_id=1`，重启 Dashboard → **仍是 3 台**。
7. 试 `DELETE` 该行 + 重启 Agent 触发自动注册 → 20 秒内 `servers` 表没有新行，节点彻底丢失。

第 6、7 步没解决显示问题，最终结论是：**这台沙箱节点需要回面板重新“添加节点”生成行**（或者接受它作为临时沙箱不进常驻面板）。所以：

- `user_id` 一致性是必要检查项，但**不是本次现象的唯一充分原因**，别把它写成万能修法。
- `DELETE` 重建是错误方向，已被证否。

## 复查用的只读命令

```bash
# WS 真相
python3 scripts/probe_nezha_status.py <PRIVATE_IDENTIFIER> 34474

# DB 元数据
ssh vps-hk "sqlite3 /opt/nezha/dashboard/data/sqlite.db \
  'SELECT id,name,user_id,display_index,hide_for_guest FROM servers ORDER BY id;'"
ssh vps-hk "sqlite3 /opt/nezha/dashboard/data/sqlite.db 'SELECT id,username FROM users;'"

# Agent 是否真连上（沙箱侧，注意 172.16.x 是沙箱内网）
ssh <agent_host> 'ss -tn | grep <PRIVATE_IDENTIFIER>; systemctl --user is-active nezha-agent'
```

## 复盘：本次真正该早做的两件事

1. 动手改 DB 前先跑一次 WS 自检并**记下当前 name**，作为“重启前后对照”，否则分不清是改名没生效还是节点掉了。
2. 面对“agent 连着但不显示”，排查顺序固定为：WS 列表 → `user_id` → ESTAB → secret 哈希 → 链路。本次先查了 MTU/NAT/secret，绕了一大圈。
