---
name: cf-node-ops
description: 提CF节点项目或edgetunnel时调用。部署与防封规范。
version: 1.0.0
author: 柠檬
license: MIT
metadata:
  hermes:
    tags: [cloudflare, edgetunnel, vless, proxy, networking, pages]
    related_skills: [proxy-node-connectivity, socks5-proxy-setup, emby-proxy-ops]
---

# Cloudflare 边缘计算代理节点（edgetunnel）运维与安全规范

## When to Use
当爸爸提到 **“CF节点项目”**、**“edgetunnel”**、**“CF翻墙节点”**、**“VLESS Pages/Workers”**，或需要部署、复刻、升级、排查基于 Cloudflare 平台的边缘代理隧道时，调用本技能。

---

## ⚠️ 铁律防线（四大安全红线，严禁破坏）

1. **大号小号严格物理隔离（小号当炮灰）**：
   - **绝对禁止**在承载生产主资产（如主力域名 `586934.xyz`、Emby 反代网关 `mute-king-08a5`、关键 DNS 解析）的主 Cloudflare 账号中运行梯子/边缘隧道项目！
   - **必须**使用独立的纯白免费 Cloudflare 小号（全新备用邮箱注册，无信用卡无重要资产）作为承载环境。
   - **防连坐保障**：即使因跑大流量触发 Cloudflare ToS（服务条款第 2.8 条）导致小号被封，爸爸的主力域名与 Emby 视频服务永远 100% 毫发无损。

2. **强密码与后台防爆破**：
   - `edgetunnel` 的 `/login` 接口没有任何图形验证码（CAPTCHA），也没有输错锁定机制。**严禁使用 4 位纯数字等简单弱密码（如 0919、1234）**，否则 10~20 秒内就会被脚本扫穿。
   - 面板中若绑定了 Cloudflare API Token（用于显示每日用量），密码被破会导致整个 CF 账号控制权泄漏。
   - **密码标准**：必须设置为 16+ 位高强度随机密码，或更改管理后台私密访问路径。

3. **严格个人自用，严禁公开外泄**：
   - 绝不可将面板地址与订阅链接分享到群聊、公开论坛或提供给多人测速；
   - 严禁用来挂载 BT/PT 下载、大文件批量爬虫，仅限爸爸个人作为手机/电脑轻量应急备用翻墙线路（月流量控制在轻量范围），防止触发 CF 流量异常监控。

4. **必须配置有效 ProxyIP 与 ECH**：
   - **ProxyIP**：CF Workers 默认不能直连 CF 自身 Anycast 节点（会报 Error 1101 回环错误），必须在后台或环境变量中配置有效 ProxyIP（如 `tw.william.us.ci` 或自建中继）。
   - **ECH (Encrypted Client Hello)**：开启 ECH 阻断保护（`cloudflare-ech.com` + 阿里 DoH `dns.alidns.com`），规避 GFW 对 SNI 明文的识别拦截。

---

## 🏛️ 核心架构与资产对照

* **上游开源项目**：`https://github.com/cmliu/edgetunnel`（v2.1 最新稳定核心）
* **参考成品样本**：`https://llycf.cc.cd/admin`（密码 `0919`，已审计其底层 `config.json` 与节点订阅链）
* **历史沉淀项目**：
  - Pages 项目 `cf00`：曾部署在 `naye.ccwu.cc` / `cf00-63k.pages.dev`（v20260601 旧版本，密码 `0618`，绑定 KV `CF00`）。
  - Workers `lemon-node`：挂在 `node.586934.xyz`（更早期的单文件 GAMFC 节点）。

---

## 🛠️ 标准部署与升级 SOP（Pages 方案，官方最佳推荐）

### 1. 准备代码包
克隆或下载最新代码包，核心逻辑封装在 `_worker.js`：
```bash
curl -sL https://github.com/cmliu/edgetunnel/archive/refs/heads/main.tar.gz | tar -xz -C /tmp/edgetunnel --strip-components=1
```

### 2. Cloudflare Pages 部署流程
1. **创建项目**：
   - 在 CF 小号控制台中选择 **Workers 和 Pages** -> **创建应用程序** -> **Pages** -> **直接上传**。
   - 项目名称推荐命名为 `lemon-tunnel` 或 `edgetunnel`。
   - 上传代码目录（包含 `_worker.js`），点击**部署**。

2. **绑定 KV 命名空间**：
   - 在控制台创建一个新的 KV 命名空间（例如 `EDT_KV`）。
   - 进入 Pages 项目设置 -> **函数 / 绑定 (Bindings)** -> **添加绑定**：
     * 类型：`KV 命名空间`
     * 变量名称：`KV`（**必须全大写**）
     * 命名空间：选择刚建好的 `EDT_KV`。

3. **配置环境变量**：
   - 在项目设置 -> **环境变量** 中添加：
     * `ADMIN`：爸爸指定的 16+ 位高强度管理后台登录密码。
     * `PROXYIP`：`tw.william.us.ci`（优质反代中继出口，解决 1101）。
     * `KEY`：自定义快速订阅路径密钥（例如 `LemonSecretKey`）。

4. **重新部署生效**：
   - 添加完 KV 绑定与环境变量后，在“部署”选项卡点击**重新部署**。

5. **配置自定义域名（可选）**：
   - 默认分配 `xxx.pages.dev`。如需自定义，在“自定义域”绑定小号下的非核心二级域名。

---

## 🎛️ 面板配置与大盘点亮

登录 `https://<域名>/admin` 输入管理员密码进入后台：

1. **激活用量仪表盘**：
   - 在面板的 Cloudflare 设置中填入小号的 **Account ID** 与具有 Workers/Pages 只读权限的 **API Token**。
   - 保存后即可在仪表盘直观看到当天用量进度（例如 `pages: xxx / 100,000`）。

2. **节点安全配置**：
   - **协议类型**：首选 `vless`。
   - **传输协议**：`ws`。
   - **ECH 开关**：开启，DNS 填 `https://dns.alidns.com/dns-query`，SNI 填 `cloudflare-ech.com`。
   - **随机路径**：开启（自动生成 `/service/jump/...` 掩护路径）。

3. **客户端订阅分发**：
   - 面板右上角或订阅区域可一键复制：
     * **Clash / Mihomo 订阅**
     * **Sing-box 订阅**
     * **Surge 订阅**
     * **标准 VLESS 单节点连接串**

---

## 🔍 排错与避坑指南

1. **页面提示 `noADMIN`**：
   - 原因：未在环境变量中配置 `ADMIN` 密码。
   - 解决：进入 Pages/Worker 设置添加 `ADMIN` 变量并重新部署。

2. **访问 `/admin` 报 500 或报错无法保存配置**：
   - 原因：KV 绑定名称错误。必须严格大写为 `KV`，不能写成 `kv` 或其他名称。

3. **客户端连接报 Error 1101 (Worker thrown exception)**：
   - 原因：节点流量直连了 Cloudflare 本机节点被安全机制拦截。
   - 解决：在后台指定有效的 ProxyIP（如 `tw.william.us.ci`、`proxyip.cmliussss.net` 或爸爸的香港 S5 出口）。

4. **测速超时 / 连接断开**：
   - 检查客户端是否支持 ECH；若客户端版本较旧不支持 ECH，在后台临时关闭 ECH 或升级客户端（Clash Meta / Sing-box 最新版均已原生支持 ECH）。
