---
name: proxy-node-connectivity
description: Test proxy nodes and distinguish ports from proxies.
---

# Proxy 节点联通性测试

用于测试用户提供的 VLESS、Reality、VMess、Trojan 等代理节点。核心原则是：**端口可达不等于代理可用**，必须分层验证并如实报告。

## 标准流程

1. **解析参数并保护敏感信息**
   - 提取地址、端口、协议、UUID、flow、SNI、Reality public key、short ID 等。
   - 测试结果中不要重复完整打印 UUID 或订阅链接；必要时只显示脱敏后的地址和参数类型。
   - 不修改用户节点参数，不凭经验猜测缺失值。

2. **基础 TCP 检查**
   - 对目标 `host:port` 做 TCP connect，记录成功/失败、耗时和错误。
   - 该步骤只能证明端口监听和网络路径基本可达，不能证明协议握手成功。

3. **客户端配置校验**
   - 使用与协议匹配的真实客户端（例如 Xray-core）生成临时最小配置。
   - 先运行客户端的配置测试模式，确认 JSON/schema 和协议参数被客户端接受。
   - 配置只监听本机临时 SOCKS 入站，测试结束后关闭进程并清理临时文件。

4. **真实代理请求**
   - 启动临时客户端，通过 SOCKS5 `--socks5-hostname` 发起至少一个 HTTPS 请求；优先使用多个稳定探测目标以排除单站点故障。
   - 记录客户端是否接受连接、HTTP 状态码、curl 返回码、耗时和客户端日志。
   - `HTTP_STATUS=000`、连接被 reset、TLS/Reality 握手错误或无响应均应判为实际代理失败，而不是“基本可用”。

5. **分层结论**
   - `TCP 失败`：节点地址/端口从当前测试环境不可达。
   - `TCP 成功 + 配置失败`：参数格式或客户端配置有问题。
   - `TCP 成功 + 配置成功 + 代理请求失败`：端口开着，但协议握手、服务端配置、访问控制或服务端出站存在问题；不能标记为可用。
   - `代理请求成功`：报告实际探测目标、状态码和测试时间；不要泛化为所有网站都可用。

## 证据与报告要求

- 明确区分“端口连通”“配置可加载”“协议握手/代理请求成功”三个层级。
- 报告真实命令输出中的关键结果，不编造延迟、状态码或可用性。
- 如果只做了 TCP 测试，要明确说“仅验证 TCP”，不要声称节点可用。
- 若多个目标均被 reset，结论应是“端口可达但实际代理不可用”，并列出可能原因但标注为推测。
- 涉及当前网络状态时必须实际测试，不能凭历史结果或记忆判断。

## 工具与实现注意事项

- 优先使用系统已有的 Xray/sing-box；若需要临时下载客户端，先做版本和配置校验，再运行测试。
- 通过 shell 启动长期运行客户端时，使用受控的后台进程机制或独立脚本，避免在前台命令中直接用 `&`；测试完成必须终止进程。
- 不把完整节点链接写入持久日志、技能文件或最终报告。
- 可复用的 Xray Reality 最小测试配方见 `references/xray-reality-test-recipe.md`。
- NAT 容器/超微 VPS 单端口复用、tmpfs 踩坑与 sslh 探测超时排障见 `references/nat-vps-single-port-multiplexing.md`。
- Alpine Linux (LXC NAT) 部署 Sing-Box VLESS-Reality 排障与 OpenRC 自启见 `references/alpine-lxc-nat-singbox-reality.md`。
- 哪吒监控 V2 (Nezha V2 Dashboard/Agent) 跨节点部署、OpenRC/Systemd 守护与 UUID 校验踩坑见 `references/nezha-v2-dashboard-agent-ops.md`。
- Cloudflare Worker VLESS / EdgeTunnel 节点部署、ProxyIP 回源、双向回传排障与 Loon 插件测试质量局限性深度剖析见 `references/cf-worker-vless-edgetunnel-ops.md`。
