---
name: proxy-node-connectivity
description: Test proxy nodes and distinguish ports from proxies.
---

# Proxy 节点联通性测试

用于测试用户提供的 VLESS、Reality、VMess、Trojan 等代理节点。核心原则是：**端口可达不等于代理可用**，必须分层验证并如实报告。

## 标准流程

1. **解析参数并保护敏感信息**
   - 提取地址、端口、协议、UUID、flow、SNI、Reality public key、short ID 等。
   - 测试结果中不要重复完整打印 UUID 或订阅链接；必要时只显示脱敏后的地址和参数类型。
   - 不修改用户节点参数，不凭经验猜测缺失值。

2. **基础 TCP 检查**
   - 对目标 `host:port` 做 TCP connect，记录成功/失败、耗时和错误。
   - 该步骤只能证明端口监听和网络路径基本可达，不能证明协议握手成功。

3. **客户端配置校验**
   - 使用与协议匹配的真实客户端（例如 Xray-core）生成临时最小配置。
   - 先运行客户端的配置测试模式，确认 JSON/schema 和协议参数被客户端接受。
   - 配置只监听本机临时 SOCKS 入站，测试结束后关闭进程并清理临时文件。

4. **真实代理请求**
   - 启动临时客户端，通过 SOCKS5 `--socks5-hostname` 发起至少一个 HTTPS 请求；优先使用多个稳定探测目标以排除单站点故障。
   - 记录客户端是否接受连接、HTTP 状态码、curl 返回码、耗时和客户端日志。
   - `HTTP_STATUS=000`、连接被 reset、TLS/Reality 握手错误或无响应均应判为实际代理失败，而不是“基本可用”。

5. **分层结论**
   - `TCP 失败`：节点地址/端口从当前测试环境不可达。
   - `TCP 成功 + 配置失败`：参数格式或客户端配置有问题。
   - `TCP 成功 + 配置成功 + 代理请求失败`：端口开着，但协议握手、服务端配置、访问控制或服务端出站存在问题；不能标记为可用。
   - `代理请求成功`：报告实际探测目标、状态码和测试时间；不要泛化为所有网站都可用。

## 群聊上下文解读：代理/SOCKS 问题

当用户要求结合群聊上下文分析 S5/SOCKS5 连不通、是否需要挂代理等情况时：

1. 先区分发言人、被回复对象和引用内容；不要把相邻消息的话题/故障归给错误的人。必要时回查前后消息及原始图片，而不是依赖摘要或转述。
2. 用准确术语解释：SOCKS5 是代理协议；“弱协议”不是明确的 SOCKS5 技术分类。挂上另一条代理后才可达，可能是源 IP 白名单、防火墙/ACL、运营商路由或过滤、目的端口可达性、客户端配置等因素，不能仅凭该现象断言“机主屏蔽弱协议”。
3. 分层核验：分别比较目标 IP:port 的 TCP 连通、SOCKS5 握手/认证、经代理访问目标的结果；如有服务端权限，再核对防火墙规则与代理日志。只根据聊天描述时，明确标注为可能解释，不伪装成已验证根因。
4. 输出简洁、先给结论；对群聊纠错时明确更正具体是谁的问题，并避免重复复述整段过程。

## 证据与报告要求

- 明确区分“端口连通”“配置可加载”“协议握手/代理请求成功”三个层级。
- 报告真实命令输出中的关键结果，不编造延迟、状态码或可用性。
- 如果只做了 TCP 测试，要明确说“仅验证 TCP”，不要声称节点可用。
- 若多个目标均被 reset，结论应是“端口可达但实际代理不可用”，并列出可能原因但标注为推测。
- 涉及当前网络状态时必须实际测试，不能凭历史结果或记忆判断。

## 工具与实现注意事项

- 优先使用系统已有的 Xray/sing-box；若需要临时下载客户端，先做版本和配置校验，再运行测试。
- 通过 shell 启动长期运行客户端时，使用受控的后台进程机制或独立脚本，避免在前台命令中直接用 `&`；测试完成必须终止进程。
- 不把完整节点链接写入持久日志、技能文件或最终报告。
- 可复用的 Xray Reality 最小测试配方见 `references/xray-reality-test-recipe.md`。
- NAT 容器/超微 VPS 单端口复用、tmpfs 踩坑与 sslh 探测超时排障见 `references/nat-vps-single-port-multiplexing.md`。
- Alpine Linux (LXC NAT) 部署 Sing-Box VLESS-Reality 排障与 OpenRC 自启见 `references/alpine-lxc-nat-singbox-reality.md`。
- 哪吒监控 V2 (Nezha V2 Dashboard/Agent) 跨节点部署、OpenRC/Systemd 守护与 UUID 校验踩坑见 `references/nezha-v2-dashboard-agent-ops.md`。用户报"某台机器在面板上掉线了"时先读该文件：需要区分「Agent 裸跑无守护被 OOM 杀掉」与「进程在跑但连不上面板」，存活判定必须看到面板端口的 TCP ESTAB，`servers.updated_at` 与 `systemctl is-active` 都会误判；面板管理员密码是 bcrypt 哈希不可读取，只能重置。
- Cloudflare Worker VLESS / EdgeTunnel 2.x 面板部署（CMLiu edgetunnel）、KV 绑定与 CF API 仪表盘点亮、ECH 抗审查、ProxyIP 链式回源与 Loon 插件测试质量局限性深度剖析见 `references/cf-worker-vless-edgetunnel-ops.md`。
