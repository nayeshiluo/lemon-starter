# Cloudflare Worker / EdgeTunnel VLESS 节点运维与排障指南

## 一、核心架构与工作原理

1. **三段式转发流**：
   - `客户端 ➡️ Cloudflare CDN Anycast 边缘 (优选 IP) ➡️ Cloudflare Worker (V8 计算实例) ➡️ 目标网站 / ProxyIP`。
2. **入口与落地分离机制**：
   - **入口地区 (Entry)**：由客户端节点配置中的 `Address` 优选 IP 决定（如连接香港 CDN 节点则入口为香港）。
   - **落地地区 (Exit)**：由 Cloudflare Worker 内部调度出站机房或外部 `ProxyIP` 决定（通常落于美西、新加坡或欧洲机房）。
3. **ProxyIP 的必要性与调度**：
   - Cloudflare 官方禁止 Worker 内部直接回源访问受 Cloudflare 保护的网站（触发 1000/500 错误）。
   - 必须配置高可用 ProxyIP 池作为回源兜底，但应优先尝试直连，直连失败或目标为 CF 网段时再 fallback 到 ProxyIP。

---

## 二、双向数据流与回传常见故障排查

### 1. 现象：握手成功 (101 Switching Protocols)，但无数据回传 (0KB 上下行)
* **根因**：
  - 未使用 `import { connect } from 'cloudflare:sockets'` 正确建立底层 TCP Socket。
  - 数据管道未双向绑定，或未正确处理 VLESS 响应头 `[0, 0]`。
  - 强制把所有非 TLS 流量转发至单一 ProxyIP 的 443 端口导致连接被对端重置。
* **排障与验证命令**：
  使用 Python 构造真实的 WebSocket + VLESS Header 二进制帧发送测试请求（如访问 `httpbin.org:80`），验证是否收到 `HTTP/1.1 200 OK` 真实回传包。

---

## 三、Loon / 代理客户端节点质量测试失败根因分析

当使用 Loon、Surge 等客户端的节点质量测试、测速或流媒体检测插件时，CF Worker 节点常表现为“测不出质量 / 失败”：

1. **缺少裸 UDP 协议支持 (最核心原因)**：
   - Loon 质量插件普遍发送 UDP 数据包检测 NAT 类型与丢包率。
   - Cloudflare Worker 运行环境仅支持 TCP（通过 WebSocket），不支持裸 UDP 转发（仅能将 53 端口 DNS 查询通过 HTTPS DoH 转发至 `1.1.1.1`）。非 DNS 的 UDP 包会被静默丢弃或报错。
2. **0-RTT EarlyData 与激进测速超时**：
   - Loon 测速插件对并发握手超时要求严苛（通常 500ms ~ 1000ms）。三段式调度握手开销可能导致部分激进测速判定为超时。
3. **Cloudflare 测速接口防回环限制**：
   - 测速插件请求 `speed.cloudflare.com` 时，流量经由 CF Worker 再次进入 CF 自身测速节点，易触发边缘频控或防压测拦截。

---

## 四、自动化部署与订阅参数模板

* **Worker 部署权限要求**：
  Cloudflare API Token 必须具备 `Account -> Workers Scripts: Edit` 权限，仅有 `Zone DNS: Edit` 会报 403。
* **自定义域名绑定**：
  通过 API 路由 `PUT /accounts/{account_id}/workers/domains` 自动挂载自定义域名（如 `node.yourdomain.com`），规避 `*.workers.dev` 官方子域名被污染问题。
* **订阅响应头伪装**：
  在输出 Base64 订阅时需携带 `Subscription-Userinfo: upload=0; download=0; total=107374182400; expire=0`，避免部分客户端（Shadowrocket/Clash）因无配额信息提示订阅过期。

---

## 五、CMLiu edgetunnel 2.x 现代化控制面板与部署架构

`cmliu/edgetunnel` (v2.1+) 是当前主流的 CF Pages / Workers 边缘隧道面板化解密方案：

1. **核心组件与依赖绑定**：
   - **计算运行时**：单文件 `_worker.js` 兼容 Cloudflare Pages Functions 与 Cloudflare Workers。
   - **环境变量**：`ADMIN` 为后台管理员密码；可选 `KEY` 用于快速订阅与鉴权种子。
   - **KV 命名空间**：必须绑定变量名为 `KV` 的命名空间，用于持久化存储 `config.json`（节点与分流配置）、`ADD.txt`（自定义优选 IP）、`cf.json`（CF API 凭证）与访问日志。
   - **前端静态后台**：管理界面解耦托管在 `https://edt-pages.github.io/admin`，后端在校验 Cookie（`auth=MD5(UA + KEY + ADMIN)`）后代理回源前端 HTML/CSS/JS。

2. **核心防阻断与加速机制**：
   - **ECH (Encrypted Client Hello)**：面板配置启用 ECH，结合阿里公共 DoH（`https://dns.alidns.com/dns-query`）查询 `cloudflare-ech.com` 的 ECHConfig，实现 TLS SNI 加密，抵御深度包检测（DPI）阻断。
   - **动态伪装随机路径**：每次请求动态生成伪装静态路径（如 `/service/docs/jump/...` 或 `/uploads/...`），避免客户端使用固定 WS 路径被特征识别。
   - **ProxyIP 链式回源**：在面板配置固定优质 ProxyIP（如 `tw.william.us.ci` 或其他干净中继），将流量转发至目标网站，彻底规避 CF 官方 1101 错误与对自身 CDN 站点的 1000 回环拦截。
   - **Cloudflare 请求大盘**：在后台填入 `AccountID` 与具有 Workers 读取权限的 `APIToken`，面板自动调用 Cloudflare API 实时统计当日请求次数（Pages/Workers 独立与汇总），直观掌控 10 万次/天免费额度。

3. **版本审计与升级规范**：
   - **版本校验接口**：访问 `/version?uuid={UUID}` 可返回当前部署时间戳版本号（如 `20260904162413`）。
   - **平滑升级方式**：对于已有 Pages 项目，只需使用 `wrangler pages deploy` 或 Git 触发将最新的 `_worker.js` 推送部署，原有 KV 数据库中的 `config.json` 和自定义 IP 完全保留，无需重新绑定域名或重置密码。

---

## 六、CF CDN 代理 + 独立海外 VPS 架构（救活被封 VPS 与大流量落地）

当持有海外廉价/大流量 VPS（如洛杉矶 5TB 机型）且因 IP/端口被 GFW 阻断导致无法直连时：

1. **核心架构**：
   `客户端 ➡️ CF 优选 Anycast IP (香港 86ms / 美西 86ms) ➡️ Cloudflare CDN 边缘 ➡️ 洛杉矶 VPS (VLESS+WS 后端) ➡️ 目标网站`
2. **核心优势**：
   - **救活被墙机**：国内只连接 Cloudflare CDN 节点，海外由 CF 走专线直连 VPS，无视 VPS 本地 IP/端口封锁。
   - **原生独立落地 IP**：彻底摆脱 CF Worker 共享 IP 的 Google 验证码与 1000 报错，出站走 VPS 原生网络。
   - **大流量消耗**：直接使用 VPS 套餐自带的月度流量配额（如 5TB），避免公有云高昂流量费。

---

## 七、SOCKS5 / Telegram 代理与 CF CDN 端口/SSL 避坑准则

1. **Telegram 内置代理与客户端订阅格式冲突**：
   - **Telegram App 内置代理仅支持原生 SOCKS5 和 MTProto**，严禁为了适配普通订阅客户端而将已有 SOCKS5 端口改成 Shadowsocks/VMess，否则 Telegram 会立刻鉴权失败断连。
   - **通用订阅客户端的过滤机制**：Loon、Shadowrocket、Clash 等在拉取远程 Base64 订阅时，默认会自动忽略/过滤裸 `socks://` 协议（视为本地未加密 socket）；若需提供给订阅客户端，应部署标准 `ss://` 或 `vless://`。
2. **Cloudflare CDN 代理端口硬性限制**：
   - Cloudflare CDN 仅支持特定端口：
     - **HTTP 端口**：`80, 8080, 8880, 2052, 2082, 2086, 2095`
     - **HTTPS (TLS) 端口**：`443, 2053, 2083, 2087, 2096, 8443`
   - 若 VPS 后端监听在非标准端口（如 `20888` / `24443`），CF CDN 无法接入转发。
3. **Cloudflare SSL 模式与 VPS 回源配置**：
   - 当域名在 CF 上开启 `Full` SSL 模式时，CF 会通过 TLS 与 VPS 回源端口通信（如 `2053`）。VPS 端的 Xray 必须配置自签名或合法证书；若仅为 HTTP WS，应使用支持 HTTP 的 CF 端口（如 `2052`）或配置 Origin Rules。
