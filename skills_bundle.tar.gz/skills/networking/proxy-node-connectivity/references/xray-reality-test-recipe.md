# Xray Reality 节点测试配方

## 最小验证层级

1. TCP connect 到节点地址和端口。
2. Xray `run -test -config` 校验临时 JSON 配置。
3. 启动本机临时 SOCKS 入站。
4. 使用 `curl --socks5-hostname 127.0.0.1:<port>` 请求 HTTPS 探测站点。
5. 读取 curl 返回码、HTTP 状态码和 Xray 日志，然后终止客户端。

## 关键判定

- `TCP success` 仅代表目标端口可达。
- Xray 配置校验成功仅代表本地参数能被客户端解析。
- Xray 接受 SOCKS 连接但 curl 返回 `35`、`HTTP_STATUS=000`、`Recv failure: Connection reset by peer`，表示真实代理链路失败。
- 多个 HTTPS 目标均失败时，可报告“端口可达但代理不可用”；服务端配置、Reality 凭据、访问控制或服务端出站只是可能原因，不能当作已证实根因。

## 安全与清理

- 节点链接、UUID、public key 和 short ID 只用于当前临时配置，不写入技能库或最终持久日志。
- 临时 Xray 进程必须在测试后终止；临时配置应放在 `/tmp` 并按需删除。
- 不要把单个网站成功访问泛化成所有网站都可用。
