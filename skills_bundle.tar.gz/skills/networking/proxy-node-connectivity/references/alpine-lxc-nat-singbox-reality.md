# Alpine Linux (LXC NAT) 部署 Sing-Box VLESS-Reality 极速实战与排障

在低配 Alpine Linux 3.21 LXC NAT 容器（如 Hytron、NAT 小鸡）上部署与排障代理节点的关键踩坑记录与最佳实践。

## 1. 核心踩坑与排障

### 现象 A：客户端测试出现「TCP 延迟几十/几百 ms，但 HTTP/节点连接 Timeout」
- **根因分析**：
  1. **协议明文特征被墙拦截**：原版 Shadowsocks (如 `aes-256-gcm`、`chacha20-ietf-poly1305`) 没有 TLS 伪装层，在公网 NAT 高位端口极易被 GFW 主动探测（Active Probing）和深度包检测（DPI）阻断，导致 TCP 握手通（能 Ping 出延迟），但 HTTP 握手永远被 Drop。
  2. **国内 SNI 伪装域名重定向陷阱 (如 gateway.icloud.com)**：在大陆网络环境下，部分 Apple 域名（如 `gateway.icloud.com`）会被 DNS 重定向或解析到国内“云上贵州 (GCBD)”节点，导致大陆客户端拿到的本地 TLS 证书链与海外服务端实际证书不匹配，Reality 握手被客户端或 GFW 判定失败超时。
     * **推荐国内无污染、直连极佳的 SNI**：`itunes.apple.com`、`addons.mozilla.org`、`www.microsoft.com`、`swdist.apple.com`。客户端指纹（`fp`）在 iOS/小火箭环境下优先推荐 `safari` 或 `chrome`。
  3. **IPv6 假死延迟**：LXC 容器内默认启用了 IPv6（或 DHCP 分配了 IPv6），但宿主机未配置外网 IPv6 出口路由。DNS 或代理内核解析域名时优先发起 AAAA 连接，导致连接挂起直至超时。
- **解决方案**：
  1. 彻底禁用无路由的 IPv6：
     ```sh
     echo 'net.ipv6.conf.all.disable_ipv6 = 1' >> /etc/sysctl.conf
     echo 'net.ipv6.conf.default.disable_ipv6 = 1' >> /etc/sysctl.conf
     sysctl -p
     ```
  2. 升级为 **VLESS + Reality**，使用国内直连且无 GCBD 重定向的 TLS 1.3 伪装域名（优先 `itunes.apple.com`）。

---

### 现象 B：小火箭测试「时通时断 / 间歇性 Timeout / 显示已连接但测速失败」
- **根因分析**：
  1. **Vision 流控 (`xtls-rprx-vision`) 与小火箭明文测速探测包冲突**：小火箭的「延迟测试」默认发送轻量明文 HTTP 204 请求（非双层 TLS 流量）。当配置了 Vision 流控时，小火箭内部对非 TLS 数据包的流控解析可能判定异常，造成**测速假超时**（即使实际代理上网通畅）。
  2. **小火箭全局开关开启状态冲突**：当小火箭顶部总开关处于“已连接”状态时直接点测速，探测包可能受内部代理路由回环影响而报错。
- **解决方案**：
  1. **服务端推荐无 flow 纯净 VLESS-Reality**：服务端 inbound 用户配置只保留 `uuid`（不强制约束 flow），兼容所有客户端：
     ```json
     "users": [
       { "uuid": "<UUID>" }
     ]
     ```
  2. **客户端排障**：
     * 客户端编辑节点，将「流控 (Flow)」留空/设为无（none）。
     * 最准验证方法是直接切到浏览器（Safari/Chrome）访问 `google.com` 验证真实连通性；若需测速，可先关闭顶部开关再点延迟测试。

---

### 现象 C：切换协议时 Sing-Box 启动失败或客户端连不上（端口被旧进程占用）
- **根因**：从 shadowsocks-rust 切换至 sing-box 监听同一内网端口（如 81）时，若之前运行过前台调试或未完全退出的旧进程，会导致 `bind: address already in use`，sing-box 启动即退出。
- **解决方案**：切换前先清理进程并确认端口释放：
  ```sh
  killall -9 ssserver 2>/dev/null || true
  killall -9 sing-box 2>/dev/null || true
  netstat -tuln | grep 81
  rc-service sing-box restart
  ```

---

### 现象 C：Alpine Linux 下载官方 Sing-Box 报 `sh: /usr/local/bin/sing-box: not found`
- **根因**：Sing-Box 官方预编译的 `linux-amd64` 依赖 glibc，而 Alpine 原生使用 musl libc。
- **解决方案**：安装兼容层 `gcompat` 即可无缝运行官方二进制：
  ```sh
  apk add --no-cache gcompat
  ```

---

## 2. Alpine LXC 极简部署全流程

### 步骤 1：下载并配置二进制
```sh
cd /tmp
wget -q https://github.com/SagerNet/sing-box/releases/download/v1.14.0/sing-box-1.14.0-linux-amd64.tar.gz
tar -xzf sing-box-1.14.0-linux-amd64.tar.gz
cp sing-box-1.14.0-linux-amd64/sing-box /usr/local/bin/sing-box
chmod +x /usr/local/bin/sing-box
rm -rf /tmp/sing-box*
```

### 步骤 2：生成密钥与配置
```sh
# 生成 Reality 密钥对与 UUID
sing-box generate reality-keypair
sing-box generate uuid
sing-box generate rand --hex 8
```

编写 `/etc/sing-box/config.json`（注意：Sing-Box 1.14.0+ 已彻底移除旧版 dns.servers 配置语法，直接采用精简 direct 出站与系统 DNS 即可，避免配置解析错误）：
```json
{
  "log": {
    "level": "warn",
    "timestamp": true
  },
  "inbounds": [
    {
      "type": "vless",
      "tag": "vless-in",
      "listen": "::",
      "listen_port": 81,
      "tcp_fast_open": true,
      "users": [
        {
          "uuid": "<UUID>",
          "flow": "xtls-rprx-vision"
        }
      ],
      "tls": {
        "enabled": true,
        "server_name": "itunes.apple.com",
        "reality": {
          "enabled": true,
          "handshake": {
            "server": "itunes.apple.com",
            "server_port": 443
          },
          "private_key": "<PRIVATE_KEY>",
          "short_id": [
            "<SHORT_ID>"
          ]
        }
      }
    }
  ],
  "outbounds": [
    {
      "type": "direct",
      "tag": "direct"
    }
  ]
}
```

---

## 3. 客户端链接格式与延迟指标解读

### 标准 Reality VLESS 链接结构
```text
vless://<UUID>@<PUBLIC_IP>:<MAPPED_PORT>?security=reality&encryption=none&pbk=<PUBLIC_KEY>&headerType=none&type=tcp&flow=xtls-rprx-vision&sni=itunes.apple.com&sid=<SHORT_ID>&fp=safari#<URL_ENCODED_TAG>
```

### Shadowrocket / 客户端测试延迟指标解读
客户端（如小火箭）测试时返回的两个数字（例如 `174ms, 1549ms`）：
1. **第一个数值（如 `174ms`）**：客户端到 VPS 节点的物理 **TCP Ping RTT**。普通国际 BGP（如 Hytron 香港）直连通常在 `100~200ms`，属于正常物理链路延迟。
2. **第二个数值（如 `1549ms`）**：**完整 HTTP 业务探测延迟**（TCP 握手 + TLS 1.3 Reality 伪装证书协商 + 小鸡向海外 Google/Cloudflare 请求 204）。首次冷启动测试包含全链路协商故数值偏大；实际使用在 TCP Keep-Alive 连接复用后，网页与流媒体均为毫秒级秒开。
