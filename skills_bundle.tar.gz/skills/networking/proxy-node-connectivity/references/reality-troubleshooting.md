# Reality 节点排障与 SNI 伪装域名优化指南

## 1. Reality SNI 伪装域名白名单机制
- **问题现象**：在 VPS 端部署 Reality（443 端口）后，TCP 端口可通，但在客户端（Shadowrocket / Clash / Loon / Sing-box / V2rayN）连接时提示“连接超时”或“连接被重置（Connection Reset）”。
- **原因**：部分国内运营商对常见国外大厂（如 `www.microsoft.com`、`www.yahoo.com`）的 443 端口有基于 SNI 的主动重置过滤机制。
- **解决方案**：
  - 服务端配置兼容多个主流大厂域名：`serverNames: ["gateway.icloud.com", "itunes.apple.com", "www.apple.com", "www.microsoft.com"]`，并将 `dest` 设为 `gateway.icloud.com:443`。
  - 客户端连接时指定 `sni=gateway.icloud.com`，利用 Apple 国内加速 CDN 节点实现 100% 稳定直连。

## 2. 节点“只能进 不能出”与 IPv6 路由黑洞排障 (The IPv6 Blackhole Pitfall)
- **问题现象**：客户端通过 Reality / SOCKS5 能够正常握手连入节点（服务端日志显示 accepted），但客户端访问任何境外网站（Google / YouTube）均无响应、提示网络中断或持续超时。
- **根本原因**：许多廉价 VPS 仅具备可用公网 IPv4 地址，宿主机未分配有效的公网 IPv6 出口路由（`curl -6 https://google.com` 报错无法连接）；而 Xray / Sing-box 的内置 DNS 与 `freedom` 出站默认会优先解析并尝试连接双栈目标的 IPv6 地址，导致出站请求全部掉入 IPv6 路由黑洞中 hang 住。
- **解决方案**：在服务端 Xray 配置中显式声明 IPv4 独占出站策略与 DNS 查询策略：
  ```json
  {
    "dns": {
      "servers": ["8.8.8.8", "1.1.1.1"],
      "queryStrategy": "UseIPv4"
    },
    "outbounds": [
      {
        "protocol": "freedom",
        "tag": "direct",
        "settings": {
          "domainStrategy": "UseIPv4"
        }
      }
    ]
  }
  ```

## 3. 远程生成 Xray 配置的引号防脱落准则
- 避免直接在远程 Shell 中使用带双引号的 `echo` 写入 JSON，易被 Bash 展开导致缺少引号而破坏 JSON 结构。
- 推荐使用 Python 的 `json.dump` 写入配置，或者使用带单引号保护的 `cat << 'EOF' > config.json`。

## 3. 容器排障指令
```bash
# 检查 Xray 容器运行状态与错误日志
docker ps -a
docker logs <container_name> --tail 50

# 验证服务端 Reality 握手证书回显
openssl s_client -connect <IP>:443 -servername gateway.icloud.com </dev/null
```
