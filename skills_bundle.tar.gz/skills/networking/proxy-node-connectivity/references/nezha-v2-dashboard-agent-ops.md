# 哪吒监控 V2 (Nezha Monitoring V2) 独立仪表盘与 Agent 踩坑与排障指南

## 1. 架构核心与端口划分
* **Dashboard 服务端**：监听 Web HTTP/gRPC（默认配置可设 `listen_port: 8088`）。在 NAT VPS 下通过映射公网高位端口（如 `34474 -> 8088`）对外提供 Web 面板。
* **Agent 客户端**：通过 gRPC / Web API 向 Dashboard 上报数据。
* **连接通信模式**：
  * **本机采集（Server 与 Agent 同机）**：在配置文件中 `server: 127.0.0.1:8088`，`tls: false`，`insecure_tls: true`。
  * **跨机/远端采集（其他机器如 AWS / RackNerd）**：在配置文件中 `server: <公网IP>:<外网映射端口>`（如 `45.196.236.222:34474`），`tls: false`，`insecure_tls: true`。

## 2. 关键排坑点 (Pitfalls)

### 坑 1：UUID 长度与格式严格校验
* **现象**：`init config failed: uuid string is wrong length`
* **根因**：Nezha V2 的 Agent 配置中 `uuid` 必须是**标准 36 位 UUID 格式**（例如 `e3ba469f-7673-40c6-a15e-b8bbda8086e3`），不能使用自定义字符串（如 `hk-hytron-node-uuid`）。
* **解决**：在服务端 sqlite 或后台生成合法的 UUID，在 Agent 的 `config.yml` 中必须完全一致。

### 坑 2：面板首次打开“没有机器 / 机器离线”
* **现象**：在 Dashboard 数据库插入或添加了主机，但 Web 前端刷新看不到机器或显示离线。
* **根因**：
  1. Nezha Dashboard V2 前端默认只展示已在线汇报的机器（或由 `hide_for_guest` 字段控制）；
  2. 目标机器上必须真正运行 `nezha-agent` 且通信建立成功，机器卡片才会点亮展示 CPU/内存/网速。

### 坑 3：Alpine Linux (OpenRC) 守护进程启动崩溃
* **现象**：OpenRC 启动脚本报 `status: crashed`，提示 `Permission denied` 或参数语法错误。
* **根因**：OpenRC 默认的 `start-stop-daemon` 对长前台运行的 Go 二进制程序管理容易丢失 PID。
* **解决**：在 OpenRC 脚本中使用 `supervisor="supervise-daemon"`，配置简洁健壮：
```sh
#!/sbin/openrc-run
name="nezha-agent"
supervisor="supervise-daemon"
command="/opt/nezha/nezha-agent"
command_args="-c /opt/nezha/agent_config.yml"

depend() {
    need net
}
```

### 坑 4：Systemd 环境（Ubuntu / Debian）自动化守护
在标准 Linux 上部署 Agent：
```ini
[Unit]
Description=Nezha Monitoring Agent
After=network.target

[Service]
Type=simple
ExecStart=/opt/nezha-agent/nezha-agent -c /opt/nezha-agent/config.yml
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
```
