# 哪吒监控 V2 (Nezha Monitoring V2) 独立仪表盘与 Agent 踩坑与排障指南

## 1. 架构核心与端口划分
* **Dashboard 服务端**：监听 Web HTTP/gRPC（默认配置可设 `listen_port: 8088`）。在 NAT VPS 下通过映射公网高位端口（如 `34474 -> 8088`）对外提供 Web 面板。
* **Agent 客户端**：通过 gRPC / Web API 向 Dashboard 上报数据。
* **连接通信模式**：
  * **本机采集（Server 与 Agent 同机）**：在配置文件中 `server: 127.0.0.1:8088`，`tls: false`，`insecure_tls: true`。
  * **跨机/远端采集（其他机器如 AWS / RackNerd）**：在配置文件中 `server: <公网IP>:<外网映射端口>`（如 `45.196.236.222:34474`），`tls: false`，`insecure_tls: true`。
* **V2 的 Web 与 gRPC 共用同一个 `listen_port`**：NAT 映射的那一个公网端口（如 34474）既是浏览器访问面板的地址，也是 Agent 上报的 gRPC 目标，不要去找第二个端口。

## 2. 文件布局：先认对配置文件，别被诱饵浪费时间

一台既跑 Dashboard 又跑 Agent 的机器上会同时存在 3 个 yml/yaml，**只有一个是面板真配置**：

| 路径 | 是什么 | 关键字段 |
|---|---|---|
| `/opt/nezha/dashboard/data/config.yaml` | ✅ **面板真配置（唯一真源）** | `listen_port`、`agent_secret_key`、`jwt_secret_key`、`site_name`、`language` |
| `/opt/nezha/dashboard/config.yaml` | 面板配置的初始模板/副本 | 可能与 data/ 下不一致，不要信 |
| `/opt/nezha/config.yml`、`/opt/nezha/agent_config.yml` | ❌ **Agent 配置**（不是面板的） | `server`、`uuid`、`client_secret` |

⚠️ 实测踩坑：`/opt/nezha/config.yml` 里 `server: ""`、`client_secret: ""` 全是空的，看起来像"面板没配置好"，其实那只是本机 Agent 的模板文件，与面板毫无关系。**排查面板问题必须直接读 `/opt/nezha/dashboard/data/config.yaml`**，不要在 `/opt/nezha/` 根目录的文件上纠缠。

## 3. 从 Dashboard 数据库读取节点清单与 UUID

面板数据库固定在 `/opt/nezha/dashboard/data/sqlite.db`（Alpine 小鸡上 `sqlite3` 通常已自带）。

```bash
# 全部受控节点及其 UUID —— 把 Agent 与面板对应起来的唯一依据
sqlite3 /opt/nezha/dashboard/data/sqlite.db 'SELECT id, name, uuid FROM servers;'

# 管理员账号（只有用户名可读，密码见第 5 节）
sqlite3 /opt/nezha/dashboard/data/sqlite.db 'SELECT id, username FROM users;'
```

⚠️ **`servers` 表没有 `last_active` 字段**（V2 已移除），`SELECT ... last_active` 直接报 `no such column`。可用的时间字段是 `created_at` / `updated_at`。

⚠️ **更重要的坑：`updated_at` 不是存活指标。** 实测 Agent 重新连上、gRPC 已 ESTAB 之后，三台机器的 `updated_at` 仍全部停留在建库时的同一个时间戳——实时心跳/负载走内存与时序库，不回写 `servers` 表。**用 `updated_at` 判断在线离线一定会误判。** 正确验证见第 4 节。

## 4. 判断 Agent 到底有没有在上报（权威验证法）

不要看面板 `updated_at`，也不要只看 `systemctl is-active`（进程活着但连不上面板是常见状态）。三层验证：

```bash
# ① 进程在跑（用完整路径过滤，否则会匹配到自己的 grep/shell 包装命令）
ps -eo pid,etime,cmd | grep '/home/ubuntu/nezha-agent/nezha-agent' | grep -v grep

# ② 【权威】到面板 gRPC 的 TCP 连接处于 ESTAB —— "真的在上报"的铁证
ss -tnp 2>/dev/null | grep <面板公网端口>
# 期望输出形如：
# ESTAB 0 0 172.31.4.215:37254 45.196.236.222:34474 users:(("nezha-agent",pid=543476,fd=7))

# ③ 面板侧 HTTP 存活
curl -s -o /dev/null -w 'HTTP %{http_code}\n' http://127.0.0.1:8088/
```

💡 `pgrep -af nezha-agent` 在 Hermes 的 shell 包装下会把**自己这条命令**也匹配出来（命令行里含关键字），造成"进程还在"的假阳性。用上面 ① 的完整路径 + `grep -v grep` 写法。

## 5. 面板管理员密码：不可读取，只能重置

`users.password` 是 **bcrypt 哈希**（形如 `$2a$10$OsPiOcirOYdsG...`），单向不可逆，明文不存在于任何配置文件或数据库字段。

- 用户要"面板用户名和密码"时：**用户名可以给（通常是 `admin`），密码必须如实说明无法找回**，不要编造，也不要把哈希当密码发过去。
- 恢复访问只有一条路：生成新密码的 bcrypt 哈希写回 `users` 表再重启 dashboard。执行前先向用户确认新密码（改动登录凭证，需要明确授权）。
- `agent_secret_key`（如 `LemonNezha_Secret_9618`）与 `jwt_secret_key` 明文可读，但它们**不是**登录密码，别搞混。

### 5.1 重置密码的正确姿势（含一个会静默失败的致命坑）

```bash
# ① 本地生成 bcrypt 哈希；必须 prefix=2a、rounds=10，与 Go 端 golang.org/x/crypto/bcrypt 兼容
python3 -c "
import bcrypt
h = bcrypt.hashpw(b'<新密码>', bcrypt.gensalt(rounds=10, prefix=b'2a')).decode()
print(h)" > /tmp/nz_hash.txt   # 期望 60 字符，形如 \$2a\$10\$M7WSfva...

# ② 整条 SQL 落成本地文件 → base64 → 远端解码执行（关键，见下方警告）
HASH=$(head -1 /tmp/nz_hash.txt)
printf "UPDATE users SET password='%s', updated_at=datetime('now'), token_version=token_version+1 WHERE username='admin';" "$HASH" > /tmp/nz_fix.sql
B64=$(base64 -w0 /tmp/nz_fix.sql)
ssh <面板机> "cd /opt/nezha/dashboard/data \
  && cp -a sqlite.db sqlite.db.bak-\$(date +%Y%m%d_%H%M%S) \
  && echo '$B64' | base64 -d > /tmp/f.sql \
  && sqlite3 sqlite.db < /tmp/f.sql && rm -f /tmp/f.sql \
  && sqlite3 sqlite.db \"SELECT username,password FROM users;\""

# ③ 重启面板（Alpine/OpenRC）
ssh <面板机> "rc-service nezha-dashboard restart"     # systemd 环境用 systemctl restart

# ④ 【唯一可信验证】实测登录 API，别靠"改完了应该就行"
ssh <面板机> "curl -s -X POST 'http://127.0.0.1:8088/api/v1/login' \
  -H 'Content-Type: application/json' \
  -d '{\"username\":\"admin\",\"password\":\"<新密码>\"}'"
# 期望：{"success":true,"data":{"token":"...","expire":"..."}}
```

`token_version+1` 会吊销所有已签发的旧 JWT，改密后其他设备的登录态立即失效——这是期望行为。

#### ⚠️ 致命坑：bcrypt 哈希里的 `$` 会被 SSH 的双层 shell 吃掉，且静默失败
`$2a$10$...` 中的 `$2a`、`$10` 在**远端 shell** 会被当变量展开（未定义 → 空串），写进库的哈希残缺成 `a0` 之类。**SQL 执行成功、无任何报错**，但登录永远失败，极易误判成"哈希算错了"或"密码记错了"而反复重试。

- ❌ 错误：`ssh host "sqlite3 db \"UPDATE ... password='$HASH' ...\""` —— 本地展开一次、远端再展开一次。
- ❌ 单引号包裹也救不了：`$HASH` 要在本地展开才拿得到值，一旦展开后的字符串进了远端命令行就会被二次解析。
- ✅ 正确：**base64 传输**。base64 输出是纯字母数字，穿越任意层数的 shell 都不会被改写。
- 写完**必须回读** `SELECT password FROM users`，确认是完整 60 字符的 `$2a$10$...`。若看到 `a0` 这种短串，说明被吃了 —— 用第 ② 步的备份 `cp -f sqlite.db.bak-<ts> sqlite.db` 回滚后重来。

#### 另一个无害告警，别去"修"
Alpine 面板机执行 `rc-service nezha-dashboard restart` 时会打印：
```text
/etc/init.d/nezha-dashboard: line 4: /opt/nezha/dashboard/data/config.yaml: Permission denied
```
这是 init 脚本第 4 行尝试读配置的告警，只要随后出现 `* status: started` 且 `curl 127.0.0.1:8088` 返回 200，面板就是完全正常的，不要为此改权限或改脚本。

## 6. 关键排坑点 (Pitfalls)

### 坑 1：UUID 长度与格式严格校验
* **现象**：`init config failed: uuid string is wrong length`
* **根因**：Nezha V2 的 Agent 配置中 `uuid` 必须是**标准 36 位 UUID 格式**（例如 `e3ba469f-7673-40c6-a15e-b8bbda8086e3`），不能使用自定义字符串（如 `hk-hytron-node-uuid`）。
* **解决**：在服务端 sqlite 或后台生成合法的 UUID，在 Agent 的 `config.yml` 中必须完全一致（用第 3 节的 SQL 核对）。

### 坑 2：面板首次打开"没有机器 / 机器离线"
* **现象**：在 Dashboard 数据库插入或添加了主机，但 Web 前端刷新看不到机器或显示离线。
* **根因**：
  1. Nezha Dashboard V2 前端默认只展示已在线汇报的机器（或由 `hide_for_guest` 字段控制）；
  2. 目标机器上必须真正运行 `nezha-agent` 且通信建立成功，机器卡片才会点亮展示 CPU/内存/网速。

### 坑 3：Alpine Linux (OpenRC) 守护进程启动崩溃
* **现象**：OpenRC 启动脚本报 `status: crashed`，提示 `Permission denied` 或参数语法错误。
* **根因**：OpenRC 默认的 `start-stop-daemon` 对长前台运行的 Go 二进制程序管理容易丢失 PID。
* **解决**：在 OpenRC 脚本中使用 `supervisor="supervise-daemon"`，配置简洁健壮：
```sh
#!/sbin/openrc-run
name="nezha-agent"
supervisor="supervise-daemon"
command="/opt/nezha/nezha-agent"
command_args="-c /opt/nezha/agent_config.yml"

depend() {
    need net
}
```

### 坑 4（最高频·致命）：Agent 裸跑无守护 → 一次意外退出就永久掉线
* **现象**：用户反馈"某台机器在面板上掉线了"，登上去发现 `nezha-agent` 进程**根本不存在**，且 `/etc/systemd/system/` 里没有任何 nezha 单元、`crontab -l` 也没有守护条目。
* **根因**：部署时用 `nohup`/裸 `&`/手动前台启动，从未注册守护。进程一旦被杀（**OOM Killer 是最常见的凶手**，尤其 1~2GB 的小实例）就再也没人拉起来，表现为"永久掉线"而非"偶发抖动"。
* **诊断四连**（缺一不可，只查进程会误判成"服务挂了重启就好"）：
  ```bash
  ps -eo pid,etime,cmd | grep '<agent 完整路径>' | grep -v grep   # 进程在不在
  ls /etc/systemd/system/ | grep -i nezha                        # 有没有 systemd 守护
  crontab -l 2>/dev/null | grep -ci nezha                        # 有没有 cron 守护
  grep oom_kill /proc/vmstat                                     # 是不是被 OOM 杀的
  ```
  `oom_kill > 0` 说明本机发生过 OOM，Agent 大概率是那次的连带受害者——此时**光装守护不够**，必须一并处理内存超配问题（Hermes 场景见 `hermes-gateway-ops` 技能的 `references/session-storage-corruption.md`「OOM 撑爆页缓存」节）。
* **修复：一律补 systemd 守护，不要只是手动把进程重启起来。**
  ```ini
  # /etc/systemd/system/nezha-agent.service
  [Unit]
  Description=Nezha Agent
  After=network-online.target
  Wants=network-online.target

  [Service]
  Type=simple
  User=ubuntu
  WorkingDirectory=/home/ubuntu/nezha-agent
  ExecStart=/home/ubuntu/nezha-agent/nezha-agent -c /home/ubuntu/nezha-agent/config.yml
  Restart=always
  RestartSec=5
  StandardOutput=append:/home/ubuntu/nezha-agent/agent.log
  StandardError=append:/home/ubuntu/nezha-agent/agent.log

  [Install]
  WantedBy=multi-user.target
  ```
  ```bash
  sudo install -m 644 /tmp/nezha-agent.service /etc/systemd/system/nezha-agent.service
  sudo systemctl daemon-reload && sudo systemctl enable --now nezha-agent.service
  systemctl is-enabled nezha-agent.service && systemctl is-active nezha-agent.service
  ```
  ⚠️ 用 `Wants/After=network-online.target`（不是 `network.target`）：跨公网上报的 Agent 在纯 `network.target` 下可能因路由未就绪而首连失败。
  ⚠️ `User=` 要匹配二进制与配置文件的所有者（例如 `ubuntu`），否则读不到 `config.yml`。
  ⚠️ 装完**必须用第 4 节的 ESTAB 检查收尾**：`is-active` 返回 active 只代表进程起来了，不代表连上了面板。
* **部署 Agent 时的默认动作**：任何一次 Agent 安装都直接把守护一起装上（systemd 或 OpenRC `supervise-daemon`），不要留"先手动跑起来看看"的裸进程——那就是下一次掉线的伏笔。

### 坑 5：Agent 日志可能是空的，别把"日志空"当"没启动"
`StandardOutput=append:` 指向的日志文件在 Agent 正常连通、无异常时**可能长时间为空**（V2 Agent 正常路径下很安静）。判断依据永远是第 4 节的 ESTAB，不是日志有没有内容。`journalctl -u nezha-agent` 一般只有一行 `Started ...`，同样正常。

## 7. 安全提醒（面板暴露面）
NAT 小鸡上把 `listen_port` 直接映射到公网高位端口（如 `34474`）等于**裸 HTTP 暴露登录页**：登录凭证明文传输，面板版本与站点名对外可见。向用户报告修复结果时应主动提示这一点并给出可选加固（Cloudflare 代理 / 反代加 TLS / 仅内网监听 + 隧道），但在用户同意前不要改动现有可用链路。
