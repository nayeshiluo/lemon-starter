# NAT 容器 VPS 单端口复用与代理节点排障指南

## 1. NAT 容器 / 超微型 VPS (128M~256M) 环境坑点

- **tmpfs 内存写满导致 OOM / 连接重置**：
  - 容器系统的 `/tmp` 通常是 `tmpfs` 虚拟文件系统（直接占用物理 RAM）。
  - 下载大于 20MB 的压缩包到 `/tmp` 或在 `/tmp` 中解压大文件，会直接吃光 192MB 内存，触发容器 cgroup 限制并导致 SSH 瞬间断开 (`Connection reset by peer`)。
  - **规范**：所有文件下载、解压与持久化存储必须直接落盘到物理根目录（如 `/root/`），严禁写入 `/tmp`。
- **Go 二进制兼容与轻量化**：
  - Debian 13 (Trixie) + Podman 容器环境对部分 Go 运行时有内存映射限制。若遇到 Go 程序 segfault，优先使用静态编译或经过验证的 Xray-core (go1.23+)、C 语言工具 (sslh / trojan-gfw) 或 Rust 工具 (shadowsocks-rust)。
  - Xray 极轻量部署仅占用约 15MB 物理内存，非常适合 192MB 内存的超微型 NAT 小鸡。

---

## 2. 单端口复用与 sslh “2 秒探测超时” 陷阱 (The sslh Anyprot Timeout Pitfall)

- **现象**：
  - NAT 机器全局只有一个公网端口映射（如 `23355 -> 内部 22`）。
  - 为了同时保留 SSH 管理并跑代理节点，使用 `sslh` 做端口复用：
    ```bash
    sslh -p 0.0.0.0:22 --ssh 127.0.0.1:2222 --anyprot 127.0.0.1:8388
    ```
  - 部署后用本地测试代理正常连通，但用户在 Clash / Shadowrocket / v2rayN 客户端中测延迟却显示 **“节点超时 / 节点不通”**。
- **根本原因**：
  - `sslh` 的协议探测机制是：收到连接先检查前几个字节是否匹配指定协议（如 SSH 的 `SSH-2.0...`、TLS 的 `\x16\x03...`）。
  - 如果是裸 Shadowsocks (AEAD) 等没有固定协议头的流量，`sslh` 无法立即识别，会**等待 probe timeout（默认 2 秒）** 直至超时，才降级转发到 `--anyprot`。
  - 客户端测速工具（Clash Verge、小火箭）的 TCP 握手测速超时一般为 1.5 秒，刚好被这 2 秒的探测等待截断，直接判定为不可达。
- **解决方案**：
  1. **放弃裸协议，改用 TLS 伪装协议（VLESS-Reality / Trojan）**：
     - TLS 报文首字节为 `0x16 0x03 0x01`（TLS ClientHello），`sslh --tls 127.0.0.1:443` 能在 **0 毫秒** 内瞬间命中并分流，彻底消除 2 秒等待。
  2. **终极纯净方案：直连单端口（0分流·0损耗·Web控制台管理）**：
     - 对于独角鲸云/各类 NAT 容器，控制面板自带免密 Web Console（控制台）。
     - 此时无需做复杂的端口多路复用，直接将 Shadowsocks-Rust 或 Trojan 绑定至 `0.0.0.0:22`，把 SSH 移至 2222 仅供本地/控制台访问。
     - 客户端直连 22 端口，消除所有中间分流层与探测超时，达到 100% 连通与极致低延迟。

---

## 3. 运维实战与高级技巧 (Operational Techniques)

- **通过 SOCKS5 代理隧道实现远程 SSH 维护（防失联黑科技）**：
  - 当外部单一端口（如 23355 -> 内部 22）被代理服务独占，且 SSH 监听在内部 `127.0.0.1:2222` 时，管理员无需依赖网页控制台，可直接利用该代理通道 SSH 登录维护：
    ```bash
    # 启动本地代理客户端 (监听 10888) 后，通过 ProxyCommand 穿透进容器
    ssh -o "ProxyCommand=nc -X 5 -x 127.0.0.1:10888 %h %p" -p 2222 root@127.0.0.1
    ```
- **热切换服务与测试时间窗口防护**：
  - 切换代理服务（如从 SS 切换到 Xray）时，若先 `systemctl stop` 再下载配置新服务，期间端口关闭会导致用户客户端测速瞬间报超时。
  - **规范**：准备好完整配置文件后再执行单行链式切换（`systemctl stop A && systemctl start B`），并明确提醒用户等待切换生效后再测速。
- **Reality `dest` 容器网络解析陷阱**：
  - 在非特权 Podman 容器内运行 Xray Reality 时，若 `dest`（如 `www.apple.com:443`）在容器内部 DNS 解析慢或与 TLS 1.3 握手异常，Xray 会直接向下游客户端发送 `Connection reset by peer`。
  - 遇到 Reality 连接重置时，先在容器内用 `curl -Iv https://<dest>` 验证 TLS 1.3 连通性，或优先使用无外部 `dest` 握手依赖的 Shadowsocks-Rust / Trojan。
