# MTProto Fake-TLS (mtg) 部署与端到端验证

## 适用场景
- 用户要「Telegram 内置代理」国内裸连（不挂梯）。S5 明文握手被 GFW 字节级识别秒断，只有服务器在国内 BGP 机才能裸连。
- 一键点亮链接：`tg://proxy?server=IP&port=PORT&secret=HEX` 或 `https://t.me/proxy?server=...&port=...&secret=...`（两者等价，后者可在任意聊天框点击）。

## 部署步骤（Alpine）
1. **安装 mtg ≥2.2.8**（apk 仓库可能是 2.1.x，有 DNS bug，见坑）：
   ```bash
   mkdir -p /var/tmp/mtg-upd && cd /var/tmp/mtg-upd
   curl -sL -o mtg.tar.gz https://github.com/9seconds/mtg/releases/download/v2.2.8/mtg-2.2.8-linux-amd64.tar.gz
   tar -xzf mtg.tar.gz -C x && cp $(find x -name mtg | head -1) /usr/local/bin/mtg && chmod +x /usr/local/bin/mtg
   ```
2. **生成 secret**：`mtg generate-secret --hex itunes.apple.com`（或 gateway.icloud.com）。输出以 `ee` 开头、尾部是伪装域 hex。
3. **配置** `/etc/mtg/config.toml`：
   ```toml
   secret = "ee..."   # 上一步输出
   bind-to = "0.0.0.0:80"   # 内部监听端口，NAT 映射外部端口到它
   ```
4. **OpenRC 守护** `/etc/init.d/mtg`（supervise-daemon 自动重启）：
   ```sh
   #!/sbin/openrc-run
   name="mtg"
   description="MTProto proxy service"
   supervisor="supervise-daemon"
   command="/usr/local/bin/mtg"
   command_args="run /etc/mtg/config.toml"
   output_log="/var/log/mtg.log"
   error_log="/var/log/mtg.err"
   depend() { need net; after firewall; }
   ```
   `chmod 755 /etc/init.d/mtg && rc-update add mtg default && rc-service mtg start`
5. **NAT 面板映射**：公网端口（如 30034）→ 内部端口（如 80），TCP。
6. **一键链接**：
   `https://t.me/proxy?server=<公网IP>&port=<公网映射端口>&secret=<HEX>`

## 验证（无 TG 客户端也能端到端）
```python
import socket, struct, os
def build_client_hello(sni: str) -> bytes:
    sni_bytes = sni.encode()
    server_name_list = b"\x00" + struct.pack(">H", len(sni_bytes)) + sni_bytes
    ext_sni = struct.pack(">H", len(server_name_list)) + server_name_list
    extension_sni = b"\x00\x00" + struct.pack(">H", len(ext_sni)) + ext_sni
    cipher_suites = bytes([0xc0,0x2f, 0xc0,0x2b, 0x00,0x9c, 0xcc,0xa8, 0x13,0x01])
    body = b"\x03\x03" + os.urandom(32) + b"\x00"
    body += struct.pack(">H", len(cipher_suites)) + cipher_suites
    body += b"\x01\x00"
    body += struct.pack(">H", len(extension_sni)) + extension_sni
    hs = b"\x01" + len(body).to_bytes(3, "big") + body
    return b"\x16\x03\x01" + struct.pack(">H", len(hs)) + hs

s = socket.create_connection(("IP", 30034), timeout=8)
s.sendall(build_client_hello("itunes.apple.com"))
hdr = s.recv(5)   # 0x16 = TLS Handshake = 正常；0x15 = Alert = 异常
```
判读：返回 TLS Handshake record（首字节 0x16）且载荷以 `02 00 00 ...`（ServerHello）开头 → 服务端在线且 fake-tls 正常。**注意 mtg 对任意 SNI 都返回克隆的 ServerHello**，"错误 SNI 也成功"是正常克隆行为，最终校验在客户端按 secret 内嵌域执行。

## 实测坑
1. **mtg 2.1.x DNS bug**：日志 `cannot resolve dns names: cannot find any ips for tcp:<域>`，系统 DNS 正常也无解 → 必须 2.2.8+。
2. **宿主 DNS 只回 IPv6**（Incus/LXC）：resolv.conf 的 `10.10.0.1` 解析 Apple 域只给 AAAA，容器 IPv6 又禁用 → 换 1.1.1.1/8.8.8.8，并写 `/etc/resolv.conf.head` 防 dhcpcd 覆盖。
3. 内存 <10MB；supervise-daemon 托管自动重启；日志默认只记 warn（有空连接不写日志属正常）。

## 延迟优化方法论
- **三层分段的实测顺序**：
  1. 用户侧→代理：`ss -tin` 找入站连接 `minrtt`（235ms 级=国内绕路/QoS，正常 CN2 <80ms）
  2. 代理→各 TG DC：`ping` 延迟矩阵（DC4 新加坡 180ms vs DC5 接入 34ms）
  3. 账号 DC vs 实际 DC：session 文件(sqlite sessions 表) 看绑定 DC；`ss -tnp | grep <mtg pid>` 看出站真实 DC
- **TG DC IP 表**：DC1 迈阿密 149.154.175.50 / DC2 阿姆斯特丹 149.154.167.51 / DC3 迪拜 149.154.175.100 / DC4 新加坡 149.154.167.91 / DC5 旧金山(亚洲接入) 91.108.56.130
- **廉价骨干识别**：traceroute 第二跳 `cogentco.com` = Cogent 廉价上游，HK→SG 绕 180ms、HK→US 34ms 即典型。
- **优化排序**：物理线路 > 协议 > 内核微调。微调项（`tcp_slow_start_after_idle=0`、`tcp_tw_reuse=1`、`ip_local_port_range=10000 65535`、`tcp_rmem/wmem` 上调，写 `/etc/sysctl.d/99-lemon-optimize.conf`）只是锦上添花。根治 = 换 CN2/BGP 线机器（腾讯轻量香港等，24-40 元/月）。
- **决策提示**：NAT 面板若无线路切换选项，接受现状或换机；S5 保留给海外自动化（AWS 出网挡箭牌），MTProto 专供 TG 内置代理，双轨互不干扰。

## 已落地实例（2026-09）
- 香港 Hytron NAT `45.196.236.222:30034 → 内 80`
- secret：`ee4568f8d5e563825d3589bdb25dc170c96974756e65732e6170706c652e636f6d`（itunes.apple.com）
- 一键链接：`https://t.me/proxy?server=45.196.236.222&port=30034&secret=ee4568f8d5e563825d3589bdb25dc170c96974756e65732e6170706c652e636f6d`
- DNS 已固化 1.1.1.1/8.8.8.8；Cogent 上行；国内入口 235ms、HK→DC4 180ms、HK→DC5 34ms；BBR + 内核微调已应用