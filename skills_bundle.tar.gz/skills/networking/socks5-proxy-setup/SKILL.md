---
name: socks5-proxy-setup
description: 搭建 SOCKS5 代理（dante/sockd）：认证、NAT 端口、验证。
---

# SOCKS5 代理服务器搭建（dante）

## When to Use

用户要求在小鸡/VPS 上"搞一个 S5/SOCKS5 代理"、给 Telegram 配代理、或任何"把某台服务器变成代理节点"的搭建任务。NAT VPS（商家给端口映射列表）尤其常见。只测别人的节点是否可用则用 `proxy-node-connectivity`。

## 标准流程

1. **安装 dante**
   - Alpine：`apk add dante-server`（守护进程叫 `sockd`）
   - Debian/Ubuntu：`apt install danted`（守护进程叫 `danted`，配置 /etc/danted.conf）

2. **写配置文件**：`/etc/sockd.conf`，模板见 `templates/sockd.conf`。要点：
   - `internal: 0.0.0.0 port = <内部监听端口>`
   - `external: eth0`（按 `ip addr` 实际网卡名）
   - `socksmethod: username` **必须同时出现在全局顶层和规则内**（见坑 1）
   - NAT 小鸡上内部端口由商家映射：`15113 -> 8080` 意思是外部连 15113，内部监听 8080

3. **创建认证系统用户**（dante 用户名认证查系统用户表，见坑 2）：
   ```bash
   adduser -D -s /sbin/nologin <user>          # Alpine
   echo "<user>:<password>" | chpasswd
   # Debian: useradd -M -s /sbin/nologin <user> && echo '<user>:<pass>' | chpasswd
   ```

4. **启动 + 开机自启**
   - Alpine：`rc-service sockd start && rc-update add sockd`
   - Debian：`systemctl enable --now danted`

5. **验证**（从另一台机器/跳板机走外部端口测）
   ```bash
   # 正确密码 → 期望 HTTP 200 且出口 IP = 小鸡公网 IP
   curl -x socks5h://USER:PASS@公网IP:外部端口 -s -o /dev/null -w "%{http_code}\n" https://ifconfig.me
   # 错误密码 → 期望连接失败（HTTP 000），证明认证强制生效
   curl -x socks5h://USER:错密码@公网IP:外部端口 -s -o /dev/null -w "%{http_code}\n" https://ifconfig.me
   ```
   TCP 通但 curl 挂 = 代理协议/认证问题，`tail /var/log/sockd.log` 查原因。

## 坑（实测踩过）

1. **全局 `socksmethod: username` 必须声明**：规则里用 `socksmethod: username` 时，配置顶层也必须有一行 `socksmethod: username`，否则启动失败：`method "username" is set in the rule, but not in the global socksmethod specification`。注意旧关键字 `method:` 会打印 deprecation 警告——只删那一行而不补全局 `socksmethod:` 会直接起不来。
2. **认证查的是系统用户表，不是自定义密码文件**：写过 `/etc/sockd.passwd` 没用，dante 报错 `could not access user "X"'s records in the system password file`。正解是建真实系统用户（nologin shell）+ chpasswd 设密码。
3. **NAT 端口映射**：给用户填的是**外部映射端口**（如 15113），不是内部监听端口（8080）。先 `bash -c 'echo > /dev/tcp/公网IP/外部端口'` 确认外部可达再排查代理本身。
4. **Dante 与 Telegram 客户端的兼容性陷阱（严重踩坑）**：
   - **症状**：用户在 Telegram 里配置 Dante S5 代理时显示“不可用 / 连接失败”，服务端日志 `/var/log/sockd.log` 狂刷：`unbound ipaddress (0.0.0.0.443) in request` 或 `connect(2) ... failed: Network unreachable`。
   - **原因**：Dante 在处理 Telegram 客户端的域名解析、多 DC 直连（如 `149.154.167.50:443`）与 `0.0.0.0` 绑定请求时存在 DNS 解析和路由缺陷，服务端主动拒绝了 TG 的请求。
   - **解决方案（推荐替代方案）**：在低配 VPS 或需要高兼容性时，**直接使用 sing-box 的 SOCKS5 inbound 替代 Dante**，内存更小（<15MB）、支持 RFC 1928/1929、自动接管 DNS 解析，对 Telegram 客户端 100% 兼容。
5. **Telegram SOCKS5 一键添加链接格式**：
   - 带认证：`https://t.me/socks?server=<IP>&port=<PORT>&user=<USER>&pass=<PASS>`（或 `tg://socks?server=...`）
   - 无认证：`https://t.me/socks?server=<IP>&port=<PORT>`
6. **国内裸连 Telegram S5 的两种情况分析**：
   - **IP 干净/非阻断海外直连**：只要 VPS 的 IP 和端口未被 GFW 封锁，Telegram 填 S5 可以直接裸连（很多海外云主机/小鸡可用）。
   - **国内中转 S5（商业 TG 代理常见方案）**：用户购买的所谓“免翻墙 TG S5”多数是国内 BGP 节点（如上海/广州等国内服务器 IP），国内连国内走明文 S5（不受 GFW 干扰），国内机器再通过加密隧道（Gost/专线/Shadowsocks）把流量送往海外落地机。

## 进阶方案一：使用 sing-box 搭建高兼容 SOCKS5（替代 Dante）

当需要为 Telegram 或常规客户端提供 SOCKS5 代理时，推荐使用 `sing-box` 替代传统的 dante：

```json
{
  "log": { "level": "info", "timestamp": true },
  "inbounds": [
    {
      "type": "socks",
      "tag": "socks-in",
      "listen": "::",
      "listen_port": 8080,
      "users": [
        {
          "username": "lemon",
          "password": "your_password"
        }
      ]
    }
  ],
  "outbounds": [
    { "type": "direct", "tag": "direct" }
  ]
}
```

## 进阶方案二：Telegram 专线原生代理（mtg MTProto Fake-TLS）

当用户需要**在 Telegram 客户端内直接配置代理、不挂后台 VPN 直连**：

1. **安装 mtg（Go 静态编译，内存占用 <10MB，极适合 Alpine/低配 NAT）**：
   ```bash
   curl -Lo /tmp/mtg.tar.gz https://github.com/9seconds/mtg/releases/download/v2.2.8/mtg-2.2.8-linux-amd64.tar.gz
   tar -xzf /tmp/mtg.tar.gz -C /tmp && cp /tmp/mtg-*/mtg /usr/local/bin/ && chmod +x /usr/local/bin/mtg
   ```
2. **生成 Fake-TLS Secret（伪装 Apple 域名）**：
   ```bash
   /usr/local/bin/mtg generate-secret itunes.apple.com
   # 输出为 base64 secret，如 7lYx1Uq1_hICpMHCcW3yiX5pdHVuZXMuYXBwbGUuY29t
   ```
3. **编写配置文件 `/etc/mtg/config.toml`**：
   ```toml
   secret = "<生成的 base64 secret>"
   bind-to = "0.0.0.0:80"  # 填内部监听端口
   ```
4. **Alpine OpenRC 守护进程 `/etc/init.d/mtg`**：
   ```bash
   #!/sbin/openrc-run
   name="mtg"
   description="MTProto proxy service"
   supervisor="supervise-daemon"
   command="/usr/local/bin/mtg"
   command_args="run /etc/mtg/config.toml"
   output_log="/var/log/mtg.log"
   error_log="/var/log/mtg.err"
   depend() { need net; after firewall; }
   ```
   启动：`chmod 755 /etc/init.d/mtg && rc-update add mtg default && rc-service mtg start`
5. **获取一键添加链接**：
   运行 `/usr/local/bin/mtg access /etc/mtg/config.toml`，提取 `tg_url` / `tme_url`（如遇 NAT 端口映射，将链接中的端口改为外部映射端口如 `15111`）。

## 进阶方案三：全能翻墙直连免挂梯方案（sing-box VLESS-Reality）

当用户需要从国内直接裸连翻墙且服务器为低配/NAT VPS（如 Alpine 256MB）：

1. **安装 sing-box（Alpine 环境需 gcompat）**：
   ```bash
   apk add --no-cache curl tar jq gcompat
   # 下载 linux-amd64 发布包并放置到 /usr/local/bin/sing-box
   ```
2. **生成 Reality 密钥与 UUID**：
   ```bash
   sing-box generate reality-keypair
   sing-box generate uuid
   sing-box generate rand --hex 8  # short_id
   ```
3. **配置 `/etc/sing-box/config.json`**：
   - 监听内部端口（如 443，对应 NAT 外部映射端口如 15112）
   - `server_name` 推荐 `itunes.apple.com` 或 `gateway.icloud.com`
4. **OpenRC 守护进程配置**：
   - 编写 `/etc/init.d/sing-box`（`command_background="yes"`, `pidfile="/run/sing-box.pid"`）
   - `rc-update add sing-box default && rc-service sing-box start`
5. **生成分享链接格式**：
   `vless://<UUID>@<公网IP>:<外部端口>?security=reality&encryption=none&pbk=<PubKey>&headerType=none&type=tcp&flow=xtls-rprx-vision&sni=<SNI>&sid=<ShortID>&fp=chrome#<节点名>`

## 相关边界

- 只测节点不搭服务 → 见 `proxy-node-connectivity`
- 订阅转 OpenAI 兼容 API → 见 `cliproxyapi`