---
name: socks5-proxy-setup
description: 搭建 SOCKS5 代理（dante/sockd）：认证、NAT 端口、验证。
---

# SOCKS5 代理服务器搭建（dante）

## When to Use

用户要求在小鸡/VPS 上"搞一个 S5/SOCKS5 代理"、给 Telegram 配代理、或任何"把某台服务器变成代理节点"的搭建任务。NAT VPS（商家给端口映射列表）尤其常见。只测别人的节点是否可用则用 `proxy-node-connectivity`。

## 标准流程

1. **安装 dante**
   - Alpine：`apk add dante-server`（守护进程叫 `sockd`）
   - Debian/Ubuntu：`apt install danted`（守护进程叫 `danted`，配置 /etc/danted.conf）

2. **写配置文件**：`/etc/sockd.conf`，模板见 `templates/sockd.conf`。要点：
   - `internal: 0.0.0.0 port = <内部监听端口>`
   - `external: eth0`（按 `ip addr` 实际网卡名）
   - `socksmethod: username` **必须同时出现在全局顶层和规则内**（见坑 1）
   - NAT 小鸡上内部端口由商家映射：`15113 -> 8080` 意思是外部连 15113，内部监听 8080

3. **创建认证系统用户**（dante 用户名认证查系统用户表，见坑 2）：
   ```bash
   adduser -D -s /sbin/nologin <user>          # Alpine
   echo "<user>:<password>" | chpasswd
   # Debian: useradd -M -s /sbin/nologin <user> && echo '<user>:<pass>' | chpasswd
   ```

4. **启动 + 开机自启**
   - Alpine：`rc-service sockd start && rc-update add sockd`
   - Debian：`systemctl enable --now danted`

5. **验证**（从另一台机器/跳板机走外部端口测）
   ```bash
   # 正确密码 → 期望 HTTP 200 且出口 IP = 小鸡公网 IP
   curl -x socks5h://USER:PASS@公网IP:外部端口 -s -o /dev/null -w "%{http_code}\n" https://ifconfig.me
   # 错误密码 → 期望连接失败（HTTP 000），证明认证强制生效
   curl -x socks5h://USER:错密码@公网IP:外部端口 -s -o /dev/null -w "%{http_code}\n" https://ifconfig.me
   ```
   TCP 通但 curl 挂 = 代理协议/认证问题，`tail /var/log/sockd.log` 查原因。

## 坑（实测踩过）

1. **全局 `socksmethod: username` 必须声明**：规则里用 `socksmethod: username` 时，配置顶层也必须有一行 `socksmethod: username`，否则启动失败：`method "username" is set in the rule, but not in the global socksmethod specification`。注意旧关键字 `method:` 会打印 deprecation 警告——只删那一行而不补全局 `socksmethod:` 会直接起不来。
2. **认证查的是系统用户表，不是自定义密码文件**：写过 `/etc/sockd.passwd` 没用，dante 报错 `could not access user "X"'s records in the system password file`。正解是建真实系统用户（nologin shell）+ chpasswd 设密码。
3. **NAT 端口映射**：给用户填的是**外部映射端口**（如 15113），不是内部监听端口（8080）。先 `bash -c 'echo > /dev/tcp/公网IP/外部端口'` 确认外部可达再排查代理本身。
4. **Dante 与 Telegram 客户端的兼容性陷阱（严重踩坑）**：
   - **症状**：用户在 Telegram 里配置 Dante S5 代理时显示“不可用 / 连接失败”，服务端日志 `/var/log/sockd.log` 狂刷：`unbound ipaddress (0.0.0.0.443) in request` 或 `connect(2) ... failed: Network unreachable`。
   - **原因**：Dante 在处理 Telegram 客户端的域名解析、多 DC 直连（如 `149.154.167.50:443`）与 `0.0.0.0` 绑定请求时存在 DNS 解析和路由缺陷，服务端主动拒绝了 TG 的请求。
   - **解决方案（推荐替代方案）**：在低配 VPS 或需要高兼容性时，**直接使用 sing-box 的 SOCKS5 inbound 替代 Dante**，内存更小（<15MB）、支持 RFC 1928/1929、自动接管 DNS 解析，对 Telegram 客户端 100% 兼容。
5. **Telegram SOCKS5 一键添加链接格式**：
   - 带认证：`https://t.me/socks?server=<IP>&port=<PORT>&user=<USER>&pass=<PASS>`（或 `tg://socks?server=...`）
   - 无认证：`https://t.me/socks?server=<IP>&port=<PORT>`
6. **国内裸连 Telegram S5 的两种情况分析**：
   - **IP 干净/非阻断海外直连**：只要 VPS 的 IP 和端口未被 GFW 封锁，Telegram 填 S5 可以直接裸连（很多海外云主机/小鸡可用）。
   - **国内中转 S5（商业 TG 代理常见方案）**：用户购买的所谓“免翻墙 TG S5”多数是国内 BGP 节点（如上海/广州等国内服务器 IP），国内连国内走明文 S5（不受 GFW 干扰），国内机器再通过加密隧道（Gost/专线/Shadowsocks）把流量送往海外落地机。
7. **Telegram Telethon 会话跨 IP 迁移陷阱（AuthKeyDuplicatedError）**：
   - **现象**：将 `.session` 文件复制到新 VPS 并发请求时，报错 `AuthKeyDuplicatedError: The authorization key (session file) was used under two different IP addresses simultaneously`。
   - **原因**：Telegram MTProto 服务端检测到同一 AuthKey 从两个不同国家/机房 IP 同时发起连接，会强制吊销该 Session 密钥。
   - **对策**：在迁移前务必彻底停止旧服务器上的 Telethon 进程（`pkill -f userbot`），或在新服务器上通过手机号重新生成独立的 Session 文件。
8. **Docker 容器化极低内存占用（实测 <10MB）**：
   - 使用 `teddysun/xray:latest` 容器同时承载 VLESS-Reality 与 SOCKS5，实测内存开销仅 ~7.6MB；
   - 使用 `telegrammessenger/proxy:latest` 容器承载 MTProto，内存开销仅 ~10.8MB；
   - 2GB/1GB 低配 VPS 完全无压力，推荐采用 Docker Compose 独立容器化运行以隔离网络和宿主环境。
9. **Loon 订阅分发服务的标准端口陷阱（80 端口 vs 高位端口）**：
   - **症状**：在 Loon / Shadowrocket 客户端添加订阅 `http://IP:8688/` 时提示 `下载订阅资源失败: 请求超时`。
   - **原因**：国内移动/联通/电信直连海外 VPS 的非标准高位端口（如 8688/8080）极易被运营商防火墙直接丢包阻断。
   - **对策**：订阅分发服务务必监听标准 **80 端口**（`http://IP/`），并在 systemd 中设置 `User=root`（避免非 root 绑定 80 端口报 `PermissionError: [Errno 13] Permission denied`）。
10. **Reality 延迟测试「163ms, Timeout」排查与 Shadowsocks 备份策略**：
   - **症状**：Loon 节点测试显示 `163ms, Timeout`（TCP ping 正常，但 HTTP 204 测速超时）。
   - **原因**：Reality 选用的伪装域名（如 `gateway.icloud.com`）在部分网络环境下 TLS 握手/ALPN 回落受阻。
   - **对策**：将 Reality 的 `dest` 和 `serverNames` 切换为通用性更好的 `www.microsoft.com` 或 `itunes.apple.com`（避免 `gateway.icloud.com` 在国内被解析至云上贵州导致证书不一致），并在 Xray 容器中同时配置一个标准 **Shadowsocks (aes-128-gcm)** 节点作为全能备用。
11. **超微型 NAT 容器（<256MB 内存，如 192M Podman/LXC）下载与运行时陷阱**：
   - **tmpfs 内存爆破**：多数容器系统默认将 `/tmp` 挂载为 `tmpfs`（直接占用 RAM）。在 192M 内存小鸡上直接 `curl -Lo /tmp/pkg.tar.gz` 下载 30M~50M 的大二进制包或在 `/tmp` 解压会瞬间吃满内存触发 cgroup OOM，导致进程被杀且 SSH 断开（`Connection reset by peer`）。
   - **对策**：下载与解压必须指定真实磁盘目录（如 `/root/` 或 `/var/tmp/`），避开 tmpfs。
   - **组件选型**：超微内存容器优先推荐原生 C 编写或 APT 仓库轻量组件（如 `shadowsocks-libev`，内存占用仅 3~5MB）或极轻量 Rust，避免在严格 cgroup 限制下冷启动大体积 Go 二进制。
12. **NAT 小鸡仅分配单一 SSH 端口时的多路复用方案（sslh 分流）**：
   - **场景**：很多超低价 NAT 容器（如独角鲸云 $0.88 等）后台不提供自定义端口映射，全局仅分配一个公网入口端口（如 `23355 -> 内部 22`）。
   - **误区**：直接占用 22 端口跑代理会导致 SSH 永久失联，或以为单端口无法跑节点。
   - **解决方案**：使用 C 编写的极轻量端口复用神器 `sslh`（内存仅 1.5MB）：
     1. 将 sshd 内部监听移至 `127.0.0.1:2222`；
     2. 代理服务（如 shadowsocks-rust / trojan）监听 `127.0.0.1:8388`；
     3. `sslh` 监听 `0.0.0.0:22`，配置 `--ssh 127.0.0.1:2222 --anyprot 127.0.0.1:8388`；
     4. 外部通过同一端口既能正常 SSH 登录管理，又能一键连接代理节点。
13. **Sing-Box 1.14.0+ DNS 配置格式废除陷阱（服务崩溃）**：
   - **症状**：在 Sing-box 1.14.0+ 启动时报 `FATAL: legacy DNS server formats are deprecated in 1.12.0 and removed in 1.14.0`，导致服务秒退、端口无法监听。
   - **对策**：在轻量 NAT 小鸡上直接省略冗余的顶层 `dns` 配置块，让 Sing-box 原生继承系统的 `/etc/resolv.conf`；如需自定义 DNS，必须遵循新版带 `type` 字段的规范结构。
14. **小火箭 (Shadowrocket) Vision 流控与明文探测假超时陷阱**：
   - **症状**：小火箭测速显示 `295ms, Timeout`，但底层 TCP ping 正常。
   - **原因**：小火箭点击“延迟测试”发送的是纯 HTTP 明文探测包。当服务端或客户端强制启用了 `flow=xtls-rprx-vision` 时，针对明文探测包的流控解析可能被客户端直接丢弃，造成“假超时”。
   - **对策**：在 NAT VPS 上服务端 `users` 配置中去除强制 `flow: xtls-rprx-vision` 约束，客户端 URL 去除 `flow=...` 参数，使用标准纯净 VLESS Reality。
15. **Alpine/LXC 容器未通 IPv6 导致的网络挂起延迟**：
   - **症状**：`curl` 或代理请求时卡顿数秒，日志出现 `Immediate connect fail for [2001:...]: Network unreachable`。
   - **对策**：在 `/etc/sysctl.conf` 写入 `net.ipv6.conf.all.disable_ipv6 = 1` 并执行 `sysctl -p`，彻底关闭无外网路由的 IPv6 寻址等待。
16. **移动端 SSH 工具（如 ServerCat / Termius）连接 NAT VPS 的端口覆盖陷阱**：
   - **症状**：在 ServerCat 中填写 NAT VPS 连接时持续转圈或反复弹出密码输入框（`root@IP:22`）。
   - **原因**：ServerCat 等客户端在输入 IP 后默认填充内部标准端口 `22`；由于 NAT VPS 外部访问依赖高位映射端口（如 `30023 -> 22`），未修改端口会导致请求直接命中宿主机防火墙或超时。
   - **对策**：在移动端 SSH 工具中必须显式将「端口」从 22 改为分配的**公网高位映射端口**。
17. **ServerStatus-Rust 极轻量探针在 Alpine NAT 容器上的极速部署规范 (<8MB 内存)**：
   - **架构优势**：Rust 编写、单二进制文件、自带 Web 监控大屏（CPU/内存/实时上下行网速/三网延迟/Uptime），服务端+客户端常驻仅占 ~5MB 内存。
   - **下载安装（Alpine musl 原生包）**：
     ```bash
     mkdir -p /opt/serverstatus/web && cd /opt/serverstatus
     wget -q https://github.com/zdz/ServerStatus-Rust/releases/download/v1.8.1/server-x86_64-unknown-linux-musl.zip
     unzip -q server-x86_64-unknown-linux-musl.zip
     wget -q https://github.com/zdz/ServerStatus-Rust/releases/download/v1.8.1/client-x86_64-unknown-linux-musl.zip
     unzip -q client-x86_64-unknown-linux-musl.zip
     # 提取 Web 前端静态文件到 /opt/serverstatus/web/
     chmod +x stat_server stat_client
     ```
   - **服务端配置 `/opt/serverstatus/config.toml`**：
     ```toml
     grpc_addr = "127.0.0.1:9394"
     http_addr = "0.0.0.0:8088"  # 内部监听端口，对应 NAT 外网映射端口（如 34474）
     offline_threshold = 30
     hosts = [
       {name = "hk-hytron", password = "SecretPassword", alias = "🇭🇰 香港 Hytron NAT", location = "hk", type = "lxc"},
       {name = "rn-la", password = "SecretPassword", alias = "🇺🇸 洛杉矶 RackNerd", location = "us", type = "kvm"}
     ]
     ```
   - **Alpine OpenRC 守护进程注册**：
     - `/etc/init.d/stat-server`：`command="/opt/serverstatus/stat_server"`, `command_args="-c /opt/serverstatus/config.toml"`
     - `/etc/init.d/stat-client`：`command="/opt/serverstatus/stat_client"`, `command_args="-a http://127.0.0.1:8088/report -u hk-hytron -p SecretPassword --alias '🇭🇰 香港 Hytron NAT' -t lxc --location hk"`
     - `rc-update add stat-server default && rc-update add stat-client default`
   - **其他外部服务器挂载一键指令**：
     ```bash
     ./stat_client -a http://<公网IP>:<外网映射端口>/report -u rn-la -p SecretPassword --alias '🇺🇸 洛杉矶 RackNerd' -t kvm --location us
     ```
18. **廉价 NAT 小鸡作为主服务器（如 AWS EC2）出网流量挡箭牌的实战规范**：
   - **痛点**：主服务器每月严格限制免费出网流量（如 AWS 100GB/月），爬虫大图抓取、TG 媒体下载极易消耗配额。
   - **最佳实践**：在廉价大流量 NAT 小鸡部署认证 SOCKS5，主服务器代码中统一注入代理：
     ```python
     import requests
     proxies = {
         "http": "socks5h://user:pass@NAT_IP:NAT_PORT",
         "https": "socks5h://user:pass@NAT_IP:NAT_PORT"
     }
     # 外部请求 100% 走小鸡出网，主服务器消耗 0 流量
     resp = requests.get("https://api.telegram.org", proxies=proxies, timeout=10)
     ```
19. **哪吒监控 V2 (Nezha Dashboard V2) 在 Alpine NAT 容器上的独立高颜值面板部署与 Sqlite 自动化初始化规范**：
   - **场景**：当用户觉得 ServerStatus 默认主题简陋，需要现代卡片式全功能高颜值大屏、统一监控名下所有资产机器（CPU/内存/实时上下行/累计流量/国旗图标）时，首选官方哪吒 V2（Nezha v2.3.7+）。
   - **单二进制极速安装 (Alpine musl/gcompat)**：
     ```bash
     mkdir -p /opt/nezha/dashboard/data && cd /opt/nezha/dashboard
     wget -q https://github.com/nezhahq/nezha/releases/download/v2.3.7/dashboard-linux-amd64.zip
     unzip -q dashboard-linux-amd64.zip && chmod +x dashboard-linux-amd64
     ```
   - **精简配置 `/opt/nezha/dashboard/data/config.yaml`**：
     ```yaml
     admin_template: admin-dist
     agent_secret_key: SecretKeyHere
     avg_ping_count: 2
     cover: 1
     jwt_timeout: 30
     language: zh_CN
     listen_port: 8088 # 内部端口，对应 NAT 外网映射端口
     location: Asia/Shanghai
     site_name: "🍋 柠檬专属多服务器监控"
     user_template: user-dist
     ```
   - **OpenRC 守护进程 `/etc/init.d/nezha-dashboard`**：
     ```bash
     #!/sbin/openrc-run
     name="nezha-dashboard"
     description="Nezha Monitoring Dashboard"
     command="/opt/nezha/dashboard/dashboard-linux-amd64"
     command_args="-c /opt/nezha/dashboard/data/config.yaml -db /opt/nezha/dashboard/data/sqlite.db"
     command_background=true
     pidfile="/run/nezha-dashboard.pid"
     directory="/opt/nezha/dashboard"
     depend() { need net; }
     ```
   - **自动化生成与重置管理员账号与预设卡片**：
     - 借助 `apache2-utils` 的 `htpasswd -B` 或 Python 写入标准 bcrypt 哈希到 `users` 表；
     - 预设机器在 `servers` 表插入 `(created_at, updated_at, user_id, name, uuid, note, public_note, display_index)`，实现无头自动化上线。
20. **哪吒监控 V2 (Nezha Agent 2.3+) 在 Alpine OpenRC 与多平台远端纳管陷阱**：
   - **UUID 格式严格校验**：`config.yml` 与数据库中的 `uuid` 必须为标准的 36 位 RFC 4122 UUID 格式（如 `e3ba469f-7673-40c6-a15e-b8bbda8086e3`），不可使用自定义短字符串，否则 Agent 启动报 `init config failed: uuid string is wrong length`。
   - **Alpine OpenRC 保活**：OpenRC 启动脚本中推荐声明 `supervisor="supervise-daemon"`，让系统级 supervisor-daemon 接管 Go 进程的自动重启与保活，避免 `command_background=true` 误判 crashed。
   - **远端多机无依赖解压与注册**：在部分远端 VPS（无 unzip 预装）上部署 Agent 时，直接使用 `python3 -c "import zipfile; zipfile.ZipFile('agent.zip').extractall('dir')"` 零依赖解压并注册 systemd，实现秒级点亮。

## 进阶方案四：Loon 专属配置规范与极简订阅分发服务

### 1. Loon 专属节点格式规范
- **VLESS-Reality**：
  ```text
  节点名 = vless, IP, PORT, "UUID", flow=xtls-rprx-vision, security=reality, reality-public-key=PubKey, reality-short-id=ShortId, reality-server-name=SNI, transport=tcp, fast-open=false
  ```
- **SOCKS5**：
  ```text
  节点名 = socks5, IP, PORT, "USER", "PASS", fast-open=false
  ```

### 2. 零依赖 Python 轻量订阅分发服务（支持 Base64 与 Loon 原生格式）
部署在服务器指定端口（如 8688），让 Loon / 小火箭 / Clash 一键订阅拉取：
```python
from http.server import HTTPServer, BaseHTTPRequestHandler
import base64

VLESS_LINK = "vless://<UUID>@<IP>:<PORT>?encryption=none&flow=xtls-rprx-vision&security=reality&sni=<SNI>&fp=chrome&pbk=<PUBKEY>&sid=<SID>&type=tcp#节点名"
S5_LINK = "socks5://<USER>:<PASS>@<IP>:<PORT>#节点名"
LOON_CONFIG = """[Proxy]
节点名-Reality = vless, <IP>, <PORT>, "<UUID>", flow=xtls-rprx-vision, security=reality, reality-public-key=<PUBKEY>, reality-short-id=<SID>, reality-server-name=<SNI>, transport=tcp, fast-open=false
节点名-S5 = socks5, <IP>, <PORT>, "<USER>", "<PASS>", fast-open=false
"""

class SubHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        self.send_response(200)
        self.send_header('Content-Type', 'text/plain; charset=utf-8')
        self.send_header('Subscription-Userinfo', 'upload=0; download=0; total=5368709120000; expire=1893456000')
        self.end_headers()
        if '/loon' in self.path:
            self.wfile.write(LOON_CONFIG.encode('utf-8'))
        else:
            nodes_text = f"{VLESS_LINK}\n{S5_LINK}\n"
            self.wfile.write(base64.b64encode(nodes_text.encode('utf-8')))

if __name__ == '__main__':
    HTTPServer(('0.0.0.0', 8688), SubHandler).serve_forever()
```

## 进阶方案一：使用 sing-box 搭建高兼容 SOCKS5（替代 Dante）

当需要为 Telegram 或常规客户端提供 SOCKS5 代理时，推荐使用 `sing-box` 替代传统的 dante：

```json
{
  "log": { "level": "info", "timestamp": true },
  "inbounds": [
    {
      "type": "socks",
      "tag": "socks-in",
      "listen": "::",
      "listen_port": 8080,
      "users": [
        {
          "username": "lemon",
          "password": "your_password"
        }
      ]
    }
  ],
  "outbounds": [
    { "type": "direct", "tag": "direct" }
  ]
}
```

## 进阶方案二：Telegram 专线原生代理（mtg MTProto Fake-TLS）

当用户需要**在 Telegram 客户端内直接配置代理、不挂后台 VPN 直连**：

1. **安装 mtg（Go 静态编译，内存占用 <10MB，极适合 Alpine/低配 NAT）**：
   ```bash
   curl -Lo /tmp/mtg.tar.gz https://github.com/9seconds/mtg/releases/download/v2.2.8/mtg-2.2.8-linux-amd64.tar.gz
   tar -xzf /tmp/mtg.tar.gz -C /tmp && cp /tmp/mtg-*/mtg /usr/local/bin/ && chmod +x /usr/local/bin/mtg
   ```
2. **生成 Fake-TLS Secret（伪装 Apple 域名）**：
   ```bash
   /usr/local/bin/mtg generate-secret itunes.apple.com
   # 输出为 base64 secret，如 7lYx1Uq1_hICpMHCcW3yiX5pdHVuZXMuYXBwbGUuY29t
   ```
3. **编写配置文件 `/etc/mtg/config.toml`**：
   ```toml
   secret = "<生成的 base64 secret>"
   bind-to = "0.0.0.0:80"  # 填内部监听端口
   ```
4. **Alpine OpenRC 守护进程 `/etc/init.d/mtg`**：
   ```bash
   #!/sbin/openrc-run
   name="mtg"
   description="MTProto proxy service"
   supervisor="supervise-daemon"
   command="/usr/local/bin/mtg"
   command_args="run /etc/mtg/config.toml"
   output_log="/var/log/mtg.log"
   error_log="/var/log/mtg.err"
   depend() { need net; after firewall; }
   ```
   启动：`chmod 755 /etc/init.d/mtg && rc-update add mtg default && rc-service mtg start`
5. **获取一键添加链接**：
   运行 `/usr/local/bin/mtg access /etc/mtg/config.toml`，提取 `tg_url` / `tme_url`（如遇 NAT 端口映射，将链接中的端口改为外部映射端口如 `15111`）。

## 进阶方案三：全能翻墙直连免挂梯方案（sing-box VLESS-Reality）

当用户需要从国内直接裸连翻墙且服务器为低配/NAT VPS（如 Alpine 256MB）：

1. **安装 sing-box（Alpine 环境需 gcompat）**：
   ```bash
   apk add --no-cache curl tar jq gcompat
   # 下载 linux-amd64 发布包并放置到 /usr/local/bin/sing-box
   ```
2. **生成 Reality 密钥与 UUID**：
   ```bash
   sing-box generate reality-keypair
   sing-box generate uuid
   sing-box generate rand --hex 8  # short_id
   ```
3. **配置 `/etc/sing-box/config.json`**：
   - 监听内部端口（如 443，对应 NAT 外部映射端口如 15112）
   - `server_name` 推荐 `itunes.apple.com` 或 `gateway.icloud.com`
4. **OpenRC 守护进程配置**：
   - 编写 `/etc/init.d/sing-box`（`command_background="yes"`, `pidfile="/run/sing-box.pid"`）
   - `rc-update add sing-box default && rc-service sing-box start`
5. **生成分享链接格式**：
   `vless://<UUID>@<公网IP>:<外部端口>?security=reality&encryption=none&pbk=<PubKey>&headerType=none&type=tcp&flow=xtls-rprx-vision&sni=<SNI>&sid=<ShortID>&fp=chrome#<节点名>`

## 进阶方案五：Alpine 官方原生极轻量 Shadowsocks-Rust 搭建（<10MB 内存，零外部下载）

当小鸡为 Alpine Linux（尤其是超微型 LXC NAT 容器，如 128M/256M/512M 规格），官方 `community` 源自带 `shadowsocks-rust-ssserver`，**无需从 GitHub 下载外部二进制**，避免了 tmpfs 内存爆破和网络拉取超时问题：

1. **一键安装**：
   ```bash
   apk add --no-cache shadowsocks-rust-ssserver
   ```
2. **配置文件 `/etc/shadowsocks-rust/config.json`**：
   ```json
   {
       "server": "0.0.0.0",
       "server_port": 81,
       "password": "YourStrongPasswordHere",
       "method": "aes-256-gcm",
       "timeout": 300,
       "mode": "tcp_and_udp",
       "fast_open": false
   }
   ```
3. **OpenRC 守护进程 `/etc/init.d/shadowsocks-rust`**：
   ```bash
   #!/sbin/openrc-run
   name="shadowsocks-rust"
   description="Shadowsocks Rust Service"
   command="/usr/bin/ssserver"
   command_args="-c /etc/shadowsocks-rust/config.json"
   command_background=true
   pidfile="/run/shadowsocks-rust.pid"

   depend() {
       need net
   }
   ```
   启动与开机自启：
   ```bash
   chmod +x /etc/init.d/shadowsocks-rust
   rc-update add shadowsocks-rust default
   rc-service shadowsocks-rust restart
   ```
4. **客户端链接生成规范 (SIP002 标准)**：
   - Base64 编码 `method:password`（例如 `aes-256-gcm:YourStrongPasswordHere` -> `YWVzLTI1Ni1nY206...`）
   - 链接结构：`ss://<BASE64_USERPASS>@<公网IP>:<外部映射端口>#<URL_ENCODED_TAG>`
   - Clash 配置：`type: ss`, `cipher: aes-256-gcm`, `port: <外部映射端口>`

## 相关边界

- 单端口 NAT 小鸡多路复用部署节点 → 见坑 12 及进阶方案五（`sslh` + `shadowsocks-rust`）
- 只测节点不搭服务 → 见 `proxy-node-connectivity`
- 订阅转 OpenAI 兼容 API → 见 `cliproxyapi`