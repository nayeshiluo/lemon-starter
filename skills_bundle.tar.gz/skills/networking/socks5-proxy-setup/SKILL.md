---
name: socks5-proxy-setup
description: 搭建 SOCKS5 代理（dante/sockd）：认证、NAT 端口、验证。
---

# SOCKS5 代理服务器搭建（dante）

## When to Use

用户要求在小鸡/VPS 上"搞一个 S5/SOCKS5 代理"、给 Telegram 配代理、或任何"把某台服务器变成代理节点"的搭建任务。NAT VPS（商家给端口映射列表）尤其常见。只测别人的节点是否可用则用 `proxy-node-connectivity`。

## 标准流程

1. **安装 dante**
   - Alpine：`apk add dante-server`（守护进程叫 `sockd`）
   - Debian/Ubuntu：`apt install danted`（守护进程叫 `danted`，配置 /etc/danted.conf）

2. **写配置文件**：`/etc/sockd.conf`，模板见 `templates/sockd.conf`。要点：
   - `internal: 0.0.0.0 port = <内部监听端口>`
   - `external: eth0`（按 `ip addr` 实际网卡名）
   - `socksmethod: username` **必须同时出现在全局顶层和规则内**（见坑 1）
   - NAT 小鸡上内部端口由商家映射：`15113 -> 8080` 意思是外部连 15113，内部监听 8080

3. **创建认证系统用户**（dante 用户名认证查系统用户表，见坑 2）：
   ```bash
   adduser -D -s /sbin/nologin <user>          # Alpine
   echo "<user>:<password>" | chpasswd
   # Debian: useradd -M -s /sbin/nologin <user> && echo '<user>:<pass>' | chpasswd
   ```

4. **启动 + 开机自启**
   - Alpine：`rc-service sockd start && rc-update add sockd`
   - Debian：`systemctl enable --now danted`

5. **验证**（从另一台机器/跳板机走外部端口测）
   ```bash
   # 正确密码 → 期望 HTTP 200 且出口 IP = 小鸡公网 IP
   curl -x socks5h://USER:PASS@公网IP:外部端口 -s -o /dev/null -w "%{http_code}\n" https://ifconfig.me
   # 错误密码 → 期望连接失败（HTTP 000），证明认证强制生效
   curl -x socks5h://USER:错密码@公网IP:外部端口 -s -o /dev/null -w "%{http_code}\n" https://ifconfig.me
   ```
   TCP 通但 curl 挂 = 代理协议/认证问题，`tail /var/log/sockd.log` 查原因。

## 坑（实测踩过）

1. **全局 `socksmethod: username` 必须声明**：规则里用 `socksmethod: username` 时，配置顶层也必须有一行 `socksmethod: username`，否则启动失败：`method "username" is set in the rule, but not in the global socksmethod specification`。注意旧关键字 `method:` 会打印 deprecation 警告——只删那一行而不补全局 `socksmethod:` 会直接起不来。
2. **认证查的是系统用户表，不是自定义密码文件**：写过 `/etc/sockd.passwd` 没用，dante 报错 `could not access user "X"'s records in the system password file`。正解是建真实系统用户（nologin shell）+ chpasswd 设密码。
3. **NAT 端口映射**：给用户填的是**外部映射端口**（如 15113），不是内部监听端口（8080）。先 `bash -c 'echo > /dev/tcp/公网IP/外部端口'` 确认外部可达再排查代理本身。
4. **S5 只代理 Telegram 流量**：纯 SOCKS5 不加密、不管其他 App，不能替代梯子；跟用户说清楚，避免误会。

## 相关边界

- 只测节点不搭服务 → 见 `proxy-node-connectivity`
- 订阅转 OpenAI 兼容 API → 见 `cliproxyapi`